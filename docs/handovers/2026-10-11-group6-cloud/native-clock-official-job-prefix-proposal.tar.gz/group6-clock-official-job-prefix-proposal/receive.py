from pathlib import Path
import subprocess,hashlib,json,shutil,os,difflib,tempfile
P=Path(__file__).resolve().parent;REPO=Path('/workspace/ergopti');root=Path(tempfile.mkdtemp(prefix='physical-source-',dir=P));tmp=root.parent/(root.name+'-private-tmp');tmp.mkdir(mode=0o700)
roots=['static/ergopti_plus/macos/launcher','static/ergopti_plus/macos/adapters/release_stage.sh','static/ergopti_plus/_shared/modules/updater/defaults.json','tools/build','tools/diagnostics','static/ergopti_plus/macos/tests/support','static/ergopti_plus/macos/platform/network','static/ergopti_plus/_shared/python/network_proxy_policy.py','static/ergopti_plus/_shared/modules/network']
files=set(subprocess.check_output(['git','ls-files','-z','--',*roots],cwd=REPO).decode().split('\0'));files.discard('')
files.update(['tools/ci/native_http_clock_evidence.cjs','tools/ci/dev-release-qualification.cjs','.github/workflows/ci.yml','.github/workflows/ci-macos.yml','.github/ci/dev_release_qualification_exceptions.json','.github/ci/stable_release_qualification_exception.json','tools/test/export-macos-managed-http-test-deps.py','static/ergopti_plus/macos/uv.lock','tools/test/test-native-http-clock-evidence.cjs','tools/test/test-managed-ollama-protocol.cjs','tools/test/fixtures/native_http_clock_workflow.yml','tools/lib/git-bash.cjs','tools/lib/python.cjs'])
pins={}
for rel in sorted(files):
 raw=(REPO/rel).read_bytes();pins[rel]=hashlib.sha256(raw).hexdigest();out=root/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
(P/'source-inventory.json').write_text(json.dumps(pins,indent=2)+'\n')
env=os.environ.copy();env.update({'TMPDIR':str(tmp),'NODE_PATH':'/workspace/ergopti/node_modules','GIT_CEILING_DIRECTORIES':str(P)})
for args in [['init','-q'],['config','user.name','Bounded official metadata receiving'],['config','user.email','portable@example.invalid'],['add','--all'],['commit','-qm','Frozen actual source input']]:subprocess.run(['git','-c','core.hooksPath=/dev/null',*args],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
for rel in ['tools/ci/native_http_clock_evidence.cjs','tools/test/test-native-http-clock-evidence.cjs']:(root/rel).write_bytes((P/'candidate'/rel).read_bytes())
# A physical test file executes exactly its original helper definitions and
# selected official callback. The original full script is retained for full32.
js=r'''const fs=require('node:fs'),path=require('node:path'),acorn=require('acorn'),assert=require('node:assert/strict');const P=process.argv[2],root=process.argv[3],rel='tools/test/test-native-http-clock-evidence.cjs';const source=fs.readFileSync(path.join(root,rel),'utf8');const ast=acorn.parse(source,{ecmaVersion:'latest'});let target;function walk(n){if(!n||typeof n!=='object')return;if(n.type==='CallExpression'&&n.callee.name==='control'&&n.arguments[0]?.value==='official metadata consistency never authenticates caller JSON')target=n;for(const [k,v] of Object.entries(n))if(k!=='start'&&k!=='end'){if(Array.isArray(v))v.forEach(walk);else if(v&&typeof v==='object')walk(v);}}walk(ast);assert.ok(target);let result='';for(const n of ast.body){if(n.type==='TryStatement')break;result+=source.slice(n.start,n.end)+'\n';}result+=source.slice(target.start,target.end)+';\nassert.equal(received,1);\nfs.rmSync(temporary,{recursive:true,force:true});\n';fs.writeFileSync(path.join(root,'tools/test/official-metadata-focus.cjs'),result);'''
subprocess.run(['node','-e',js,'-',str(P),str(root)],cwd=root,env=env,check=True)
records=[]
def fence():
 for rel,pin in pins.items():assert hashlib.sha256((REPO/rel).read_bytes()).hexdigest()==pin,rel

def run(name,relative):
 fence();stdout=P/(name+'.stdout');stderr=P/(name+'.stderr')
 with stdout.open('wb') as out,stderr.open('wb') as err:r=subprocess.run(['node',str(root/relative)],cwd=root,env=env,stdout=out,stderr=err,timeout=120)
 fence();raw=stdout.read_text();rec={'name':name,'exit':r.returncode,'PASS_lines':len([l for l in raw.splitlines() if l.startswith('PASS ')]),'stdout_sha256':hashlib.sha256(stdout.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(stderr.read_bytes()).hexdigest(),'source_count':len(pins),'canonical_source_fence':True,'native':False,'official_authentication':False};records.append(rec);(P/'receipts.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True);return r.returncode
wrapper='tools/ci/native_http_clock_evidence.cjs'
(root/wrapper).write_bytes((P/'preimages'/wrapper).read_bytes());assert run('original-comparison-new-literal-red','tools/test/official-metadata-focus.cjs')==1
assert 'Official job consistency refused' in (P/'original-comparison-new-literal-red.stderr').read_text()
(root/wrapper).write_bytes((P/'candidate'/wrapper).read_bytes());assert run('candidate-focus-green','tools/test/official-metadata-focus.cjs')==0
assert run('candidate-physical32','tools/test/test-native-http-clock-evidence.cjs')==0
assert 'CLOCK_RECEIVER controls=32 native=false official=false' in (P/'candidate-physical32.stdout').read_text()
assert records[-1]['PASS_lines']==32
print(json.dumps({'terminal':True,'root':str(root)}))
