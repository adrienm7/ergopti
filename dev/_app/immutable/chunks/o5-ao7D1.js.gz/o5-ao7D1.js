const t=""+new URL("../assets/ErgoptiPlus.C3HdJUcX.ahk",import.meta.url).href;export{t as default};
