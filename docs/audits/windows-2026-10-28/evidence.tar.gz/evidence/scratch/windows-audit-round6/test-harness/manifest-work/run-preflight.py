from pathlib import Path
import subprocess,json,sys,hashlib
root=Path('/workspace/ergopti-windows-r6-tests')
packet=Path(__file__).parent
commands=[['node','node_modules/prettier/bin/prettier.cjs','--write','tools/test/validate-ahk-suite-manifest.cjs','tools/test/test-ahk-suite-manifest.cjs'],['node','tools/test/test-ahk-suite-manifest.cjs'],['node','tools/lint/lint-conventions.js','--fail-on-violations']]
results=[]
for command in commands:
 print('EXECUTE '+repr(command),flush=True)
 result=subprocess.run(command,cwd=root)
 results.append({'argv':command,'exit_code':result.returncode})
 (packet/'preflight-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if result.returncode:sys.exit(result.returncode)
print('Manifest selected gates completed.',flush=True)
