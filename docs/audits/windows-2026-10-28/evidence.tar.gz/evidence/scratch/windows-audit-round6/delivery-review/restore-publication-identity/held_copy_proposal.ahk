; Review-only replacement for the configuration restore copy boundary.
; The pathname wrapper preserves the existing fixed restore sidecar contract.
FSCopyReplaceAtomic(Source, Destination, &Receipt := 0) {
	Receipt := _FSCopyReceipt()
	if !FSPathIsAdmissible(Source) || !FSPathIsAdmissible(Destination)
		return false
	SourceOwner := _FSCopyOwner("")
	try {
		FullSource := _FSCopyFullPath(Source)
		FullDestination := _FSCopyFullPath(Destination)
		SourceOwner["path"] := FullSource
		Receipt["phase"] := "open_source"
		if !_FSCopyAcquire(SourceOwner, "path", , &NativeError) {
			Receipt["native_error"] := NativeError
			return false
		}
		Receipt := _FSCopyHeldSourceReplaceAtomic(SourceOwner["handle"], FullSource,
			FullDestination, FullDestination . ".ergopti-restore.tmp")
	} catch as Err {
		Receipt["detail"] := Err.Message
	} finally {
		if !_FSCopyClose(SourceOwner, &NativeError) {
			Receipt["close_errors"]["source_path"] := NativeError
			Receipt["close_error_details"]["source_path"] := SourceOwner["close_detail"]
			Receipt["ok"] := false
		}
	}
	return Receipt["ok"]
}

; SourcePath is reader-admission metadata, never a source-opening authority.
; Private config-copy core; no layout generation or cancellation API is granted.
; The caller retains its original held source and owns its eventual disposal.
; StagePath must be a distinct, absent sibling of Destination. Publication keeps
; the existing replace-live-destination policy; this is not destination CAS.
_FSCopyHeldSourceReplaceAtomic(SourceHandle, SourcePath, Destination, StagePath) {
	Receipt := _FSCopyReceipt()
	if !(SourceHandle is Integer) || SourceHandle == 0 || SourceHandle == -1
			|| !FSPathIsAdmissible(SourcePath) || !FSPathIsAdmissible(Destination)
			|| !FSPathIsAdmissible(StagePath)
		return Receipt
	SourceOwner := _FSCopyOwner(SourcePath), StageOwner := _FSCopyOwner("")
	DestinationActivity := 0
	try {
		FullDestination := _FSCopyFullPath(Destination)
		FullStage := _FSCopyFullPath(StagePath)
		SplitPath(FullDestination, , &DestinationDirectory)
		SplitPath(FullStage, , &StageDirectory)
		if StrCompare(FullDestination, FullStage, false) == 0
				|| StrCompare(DestinationDirectory, StageDirectory, false) != 0 {
			Receipt["detail"] := "Publication requires a distinct same-directory stage."
			return Receipt
		}
		StageOwner["path"] := FullStage
		Receipt["phase"] := "pin_source"
		if !_FSCopyAcquire(SourceOwner, "held", SourceHandle, &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Held := FSHandleSnapshot(SourceHandle), Before := FSHandleSnapshot(SourceOwner["handle"])
		if !Held["ok"] || !Before["ok"] || !_FSCopyOrdinary(SourceOwner["handle"])
				|| Before["size"] < 0 {
			Receipt["detail"] := "The held source is not a readable ordinary file."
			return Receipt
		}
		for Key in ["volume", "index_high", "index_low"] {
			if Held[Key] != Before[Key] {
				Receipt["detail"] := "The source pin did not preserve the held file identity."
				return Receipt
			}
		}
		Receipt["source_identity"] := Before
		if !DllCall("kernel32\SetFilePointerEx", "Ptr", SourceOwner["handle"], "Int64", 0, "Ptr", 0, "UInt", 0, "Int") {
			Receipt["native_error"] := A_LastError
			Receipt["detail"] := "The held source cursor could not be reset."
			return Receipt
		}
		Receipt["phase"] := "create_stage"
		if !_FSCopyAcquire(StageOwner, "stage", , &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Created := FSHandleSnapshot(StageOwner["handle"])
		if !Created["ok"] {
			Receipt["detail"] := "The acquired stage has no native identity receipt."
			return Receipt
		}
		Receipt["stage_identity"] := Created
		static COPY_CHUNK_BYTES := 0x10000
		Bytes := Buffer(COPY_CHUNK_BYTES), Readback := Buffer(COPY_CHUNK_BYTES)
		Offset := 0
		while Offset < Before["size"] {
			Count := Min(COPY_CHUNK_BYTES, Before["size"] - Offset)
			Receipt["phase"] := "read_source"
			if !_FSCopyTransfer(SourceOwner["handle"], Bytes, Count, false, &NativeError) {
				Receipt["native_error"] := NativeError
				Receipt["detail"] := "The source read did not complete."
				return Receipt
			}
			Receipt["phase"] := "write_stage"
			if !_FSCopyTransfer(StageOwner["handle"], Bytes, Count, true, &NativeError) {
				Receipt["native_error"] := NativeError
				Receipt["detail"] := "The stage write did not complete."
				return Receipt
			}
			Receipt["phase"] := "verify_stage"
			if !DllCall("kernel32\SetFilePointerEx", "Ptr", StageOwner["handle"],
					"Int64", Offset, "Ptr", 0, "UInt", 0, "Int") {
				Receipt["native_error"] := A_LastError
				return Receipt
			}
			if !_FSCopyTransfer(StageOwner["handle"], Readback, Count, false, &NativeError) {
				Receipt["native_error"] := NativeError
				return Receipt
			}
			if DllCall("ntdll\RtlCompareMemory", "Ptr", Bytes, "Ptr", Readback,
					"UPtr", Count, "UPtr") != Count {
				Receipt["detail"] := "The held stage differs from the source bytes."
				return Receipt
			}
			Offset += Count
			Receipt["bytes"] := Offset
		}
		After := FSHandleSnapshot(SourceOwner["handle"]), Staged := FSHandleSnapshot(StageOwner["handle"])
		if !After["ok"] || !Staged["ok"] || Staged["size"] != Before["size"] {
			Receipt["detail"] := "The source or stage size could not be verified."
			return Receipt
		}
		for Key in ["volume", "index_high", "index_low", "size", "write_high", "write_low"] {
			if Before[Key] != After[Key] {
				Receipt["detail"] := "The held source changed during the copy."
				return Receipt
			}
		}
		Receipt["phase"] := "flush_stage"
		if !_FSCopyFlush(StageOwner["handle"], &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		; This aliases reader admission only. The stage owner alone closes the
		; native handle; both metadata paths remain busy until that close ACK.
		DestinationActivity := FileReadActivityEnter(FullDestination)
		Receipt["phase"] := "publish_stage"
		Receipt["publication"] := "unknown"
		if !_FSCopyPublish(StageOwner["handle"], FullDestination, &NativeError) {
			Receipt["publication"] := "refused"
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Receipt["publication"] := "completed"
		FileReadActivityBind(DestinationActivity, StageOwner["handle"])
		Receipt["phase"] := "flush_published"
		if !_FSCopyFlush(StageOwner["handle"], &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Receipt["ok"] := true
		Receipt["phase"] := "complete"
	} catch as Err {
		Receipt["detail"] := Err.Message
	} finally {
		StageClosed := _FSCopyClose(StageOwner, &NativeError)
		if !StageClosed {
			Receipt["close_errors"]["stage"] := NativeError
			Receipt["close_error_details"]["stage"] := StageOwner["close_detail"]
			Receipt["ok"] := false
		}
		if IsObject(DestinationActivity) && StageClosed {
			try {
				if !FileReadActivityLeave(DestinationActivity) {
					Receipt["close_errors"]["destination_activity"] := 0
					Receipt["close_error_details"]["destination_activity"] := "Destination reader metadata retirement was refused."
					Receipt["ok"] := false
				}
			} catch as Err {
				Receipt["close_errors"]["destination_activity"] := 0
				Receipt["close_error_details"]["destination_activity"] := Err.Message
				Receipt["ok"] := false
			}
		}
		if !_FSCopyClose(SourceOwner, &NativeError) {
			Receipt["close_errors"]["source_pin"] := NativeError
			Receipt["close_error_details"]["source_pin"] := SourceOwner["close_detail"]
			Receipt["ok"] := false
		}
	}
	return Receipt
}

_FSCopyReceipt() {
	return Map("ok", false, "phase", "admission", "native_error", 0, "detail", "",
		"publication", "not_attempted", "bytes", 0, "close_errors", Map(), "close_error_details", Map())
}

_FSCopyOwner(Path) {
	return Map("path", Path, "handle", -1, "returned", false, "activity", 0, "close_detail", "")
}

_FSCopyAcquire(Owner, Mode, Original := 0, &NativeError := 0) {
	static GENERIC_READ := 0x80000000, GENERIC_WRITE := 0x40000000, DELETE_ACCESS := 0x10000
	static FILE_SHARE_READ := 1, FILE_SHARE_WRITE := 2, CREATE_NEW := 1, OPEN_EXISTING := 3
	static FILE_ATTRIBUTE_NORMAL := 0x80, FILE_FLAG_WRITE_THROUGH := 0x80000000
	NativeError := 0
	if Mode != "held" && Mode != "path" && Mode != "stage"
		throw ValueError("Unknown held-copy acquisition mode.")
	Owner["activity"] := FileReadActivityEnter(Owner["path"])
	if Mode == "held"
		Handle := DllCall("kernel32\ReOpenFile", "Ptr", Original, "UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ, "UInt", 0, "Ptr")
	else if Mode == "path"
		Handle := DllCall("kernel32\CreateFileW", "Str", Owner["path"], "UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ | FILE_SHARE_WRITE, "Ptr", 0, "UInt", OPEN_EXISTING,
			"UInt", FILE_ATTRIBUTE_NORMAL, "Ptr", 0, "Ptr")
	else if Mode == "stage"
		Handle := DllCall("kernel32\CreateFileW", "Str", Owner["path"],
			"UInt", GENERIC_READ | GENERIC_WRITE | DELETE_ACCESS, "UInt", 0, "Ptr", 0,
			"UInt", CREATE_NEW, "UInt", FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, "Ptr", 0, "Ptr")
	else
		throw ValueError("Unknown held-copy acquisition mode.")
	NativeError := Handle == -1 ? A_LastError : 0
	Owner["returned"] := true
	Owner["handle"] := Handle
	if Handle == -1
		return false
	FileReadActivityBind(Owner["activity"], Handle)
	return true
}

_FSCopyClose(Owner, &NativeError := 0) {
	NativeError := 0
	try {
		if !IsObject(Owner["activity"])
			return true
		if Owner["handle"] == -1 {
			if !Owner["returned"] {
				Owner["close_detail"] := "The native acquisition outcome is unknown."
				return false
			}
		} else {
			if !_FSCopyNativeClose(Owner["handle"], &NativeError) {
				Owner["close_detail"] := "Native CloseHandle refused retirement."
				return false
			}
			Owner["handle"] := -1
		}
		if !FileReadActivityLeave(Owner["activity"]) {
			Owner["close_detail"] := "Reader activity retirement was refused."
			return false
		}
		Owner["activity"] := 0
		return true
	} catch as Err {
		Owner["close_detail"] := Err.Message
		return false
	}
}

_FSCopyNativeClose(Handle, &NativeError := 0) {
	Closed := DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
	NativeError := Closed ? 0 : A_LastError
	return Closed
}

_FSCopyOrdinary(Handle) {
	Info := Buffer(52, 0)
	return DllCall("kernel32\GetFileInformationByHandle", "Ptr", Handle, "Ptr", Info, "Int")
		&& !(NumGet(Info, 0, "UInt") & 0x410)
		&& DllCall("kernel32\GetFileType", "Ptr", Handle, "UInt") == 1
}

_FSCopyTransfer(Handle, Bytes, Count, Write, &NativeError := 0) {
	NativeError := 0
	Offset := 0
	while Offset < Count {
		Transferred := 0
		if !_FSCopyNativeIo(Write, Handle, Bytes.Ptr + Offset, Count - Offset, &Transferred, &NativeError)
				|| Transferred <= 0 || Transferred > Count - Offset
			return false
		Offset += Transferred
	}
	return true
}

_FSCopyNativeIo(Write, Handle, Address, Count, &Transferred, &NativeError := 0) {
	Api := Write ? "kernel32\WriteFile" : "kernel32\ReadFile"
	Completed := DllCall(Api, "Ptr", Handle, "Ptr", Address, "UInt", Count,
		"UInt*", &Transferred, "Ptr", 0, "Int") != 0
	NativeError := Completed ? 0 : A_LastError
	return Completed
}

_FSCopyFlush(Handle, &NativeError := 0) {
	Flushed := DllCall("kernel32\FlushFileBuffers", "Ptr", Handle, "Int") != 0
	NativeError := Flushed ? 0 : A_LastError
	return Flushed
}

_FSCopyPublish(Handle, Destination, &NativeError := 0) {
	static FILE_RENAME_INFO_CLASS := 3
	NameBytes := StrLen(Destination) * 2
	NameOffset := A_PtrSize == 8 ? 20 : 12
	Rename := Buffer(NameOffset + NameBytes + 2, 0)
	NumPut("UInt", 1, Rename, 0)
	NumPut("UInt", NameBytes, Rename, A_PtrSize == 8 ? 16 : 8)
	StrPut(Destination, Rename.Ptr + NameOffset, StrLen(Destination) + 1, "UTF-16")
	Published := DllCall("kernel32\SetFileInformationByHandle", "Ptr", Handle,
		"Int", FILE_RENAME_INFO_CLASS, "Ptr", Rename, "UInt", Rename.Size, "Int") != 0
	NativeError := Published ? 0 : A_LastError
	return Published
}

_FSCopyFullPath(Path) {
	Size := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", 0, "Ptr", 0, "Ptr", 0, "UInt")
	if !Size
		throw OSError(A_LastError, A_ThisFunc)
	Full := Buffer(Size * 2)
	Written := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", Size, "Ptr", Full, "Ptr", 0, "UInt")
	if !Written || Written >= Size
		throw Error("Held-copy path resolution did not complete.")
	return StrGet(Full)
}
