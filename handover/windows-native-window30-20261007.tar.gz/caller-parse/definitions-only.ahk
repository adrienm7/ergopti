﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
#ErrorStdOut
#Warn All, StdOut
#Warn VarUnset, Off
ExitApp(0)
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\adapters\timer_scheduler.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_webview.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_deps_checker.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\_generated\ollama_guardian_images.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\adapters\ollama_platform.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\adapters\ollama_guardian_native.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\adapters\ollama_intake_native.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\adapters\ollama_guardian_task.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\adapters\ollama_managed_identity.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_runtime_owner.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_runtime_source_spec.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_install_files_port.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\adapters\ollama_managed_files_default.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_archive_intake.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_official_archive_provider.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_user_local_session.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_official_session_archive.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_managed_http.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_model_pull_owner.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_managed_coordinator.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_managed_ready_commit.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\ui\menu\menu_llm\managed_runtime_consent.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_managed_driver.ahk
#Include D:\ErgoptiAuditWorkspace\window30-caller-parse-20261007-delivery-v4\code\static\ergopti_plus\windows\modules\llm\ollama_managed_windows_lifecycle.ahk
