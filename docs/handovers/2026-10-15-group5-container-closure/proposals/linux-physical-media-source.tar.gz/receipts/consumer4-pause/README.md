# Private Linux original-source metrics consumer

Four source/test paths only. The existing hold-duration test module keeps its entire original 23-case prefix and appends nine controls. Production remains a private proposal; canonical four paths still match PRE.

The original pre-remap onPhysicalSource capability feeds raw numeric positions separately from five shared semantic media IDs. Consumed original input counts; immediate/deferred remapper output has no physical heatmap authority. Existing logical character/WPM callbacks remain separate. Original source/device and privacy tokens fence press/release; cancellation retains only a down ledger until an original up, without reconstructing a hold. Policy/source receiver construction occurs at keylogger.init, before input callbacks.

Media pending rows drain only after the existing SQLite writer returns literal true for the captured prefix. False/throw keeps the same pending rows. Semantic hold threshold uses shared Timings; original numeric TapHold threshold remains unchanged. No JSON media success or new default/permission/native activation is introduced.

Actual receiving: full existing module 32 PASS/0 FAIL on Lua 5.4 and LuaJIT; eight source omissions produce 1,2,1,1,1,4,1,2 assertion failures, exact restore gives 32/0 on both. Saved before-raw-join producer with the frozen corrected SQL has 5 PASS/2 assertion FAIL (synthetic numeric credit and duplicate after cancellation). The earlier token-column SQL refusal is retained separately and receives no causal credit.

These are software controls through original Hook/Reader algorithms with controlled transport/grab/classification and real owned /dev/null/zero descriptor fstat, plus actual SQLite CLI storage. No real evdev/uinput device, desktop grab, physical key, compositor or user profile was exercised.

Supplier four is separately sealed at ../SUPPLIER-FINAL (4960fa33) and independently source-cleared (5f6f149d; author-owned peer receipt). Its callbacks are not altered here. Canonical adoption requires Root/G3 ownership coordination; this packet grants no native qualification.
