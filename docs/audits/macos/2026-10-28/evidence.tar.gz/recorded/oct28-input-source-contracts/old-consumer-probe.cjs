'use strict';
const fs = require('node:fs');
const original = fs.readFileSync;
const sourcePath = '/workspace/ergopti-macos-cloner-i18n/static/ergopti_plus/macos/modules/keymap/input_sources.lua';
const frozen = original('/workspace/scratch/oct28-input-source-contracts/old-input-sources.lua');
fs.readFileSync = function(file, options) {
 if (file === sourcePath) return options === 'utf8' || options?.encoding === 'utf8' ? frozen.toString('utf8') : Buffer.from(frozen);
 return original.apply(this, arguments);
};
require('/workspace/ergopti-macos-cloner-i18n/tools/test/test-input-source-python-supervisor.cjs');
