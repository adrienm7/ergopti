#!/usr/bin/env python3
"""Own a bounded real GTK/WebKit wizard profile; never substitutes authorities."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import select
import shutil
import pathlib
import subprocess
import sys
import tempfile
import time
import tomllib

PACKET = Path(__file__).resolve().parent
ROOT = PACKET


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def snapshot(folder):
    result = {}
    for path in sorted(folder.rglob("*")):
        name = str(path.relative_to(folder))
        if path.is_symlink():
            result[name] = {"kind": "symlink", "target": os.readlink(path)}
        elif path.is_file():
            result[name] = {"kind": "file", "sha256": digest(path), "bytes": path.stat().st_size}
    return result


def controlled_environment(profile):
    env = os.environ.copy()
    # A fresh native session owns its display/auth/socket, not an inherited desktop.
    for key in ("DISPLAY", "WAYLAND_DISPLAY", "DBUS_SESSION_BUS_ADDRESS", "XAUTHORITY"):
        env.pop(key, None)
    for key, child in {
        "XDG_CONFIG_HOME": "config", "XDG_DATA_HOME": "data",
        "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache",
        "XDG_RUNTIME_DIR": "runtime", "TMPDIR": "tmp",
    }.items():
        folder = profile / child
        folder.mkdir(mode=0o700)
        env[key] = str(folder)
    # These are the actual existing paths in activate-ergopti[-gtk].sh. Do not
    # source its shared mkdir/XDG defaults and do not repurpose HOME.
    env["PATH"] = ":".join((
        "/workspace/tooling/graphical-bin", "/workspace/tooling/gtk/usr/bin",
        "/workspace/tooling/native/usr/bin", env.get("PATH", ""),
    ))
    env["LD_LIBRARY_PATH"] = ":".join(filter(None, (
        "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu",
        "/workspace/tooling/native/usr/lib/x86_64-linux-gnu",
        env.get("LD_LIBRARY_PATH", ""),
    )))
    env["LUA_PATH"] = (
        "./?.lua;./?/init.lua;../_shared/lua/?.lua;../_shared/lua/?/init.lua;"
        "/workspace/tooling/gtk/usr/share/lua/5.1/?.lua;"
        "/workspace/tooling/gtk/usr/share/lua/5.1/?/init.lua;"
        "/workspace/tooling/native/usr/share/lua/5.1/?.lua;"
        "/workspace/tooling/native/usr/share/lua/5.1/?/init.lua;;"
    )
    env["LUA_CPATH"] = (
        "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;"
        "/workspace/tooling/native/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;;"
    )
    env["GI_TYPELIB_PATH"] = "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/girepository-1.0"
    env["WEBKIT_INJECTED_BUNDLE_PATH"] = "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/injected-bundle"
    env["GDK_BACKEND"] = "x11"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def session_supervisor():
    """Remain the unreaped PGID anchor after the genuine native command finishes."""
    status_path = pathlib.Path(sys.argv[2])
    native_fds = tuple(int(value) for value in sys.argv[3].split(",") if value)
    command = sys.argv[4:]
    # A caught handler resets to default across exec; native children therefore
    # still receive TERM. Only this ownership anchor remains alive until KILL.
    signal.signal(signal.SIGTERM, lambda _sig, _frame: None)
    child = None
    record = {}
    try:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, pass_fds=native_fds)
        for fd in native_fds:
            os.close(fd)
        while child.poll() is None:
            if select.select([0], [], [], 0.05)[0] and os.read(0, 1) == b"":
                # Parent custody disappeared; this unreaped live anchor still
                # proves the PGID. Retire this session, including the anchor.
                os.killpg(os.getpgrp(), signal.SIGTERM)
                time.sleep(0.2)
                os.killpg(os.getpgrp(), signal.SIGKILL)
        record = {"exit_code": child.returncode, "command_pid": child.pid}
    except BaseException as error:
        record = {"exit_code": 125, "supervisor_error": str(error)}
    finally:
        temporary = status_path.with_suffix(".pending")
        temporary.write_text(json.dumps(record) + "\n")
        temporary.replace(status_path)
    # Do not exit/reap the PGID anchor when the command has finished. Descendants
    # may remain; exact group teardown is mandatory before runner reaps us.
    while True:
        if select.select([0], [], [], 0.1)[0] and os.read(0, 1) == b"":
            os.killpg(os.getpgrp(), signal.SIGTERM)
            time.sleep(0.2)
            os.killpg(os.getpgrp(), signal.SIGKILL)


class OwnedSession:
    def __init__(self, command, status_path, log_out, log_err, environment, native_fds=(), cwd=ROOT):
        self.status_path = status_path
        self.process = subprocess.Popen(
            [sys.executable, str(ROOT / "run-private-wizard.py"), "--owned-session", str(status_path),
             ",".join(str(fd) for fd in native_fds), *command],
            stdin=subprocess.PIPE, stdout=log_out, stderr=log_err, env=environment,
            cwd=cwd, pass_fds=native_fds, start_new_session=True,
        )
        self.pgid = self.process.pid
        self.disposed = False
        # No poll/wait/communicate is permitted on this anchor before teardown.
        # Even unexpected anchor death leaves its unreaped PID unrecyclable.

    def status(self):
        if not self.status_path.exists():
            return None
        return json.loads(self.status_path.read_text())

    def dispose(self):
        if self.disposed:
            return
        if self.process.returncode is not None:
            raise RuntimeError("custody refused: ownership anchor was reaped before group teardown")
        errors = []
        for name, sig in (("TERM", signal.SIGTERM), ("KILL", signal.SIGKILL)):
            try:
                os.killpg(self.pgid, sig)
            except ProcessLookupError:
                # The unreaped PID still prevents PGID reuse. ESRCH means that
                # exact anchored group already has no signalable native members.
                pass
            except OSError as error:
                errors.append(name + ": " + str(error))
            if name == "TERM":
                time.sleep(0.2)
        try:
            self.process.wait(timeout=3)
        except subprocess.TimeoutExpired as error:
            errors.append("anchor bounded wait: " + str(error))
        finally:
            if self.process.stdin is not None:
                self.process.stdin.close()
        self.disposed = not errors
        if errors:
            raise RuntimeError("; ".join(errors))


class NativeEnvironmentError(RuntimeError):
    pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, default=Path("/workspace/ergopti"))
    parser.add_argument("--execute", action="store_true", help="Run only in Root's released native slot")
    args = parser.parse_args()
    if not args.execute:
        print("SOURCE ONLY: prepared real wizard cancel/finish/reopen; no native process executed.")
        return 0
    profile = None
    server = native = None
    reader = writer = None
    cleanup_errors = []
    qualification_errors = []
    frozen = checkout = None
    primary_error = None
    environment_unrun = False
    manifest = {
        "scope": "real X11 GTK/WebKit wizard receiving with physical files",
        "status": "running", "planned_processes": ["cancel", "finish", "reopen"],
        "attempted_processes": [], "launched_processes": [], "completed_processes": [],
        "passed_processes": [], "processes": [], "independent_file_assertions": [],
        "unrun": ["native Browse", "physical input", "Wayland", "installed daemon restart", "Windows/macOS"],
    }

    def verify(condition, name):
        manifest["independent_file_assertions"].append({"name": name, "passed": condition is True})
        if condition is not True:
            raise RuntimeError(name)

    def dispose(label, session):
        if session is not None:
            try:
                session.dispose()
            except BaseException as error:
                cleanup_errors.append(label + ": " + str(error))

    try:
        packet_manifest = json.loads((PACKET / "SOURCE-PROPOSAL.json").read_text())
        packet_mismatches = [name for name, expected in packet_manifest["files"].items()
                             if not (PACKET / name).is_file() or digest(PACKET / name) != expected["sha256"]]
        if packet_mismatches:
            raise RuntimeError("reviewed private packet drift: " + json.dumps(packet_mismatches))
        manifest["expected_packet_proposal_sha256"] = digest(PACKET / "SOURCE-PROPOSAL.json")
        checkout = args.checkout.resolve()
        frozen = json.loads((PACKET / "SOURCE-CLOSURE.json").read_text())
        mismatches = [path for path, expected in frozen["production_sources"].items()
                      if not (checkout / path).is_file() or digest(checkout / path) != expected]
        if mismatches:
            raise RuntimeError("reviewed source closure drift: " + json.dumps(mismatches))
        manifest.update(source_closure_sha256=digest(PACKET / "SOURCE-CLOSURE.json"),
                        worker_sha256=digest(PACKET / "wizard-native-worker.lua"),
                        controller_sha256=digest(Path(__file__).resolve()))
        profile = Path(tempfile.mkdtemp(prefix="actual-wizard-", dir=PACKET))
        os.chmod(profile, 0o700)
        manifest["profile"] = str(profile)
        env = controlled_environment(profile)
        declaration = tomllib.loads((checkout / "static/ergopti_plus/_shared/modules/features/manifest.toml").read_text())
        # Independently authored expected paths/defaults; the actual declaration
        # is checked against them, never used to regenerate expected answers.
        for path, expected in frozen["expected_master_defaults"].items():
            section, key = path.split(".")
            entries = [entry for entry in declaration["features"][section]
                       if entry["id"] == key and "linux" in entry.get("platforms", ["ahk", "hs", "linux"])]
            verify(len(entries) == 1, "one independently declared Linux default owner: " + path)
            verify(entries[0]["type"] == "boolean" and entries[0]["default"] is expected,
                   "independent declared boolean default: " + path)
        binaries = {name: shutil.which(name, path=env["PATH"])
                    for name in ("luajit", "Xvfb", "dbus-run-session")}
        manifest["binaries"] = binaries
        if any(value is None for value in binaries.values()):
            raise NativeEnvironmentError("required actual native executable is absent")
        target = profile / "chosen-config"
        target.mkdir(mode=0o700)
        (profile / "config" / "ergopti").mkdir(mode=0o700)
        cwd = checkout / "static/ergopti_plus/linux"
        original_config_snapshot = snapshot(profile / "config")
        reader, writer = os.pipe()
        with (profile / "xvfb.log").open("wb") as log:
            server = OwnedSession(
                [binaries["Xvfb"], "-displayfd", str(writer), "-screen", "0", "1024x768x24", "-nolisten", "tcp", "-noreset"],
                profile / "xvfb-command-status.json", log, log, env, (writer,), cwd=cwd,
            )
        manifest["owned_xvfb_pgid"] = server.pgid
        os.close(writer)
        writer = None
        if not select.select([reader], [], [], 5)[0]:
            raise NativeEnvironmentError("owned real Xvfb display readiness is absent")
        display = os.read(reader, 32).decode("ascii").strip()
        if not display.isdecimal():
            raise NativeEnvironmentError("owned real Xvfb display identity is invalid")
        env.update(DISPLAY=":" + display, NO_AT_BRIDGE="1")
        manifest["owned_display"] = ":" + display
        for mode in manifest["planned_processes"]:
            manifest["attempted_processes"].append(mode)
            entry = {"mode": mode, "status": "attempted", "launched": False,
                     "completed": False, "timed_out": False, "timeout_seconds": 90}
            manifest["processes"].append(entry)
            before = snapshot(profile / "config")
            target_before = snapshot(target)
            receipt = profile / (mode + "-native.json")
            command = [binaries["dbus-run-session"], "--", binaries["luajit"],
                       str(PACKET / "wizard-native-worker.lua"), mode, str(target), str(receipt)]
            entry["command"] = command
            log_path = profile / (mode + "-native.log")
            started = time.monotonic()
            status = None
            try:
                with log_path.open("wb") as log:
                    native = OwnedSession(command, profile / (mode + "-command-status.json"),
                                          log, log, env, cwd=cwd)
                entry.update(launched=True, owned_native_pgid=native.pgid, status="launched")
                manifest["launched_processes"].append(mode)
                deadline = time.monotonic() + 90
                while native.status() is None and time.monotonic() < deadline:
                    time.sleep(0.05)
                status = native.status()
                if status is None:
                    entry["timed_out"] = True
                    raise RuntimeError("actual native command deadline: " + mode)
                entry.update(completed=True, command_status=status, exit=status["exit_code"], status="completed")
                manifest["completed_processes"].append(mode)
                entry["receipt_present"] = receipt.is_file()
                if receipt.is_file():
                    entry["native_receipt_sha256"] = digest(receipt)
                    entry["native_receipt"] = json.loads(receipt.read_text())
                if status["exit_code"] != 0 or not entry["receipt_present"]:
                    if entry.get("native_receipt", {}).get("status") == "ENVIRONMENT_UNRUN":
                        raise NativeEnvironmentError("actual native environment refused: " + mode)
                    raise RuntimeError("actual native receiving did not pass: " + mode)
                verify(entry["native_receipt"]["status"] == "PASS", mode + " native receipt is PASS")
                verify(entry["native_receipt"]["cleanup"].get("manager_retired") is True,
                       mode + " actual native manager cleanup acknowledged")
                if mode == "cancel":
                    verify(snapshot(profile / "config") == original_config_snapshot, "fresh cancel leaves bootstrap/config bytes untouched")
                    verify(snapshot(target) == target_before, "fresh cancel leaves chosen folder untouched")
                elif mode == "finish":
                    actual = tomllib.loads((target / "config.toml").read_text())
                    policy = tomllib.loads((checkout / "static/ergopti_plus/_shared/core/config_schema/migrations.toml").read_text())
                    verify(policy["registry"]["current_version"] == frozen["expected_schema_version"], "independent frozen schema policy remains current")
                    verify(type(actual["_meta"]["schema_version"]) is int and actual["_meta"]["schema_version"] == frozen["expected_schema_version"], "committed schema matches independent frozen policy")
                    for family in ("shortcuts", "gestures", "llm", "metrics"):
                        section = actual.get(family, {})
                        verify(type(section) is dict, "actual boolean family remains a table: " + family)
                        # Only absence of this exact declared defaultfalse leaf
                        # is neutral. Strings, numbers, true or another owner fail.
                        off = section["enabled"] is False if "enabled" in section else frozen["expected_master_defaults"][family + ".enabled"] is False
                        verify(off, "independent explicit No persisted: " + family)
                    verify(actual["category_enabled"]["key_combinations"] is False,
                           "default-on key combinations retain explicit typed false")
                    storage = json.loads((profile / "config" / "ergopti_plus" / "storage.json").read_text())
                    verify(storage["locale"] == "en", "bootstrap persists explicit English locale")
                    verify(storage["paths.config_dir"] == str(target), "bootstrap persists exact moved folder")
                    verify(not (profile / "config" / "ergopti" / "config.toml").exists(), "no second config in default folder")
                elif mode == "reopen":
                    verify(snapshot(profile / "config") == before, "fresh-process rerun cancel preserves exact bootstrap bytes")
                    verify(snapshot(target) == target_before, "fresh-process rerun cancel preserves all chosen-folder bytes")
                entry["status"] = "assertions_passed"
            except BaseException as error:
                entry["primary_error"] = str(error)
                entry["status"] = "ENVIRONMENT_UNRUN" if isinstance(error, NativeEnvironmentError) else "FAIL"
                raise
            finally:
                # Native anchor is not poll/wait/communicated before exact disposal.
                dispose(mode + " native session", native)
                entry["native_session_disposed"] = native is None or native.disposed
                if native is not None and native.disposed:
                    native = None
                entry["elapsed_seconds"] = time.monotonic() - started
                try:
                    if log_path.is_file():
                        entry.update(log_sha256=digest(log_path), log_bytes=log_path.stat().st_size)
                except BaseException as error:
                    cleanup_errors.append(mode + " log accounting: " + str(error))
            if cleanup_errors:
                entry["status"] = "FAIL"
                raise RuntimeError("actual owned receiving cleanup refused")
            entry["status"] = "PASS"
            manifest["passed_processes"].append(mode)
    except BaseException as error:
        primary_error = str(error)
        environment_unrun = isinstance(error, NativeEnvironmentError)
    finally:
        # Independent phases preserve the original failure and still attempt all
        # exact sessions, descriptor closes, snapshots and durable receipt writes.
        dispose("remaining native session", native)
        dispose("Xvfb session", server)
        for label, fd in (("display readiness reader", reader), ("display readiness writer", writer)):
            if fd is not None:
                try:
                    os.close(fd)
                except BaseException as error:
                    cleanup_errors.append(label + ": " + str(error))
        manifest.update(primary_error=primary_error, cleanup_errors=cleanup_errors,
                        xvfb_session_disposed=server is None or server.disposed)
        manifest["unexecuted_processes"] = [mode for mode in manifest["planned_processes"]
                                            if mode not in manifest["launched_processes"]]
        manifest["uncompleted_processes"] = [mode for mode in manifest["planned_processes"]
                                             if mode not in manifest["completed_processes"]]
        try:
            manifest["final_profile_files"] = snapshot(profile) if profile is not None else {}
        except BaseException as error:
            cleanup_errors.append("profile accounting: " + str(error))
        # Reconcile actual production inputs at the end; no concurrent source
        # mutation can borrow the frozen qualification of an earlier image.
        manifest["final_source_reconciliation"] = {"status": "UNRUN"}
        if frozen is not None and checkout is not None:
            try:
                changed = [path for path, expected in frozen["production_sources"].items()
                           if not (checkout / path).is_file() or digest(checkout / path) != expected]
                manifest["final_source_reconciliation"] = {"status": "MATCH" if not changed else "DRIFT", "changed": changed}
                if changed:
                    qualification_errors.append("actual production source closure changed during receiving")
            except BaseException as error:
                qualification_errors.append("final production source accounting: " + str(error))
        manifest["qualification_errors"] = qualification_errors
        # Genuine cleanup/qualification refusal is failure1 even when the native
        # prerequisite was unavailable; do not downgrade it to environment2.
        manifest["status"] = ("FAIL" if cleanup_errors or qualification_errors else
                              "ENVIRONMENT_UNRUN" if environment_unrun else
                              "FAIL" if primary_error else "PASS")
        receipt_path = profile / "ACTUAL-RESULTS.json" if profile is not None else PACKET / ("FAILED-RECEIVING-" + str(time.time_ns()) + ".json")
        manifest["receipt_write_attempted"] = True
        try:
            write_json(receipt_path, manifest)
            receipt_sha = digest(receipt_path)
        except BaseException as error:
            cleanup_errors.append("durable receipt write: " + str(error))
            manifest["status"] = "FAIL"
            receipt_sha = None
        print(json.dumps({"status": manifest["status"], "receipt": str(receipt_path),
                          "receipt_sha256": receipt_sha, "primary_error": primary_error,
                          "cleanup_errors": cleanup_errors, "qualification_errors": qualification_errors,
                          "attempted_processes": manifest["attempted_processes"],
                          "launched_processes": manifest["launched_processes"],
                          "completed_processes": manifest["completed_processes"],
                          "unexecuted_processes": manifest["unexecuted_processes"]}))
    return 0 if manifest["status"] == "PASS" else 2 if manifest["status"] == "ENVIRONMENT_UNRUN" else 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--owned-session":
        session_supervisor()
    else:
        sys.exit(main())
