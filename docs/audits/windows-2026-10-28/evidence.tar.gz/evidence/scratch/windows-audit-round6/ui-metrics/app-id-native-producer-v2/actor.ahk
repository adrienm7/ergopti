﻿#Requires AutoHotkey v2.0
#SingleInstance Off
Owner := Gui()
Owner.Title := "Ergopti owned extensionless app probe"
Owner.AddText(, "Owned native process identity probe")
Owner.OnEvent("Close", (*) => ExitApp(0))
Owner.Show("w300 h100")
SetTimer(() => ExitApp(0), -20000)
