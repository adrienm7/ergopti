"""Add only opt-in passive observation after original owned closure."""
from pathlib import Path
import ast,difflib,hashlib,json
BASE=Path(__file__).resolve().parent
WIRE='static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
BUILDER='static/ergopti_plus/macos/tests/support/native_http_fixture_builder.py'
wire=(BASE/'preimage'/WIRE).read_text()
sig='        trust_operation=None,\n    ):\n'
assert wire.count(sig)==1
wire=wire.replace(sig,'        trust_operation=None,\n        passive_receiving=None,\n    ):\n',1)
anchor='        if trust_operation == "add":\n            try:\n'
observer='''        # Optional receiving observes this same local owner only after its
        # original literalTrue ACK and original three capture closures. It has
        # no retirement authority and cannot pay debt or change a primary.
        if passive_receiving is not None:
            try:
                if (
                    group_settled is True
                    and owned is not None
                    and owned.reaped is True
                    and not closure_refused
                    and all(stream is not None and stream.closed is True for stream in streams)
                    and not self.command_file_debt
                    and not self.command_group_debt
                ):
                    receipt = owned.receipt()
                    if (
                        type(receipt) is not dict
                        or set(receipt) != {
                            "worker_pid", "group_id", "closed", "reservation_lost",
                            "signals", "live_group_members", "escaped_sessions_managed",
                        }
                        or type(receipt["worker_pid"]) is not int
                        or not 0 < receipt["worker_pid"] <= 2_147_483_647
                        or receipt["worker_pid"] != owned.process.pid
                        or type(receipt["group_id"]) is not int
                        or receipt["group_id"] != receipt["worker_pid"]
                        or any(type(receipt[key]) is not bool for key in (
                            "closed", "reservation_lost", "escaped_sessions_managed",
                        ))
                        or type(receipt["signals"]) is not list
                        or len(receipt["signals"]) > 2
                        or any(type(value) is not int or value not in (15, 9) for value in receipt["signals"])
                        or type(receipt["live_group_members"]) is not list
                        or receipt["live_group_members"]
                    ):
                        raise FixtureFailure("Native fixture passive receipt bound refused")
                    receipt = {
                        **receipt,
                        "signals": list(receipt["signals"]),
                        "live_group_members": [],
                    }
                    passive_receiving(
                        {
                            "version": 1,
                            "command": dict(self.command_fact),
                            "exit_status": owned.process.returncode,
                            "original_failed": failure is not None,
                            "literal_true_settlement": True,
                            "stdin_closed": True,
                            "stderr_closed": True,
                            "stdout_closed": True,
                            "command_group_debt": False,
                            "command_file_debt": False,
                            "owner": receipt,
                            "stdout": result[1] if result is not None else None,
                        }
                    )
            except BaseException as observation_failure:
                if failure is None and (
                    not isinstance(observation_failure, Exception)
                    or (
                        type(observation_failure) is FixtureFailure
                        and observation_failure.args == ("Native fixture cancelled",)
                    )
                ):
                    failure = observation_failure
'''
assert wire.count(anchor)==1
wire=wire.replace(anchor,observer+anchor,1)
old=(BASE/'preimage'/BUILDER).read_text()
return_anchor='        return self.fixture._command(arguments, timeout=timeout, deadline=deadline)\n'
forward='''        observer = getattr(self, "passive_command_receiver", None)
        if observer is not None:
            if arguments[:2] == ["/usr/bin/xcrun", "swiftc"]:
                role = "compile"
            elif arguments[:-1] == ["/usr/bin/codesign", "--force", "--sign", "-"]:
                role = "sign"
            elif arguments[:-1] == ["/usr/bin/codesign", "--verify", "--strict"]:
                role = "strict_verify"
            else:
                raise BuildRefused("Native fixture passive command role refused")
            return self.fixture._command(
                arguments,
                timeout=timeout,
                deadline=deadline,
                passive_receiving=lambda fact: observer(role, fact),
            )
'''
assert old.count(return_anchor)==1
builder=old.replace(return_anchor,forward+return_anchor,1)
assert wire.replace(observer+anchor,anchor,1).replace('        trust_operation=None,\n        passive_receiving=None,\n    ):\n',sig,1)==(BASE/'preimage'/WIRE).read_text()
assert builder.replace(forward+return_anchor,return_anchor,1)==old
for rel,source in ((WIRE,wire),(BUILDER,builder)):
    ast.parse(source);(BASE/'candidate'/rel).write_text(source)
(BASE/'passive-seam-inverse.json').write_text(json.dumps({'wire_signature_before':sig,'wire_signature_after':'        trust_operation=None,\n        passive_receiving=None,\n    ):\n','wire_observer_anchor':anchor,'wire_observer_addition':observer,'builder_forward_anchor':return_anchor,'builder_forward_addition':forward},indent=2)+'\n')
(BASE/'passive-seam.patch').write_text(''.join(''.join(difflib.unified_diff((BASE/'preimage'/rel).read_text().splitlines(keepends=True),source.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel)) for rel,source in ((WIRE,wire),(BUILDER,builder))))
print(json.dumps({'wire':hashlib.sha256(wire.encode()).hexdigest(),'builder':hashlib.sha256(builder.encode()).hexdigest(),'state':'SOURCE_ONLY_UNRUN'},sort_keys=True))
