using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
namespace Ergopti.Ollama {
    public static class SourceProducerNative {
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        static extern IntPtr LoadLibraryW(string path);
        [DllImport("kernel32.dll", CharSet=CharSet.Ansi, SetLastError=true)]
        static extern IntPtr GetProcAddress(IntPtr module, string name);
        [DllImport("kernel32.dll", SetLastError=true)]
        public static extern uint WaitForMultipleObjects(uint count, IntPtr[] handles, bool all, uint timeout);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        delegate int PublishPort(IntPtr map, IntPtr ready, IntPtr release, IntPtr parent,
                                byte[] digest, IntPtr records, UIntPtr count);
        [StructLayout(LayoutKind.Sequential)]
        struct Expected {
            public UIntPtr handle;
            public uint kind;
            public ulong volume, index;
            public IntPtr path;
            public UIntPtr units;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst=32)] public byte[] digest;
        }
        [DllImport("kernel32.dll", SetLastError=true)]
        static extern bool SetHandleInformation(IntPtr handle, uint mask, uint flags);
        public static void AdmitInherited(IntPtr map, IntPtr ready, IntPtr release, IntPtr parent) {
            foreach(IntPtr handle in new IntPtr[] {map,ready,release,parent}) {
                if(handle == IntPtr.Zero || handle == new IntPtr(-1) || !SetHandleInformation(handle,1u,0u))
                    throw new Win32Exception(Marshal.GetLastWin32Error());
            }
        }
        [DllImport("kernel32.dll", EntryPoint="GetTickCount64")]
        public static extern ulong Tick64();
        [DllImport("kernel32.dll", EntryPoint="GetCurrentProcessId")]
        public static extern uint CurrentPid();
        [DllImport("kernel32.dll", EntryPoint="GetCurrentProcess")]
        static extern IntPtr CurrentProcess();
        [DllImport("kernel32.dll", SetLastError=true)]
        static extern bool GetProcessTimes(IntPtr process,out long creation,out long exit,out long kernel,out long user);
        public static ulong CurrentCreation() {
            long creation,exit,kernel,user;
            if(!GetProcessTimes(CurrentProcess(),out creation,out exit,out kernel,out user))
                throw new Win32Exception(Marshal.GetLastWin32Error());
            return unchecked((ulong)creation);
        }
        static IntPtr module;
        static PublishPort publish;
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        delegate int IntakePublishPort(ulong channel,IntPtr map,IntPtr ready,IntPtr release,IntPtr parent,
                                       byte[] digest,IntPtr records,UIntPtr count);
        static IntakePublishPort intakePublish;
        static ulong intakeChannel;
        public static void ExpectIntakeChannel(ulong channel) {
            if(channel==0 || intakeChannel!=0)throw new InvalidOperationException("Intake channel binding is once-only.");
            intakeChannel=channel;
        }
        public static void Load(string path) {
            if (module != IntPtr.Zero || publish != null || IntPtr.Size != 8 || Marshal.SizeOf(typeof(Expected)) != 80)
                throw new InvalidOperationException("Source channel module/layout initialization refused.");
            module = LoadLibraryW(path);
            if (module == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
            IntPtr entry = GetProcAddress(module, "GSC_Publish");
            if (entry == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
            publish = (PublishPort)Marshal.GetDelegateForFunctionPointer(entry, typeof(PublishPort));
            IntPtr intakeEntry = GetProcAddress(module, "GSC_PublishIntake");
            if(intakeEntry == IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());
            intakePublish=(IntakePublishPort)Marshal.GetDelegateForFunctionPointer(intakeEntry,typeof(IntakePublishPort));
            // The worker owns this module until process terminal. No unload can
            // invalidate a retained channel operation or uncertain native view.
        }
        public static void Publish(IntPtr map, IntPtr ready, IntPtr release, IntPtr parent,
                                   byte[] digest, IntPtr[] handles, uint[] kinds,
                                   ulong[] volumes, ulong[] indices, string[] paths, byte[][] hashes) {
            if (publish == null || digest == null || digest.Length != 32 || handles.Length == 0 ||
                handles.Length != kinds.Length || handles.Length != volumes.Length ||
                handles.Length != indices.Length || handles.Length != paths.Length || handles.Length != hashes.Length)
                throw new InvalidOperationException("Source offer shape refused.");
            int bytes = checked(handles.Length * 80);
            IntPtr records = Marshal.AllocHGlobal(bytes);
            IntPtr[] strings = new IntPtr[handles.Length];
            try {
                for (int i=0; i<handles.Length; ++i) {
                    if (handles[i] == IntPtr.Zero || handles[i] == new IntPtr(-1) || kinds[i] > 1 ||
                        String.IsNullOrEmpty(paths[i]) || paths[i].IndexOf('\0') >= 0 || hashes[i].Length != 32)
                        throw new InvalidOperationException("Source offer member refused.");
                    strings[i] = Marshal.StringToHGlobalUni(paths[i]);
                    Expected row = new Expected { handle = new UIntPtr(unchecked((ulong)handles[i].ToInt64())),
                        kind=kinds[i], volume=volumes[i], index=indices[i], path=strings[i],
                        units=new UIntPtr((uint)paths[i].Length), digest=hashes[i] };
                    Marshal.StructureToPtr(row, IntPtr.Add(records, checked(i*80)), false);
                }
                int result=intakeChannel!=0
                    ? intakePublish(intakeChannel,map,ready,release,parent,digest,records,new UIntPtr((uint)handles.Length))
                    : publish(map,ready,release,parent,digest,records,new UIntPtr((uint)handles.Length));
                if (result != 1)
                    throw new InvalidOperationException("Native source publication refused.");
            } finally {
                foreach (IntPtr value in strings) if(value != IntPtr.Zero) Marshal.FreeHGlobal(value);
                Marshal.FreeHGlobal(records);
            }
        }
    }
}
