function readSourceFile(file, maximum = 33554432) {
	const named = fs.lstatSync(file, { bigint: true });
	demand(
		named.isFile() && !named.isSymbolicLink() && named.nlink === 1n,
		'Regular unaliased source/image required.'
	);
	const fd = fs.openSync(
		file,
		fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0) | (fs.constants.O_NONBLOCK || 0)
	);
	try {
		const acquired = fs.fstatSync(fd, { bigint: true });
		demand(
			acquired.isFile() &&
				acquired.nlink === 1n &&
				acquired.size <= BigInt(maximum) &&
				acquired.dev === named.dev &&
				acquired.ino === named.ino,
			'Source/image acquisition refused.'
		);
		const storage = Buffer.alloc(Number(acquired.size) + 1);
		let length = 0;
		while (length < storage.length) {
			const count = fs.readSync(fd, storage, length, storage.length - length, null);
			if (!count) break;
			length += count;
		}
		const bytes = storage.subarray(0, length);
		const final = fs.fstatSync(fd, { bigint: true });
		const finalNamed = fs.lstatSync(file, { bigint: true });
		demand(
			final.isFile() &&
				finalNamed.isFile() &&
				!finalNamed.isSymbolicLink() &&
				final.nlink === 1n &&
				finalNamed.nlink === 1n &&
				final.dev === acquired.dev &&
				final.ino === acquired.ino &&
				finalNamed.dev === acquired.dev &&
				finalNamed.ino === acquired.ino &&
				final.size === acquired.size &&
				BigInt(bytes.length) === acquired.size &&
				final.mtimeNs === acquired.mtimeNs &&
				final.ctimeNs === acquired.ctimeNs,
			'Source/image changed during receiving.'
		);
		return {
			bytes,
			sha256: sha(bytes),
			identity: {
				dev: String(acquired.dev),
				ino: String(acquired.ino),
				size: String(acquired.size)
			}
		};
	} finally {
		fs.closeSync(fd);
	}
}
