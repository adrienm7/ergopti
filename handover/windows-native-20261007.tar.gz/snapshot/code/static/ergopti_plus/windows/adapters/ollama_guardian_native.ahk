﻿; adapters/ollama_guardian_native.ahk
#Requires AutoHotkey v2.0

global _OllamaGuardianNativeOwners := Map()

/** Pins the actual compiled bridge and code images for the driver lifetime. */
class OllamaGuardianNativePort {
	__New(Pins) {
		global _OllamaGuardianNativeOwners
		if !(Pins is Map)
			throw TypeError("Guardian native initialization requires compiled image pins.")
		this.Pins := Map()
		this.Readers := []
		this.Module := 0
		this.Exports := Map()
		this.InheritanceOwners := Map()
		this.Phase := "acquiring"
		this.FirstError := ""
		local module_pin := Pins.Get("NativeModule", 0)
		if !(module_pin is Map)
			throw TypeError("The guardian bridge image pin is mandatory.")
		local module_path := module_pin.Get("path", "")
		local previous_critical := Critical("On")
		try {
			if _OllamaGuardianNativeOwners.Has(module_path)
				throw ValueError("The guardian bridge already has an owning initialization.")
			_OllamaGuardianNativeOwners[module_path] := this
		} finally Critical(previous_critical)
		try {
			for name in ["NativeModule", "Guardian", "ManagedBridge", "FilesHelper",
				"PublicationHelper", "ProducerHelper", "SourceWorker", "Launcher"] {
				local pin := Pins.Get(name, 0)
				if !(pin is Map) || !(pin.Get("bytes", 0) is Integer) || pin["bytes"] <= 0
						|| pin["bytes"] > 0xffffffff || !RegExMatch(pin.Get("sha256", ""), "\A[0-9a-f]{64}\z")
						|| !RegExMatch(pin.Get("path", ""), "\A[A-Za-z]:\\")
					throw ValueError("Every guardian code image needs its exact path/size/digest.")
				this.Pins[name] := pin.Clone()
				; Numeric read0/share-read0x100 excludes writers and deletion. The
				; stream is recorded before hashing and retained through process exit.
				local reader := FileOpen(pin["path"], 0x100, "UTF-8-RAW")
				this.Readers.Push(reader)
				if reader.Length != pin["bytes"]
					throw Error("Guardian code image length differs from its compiled pin.")
				reader.Pos := 0
				local bytes := Buffer(pin["bytes"], 0)
				if reader.RawRead(bytes, bytes.Size) != bytes.Size || reader.Length != bytes.Size
					throw Error("Guardian code image read was incomplete.")
				if StrLower(CryptoSha256Bytes(bytes)) != pin["sha256"]
					throw Error("Guardian code image digest differs from its compiled pin.")
			}
			this.Module := DllCall("Kernel32\LoadLibraryW", "Str", module_path, "Ptr")
			if !this.Module
				throw OSError(A_LastError, "LoadLibraryW(guardian bridge)")
			for name in ["GB_Create", "GB_Inherited", "GB_AcquireInheritance", "GB_ReleaseInheritance",
				"GB_Bind", "GB_BeginGuardian",
				"GB_Poll", "GB_ClaimActivation", "GB_Stop"] {
				local address := DllCall("Kernel32\GetProcAddress", "Ptr", this.Module, "AStr", name, "Ptr")
				if !address
					throw OSError(A_LastError, "GetProcAddress(guardian bridge)")
				this.Exports[name] := address
			}
			this.Phase := "ready"
		} catch as Err {
			this.FirstError := Err.Message
			this.Phase := "retained-debt"
			throw Err
		}
	}

	_Entry(Name) {
		if this.Phase != "ready" || !this.Exports.Has(Name)
			throw ValueError("The guardian module has no admitted callable entry.")
		return this.Exports[Name]
	}

	_Digest(Hash) {
		if !RegExMatch(Hash, "\A[0-9a-f]{64}\z")
			throw ValueError("Native source intent needs exact lowercase SHA-256.")
		local bytes := Buffer(32, 0)
		loop 32
			NumPut("UChar", Integer("0x" . SubStr(Hash, (A_Index - 1) * 2 + 1, 2)), bytes, A_Index - 1)
		return bytes
	}

	CreateChannel(RecordCapacity, PathCapacity, ManifestHash) {
		if !(RecordCapacity is Integer) || !(PathCapacity is Integer)
				|| RecordCapacity <= 0 || RecordCapacity > 0xffffffff || PathCapacity <= 0 || PathCapacity > 0xffffffff
			throw ValueError("Native source capacities must be derived admitted UInt32 bounds.")
		local manifest := this._Digest(ManifestHash)
		local guardian := this._Digest(this.Pins["Guardian"]["sha256"])
		local id := 0
		if !DllCall(this._Entry("GB_Create"), "UInt", RecordCapacity, "UInt", PathCapacity,
				"Ptr", manifest.Ptr, "Ptr", guardian.Ptr, "Int64*", &id, "CDecl Int")
			throw OSError(A_LastError, "GB_Create")
		if id <= 0
			throw Error("The native guardian registry did not return its owning ID.")
		return id
	}

	Inherited(Id) {
		local mapping := 0, ready := 0, release := 0, parent := 0
		if !DllCall(this._Entry("GB_Inherited"), "Int64", Id, "Ptr*", &mapping,
				"Ptr*", &ready, "Ptr*", &release, "Ptr*", &parent, "CDecl Int")
			throw Error("The native source registry refused its inherited capability list.")
		return [mapping, ready, release, parent]
	}

	InheritanceLease(Id, Handles) {
		if this.InheritanceOwners.Has(Id)
			throw ValueError("The native channel already has its inheritance owner.")
		local lease := OllamaGuardianInheritanceLease(this, Id, Handles)
		; A failed acquisition never depends on the caller's local variable lifetime.
		this.InheritanceOwners[Id] := lease
		return lease
	}

	_AcquireInheritance(Lease) {
		local token := 0, result := 0
		try result := DllCall(this._Entry("GB_AcquireInheritance"), "Int64", Lease.Id,
			"Int64*", &token, "CDecl Int")
		finally Lease.Token := token
		return result
	}

	_ReleaseInheritance(Lease) {
		return DllCall(this._Entry("GB_ReleaseInheritance"), "Int64", Lease.Id,
			"Int64", Lease.Token, "CDecl Int")
	}

	_RetryInheritance() {
		for id, lease in this.InheritanceOwners
			if lease.ReleaseRequested && !lease.ResetAcknowledged
				lease.Release()
	}

	Bind(Id, Process) {
		return DllCall(this._Entry("GB_Bind"), "Int64", Id, "Ptr", Process, "CDecl Int")
	}

	Begin(Id, Job, Daemon, DaemonPid, Source, SourcePid) {
		return DllCall(this._Entry("GB_BeginGuardian"), "Int64", Id, "Ptr", Job,
			"Ptr", Daemon, "Ptr", Source, "CDecl Int")
	}

	Claim(Id) {
		return DllCall(this._Entry("GB_ClaimActivation"), "Int64", Id, "CDecl Int")
	}

	Stop(Id) {
		; Refused reset cannot prevent requesting exact source/job stop.
		try this._RetryInheritance()
		return DllCall(this._Entry("GB_Stop"), "Int64", Id, "CDecl Int")
	}

	Poll(Id) {
		try this._RetryInheritance()
		local wire := Buffer(32, 0)
		if !DllCall(this._Entry("GB_Poll"), "Int64", Id, "Ptr", wire.Ptr, "CDecl Int")
			throw Error("The native guardian registry refused its status lookup.")
		if NumGet(wire, 0, "Int64") != Id || NumGet(wire, 28, "UInt") != 0
			throw Error("The native guardian status does not identify its exact owner.")
		return Map("id", Id, "phase", NumGet(wire, 8, "UInt"), "error", NumGet(wire, 12, "UInt"),
			"source_phase", NumGet(wire, 16, "UInt"), "factory_phase", NumGet(wire, 20, "UInt"),
			"activation_claimed", NumGet(wire, 24, "UInt"))
	}
}

/** Native row owns the originals; this object retains its exact reset token. */
class OllamaGuardianInheritanceLease {
	__New(Port, Id, Handles) {
		if !(Id is Integer) || Id <= 0 || !(Handles is Array) || Handles.Length != 4
			throw ValueError("Inheritance lease requires one exact channel and four originals.")
		this.Port := Port
		this.Id := Id
		this.Handles := Handles.Clone()
		this.Token := 0
		this.Attempted := false
		this.ReleaseRequested := false
		this.ResetAcknowledged := false
		this.FirstError := ""
	}

	Acquire() {
		if this.Attempted || this.ReleaseRequested
			return false
		this.Attempted := true
		try {
			local result := this.Port._AcquireInheritance(this)
			if !(result is Integer) || result != true || this.Token <= 0
				throw Error("Native source inheritance acquisition refused.")
			return true
		} catch as Err {
			if this.FirstError == ""
				this.FirstError := Err.Message
			throw Err
		}
	}

	Release() {
		this.ReleaseRequested := true
		if this.ResetAcknowledged
			return true
		; GB reserves/output-publishes a token before any native flag effects.
		; Zero after a failed call identifies no acquired native flag lease.
		if this.Token == 0 {
			this.ResetAcknowledged := true
			return true
		}
		try {
			local result := this.Port._ReleaseInheritance(this)
			if !(result is Integer) || result != true
				throw Error("Native source inheritance reset is retained debt.")
			this.ResetAcknowledged := true
			return true
		} catch as Err {
			if this.FirstError == ""
				this.FirstError := Err.Message
			return false
		}
	}
}
