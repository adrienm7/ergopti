from pathlib import Path
import hashlib,json,sys
r=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit("Pass one exact INDEX.json key; no source is executed")
row=json.loads((r/"INDEX.json").read_text())[sys.argv[1]]
p=r/row["blob"]
b=p.read_bytes()
if hashlib.sha256(b).hexdigest()!=row["sha256"] or len(b)!=row["bytes"]:raise SystemExit("Body custody mismatch")
sys.stdout.buffer.write(b)
