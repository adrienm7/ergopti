﻿; infra/config_transition_runtime.ahk

; ==============================================================================
; MODULE: Configuration Transition Runtime Boundary
; DESCRIPTION:
; Binds the portable bounded transition journal to strict Windows filesystem
; adapters and to the driver's process-wide terminal configuration barrier.
; Recovery is callable before paths.toml is read; live transitions retain one
; exact owner bundle from their first old snapshot through Reload/Exit.
;
; FEATURES & RATIONALE:
; 1. The portable journal knows only its eight-call port, never AHK/Win32 APIs.
; 2. Boot recovery acquires every recorded target before changing one byte.
; 3. Live callers preflight stale WAL paths before acquiring the dry barrier.
; 4. Strict typed results prevent truthy Maps or string "0" from authorizing IO.
; ==============================================================================

#Requires AutoHotkey v2.0

global _ConfigTransitionRetainedBarrier := false





; ==========================================
; ==========================================
; ======= 1/ Production Port Binding =======
; ==========================================
; ==========================================

; Constructs the exact eight-method production port. Windows-only primitives
; deliberately remain outside ADAPTER_FILE_SYSTEM, whose portable five-method
; contract is consumed by cross-driver compliance tests.
ConfigTransitionProductionPort(InspectPort := unset, Request := "owns") {
	static Issued := Map(), HistoricalIssued := Map(), CanonicalPort := false
	static Native := Map(
		"exists", FSStrictExists, "read", FSReadUtf8Exact,
		"read_bounded", FSReadUtf8ExactBounded, "write_create_durable", FSWriteCreateDurable,
		"move_create", FSAtomicMoveCreate, "move_replace", FSAtomicMoveReplace,
		"delete", FSDeleteStrict, "hash", CryptoSha256)
	Live() {
		for Name, Owner in Native
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return Native["exists"] == FSStrictExists && Native["read"] == FSReadUtf8Exact
			&& Native["read_bounded"] == FSReadUtf8ExactBounded && Native["write_create_durable"] == FSWriteCreateDurable
			&& Native["move_create"] == FSAtomicMoveCreate && Native["move_replace"] == FSAtomicMoveReplace
			&& Native["delete"] == FSDeleteStrict && Native["hash"] == CryptoSha256
	}
	if IsSet(InspectPort) {
		; Identity history is refusal-only: it never grants native admission.
		; Preserve deliberate retired identities so none falls back to custom IO.
		if Request == "known"
			return HistoricalIssued.Has(InspectPort)
		if !(InspectPort is Map) || ObjGetBase(InspectPort) != Map.Prototype || !Issued.Has(InspectPort)
			return false
		for Name in ObjOwnProps(InspectPort)
			return false
		if Request == "retire" {
			Issued.Delete(InspectPort)
			if CanonicalPort == InspectPort
				CanonicalPort := false
			return 1
		}
		if Request != "owns" || !Live() || InspectPort.Count != Native.Count || InspectPort.CaseSense != Native.CaseSense
			return false
		for Name, Callback in Native {
			if !InspectPort.Has(Name) || InspectPort[Name] != Callback
				return false
		}
		return 1
	}
	if Request != "owns" || !Live()
		throw Error("The native transition port owner is unavailable")
	; The native functions are one driver-lifetime owner, not one certificate
	; per read/hash helper. Reuse its exact checked map so the private issuer
	; does not retain an unbounded sequence of otherwise unreachable ports.
	if CanonicalPort is Map {
		if !ConfigTransitionProductionPort(CanonicalPort)
			throw Error("The canonical native transition port data image changed")
		return CanonicalPort
	}
	CanonicalPort := Native.Clone()
	Issued[CanonicalPort] := true
	HistoricalIssued[CanonicalPort] := true
	return CanonicalPort
}

; Resolves the optional injected port without accepting arbitrary falsey values.
_ConfigTransitionRuntimePort(Port) {
	static PortOwner := ConfigTransitionProductionPort
	if PortOwner != ConfigTransitionProductionPort
		throw Error("The original native transition port owner was withdrawn")
	if (Port is Integer) && Port == 0
		return PortOwner.Call()
	if PortOwner.Call(Port, "known") && !PortOwner.Call(Port)
		throw Error("A revoked genuine native transition port cannot dispatch as a custom port")
	return Port
}

; Strict success predicate for public journal results.
ConfigTransitionResultIs(Result, Kind) {
	if !(Kind is String)
		return false
	return (Result is Map)
		&& Result.Has("status") && Result.Has("kind")
		&& (Result["status"] is String) && Result["status"] == "ok"
		&& (Result["kind"] is String) && Result["kind"] == Kind
}

; Creates one exact target intention without leaking the journal's schema into
; every UI caller.
ConfigTransitionPresentTarget(Path, Content, ExpectedOld := 0) {
	Spec := Map("path", Path, "new_present", 1, "new_content", Content)
	if ExpectedOld is Map {
		Spec["expected_old"] := ExpectedOld
	} else if !(ExpectedOld is Integer) || ExpectedOld != 0 {
		throw TypeError("ExpectedOld must be a Map or the integer sentinel 0.")
	}
	return Spec
}

ConfigTransitionAbsentTarget(Path) {
	return Map("path", Path, "new_present", 0, "new_content", "")
}

ConfigTransitionExpectedOld(Present, Content, Port := 0) {
	global CONFIG_TRANSITION_HASH_ABSENT
	if !(Present is Integer) || (Present != 0 && Present != 1)
			|| !(Content is String) || (!Present && Content != "")
		return false
	if !Present
		return Map("present", 0, "hash", CONFIG_TRANSITION_HASH_ABSENT)
	Port := _ConfigTransitionRuntimePort(Port)
	if !(Port is Map)
		return false
	if !_ConfigTransitionPortHash(Port, Content, &Digest, &Detail)
		return false
	return Map("present", 1, "hash", Digest)
}

; Pure reset intention builder shared by the tray action and behavioural tests.
; config.toml remains present to suppress first-run onboarding; the two sibling
; stores become absent in the same crash-recoverable transition.
_ConfigResetTransitionTargets(ConfigPath, TapHoldPath, ApiEntriesPath) {
	return [
		ConfigTransitionPresentTarget(ConfigPath,
			"[_meta]`nschema_version = " . ConfigMigrateCurrentVersion() . "`n"),
		ConfigTransitionAbsentTarget(TapHoldPath),
		ConfigTransitionAbsentTarget(ApiEntriesPath)
	]
}

; Validates a user-selected configuration directory through the same absolute
; Windows-path grammar used by journal targets. A synthetic child lets drive and
; UNC share roots remain valid even though target paths themselves may not end
; in a separator. The returned form has exactly one trailing backslash.
ConfigTransitionNormalizeConfigDir(Path) {
	if !(Path is String) || Path == ""
		return false
	Normalized := StrReplace(Path, "/", "\")
	if !RegExMatch(Normalized, "^[A-Za-z]:\\")
			&& SubStr(Normalized, 1, 2) != "\\"
		return false
	Root := Normalized
	if SubStr(Root, -1) == "\"
		Root := SubStr(Root, 1, StrLen(Root) - 1)
	ProbeName := "__ergopti_config_dir_validation__.tmp"
	ValidatedProbe := _ConfigTransitionNormalizePath(Root . "\" . ProbeName)
	if !(ValidatedProbe is String)
		return false
	return Root . "\"
}

; Selects the boot configuration root without validating an unused default.
; An absent profile must never redirect personal writes to a drive-relative root.
; @param Overrides {Map} Flat locator values returned by ReadPathsToml.
; @param DefaultDir {String} Already-derived ordinary or isolated smoke default.
; @return {String} Exact selected directory; boot preserves separator handling.
ConfigTransitionSelectBootConfigDir(Overrides, DefaultDir) {
	if Overrides.Has("ConfigDirPath") && Overrides["ConfigDirPath"] != ""
		return Overrides["ConfigDirPath"]
	if !(ConfigTransitionNormalizeConfigDir(DefaultDir) is String)
		throw ValueError("The selected default configuration directory is invalid.")
	return DefaultDir
}

; The LogsDirPath override a paths.toml rewrite must keep: the resolved logs
; folder when it differs from the default, else "". Onboarding and a
; configuration-folder change rebuild the whole locator, which would otherwise
; silently send the logs back to the default folder.
; @returns {String}
ConfigTransitionCurrentLogsOverride() {
	global _LogsDir, _DefaultLogsDir
	if !IsSet(_LogsDir) || !IsSet(_DefaultLogsDir)
		return ""
	return (_LogsDir != _DefaultLogsDir) ? _LogsDir : ""
}

; Canonical paths.toml image shared by onboarding and the paths editor. Keeping
; this a pure builder lets the journal snapshot the old locator before any byte
; of new authority reaches disk. Both comment and live value are validated so
; quotes/control bytes can never escape their TOML line.
; @param LogsDir {String} LogsDirPath to store, "" for the OS default.
; @param DefaultLogsDir {String} OS-default logs folder named in the comment.
ConfigTransitionPathsTomlContent(NewDir, DefaultDir := "", LogsDir := "", DefaultLogsDir := "") {
	NormalizedNewDir := ConfigTransitionNormalizeConfigDir(NewDir)
	if !(NormalizedNewDir is String)
		throw ValueError("A paths.toml transition requires a config directory.")
	if !(DefaultDir is String)
		throw TypeError("The default config directory must be a String.")
	NormalizedDefaultDir := ""
	if DefaultDir != "" {
		NormalizedDefaultDir := ConfigTransitionNormalizeConfigDir(DefaultDir)
		if !(NormalizedDefaultDir is String)
			throw ValueError("The default config directory is invalid.")
	}
	if !(LogsDir is String) || !(DefaultLogsDir is String)
		throw TypeError("The logs folders must be Strings.")
	NormalizedLogsDir := ""
	if LogsDir != "" {
		NormalizedLogsDir := ConfigTransitionNormalizeConfigDir(LogsDir)
		if !(NormalizedLogsDir is String)
			throw ValueError("The logs folder is invalid.")
	}
	NormalizedDefaultLogsDir := ""
	if DefaultLogsDir != "" {
		NormalizedDefaultLogsDir := ConfigTransitionNormalizeConfigDir(DefaultLogsDir)
		if !(NormalizedDefaultLogsDir is String)
			throw ValueError("The default logs folder is invalid.")
	}
	DefaultFwd := StrReplace(NormalizedDefaultDir, "\", "/")
	NewFwd := StrReplace(NormalizedNewDir, "\", "/")
	Body := "# Custom paths — auto-generated by ErgoptiPlus.`n"
	Body .= "# Edit this file to point to your personal configuration folder.`n"
	if (DefaultFwd != "")
		Body .= "# If absent or commented out, files are looked up in: "
			. DefaultFwd . "`n"
	Body .= '`nConfigDirPath = "' . NewFwd . '"`n'
	LogsKey := AppDirsLogsOverrideKey()
	if (NormalizedDefaultLogsDir != "")
		Body .= "`n# Logs folder. If absent or commented out, logs are written to: "
			. StrReplace(NormalizedDefaultLogsDir, "\", "/") . "`n"
	if (NormalizedLogsDir != "")
		Body .= LogsKey . ' = "' . StrReplace(NormalizedLogsDir, "\", "/") . '"`n'
	return Body
}





; ============================================
; ============================================
; ======= 2/ Ownership and Live Commit =======
; ============================================
; ============================================

_ConfigTransitionRuntimeOwns(Bundle, Path) {
	return _ConfigWriteLeaseSelectOwner(Bundle, Path) is Object
}

; A failed rollback must not reopen config admission around an unresolved WAL.
; Retain that exact terminal bundle for the next explicit Reload/Exit; lifecycle
; borrows it instead of deadlocking on a second acquisition.
ConfigTransitionRetainBarrier(Bundle) {
	global _ConfigTransitionRetainedBarrier
	PreviousCritical := Critical("On")
	try {
		; Shape is intrinsic; only the actual closed issuer grants custody.
		if !_ConfigWriteLeaseDataObject(Bundle, ["kind", "id", "tokens", "authorized", "shutdown_claimed"])
				|| !_ConfigWriteTerminalTryAcquire([], Bundle)
			return false
		if !(Bundle is Object) || !Bundle.HasOwnProp("kind")
				|| Bundle.kind != "terminal_bundle"
				|| !Bundle.HasOwnProp("tokens") || !(Bundle.tokens is Array)
				|| !_ConfigWriteTerminalIsActive()
			return false
		for Token in Bundle.tokens {
			if !_ConfigWriteLeaseOwns(Token)
				return false
		}
		if (_ConfigTransitionRetainedBarrier is Object)
			return _ConfigTransitionRetainedBarrier == Bundle
		_ConfigTransitionRetainedBarrier := Bundle
		return true
	} finally Critical(PreviousCritical)
}

ConfigTransitionRetainedBarrier() {
	global _ConfigTransitionRetainedBarrier
	PreviousCritical := Critical("On")
	try return (IsSet(_ConfigTransitionRetainedBarrier) && _ConfigTransitionRetainedBarrier is Object)
		? _ConfigTransitionRetainedBarrier : false
	finally Critical(PreviousCritical)
}

; Refusal callback for a transition that lent its bundle to a reload which was
; refused after launch. The bundle comes back owned: RollbackFn(Bundle) restores
; the old state and returns true only when it retained the barrier, exactly as
; the caller's synchronous refusal branch; every other outcome releases it.
ConfigTransitionSettleRefusedReload(RollbackFn, Bundle, *) {
	Retained := false
	try Retained := RollbackFn.Call(Bundle)
	finally {
		if !((Retained is Integer) && Retained == 1)
			_ConfigWriteTerminalRelease(Bundle)
	}
}

; Classifies the resolution of a failed owned operation. Only an absent WAL or
; a verified all-old recovery lets the initiating process continue on its old
; RAM state. Any other outcome retains the global barrier and annotates the
; primary result so UI finally-blocks cannot accidentally reopen admission.
_ConfigTransitionProtectFailedResolution(Primary, Resolution, Bundle) {
	if !(Primary is Map)
		Primary := _ConfigTransitionResult("fatal", "malformed_primary_result")
	Primary["rollback"] := Resolution
	if ConfigTransitionResultIs(Resolution, "absent")
			|| ConfigTransitionResultIs(Resolution, "recovered_old")
		return Primary
	; Never release admission merely because retaining the discoverable bundle
	; itself hit an invariant failure. The initiating caller still owns Bundle,
	; so marking it retained makes its finally block fail closed. If registration
	; failed, later lifecycle acquisition also sees the live terminal barrier as
	; busy and refuses instead of reopening around an unresolved disk image.
	if !ConfigTransitionRetainBarrier(Bundle)
		Primary["barrier_registration_failed"] := 1
	Primary["barrier_retained"] := 1
	Primary["bundle"] := Bundle
	return Primary
}

; Acquires the LLM-aware process-wide barrier over intended targets plus every
; path named by an already-valid transition WAL. The WAL is inspected again
; after acquisition before recovery, closing the read-to-own race.
ConfigTransitionAcquireLifecycleBundle(PathsFile, IntendedPaths, Port := 0,
		AcquireFn := 0, SettleFn := 0) {
	PreviousCritical := Critical("Off")
	try return _ConfigTransitionAcquireLifecycleBundleNonCritical(PathsFile,
		IntendedPaths, Port, AcquireFn, SettleFn)
	finally Critical(PreviousCritical)
}

_ConfigTransitionAcquireLifecycleBundleNonCritical(PathsFile, IntendedPaths,
		Port, AcquireFn, SettleFn) {
	UseNative := ((Port is Integer) && Port == 0) || ConfigTransitionProductionPort(Port)
	Port := _ConfigTransitionRuntimePort(Port)
	NormalizedLocator := _ConfigTransitionNormalizePath(PathsFile)
	if !(NormalizedLocator is String) || !(IntendedPaths is Array)
		return _ConfigTransitionResult("fatal", "invalid_arguments")
	Inspected := ConfigTransitionInspect(NormalizedLocator, Port)
	if !ConfigTransitionResultIs(Inspected, "absent")
			&& !ConfigTransitionResultIs(Inspected, "ready")
		return Inspected
	AdditionalPaths := [NormalizedLocator]
	for Path in IntendedPaths {
		NormalizedPath := _ConfigTransitionNormalizePath(Path)
		if !(NormalizedPath is String)
			return _ConfigTransitionResult("fatal", "invalid_target_path")
		AdditionalPaths.Push(NormalizedPath)
	}
	if ConfigTransitionResultIs(Inspected, "ready") {
		for Target in Inspected["record"]["targets"]
			AdditionalPaths.Push(Target["path"])
	}
	try Bundle := HasMethod(AcquireFn, "Call")
		? AcquireFn.Call(AdditionalPaths)
		: ConfigWriteAcquireLifecycleBundle(AdditionalPaths)
	catch as Err {
		return _ConfigTransitionResult("retry", "terminal_barrier_failed",
			"Terminal bundle acquisition threw: " . Err.Message)
	}
	if !(Bundle is Object) {
		return _ConfigTransitionResult("retry", "terminal_barrier_busy",
			"Another configuration transaction owns the process-wide barrier.")
	}
	; A full-save accepted before the terminal barrier is an older durable
	; obligation, not work that may run from OnExit after this WAL has committed.
	; Settle it now through the borrowed bundle so the journal snapshots its bytes.
	try Settled := HasMethod(SettleFn, "Call")
		? SettleFn.Call(Bundle)
		: _ConfigFullSaveSettleTerminal(Bundle)
	catch as Err {
		Settled := 0
		SettleDetail := Err.Message
	}
	if !((Settled is Integer) && Settled == 1) {
		_ConfigWriteTerminalRelease(Bundle)
		return _ConfigTransitionResult("retry", "pending_save_unsettled",
			IsSet(SettleDetail) ? SettleDetail
				: "An accepted full configuration save remains non-durable.")
	}
	; Settle the inspected WAL while every named target is owned, before the
	; caller can parse candidate config bytes. Building from a prepared/applying
	; mixed image and only recovering inside Commit would canonize crash debris.
	Recovered := _ConfigTransitionRecoverOwnedNonCritical(NormalizedLocator,
		Bundle, UseNative ? 0 : Port, 0)
	if !ConfigTransitionResultIs(Recovered, "absent")
			&& !ConfigTransitionResultIs(Recovered, "recovered_old")
			&& !ConfigTransitionResultIs(Recovered, "recovered_new") {
		return _ConfigTransitionProtectFailedResolution(Recovered,
			Recovered.Clone(), Bundle)
	}
	Result := _ConfigTransitionResult("ok", "bundle_acquired", "",
		Recovered["record"])
	Result["bundle"] := Bundle
	Result["recovery_kind"] := Recovered["kind"]
	return Result
}

; Recovers an existing journal only when the retained bundle owns its locator
; and every recorded target. This is intentionally stricter than relying on the
; terminal flag alone: future lease implementations may become path-scoped.
ConfigTransitionRecoverOwned(PathsFile, Bundle, Port := 0, PauseFn := 0) {
	PreviousCritical := Critical("Off")
	try return _ConfigTransitionRecoverOwnedNonCritical(PathsFile, Bundle,
		Port, PauseFn)
	finally Critical(PreviousCritical)
}

_ConfigTransitionRecoverOwnedNonCritical(PathsFile, Bundle, Port, PauseFn) {
	UseNative := ((Port is Integer) && Port == 0) || ConfigTransitionProductionPort(Port)
	Port := _ConfigTransitionRuntimePort(Port)
	NormalizedLocator := _ConfigTransitionNormalizePath(PathsFile)
	if !(NormalizedLocator is String)
		return _ConfigTransitionResult("fatal", "invalid_arguments")
	if !_ConfigTransitionRuntimeOwns(Bundle, NormalizedLocator) {
		return _ConfigTransitionResult("fatal", "locator_owner_missing",
			"The terminal bundle does not own the stable locator.")
	}
	Inspected := ConfigTransitionInspect(NormalizedLocator, Port)
	if ConfigTransitionResultIs(Inspected, "absent")
		return Inspected
	if !ConfigTransitionResultIs(Inspected, "ready")
		return Inspected
	for Target in Inspected["record"]["targets"] {
		if !_ConfigTransitionRuntimeOwns(Bundle, Target["path"]) {
			return _ConfigTransitionResult("fatal", "target_owner_missing",
				"The terminal bundle does not own recorded target '"
				. Target["path"] . "'.", Inspected["record"])
		}
	}
	NoopFn := 0
	if UseNative {
		try NativeOwner := _ConfigTransitionGuardedProductionPort(NormalizedLocator, Bundle, [], true)
		catch as Err
			return _ConfigTransitionResult("retry", "recovery_source_schema_refused", Err.Message, Inspected["record"])
		Port := NativeOwner.port
		NoopFn := NativeOwner.noop
	} else {
		for Target in Inspected["record"]["targets"] {
			SplitPath(Target["path"], &Name)
			if StrLower(Name) == "config.toml" || ConfigMigrateBoot(Target["path"], "known")
				return _ConfigTransitionResult("fatal", "guarded_custom_recovery_port_unqualified")
		}
	}
	return ConfigTransitionRecover(NormalizedLocator, Port, PauseFn, NoopFn)
}

; Prepares and applies one ordered transition while the caller retains the
; terminal bundle. Failure paths immediately attempt phase-directed rollback;
; the primary result remains authoritative and carries the rollback result for
; logging/tests instead of turning a failed commit into truthy success.
ConfigTransitionCommitOwned(PathsFile, TargetSpecs, Bundle, Port := 0,
		PauseFn := 0) {
	PreviousCritical := Critical("Off")
	try return _ConfigTransitionCommitOwnedNonCritical(PathsFile, TargetSpecs,
		Bundle, Port, PauseFn)
	finally Critical(PreviousCritical)
}

_ConfigTransitionCommitOwnedNonCritical(PathsFile, TargetSpecs, Bundle, Port,
		PauseFn) {
	UseNative := ((Port is Integer) && Port == 0) || ConfigTransitionProductionPort(Port)
	Port := _ConfigTransitionRuntimePort(Port)
	NormalizedLocator := _ConfigTransitionNormalizePath(PathsFile)
	if !(NormalizedLocator is String) || !(TargetSpecs is Array)
		return _ConfigTransitionResult("fatal", "invalid_arguments")
	if !_ConfigTransitionRuntimeOwns(Bundle, NormalizedLocator)
		return _ConfigTransitionResult("fatal", "locator_owner_missing")
	for Spec in TargetSpecs {
		if !(Spec is Map) || !Spec.Has("path")
			return _ConfigTransitionResult("fatal", "target_schema_invalid")
		NormalizedPath := _ConfigTransitionNormalizePath(Spec["path"])
		if !(NormalizedPath is String)
				|| !_ConfigTransitionRuntimeOwns(Bundle, NormalizedPath)
			return _ConfigTransitionResult("fatal", "target_owner_missing")
	}
	Recovered := _ConfigTransitionRecoverOwnedNonCritical(NormalizedLocator,
		Bundle, UseNative ? 0 : Port, 0)
	if !ConfigTransitionResultIs(Recovered, "absent")
			&& !ConfigTransitionResultIs(Recovered, "recovered_old")
			&& !ConfigTransitionResultIs(Recovered, "recovered_new")
		return _ConfigTransitionProtectFailedResolution(Recovered,
			Recovered.Clone(), Bundle)
	NoopFn := 0
	if UseNative {
		try NativeOwner := _ConfigTransitionGuardedProductionPort(NormalizedLocator, Bundle, TargetSpecs)
		catch as Err
			return _ConfigTransitionResult("retry", "source_schema_admission_refused", Err.Message)
		Port := NativeOwner.port
		NoopFn := NativeOwner.noop
	} else {
		for Spec in TargetSpecs {
			SplitPath(Spec["path"], &Name)
			if StrLower(Name) == "config.toml" || ConfigMigrateBoot(Spec["path"], "known")
				return _ConfigTransitionResult("fatal", "guarded_custom_port_unqualified")
		}
	}
	Prepared := ConfigTransitionPrepare(NormalizedLocator, TargetSpecs, Port,
		"", PauseFn)
	if !ConfigTransitionResultIs(Prepared, "prepared") {
		Rollback := _ConfigTransitionRecoverOwnedNonCritical(
			NormalizedLocator, Bundle, UseNative ? 0 : Port, 0)
		return _ConfigTransitionProtectFailedResolution(Prepared, Rollback,
			Bundle)
	}
	Applied := ConfigTransitionApply(NormalizedLocator, Port, PauseFn, NoopFn)
	if !ConfigTransitionResultIs(Applied, "committed_new") {
		Rollback := _ConfigTransitionRecoverOwnedNonCritical(
			NormalizedLocator, Bundle, UseNative ? 0 : Port, 0)
		return _ConfigTransitionProtectFailedResolution(Applied, Rollback,
			Bundle)
	}
	return Applied
}

; Aborts a live transition after a refused Reload. ``committed_new`` normally
; directs boot recovery forward; while this same process still retains the
; terminal bundle, it is permitted to durably demote that phase to ``applying``
; and therefore restore all-old. A crash anywhere after the demotion also rolls
; old at boot, so the caller never releases a barrier around split authority.
ConfigTransitionRollbackOwned(PathsFile, Bundle, Port := 0, PauseFn := 0) {
	PreviousCritical := Critical("Off")
	try return _ConfigTransitionRollbackOwnedNonCritical(PathsFile, Bundle,
		Port, PauseFn)
	finally Critical(PreviousCritical)
}

_ConfigTransitionRollbackOwnedNonCritical(PathsFile, Bundle, Port, PauseFn) {
	global CONFIG_TRANSITION_PHASE_COMMITTED_NEW
	global CONFIG_TRANSITION_PHASE_APPLYING
	UseNative := ((Port is Integer) && Port == 0) || ConfigTransitionProductionPort(Port)
	Port := _ConfigTransitionRuntimePort(Port)
	NormalizedLocator := _ConfigTransitionNormalizePath(PathsFile)
	if !(NormalizedLocator is String)
		return _ConfigTransitionResult("fatal", "invalid_arguments")
	if !_ConfigTransitionRuntimeOwns(Bundle, NormalizedLocator)
		return _ConfigTransitionResult("fatal", "locator_owner_missing")
	Inspected := ConfigTransitionInspect(NormalizedLocator, Port)
	if ConfigTransitionResultIs(Inspected, "absent")
		return Inspected
	if !ConfigTransitionResultIs(Inspected, "ready")
		return Inspected
	Record := Inspected["record"]
	for Target in Record["targets"] {
		if !_ConfigTransitionRuntimeOwns(Bundle, Target["path"])
			return _ConfigTransitionResult("fatal", "target_owner_missing", "",
				Record)
	}
	if UseNative {
		try NativeOwner := _ConfigTransitionGuardedProductionPort(NormalizedLocator, Bundle, [], true)
		catch as Err
			return _ConfigTransitionResult("retry", "rollback_source_schema_refused", Err.Message, Record)
		Port := NativeOwner.port
	}
	if Record["phase"] == CONFIG_TRANSITION_PHASE_COMMITTED_NEW {
		RollbackRecord := _ConfigTransitionWithPhase(Record,
			CONFIG_TRANSITION_PHASE_APPLYING)
		Demoted := _ConfigTransitionPublishWalReplace(Port,
			NormalizedLocator, RollbackRecord)
		if !ConfigTransitionResultIs(Demoted, "wal_phase_published")
			return Demoted
		_ConfigTransitionPause(PauseFn, "phase:rollback_applying")
	}
	return _ConfigTransitionRecoverOwnedNonCritical(NormalizedLocator, Bundle,
		UseNative ? 0 : Port, PauseFn)
}

; Emits one English developer diagnostic. UI callers add their existing
; localized MsgBox/notification; boot uses the result in a visible fatal error.
ConfigTransitionLogFailure(Context, Result) {
	PreviousCritical := Critical("Off")
	try {
	Status := (Result is Map) && Result.Has("status")
		? String(Result["status"]) : "malformed"
	Kind := (Result is Map) && Result.Has("kind")
		? String(Result["kind"]) : "malformed_result"
	Detail := (Result is Map) && Result.Has("detail")
		? String(Result["detail"]) : ""
	try LoggerError(Context,
		"Configuration transition failed ({1}/{2}): {3}",
		Status, Kind, Detail)
	return false
	} finally Critical(PreviousCritical)
}





; ==============================================
; ==============================================
; ======= 3/ Pre-locator Boot Recovery =========
; ==============================================
; ==============================================

; Resolves a valid WAL under a dry terminal barrier before paths.toml can be
; read. A malformed/unreadable WAL is returned unchanged as quarantine; no
; cleanup is attempted without a validated ownership namespace.
ConfigTransitionRecoverAtBoot(PathsFile, Port := 0, PauseFn := 0) {
	PreviousCritical := Critical("Off")
	try return _ConfigTransitionRecoverAtBootNonCritical(PathsFile, Port,
		PauseFn)
	finally Critical(PreviousCritical)
}

_ConfigTransitionRecoverAtBootNonCritical(PathsFile, Port, PauseFn) {
	UseNative := ((Port is Integer) && Port == 0) || ConfigTransitionProductionPort(Port)
	Port := _ConfigTransitionRuntimePort(Port)
	NormalizedLocator := _ConfigTransitionNormalizePath(PathsFile)
	if !(NormalizedLocator is String)
		return _ConfigTransitionResult("fatal", "invalid_arguments")
	Inspected := ConfigTransitionInspect(NormalizedLocator, Port)
	if ConfigTransitionResultIs(Inspected, "absent")
		return Inspected
	if !ConfigTransitionResultIs(Inspected, "ready")
		return Inspected
	OwnedPaths := [NormalizedLocator]
	for Target in Inspected["record"]["targets"]
		OwnedPaths.Push(Target["path"])
	Bundle := _ConfigWriteTerminalTryAcquire(OwnedPaths)
	if !(Bundle is Object) {
		return _ConfigTransitionResult("retry", "terminal_barrier_busy",
			"Boot recovery could not acquire every recorded target.",
			Inspected["record"])
	}
	try return _ConfigTransitionRecoverOwnedNonCritical(NormalizedLocator,
		Bundle, UseNative ? 0 : Port, PauseFn)
	finally _ConfigWriteTerminalRelease(Bundle)
}

; Writes an early diagnostic beside the stable locator, then throws. The throw
; is deliberate: continuing into ReadPathsToml after quarantine would let a
; mixed old/new image become live authority and be re-saved as if coherent.
ConfigTransitionRecoverAtBootOrThrow(PathsFile, Port := 0) {
	PreviousCritical := Critical("Off")
	try return _ConfigTransitionRecoverAtBootOrThrowNonCritical(PathsFile, Port)
	finally Critical(PreviousCritical)
}

_ConfigTransitionRecoverAtBootOrThrowNonCritical(PathsFile, Port) {
	Result := _ConfigTransitionRecoverAtBootNonCritical(PathsFile, Port, 0)
	if ConfigTransitionResultIs(Result, "absent")
			|| ConfigTransitionResultIs(Result, "recovered_old")
			|| ConfigTransitionResultIs(Result, "recovered_new")
		return true
	Status := (Result is Map) && Result.Has("status")
		? String(Result["status"]) : "malformed"
	Kind := (Result is Map) && Result.Has("kind")
		? String(Result["kind"]) : "malformed_result"
	Detail := (Result is Map) && Result.Has("detail")
		? String(Result["detail"]) : ""
	Message := "Configuration transition recovery refused before paths.toml "
		. "read (" . Status . "/" . Kind . "): " . Detail
	; LoggerInit has not run and paths.toml is unread: the line goes straight
	; to bootstrap.log in the default logs folder.
	try LoggerAppendBootstrapLine("ERROR", "ConfigTransition", Message)
	throw Error(Message)
}


; This constructor owns its eight-method native port and private target guards.
; Public intent/cache objects never register a journal phase or native issuer.
_ConfigTransitionGuardedProductionPort(PathsFile, Bundle, TargetSpecs, Recovery := false) {
	static PortOwner := ConfigTransitionProductionPort
	static ReplaceOwner := FSConfigAtomicMoveReplace, CreateOwner := FSConfigAtomicMoveCreate
	static DeleteOwner := FSConfigDeleteStrict, NoopOwner := FSNativeAcknowledge
	for Owner in [PortOwner, ReplaceOwner, CreateOwner, DeleteOwner, NoopOwner]
		if Object.Prototype.HasOwnProp.Call(Owner, "Call")
			throw Error("The original configuration native producer was modified")
	if PortOwner != ConfigTransitionProductionPort || ReplaceOwner != FSConfigAtomicMoveReplace
			|| CreateOwner != FSConfigAtomicMoveCreate || DeleteOwner != FSConfigDeleteStrict
			|| NoopOwner != FSNativeAcknowledge
		throw Error("The original configuration native producer was withdrawn")
	Native := PortOwner.Call()
	Guards := Map()
	Guards.CaseSense := "On"
	; Keep canonical Native as authority. This private callback adapter forwards
	; the captured real native class without registering itself as a native port.
	Callbacks := Map()
	for Method, Callback in Native
		Callbacks[Method] := Dispatch.Bind(Callback)
	if Recovery {
		Inspected := ConfigTransitionInspect(PathsFile, Callbacks)
		if !ConfigTransitionResultIs(Inspected, "ready")
			throw Error("The actual native recovery WAL is unavailable")
		TargetSpecs := Inspected["record"]["targets"]
	}
	if !(TargetSpecs is Array) || !_ConfigWriteTerminalOwnsExact(Bundle, PathsFile)
		throw Error("The actual transition lacks its native locator owner")
	for Spec in TargetSpecs {
		Path := Spec["path"]
		SplitPath(Path, &Name)
		if StrLower(Name) != "config.toml" && !ConfigMigrateBoot(Path, "known")
			continue
		if !Recovery && !ConfigSchemaPrepareOwnedSource(Path, Bundle)
			throw Error("The genuine transition target source/schema could not be constructed")
		if !NativeLive()
			throw Error("The actual native transition port owner was withdrawn before source read")
		Present := Callbacks["exists"].Call(Path)
		if !NativeLive()
			throw Error("The actual native transition port owner was withdrawn during source read")
		Content := Present ? Callbacks["read"].Call(Path) : ""
		Candidate := Recovery ? Map("present", Present, "content", Content)
			: Map("present", Spec["new_present"], "content", Spec["new_content"])
		Guard := Recovery ? ConfigMigrateBoot(Path, "capture_recovery", PathsFile, Bundle)
			: ConfigMigrateBoot(Path, "capture_transition", Candidate, Bundle)
		if !HasMethod(Guard, "Call") || !Guard.Call(Content, Present, Candidate["content"], Candidate["present"])
			throw Error("The complete configuration transition candidate was refused")
		Guards[_ConfigWriteLeaseKey(Path)] := { check: Guard, old_present: Present, old_content: Content,
			new_present: Candidate["present"], new_content: Candidate["content"] }
	}
	NativeLive() {
		for Owner in [PortOwner, ReplaceOwner, CreateOwner, DeleteOwner, NoopOwner]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return ReplaceOwner == FSConfigAtomicMoveReplace && CreateOwner == FSConfigAtomicMoveCreate
			&& DeleteOwner == FSConfigDeleteStrict && NoopOwner == FSNativeAcknowledge
			&& PortOwner == ConfigTransitionProductionPort && PortOwner.Call(Native)
			&& Native["exists"] == FSStrictExists && Native["read"] == FSReadUtf8Exact
			&& Native["read_bounded"] == FSReadUtf8ExactBounded && Native["write_create_durable"] == FSWriteCreateDurable
			&& Native["move_create"] == FSAtomicMoveCreate && Native["move_replace"] == FSAtomicMoveReplace
			&& Native["delete"] == FSDeleteStrict && Native["hash"] == CryptoSha256
	}
	AllLive() {
		if !NativeLive() || !_ConfigWriteTerminalOwnsExact(Bundle, PathsFile)
			return false
		for Key, Row in Guards {
			if !Row.check.Call(Row.old_content, Row.old_present, Row.new_content, Row.new_present)
				return false
		}
		; Source comparisons may be long; their accepted result cannot retain
		; callback authority withdrawn while the real guards were evaluating.
		return NativeLive() && _ConfigWriteTerminalOwnsExact(Bundle, PathsFile)
	}
	Dispatch(Callback, Args*) {
		if !AllLive()
			throw Error("The actual guarded native callback owner was withdrawn before dispatch")
		Result := Callback.Call(Args*)
		if !AllLive()
			throw Error("The actual guarded native callback owner was withdrawn during dispatch")
		return Result
	}
	Read(Path) {
		if !AllLive()
			throw Error("The native transition source owner was withdrawn")
		Content := Callbacks["read"].Call(Path)
		if !AllLive()
			throw Error("The actual guarded native read owner was withdrawn before source admission")
		Key := _ConfigWriteLeaseKey(Path)
		if Guards.Has(Key) && !Guards[Key].check.Call(Content, 1, Content, 1)
			throw Error("The actual transition target source changed outside its admitted images")
		return Content
	}
	MoveReplace(Source, Destination) {
		if !AllLive()
			return 0
		Key := _ConfigWriteLeaseKey(Destination)
		if Guards.Has(Key) {
			Candidate := Callbacks["read"].Call(Source)
			Present := Callbacks["exists"].Call(Destination)
			Content := Present ? Callbacks["read"].Call(Destination) : ""
			Check := Guards[Key].check
			Admission := () => AllLive() && Check.Call(Content, Present, Candidate, 1)
		} else
			Admission := AllLive
		return ReplaceOwner.Call(Source, Destination, &MoveError, Admission)
	}
	MoveCreate(Source, Destination) {
		if !AllLive()
			return 0
		return CreateOwner.Call(Source, Destination, AllLive)
	}
	Delete(Path) {
		if !AllLive()
			return 0
		Key := _ConfigWriteLeaseKey(Path)
		if Guards.Has(Key) {
			Present := Callbacks["exists"].Call(Path)
			Content := Present ? Callbacks["read"].Call(Path) : ""
			Check := Guards[Key].check
			Admission := () => AllLive() && Check.Call(Content, Present, "", 0)
		} else
			Admission := AllLive
		return DeleteOwner.Call(Path, Admission)
	}
	Noop(Path, Content, Present) {
		if !AllLive()
			return 0
		ActualPresent := Callbacks["exists"].Call(Path)
		ActualContent := ActualPresent ? Callbacks["read"].Call(Path) : ""
		if ActualPresent != Present || StrCompare(ActualContent, Content, true) != 0
			return 0
		Key := _ConfigWriteLeaseKey(Path)
		if Guards.Has(Key) {
			Check := Guards[Key].check
			Admission := () => AllLive() && Check.Call(Content, Present, Content, Present)
		} else
			Admission := AllLive
		return NoopOwner.Call(Admission)
	}
	Port := Callbacks.Clone()
	Port["read"] := Read
	Port["move_create"] := MoveCreate
	Port["move_replace"] := MoveReplace
	Port["delete"] := Delete
	return { port: Port, noop: Noop }
}


; Reads genuine validated WAL material through fixed native functions. Returned
; objects are detached facts; the private schema issuer invokes this owner
; itself and never accepts a caller's copy as a registration capability.
_ConfigTransitionNativeRecoveryImages(PathsFile, Path, Bundle) {
	static PortOwner := ConfigTransitionProductionPort, InspectOwner := ConfigTransitionInspect
	static NamespaceOwner := _ConfigTransitionPreflightOwnedNamespace, ArtifactOwner := _ConfigTransitionReadArtifact
	static ArtifactPathsOwner := _ConfigTransitionArtifactPaths, SnapshotOwner := _ConfigTransitionReadSnapshot
	static TerminalOwner := _ConfigWriteTerminalOwnsExact, KeyOwner := _ConfigWriteLeaseKey
	static ResultOwner := ConfigTransitionResultIs
	NativeLive() {
		for Owner in [PortOwner, InspectOwner, NamespaceOwner, ArtifactOwner, ArtifactPathsOwner,
			SnapshotOwner, TerminalOwner, KeyOwner, ResultOwner]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return PortOwner == ConfigTransitionProductionPort && InspectOwner == ConfigTransitionInspect
			&& NamespaceOwner == _ConfigTransitionPreflightOwnedNamespace && ArtifactOwner == _ConfigTransitionReadArtifact
			&& ArtifactPathsOwner == _ConfigTransitionArtifactPaths && SnapshotOwner == _ConfigTransitionReadSnapshot
			&& TerminalOwner == _ConfigWriteTerminalOwnsExact && KeyOwner == _ConfigWriteLeaseKey
			&& ResultOwner == ConfigTransitionResultIs
	}
	PortLive() {
		if !NativeLive()
			return false
		if !IsSet(Port)
			return true
		try Accepted := PortOwner.Call(Port)
		catch {
			return false
		}
		return NativeLive() && (Accepted is Integer) && Accepted == 1
	}
	OwnerLive() {
		if !PortLive()
			return false
		LocatorOwned := TerminalOwner.Call(Bundle, PathsFile)
		if !PortLive() || !(LocatorOwned is Integer) || LocatorOwned != 1
			return false
		TargetOwned := TerminalOwner.Call(Bundle, Path)
		return PortLive() && (TargetOwned is Integer) && TargetOwned == 1
	}
	; This private adapter is data for the original recovery producers, never
	; an issued native port or a schema registration capability. The captured
	; canonical port remains the only native authority checked by OwnerLive.
	Dispatch(Callback, Args*) {
		if !OwnerLive()
			throw Error("The actual recovery native owner was withdrawn before callback dispatch")
		Result := Callback.Call(Args*)
		if !OwnerLive()
			throw Error("The actual recovery native owner was withdrawn during callback dispatch")
		return Result
	}
	ActualResultIs(Result, Kind) {
		if !OwnerLive()
			return false
		Accepted := ResultOwner.Call(Result, Kind)
		return OwnerLive() && (Accepted is Integer) && Accepted == 1
	}
	if !OwnerLive()
		return false
	try Port := PortOwner.Call()
	catch {
		return false
	}
	if !OwnerLive()
		return false
	; Capture real admitted callbacks before any producer can enter native IO.
	; A descriptor withdrawal during read must refuse before the same producer
	; resumes its nested hash or subsequent filesystem callback.
	RecoveryPort := Map()
	for Method, Callback in Port
		RecoveryPort[Method] := Dispatch.Bind(Callback)
	if !OwnerLive()
		return false
	Inspected := InspectOwner.Call(PathsFile, RecoveryPort)
	if !ActualResultIs(Inspected, "ready")
		return false
	Record := Inspected["record"]
	if !OwnerLive()
		return false
	Namespace := NamespaceOwner.Call(PathsFile, Record, RecoveryPort)
	if !ActualResultIs(Namespace, "cleanup_preflight")
		return false
	if !OwnerLive()
		return false
	TargetKey := KeyOwner.Call(Path)
	if !OwnerLive() || !(TargetKey is String)
		return false
	Selected := false
	for Target in Record["targets"] {
		if !OwnerLive()
			return false
		CandidateKey := KeyOwner.Call(Target["path"])
		if !OwnerLive() || !(CandidateKey is String)
			return false
		if StrCompare(CandidateKey, TargetKey, true) == 0 {
			Selected := Target
			break
		}
	}
	if !(Selected is Map) || !OwnerLive()
		return false
	Actual := SnapshotOwner.Call(RecoveryPort, Path)
	if !ActualResultIs(Actual, "snapshot")
		return false
	Snapshot := Actual["snapshot"]
	if !OwnerLive()
		return false
	Artifacts := ArtifactPathsOwner.Call(Path, Record["tx_id"])
	if !OwnerLive()
		return false
	Images := Map("old", false, "new", false)
	for Side in ["old", "new"] {
		if !OwnerLive()
			return false
		if !Selected[Side . "_present"] {
			Images[Side] := { present: 0, source: "" }
			continue
		}
		if Snapshot["present"] == 1 && Snapshot["hash"] == Selected[Side . "_hash"] {
			Images[Side] := { present: 1, source: Snapshot["content"] }
			continue
		}
		Artifact := ArtifactOwner.Call(RecoveryPort, Artifacts[Side], Selected[Side . "_hash"])
		if !OwnerLive()
			return false
		if ActualResultIs(Artifact, "artifact")
			Images[Side] := { present: 1, source: Artifact["content"] }
	}
	if !OwnerLive()
		return false
	Desired := Record["phase"] == CONFIG_TRANSITION_PHASE_COMMITTED_NEW ? "new" : "old"
	if !(Images[Desired] is Object) || !OwnerLive()
		return false
	return { old: Images["old"], new: Images["new"] }
}
