# Windows targeted semantic configuration writer

This packet is an isolated source preparation against
`88909124461a3dbdfe5b745453fe50333eb64adc`. It advances TODO42; it does not
complete the full-state writer, installed-driver acceptance, or native validation.
The repository checkout, index, refs and CI have not been modified by this task.

## Implemented ownership

`TOML_BuildConfigUpdatedContent` and `TOML_ConfigBatchWrite` are explicit
configuration-only entry points. They reuse `_TOML_BatchWriteImpl` for classified
source reads, session write refusals, exact source generation checks, staging,
flush/readback verification and atomic replacement. They do not introduce a
second filesystem writer. Generic TOML builder/writer callers keep their
existing flat semantics and strict namespace-loss refusals.

The new native document transformation starts from the complete typed source.
It applies section paths and literal leaf keys to an independent document,
rejecting scalar/array namespace collisions. Existing root and section-relative
dotted rows retain their native key spelling when changed. Inline descendants
are rendered through their existing assignment owner. Newly added leaves use
the deepest surviving explicit table, or the root before the first header;
they never accidentally acquire the preceding table's owner.

Unchanged assignments, comments, multiline values, unknown records and distinct
table-array generations remain exact physical source spans. Changed owned
assignments retain canonical value rendering. Every completed image is parsed
again and compared with the complete requested semantic model before the
existing source and publication fences. Semantic no-ops retain the exact source,
including unchanged owned comments. An inline assignment is one physical record:
editing an owned descendant retains its other semantic values but canonicalizes
that containing record. Empty semantic write batches still require
valid source admission. Prefix replacement is explicit ownership; ordinary
updates cannot manufacture a subtree through an obsolete scalar or array.

Only the actual configuration gateway and scoped detached configuration builder
select these new entry points. Generic extension overrides, personal files,
cleanup discovery and other groups' builders remain untouched.

## Assertions and validation

The existing registered test file is retained as a byte-identical prefix;
all original assertions and independent shared corpora are unchanged. New
registered cases cover handwritten complete source/candidate images, root and
relative dotted paths, inline descendants, array generations, quoted literal
dots, exact Unicode/empty names, new table ownership, deletion, unchanged owned
comments, duplicate sources, scalar/array collisions, explicit replacement,
actual source mutation and the actual admitted configuration gateway.

`independent-golden-oracle.json` validates the independently authored complete
images with Python `tomllib` and separately applied explicit effects. It is
not execution of the native writer. The source encoding, registered suite
manifest, include coverage, closure and strict convention gates passed; their
exact logs and `verify-change-selection.json` are saved. Isolated patch
application reproduces all five frozen postimages exactly.

Windows AutoHotkey/Wine is unavailable here. Native unit, complete include
compilation/startup, E2E, packaging and installation have not executed for this
packet. The expected native red/green control is prepared as
`old-renderer-control.patch`: it keeps the new API names and production routes
while selecting the existing flat rendering path in their wrappers. Thus native
red is a behavior comparison rather than a missing-function failure. That
control has not executed either.

Initial archive-only gates lacked hook/workflow and OS lint inputs. Those setup
failures were repaired using exact baseline archive files; later selected
static checks passed. No root source changed during that correction.

## Full-save policy remains strict

`SaveFullConfig` continues calling the generic writer. In particular, the
pre-existing FMS inline-child case still requires `CONFIG_SAVE_FAILED`, while
its physical equivalent requires success. No input-shape exception or weakened
assertion is included.

Source inspection shows that the actual collector's obsolete neutral
`enabled=false` row is removed by `_ConfigKeepOutdatedEntries`; its valid
`time_activation_seconds=0.25` row remains unchanged. The new separate semantic
candidate appears to be a genuine exact no-op that retains both obsolete
`enabled="true"` and unknown `future="retain"` records. This is a policy conflict
to qualify independently, not authorization to replace the full-save contract.

A new registered native probe preserves the existing failed full-save result
and observes the real filtered writer-port batch, then verifies the separate
semantic candidate is the unchanged complete image. No assertion runs inside
a caught writer callback. The probe itself remains unexecuted locally.

Full-state admission, onboarding Finish, the LLM detached configuration builder,
actual menu persistence and installed-driver restart remain qualification or
implementation work. TODO42 must remain partial until those requirements are
resolved and the Windows behavior is actually qualified.

## Review and application

Use the patch and hash manifest as the authoritative frozen inputs; scratch
text drafts are not application artifacts. Check every exact preimage against
the current branch, independently review semantic destination and physical
ownership, then apply through the root's owned integration process. Native CI
must preserve every original assertion and let manually dispatched validation
finish without releasing anything.
