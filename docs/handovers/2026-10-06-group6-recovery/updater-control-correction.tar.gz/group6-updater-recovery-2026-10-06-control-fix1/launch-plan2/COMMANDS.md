<!-- group6-native-updater-96-validation-source-plan2/COMMANDS.md -->

# Frozen controlled-model launch

Status: source only. Delimiter-only correction0a9d8e5c is source-ACKed; first importFAIL/zero executed cases remains preserved in qualification1. The scripts were authored and hashed without parsing or
running Lua, importing a model, preparing a snapshot or launching a test. Wait
for the root's explicit exclusive-slot grant and completion of its current gate.
`LAUNCH-PLAN.json` binds the exact96 normal-framework cases and actual binary
paths. `SCRIPT-BINDINGS.json` binds this launcher's source.

Use a new private destination; these commands refuse occupied snapshots and
existing logs/results. Do not pass `--help` to a runner. Capture setup/command
errors separately from test failures, and never relaunch over an earlier receipt.

```bash
source /workspace/ergopti-env.sh
python3 /workspace/scratch/group6-native-updater-96-validation-source-plan2/prepare_snapshot.py /workspace/scratch/group6-native-updater-96-qualification2
python3 /workspace/scratch/group6-native-updater-96-validation-source-plan2/run_sequence.py /workspace/scratch/group6-native-updater-96-qualification2 candidate
```

The candidate launcher verifies every source, control and actual interpreter
binding before execution. Each module runs in its own process with the genuine
Linux helpers and additive checked manifest. It executes production22,
installer45 and registry29 on LuaJIT, then the same sequence on Lua5.4. It stops
at the first candidate failure and records all remaining modules as NOT EXECUTED.
It performs no native/full/JS/GUI suite or build.

After all96 candidate cases pass on each ABI, and only while the same exclusive
slot remains explicitly available:

```bash
python3 /workspace/scratch/group6-native-updater-96-validation-source-plan2/run_sequence.py /workspace/scratch/group6-native-updater-96-qualification2 predecessor
```

This second command retains every original control/oracle and records direct
predecessor statuses without stopping after expected failures. Production uses
exact managerc34/transfer93b and installer980. Installer uses exact980 and all
unchanged revision4 shared/caller sources. Registry uses exactbeb3 with its old
ade35 embedded feeder. No source expectations are derived from the candidate.

The known-refusal8 predecessor cases may fail at construction because980 lacks
the new cleanup-operation contract. Report that control point honestly; do not
count all8 as distinct causally exercised lifetime bugs. The actual coupled
manager/installer case independently reaches the original pre-reader receiving
path. The old22 publication/admission cases must be classified individually from
their actual trace. Registry29 and the unchanged37 install controls are expected
to preserve their old behavior; their baseline outcomes are regression evidence,
not proof of a change they do not exercise.

`SOURCE-BINDINGS.json` records before/after-equal root snapshot sources, immutable
candidate/predecessor inventories and byte comparisons of all37 old control
files plus the entire original8 manager case region. `RESULT-candidate.json`
and `RESULT-predecessor.json` preserve exact commands, exit statuses, logs,
executed counts, zero intended skips and import/floor failures. Both are private
captured evidence, not driver/native acceptance.

Stop and notify the root on an unexpected candidate failure. Keep its source,
logs and partial counts immutable, release the slot only when the launched
command has actually returned, then source-review any fixture correction before
a new destination/rerun. No assertion, expected value, source ownership predicate
or floor may be weakened. No root files, Git, CI or generated artifacts are
changed by this launcher. An original full-suite floor and physical native
pipeline/packaging acceptance remain separate required qualifications.
