# Frozen Windows Ollama preparation for PC continuation

The user explicitly stopped new Windows implementation/testing and deferred
Windows dependencies to their PC. These sources are inactive preparations.
None are adopted into the Windows driver. No native Windows result is claimed.

## Preserve these packet files

The root-level candidate and `versions/file-port-v1` preserve the original
source/hashes. `versions/file-port-v2` preserves the extraction identity WAL,
25 native cases and actual AST-only receipts. `versions/file-port-v3` is the
latest unreviewed preparation; its `PREIMAGE-SNAPSHOT.json` binds v2 source
preimages and `FROZEN-SNAPSHOT.json` binds every latest source/fixture byte.

Latest source and prospective driver path under
`static/ergopti_plus/windows/`:

| Packet file in v3 | Prospective driver path | Status |
| --- | --- | --- |
| `ollama_managed_files.ps1` | `modules/llm/ollama_managed_files.ps1` | Extraction/source/WAL helper; latest directory identity changes unreviewed. |
| `ollama_install_files_port.ahk` | `modules/llm/ollama_install_files_port.ahk` | Latest bounded claim/captured authorization changes unreviewed; native construction binding absent. |
| `ollama_native_source.ps1` | `modules/llm/ollama_native_source.ps1` | New captured-code byte import; unreviewed, unparsed, unexecuted. |
| `ollama_download_archive.ps1` | `modules/llm/ollama_download_archive.ps1` | New finite HTTPS archive streamer; unreviewed, unparsed, unexecuted. |
| `ollama_runtime_owner.ahk` | `modules/llm/ollama_runtime_owner.ahk` | Earlier exact foreground task/physical observer draft; construction gap remains. |
| `ollama-runtime-launch.ps1` | `modules/llm/ollama-runtime-launch.ps1` | Earlier foreground CLI launcher; no native launch ran. |
| `test_ollama_install_files.ps1` | `tests/unit/test_ollama_install_files.ps1` | 25 native cases authored, none executed or registered. |
| `fixtures/*` | `tests/fixtures/ollama-install-files/*` | Ten inert independent ZIPs, literal payloads/receipts and their authoring script. |

Retain `PLAN.md`, `FILE-PORT-CONTRACT.md`, `WAL-CHANGES.md`, parser commands and
receipts, all snapshots, and the independent review findings. Prospective
production paths are new; verify their absence/preimages against current dev
before adoption. No shared pin, menu, configuration, adapter or registration
changes are included. Existing production owner changes from other groups must
be preserved and coordinated.

## Evidence that actually exists

- Ten tiny inert ZIP fixtures were authored; no payload was executed.
- The original 20 cases remain intact; v2 adds five partial creation/WAL cases.
  All 25 Windows cases are unexecuted. No native fixture suite ran.
- Official portable PowerShell Core 7.4.13 on Linux parsed v2 helper, test and
  runtime launcher: three ASTs, zero diagnostics, unchanged source hashes.
  First startup exited 134 due to a read-only XDG cache; existing onboarding
  activation corrected it. Both successful parser receipts and raw commands
  remain saved. No dot-source, Add-Type or Win32 API executed.
- These v2 receipts are not v3 parse results. No v3 source was parsed or run.
- Parent official archive metadata records a complete verified ARM64 ZIP and
  only a bounded AMD64 central-directory tail. Preserve the small receipts and
  `windows-arm64-cli-imports.json`; do not commit the downloaded archive binary.
  Direct ARM64 imports show Universal CRT API sets/KERNEL32/ADVAPI32, without
  direct VCRUNTIME/MSVCP/delay imports. Dynamic dependencies/startup remain
  unqualified. Never execute bundled vc_redist under the no-admin requirement.

## Review blockers and source delta

Independent `native_setup` source review of v2 found:

1. Child directory paths lacked originating identities. Fresh private
   replacements containing the original moved files could be adopted/deleted.
2. AHK check/claim was not atomic with Critical disabled, permitting an
   interrupted acquisition to overwrite another retained owner.
3. Authorization read the mutable caller map after captured admission, rather
   than its captured clone.
4. Archive namespace preflight omitted regular-file ancestor/prefix collisions
   and descendants of reserved private receipt roots. Such entries could create
   malformed duplicate-kind WAL records after acquisition.

V3 prepares source changes for 1–3 only: exact directory identities in the hashed
manifest and comparison after acquisition; brief Critical atomic claim; captured
authorize callback. None are reviewed, parsed or tested, and their causal tests
are not yet authored. Blocker 4 remains unresolved. Preserve these differences
as proposals; do not label them validated fixes or integrated functionality.

## Resume on Windows

1. Read current instructions, memory, TODO48, latest dev and independent review.
   Recheck source ownership/preimages before editing or registering anything.
2. Finish all namespace/prefix/implicit-directory/reserved-receipt preflight
   before stage/WAL creation. Add independent inert fixtures and causal tests.
3. Independently review v3 directory/claim/authorization changes and add causal
   cases that preserve moved original file IDs, force interrupted acquisition,
   and mutate the original authorization map during admission.
4. Parse using actual Windows PowerShell 5.1 and the real AHK toolchain, then
   register/run actual native tests. Qualify DACLs, all native identity/rename/
   disposition layouts, missing-path classification, partial/crash/deletion
   retry and foreign/reparse refusal. AST-only Linux parsing is insufficient.
5. Obtain Group 3's actual optional construction ownership API before wiring
   task consumers. Saved source at published 1b3f5c still has seven arguments;
   the saved issue comment supplies no callable construction receipt signature.
   Never invent an eighth argument or infer settlement from empty task state.
6. Review and test the finite downloader: proxy/TLS/redirect behavior, exact
   long stream length/digest, truncation/status/timeout/oversize/source drift,
   physical worker and private file retirement. Ordinary CurlAsyncRequest's
   8 MiB cap remains unchanged. There are no downloader regression cases yet.
7. Implement native host architecture/runtime resolver, immutable version
   loading lease and actual private foreground service readiness. No resolver
   source was written before the stop. Coordinate explicit no-deadline daemon
   mode with the shared worker owner; its published API requires positive
   timeout. No daemon extension is integrated.
8. Compose shared consent/source/endpoint/model/menu/lifecycle owners only after
   producer contracts settle. Start/install does not enable the master AI switch;
   model installation requires its own explicit consent. Never kill external
   Ollama or install VC/admin prerequisites automatically.
9. Complete actual unit/E2E, packaging, per-user installation/restart and
   physical service/model behavior on affected OSes. Keep TODO48 until its full
   requirements pass. These sources alone finish no TODO item.
