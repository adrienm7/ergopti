// Tests/ErgoptiPlusTests/ManagedHTTPWPADWireTests.swift
// Injected native DHCP metadata joins actual CFNetwork PAC fetch and NSURLSession.

import CFNetwork
import Foundation
import XCTest
@testable import ErgoptiPlus

/// Closed observations from the original completed frames; no request is replayed.
enum ManagedWPADFailureDiagnostic {
	static func project(_ frames: [(UInt8, Data)]) -> (reason: String, stage: String) {
		guard frames.filter({ $0.0 == 67 }).count == 1,
			let last = frames.last, last.0 == 67, last.1.count <= 65_536,
			let fields = (try? JSONSerialization.jsonObject(with: last.1)) as? [String: Any],
			let version = fields["version"] as? NSNumber,
			CFGetTypeID(version) != CFBooleanGetTypeID(), version.doubleValue == 1,
			let reason = fields["reason"] as? String,
			["complete", "deadline", "cancelled", "offline", "certificate", "connect", "proxy", "unavailable"].contains(reason)
		else { return ("unknown", "unknown") }
		guard let name = fields["native_refusal_stage"] as? String,
			let stage = ManagedHTTPFailureStage(rawValue: name), stage.permits(reason: reason)
		else { return (reason, "unknown") }
		return (reason, stage.rawValue)
	}

	static func format(_ frames: [(UInt8, Data)]) -> String {
		let fact = project(frames)
		return "# native_http_wpad_failure reason=\(fact.reason) stage=\(fact.stage)"
	}
}

final class ManagedHTTPWPADWireTests: XCTestCase {
	/// Provider injection qualifies the receiving boundary, while acquiring
	/// actual customer DHCP/DNS settings remains a separate device check.
	func testDHCPMetadataOwnsRealPACURLRoutesAndRefusesInvalidDiscoveryBeforeNetwork() throws {
		let fixture = try ManagedWireFixture()
		defer {
			do { try fixture.close() }
			catch { XCTFail("WPAD receiving fixture did not restore owned trust and private keychain") }
		}
		let host = try XCTUnwrap(fixture.profile["host"] as? String)
		let port = try XCTUnwrap(fixture.profile["origin_port"] as? Int)
		let ports = try XCTUnwrap(fixture.profile["ports"] as? [String: Int])
		let refused = try XCTUnwrap(ports["refused"])
		let pacURL = try XCTUnwrap(fixture.profile["pac_url"] as? String)
		let settings: [String: Any] = [kCFNetworkProxiesProxyAutoDiscoveryEnable as String: 1,
			kCFNetworkProxiesHTTPSEnable as String: 1, kCFNetworkProxiesHTTPSProxy as String: "127.0.0.1",
			kCFNetworkProxiesHTTPSPort as String: refused]

		func execute(_ path: String, metadata: ManagedWPADMetadata, expired: Bool = false) throws -> (Int32, [(UInt8, Data)], Int) {
			let fields: [String: Any] = ["version": 1, "url": "https://\(host):\(port)\(path)",
				"method": "GET", "headers": [["Accept-Encoding", "identity"]],
				"timeout": 20, "idle_timeout": 10, "direct": false]
			let request = try XCTUnwrap(ManagedHTTPRequest.parse(JSONSerialization.data(withJSONObject: fields)))
			let collector = ManagedWireFrames()
			var reads = 0
			let status = ManagedHTTPWorker.execute(request, maximumSelections: 128,
				started: ProcessInfo.processInfo.systemUptime - (expired ? 21 : 0),
				settingsProvider: { settings as CFDictionary },
				discoveryMetadataProvider: { reads += 1; return metadata }, output: collector.append)
			return (status, try collector.frames(), reads)
		}

		func terminal(_ frames: [(UInt8, Data)]) throws -> [String: Any] {
			XCTAssertEqual(frames.filter { $0.0 == 67 }.count, 1)
			let last = try XCTUnwrap(frames.last)
			XCTAssertEqual(last.0, 67)
			return try XCTUnwrap(JSONSerialization.jsonObject(with: last.1) as? [String: Any])
		}

		for metadata in [ManagedWPADMetadata(dhcpOption: nil, searchDomains: []),
			ManagedWPADMetadata(dhcpOption: Data("https://reserved:credential@pac.example/a".utf8), searchDomains: ["corp"])] {
			let result = try execute("/alpha?case=one", metadata: metadata)
			XCTAssertEqual(result.0, 78)
			XCTAssertEqual(result.2, 1)
			XCTAssertEqual(try terminal(result.1)["reason"] as? String, "unavailable")
			XCTAssertFalse(result.1.contains { $0.0 == 72 || $0.0 == 68 })
		}
		let metadata = ManagedWPADMetadata(dhcpOption: Data(pacURL.utf8), searchDomains: ["corp"])
		let expired = try execute("/alpha?case=one", metadata: metadata, expired: true)
		XCTAssertEqual(expired.0, 75)
		XCTAssertEqual(expired.2, 0, "Expired original budget refuses before even reading discovery metadata")
		XCTAssertEqual(try terminal(expired.1)["reason"] as? String, "deadline")
		let before = try fixture.command(["command": "stats"])
		XCTAssertEqual((before["records"] as? [[String: Any]])?.count, 0,
			"Invalid discovery never falls back to DIRECT or the configured fixed relay")
		XCTAssertEqual(before["active"] as? Int, 0)

		XCTAssertEqual(try fixture.command(["command": "trust", "enabled": true])["trusted"] as? Bool, true)
		for path in ["/alpha?case=one", "/beta?case=two"] {
			let result = try execute(path, metadata: metadata)
			if result.0 != 0 {
				// Inspect the original completed request only; never echo unknown frame data.
				print(ManagedWPADFailureDiagnostic.format(result.1))
			}
			XCTAssertEqual(result.0, 0)
			XCTAssertEqual(result.2, 1)
			XCTAssertEqual(try terminal(result.1)["success"] as? Bool, true)
			XCTAssertEqual(result.1.filter { $0.0 == 72 }.count, 1)
			let body = result.1.filter { $0.0 == 68 }.reduce(into: Data()) { $0.append($1.1) }
			XCTAssertEqual(body, Data([111, 119, 110, 101, 100, 0, 110, 97, 116, 105, 118, 101, 255, 119, 105, 114, 101]))
			XCTAssertEqual(try fixture.command(["command": "stats"])["active"] as? Int, 0)
		}
		let final = try fixture.command(["command": "stats"])
		let records = try XCTUnwrap(final["records"] as? [[String: Any]])
		let origins = records.filter { $0["event"] as? String == "origin" }
		XCTAssertEqual(origins.map { $0["path"] as? String }, ["/alpha?case=one", "/beta?case=two"])
		XCTAssertEqual(origins.map { $0["route"] as? String }, ["first", "second"])
		XCTAssertEqual(records.filter { $0["event"] as? String == "connect" }.count, 2)
		try fixture.close()
	}
}

// Pure frame diagnostics remain independent of the native WPAD receiving case.
final class ManagedWPADFailureDiagnosticTests: XCTestCase {
	private func terminal(_ fields: [String: Any]) throws -> (UInt8, Data) {
		return (67, try JSONSerialization.data(withJSONObject: fields))
	}

	func testKnownStagesHaveIndependentExactFormattedOutputs() throws {
		XCTAssertEqual(ManagedHTTPFailureStage.certificateLoad.rawValue, "native_certificate_load")
		XCTAssertEqual(ManagedHTTPFailureStage.sessionTerminal.rawValue, "native_session_terminal")
		XCTAssertTrue(ManagedHTTPFailureStage.certificateLoad.permits(reason: "certificate"))
		XCTAssertTrue(ManagedHTTPFailureStage.sessionTerminal.permits(reason: "certificate"))
		let load = try terminal(["version": 1, "reason": "certificate",
			"native_refusal_stage": "native_certificate_load"])
		let session = try terminal(["version": 1, "reason": "certificate",
			"native_refusal_stage": "native_session_terminal"])
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([load]),
			"# native_http_wpad_failure reason=certificate stage=native_certificate_load")
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([session]),
			"# native_http_wpad_failure reason=certificate stage=native_session_terminal")
		let loadFact = ManagedWPADFailureDiagnostic.project([load])
		XCTAssertEqual(loadFact.reason, "certificate")
		XCTAssertEqual(loadFact.stage, "native_certificate_load")
		let sessionFact = ManagedWPADFailureDiagnostic.project([session])
		XCTAssertEqual(sessionFact.reason, "certificate")
		XCTAssertEqual(sessionFact.stage, "native_session_terminal")
	}

	func testMissingUnknownAndIncompatibleStagesPreserveOnlyKnownReason() throws {
		let missing = try terminal(["version": 1, "reason": "certificate"])
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([missing]),
			"# native_http_wpad_failure reason=certificate stage=unknown")
		let stages: [Any] = [NSNull(), 7, ["private-stage-canary"], "private-stage-canary",
			"native_policy_load"]
		for stage in stages {
			let frame = try terminal(["version": 1, "reason": "certificate",
				"native_refusal_stage": stage])
			XCTAssertEqual(ManagedWPADFailureDiagnostic.format([frame]),
				"# native_http_wpad_failure reason=certificate stage=unknown")
			let fact = ManagedWPADFailureDiagnostic.project([frame])
			XCTAssertEqual(fact.reason, "certificate")
			XCTAssertEqual(fact.stage, "unknown")
		}
		XCTAssertFalse(ManagedHTTPFailureStage.policyLoad.permits(reason: "certificate"))
	}

	func testBooleanMissingAndMalformedVersionOrJSONRefuseAllLabels() throws {
		let versions: [Any] = [true, false, 2, "1", NSNull()]
		for version in versions {
			let frame = try terminal(["version": version, "reason": "certificate",
				"native_refusal_stage": "native_certificate_load"])
			XCTAssertEqual(ManagedWPADFailureDiagnostic.format([frame]),
				"# native_http_wpad_failure reason=unknown stage=unknown")
		}
		let missing = try terminal(["reason": "certificate",
			"native_refusal_stage": "native_certificate_load"])
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([missing]),
			"# native_http_wpad_failure reason=unknown stage=unknown")
		for bytes in [Data(), Data("private-invalid-json-canary".utf8), Data("[]".utf8),
			Data("\"private-scalar-canary\"".utf8)] {
			XCTAssertEqual(ManagedWPADFailureDiagnostic.format([(67, bytes)]),
				"# native_http_wpad_failure reason=unknown stage=unknown")
		}
	}

	func testDuplicateLateOrAbsentTerminalRefusesAllLabels() throws {
		let frame = try terminal(["version": 1, "reason": "certificate",
			"native_refusal_stage": "native_certificate_load"])
		let header: (UInt8, Data) = (72, Data("private-header-canary".utf8))
		let body: (UInt8, Data) = (68, Data("private-body-canary".utf8))
		for frames in [[frame, frame], [frame, header], [frame, body], [header, body], []] {
			XCTAssertEqual(ManagedWPADFailureDiagnostic.format(frames),
				"# native_http_wpad_failure reason=unknown stage=unknown")
			let fact = ManagedWPADFailureDiagnostic.project(frames)
			XCTAssertEqual(fact.reason, "unknown")
			XCTAssertEqual(fact.stage, "unknown")
		}
	}

	func testExactTerminalBoundAdmitsWhileOneExtraByteRefuses() throws {
		let prefix = "{\"version\":1,\"reason\":\"certificate\",\"native_refusal_stage\":\"native_certificate_load\",\"private\":\""
		let suffix = "\"}"
		let padding = String(repeating: "x", count: 65_536 - prefix.utf8.count - suffix.utf8.count)
		let bounded = Data((prefix + padding + suffix).utf8)
		XCTAssertEqual(bounded.count, 65_536)
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([(67, bounded)]),
			"# native_http_wpad_failure reason=certificate stage=native_certificate_load")
		var oversized = bounded
		oversized.append(32)
		XCTAssertEqual(oversized.count, 65_537)
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([(67, oversized)]),
			"# native_http_wpad_failure reason=unknown stage=unknown")
	}

	func testPrivateFieldsHeadersAndBodiesNeverEnterTheFormattedOutput() throws {
		let frame = try terminal(["version": 1, "reason": "certificate",
			"native_refusal_stage": "native_certificate_load",
			"private": "https://private-user:private-password@private-host.invalid/secret",
			"userInfo": ["subject": "private-certificate-subject-canary"]])
		let frames: [(UInt8, Data)] = [(72, Data("private-header-canary".utf8)),
			(68, Data("private-body-canary".utf8)), frame]
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format(frames),
			"# native_http_wpad_failure reason=certificate stage=native_certificate_load")
		let fact = ManagedWPADFailureDiagnostic.project(frames)
		XCTAssertEqual(fact.reason, "certificate")
		XCTAssertEqual(fact.stage, "native_certificate_load")
	}

	func testPrivateReasonOrStageIsReplacedByClosedUnknownLabel() throws {
		let reason = try terminal(["version": 1, "reason": "private-reason-canary",
			"native_refusal_stage": "native_certificate_load"])
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([reason]),
			"# native_http_wpad_failure reason=unknown stage=unknown")
		let stage = try terminal(["version": 1, "reason": "certificate",
			"native_refusal_stage": "private-stage-canary"])
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([stage]),
			"# native_http_wpad_failure reason=certificate stage=unknown")
		let malformed = try terminal(["version": 1, "reason": ["private-reason-canary"],
			"native_refusal_stage": "native_certificate_load"])
		XCTAssertEqual(ManagedWPADFailureDiagnostic.format([malformed]),
			"# native_http_wpad_failure reason=unknown stage=unknown")
	}
}
