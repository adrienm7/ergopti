import os,sys,subprocess,json,hashlib,importlib.util,tempfile,shutil,datetime
from pathlib import Path
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-cloner-i18n');driver=w/'static/ergopti_plus/macos';shared=w/'static/ergopti_plus/_shared';d=Path('/workspace/scratch/oct28-updater');out=d/'current-dev-baseline';out.mkdir();source=driver/'modules/updater/release_installer.lua';before=hashlib.sha256(source.read_bytes()).hexdigest()
def load(n,p):
 spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
physical=load('physical_old8',d/'baseline-probe/old8-physical.py');arming=load('current_arming',driver/'tests/support/modules/updater/release_arming_fixture.py');capture=arming.CAPTURE.split('installer._getenv=',1)[0]+'\nio.write(installer.SWAP_SCRIPT)\n';e=dict(os.environ,USER='agent',LOGNAME='agent');e['PATH']='/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:'+e['PATH'];actual=subprocess.check_output(['/workspace/toolchain/bin/lua','-',str(driver),str(shared),'','','',''],input=capture.encode(),env=e);program=actual.decode();assert program==physical.extract_program(source.read_text());(out/'actual-current-dev-SWAP.sh').write_bytes(actual)
external=Path(tempfile.mkdtemp(prefix='oct28-updater-',dir='/dev/shm'));external.chmod(0o700);assert out.stat().st_dev!=external.stat().st_dev
try:
 row=physical.execute_case(program,'actual-current-dev-cross-device',out,external,False,256)
 assert row['exit_code']==6 and row['arming_observed'] and row['app_marker']=='chosen' and row['previous_marker'] is None and row['nested_previous_marker']=='installed' and row['opened']==row['app_path']+'\n',row
 assert before==hashlib.sha256(source.read_bytes()).hexdigest()
 receipt={'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'source_sha256':before,'actual_lua_program_sha256':hashlib.sha256(actual).hexdigest(),'actual_lua_matches_strict_parser':True,'bug':'Actual current-dev cross-filesystem copy leaves partial app; rollback nests original then falsely reports restored and opens partial app','case':row,'scope':'Real Linux filesystem and mv/RLIMIT_FSIZE, no Darwin claim; exact original Lua-emitted SWAP no business-logic mutant, opener records only.'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
finally:shutil.rmtree(external)
