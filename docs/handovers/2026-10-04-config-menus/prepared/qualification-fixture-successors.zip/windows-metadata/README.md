# Windows personal opening-source metadata fixture repair

## Failure and cause

Manual CI 37276807199 tested projection ab142045e4c3460ad184ddf8c1ca09482fa835a7
of source a550193ebc31aa819c369f701a61ebed72d86216. Its actual Windows unit
suite reported 9,164 passed and 25 failed. The bounded subject failure was
`personal-opening-source: own image preserves all four file and section metadata
neighbors`: `Item has no value` at the original native fixture line 948.

The initial `WritePersonalToml(_PTIOCR_Model("seed"))` has no prior overrides.
The real writer emits `[_meta]`, `[_meta.sections]`, and `[[alpha]]`/`[[beta]]`.
It emits `[_meta.sections.alpha]` only when an existing override map is nonempty.
The original fixture tries to insert four section metadata records by replacing
that absent override header, silently matching zero times. The final preservation
assertions then dereference section overrides that were never seeded.

The patch inserts the independently written section metadata before the actual
`[[alpha]]` anchor, retaining that anchor and every original expected literal.
Both file and section replacements expose their match counts and refuse fixture
construction unless each finds its one intended anchor. No production writer
changes and no weakened final assertions are included.

## Frozen scope and receipts

- `manifest.json` records exact preimage, postimage, patch hashes and byte identity
  against original dev 3b4afeba128bdcf9fb1155754742792c95f250fc.
- `before.ahk`/`after.ahk` retain UTF-8 BOM and LF.
- All 151 original assertion statements remain literally identical, including
  both maps that enumerate the four file and four section metadata expectations.
- Isolated `git apply --check` and application passed; resulting bytes match
  `after.ahk` exactly. The repository checkout, index, refs and CI were untouched.
- `static-mechanism-receipt.json` labels a source-derived construction exercise:
  original anchor counts 1/0, revised counts 1/1, four section literals present,
  both entry headers retained. It is not a run of AutoHotkey or its native parser.
- `verify-change-selection.json` records the actual gate selector's required
  AHK encoding and AHK native suite gates. Selecting gates does not run them.

## Required native qualification

AutoHotkey/Windows execution is unavailable in this Linux container. The native
Windows unit suite remains unexecuted for this frozen patch and must qualify the
real metadata capture, transactional save, all eight values, BOM/source image,
and updated live beta entry. The earlier CI failure is actual native evidence;
the static mechanism exercise is only diagnosis and patch-construction evidence.

The fixture's latest upstream edits were 2476b0b2a432599617712c483f0f84ae9b1dad89
and b6281d6fc5ead71de5c2b5f773762741034cc821. These predate the integrated
source and already contained this absent-anchor seed problem.
