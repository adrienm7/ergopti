from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/unit/modules/hotstrings/personal/test_personal_info_unreadable_never_persisted.ahk')
s=p.read_text(encoding='utf-8-sig');start=s.index('_PIU_UnreadableReadBlocksTheWrite() {');end=s.index('\n}\n',start)+2;body=s[start:end]
old='Threw := ""';assert body.count(old)==1;body=body.replace(old,old+', ContractThrew := false')
old='catch as Err {\n\t\tThrew := Err.Message';assert body.count(old)==1;body=body.replace(old,'catch as Err {\n\t\tContractThrew := true\n\t\tThrew := Err.Message')
old='Assert(Threw == "",';assert body.count(old)==1;body=body.replace(old,'Assert(!ContractThrew,')
s=s[:start]+body+s[end:];p.write_text(s,encoding='utf-8-sig',newline='\n')
