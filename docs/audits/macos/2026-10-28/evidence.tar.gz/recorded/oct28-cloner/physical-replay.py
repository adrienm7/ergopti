from pathlib import Path
import subprocess,os,json,sys,hashlib,datetime
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-picker-observer');root=Path('/workspace/scratch/oct28-cloner/physical-replay');root.mkdir(mode=0o700)
node='/workspace/toolchain/node-v22.22.2-linux-x64/bin/node';port=w/'tools/test/lib/app-cloner-native-stat-port.cjs';probe=w/'tools/test/lib/app-cloner-log-cleanup-probe.py';palette=w/'static/ergopti_plus/_shared/data/native_theme.toml';rows=[]
for version,source in [('old',Path('/workspace/scratch/oct28-cloner/04-fifth/resources')),('new',Path('/workspace/scratch/oct28-cloner/05-signal/resources'))]:
 for shell in ['/usr/bin/bash','/usr/bin/zsh']:
  case=root/(version+'-'+Path(shell).name);case.mkdir(mode=0o700)
  subprocess.run([node,'-e','require(process.argv[1]).createNativeStatResources({resources:process.argv[2],fixtureRoot:process.argv[3],toBashPath:x=>x})',str(port),str(source),str(case)],check=True,capture_output=True)
  env=dict(os.environ,REAL_PYTHON=sys.executable,OWNED_STAT_QUERY=str(case/'native-stat-query.py'),OWNED_STAT_FAULT='')
  result=subprocess.run([sys.executable,str(probe),'--resources',str(case/'native-stat-port-resources'),'--shell',shell,'--palette',str(palette),'--fixture',str(case/'cases')],env=env,capture_output=True,text=True,timeout=30)
  (case/'stdout.json').write_text(result.stdout);(case/'stderr.log').write_text(result.stderr);report=json.loads(result.stdout)
  assert len(report['cases'])==len({c['caller']+':'+c['mode'] for c in report['cases']})==18
  assert report['ownership_closed'] and all(c['ownership_closed'] for c in report['cases'])
  assert not result.stderr
  if version=='new':assert result.returncode==0 and not report['failures'],report
  else:
   assert result.returncode==1 and len(report['failures'])==(1 if shell.endswith('bash') else 13),report['failures']
  rows.append({'version':version,'shell':shell,'actual_exit':result.returncode,'cases':len(report['cases']),'failures':report['failures'],'ownership_closed':report['ownership_closed'],'report':str(case/'stdout.json'),'report_sha256':hashlib.sha256(result.stdout.encode()).hexdigest()})
receipt={'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_head':'74f683f5a6ad49a62e5dad8837b8375375a01d3c','rows':rows,'total_physical_cases':72,'native_darwin':'UNRUN Linux only; real zsh/bash and kernel quotas with explicit native command ports','scope':'Actual CLI prefixes/fullshortcut/cleanup API, exact roles retain execution_scope fields; no fullclone desktop launch claim'};(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
