import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

root = Path('/workspace/ergopti')
out = Path('/workspace/.ergopti-cloud')
log = out / 'resume-personal-topology-short-full-verify.log'
status = out / 'resume-personal-topology-short-full-status.json'
paths = [
    'static/ergopti_plus/linux/infra/file_watchers.lua',
    'static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua',
]


def snapshot():
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root, text=True),
        'sources': {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths},
        'index_tree': subprocess.check_output(['git', 'write-tree'], cwd=root, text=True).strip(),
    }


os.environ["TMPDIR"] = tempfile.mkdtemp(prefix="eg-", dir="/var/tmp")
os.environ["TEMP"] = os.environ["TMPDIR"]
before = snapshot()
receipt = {
    'status': 'RUNNING',
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command': ['node', 'tools/test/verify-change.cjs'],
    'cwd': str(root),
    'tmpdir': os.environ.get('TMPDIR'),
    'before': before,
}
status.write_text(json.dumps(receipt, indent=2) + '\n')
with log.open('wb') as stream:
    result = subprocess.run(receipt['command'], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
after = snapshot()
receipt.update({
    'status': 'TERMINAL',
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code': result.returncode,
    'after': after,
    'inputs_unchanged': before == after,
    'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
})
status.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode if before == after else 125)
