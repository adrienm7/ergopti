# Tap-Hold key-head current-source successor

This is an implementation packet, not integrated or natively qualified work.
Its parent is `6370e0d9344f1a94ce2caeddced4a0528ba93dfd`. The original frozen
packet SHA256 `98020999760ad87aaff015e82871635f0aac85a78ef99c894072801c6e71f93b`
is verified. The current source-only/generated successor SHA256 is
`b3ce412465b6b071106e63a50375bba66cfb9baea5d0c0a597c8c85dc661e4d1`.

`preimages-postimages.json` names exactly 16 owned source/test/artifact paths.
The old TODO hunk is deliberately excluded for current group-only composition.
Current Linux wizard validation and the network group's download owner remain
intact. Generated artifacts were recreated by `node tools/build/build-menu-manifest.js`
and `node tools/test/test-native-menu-rows.cjs --update-baseline`; repeated runs
are byte-identical. The census goes from96/153/97 to95/152/96, retiring exactly
one native separator site per driver. No new locale or schema key is added.

The shared template owns row order, platform labels, includes and literal current
captions; native providers retain callbacks and picker data. The new reader guard
follows includes only from literal driver-reader roots with an actual recursive
native consumer. It rejects reachable missing/cyclic edges. Historical field
checks, floors and group suffix handling remain. Six actual malformed graph and
consumer mutations fail; the six standalone helper assertions run normally.
All three old native test files remain byte-identical prefixes. The new shared
corpus is frozen independent input; formatting changes no decoded expectations.

Focused Linux runs pass24/0 on Lua5.4 and LuaJIT; supported macOS Lua5.4 passes17/0.
A macOS LuaJIT diagnostic fails0/17 because the existing macOS code requires Lua5.4
syntax/table.pack; it is not a supported runtime or acceptance check. Restoring
only three old native providers gives Linux21/3, macOS14/3 and actual manifest
JS exit1. The missing capability is independently exposed.

Manifest, parity, handler bijection, reader reachability, locale labels,
unavailability, census, portable AHK BOM/LF/static/registration and the archive's
repository format check pass. Existing label-coverage reporting still reports
105/110 missing translated labels; this bounded packet introduces no labels.
These local observations do not qualify Windows native execution, installed
Hammerspoon, E2E, packaging, installation or physical input. Full `verify-change`
and native affected-OS CI remain mandatory with the owning root workflow.
Physical Windows/macOS/Linux tray acceptance remains an explicit TODO step.
No TODO item is removed, no branch/index/ref was modified and no release runs.
