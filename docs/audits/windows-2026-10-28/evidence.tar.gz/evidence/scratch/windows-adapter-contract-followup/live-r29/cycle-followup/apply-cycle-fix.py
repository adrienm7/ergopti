from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/live/live_harness.ahk')
s=p.read_text(encoding='utf-8-sig')
old='\tif State.Done {\n\t\tSetTimer(State.Tick, 0)\n\t\treturn\n\t}\n'
new='\tif State.Done\n\t\treturn\n'
assert s.count(old)==1;s=s.replace(old,new)
old='\t\tState.Done := true\n\t\tSetTimer(State.Tick, 0)\n\t\treturn\n'
new='\t\tSetTimer(State.Tick, 0)\n\t\tState.Tick := 0\n\t\tState.Done := true\n\t\treturn\n'
assert s.count(old)==1;s=s.replace(old,new)
old='\t}\n\tState.Done := true\n}\n\n/** Waits for a LiveDriveWindow state'
new='\t}\n\tState.Tick := 0\n\tState.Done := true\n}\n\n/** Waits for a LiveDriveWindow state'
assert s.count(old)==1;s=s.replace(old,new)
p.write_text(s,encoding='utf-8-sig',newline='\n')
