// static/ergopti_plus/windows/native/key_combination_owner/pair_arbitration.h
/**
 * @file pair_arbitration.h
 * @brief Detached simultaneous-pair plans for a future single native owner.
 *
 * This pure reducer installs no hook, suppresses no edge, injects no output and
 * issues no native acknowledgement. Every input field is a caller-supplied fact,
 * not a capability. A future owner must independently admit facts, execute the
 * plan in order and retain real modifier/output/retirement debt. In particular,
 * committing a proposed logical state cannot acknowledge native retirement.
 */

#ifndef ERGOPTI_PAIR_ARBITRATION_H
#define ERGOPTI_PAIR_ARBITRATION_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Storage capacity only; no key catalogue, default or configuration lives here. */
#define ERGOPTI_PAIR_MAX_ROWS 256u
#define ERGOPTI_PAIR_STATE_INIT {0}

enum ErgoptiPair_Status {
	ERGOPTI_PAIR_OK = 0,
	ERGOPTI_PAIR_INVALID_ARGUMENT = -1,
	ERGOPTI_PAIR_INVALID_POLICY = -2,
	ERGOPTI_PAIR_NOT_INITIALIZED = -3,
	ERGOPTI_PAIR_ALREADY_INITIALIZED = -4
};

enum ErgoptiPair_Origin {
	ERGOPTI_PAIR_ORIGIN_UNKNOWN = 0,
	ERGOPTI_PAIR_ORIGIN_PHYSICAL = 1,
	ERGOPTI_PAIR_ORIGIN_ALTGR_CTRL = 2,
	ERGOPTI_PAIR_ORIGIN_INJECTED = 3
};

enum ErgoptiPair_InputKind {
	ERGOPTI_PAIR_DOWN = 1,
	ERGOPTI_PAIR_UP = 2,
	ERGOPTI_PAIR_REPEAT = 3,
	ERGOPTI_PAIR_CLOCK = 4,
	ERGOPTI_PAIR_CANCEL = 5
};

enum ErgoptiPair_Mode {
	ERGOPTI_PAIR_IDLE = 1,
	ERGOPTI_PAIR_WAITING = 2,
	ERGOPTI_PAIR_HELD_ALONE = 3,
	ERGOPTI_PAIR_CHORD = 4,
	ERGOPTI_PAIR_RETIRING = 5,
	ERGOPTI_PAIR_DISABLED = 6
};

enum ErgoptiPair_EventRoute {
	ERGOPTI_PAIR_NO_EVENT = 0,
	ERGOPTI_PAIR_PASS_ORIGINAL = 1,
	ERGOPTI_PAIR_BUFFER_PROPOSAL = 2,
	ERGOPTI_PAIR_RETAIN_PROPOSAL = 3
};

enum ErgoptiPair_Withdrawal {
	ERGOPTI_PAIR_WITHDRAW_NONE = 0,
	ERGOPTI_PAIR_WITHDRAW_CONTEXT = 1,
	ERGOPTI_PAIR_WITHDRAW_CLOCK = 2,
	ERGOPTI_PAIR_WITHDRAW_CANCEL = 3,
	ERGOPTI_PAIR_WITHDRAW_ORIGIN = 4,
	ERGOPTI_PAIR_WITHDRAW_SOURCE_GENERATION = 5,
	ERGOPTI_PAIR_WITHDRAW_PRESS_IDENTITY = 6
};

/**
 * One already compiled shared-policy row. Opaque IDs are caller-owned references.
 * action_id zero means the shared `none` value; no actions are declared here.
 * canonical_index identifies this row or its earlier reciprocal direction,
 * exactly as the supplied shared chord policy's catalogue-order canonical row.
 */
typedef struct ErgoptiPair_Row {
	uint32_t first_key;
	uint32_t second_key;
	uint32_t pair_id;
	uint32_t action_id;
	size_t canonical_index;
} ErgoptiPair_Row;

typedef struct ErgoptiPair_Policy {
	const ErgoptiPair_Row *rows;
	size_t row_count;
	double simultaneous_threshold_ms;
	bool symmetric;
	uint64_t revision;
} ErgoptiPair_Policy;

/** Source, policy, route and pause facts must come from the sole actual owner. */
typedef struct ErgoptiPair_Context {
	uint64_t owner_epoch;
	uint64_t policy_revision;
	uint64_t route_epoch;
	bool current;
	bool enabled;
	bool paused;
	/* Genuine original first-press availability, not inferred from this core. */
	bool first_available;
} ErgoptiPair_Context;

/**
 * at_ms is an integer monotonic millisecond observation. Identity survives its
 * matching repeat/up; it is not recreated from GetKeyState or current RAlt.
 * Raw fake-Ctrl classification belongs to the real owner before normalization.
 */
typedef struct ErgoptiPair_Input {
	enum ErgoptiPair_InputKind kind;
	enum ErgoptiPair_Origin origin;
	uint32_t key;
	uint64_t source;
	uint64_t generation;
	uint64_t press;
	uint64_t at_ms;
} ErgoptiPair_Input;

/* Caller storage, not an authorization token. After initialization, retain it
 * unchanged except through a reducer proposal or a complete value copy. */
typedef struct ErgoptiPair_State {
	bool initialized;
	enum ErgoptiPair_Mode mode;
	uint64_t owner_epoch;
	uint64_t route_epoch;
	uint64_t policy_revision;
	uint64_t last_at_ms;
	bool observed_time;
	double threshold_ms;
	bool symmetric;
	size_t row_count;
	ErgoptiPair_Row rows[ERGOPTI_PAIR_MAX_ROWS];
	ErgoptiPair_Input first;
	ErgoptiPair_Input second;
	bool first_down;
	bool second_down;
	enum ErgoptiPair_Withdrawal withdrawal;
} ErgoptiPair_State;

/**
 * Detached logical proposal. A flushed original down precedes the current
 * original event and keeps its original timestamp/identity. A selected chord
 * carries the actual press order separately from canonical pair/action IDs.
 * Retirement lists retained original down identities; it grants no replay,
 * release or drop authority. No finalization/ack factory exists in this API.
 */
typedef struct ErgoptiPair_Plan {
	enum ErgoptiPair_EventRoute current_route;
	bool flush_first;
	ErgoptiPair_Input original_first;
	bool selected;
	uint32_t pair_id;
	uint32_t action_id;
	ErgoptiPair_Input actual_first;
	ErgoptiPair_Input actual_second;
	bool requires_native_retirement;
	size_t retirement_count;
	ErgoptiPair_Input retirement_inputs[2];
	enum ErgoptiPair_Withdrawal withdrawal;
} ErgoptiPair_Plan;

/**
 * Initialize zero-initialized detached planning state exactly once. This does
 * not install or admit a native role; never discard an old owner's live debt to
 * substitute another logical state, including after context withdrawal.
 */
enum ErgoptiPair_Status ErgoptiPair_Initialize(
	ErgoptiPair_State *state, const ErgoptiPair_Policy *policy,
	const ErgoptiPair_Context *context);

/**
 * Produce a next-state proposal without changing previous. next may equal
 * previous. Invalid arguments leave both next and plan unchanged. Successful
 * returns mean only that a detached plan was computed, never native success.
 */
enum ErgoptiPair_Status ErgoptiPair_Reduce(
	const ErgoptiPair_State *previous, const ErgoptiPair_Context *context,
	const ErgoptiPair_Input *input, ErgoptiPair_State *next,
	ErgoptiPair_Plan *plan);

#endif
