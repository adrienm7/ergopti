"""Run the complete original module cohort unchanged; no targets patched."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

source,output=map(Path,sys.argv[1:])
spec=importlib.util.spec_from_file_location('private_full_facts',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
def subjects(tests):
 for item in tests:
  if isinstance(item,unittest.TestSuite):
   yield from subjects(item)
  else:
   yield item.id().split('.',1)[1]
selected=list(subjects(suite))
if len(selected)!=52 or len(set(selected))!=52:
 raise RuntimeError('Original full52 census refused')
result=unittest.TextTestRunner(verbosity=2).run(suite)
summary={'total':result.testsRun,'pass':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
 'fail':len(result.failures),'errors':len(result.errors),'skip':len(result.skipped),'selected':selected,
 'fail_names':[test.id().split('.',1)[1] for test,_ in result.failures],
 'error_names':[test.id().split('.',1)[1] for test,_ in result.errors],
 'native_swift_compile_or_certificate_cause_credit':False}
with output.open('x') as stream:
 stream.write(json.dumps(summary,indent=2,sort_keys=True)+'\n')
output.chmod(0o600)
raise SystemExit(0 if result.wasSuccessful() and result.testsRun==52 and not result.skipped else 1)
