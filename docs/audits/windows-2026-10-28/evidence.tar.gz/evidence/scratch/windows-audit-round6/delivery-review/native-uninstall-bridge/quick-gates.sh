set -euo pipefail
cd /workspace/ergopti-windows-r7-installer
pwd
node tools/test/verify-change.cjs --plan
node tools/test/test-ahk-encoding.cjs
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
git diff --check
