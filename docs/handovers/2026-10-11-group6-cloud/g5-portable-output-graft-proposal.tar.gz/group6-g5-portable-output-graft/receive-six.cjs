'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const { spawnSync } = require('node:child_process');
const target = path.resolve(process.argv[2]);
// Execute only the unchanged published six-control function. It reads the
// ACTUAL target-file loop via __filename, never a modeled replacement loop.
// This does not evaluate any earlier G5/native/cohort/default suite statement.
const declaration = fs.readFileSync(path.join(__dirname, 'control-addition.cjs'), 'utf8');
assert.ok(declaration.endsWith('\nreceivePortableFailureOutput();'));
const context = { fs, path, os, assert, require, process, spawnSync,
 __filename: target, __dirname: path.dirname(target) };
try {
 vm.runInNewContext(declaration, context, { filename: 'published-six-controls-reading-actual-target.cjs', timeout: 15000 });
 process.stdout.write('GRAFT_RECEIVING passed=6 failed=0 errors=0 skipped=0 native=false\n');
} catch (error) {
 process.stderr.write(error.stack + '\n');
 process.stderr.write(JSON.stringify({ code: error.code || null, operator: error.operator || null, actual: error.actual ?? null, expected: error.expected ?? null, native: false }) + '\n');
 process.exitCode = 1;
}
