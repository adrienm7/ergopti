'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const parser = require('/workspace/ergopti/node_modules/@babel/parser');
const root = __dirname;
const clean = (value) => {
 if (Array.isArray(value)) return value.map(clean);
 if (!value || typeof value !== 'object') return value;
 const result = {};
 for (const [key, entry] of Object.entries(value)) {
  if (!['start', 'end', 'loc', 'extra', 'leadingComments', 'trailingComments', 'innerComments', 'comments', 'tokens'].includes(key)) result[key] = clean(entry);
 }
 return result;
};
const parse = (source) => parser.parse(source, { sourceType: 'script' }).program;
const results = {};
for (const relative of ['tools/test/test-macos-swift-launcher-ci.cjs','tools/test/test-macos-dev-qualification-deferral.cjs']) {
 const before = parse(fs.readFileSync(path.join(root,'preimages',relative),'utf8'));
 const after = parse(fs.readFileSync(path.join(root,'candidate',relative),'utf8'));
 let removed = 0;
 if (relative.includes('swift-launcher')) {
  after.body = after.body.filter((node) => {
   const isNew = node.type === 'BlockStatement' && node.body.some((entry) => entry.type === 'VariableDeclaration' && entry.declarations.some((declaration) => declaration.id.name === 'sdk' && declaration.init.arguments?.[0]?.value === '../diagnostics/sdk_permission_xctest_evidence.cjs'));
   if (isNew) removed++;
   return !isNew;
  });
  assert.equal(removed,1);
 } else {
  after.body = after.body.filter((node) => {
   const isNew = node.type === 'FunctionDeclaration' && node.id.name === 'admitPermissionObservationSelector'
    || node.type === 'VariableDeclaration' && node.declarations.some((declaration) => ['PERMISSION_FILTER','PERMISSION_STEP_SOURCE'].includes(declaration.id.name));
   if (isNew) removed++;
   return !isNew;
  });
  assert.equal(removed,3);
  const walk = (node) => {
   if (!node || typeof node !== 'object') return;
   if (node.type === 'ReturnStatement' && node.argument?.type === 'CallExpression' && node.argument.callee.name === 'admitPermissionObservationSelector') {
    assert.equal(node.argument.arguments.length,1);
    node.argument = node.argument.arguments[0]; removed++;
   }
   for (const entry of Object.values(node)) {
    if (Array.isArray(entry)) entry.forEach(walk); else if (entry && typeof entry === 'object') walk(entry);
   }
  };
  walk(after); assert.equal(removed,4);
 }
 assert.deepEqual(clean(after),clean(before));
 results[relative] = { original_whole_module_AST_preserved:true, additive_nodes_or_wrapper_removed:removed };
}
const workflow = '.github/workflows/ci-macos.yml';
const old = fs.readFileSync(path.join(root,'preimages',workflow),'utf8');
const next = fs.readFileSync(path.join(root,'candidate',workflow),'utf8');
const step = fs.readFileSync(path.join(root,'observation-step.yml'),'utf8');
assert.equal(next.split(step).length,2);
const inverse = next.replace(step,'').replace('            ${{ runner.temp }}/swift-launcher-evidence/sdk-permission-*.json\n','').replace('            ${{ runner.temp }}/swift-launcher-evidence/sdk-permission-xctest.log\n','');
assert.equal(inverse,old);
results[workflow] = { original_workflow_inverse_byte_exact:true, original_item36_25_cohort_unchanged:true };
console.log(JSON.stringify(results,null,2));
