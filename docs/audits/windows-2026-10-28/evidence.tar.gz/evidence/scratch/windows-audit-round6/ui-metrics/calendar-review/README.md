# Calendar review receipt

Read-only audit of Windows metrics apps UI at commit 60f5eccbcc9ce950ddb128f977b548874ecb1193. No checkout source was edited. Proof command used the pinned Node environment and `node --single-threaded apia-red.cjs` and exited 0. The captured output is in apia-red-output.json; the actual loaded Windows HTML, host message callback, aggregation and display helpers were exercised through the existing browser-port test fixture.

## Confirmed failure

Under Pacific/Apia, selecting recorded key 2011-12-30 displays 31/12/2011 and aggregates both 2011-12-30 and 2011-12-31: 2 days and 6 chars. Expected: 30/12/2011, only key 2011-12-30, 1 day, 2 chars. No error is logged. Local Date construction normalizes the skipped local day to December 31; resetting hours cannot repair this collapse.

## Date-key domain evidence

- static/ergopti_plus/_shared/data/db/schema.sql:63-64 requires replay to reconstruct exact same rows on another machine.
- schema.sql:74-75 stores timestamps and denormalized date as TEXT, documented YYYY-MM-DD; no timezone, date cutoff or year range constraint applies.
- static/ergopti_plus/windows/modules/keystats/keystats_reader_manifest.ahk:16 describes canonical YYYY-MM-DD keys; these labels pass through.
- static/ergopti_plus/_shared/data/metrics_manifest_contract.json adds no date cutoff/range restriction.

Therefore archived keys from a different timezone remain meaningful, including 2011-12-30 while viewed in Apia. Calendar labels need Gregorian civil-day identity independent of viewer timezone.

## Complete calendar callsites

See source-callsites.txt for line-level source inventory. Coherent conversion touches helpers.js parseDateKey + formatDisplayDate; state.js selected anchor/period start plus weekday filter and by_weekday; main.js sorting and streak; charts.js ribbon, comparator and annual calendar.

Annual calendar requires converting actual local today to a civil-day ordinal once, then using UTC day shifts, weekday, key formatting, month labels and tooltip date fields throughout the loop. Otherwise Apia skips the archived day and local getters can shift UTC ordinal labels in negative-offset zones. main.js real-now todayDow intentionally remains local.

## Recommended minimal model and guards

Parse date-only ISO/French fields directly as UTC Gregorian day ordinals. Preserve accepted input shapes and invalid-input policy. Numeric epoch and fallback parsed instants retain existing LOCAL calendar-date meaning before encoding their local fields as UTC ordinals. Preserve raw recorded keys. Add shared ordinal shifting, ISO formatter and local-today encoder. Avoid elapsed-time tolerance or local midnight normalization as a substitute.

Keep physical DST controls independently using native Date constructors (23h/25h/24.5h), then separately assert ordinal civil-day adjacency. Existing parseDateKey physical-span assertions must be updated intentionally because its output now models calendar identity. Add Havana/Santiago streak and period checks; Apia selected-day, weekday, ribbon, annual calendar checks; and Los Angeles/Paris local-today checks around a UTC date boundary. Native OS execution is not claimed by these shared UI probes.
