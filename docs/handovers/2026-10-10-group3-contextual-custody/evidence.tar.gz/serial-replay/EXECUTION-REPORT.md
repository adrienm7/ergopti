# Recovered Linux contextual delivery replay

All 36 planned runs completed serially: LuaJIT first, then Lua 5.4. The orchestrator exited 0 with no unexpected results. Each ABI used the checked runner's independently frozen unique-name census and exact completed count. Required causal failure identities were frozen in `frozen-plan.json` before any Lua execution and all observed failure sets matched exactly.

| Scenario | LuaJIT passed / failed | Lua 5.4 passed / failed | Outcome |
| --- | --- | --- | --- |
| Original contextual source, 20 cases | 1 / 19 | 1 / 19 | Expected regression |
| Candidate contextual source, 20 cases | 20 / 0 | 20 / 0 | Passed |
| Remove late guard | 1 / 19 | 1 / 19 | Expected inverse failures |
| Keep stale admission after source | 17 / 3 | 17 / 3 | Expected inverse failures |
| Remove post-admission owner fence | 18 / 2 | 18 / 2 | Expected inverse failures |
| Remove post-decision owner fence | 19 / 1 | 19 / 1 | Expected inverse failure |
| Remove terminal owner fence | 19 / 1 | 19 / 1 | Expected inverse failure |
| Remove issuer pins | 16 / 4 | 16 / 4 | Expected inverse failures |
| Let selected-source exception escape | 19 / 1 | 19 / 1 | Expected inverse failure |
| Original editor cohort on original source | 14 / 0 | 14 / 0 | Passed |
| Original editor cohort on candidate source | 14 / 0 | 14 / 0 | Passed |
| Original owner cohort on original source | 3 / 0 | 3 / 0 | Passed |
| Original owner cohort on candidate source | 3 / 0 | 3 / 0 | Passed |

All five enrollment negative controls refused on both ABIs with process exit 1: zero selection, mistyped selector, missing selected case, foreign selected case and duplicate selected case. A missing case can have zero assertion failures while the runner still refuses its incomplete census; that is the intended protection. These controls are distinguished from product regressions and source inverse failures.

`execution/replay-receipt.json` retains every exact command, source/test hash, exit, raw stdout/stderr hash, selected/passed/failed name census and independent required failure set. The raw files remain under `execution/luajit/` and `execution/lua5.4/`. Version observations are retained as raw stdout/stderr without extra runtime invocations.

All 2,119 tracked preparation dependency hashes matched before and after replay. Canonical HEAD stayed `7892616a62d6925126d4ff98b4d4818eb387813b`. The original proposal's 24 seal members and all checked-runner packet members remain byte-exact. No canonical file, original assertion, generator, independent corpus or product capability was edited during replay.

Additive contextual cases, seven source inverses and three-owner cohorts have empty stderr. Each of the four paired editor runs has exactly four identical `Automatic startup requires an installed application.` stderr lines: 212 bytes, SHA256 `3a80b02ae1b72e213985374ee9da1847ba6ad9d3f89325f18d54a24e7deb79f7`. Those unchanged fixture refusals do not qualify native startup or installation. Mistyped-selector controls intentionally have native assertion tracebacks reporting the unknown cohort; their distinct raw stderr is retained, not treated as empty.

This closes the recovered component regression and checked enrollment evidence. Parent canonical selected gates and any required CI remain separate. Fake selected-source and executor seams are explicit original enrolled fixture boundaries; no physical keyboard, desktop, installed runtime, packaging or native output authority is qualified here. Old vanished logs remain unavailable and are not used as evidence.
