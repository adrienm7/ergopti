﻿; Shared test-owned logger directories; preserve assignment at the logger boundary.
global _LogsDir := A_Temp . "\ergopti_test_logs\ergopti_plus\"
global _DefaultLogsDir := _LogsDir
