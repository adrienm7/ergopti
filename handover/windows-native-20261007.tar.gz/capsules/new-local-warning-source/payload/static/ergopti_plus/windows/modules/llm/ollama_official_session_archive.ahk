﻿; modules/llm/ollama_official_session_archive.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Official Archive Session Factory
; DESCRIPTION:
; Constructs the provider only after the existing session consent/current gate.
; Native code pins remain the existing unique resident module's authority.
; ==============================================================================

/** Reuses one initialized bridge; an older partial/base initialization refuses. */
OllamaOfficialIntakeNative(Pins) {
	global _OllamaGuardianNativeOwners
	if !(Pins is Map) || !(Pins.Get("NativeModule", 0) is Map)
		throw TypeError("Official acquisition requires generated native image pins.")
	local key := Pins["NativeModule"].Get("path", "")
	if !_OllamaGuardianNativeOwners.Has(key)
		return OllamaIntakeNativePort(Pins)
	local native := _OllamaGuardianNativeOwners[key]
	if !(native is OllamaIntakeNativePort) || native.Phase != "ready" || native.Pins.Count != Pins.Count
		throw ValueError("The existing guardian initialization does not admit this intake ABI.")
	for official_pin_role, pin in Pins {
		if !(pin is Map) || !(native.Pins.Get(official_pin_role, 0) is Map)
			throw ValueError("An active native image role cannot be replaced.")
		for official_pin_field in ["path", "bytes", "sha256"]
			if Type(pin.Get(official_pin_field, 0)) != Type(native.Pins[official_pin_role].Get(official_pin_field, 0))
					|| !(pin.Get(official_pin_field, 0) == native.Pins[official_pin_role].Get(official_pin_field, 0))
				throw ValueError("An active native image differs from its captured generated pin.")
	}
	return native
}

/** Builds one genuine intake/provider; no process starts in this constructor. */
OllamaOfficialSessionArchive(Files, RuntimeOptions, Current, OnPrepared, PollMilliseconds, Deadline, Version, AssetId) {
	if !(Files is OllamaManagedFilesDefault) || !(RuntimeOptions is Map)
			|| !HasMethod(Current, "Call") || !HasMethod(OnPrepared, "Call")
			|| !(PollMilliseconds is Integer) || PollMilliseconds <= 0 || !(Deadline is Integer) || Deadline <= A_TickCount
			|| !(RuntimeOptions.Get("source_capture_bytes", 0) is Integer) || RuntimeOptions["source_capture_bytes"] <= 0
			|| !RegExMatch(RuntimeOptions.Get("powershell", ""), "\A[A-Za-z]:\\")
		throw TypeError("Official archive construction requires captured native source policies.")
	local asset := OllamaReleaseWindowsAsset(AssetId), projection := OllamaManagedPinProjection(Files.Pins)
	if !(asset["version"] == Version)
		throw ValueError("Official archive construction belongs to another canonical release.")
	local native := OllamaOfficialIntakeNative(projection["native"])
	local intake := OllamaArchiveIntake(Files, native, Map("poll_ms", PollMilliseconds,
		"capture_bytes", RuntimeOptions["source_capture_bytes"], "archive_bytes", asset["bytes"],
		"powershell", RuntimeOptions["powershell"]), Current, OnPrepared)
	return OllamaOfficialArchiveProvider(intake, Map("poll_ms", PollMilliseconds), Current, OnPrepared)
}
