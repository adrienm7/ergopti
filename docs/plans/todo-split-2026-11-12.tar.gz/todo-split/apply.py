"""Clean TODO.md (drop finished items) and move the hardware checks to one file per OS.

Usage: python3 -I apply.py <repo_root> [base_commit]

base_commit is the dev commit before the cleanup (default: HEAD of repo_root); TODO.md
points to `git show <base>:TODO.md` for the long form. Re-runnable on a newer dev: the
decisions (decisions.tsv) and the residual open lines (residual.tsv) are keyed by the exact
first line of each [x] item; an [x] item without a decision is dropped and listed, and a
residual whose item is gone is listed, so new items can be judged by hand.
"""
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from todo_model import BOX, done_items, indent  # noqa: E402

ROOT = os.path.abspath(sys.argv[1])
BASE = sys.argv[2] if len(sys.argv) > 2 else subprocess.check_output(
    ['git', '-C', ROOT, 'rev-parse', '--short=10', 'HEAD'], text=True).strip()

HARDWARE = {
    '## To confirm on the Mac': ('TODO-tests-macos.md', 'ErgoptiPlus checks on a real Mac',
                                'The macOS checks only a real Mac can answer; code work stays in [TODO.md](TODO.md).'),
    '## To confirm on the Windows PC': ('TODO-tests-windows.md', 'ErgoptiPlus checks on a real Windows PC',
                                       'The Windows checks only a real PC can answer; code work stays in [TODO.md](TODO.md).'),
    '## To confirm on Linux': ('TODO-tests-linux.md', 'ErgoptiPlus checks on a real Linux desktop',
                               'The Linux checks only a real desktop can answer; code work stays in [TODO.md](TODO.md).'),
}
# Sections that are history once their items are done, whatever prose is left.
STALE = (
    '## Handoff, 2026-11-03 late evening',
    '## Branch `wip/layout-composer-responsive`',
    '## Branch `wip/gesture-clear-touchpad`',
)
RELEASE = '## Release 1.0.9 (maintainer requests of 1-2 November'
RELEASE_HEADING = '## Carried over from the 1.0.9 requests (1-2 November)'
RELEASE_INTRO = 'Released as v1.0.9; these requests of 1-2 November are still open.'


def read(path):
    with open(os.path.join(ROOT, path), encoding='utf-8') as handle:
        return handle.read()


def write(path, text):
    with open(os.path.join(ROOT, path), 'w', encoding='utf-8', newline='\n') as handle:
        handle.write(text)


def load_tsv(name):
    path = os.path.join(HERE, name)
    rows = []
    with open(path, encoding='utf-8') as handle:
        for line in handle:
            line = line.rstrip('\n')
            if line:
                rows.append(line.split('\t'))
    return rows


def count_open(lines):
    return sum(1 for line in lines if re.match(r'^\s*- \[ \]', line))


def squeeze(lines):
    """One blank line at most between blocks, none at the end."""
    out = []
    for line in lines:
        if not line.strip() and out and not out[-1].strip():
            continue
        out.append(line.rstrip() if not line.strip() else line)
    while out and not out[-1].strip():
        out.pop()
    return out


def has_work(lines):
    """A block keeps open work: an open checkbox or a top-level plain bullet."""
    for line in lines:
        if re.match(r'^\s*- \[ \]', line) or re.match(r'^- (?!\[x\])', line):
            return True
    return False


def split(lines, level):
    """[(heading or None, lines)] split on headings of exactly this level."""
    mark = '#' * level + ' '
    out = [(None, [])]
    for line in lines:
        if line.startswith(mark):
            out.append((line, [line]))
        else:
            out[-1][1].append(line)
    return out


def main():
    decisions = {row[0]: row[1] for row in load_tsv('decisions.tsv')}
    residuals = load_tsv('residual.tsv')
    lines = read('TODO.md').split('\n')
    open_before = count_open(lines)

    # 1. Drop every [x] item with its continuation lines.
    drop = set()
    seen_keys = set()
    undecided = []
    for start, end, section, key in done_items(lines):
        seen_keys.add(key)
        if key not in decisions:
            undecided.append((section, key))
        drop.update(range(start, end))
    lines = [line for i, line in enumerate(lines) if i not in drop]

    # 2. Residual lines, per (file, heading).
    pending = {}
    missing = []
    for key, target, heading, text in residuals:
        if key != '*' and key not in seen_keys:
            missing.append(key)
            continue
        pending.setdefault((target, heading), []).append(text.replace('\\n', '\n').replace('{BASE}', BASE))

    def append_residuals(target, heading, block):
        extra = pending.pop((target, heading), [])
        if not extra:
            return block
        block = squeeze(block)
        return block + [''] + '\n\n'.join(extra).split('\n') + ['']

    # 3. Sections: hardware ones move out, stale or finished ones go.
    kept, dropped, moved = [], [], {}
    for heading, block in split(lines, 2):
        if heading in HARDWARE:
            moved[heading] = block
            continue
        if heading is None:
            kept.append((heading, block))
            continue
        subs = []
        for sub, sub_block in split(block, 3):
            if sub is not None and not has_work(sub_block) and (('TODO.md', f'{heading} > {sub}') not in pending):
                dropped.append('  ' + sub)
                continue
            if sub is not None:
                sub_block = append_residuals('TODO.md', f'{heading} > {sub}', sub_block)
            subs.extend(sub_block)
        targeted = ('TODO.md', heading) in pending
        if heading.startswith(STALE) or (not has_work(subs) and not targeted):
            dropped.append(heading)
            continue
        if heading.startswith(RELEASE):
            body = subs[1:]
            first = next(i for i, line in enumerate(body) if line.startswith('- '))
            subs = [RELEASE_HEADING, '', RELEASE_INTRO, ''] + body[first:]
        subs = append_residuals('TODO.md', heading, subs)
        kept.append((heading, squeeze(subs) + ['']))

    # 4. Header: date, latest stable, long form, pointer to the test files.
    head = '\n'.join(kept[0][1])
    head = re.sub(r'Updated: [0-9-]+\.', 'Updated: 2026-11-12.', head)
    head = re.sub(r'Latest stable: \[v[0-9.]+\]\([^)]*\)',
                  'Latest stable: [v1.0.9](https://github.com/adrienm7/ergopti/releases/tag/v1.0.9)', head)
    head = re.sub(r'\(`git show [0-9a-f]+:TODO\.md` is the long form before this shrink\)',
                  f'(`git show {BASE}:TODO.md` is the long form before the 2026-11-12 cleanup)', head)
    head = re.sub(r'This file shrinks toward deletion after the next field reports: each machine section is one line per check,'
                  r'\s+naming\s+the field-run step or the hand action that proves it and the commits it confirms\.\s+',
                  '', head)
    pointer = ('This file lists features and fixes. The checks only real hardware can answer are in\n'
               '[TODO-tests-macos.md](TODO-tests-macos.md), [TODO-tests-windows.md](TODO-tests-windows.md) and\n'
               '[TODO-tests-linux.md](TODO-tests-linux.md).')
    head = head.replace('Conventions and tags:\n[', 'Conventions and tags: [')
    head = squeeze(head.split('\n')) + [''] + pointer.split('\n') + ['']
    kept[0] = (None, head)

    out = []
    for _, block in kept:
        out.extend(block)
    todo = squeeze(out)
    write('TODO.md', '\n'.join(todo) + '\n')

    # 5. One test file per OS, the section heading kept exactly.
    open_after = count_open(todo)
    for heading, (name, title, intro) in HARDWARE.items():
        block = moved.get(heading)
        if block is None:
            sys.exit(f'missing section {heading}')
        block = append_residuals(name, heading, block)
        text = squeeze([f'<!-- {name} -->', '', f'# {title}', '', intro, ''] + block)
        open_after += count_open(text)
        write(name, '\n'.join(text) + '\n')

    for (target, heading), extra in pending.items():
        print(f'UNPLACED residual for {target} {heading}: {len(extra)} line(s)')

    # 6. Readers of the moved sections, then Prettier on the four files (the format gate).
    replace_refs()
    prettier = next((p for p in (os.path.join(ROOT, 'node_modules/.bin/prettier'),
                                 '/home/user/ergopti/node_modules/.bin/prettier') if os.path.exists(p)), None)
    if prettier is None:
        sys.exit('prettier not found: run it on TODO.md and TODO-tests-*.md by hand')
    subprocess.check_call([prettier, '--log-level', 'warn', '--write', 'TODO.md'] +
                          [name for name, _, _ in HARDWARE.values()], cwd=ROOT)

    added = sum(len(v) for v in [r for r in residuals if r[0] == '*' or r[0] in seen_keys])
    print(f'base {BASE}')
    print(f'open checkboxes: before {open_before}, after {open_after} (residuals placed: '
          f'{sum(1 for r in residuals if r[0] == "*" or r[0] in seen_keys)})')
    print('dropped sections:')
    for heading in dropped:
        print('  ' + heading)
    if missing:
        print('residual keys not found (item gone or reworded):')
        for key in missing:
            print('  ' + key[:120])
    if undecided:
        print('[x] items with no decision (dropped, judge by hand):')
        for section, key in undecided:
            print(f'  {section[3:40]} | {key[:120]}')
    del added


REFS = [
    ('static/ergopti_plus/linux/data/field_todo_coverage.json', [
        ('"file": "TODO.md"', '"file": "TODO-tests-linux.md"'),
        ('Maps every point of TODO.md « To confirm on Linux »', 'Maps every point of TODO-tests-linux.md « To confirm on Linux »'),
    ]),
    ('static/ergopti_plus/macos/data/field_todo_coverage.json', [
        ('"file": "TODO.md"', '"file": "TODO-tests-macos.md"'),
        ('Maps every point of TODO.md « To confirm on the Mac »', 'Maps every point of TODO-tests-macos.md « To confirm on the Mac »'),
    ]),
    ('static/ergopti_plus/linux/tests/unit/infra/control/test_field_todo_coverage.lua', [
        ('TODO.md « To confirm on Linux »', 'TODO-tests-linux.md « To confirm on Linux »'),
    ]),
    ('static/ergopti_plus/macos/tests/unit/infra/field_run/test_field_todo_coverage.lua', [
        ('TODO.md « To confirm on the Mac »', 'TODO-tests-macos.md « To confirm on the Mac »'),
    ]),
    ('docs/tooling/linux-field-report-coverage.md', [('lines of `TODO.md`', 'lines of `TODO-tests-linux.md`')]),
    ('docs/tooling/macos-field-report-coverage.md', [('lines of `TODO.md`', 'lines of `TODO-tests-macos.md`')]),
    ('docs/tooling/windows-maintainer-checks.md', [('lines of `TODO.md`', 'lines of `TODO-tests-windows.md`')]),
    ('tools/dev/collect-macos-field-report.sh', [('TODO.md « To confirm on the Mac »', 'TODO-tests-macos.md « To confirm on the Mac »')]),
    ('tools/dev/field-todo-summary.py', [('point of its TODO.md section', 'point of its TODO-tests-<os>.md section')]),
    ('tools/maintainer/windows-live-checks.cjs', [('"Maintainer checks > Windows PC" lines of TODO.md', '"To confirm on the Windows PC" lines of TODO-tests-windows.md')]),
    ('static/ergopti_plus/macos/infra/field_check_session.lua', [("TODO.md's « Mac hardware session »", '« To confirm on the Mac » (TODO-tests-macos.md)')]),
    ('static/ergopti_plus/linux/tests/unit/modules/gestures/engine/test_touchpad_container_proofs.lua', [('TODO.md "To confirm on Linux"', 'TODO-tests-linux.md "To confirm on Linux"')]),
]


def replace_refs():
    for path, pairs in REFS:
        text = read(path)
        for old, new in pairs:
            if new in text and old not in text:
                continue
            if old not in text:
                print(f'REF not found in {path}: {old}')
                continue
            text = text.replace(old, new)
        write(path, text)


if __name__ == '__main__':
    main()
