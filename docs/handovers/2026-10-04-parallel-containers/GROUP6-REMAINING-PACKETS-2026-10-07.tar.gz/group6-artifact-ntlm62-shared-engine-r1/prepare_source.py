from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/ergopti'); packet=Path('/tmp/group6-artifact-ntlm62-shared-engine-r1')
rel='static/ergopti_plus/windows/vendor/ergopti_managed_curl_worker.ps1'
src=(root/rel).read_text(); start=src.index('function Get-RemainingBudget {'); end=src.index('\ntry {',start); helper=src[start:end]
engine='''# vendor/ergopti_curl_attempt.ps1
# Native curl attempt mechanics shared by private request and artifact owners.
# Loading defines a factory only; creating an instance starts no native process.
function New-ErgoptiCurlAttemptEngine {
    param(
        $InputValue,
        [hashtable]$Answer,
        [string]$CapabilityInput,
        [string]$PayloadPath,
        [string]$CurlConfig
    )
    # Each factory call creates a module-local process slot. Public methods
    # expose scalar acknowledgement only, never native cancellation authority.
    $Module = New-Module -AsCustomObject -ArgumentList @(
        $InputValue, $Answer, $CapabilityInput, $PayloadPath, $CurlConfig
    ) -ScriptBlock {
        param($InputValue, $Answer, $CapabilityInput, $PayloadPath, $CurlConfig)
        $script:Child = $null
'''+''.join('        '+line+'\n' for line in helper.splitlines())+'''
        function GetRemainingBudget { return (Get-RemainingBudget) }
        function GetNativeRemainingBudget { return (Get-NativeRemainingBudget) }
        function ObserveCapability { return (Get-OwnedCurlCapability) }
        function InvokeRoute {
            param([Uri]$Destination, $Route, [string]$Authentication,
                [string]$Method, [bool]$SendBody, [bool]$SendHeaders)
            return (Invoke-CurlRoute $Destination $Route $Authentication $Method $SendBody $SendHeaders)
        }
        function TestNtlmChallenge {
            param([Uri]$Destination, $Route, $Metrics, $Capability)
            return (Test-CausalNtlmChallenge $Destination $Route $Metrics $Capability)
        }
        function ChildQuiesced { return ($null -eq $script:Child) }
        Export-ModuleMember -Function GetRemainingBudget, GetNativeRemainingBudget,
            ObserveCapability, InvokeRoute, TestNtlmChallenge, ChildQuiesced
    }
    return $Module
}
'''
modified=src[:start]+'''function Get-RemainingBudget { return $AttemptEngine.GetRemainingBudget() }
function Get-NativeRemainingBudget { return $AttemptEngine.GetNativeRemainingBudget() }
'''+src[end:]
modified=modified.replace('$Child = $null','$AttemptEngine = $null',1)
old='    . $InputValue.route_path\n'; new=old+'''    . (Join-Path $PSScriptRoot 'ergopti_curl_attempt.ps1')
    $AttemptEngine = New-ErgoptiCurlAttemptEngine $InputValue $Answer $CapabilityInput $PayloadPath $CurlConfig
'''; assert modified.count(old)==1; modified=modified.replace(old,new,1)
repls=[('$Capability = Get-OwnedCurlCapability','$Capability = $AttemptEngine.ObserveCapability()'),("Invoke-CurlRoute $Destination $Route 'negotiate' $Method $SendBody $SendHeaders", "$AttemptEngine.InvokeRoute($Destination, $Route, 'negotiate', $Method, $SendBody, $SendHeaders)"),('Test-CausalNtlmChallenge $Destination $Route $Metrics $Capability','$AttemptEngine.TestNtlmChallenge($Destination, $Route, $Metrics, $Capability)'),("Invoke-CurlRoute $Destination $Route 'ntlm' $Method $SendBody $SendHeaders", "$AttemptEngine.InvokeRoute($Destination, $Route, 'ntlm', $Method, $SendBody, $SendHeaders)"),('$null -eq $Child','$null -eq $AttemptEngine -or $AttemptEngine.ChildQuiesced()')]
for oldv,newv in repls:
    assert modified.count(oldv)==1,oldv; modified=modified.replace(oldv,newv,1)
# Exact inverse of all edited original spans, with unchanged helpers restored.
inverse=modified
for oldv,newv in reversed(repls): inverse=inverse.replace(newv,oldv,1)
inverse=inverse.replace(new,old,1).replace('$AttemptEngine = $null','$Child = $null',1)
inverse=inverse.replace('function Get-RemainingBudget { return $AttemptEngine.GetRemainingBudget() }\nfunction Get-NativeRemainingBudget { return $AttemptEngine.GetNativeRemainingBudget() }\n',helper,1)
assert inverse==src
manifestrel='tools/build/windows_bundle_manifest.json'; manifest=(root/manifestrel).read_text(); marker='\t"required": [\n'; entry='''\t\t{
\t\t\t"source": "static/ergopti_plus/windows/vendor/ergopti_curl_attempt.ps1",
\t\t\t"dest": "vendor/ergopti_curl_attempt.ps1"
\t\t},
'''; assert manifest.count(marker)==1; manifestnew=manifest.replace(marker,marker+entry,1); assert json.loads(manifestnew)['required'][0]['dest']=='vendor/ergopti_curl_attempt.ps1'
files={rel:(src,modified),'static/ergopti_plus/windows/vendor/ergopti_curl_attempt.ps1':('',engine),manifestrel:(manifest,manifestnew)}
rows=[]; diff=[]
for path,(before,after) in files.items():
    for folder,value in [('preimages',before),('candidate',after)]:
        p=packet/folder/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value.encode())
    rows.append({'path':path,'preimage_sha256':hashlib.sha256(before.encode()).hexdigest() if before else None,'candidate_sha256':hashlib.sha256(after.encode()).hexdigest(),'new_file':not before})
    diff.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+path if before else '/dev/null',tofile='b/'+path))
(packet/'candidate.patch').write_text(''.join(diff))
(packet/'MANIFEST.json').write_text(json.dumps({'source_only':True,'runtime_executed':False,'whole_original_worker_inverse_exact':True,'original_helper_utf8_sha256':hashlib.sha256(helper.encode()).hexdigest(),'carrier_files':rows,'patch_sha256':hashlib.sha256((packet/'candidate.patch').read_bytes()).hexdigest()},indent=2)+'\n')
print((packet/'MANIFEST.json').read_text())
