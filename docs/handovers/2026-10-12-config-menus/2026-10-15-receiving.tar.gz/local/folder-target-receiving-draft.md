<!-- docs/handovers/2026-10-12-config-menus/2026-10-15-RECEIVING.md -->

# Group 1 receiving on 2026-10-15

## Refreshed source and retained contracts

The resumed source is Dev `6818cd94eba5966c26308f8e8dd30d0b8514023e`.
The existing feature history is preserved: its published `ad8065fea` is an
ancestor, and the local canonical feature was fast-forwarded to fresh Dev.
Root's AI producer and menu-reader corrections remain intact. Fresh Dev later
advanced to `f1b1d0b208bf6d24f5cd923718c7b0ca6f2fcaf7`: its diagnostic query
timeout and original controlled receiving are retained; none of those four
paths overlaps the wizard correction. No workflow,
runner, inventory, Snapshot registration or shared menu proof helper is changed.

The shared wizard previously advertised the OS default for an empty field on
all drivers. Windows and Linux actually select that default; macOS retains its
captured configuration destination. With custom macOS folder B and OS default
A, the displayed promise and placeholder therefore named the wrong folder.

Each native initializer now declares `empty_config_dir`. Windows uses its
existing empty-folder resolver; Linux uses its existing default resolver;
macOS derives the root from the captured configuration file, removing only the
terminal `hammerspoon` directory. A mutable path getter cannot replace this
captured authority. The page requires the field before changing its state and
uses it in the placeholder and a new onboarding-only hint translated into all
21 locales. The other dialogs' default-folder hint remains unchanged.

Import, Finish, metrics, deferred admission and native source fences retain
their existing contracts. The same empty wire value is preserved. This is a
presentation correction, not a claim of native parity or installed acceptance.

## Independent causal receiving

| Owning cohort | Candidate | Literal predecessor `6818` | Restored |
| --- | --- | --- | --- |
| macOS delivery, all 67 original and four additive cases | 71 PASS/0 FAIL | 67 PASS/4 FAIL | 71 PASS/0 FAIL |
| Linux onboarding filter, including two additive cases | 38 PASS/0 FAIL | 36 PASS/2 FAIL | 38 PASS/0 FAIL |

Every added native failure is the missing declared folder, not a dependency
failure. Producer bytes are restored and verified by SHA256. Existing Windows
and macOS test files retain their complete original byte prefixes; removing
only the Linux addition restores its complete original fixture.

The page's literal predecessor reaches the added macOS case after all original
page assertions and fails with actual A versus expected B. The corrected page
passes the three platform paths, empty import/Finish wire contract, native
picker behavior, all 21 locale renders, literal path punctuation, and refusal
of missing/invalid initialization targets before page reset.

The first Linux invocation inside the filesystem sandbox reported two
successful selected cases and six load-time fixture errors because its
configured external temporary directory was inaccessible. The identical
invocation with supported temporary-directory access passes 2/0; the broader
onboarding filter passes 38/0. The failed first invocation is retained
separately from the causal producer comparison.

Two new Windows cases observe the genuine initializer through its existing
JavaScript queue, preserve private absent configuration and restore globals.
They are not executed by this Linux container. AHK encoding/source inspection
is distinct from native parsing and execution.

## Delayed locale replies retain folder intent

The selected locale preview is asynchronous. The user can choose French, enter
the folder step before its response, type a custom folder or clear the field,
and then receive the matching French strings. The old renderer restores the
last saved folder and loses that input on all three platform paths. A stale
locale envelope and a native picker selection are independent preserved
controls. An external read-only DOM observation records all twelve original
platform/route outcomes before this second correction.

The page now retains raw input in its existing folder state on the actual
`input` event. Trimming, configuration reads, intent retirement and metrics
requests still belong to leaving the folder step. Eighteen additive page
vectors cover matching/stale replies with typed, cleared and picked folders;
three further cases refuse replies for a superseded typed target. The literal
inspection predecessor with the identical new tests fails the first matching
Windows typed case; the corrected and restored page pass. Every first-batch
and original assertion remains intact.

The document's script cache URL is advanced for each source change, from
published v7 to v8 and v9. Its existing WebView2 cache contract requires this:
the document is refreshed, but subordinate script URLs are cached. An additive
cache regression rejects the literal published v7 URL and accepts the new
version without weakening the first threshold for the second change.

## Receiving interruption and source qualification

The first full local planner execution completes formatting, AHK encoding,
426/426 JS checks and the portable macOS E2E harness with its explicit skip.
Its process disappears during the complete macOS units, without a terminal
summary or exit receipt. That log is retained as interrupted; those units and
the later Linux gates cannot be counted as successful from it. The remaining
native-port gates are replayed with separate logs and durable terminal exit
receipts. JavaScript and native readers use separate frozen source checkouts;
no source is modified beneath an active gate.

The current Windows include graph review reads 1,840 present principal files,
resolving every mandatory include after inventory-only A_LineFile/dot-segment
normalization. It accounts separately for the present optional feature
manifest and legitimately absent optional bundle inventory. None of the new
implicit locals matches a script global. `Field` matches three script globals,
but it is a formal parameter: official AHK 2.0.26 source marks parameters
`VAR_DECLARED`, while LocalSameAsGlobal targets implicit locals without that
flag. This lexical review is not native parse/execution or complete stdout.
No warning, callback, registration or assertion is removed or suppressed.

## Coordination and native remainder

Root's automatic run `38647316677` on exact `6818cd94e` reports the Snapshot16
source-image mismatch before dry receiving or general Windows units: actual
owner `c2c26f6b...` versus reviewed pin `d049972c...`. Its annotations are
retained. The warning policy, callbacks and exact receiving guard are unchanged;
only Root can compose independent review and receiving of these source images.
This observation is not a qualification of a successor SHA.

The inactive Personal archive remains authenticated, but only seven of nine
preimages still match fresh Dev. Root's `test-menu-manifest.cjs` and
`test-menu-parity.cjs` have changed. The packet still covers one default
constructor, not all four Personal constructors. Its 31 behavioral and 12
source-witness Windows controls remain unexecuted, and its historical 71-case
helper script is absent from the sealed archive. Adoption still requires
Root's proof-helper composition and actual native receiving.

Installed wizard receiving remains required on each OS: use disposable default
A and custom B profiles, open from B, inspect the path promised for empty input,
clear the field, import and Finish, check each driver's actual destination,
restart and rerun. Include fresh, existing and moved-folder cases, delayed and
stale folder responses, refused initialization/read/publication and repaired
retry. Verify metrics separately because Linux retains its independent data
store. Physical triggers and real Cocoa/WebView2/WebKit behavior are separate
from portable tests and hosted packaging.

TODO5/7/33/42/54/81 and transversal 16/38 remain partial; no item is removed.
The additional diagnostics request remains dependent on the complete
`Texte collé.txt`, which is unavailable in the current session. No diagnostic
requirements are inferred from an attachment preview.
