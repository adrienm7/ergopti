from pathlib import Path
import json,hashlib,difflib,shutil
r=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[p for p in (r/'proposal-candidate').rglob('*') if p.is_file()]
old=(r/'held/source/tools/ci/run-windows-updater-original-diagnostic-cohort.cjs').read_text()
cli=(r/'proposal-candidate/tools/ci/run-windows-updater-original-diagnostic-cohort.cjs').read_text()
module=(r/'proposal-candidate/tools/ci/windows-updater-original-source.cjs').read_text()
child=old[old.index('async function child('):old.index('\nasync function main(')+1]
context=old[old.index('function admittedContext()'):old.index('function readSourceFile(')].strip()
heldfunctions=old[old.index('function readSourceFile('):old.index('\nconst budgetMs =')]
assert child in cli and context in cli and heldfunctions in module
entries=[]
for p in sorted(files):
 rel=str(p.relative_to(r/'proposal-candidate'));entries.append({'path':rel,'preimage':'ABSENT_IN_D316_AND_CURRENT','bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
for inverse in [False,True]:
 text=''
 for p in sorted(files):
  rel=str(p.relative_to(r/'proposal-candidate'));b=p.read_text();a,c=(b,'') if inverse else ('',b)
  text+=''.join(difflib.unified_diff(a.splitlines(True),c.splitlines(True),fromfile='a/'+rel if inverse else '/dev/null',tofile='/dev/null' if inverse else 'b/'+rel))
 (r/('final-five-path.inverse.patch' if inverse else 'final-five-path.patch')).write_text(text)
newseed=[]
for p in sorted((r/'immutable-seed').rglob('*')):
 if p.is_file():
  rel=str(p.relative_to(r/'immutable-seed'));newseed.append({'path':rel,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size});assert (r/'canonical-physical-source'/rel).read_bytes()==p.read_bytes()
(r/'final-immutable-seed-inventory.json').write_text(json.dumps({'entries':newseed,'git_preimage':'d316a83127fb212232f2bcd7fd8c6d63b0f1e4a8','new_tools_overrides':4,'whole_native_source_profile':False,'all37_original_private_and_canonical_received_source_bytes_equal':True},indent=2)+'\n')
receipts=list((r/'canonical-tmp').glob('ergopti-updater-source-*/source-controls.receipt.json'));assert len(receipts)==1
shutil.copy2(receipts[0],r/'canonical-source-controls.receipt.json')
proof={'qualification':'ACTUAL_LINUX_PORTABLE_SOURCE22_NO_NATIVE_WINDOWS_QUALIFICATION','candidate_paths':entries,'frozen_child':{'bytes':2307,'sha256':sha(child.encode()),'byte_exact':True},'official_admittedContext_body_byte_exact':True,'original_reader_and_receipt_function_bodies_byte_exact':True,'context_snapshot_wrapper':'six passive descriptor primitives, inert snapshot only; schema/scope and Proxy injection refused','original_oracle7925_sha256':sha((r/'original-oracle7925.json.raw').read_bytes()),'oracle_transport7588_sha256':sha((r/'proposal-candidate/tools/ci/windows-updater-original-label-oracle.json').read_bytes()),'current21_pins_match_d316':True,'historic_source_pin_base_not_relabelled':True,'budgets_unchanged':[300000,30000,1320000],'private22':{'passed':22,'failed':0,'errors':0,'skipped':0},'actual_canonical_named22':{'passed':22,'failed':0,'errors':0,'skipped':0},'counterfactuals':{},'early_counter_infrastructure':'Two initial launches EROFS before cases due inherited protected /var/tmp TMPDIR; logs retained; scoped private TMPDIR resolved it without Source/test assertion changes.','source_initial_author_refusal':'Child span omitted final LF2306 vs2307; corrected boundary restores exact2307/c768, no suite/native result.','final_artifact_first_author_refusal':'Initial inline packing script SyntaxError before execution; source and received test bytes unchanged.','two_authenticated_pac_outputs':'UNIMPLEMENTED_AND_NOT_REQUIRED_FOR_PREPUBLICATION_STRICT_LOCAL','workflow_activation':'HELD_UNCHANGED'}
for name in ['scope','proxy','local-argc','import']:
 b=(r/('counter-'+name+'.stderr')).read_bytes();assert b'AssertionError' in b;proof['counterfactuals'][name]={'exit':1,'failure':'ACTUAL_ASSERTION','stderr_sha256':sha(b),'stdout_sha256':sha((r/('counter-'+name+'.stdout')).read_bytes()),'native':False}
(r/'final-source-preservation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(entries));print('whole unchanged named bodies/seed/corpus joins verified')
