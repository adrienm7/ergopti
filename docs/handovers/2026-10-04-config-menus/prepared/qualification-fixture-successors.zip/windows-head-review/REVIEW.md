# Windows head CI fixture contracts independent review

CLEAR for distinct V2 patch SHA-256 `d1db59f6bb7e0ba8fe292a9839bb461c7f5ce5bd0ae4643def83efd950deae8f`. Reject original packet `24747999...` as recorded in initial-frozen-guard-gap.json. No root files, index, refs or native execution.

Both exact two-file preimages match a550193ebc31aa819c369f701a61ebed72d86216; frozen postimages match their manifest and retain AHK BOM/LF. V2 unit bytes equal V1. The sole V2 source change relative V1 replaces exactly three literal U+0008 bytes in existing raw-Menu regexes with the proper literal backslash+b boundary. All three now reject Menu() while excluding MyMenu(). The corrected receipt/proof honestly records the previous mistaken escaping explanation.

The canonical command row owner builds label/action and adds disabled only when true. Reading omitted disabled with _MR_Get(..., false) therefore expresses the existing sparse contract, retaining both configured enabled and unconfigured disabled/retained-callback-refusal assertions.

_MR_RenderRows adds each separator then continues before Added++. Its head receipt is three labelled rows, while the native menu contains four actual positions. The revised test checks receipt 3 and independently GetMenuItemCount 4. All original provider count, command-first, separator-second, selected tap/hold captions, exact native positions and picker payload assertions remain. No production return contract changed.

Both command owners are actually bound by _TH_KeyRows to the shared head. Its first reachable include owns the native command; tap is a Windows command in the same shared head. The actual template resolves includes recursively and calls MenuRenderer_CommandRow, then _MR_DeclaredProviderRow and _MR_CommandRowData; the renderer registers canonical action data with RegisterMenuItem. The replacement guard follows this actual ownership chain rather than obsolete literal action-map construction in the provider. Remaining original button/hold guards stay, with repaired raw-Menu boundaries.

Reexecuted the portable source proof from a reviewer-owned path. Eleven actual-source predicates pass; six causal native-binding/head/raw-Menu/raw-registration/action-field/dispatch mutants are rejected. Unlike V1, patterns are extracted from exact frozen AHK bytes, including actual single-backslash whitespace patterns and the original failed literal action shapes. This is portable predicate evaluation, not native AHK execution.

Only Windows test source changes. Production, generators, manifests and every independent corpus stay unchanged. Parent must rerun exact integrated Windows native CI; Win32 drawing, physical input, E2E, packaging/install are unexecuted by this reviewer.
