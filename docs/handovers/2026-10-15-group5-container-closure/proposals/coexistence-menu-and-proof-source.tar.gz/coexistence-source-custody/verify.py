import pathlib,json,hashlib
r=pathlib.Path(__file__).parent
for n,j in json.loads((r/'PUBLIC-MANIFEST.json').read_text()).items():
 x=(r/n).read_bytes();assert len(x)==j['bytes'] and hashlib.sha256(x).hexdigest()==j['sha256'],n
print('All declared exact bodies verified')
