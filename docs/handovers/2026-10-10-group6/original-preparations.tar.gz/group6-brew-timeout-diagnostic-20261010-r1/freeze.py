from pathlib import Path
import ast,difflib,hashlib,json,os
root=Path('/tmp/group6-brew-timeout-diagnostic-20261010-r1')
pre=json.loads((root/'PREIMAGES.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for entry in pre['files']:
 assert (root/'preimage'/entry['path']).read_bytes()==(Path('/workspace/ergopti')/entry['path']).read_bytes()
paths=[x['path'] for x in pre['files']]
def functions(source):
 lines=source.splitlines(keepends=True)
 out={}
 tree=ast.parse(source)
 for node in tree.body:
  if isinstance(node,ast.FunctionDef):out[node.name]=''.join(lines[node.lineno-1:node.end_lineno])
  elif isinstance(node,ast.ClassDef):
   for f in node.body:
    if isinstance(f,ast.FunctionDef):out[node.name+'.'+f.name]=''.join(lines[f.lineno-1:f.end_lineno])
 return out,tree
oldtests,ot=functions((root/'preimage'/paths[1]).read_text());newtests,nt=functions((root/'candidate'/paths[1]).read_text())
oldmethods={k:v for k,v in oldtests.items() if k.rsplit('.',1)[-1].startswith('test_')};newmethods={k:v for k,v in newtests.items() if k.rsplit('.',1)[-1].startswith('test_')}
assert len(oldmethods)==178 and len(newmethods)==188 and all(newmethods[k]==v for k,v in oldmethods.items())
addition=(root/'new-tests.py.inc').read_text()
assert (root/'candidate'/paths[1]).read_text().replace(addition,'',1)==(root/'preimage'/paths[1]).read_text()
oldhelper,oh=functions((root/'preimage'/paths[0]).read_text());newhelper,nh=functions((root/'candidate'/paths[0]).read_text())
changed={'PhaseEvidence.__init__','PhaseEvidence.record','Children.__init__','Children.run'}
assert all(newhelper[k]==v for k,v in oldhelper.items() if k not in changed)
def run_node(tree):
 return next(f for node in tree.body if isinstance(node,ast.ClassDef) and node.name=='Children' for f in node.body if isinstance(f,ast.FunctionDef) and f.name=='run')
a,b=run_node(oh),run_node(nh)
def scheduling_calls(node):
 return [ast.dump(n,include_attributes=False) for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('wait_for_exit','remaining','wait','settle')]
# Source traversal order differs only due to inserted try/finally around the callback.
assert sorted(scheduling_calls(a))==sorted(scheduling_calls(b))
oldfinally=next(n for n in a.body if isinstance(n,ast.Try) and n.finalbody).finalbody
newfinally=next(n for n in b.body if isinstance(n,ast.Try) and n.finalbody).finalbody
assert ast.dump(ast.Module(body=oldfinally,type_ignores=[]))==ast.dump(ast.Module(body=newfinally,type_ignores=[]))
oldc=(root/'preimage'/paths[2]).read_text();newc=(root/'candidate'/paths[2]).read_text();assert newc.replace('Ran 188 tests in ','Ran 178 tests in ',1)==oldc
patch='';inverse=''
for name in paths:
 a=(root/'preimage'/name).read_text().splitlines(keepends=True);b=(root/'candidate'/name).read_text().splitlines(keepends=True)
 patch+=''.join(difflib.unified_diff(a,b,fromfile='a/'+name,tofile='b/'+name))
 inverse+=''.join(difflib.unified_diff(b,a,fromfile='a/'+name,tofile='b/'+name))
(root/'application.patch').write_text(patch);(root/'whole-file-inverse.patch').write_text(inverse)
(root/'CONSERVATION.json').write_text(json.dumps({'schema':1,'checks':'source parse/byte comparison only; no imports/execution','original_method_count':178,'candidate_method_count':188,'original_test_module_whole_inverse_exact':True,'all_original_178_method_source_bytes_exact':True,'original_method_sha256':{k:sha(v.encode()) for k,v in sorted(oldmethods.items())},'added_registered_methods':sorted(set(newmethods)-set(oldmethods)),'helper_changed_old_functions':sorted(changed),'all_other_helper_function_source_bytes_exact':True,'original_run_scheduling_call_AST_multiset_exact':True,'original_run_retirement_finally_AST_exact':True,'strict_census_only_178_to_188':True,'causal_receiving_case':'FirstCommandTimeoutControls.test_generic_exit_wait_keeps_supplied_float_budget_and_opaque_deadline_null','all_tests_and_receiving_runs':'UNRUN'},indent=2)+'\n')
(root/'README.md').write_text('''# Persistent first timeout: private source candidate

Preimage: actual integrated dev591d59a942780465bca95956dc3cc9b2e960fa9e. No main/index/refs changes, no product import, suites, native execution or receiving run. Parent alone applies after source review and runs selected slots serially.

The unchanged generic AdmissionError("Owned native command exceeded deadline") hides whether the oldest timeout arose in the permission requester, its nested consent observer, or another command. The first256 immutable phase files cannot show the last144 omitted records in the actual failed run. This source candidate captures the first TimeoutExpired as a strictly typed closed fact and retains it in all subsequent helper checkpoints. It changes neither permission, action, native receipt, normal output/error capture, signature, request clocks, wait budgets, assertions nor group retirement/debt.

Schema of optional first_timeout, exactly eight keys: schema=1; command enum permission-request/consent-observer/other; stage enum readiness/ui-observer/exit-wait; budget_seconds exactly the supplied int/float, finite and 0<budget<=180; request_deadline_ns exact exposed original request uint64 in1..2**64-1, or null for an opaque wait/no proven parent context; started_ns, expired_ns and spent_ns exact uint64 in0..2**64-1, with expired>=started and spent=expired-started. The two monotonic samples are observations, never scheduling authority. The opaque child wait deadline is not reconstructed from a new timer. An observer borrows only the explicitly installed original request context around the parent callback, which is restored in finally. None of this establishes native permission API entry.

Command classification uses the existing exact OwnedAutomationRequest mode, or exact owned-root native-appleevent-consent path; foreign same-basename files are other. No argv, path, environment or exception payload enters the new fact. A private validator copies flat typed fields, refuses unknown/private/non-finite/regressed/overflow data, and revalidates the retained first fact on every checkpoint. Valid later/duplicate facts cannot replace the first. Missing first_timeout attributes on manually built legacy writers use safe getattr and preserve the original no-field projection. Existing4096-byte/256-history bounds and omission counters remain unchanged.

Telemetry startup samples before child/readiness acquisition; original cancellation propagates there. On the actual TimeoutExpired branch, AdmissionError is assigned first; optional diagnostic publication failures or interruptions cannot replace that primary, and the unchanged physical-retirement finally still executes. Source checks conserve that finally AST, all original scheduling call expressions, every other helper function body, and the entire original test module by exact inverse. All178 original registered method bodies remain byte exact; ten additive methods yield188, with strict CJS census178->188 only.

Receiving causal case: FirstCommandTimeoutControls.test_generic_exit_wait_keeps_supplied_float_budget_and_opaque_deadline_null. Against old591, it uses only original Children.run and PhaseEvidence.record/publication, first exceeds cap256, triggers original TimeoutExpired via an explicit acquired process/reservation port, proves the unchanged primary and cleanup, publishes the final checkpoint, then fails by assertion on final.get("first_timeout") being absent. It never calls a new helper API or relies on a missing-method AttributeError/TypeError for causal credit. Old/fixed runs are UNRUN; execute only by root after review. The remaining tests exercise schema/overflow/forged/mutation/duplicate/omission, proven nested context and oldest primary, readiness input retirement, callback stage, original cancellation and secondary publication faults. These portable ports claim no native process/signature/consent credit.

No native qualification or TODO36 completion is claimed. All compile/test/receiving/native controls are UNRUN. Formatter runs, review, application and validation are root-owned subsequent work.
''')
files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json':continue
 data=p.read_bytes();assert b'\r' not in data;os.chmod(p,0o400)
 files.append({'path':str(p.relative_to(root)),'sha256':sha(data),'bytes':len(data)})
manifest={'schema':1,'preimage_head':pre['head'],'kind':'private source candidate; all execution UNRUN','main_sources_match_preimages':True,'original_test_count':178,'candidate_test_count':188,'patch_sha256':sha(patch.encode()),'application_paths':paths,'files':files,'receiving_and_native':'UNRUN'}
(root/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');os.chmod(root/'MANIFEST.json',0o400)
print(json.dumps({'manifest':str(root/'MANIFEST.json'),'sha256':sha((root/'MANIFEST.json').read_bytes()),'patch_sha256':sha(patch.encode()),'old_methods':178,'candidate_methods':188,'all_execution':'UNRUN'}))
