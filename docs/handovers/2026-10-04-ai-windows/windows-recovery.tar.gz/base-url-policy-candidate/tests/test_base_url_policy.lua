--- tests/unit/modules/llm/test_base_url_policy.lua

--- ==============================================================================
--- MODULE: Shared Base URL Policy Tests
--- DESCRIPTION:
--- Independent literal valid/refused addresses pin exact shared normalization.
--- Existing driver request/native boundary assertions remain independently owned.
--- ==============================================================================

local helpers = require("tests.helpers")
local Json = require("json")
local Policy = require("llm.base_url")
local Paths = require("infra.paths")





-- ===============================================
-- ===============================================
-- ======= 1/ Independent Literal Cases ==========
-- ===============================================
-- ===============================================

helpers.describe("Shared remote base URL policy", function()
	helpers.it("replays every independent literal without rewriting URI components", function()
		local file = assert(io.open(Paths.shared("tests/corpus/llm/base_url_vectors.json"), "rb"))
		local bytes = file:read("*a")
		assert(file:close())
		local corpus = Json.decode(bytes)
		helpers.assert_eq(#corpus.cases, 35, "exact independent corpus is present")
		local checked = 0
		for _, case in ipairs(corpus.cases) do
			local normalized, reason = Policy.normalize(case.input)
			if case.valid then
				helpers.assert_eq(normalized, case.normalized, case.id)
				helpers.assert_eq(reason, "ok", case.id .. " successful category")
			else
				helpers.assert_nil(normalized, case.id)
				helpers.assert_eq(type(reason), "string", case.id .. " refusal category")
				helpers.assert_eq(reason:find("secret", 1, true), nil, case.id .. " private value absent")
			end
			checked = checked + 1
		end
		helpers.assert_eq(checked, 35, "every exact case executed")
	end)

	helpers.it("refuses primitive/nonstring values before parsing", function()
		for _, value in ipairs({ false, true, 0, 1, {}, function() end }) do
			local normalized, reason = Policy.normalize(value)
			helpers.assert_nil(normalized)
			helpers.assert_eq(reason, "base URL is empty")
		end
		local normalized, reason = Policy.normalize(nil)
		helpers.assert_nil(normalized)
		helpers.assert_eq(reason, "base URL is empty")
	end)
end)
