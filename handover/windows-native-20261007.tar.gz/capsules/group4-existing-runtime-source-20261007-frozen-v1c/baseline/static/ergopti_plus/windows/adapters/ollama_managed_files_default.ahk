﻿; adapters/ollama_managed_files_default.ahk
#Requires AutoHotkey v2.0

global _OllamaInstallCodeOwners := Map()

_OllamaInstallValidPin(Pin) {
	if !(Pin is Map) || !(Pin.Get("path", 0) is String)
			|| !(Pin.Get("bytes", 0) is Integer) || Pin["bytes"] <= 0 || Pin["bytes"] > 0xffffffff
			|| !RegExMatch(Pin.Get("sha256", ""), "\A[0-9a-f]{64}\z")
		return false
	local image_path := Pin["path"]
	if !RegExMatch(image_path, "\A[A-Za-z]:\\") || InStr(image_path, "`r") || InStr(image_path, "`n")
		return false
	loop StrLen(image_path)
		if NumGet(StrPtr(image_path), (A_Index - 1) * 2, "UShort") == 0
			return false
	return true
}

/** Retains verified helper images independently of a native task's lifetime. */
class OllamaInstallCodeOwner {
	__New(Pins) {
		global _OllamaInstallCodeOwners
		this.Pins := Map()
		this.Readers := []
		this.Phase := "acquiring"
		local worker := Pins.Get("InstallWorker", 0)
		if !(worker is Map)
			throw TypeError("The default file port requires its installation worker pin.")
		local key := worker.Get("path", "")
		local previous_critical := Critical("On")
		try {
			if _OllamaInstallCodeOwners.Has(key)
				throw ValueError("Installation code initialization already has an owner.")
			_OllamaInstallCodeOwners[key] := this
		} finally Critical(previous_critical)
		try {
			for name in ["InstallWorker", "FilesHelper", "PublicationHelper"] {
				local pin := Pins.Get(name, 0)
				if !_OllamaInstallValidPin(pin)
					throw ValueError("Installation helper images require exact captured path/size/digest pins.")
				this.Pins[name] := pin.Clone()
				local reader := FileOpen(pin["path"], 0x100, "UTF-8-RAW")
				this.Readers.Push(reader)
				if reader.Length != pin["bytes"]
					throw Error("The installation helper length changed.")
				reader.Pos := 0
				local bytes := Buffer(pin["bytes"], 0)
				if reader.RawRead(bytes, bytes.Size) != bytes.Size || reader.Length != bytes.Size
						|| StrLower(CryptoSha256Bytes(bytes)) != pin["sha256"]
					throw Error("The installation helper image changed or was incompletely read.")
			}
			this.Phase := "ready"
		} catch as Err {
			this.Phase := "retained-debt"
			throw Err
		}
	}
}

/** Default actual staged file task; logical data/file debts stay explicitly owned. */
class OllamaManagedFilesDefault {
	__New(Options, CodeProvider := 0, TaskFactory := ShellRunner_StageTreeOwned) {
		if !(Options is Map) || !(Options.Get("pins", 0) is Map) || !HasMethod(TaskFactory, "Call")
			throw TypeError("Managed files require explicit code pins and a genuine task factory.")
		this.Options := Options.Clone()
		this.Pins := Map()
		for name, pin in Options["pins"] {
			if !_OllamaInstallValidPin(pin)
				throw TypeError("Managed file image pins must be captured maps.")
			this.Pins[name] := pin.Clone()
		}
		if !this.Pins.Has("InstallWorker") || !this.Pins.Has("Guardian") || !this.Pins.Has("Launcher")
			throw TypeError("Managed files require worker and runtime code path expectations.")
		this.Provider := HasMethod(CodeProvider, "Call") ? CodeProvider : ObjBindMethod(this, "_Code")
		this.Factory := TaskFactory
		this.Receipts := []
		this.NextId := 0
		this.CurrentRecord := 0
		this.IntakeRows := []
		this.IntakeTickets := Map()
		local opts := Map("helper", this.Pins["InstallWorker"]["path"],
			"powershell", Options.Get("powershell", ""), "capture_bytes", Options.Get("capture_bytes", 0),
			"spawn", ObjBindMethod(this, "_Spawn"), "on_physical", ObjBindMethod(this, "_Physical"),
			"on_error", ObjBindMethod(this, "_Error"))
		this.Port := OllamaInstallFilesPort(opts)
	}

	Dispatch(Action, Request, Authority, OnResult) {
		if this.Port.HasOwner() || !(Request is Map) || !HasMethod(OnResult, "Call")
			return false
		if this.HasFileDebt()
			return false
		return this._RunOwned(Action, Request, Authority, OnResult)
	}

	_RunOwned(Action, Request, Authority, OnResult, RepairId := 0) {
		if Action != "prepare" && Action != "publish" && Action != "cleanup" && Action != "cleanup_partial"
			throw TypeError("Managed files require an explicit native operation.")
		if this.NextId == 0x7fffffffffffffff
			throw Error("Managed file operation identities are exhausted.")
		local row := Map("id", ++this.NextId, "action", Action, "request", Request.Clone(),
			"terminal", 0, "result", 0, "phase", "reserved", "first_error", "", "repair_id", RepairId)
		this.Receipts.Push(row)
		this.CurrentRecord := row
		LoggerInfo("LLM.install", "Managed file operation " . row["id"] . " reserved (" . Action . ").")
		return this.Port.Dispatch(Action, Request, Authority, ObjBindMethod(this, "_Logical", row, OnResult))
	}

	_Spawn(Executable, Arguments, OnDone, Adopt, CaptureBytes) {
		local code := this.Provider.Call()
		if !IsObject(code) || code.Phase != "ready" || !(code.Pins is Map)
			throw Error("Installation code still retains initialization debt.")
		local args := Arguments.Clone()
		if !code.Pins.Has("InstallWorker") || code.Pins["InstallWorker"]["path"] != this.Pins["InstallWorker"]["path"]
				|| code.Pins["InstallWorker"]["sha256"] != this.Pins["InstallWorker"]["sha256"]
				|| code.Pins["InstallWorker"]["bytes"] != this.Pins["InstallWorker"]["bytes"]
			throw Error("Installation worker code provider is foreign to the captured image.")
		for name in ["FilesHelper", "PublicationHelper"] {
			if !code.Pins.Has(name) || code.Pins[name]["path"] != this.Pins[name]["path"]
					|| code.Pins[name]["sha256"] != this.Pins[name]["sha256"] || code.Pins[name]["bytes"] != this.Pins[name]["bytes"]
				throw Error("Installation code provider is foreign to the captured helper images.")
			args.Push("-" . name . "Path", code.Pins[name]["path"], "-" . name . "Hash", code.Pins[name]["sha256"])
		}
		args.Push("-GuardianPath", this.Pins["Guardian"]["path"], "-LauncherPath", this.Pins["Launcher"]["path"])
		local task := this.Factory.Call(Executable, args, OnDone, CaptureBytes, true)
		local previous_critical := Critical("On")
		try {
			if !IsObject(_SR_TreeAuthenticateHandleLocked(task))
				throw Error("Installation construction returned a forged task.")
		} finally Critical(previous_critical)
		; The exact lazy task is adopted before staging acquires any native bundle.
		Adopt.Call(task)
		if !task.stage()
			throw Error("The installation task failed suspended staging.")
		return task
	}

	_Physical(Action, Request, Terminal) {
		local row := this.CurrentRecord
		if !(row is Map) || row["action"] != Action || !IsObject(Terminal)
			throw Error("Physical completion has no exact file operation owner.")
		if row["terminal"] is Map
			return true
		row["terminal"] := Terminal.Clone()
		row["phase"] := "retained-file-debt"
		if Terminal.Get("dispatched", true) is Integer && Terminal.Get("dispatched", true) == false {
			row["phase"] := "no-effect"
			LoggerInfo("LLM.install", "Managed file operation " . row["id"] . " physically terminal (no effect).")
			return true
		}
		try {
			local result := JsonParse(Terminal.Get("stdout", ""))
			if !(result is Map) || !(result.Get("ok", false) is Integer)
				throw Error("Native file completion is not a typed result.")
			row["result"] := result
			if Terminal["exit"] != 0 || result["ok"] != true
				throw Error(result.Get("error", "Native file operation refused."))
			local phase := result.Get("phase", "")
			if Action == "publish" {
				local source := OllamaRuntimeSourceSpec(result)
				if result["Ticket"] != Request.Get("TicketId", "") || result["StageIdentity"] != Request.Get("StageIdentity", "")
						|| result["ManifestHash"] != Request.Get("ManifestSha256", "")
					throw Error("Publication expectation belongs to a different operation.")
			} else if Action == "prepare" {
				if phase != "prepared" || result.Get("ticket", "") != Request.Get("TicketId", "")
					throw Error("Prepared receipt belongs to a different operation.")
			} else if phase != "retired" || result.Get("ticket", "") != Request.Get("TicketId", "")
				throw Error("Cleanup has not produced its exact typed retired receipt.")
			row["phase"] := phase
			if row["repair_id"] {
				local repaired := this._Find(row["repair_id"])
				if !(repaired is Map) || repaired["phase"] != "retained-file-debt"
					throw Error("Native cleanup has no exact retained repair owner.")
				repaired["phase"] := "repaired-file-debt"
			}
		} catch as Err {
			row["phase"] := "retained-file-debt"
			row["first_error"] := Err.Message
		}
		; True acknowledges adoption of raw terminal/file debt into this strong
		; session, never proves cleanup or authenticates a copied runtime lease.
		LoggerInfo("LLM.install", "Managed file operation " . row["id"] . " physically terminal (" . row["phase"] . ").")
		return true
	}

	_Logical(Row, Callback, Terminal) {
		local result := Row["result"] is Map ? Row["result"].Clone()
			: Map("ok", false, "phase", Row["phase"], "error", Row["first_error"])
		if Row["phase"] == "retained-file-debt"
			result["ok"] := false
		Callback.Call(result)
	}

	Cancel() {
		return this.Port.Cancel()
	}

	HasOwner() {
		if this.Port.HasOwner()
			return true
		for row in this.IntakeRows
			if row["owner"].HasOwner()
				return true
		return false
	}

	HasFileDebt() {
		for row in this.Receipts
			if row["phase"] == "retained-file-debt"
				return true
		return false
	}

	/** Explicit native cleanup uses only the retained operation's own receipts. */
	Repair(Id, Authority, OnResult) {
		if this.Port.HasOwner() || !(Id is Integer) || !HasMethod(OnResult, "Call")
			return false
		local old := this._Find(Id)
		if !(old is Map) || old["phase"] != "retained-file-debt" || !(old["result"] is Map)
			return false
		local original := old["request"], receipt := old["result"]
		local request := Map("ManagedRoot", original.Get("ManagedRoot", ""), "TicketId", original.Get("TicketId", ""))
		local action := "cleanup"
		if receipt.Has("creation_receipt") {
			local creation := receipt["creation_receipt"]
			if !(creation is Map) || creation.Get("ticket", "") != request["TicketId"]
				return false
			request["CreationWalIdentity"] := creation.Get("creation_wal_identity", "")
			request["CreationWalSha256"] := creation.Get("creation_wal_sha256", "")
			action := "cleanup_partial"
		} else {
			if !original.Has("StageIdentity") || !original.Has("ManifestSha256")
				return false
			request["StageIdentity"] := original["StageIdentity"]
			request["ManifestSha256"] := original["ManifestSha256"]
		}
		return this._RunOwned(action, request, Authority, OnResult, Id)
	}

	/** Conservative data-debt adoption; this never clears or authorizes a lease. */
	RetainFileDebt(Id, Reason) {
		if !(Id is Integer) || !(Reason is String) || Reason == ""
			return false
		local row := this._Find(Id)
		if !(row is Map)
			return false
		row["phase"] := "retained-file-debt"
		if row["first_error"] == ""
			row["first_error"] := Reason
		return true
	}

	_Find(Id) {
		for row in this.Receipts
			if row["id"] == Id
				return row
		return 0
	}

	_Code() {
		global _OllamaInstallCodeOwners
		local key := this.Pins["InstallWorker"]["path"]
		if _OllamaInstallCodeOwners.Has(key) {
			local code := _OllamaInstallCodeOwners[key]
			if code.Phase != "ready"
				throw Error("Installation code initialization still retains debt.")
			for name in ["InstallWorker", "FilesHelper", "PublicationHelper"]
				if !code.Pins.Has(name) || code.Pins[name]["path"] != this.Pins[name]["path"]
						|| code.Pins[name]["sha256"] != this.Pins[name]["sha256"] || code.Pins[name]["bytes"] != this.Pins[name]["bytes"]
					throw Error("An active installation code image cannot be replaced.")
			return code
		}
		return OllamaInstallCodeOwner(this.Pins)
	}

	_Error(Kind, Failure) {
		LoggerWarn("LLM.install", "Owned installation {1} refused: {2}.", Kind, Failure.Message)
	}
	ReserveIntake(Owner, Request, Generation) {
		if !(Owner is OllamaArchiveIntake) || Owner.Files != this || !(Request is Map)
				|| !(Generation is Integer) || Generation <= 0 || this.Port.HasOwner() || this.HasFileDebt()
			throw ValueError("Intake file reservation has no genuine parent owner.")
		if this.NextId == 0x7fffffffffffffff
			throw Error("Managed file operation identities are exhausted.")
		local row := Map("id", ++this.NextId, "action", "prepare", "request", Request.Clone(),
			"terminal", 0, "result", 0, "phase", "reserved", "first_error", "", "repair_id", 0,
			"owner", Owner, "generation", Generation, "ticket", 0,
			"target", Owner.Record["target"].Clone(), "deadline", Owner.Record["deadline"])
		this.Receipts.Push(row)
		this.IntakeRows.Push(row)
		this.CurrentRecord := row
		return row
	}

	_IntakeRow(Owner, Row) {
		if !(Owner is OllamaArchiveIntake) || Owner.Files != this || !(Row is Map)
				|| this._Find(Row.Get("id", 0)) != Row || Row.Get("owner", 0) != Owner
			throw ValueError("Intake file data has a foreign reservation.")
		return Row
	}

	RefuseIntakeBeforeAcquisition(Owner, Row) {
		if !(Row is Map)
			return
		this._IntakeRow(Owner, Row)
		if Row["phase"] != "reserved" || !(Owner.Record is Map) || Owner.Record["native_id"] != 0
				|| IsObject(Owner.Record["source"]) || IsObject(Owner.Record["curl_task"])
			throw ValueError("An acquired intake cannot claim no-effect retirement.")
		Row["phase"] := "no-effect"
	}

	AdoptIntake(Owner, Row, Terminal) {
		this._IntakeRow(Owner, Row)
		if Row["ticket"] is OllamaIntakePreparedTicket
			return Row["ticket"]
		if !(Owner.Record is Map) || Owner.Record["files_row"] != Row ||
				Owner.Record["generation"] != Row["generation"]
			throw ValueError("Intake terminal lost its strong source generation.")
		Row["phase"] := "retained-file-debt"
		Row["terminal"] := Terminal is Map ? Terminal.Clone() : 0
		try {
			local Status := Owner.Native.PollIntake(Owner.Record["native_id"])
			if Owner.Record["terminal"] != Terminal || !Owner.Record["source_done"]
				throw Error("Intake prepared bytes do not belong to its actual retained terminal.")
			if !(Terminal is Map) || Terminal.Get("exit", -1) != 0 || Terminal.Get("stderr", "") != ""
					|| !(Status is Map) || Status.Get("id", 0) != Owner.Record["native_id"]
					|| Status.Get("phase", -1) != 7 || Status.Get("source_terminal", 0) != 1
					|| Status.Get("source_exit", -1) != 0 || Status.Get("download_terminal", 0) != 1
					|| Status.Get("download_exit", -1) != 0 || Status.Get("download_members", -1) != 0
					|| Status.Get("composite_members", -1) != 0 || Status.Get("guardian_phase", -1) != 6
					|| Status.Get("activation_claimed", 0) != 1 || Status.Get("seal_claimed", 0) != 1
				throw Error("Intake has not physically settled its original complete tuple.")
			local lines := StrSplit(Trim(Terminal["stdout"], "`r`n"), "`n")
			if lines.Length != 2
				throw Error("Intake terminal requires exactly inventory and prepared frames.")
			local inventory := JsonParse(lines[1]), result := JsonParse(lines[2])
			if !(inventory is Map) || inventory.Get("kind", "") != "ollama-intake-inventory"
					|| inventory.Get("ticket", "") != Row["request"]["TicketId"]
					|| !(result is Map) || !(result.Get("ok", false) is Integer) || result["ok"] != true || result.Get("phase", "") != "prepared"
					|| result.Get("ticket", "") != Row["request"]["TicketId"]
					|| result.Get("asset", "") != Row["request"]["AssetId"]
					|| !RegExMatch(result.Get("stage_identity", ""), "\A[0-9a-f]{8}:[0-9a-f]{16}\z")
					|| !RegExMatch(result.Get("manifest_sha256", ""), "\A[0-9a-f]{64}\z")
				throw Error("Intake prepared data is incomplete or foreign to its actual worker.")
			Row["result"] := JsonParse(lines[2])
			if Owner.Record["cancelled"] || !Owner._Current(Owner.Record)
				throw Error("Settled prepared data outlived its current source admission.")
			Row["phase"] := "prepared"
			local ticket := OllamaIntakePreparedTicket(this, Row)
			Row["ticket"] := ticket
			this.IntakeTickets[ObjPtr(ticket)] := Map("ticket", ticket, "row", Row, "result_frame", lines[2])
			return ticket
		} catch Any as Err {
			if Row["first_error"] == ""
				Row["first_error"] := "intake_prepared_adoption_refused"
			return false
		}
	}

	ConsumeIntake(Ticket, Request, Target) {
		local issued := IsObject(Ticket) ? this.IntakeTickets.Get(ObjPtr(Ticket), 0) : 0
		if !(Ticket is OllamaIntakePreparedTicket) || Ticket.Files != this || Ticket.Consumed
				|| !(issued is Map) || issued.Get("ticket", 0) != Ticket || !(Request is Map) || !(Target is Map)
			throw ValueError("Prepared intake ticket is forged, foreign or consumed.")
		local row := issued["row"], result_frame := issued["result_frame"]
		local result_snapshot := JsonParse(result_frame)
		if Ticket.Row != row
			throw ValueError("Prepared intake ticket changed its issued source row.")
		this._IntakeRow(row["owner"], row)
		if row["phase"] != "prepared" || row["ticket"] != Ticket || row["owner"].HasOwner()
			throw ValueError("Prepared intake still owes physical source handback.")
		for name in ["ManagedRoot", "CataloguePath", "CatalogueSha256", "AssetId", "TicketId", "MaxExpandedBytes", "MaxEntries"]
			if Request.Get(name, 0) != row["request"].Get(name, 0)
				throw ValueError("Prepared ticket belongs to another captured archive source.")
		for name in ["models_dir", "origin", "port"]
			if Target.Get(name, 0) != row["target"].Get(name, 0)
				throw ValueError("Prepared intake belongs to another runtime target.")
		local current := row["owner"].CurrentFn.Call(row["request"].Clone(), row["target"].Clone())
		local previous := Critical("On")
		try {
			if !(current is Integer) || current != true || A_IsSuspended || A_TickCount >= row["deadline"]
					|| row["owner"].Revoked || row["owner"].Generation != row["generation"] || row["owner"].HasOwner()
					|| Ticket.Consumed || this.IntakeTickets.Get(ObjPtr(Ticket), 0) != issued
					|| issued["ticket"] != Ticket || issued["row"] != row || Ticket.Row != row
				throw ValueError("Prepared intake source generation expired or changed.")
			if !(issued["result_frame"] == result_frame) || !this._IntakeDataEqual(row["result"], result_snapshot)
				throw ValueError("Prepared intake data changed after its exact terminal issuance.")
			Ticket.Consumed := true
			this.IntakeTickets.Delete(ObjPtr(Ticket))
		} finally Critical(previous)
		return result_snapshot
	}

	/** Compares the closed JSON value graph, including scalar types and key spelling. */
	_IntakeDataEqual(Actual, Expected) {
		if Type(Actual) != Type(Expected)
			return false
		if Expected is Map {
			if Actual.Count != Expected.Count
				return false
			local actual_keys := [], index := 0
			for key in Actual
				actual_keys.Push(key)
			for key, value in Expected {
				local actual_key := actual_keys[++index]
				if !(actual_key == key) || !this._IntakeDataEqual(Actual[actual_key], value)
					return false
			}
			return true
		}
		if Expected is Array {
			if Actual.Length != Expected.Length
				return false
			for index, value in Expected
				if !this._IntakeDataEqual(Actual[index], value)
					return false
			return true
		}
		return !IsObject(Expected) && Actual == Expected
	}
}


/** Issued only from the actual FilesDefault row; the registry retains identity. */
class OllamaIntakePreparedTicket {
	__New(Files, Row) {
		this.Files := Files
		this.Row := Row
		this.Consumed := false
	}
}
