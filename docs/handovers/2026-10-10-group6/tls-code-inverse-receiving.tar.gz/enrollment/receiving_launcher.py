"""Run the nine unchanged historical-source controls in an isolated snapshot."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

source, output = map(Path, sys.argv[1:])
specification = importlib.util.spec_from_file_location('private_source_receiving', source)
module = importlib.util.module_from_spec(specification)
specification.loader.exec_module(module)
suite = unittest.TestSuite()
suite.addTest(module.NativeHTTPStageReceiptTests('test10FixtureFlagCannotChangeReleaseOperationsOrMoveCausalBoundaries'))
for case in [module.HistoricalPACOwnershipProjectionTests, module.PACSourceAcquisitionProjectionTests]:
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
selected = [test.id().split('.', 1)[1] for test in suite]
if len(selected) != 9 or len(set(selected)) != 9:
    raise RuntimeError('Original nine-case identity refused')
result = unittest.TextTestRunner(verbosity=2).run(suite)
summary = {'total': result.testsRun, 'pass': result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
           'fail': len(result.failures), 'errors': len(result.errors), 'skip': len(result.skipped),
           'selected': selected,
           'fail_names': [test.id().split('.', 1)[1] for test, _ in result.failures],
           'error_names': [test.id().split('.', 1)[1] for test, _ in result.errors],
           'native_compile_or_certificate_cause_credit': False}
with output.open('x') as stream:
    stream.write(json.dumps(summary, indent=2, sort_keys=True)+'\n')
output.chmod(0o600)
raise SystemExit(0 if result.wasSuccessful() and result.testsRun == 9 and not result.skipped else 1)
