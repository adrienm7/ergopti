﻿; tests/unit/test_ollama_prepared_session_route.ahk

; ==============================================================================
; MODULE: Prepared Archive Session Route Recording Controls
; DESCRIPTION:
; Uses real ticket adoption/consumption and the existing publication builder.
; Transport/process ports are recorded; this does not qualify a native daemon.
; ==============================================================================

class _SSR_Port {
	__New() {
		this.Calls := []
	}
	HasOwner() {
		return false
	}
	Cancel() {
		return true
	}
	Dispatch(Action, Request, Authority, Done) {
		AssertTrue(Authority["authorize"].Call(Action, Request))
		AssertTrue(Authority["is_current"].Call(Action, Request))
		this.Calls.Push(Map("action", Action, "request", Request.Clone(), "done", Done))
		return true
	}
}

class _SSR_Files extends _AIT_Files {
	__New() {
		super.__New()
		this.Port := _SSR_Port()
	}
}

class _SSR_Archive extends OllamaOfficialArchiveProvider {
	__New(Files, Current, Prepared) {
		this.Intake := _AIT_Owner()
		this.Intake.Files := Files
		this.Intake.CurrentFn := Current
		this.Intake.Record["files_row"] := Files.ReserveIntake(this.Intake, this.Intake.Request, 1)
		this.Prepared := Prepared
		this.Owned := false
		this.Starts := 0
		this.Stops := 0
		this.Acknowledged := false
	}
	Start(Prepare, Target, Asset, Deadline) {
		AssertEqual(Prepare["TicketId"], this.Intake.Request["TicketId"])
		AssertEqual(Target["origin"], this.Intake.Record["target"]["origin"])
		AssertEqual(Asset["asset_id"], "windows-amd64")
		AssertTrue(Deadline > A_TickCount)
		this.Starts += 1
		this.Owned := true
		return true
	}
	Issue() {
		local ticket := this.Intake.Adopt()
		AssertTrue(ticket is OllamaIntakePreparedTicket)
		this.Intake.Record := 0
		this.Owned := false
		this.Prepared.Call(ticket)
		return ticket
	}
	HasOwner() {
		return this.Owned
	}
	Stop() {
		this.Stops += 1
		if this.Acknowledged
			this.Owned := false
		return !this.Owned
	}
}

class _SSR_Session extends OllamaUserLocalSession {
	__New() {
		this.Files := _SSR_Files()
		this.RuntimeOptions := Map()
		this.Current := true
		this.Consents := 0
		this.Consent := true
		this.CurrentFn := (*) => this.Current
		this.ConsentFn := (*) => (++this.Consents, this.Consent)
		this.Dispatched := (*) => 0
		this.PollMilliseconds := 10
		this.Record := 0
		this.Generation := 0
		this.Busy := false
		this.Timer := ObjBindMethod(this, "Poll")
		this.TimerFn := (*) => true
		this.Runtime := {HasOwner: (*) => false, Invalidate: (*) => true, Owner: 0}
	}
}

_SSR_Plan() {
	local specimen := _AIT_Owner()
	return Map("prepare", specimen.Request.Clone(), "target", specimen.Record["target"].Clone(),
		"version", "0.24.0", "deadline", A_TickCount + 10000)
}

_SSR_Factory(World, Files, RuntimeOptions, Current, Prepared, PollMilliseconds, Deadline, Version, AssetId) {
	AssertEqual(Version, "0.24.0")
	AssertEqual(AssetId, "windows-amd64")
	AssertTrue(PollMilliseconds > 0 && Deadline > A_TickCount)
	World["archive"] := _SSR_Archive(Files, Current, Prepared)
	return World["archive"]
}

_SSR_PreparedTicketUsesActualPublication() {
	local session := _SSR_Session(), world := Map(), plan := _SSR_Plan()
	AssertTrue(session.Start(plan, _SSR_Factory.Bind(world)))
	AssertEqual(session.Consents, 1)
	AssertEqual(session.Files.Port.Calls.Length, 0, "Network preparation must not execute the old prepare worker.")
	AssertTrue(session.ArchiveOwned)
	local ticket := world["archive"].Issue()
	AssertTrue(ticket.Consumed)
	AssertEqual(session.Files.Port.Calls.Length, 1)
	AssertEqual(session.Files.Port.Calls[1]["action"], "publish")
	AssertEqual(session.Files.Port.Calls[1]["request"]["TicketId"], plan["prepare"]["TicketId"])
	AssertEqual(session.Files.Port.Calls[1]["request"]["StageIdentity"], "12345678:0000000000000001")
	AssertEqual(session.Files.Port.Calls[1]["request"]["ManifestSha256"], Format("{:064}", 0))
	AssertEqual(session.Record["phase"], "publishing")
	AssertFalse(session.ArchiveOwned)
	AssertThrows(() => session._ArchivePrepared(session.Record, ticket))
	AssertEqual(session.Files.Port.Calls.Length, 1)
}

_SSR_ConsentRefusalDoesNotConstruct() {
	local session := _SSR_Session(), world := Map()
	session.Consent := false
	AssertFalse(session.Start(_SSR_Plan(), _SSR_Factory.Bind(world)))
	AssertEqual(session.Consents, 1)
	AssertFalse(world.Has("archive"))
	AssertEqual(session.Files.Port.Calls.Length, 0)
}

_SSR_StalePreparedCannotConsume() {
	local session := _SSR_Session(), world := Map()
	AssertTrue(session.Start(_SSR_Plan(), _SSR_Factory.Bind(world)))
	local archive := world["archive"], ticket := archive.Intake.Adopt()
	AssertTrue(ticket is OllamaIntakePreparedTicket)
	archive.Intake.Record := 0
	session.Current := false
	AssertThrows(() => session._ArchivePrepared(session.Record, ticket))
	AssertFalse(ticket.Consumed)
	AssertEqual(session.Files.Port.Calls.Length, 0)
}

_SSR_CancelKeepsExactArchiveOwner() {
	local session := _SSR_Session(), world := Map()
	AssertTrue(session.Start(_SSR_Plan(), _SSR_Factory.Bind(world)))
	local record := session.Record, archive := world["archive"]
	AssertFalse(session.Stop())
	AssertTrue(session.Record == record)
	AssertTrue(session.ArchiveOwned)
	AssertEqual(archive.Stops, 1)
	AssertEqual(session.Files.Port.Calls.Length, 0)
	archive.Acknowledged := true
	session.Poll()
	AssertEqual(session.Record, 0)
	AssertFalse(archive.HasOwner())
}

_SSR_ForeignTicketDoesNotPublish() {
	local session := _SSR_Session(), world := Map(), foreign := _AIT_Owner()
	AssertTrue(session.Start(_SSR_Plan(), _SSR_Factory.Bind(world)))
	local ticket := foreign.Adopt()
	AssertTrue(ticket is OllamaIntakePreparedTicket)
	AssertThrows(() => session._ArchivePrepared(session.Record, ticket))
	AssertFalse(ticket.Consumed)
	AssertEqual(session.Files.Port.Calls.Length, 0)
}

_SSR_EarlyCallbackCannotAdmit() {
	local session := _SSR_Session(), world := Map()
	AssertTrue(session.Start(_SSR_Plan(), _SSR_Factory.Bind(world)))
	local ticket := world["archive"].Intake.Adopt()
	AssertTrue(ticket is OllamaIntakePreparedTicket)
	session.Record["archive_building"] := true
	AssertThrows(() => session._ArchivePrepared(session.Record, ticket))
	AssertFalse(ticket.Consumed)
	AssertEqual(session.Files.Port.Calls.Length, 0)
}

Test("official-session-prepared-ticket-publication", _SSR_PreparedTicketUsesActualPublication)
Test("official-session-consent-before-construction", _SSR_ConsentRefusalDoesNotConstruct)
Test("official-session-stale-prepared-ticket", _SSR_StalePreparedCannotConsume)
Test("official-session-cancel-awaits-archive-handback", _SSR_CancelKeepsExactArchiveOwner)
Test("official-session-foreign-prepared-ticket", _SSR_ForeignTicketDoesNotPublish)
Test("official-session-early-prepared-callback", _SSR_EarlyCallbackCannotAdmit)
