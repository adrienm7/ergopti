# Windows control CLI admission proof

Checkpoint: 2026-10-27 05:31:24 Europe/Paris. Owned branch is clean.

## Atomic changes

- `776285339b812903492ed1aba94f64af98234654` — `fix(windows): validate control session identities before lookup`. The full actual CLI previously admitted JSON Boolean/string/array schema, non-scalar or case-invalid identity, trailing-newline tokens and coercible process IDs. Actual OLD test 432: 20 cases, 7 PASS and 13 FAIL; actual formatted GREEN 439: 20/20 PASS. Original typed numeric schema spellings 1/1.0/1e0 and integral floating PIDs remain accepted. Root object, exact property identity, scalar value and integral numeric guards run before process lookup.
- `94b8144d8a12a92b8f0f5192fee72301d920a068` — `fix(windows): reject malformed control result completions`. Actual production poll AST consumed genuine private result files and reported false completion for malformed JSON kinds, wrong-case states/IDs and invalid phase fields; parse failures silently timed out. OLD test 440: 39 cases, 10 PASS and 29 FAIL; formatted GREEN 443: 39/39 PASS plus 20/20 session neighbors. Root object, exact declared identity and phase-shape guards now precede result correlation and state interpretation. All five canonical states, both requested forms and valid numeric spellings remain covered.

Normal pre-commit formatting and hooks passed for both commits; inventory/results ownership, default native coverage, encoding, loop-capture, strict conventions and false-green checks passed. Full JS suite has not run in this owned checkout; integration batch and Windows CI are still required.

## Native runtime qualification

The default AHK harness really invokes both mandatory CLI controls (444). Both fail because Wine's actual canonical Windows PowerShell executable returns no version text, so required Windows PowerShell 5.1 cannot be established. No test was skipped or converted to PASS. Actual PS semantics above were executed using PowerShell Core 7.5.2 on Linux; neither Windows PowerShell 5.1 nor user32/message delivery/live Ergopti reload is qualified here.

Registry IDs are js-0504 and js-0505. On the older owned base, local ordinals are 505 and 506. Latest inspected origin/dev bba0f984 has seven additional entries, so integration must retain those entries and use ordinals 512 and 513. See reservation.json.

## Confirmed other-OS counterpart, left unchanged

Actual readonly 446 ran the entire production `tools/control/request_driver_reload.sh` on Linux with genuine private session/request/result files, and delivered SIGUSR1 only to an owned fixture child. Healthy valid completion returned 0; JSON schema true and truncated JSON also returned 0. This is genuine false completion in the shared macOS/Linux shell reader, which recognizes text fragments without validating JSON/schema. macOS execution was not tested. No shell source or tests were changed in this Windows task. See 446-shell-parity-receipt.json and exact executable reproduction.

## Proven builder defects, left unchanged

Actual production PowerShell AST probe 430 proves that native-builder Push-Location positional Path interprets legal brackets as wildcards and can enter an unintended sibling build directory. The actual public tracked-manifest validator also admits Boolean/string/array schema values through PowerShell equality coercion. Healthy literal paths and valid numeric schema controls passed. See ../builder-boundaries for original receipts, private input fingerprints and concrete review-only patches. Both builders are provenance/fingerprint inputs, including baked native PAC source identity. Official MSVC -UpdateTracked regeneration and drift checks are required before modifying tracked closure; no hand-written manifest/DLL update or alternate regeneration was attempted.
