'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const acorn=require('/workspace/ergopti/node_modules/acorn');
const root=__dirname;
const before=fs.readFileSync(path.join(root,'preimage.cjs'),'utf8');
const after=fs.readFileSync(path.join(root,'physical-source/tools/test/test-windows-updater-original-source.cjs'),'utf8');
const parse=t=>acorn.parse(t,{ecmaVersion:'latest'});
function walk(n,visit){ if(!n||typeof n!=='object')return; if(n.type)visit(n);for(const [k,v]of Object.entries(n)){if(k==='start'||k==='end')continue;if(Array.isArray(v))v.forEach(x=>walk(x,visit));else if(v&&typeof v==='object')walk(v,visit);} }
function normalized(n){
 if(!n||typeof n!=='object')return n;
 if(Array.isArray(n))return n.map(normalized);
 if(n.type==='CallExpression'&&n.callee.type==='Identifier'&&n.callee.name==='passiveCopy')return normalized(n.arguments[0]);
 const v={};for(const [k,x]of Object.entries(n))if(!['start','end','raw'].includes(k))v[k]=normalized(x);
 // Only the actual local-invocation callee changes from host f.api to the private model.api.
 if(v.type==='CallExpression'&&v.callee.type==='MemberExpression'&&v.callee.property.name==='localInvocation'&&v.callee.object.type==='MemberExpression'&&v.callee.object.property.name==='api')v.callee.object.object={type:'Identifier',name:'architectureOwner'};
 return v;
}
function assertions(ast){const result=[];walk(ast,n=>{if(n.type==='CallExpression'&&n.callee.type==='MemberExpression'&&n.callee.object.name==='assert')result.push(JSON.stringify(normalized(n)));});return result;}
const oldAssertions=assertions(parse(before)),newAssertions=assertions(parse(after)),pool=[...newAssertions];
for(const old of oldAssertions){const i=pool.indexOf(old);assert.notEqual(i,-1,'Original assertion missing');pool.splice(i,1);}
function controls(text){const rows=[];walk(parse(text),n=>{if(n.type==='CallExpression'&&n.callee.name==='control')rows.push({name:n.arguments[0].value,body:text.slice(n.arguments[1].start,n.arguments[1].end)});});return rows;}
const oldControls=controls(before),newControls=controls(after);
assert.equal(oldControls.length,21);assert.equal(newControls.length,21);
const changed=[];let exact=0;
for(let i=0;i<oldControls.length;i++){if(oldControls[i].body===newControls[i].body)exact++;else changed.push({index:i,name:oldControls[i].name});}
assert.deepEqual(changed.map(x=>x.index),[2,4,6]);
const result={original_assertion_count:oldAssertions.length,new_assertion_count:newAssertions.length,all_original_assertions_preserved:true,normalization_exceptions:['passiveCopy only erases private-realm prototype in passive metadata comparisons','localInvocation host API callee replaced by explicit architecture model API'],original_named_control_callbacks:21,total_cases_including_main:22,byte_exact_original_callback_bodies:exact,changed_callback_bodies:changed,import_label_before:oldControls[0].name,import_label_after:newControls[0].name,production_sources_unchanged:true};
fs.writeFileSync(path.join(root,'assertion-preservation.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
