from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-ui-metrics/tools/test/test-metrics-filter-cache.cjs');s=p.read_text();a='console.log(`${passed} passed, 0 failed.`);';assert s.count(a)==1
s=s.replace(a,'''let typingAppLocaleApplications=0;
const typingAppOrderedLocales=[typingCaptionCatalogues.find(locale=>locale.name==='en.json'),...typingCaptionCatalogues.filter(locale=>locale.name!=='en.json')];
for(const host of ['windows','macos','linux']) {
	test(`${host} native app activity follows every admitted locale immediately`,()=>{
		const page=loadMetricsTypingPage(host);
		freezePageClock(page,'2026-10-27T12:00:00');
		typingAppFilterLocalePorts(page);
		const manifest={'2026-10-26':{'Editor.exe':{chars:300,time:30000,app_time_ms:60000}}};
		publishTypingPage(page,host,manifest);
		let revision=1;
		for(const locale of typingAppOrderedLocales) {
			const keys=['ui_typing.unit_active_apps','ui_typing.unit_cpm','ui_typing.heatmap_hour_chars_abbrev','ui_typing.col_app','ui_typing.col_chars','ui_typing.col_active_time'];
			for(const key of keys) assert.ok(typeof locale.strings[key]==='string'&&locale.strings[key].length>0,`${locale.name} supplies ${key}`);
			const assertLocale=()=>{
				assert.equal(page.elements.get('apps_val').innerHTML,`1<span class="stat-unit">${locale.strings['ui_typing.unit_active_apps']}</span>`,`${locale.name} localizes the active-app count`);
				assert.equal(page.elements.get('apps_fastest').innerHTML,`Editor.exe (600 ${locale.strings['ui_typing.unit_cpm']})`,`${locale.name} localizes the speed unit`);
				assert.equal(page.elements.get('apps_top_volume').innerHTML,`Editor.exe (300 ${locale.strings['ui_typing.heatmap_hour_chars_abbrev']})`,`${locale.name} localizes the character abbreviation`);
				for(const key of ['ui_typing.col_app','ui_typing.col_chars','ui_typing.col_active_time','ui_typing.unit_cpm']) assert.ok(page.elements.get('apps_table_container').innerHTML.includes(locale.strings[key]),`${locale.name} refreshes the dynamic app table header`);
			};
			const posts=page.posts.length;
			page.context._i18n_locale=locale.name.slice(0,-5);
			page.context.i18n_apply(locale.strings);
			assertLocale();
			assert.equal(page.posts.length,posts,'a locale change renders admitted app data without a native query');
			deliverTypingManifest(page,host,manifest,{revision:++revision});
			assertLocale();
			typingAppLocaleApplications++;
		}
		assert.equal(page.diagnostics.some(entry=>entry.level==='error'),false);
	});
}
assert.equal(typingAppLocaleApplications,typingCaptionCatalogues.length*3);
assert.equal(passed,1228,'all app activity locale and native-refresh controls must execute');

'''+a);p.write_text(s)
