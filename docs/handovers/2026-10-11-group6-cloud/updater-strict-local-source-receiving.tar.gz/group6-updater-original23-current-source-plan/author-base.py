from pathlib import Path
import hashlib,json,difflib,tarfile,io
r=Path(__file__).resolve().parent
original=(r/'held/source/tools/ci/run-windows-updater-original-diagnostic-cohort.cjs').read_text()
sha=lambda b:hashlib.sha256(b).hexdigest()
cstart=original.index('const ORACLE_PATH =');cend=original.index('function admittedContext()',cstart)
fstart=original.index('function readSourceFile(');fend=original.index('\nconst budgetMs =',fstart)
constants=original[cstart:cend];functions=original[fstart:fend]
module_rel='tools/ci/windows-updater-original-source.cjs'
constants_new=constants.replace("\t'tools/ci/windows-updater-original-diagnostic-cohort-inputs.json',","\t'tools/ci/windows-updater-original-diagnostic-cohort-inputs.json',\n\t'tools/ci/windows-updater-original-source.cjs',",1)
assert constants_new!=constants and constants_new.replace("\n\t'tools/ci/windows-updater-original-source.cjs',",'',1)==constants
module="// G6 original updater Source-only receiving; import acquires no Source/native child.\n'use strict';\nconst fs = require('node:fs');\nconst path = require('node:path');\nconst crypto = require('node:crypto');\nconst { execFileSync } = require('node:child_process');\nconst inputs = require('./windows-updater-original-diagnostic-cohort-inputs.json');\nconst root = path.resolve(__dirname, '../..');\nconst sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');\nconst demand = (ok, message) => {\n\tif (!ok) throw new Error(message);\n};\n\n"+constants_new+functions+"\n\nmodule.exports = { readSourceFile, candidateSourceReceipt };\n"
runner=original[:cstart]+original[cend:fstart]+original[fend:]
importline="const { readSourceFile, candidateSourceReceipt } = require('./windows-updater-original-source.cjs');\n"
anchor="const inputs = require('./windows-updater-original-diagnostic-cohort-inputs.json');\n";assert runner.count(anchor)==1;runner=runner.replace(anchor,anchor+importline,1)
ending="main().catch((error) => {\n\tconsole.error(error);\n\tprocess.exit(1);\n});\n";assert runner.endswith(ending)
runner=runner[:-len(ending)]+"if (require.main === module) {\n"+ending+"}\n"
fn=original[original.index('async function child('):original.index('\nasync function main(')+1]
assert len(fn.encode())==2307 and sha(fn.encode())=='c768c56624297229b9886e1aae3bf3e786aceef7a2b667abceffb450727d7464';assert fn in runner
restored=runner.replace(importline,'',1)
restored=restored[:restored.index('if (require.main === module) {\n')]+ending
cfstart=restored.index('function admittedContext()');cfend=restored.index('\nconst budgetMs =')
restored=restored[:cfstart]+constants+restored[cfstart:cfend]+functions+restored[cfend:]
assert restored==original
files=[('tools/ci/run-windows-updater-original-diagnostic-cohort.cjs',runner.encode()),(module_rel,module.encode()),('tools/ci/windows-updater-original-diagnostic-cohort-inputs.json',(r/'held/source/tools/ci/windows-updater-original-diagnostic-cohort-inputs.json').read_bytes()),('tools/ci/windows-updater-original-label-oracle.json',(r/'held/source/tools/ci/windows-updater-original-label-oracle.json').read_bytes())]
for rel,b in files:
 p=r/'proposal-candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
with tarfile.open('/workspace/ergopti/docs/handovers/2026-10-11-group6-cloud/windows-original23-held-preparation-preservation.tar.gz') as t:
 inner=t.extractfile('windows-original23-held-preparation/proposal/original23-portable-successor.tar.gz').read()
 with tarfile.open(fileobj=io.BytesIO(inner)) as a:(r/'original-oracle7925.json.raw').write_bytes(a.extractfile('precursor-receiving/original-oracle7925.json.raw').read())
oracle0=(r/'original-oracle7925.json.raw').read_bytes();oracle1=(r/'proposal-candidate/tools/ci/windows-updater-original-label-oracle.json').read_bytes()
assert len(oracle0)==7925 and sha(oracle0)=='241365de04cd546cdd720a8b8e23e1ee714738f1148caad3dfd41f3632ef1c1e' and json.loads(oracle0)==json.loads(oracle1)
changes=[]
for rel,b in files:changes.append({'path':rel,'canonical_preimage':'ABSENT','candidate_bytes':len(b),'candidate_sha256':sha(b)})
(r/'source-only-preservation.json').write_text(json.dumps({'qualification':'SOURCE_ONLY_UNFORMATTED_UNPARSED_UNRUN','paths':changes,'original_runner_whole_inverse_exact':True,'module_original_function_definition_bytes_exact':True,'module_only_source_scope_addition':module_rel,'child_bytes':2307,'child_sha256':sha(fn.encode()),'oracle_original_bytes':7925,'oracle_original_sha256':sha(oracle0),'oracle_transport_bytes':len(oracle1),'oracle_transport_sha256':sha(oracle1),'oracle_data_equal_without_derivation':True,'budgets_unchanged':[300000,30000,1320000],'two_output_provenance_branch':'NOT_AUTHORED_NO_CANONICAL_PRODUCER_API_OR_CURRENT_PROFILE','first_source_author_refusal':'Frozen child span excluded its original final LF (2306 vs2307); boundary corrected, original2307 hash unchanged; no runtime/test result.'},indent=2)+'\n')
for inverse in [False,True]:
 text=''
 for rel,b in files:
  b=b.decode();a,c=(b,'') if inverse else ('',b)
  text+=''.join(difflib.unified_diff(a.splitlines(True),c.splitlines(True),fromfile='a/'+rel if inverse else '/dev/null',tofile='/dev/null' if inverse else 'b/'+rel))
 (r/('canonical-base.inverse.patch' if inverse else 'canonical-base.patch')).write_text(text)
print(json.dumps(changes))
