from pathlib import Path
import subprocess,json,os,re,datetime
from zoneinfo import ZoneInfo
root=Path('/workspace/ergopti-windows-r6-tests');out=Path('/workspace/scratch/windows-adapter-contract-followup/boolean')
env=dict(os.environ,WINEPREFIX='/workspace/toolchain/wine-r3-metrics-owned',WINEPATH=r'Z:\workspace\toolchain\node-v22.22.2-win-x64;Z:\workspace\toolchain\mingit-2.56.0.4-x64\cmd')
selection='Z:'+str(out/'selected90-names.txt').replace('/',chr(92))
argv=['timeout','--kill-after=5s','600s','xvfb-run','-a','bash','tools/test/run-ahk-under-wine.sh','--ahk','/workspace/toolchain/ahk/AutoHotkey64.exe','--runner','run_all.ahk','--results',str(out/'green.tap'),'--','--list='+selection]
with (out/'green.log').open('w') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
p=out/'green.tap';tap=p.read_text(errors='replace') if p.exists() else ''
passed=[line for line in tap.splitlines() if re.match(r'^ok \d+ - ',line) and ' # SKIP ' not in line]
record={'exit_code':r.returncode,'argv':argv,'planned':int(re.search(r'^1\.\.(\d+)',tap,re.M).group(1)) if re.search(r'^1\.\.(\d+)',tap,re.M) else 0,'passed':len(passed),'failed':re.findall(r'^not ok .*',tap,re.M),'not_executed':re.findall(r'^ok .* # SKIP .*',tap,re.M),'ended_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'native_windows_qualified':False}
(out/'green-results.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2));raise SystemExit(r.returncode)
