#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import json,re
out=Path('/workspace/scratch/windows-audit-round6/lifecycle');w=out.parent/'verification-worker'
r=json.loads((w/'receipts/462-lifecycle-menu-population-green-all-exit.json').read_text());assert r['exit_code']==0,r
count=json.loads((out/'menu-population-admission-expected-count.json').read_text())['literal_registered_cases'];assert count==18
text=(w/'462-lifecycle-menu-population-green-all.tap').read_text(encoding='utf-8-sig');assert '# 18 passed, 0 failed.' in text
pairs=re.findall(r'^ok (\d+) - (.+)$',text,re.M);assert len(pairs)==18 and {int(x[0]) for x in pairs}==set(range(1,19))
CHECK
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
for p,h in json.loads((out/'menu-population-admission-candidate-hashes.json').read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
CHECK
git add -- static/ergopti_plus/windows/infra/menu_population.ahk static/ergopti_plus/windows/tests/unit/ui/menu/test_menu_population.ahk
git commit -F /workspace/scratch/windows-audit-round6/lifecycle/menu-population-admission-commit-message.txt
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
for p,h in json.loads((out/'menu-population-admission-candidate-hashes.json').read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
print(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
CHECK
