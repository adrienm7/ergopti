"""Compose only after explicitly pinned qualified143/root-client inputs arrive.

This authoring tool makes no live checkout/index/ref changes and runs no suites.
It retains every base helper/test body, fixed existing selector, and root cleanup.
"""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json

BASE = Path(__file__).resolve().parent
CLOCK = BASE / 'retained-clock-inputs'
parser = argparse.ArgumentParser()
parser.add_argument('--base143', required=True, type=Path)
parser.add_argument('--base143-test-sha256', required=True)
parser.add_argument('--base143-registry-sha256', required=True)
parser.add_argument('--client', required=True, type=Path)
parser.add_argument('--client-sha256', required=True)
args = parser.parse_args()

def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()

def functions(source):
    result = {}
    def visit(node, prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                name = prefix + child.name
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    assert name not in result
                    result[name] = ast.get_source_segment(source, child)
                visit(child, name + '.')
            else:
                visit(child, prefix)
    visit(ast.parse(source))
    return result

def count(source):
    return sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test') for node in ast.walk(ast.parse(source)))

TEST = 'tools/test/macos_native_http_receiving_facts_test.py'
REGISTRY = 'tools/test/test-managed-ollama-protocol.cjs'
CLIENT = 'static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
MAIN = 'static/ergopti_plus/macos/tests/support/native_http_fixture_main.swift'
controls = (BASE / 'candidate/tools/test/macos_native_http_clock_contract_controls.py').read_text()
assert count(controls) == 13
before_test = (args.base143 / TEST).read_text()
before_registry = (args.base143 / REGISTRY).read_text()
before_client = args.client.read_text()
assert sha(before_test) == args.base143_test_sha256
assert sha(before_registry) == args.base143_registry_sha256
assert sha(before_client) == args.client_sha256
assert count(before_test) == 103
assert 'NATIVE_FIXTURE_BUILD_CONTROLS.enrolled_cases()' in before_test
assert 'patch.object(WIRE.WireFixture, "__new__"' not in before_test
anchor = '\n\nif __name__ == "__main__":\n'
addition = '''\n\n# Fixed-path clock frame/context enrollment. These portable13 controls do not
# execute the native TestCase or qualify Darwin samples, recipe or clock epoch.
NATIVE_FIXTURE_CLOCK_CONTROLS = load(
    "macos_native_http_clock_contract_controls",
    ROOT / "tools/test/macos_native_http_clock_contract_controls.py",
)
(
    NativeFixtureClockFrameContractControls,
    NativeFixtureClockContextContractControls,
) = NATIVE_FIXTURE_CLOCK_CONTROLS.enrolled_cases()
'''
assert before_test.count(anchor) == 1
after_test = before_test.replace(anchor, addition + anchor, 1)
assert after_test.replace(addition + anchor, anchor, 1) == before_test
assert functions(after_test) == functions(before_test)
# Preserve the exact unique owning entry and every status/failure/skip predicate.
old_entry = "cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 143]);"
new_entry = "cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 156]);"
assert before_registry.count(old_entry) == 1
assert new_entry not in before_registry
after_registry = before_registry.replace(old_entry, new_entry, 1)
assert after_registry.replace(new_entry, old_entry, 1) == before_registry
inv = json.loads((CLOCK / 'exact-client-inverse.json').read_text())
after_client = before_client
for kind in ('imports', 'helper', 'call'):
    where = inv[kind + '_anchor']
    inserted = inv[kind + '_addition']
    assert after_client.count(where) == 1
    after_client = after_client.replace(where, inserted + where if kind == 'helper' else where + inserted, 1)
restored = after_client
for kind in ('call', 'helper', 'imports'):
    where, inserted = inv[kind + '_anchor'], inv[kind + '_addition']
    restored = restored.replace(inserted + where if kind == 'helper' else where + inserted, where, 1)
assert restored == before_client
old_functions, new_functions = functions(before_client), functions(after_client)
assert all(new_functions[name] == body for name, body in old_functions.items() if name != 'RealNativeClientReceiving.setUpClass')
assert new_functions['RealNativeClientReceiving.setUpClass'].replace(inv['call_addition'], '', 1) == old_functions['RealNativeClientReceiving.setUpClass']
assert new_functions['RealNativeClientReceiving.tearDownClass'] == old_functions['RealNativeClientReceiving.tearDownClass']
preimages = {TEST: before_test, REGISTRY: before_registry, CLIENT: before_client, MAIN: (CLOCK / 'preimage' / MAIN).read_text()}
candidates = {TEST: after_test, REGISTRY: after_registry, CLIENT: after_client, MAIN: (CLOCK / 'candidate' / MAIN).read_text()}
for directory, sources in (('preimage', preimages), ('candidate', candidates)):
    for rel, source in sources.items():
        path = BASE / directory / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source)
(BASE / 'proposal.patch').write_text(''.join(''.join(difflib.unified_diff(preimages[rel].splitlines(keepends=True), candidates[rel].splitlines(keepends=True), fromfile='a/' + rel, tofile='b/' + rel)) for rel in preimages) + ''.join(difflib.unified_diff([], controls.splitlines(keepends=True), fromfile='/dev/null', tofile='b/tools/test/macos_native_http_clock_contract_controls.py')))
(BASE / 'enrollment-inverse.json').write_text(json.dumps({'owning_anchor': anchor, 'owning_addition': addition, 'registry_before_entry': old_entry, 'registry_after_entry': new_entry, 'before_count': 143, 'after_count': 156, 'client': inv}, indent=2) + '\n')
(BASE / 'composition-manifest.json').write_text(json.dumps({'qualification': 'SOURCE_ONLY_UNFORMATTED_UNRUN_NO_ADOPTION_NO_NATIVE_CREDIT', 'files': {rel: {'preimage': sha(preimages[rel]), 'candidate': sha(candidates[rel])} for rel in preimages}, 'old103_existing33_and_root7_body_vectors': 'BYTE_EXACT_UNCHANGED', 'new13': 'EXACT_FIXED_SELECTOR', 'client_root_cleanup': 'UNCHANGED_BY_EXACT_CALL_INVERSE', 'unexecuted': ['portable156', 'native Swift compile', 'Darwin16 calibration', 'full canonical gates', 'ARM/AMD source-receiving', 'SDK49', 'PAC14', 'E2E', 'packaging', 'installation']}, indent=2) + '\n')
