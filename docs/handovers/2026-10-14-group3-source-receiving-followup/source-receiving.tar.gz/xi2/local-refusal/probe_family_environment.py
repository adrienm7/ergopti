"""Fresh exact child/process namespace and original constructor refusal observation."""
from pathlib import Path
import ctypes
import importlib.util
import json
import os
import platform
import threading
import traceback
import uuid

base=Path(__file__).parent
source=base/'source/static/ergopti_plus/linux/tests/hardware/native_fixture_family.py'
pid,tid=os.getpid(),threading.get_native_id()
row={'pid':pid,'native_tid':tid,'cwd':os.getcwd(),'kernel':platform.uname()._asdict(),'files':{},'links':{},'GHA':'NOT_READ_OR_SUPPLIED','native_children':0}
for name in ['/proc/self','/proc/thread-self','/proc/self/ns/pid','/proc/self/ns/pid_for_children','/proc/self/ns/mnt']:
    try: row['links'][name]=os.readlink(name)
    except OSError as error: row['links'][name]={'type':type(error).__name__,'errno':error.errno}
for name in [f'/proc/self/task/{pid}/children',f'/proc/{pid}/task/{pid}/children',f'/proc/self/task/{tid}/children','/proc/thread-self/children']:
    try: row['files'][name]={'contents':Path(name).read_text()}
    except OSError as error: row['files'][name]={'type':type(error).__name__,'errno':error.errno,'filename':error.filename}
row['task_entries']=[path.name for path in Path('/proc/self/task').iterdir()]
row['status']={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('Pid:','Tgid:','PPid:','NSpid:','Threads:'))}
libc=ctypes.CDLL(None,use_errno=True)
row['subreaper']={'result':libc.prctl(36,1,0,0,0),'errno':ctypes.get_errno()}
spec=importlib.util.spec_from_file_location('exact_family_constructor',source)
family=importlib.util.module_from_spec(spec);spec.loader.exec_module(family)
reader,writer=os.pipe()
try:
    try:
        family.Family(['/usr/bin/gcc','--version'],60,writer,uuid.uuid4().hex)
    except Exception as error:
        row['constructor']={'type':type(error).__name__,'errno':getattr(error,'errno',None),'filename':getattr(error,'filename',None),'traceback':traceback.format_exc()}
    else:
        row['constructor']={'status':'ADMITTED_NO_RUN'}
finally:
    os.close(reader);os.close(writer)
assert row['constructor']['type']=='FileNotFoundError' and row['constructor']['errno']==2
print(json.dumps(row,indent=2))
