// Independent obligations frozen before candidate execution; source/model only.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const corpusPath = '/workspace/ergopti-group5-work/lease-146-independent-FROZEN-qcj00j_k/FROZEN-RECEIVING-CORPUS.json';
const corpusBytes = fs.readFileSync(corpusPath);
assert.equal(crypto.createHash('sha256').update(corpusBytes).digest('hex'),
  '1e05b6c4fb24fb46597b55bc9be44777ccc7c78390a5d034c75dfe7e9615db72');
const candidate = require(path.resolve(process.argv[2]));
assert.equal(typeof candidate.evaluate, 'function', 'actual receiving function required');
const corpus = JSON.parse(corpusBytes);
let accepted = 0, refused = 0;
for (const row of corpus) {
  const result = candidate.evaluate(row.transcript, row.swift_status, row.tee_status);
  assert.equal(result.complete, row.expected_complete, row.name);
  assert.equal(result.scope, 'lease-native-only', row.name + '/scope');
  assert.equal(result.full_package_qualified, false, row.name + '/no full qualification');
  assert.ok(Array.isArray(result.errors), row.name + '/closed errors array');
  if (row.expected_complete) {
    assert.equal(result.completed, 146, row.name + '/completed');
    assert.deepEqual(result.errors, [], row.name + '/errors');
    accepted++;
  } else {
    assert.ok(result.errors.length > 0, row.name + '/actual refusal');
    refused++;
  }
}
assert.equal(accepted, 2);
assert.equal(refused, 42);
process.stdout.write(JSON.stringify({scope:'source-model-receiving-only', controls:44,
  pass:44, accepted, refused, failures:0, skips:0, native_executed:0}) + '\n');
