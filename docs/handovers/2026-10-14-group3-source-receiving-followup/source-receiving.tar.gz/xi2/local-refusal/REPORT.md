# Genuine local declared-XI2 component attempt: original-owner refusal

**Result: environment refusal before compiler/native scenarios.** No C3, ABI29, cookie-three, positive declared branch or installed/input/output/epoch qualification is claimed. Official GHA/Root-ownership receivers were not run or weakened. Canonical HEAD/index/worktree remains clean at `3f59f730a680ba4d8a509267b6b50d192789e317`.

## Authentic preparation

The owned compact `source/` has a genuine local Git commit `1c7886f4a2a9781a27e6b4c2f23a311c8e32e4d6` containing 22 source/dependency files. Its private Git object database has a read-only alternate to canonical objects; no canonical ref/index change or public branch was made. `SOURCE.json` records exact provenance. The original C3/display/family/C headers/witness, current `ef40b9fd` Probe and logger/display dependencies remain actual source images. Receiver files are the independently reviewed V3 source proposal, and catalogue/generator are the coherent frozen declaration proposal. The original nine diagnostic inputs plus two catalogue/generator inputs are genuine recorded source files; no GHA identity is invented.

`prepare-xi2-local-native-components.py` in the parent continuation directory retains the exact preparation command and Node renderer program. It calls the actual exported `render(data,read)` of the proposed generator, with genuine copied current dependencies. All complete returned outputs are written only inside the private source tree. Seven outputs are generated; the portable trust template is unchanged and **six outputs change**: installer, native runtime Lua, deb builder, rpm builder, PKGBUILD and Nix recipe. Each changed output matches the independently retained fifteen-path proposal's postimage exactly. `generator-proof.json` and `generator-output.diff` record the result. No workflow, PINS or inventory path was edited. This is genuine private generation, not an adopted canonical generator result or native packaging proof.

## Exact attempted invocation and refusal

Attempted:

```sh
python3 -B /workspace/.ergopti-cloud/continuation-2026-10-14/xi2-declared-local-native-components-v1/run_local_components.py
```

The independent-reviewable local program invokes the **unchanged** original `family_run` API, original C display owner and original declared Lua leader. It pins the actual private Git source before work, separately records actual system paths/modes/UIDs/hashes, derives DECLARED_SONAME from its genuine catalogue, and retains original 60-second compile/25-second native family budgets, C3 assertions and ABI/cookie/cleanup expectations. Original `system_file` is called only to observe its real ownership decision; it is never replaced or patched. The official wrappers require actual GHA context and UID0 system inputs. Here retained LuaJIT/Xvfb/SDK files are UID1000 and system X11/Xi files UID65534, so their original Root policy refuses. A separate local-component observation would not certify those missing official authorities.

The very first compiler family fails its original constructor admission. The real `actual/original-c3/compile.family.json` has exit 1 and one authenticated `stage="refused"` frame, with acquired/reaped/closed all zero and `namespace_absent=true`. No compiler child was launched; no X server, Probe or native library experiment was allocated. No retry or fallback bypass occurred.

`probe_family_environment.py` was then executed independently in a fresh real process. Its raw `actual/family-environment.stdout` establishes:

- Actual process PID equals actual native main-thread TID; `/proc/self` and `/proc/thread-self` links and PID/mount namespace links are recorded.
- `prctl(PR_SET_CHILD_SUBREAPER,1)` succeeds with result zero/errno zero.
- The required `/proc/self/task/<actual PID>/children`, `/proc/<actual PID>/task/<actual PID>/children` and `/proc/thread-self/children` reads all fail **ENOENT**.
- Calling the original `Family` constructor reproduces `FileNotFoundError` at its actual `children()` source read before child/namespace allocation. The source call is `Path(f"/proc/self/task/{os.getpid()}/children").read_text()` in `native_fixture_family.py`.

This disproves the suspected PID/TID mix for the observed execution. It establishes a missing required interface in this actual process namespace; the underlying kernel/mount configuration is not inferred. No compiler, C3/ABI/cookie/native or hardware success can be inferred from a safely refused owner.

## Retained result and next receiver

`actual/before.json` and `actual/REFUSAL.json` record all source/system hashes; all 22 tracked sources and all listed system inputs remain unchanged afterward. The genuine private commit remains intact. The original family source and all strict admission/receipt/native expectations remain unchanged. `run_local_components.py` is runnable in a suitable local environment using a fresh owned output copy; it will continue to refuse this environment unless the genuine required process-child interface is available. Do not reuse an existing `actual/` directory or relaunch the original debt owner.

Normal source guards, full unit/E2E suites, formatting gates and packaging were **not run in this local attempt**; earlier independent V3 portable/source review remains separate evidence. All positive native components are **UNRUN** because the prerequisite refused. `/dev/uinput`/`/dev/input` remain unavailable for device association; Xvfb property cookies would not prove Xorg/libinput/Writer/physical input even after a successful component run.

The next useful positive receiver is authentic hosted CI after Root's existing finite declaration/receiver/workflow custody and committed source receiving, or a local environment that genuinely supplies the original children/pidfd/Root policy. No source correction to the original owner is justified by this observed environment absence, and no bypass or fabricated GHA/source/native identity is proposed.
