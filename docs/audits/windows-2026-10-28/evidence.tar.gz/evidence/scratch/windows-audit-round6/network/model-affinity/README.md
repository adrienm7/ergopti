# Missing-model recovery custody

Commit: `cf460143624696ea62f230d8f5d25eae64577cef`.

Bug: an actual admitted private chat request retained its requested model, but a later HTTP 404 response could choose a different model for recovery consent and installation. Equivalent provider spellings also replaced the captured request spelling.

Actual old receipt 158: exact matching-model control passed; normalized alias returned the wrong authoritative spelling, and foreign/private-echo model names each acquired actual offer consent instead of being rejected (1 PASS / 3 FAIL). Tests use real public tags admission, actual filesystem terminal artifacts and PollCurl, real JSON/classification/offer code, and only OS transport/consent/install ports. No actual downloads, external network or user contents. This certifies offer/install identity, not a formatted logger privacy leak.

Correction: Windows terminal admission compares the canonical shared-normalized identity against captured presence_model, rejects mismatches with safe diagnostics/typed failure, and constructs matching recovery from the admitted spelling. Shared classifier unchanged.

Actual whole cohort 188: 23/23 PASS. Earlier 183 had 22 PASS / 1 FAIL because a legacy manually admitted fixture omitted captured model metadata; it now independently declares requested qwen2.5:7b, keeping both removed-model and missing-endpoint assertions. No production fallback or test weakening. Genuine proportional gates/hooks 210 passed 27 October 2026 01:29:40–01:29:52 Paris.

Sibling macOS source api_ollama.lua:2069–2074 also forwards the provider-derived missing model without comparing request identity; runtime-unverified, unchanged. Its non-200 branch separately logs provider error text (private-response source lead). Linux AI remains disabled/excluded.

Full native Windows suite/E2E and CI remain integration qualification. No push by this agent. See checkpoint.json/copies for exact receipts; patch cf46014362.patch is ready.
