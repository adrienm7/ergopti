# Independent Windows Delay source review

Status: SOURCE CLEAR for the exact five frozen candidate files in `review-manifest.json`. This is an inactive preparation for the partial integration; native Windows qualification remains pending.

Candidate: `/workspace/ergopti-delivery/full-group1-delay`; base: `88909124461a3dbdfe5b745453fe50333eb64adc`. No candidate, root checkout, index, ref or CI mutations were performed by this reviewer.

## Bounded corrections verified

All three rendered-menu fixtures in `test_tap_hold_hand_sections.ahk` now use the existing recursive `_CTC_ReleaseMenu(Rendered)` owner. Descendant callbacks and menus are released while held; foreign detached registrations retain dispatcher ownership. The previous native teardown blocker is resolved in source.

Nonfinite tests construct controlled IEEE double bits `0x7FF8000000000000` and `0x7FF0000000000000` through Buffer/NumPut/NumGet. Native type, `_isnan` and `_finite` assertions qualify the values before exercising refusal. These replace the unqualified CRT text-parser values; execution still requires Windows.

The separate top-level `_TH_DurationValueValid` helper requires Integer/Float, checks native float finiteness with `_finite`, then enforces the existing positive runtime bound. The public writer calls it before known-key catalogue validation and the existing transaction owner. The prompt calls the same helper on parsed seconds before rounding, rejects a zero rounded value, and now refuses a missing/non-string captured path before opening UI. The accidental intermediate insertion at a call site was caught and corrected; the exported repository definition checker now finds all four duration functions. The intermediate negative receipt remains in `finite-helper-insertion-control.log`.

## Reviewed source behavior

The writer mutates only the selected key's `time_activation_seconds` in a detached desired-state candidate. Existing dual master/child leases, staged durable write, authorization, atomic replacement and memory publication remain the sole persistence path. Each phase requires strict integer1 acknowledgement. Known-key checks reject case mismatches and injected section identities.

The new callback object captures each physical key separately and ignores native menu event arguments. The translated prompt reads effective per-key timing, accepts only the real InputBox Object/String result contract, rejects invalid/cancelled/nonfinite/out-of-range input, and checks source pointer and path after UI. It persists once, then reloads once only after accepted publication. Inherited Critical is defused during UI, I/O and reload and restored to callers.

All old transaction test bytes remain an exact prefix. Head tests retain their original four-row order, captions, payload shape, native positions and platform projection through a bounded head projection. The additional complete-tree test requires the fifth genuine custom-delay submenu. HIGH07 retains existing registration/data assertions and adds the explicit head-before-delay-tail declaration check.

## Checks executed on the final bytes

- UTF-8 BOM/LF: passed, 1830 AHK files.
- AHK v2 syntax antipatterns: passed, 1815 Windows sources.
- Loop-capture guard: passed, 14 independent self-test fixtures.
- Translated Format placeholders: passed, 16 Windows calls across 21 locales.
- Exported verify-change function-definition checker: all four duration functions found.
- Exported verify-change test-registration checker: all three changed native test files reachable, zero errors.

Logs and exact five-file pre/post hashes are in this directory. The initial RTK launcher could not initialize its default read-only HOME cache; actual checks ran as direct children with stdout captured into these evidence files, as the repository launcher contract permits for logged/parsed output.

## Pending qualification and retained limits

Native AHK unit/meta, E2E, resident startup, packaging/installation and physical Windows interaction were not executed: no native AHK interpreter or Wine is available. This source review cannot substitute for those gates. Tests isolate existing MasterGate ownership by temporarily disabling initialization; no newly executed master-off integration result is claimed.

The neutral `menu.tapholds.key_tap_delay_dialog_prompt_current` key, all 21 real translations, shared Delay/check template/compiler records and root-owned generator publication remain prerequisites. Those shared sources are outside this five-file review.

The existing writer's scalar serializer retains its established Boolean-versus-integer representation limit (`_TH_TomlFormatLine` checks numeric types first); this packet does not repair or claim general typed Boolean roundtrip preservation. Existing persisted TOML content uses CRLF (`Content .= L . "`r`n"`); source files retain BOM/LF, but this packet does not claim new runtime LF behavior. Root-level unknown fields/nested structured values remain outside the existing writer's supported serialization contract. These are disclosed legacy limits, not newly completed capabilities.
