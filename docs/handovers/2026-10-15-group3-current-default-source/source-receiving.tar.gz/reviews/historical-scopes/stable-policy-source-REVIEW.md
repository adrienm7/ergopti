# Independent source review: eb6 stable qualification policy

**SOURCE_CLEAR, bounded to the policy successor.** This is a read-only review of immutable `eb6cd9db17c9ebbe4dfdbba1d05141e394d777eb`; no subjects, policy consumer, workflow, parser, compiler or native process were executed. This does not admit a NumberRow projection/envelope, prove current 135/159 inputs, or qualify native release roles.

## Exact images

Actual API-received sources are under `../number-row-root-eb6-eleven-source-map-v1/root-sources/`; the supplier retained complete tree and blob responses. The reviewed policy is `.github/ci/stable_release_qualification_exception.json`, mode `100644`, blob `e9cf49c3f5c76b92cfe5b0bbd9c03f9874f5eecc`, 6803 bytes, SHA256 `3e9c51bc50682eb2bec4f2d3750f8379e12938798556a8c755e1c8d864a49dd3`. Original99 policy blob is `06896dfbc71360294595d0657575b68a3a1f338f`, SHA256 `0b26059b9b266b2890ad340df1920b89414c88c409f4c31b332d06508ba07aa1` (the local original Git object was read directly).

The exact eb6 consumer is `tools/ci/dev-release-qualification.cjs`, blob `2b1abb91928a9d8520cd670deebeac69b71066c9`, 29950 bytes, SHA256 `f300cc10378707359bce239cacbb2ee790a026fb0f9463f58636f725e3857bc8`. The exact eb6 `Package.swift` is 6084 bytes, SHA256 `34861f7e4a3520342f911ded13896941fa5e227c0a171b9258f38eebc8ac5b3f`. Exact eb6 `ci-macos.yml` is 165616 bytes, SHA256 `b0ccba5f409676d6670f9f1b9c4dd3a28cc2c7d478587a8922fdf72f718d831c`. These are not later private Root workflow edits or canonical-current substitutes.

## Complete policy delta and authority

The literal original-object/current-file diff has four route changes only: PAC, HTTP and model receiving name job `e2e-hs` instead of `managed-ollama-native` (policy lines37,43,96); core JS names `.github/workflows/ci-common.yml` / `shared-validation` instead of `ci.yml` / `core` (lines89–90). Model argument formatting also collapses to one line. All 13 scope identities, kinds, reasons, other fields and the entire authorization note are unchanged. This updates source topology; it does not refresh an approval, extend expiry or enlarge omitted work.

The actual eb6 consumer pins these route literals in `STABLE_EXTRA_SCOPES` (lines47–92) and rejects changed closed command shapes (317–325). Its stable boundary is still exactly v1.0.0, `2026-10-10T02:00:00Z`, the same repository and main/push/release context (253–306). `eligible` requires literal GitHub Actions plus exact context equality and a finite clock before expiry (378–387). Automatic mismatch/expiry yields no profile; explicit ineligible selection throws (390–410). A null profile has no deferred scopes (412–417), and CLI full receipts require full execution rather than claiming qualification (619–637,813–837); CLI errors set exit status1 (end of file).

The separately authorized v1.0.1 policy already present in this exact consumer has its own closed validator and expiry; it is not inherited authority from this v1.0.0 image. The four route edits grant no next-tag deferral. At the current date this legacy policy is expired.

The actual eb6 Package consumer returns no exclusions when no profile is selected (31–33), refuses unknown profiles and expired or mismatched real context (34–64), and admits only the exact one Brew test file (65–89). The actual eb6 Mac workflow locates these three native steps under job `e2e-hs` (163;909,979,1151); their original role/stage guards and source-bound receipt validation remain present (917–926,987–996,1159–1166). Full modes retain native execution. For core JS, this review corroborates the new path through the complete eb6 tree and exact consumer literal; the ci-common body was not received and is not claimed reviewed.

## Limits and disposition

No source blocker found in this policy-only successor. Root retains custody and decides adoption/composition. This review neither changes approval data nor establishes enrollment of the separate HTTP4 companion, the current four-controller SDK successor, a projection manifest, current installed/SDK native roles or full default Mac qualification. No runtime verdict is supplied.
