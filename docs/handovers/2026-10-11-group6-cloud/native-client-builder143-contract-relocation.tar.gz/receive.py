"""Serial actual portable owner receiving; no Apple compiler or native credit."""

import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

PACKET = Path(__file__).resolve().parent
REPO = Path("/workspace/ergopti")
PYTHON = "/workspace/ergopti-cloud/python/bin/python3"
BUILDER = "static/ergopti_plus/macos/tests/support/native_http_fixture_builder.py"
CLIENT = "static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py"
DIAGNOSTIC = "tools/diagnostics/macos_native_wire_swift_dependencies_test.py"
PAC = "tools/test/test-native-pac-source-contract.cjs"
MODEL = "tools/diagnostics/macos_managed_ollama_receiving.py"
NODE = "/workspace/ergopti-cloud/node-v22.22.2-linux-x64/bin/node"

tree = ast.parse((PACKET / "candidate" / DIAGNOSTIC).read_bytes())
fixed = next(n.value for n in tree.body if isinstance(n, ast.Assign)
             and [ast.unparse(t) for t in n.targets] == ["RECIPE_INPUTS"])
inputs = [BUILDER if isinstance(n, ast.Name) and n.id == "BUILDER"
          else ast.literal_eval(n) for n in fixed.elts]
assert len(inputs) == len(set(inputs)) == 18

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def physical_tree(target, proposed):
    for relative in inputs + [CLIENT, DIAGNOSTIC, PAC, MODEL]:
        source = PACKET / "candidate" / relative
        if not proposed or not source.is_file():
            source = REPO / relative
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
    return {r: digest((target / r).read_bytes()) for r in inputs + [CLIENT, DIAGNOSTIC, PAC, MODEL]}

facts = {"qualification": "actual portable source/staging/cleanup; modeled compiler owner; no native credit",
         "results": []}

with tempfile.TemporaryDirectory(prefix="ergopti-builder-contract-") as name:
    outer = Path(name)
    original, proposed = outer / "original", outer / "proposed"
    facts["original_physical_inputs"] = physical_tree(original, False)
    facts["candidate_physical_inputs"] = physical_tree(proposed, True)
    temporary = outer / "temporary"
    temporary.mkdir(mode=0o700)
    env = dict(os.environ, TMPDIR=str(temporary), PYTHONDONTWRITEBYTECODE="1")
    harness = outer / "receive-pac-check.cjs"
    harness.write_text(r'''const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const {spawnSync}=require('node:child_process');
const root=process.argv[2];
const source=fs.readFileSync(path.join(root,'tools/test/test-native-pac-source-contract.cjs'),'utf8');
const first="check('standalone-native-producers-copy-hash-and-compile-the-source-owner', () => {";
const last="check('existing-linux-python-policy-admission-is-unchanged', () => {";
assert.equal(source.split(first).length,2);assert.equal(source.split(last).length,2);
const block=source.slice(source.indexOf(first),source.indexOf(last));
let passed=0;
vm.runInNewContext(block,{fs,path,assert,spawnSync,root,
 pythonExecutable:()=>process.argv[3],check:(_label,action)=>{action();passed++;}},
 {filename:path.join(root,'tools/test/test-native-pac-source-contract.cjs'),timeout:15000});
assert.equal(passed,1);console.log('ACTUAL_PAC_OWNER_CHECK=PASS1');
''')

    def run(label, arguments, expected, cwd):
        result = subprocess.run(arguments, cwd=cwd, env=env, capture_output=True,
                                text=True, timeout=30)
        (PACKET / (label + ".stdout.log")).write_text(result.stdout)
        (PACKET / (label + ".stderr.log")).write_text(result.stderr)
        record = {"label": label, "command": arguments, "status": result.returncode,
                  "expected_status": expected,
                  "stdout_sha256": digest(result.stdout.encode()),
                  "stderr_sha256": digest(result.stderr.encode()),
                  "traceback_import_error": "ImportError" in result.stderr,
                  "assertion_error": "AssertionError" in result.stderr,
                  "retained_private_roots": sorted(p.name for p in temporary.iterdir())}
        facts["results"].append(record)
        assert result.returncode == expected, label + ": unexpected child status"
        return result

    before = run("original10-red", [PYTHON, "-I", "-B", str(original / DIAGNOSTIC)], 1, original)
    assert "Ran 10 tests" in before.stderr and "FAILED (errors=10)" in before.stderr
    # Only the outer test owner removes its own exact private receiving tree.
    # This observation does not settle a native child or authorize caller cleanup.
    retained = sorted(temporary.iterdir())
    facts["original10_retained_root_count"] = len(retained)
    for root in retained:
        assert root.parent == temporary and root.name.startswith("ergopti-native-client-app-")
        assert root.is_dir() and not root.is_symlink()
        shutil.rmtree(root)
    facts["original10_exact_outer_cleanup_complete"] = not any(temporary.iterdir())

    after = run("candidate10-green", [PYTHON, "-I", "-B", str(proposed / DIAGNOSTIC)], 0, proposed)
    assert "Ran 10 tests" in after.stderr and after.stderr.rstrip().endswith("OK")
    assert not any(temporary.iterdir()), "candidate caller retained an owned build root"
    oldpac = run("original-pac-owner-red", [NODE, str(harness), str(original), PYTHON], 1, original)
    assert "AssertionError" in oldpac.stderr and "pac_source = source" in oldpac.stderr
    run("candidate-pac-owner-green", [NODE, str(harness), str(proposed), PYTHON], 0, proposed)

    builder_path = proposed / BUILDER
    pristine = builder_path.read_bytes()
    mutants = (
        ("source-guard-omission-red", b"if _digest(_source(relative)) != digest:", b"if False:"),
        ("staged-guard-omission-red", b"if _digest(regular_bytes(path)[0]) != digest:", b"if False:"),
        ("compiler-pac-omission-red", b"*map(str, swift),",
         b'*map(str, [path for path in swift if path.name != "ManagedPACSource.swift"]),'),
    )
    for label, old, new in mutants:
        assert pristine.count(old) == 1
        changed = pristine.replace(old, new)
        try:
            builder_path.write_bytes(changed)
            received = run(label, [NODE, str(harness), str(proposed), PYTHON], 1, proposed)
            assert "AssertionError" in received.stderr and "ImportError" not in received.stderr
            facts["results"][-1]["actual_mutant_sha256"] = digest(changed)
        finally:
            builder_path.write_bytes(pristine)
        assert builder_path.read_bytes() == pristine

    caller = proposed / CLIENT
    original_caller = caller.read_bytes()
    target = b'Path(__file__).with_name("native_http_fixture_builder.py")'
    assert original_caller.count(target) == 1
    try:
        changed = original_caller.replace(target, b'Path(__file__).with_name("foreign_builder.py")')
        caller.write_bytes(changed)
        received = run("wrong-fixed-loader-red", [NODE, str(harness), str(proposed), PYTHON], 1, proposed)
        assert "AssertionError" in received.stderr and "ImportError" not in received.stderr
        facts["results"][-1]["actual_mutant_sha256"] = digest(changed)
    finally:
        caller.write_bytes(original_caller)

    diagnostic = proposed / DIAGNOSTIC
    original_diagnostic = diagnostic.read_bytes()
    target = b'write(destination, b"foreign native trust source")'
    assert original_diagnostic.count(target) == 1
    try:
        changed = original_diagnostic.replace(target, b"pass")
        diagnostic.write_bytes(changed)
        received = run("instrumentation-noop-red", [PYTHON, "-I", "-B", str(diagnostic),
                       "StandaloneSwiftDependencies.test_modified_certificate_copy_refuses_before_compiler"],
                       1, proposed)
        assert "Ran 1 test" in received.stderr and "FAILED (failures=1)" in received.stderr
        assert "modified source reached compiler" in received.stderr
        assert "errors=" not in received.stderr and "ImportError" not in received.stderr
        facts["results"][-1]["actual_mutant_sha256"] = digest(changed)
    finally:
        diagnostic.write_bytes(original_diagnostic)
    assert not any(temporary.iterdir())
    facts["candidate_sources_restored_exact"] = all(
        digest((proposed / relative).read_bytes()) == expected
        for relative, expected in facts["candidate_physical_inputs"].items())
    assert facts["candidate_sources_restored_exact"]
    facts["all_child_rounds_terminal"] = True
facts["outer_receiving_tree_retired"] = not outer.exists()
(PACKET / "receiving.json").write_text(json.dumps(facts, indent=2) + "\n")
print(json.dumps({"all_child_rounds_terminal": True,
                  "original10": "10ERROR_EXPECTED", "candidate10": "10PASS",
                  "pac_owner": "originalASSERT_RED_candidatePASS",
                  "meaningful_mutants": "5ASSERT_RED_0HELPER_ERROR",
                  "outer_receiving_tree_retired": facts["outer_receiving_tree_retired"]}))
