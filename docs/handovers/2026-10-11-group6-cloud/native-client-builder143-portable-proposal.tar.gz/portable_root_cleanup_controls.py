"""Real caller cleanup/file ownership; native owner/Security are modeled."""

import importlib.abc
import importlib.util
import json
import hashlib
import os
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

BASE = Path(__file__).resolve().parent
SUPPORT = BASE / "prospective-candidate/static/ergopti_plus/macos/tests/support"
RECEIVING = []


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class CleanupOwner:
    def __init__(self):
        self.closed = False
        self.command_group_debt = []
        self.command_file_debt = []
        self.trust_attempted = False
        self.keychain_created = False
        self.active = 0
        self.close_failure = None
        self.close_calls = 0

    def close(self):
        self.close_calls += 1
        if self.close_failure is not None:
            raise self.close_failure
        self.closed = True

    def receiving_facts(self):
        return {"active": self.active}


class ClientRootCleanupControls(unittest.TestCase):
    def setUp(self):
        self.private = tempfile.TemporaryDirectory(prefix="ergopti-root-closure-")
        self.outer = Path(self.private.name)
        self.client = load(
            "actual_cleanup_client", SUPPORT / "native_http_wire_client_receiving.py"
        )
        self.builder = load("actual_cleanup_builder", SUPPORT / "native_http_fixture_builder.py")
        self.owner = CleanupOwner()
        self.build = self.builder.OwnedFixtureBuild(self.owner, parent=self.outer)
        self.receipt = {
            "source_hashes": {},
            "binary_sha256": hashlib.sha256(b"EXPLICIT MODELED IMAGE").hexdigest(),
        }
        self.build.executable.parent.mkdir(parents=True)
        self.build.executable.write_bytes(b"EXPLICIT MODELED IMAGE")
        self.build.executable.chmod(0o700)
        self.build.receipt_path.write_text(json.dumps(self.receipt))
        self.primary = RuntimeError("EXACT MODELED BUILD FAILURE")
        self.descriptor = None
        self.renamed = None
        self.observation = {
            "method": self._testMethodName,
            "qualification": "actual POSIX files/FD; modeled native owner/Security",
        }

    def tearDown(self):
        if self.descriptor is not None:
            os.close(self.descriptor)
            self.descriptor = None
        self.private.cleanup()
        self.observation["outer_private_directory_retired"] = not self.outer.exists()
        self.observation["exact_outer_descriptor_retired"] = self.descriptor is None
        RECEIVING.append(self.observation)

    def bootstrap_failure(self):
        real_spec = importlib.util.spec_from_file_location
        build = self.build
        primary = self.primary

        class FailureBuild:
            def __new__(cls, fixture):
                self.assertIs(fixture, self.owner)
                return build

        class BuilderLoader(importlib.abc.Loader):
            def create_module(self, spec):
                return None

            def exec_module(self, module):
                module.OwnedFixtureBuild = FailureBuild

        def specific_spec(name, path, *arguments, **keywords):
            if name == "owned_native_http_build":
                self.assertEqual(Path(path), SUPPORT / "native_http_fixture_builder.py")
                return importlib.util.spec_from_loader(name, BuilderLoader())
            return real_spec(name, path, *arguments, **keywords)

        caught = None
        with (
            mock.patch.object(sys, "platform", "darwin"),
            mock.patch.dict(
                sys.modules,
                {
                    "httpx": SimpleNamespace(__version__="0.28.1"),
                    "huggingface_hub": SimpleNamespace(__version__="1.13.0"),
                },
            ),
            mock.patch.object(self.client.wire, "WireFixture", return_value=self.owner),
            mock.patch.object(importlib.util, "spec_from_file_location", side_effect=specific_spec),
            mock.patch.object(self.build, "build", side_effect=primary),
        ):
            try:
                self.client.RealNativeClientReceiving.setUpClass()
            except BaseException as failure:
                caught = failure
        self.observation.update(
            exact_primary=caught is primary,
            close_calls=self.owner.close_calls,
            root_present=self.build.root.exists(),
        )
        return caught

    def prepare_teardown(self):
        cls = self.client.RealNativeClientReceiving
        cls.fixture = self.owner
        cls.build = self.build
        cls.root = self.build.root
        cls.environment = {"ERGOPTI_LAUNCHER_EXECUTABLE": str(self.build.executable)}
        cls.receiving_workers = []
        return cls

    def capture_debt(self):
        self.descriptor = os.open(
            self.build.root / "physical-capture", os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600
        )
        self.owner.command_file_debt.append(SimpleNamespace(descriptor=self.descriptor))

    def test01OwnedBootstrapCleanupPreservesPrimary(self):
        caught = self.bootstrap_failure()
        self.assertIs(caught, self.primary)
        self.assertEqual(self.owner.close_calls, 1)
        self.assertFalse(self.build.root.exists())

    def test02BootstrapCaptureDebtRetainsRootAndPhysicalFD(self):
        self.capture_debt()
        caught = self.bootstrap_failure()
        self.assertIs(caught, self.primary)
        self.assertIsInstance(caught.__cause__, RuntimeError)
        self.assertEqual(self.owner.close_calls, 1)
        self.assertTrue(self.build.root.is_dir())
        self.assertEqual(os.fstat(self.descriptor).st_nlink, 1)
        self.observation["capture_fd_open_before_outer_cleanup"] = True

    def test03BootstrapCloseFailurePreservesExactPrimary(self):
        close_failure = OSError("EXACT MODELED PHYSICAL CLOSE FAILURE")
        self.owner.close_failure = close_failure
        caught = self.bootstrap_failure()
        self.assertIs(caught, self.primary)
        self.assertIs(caught.__cause__, close_failure)
        self.assertEqual(self.owner.close_calls, 1)
        self.assertFalse(self.owner.closed)
        self.assertTrue(self.build.root.is_dir())
        self.assertIs(self.client.RealNativeClientReceiving.root_cleanup_failures[0], close_failure)

    def test04OwnedTeardownRunsOriginalReceiptChecksThenRemovesRoot(self):
        cls = self.prepare_teardown()
        cls.tearDownClass()
        self.assertEqual(self.owner.close_calls, 1)
        self.assertFalse(self.build.root.exists())
        self.observation["root_present"] = self.build.root.exists()

    def test05ForeignTeardownRootSurvivesBeforeReceiptReads(self):
        cls = self.prepare_teardown()
        self.renamed = self.build.root.with_name(self.build.root.name + "-exact-owned")
        self.build.root.rename(self.renamed)
        shutil.copytree(self.renamed, self.build.root)
        marker = self.build.root / "foreign-owner-marker"
        marker.write_bytes(b"KEEP FOREIGN ROOT")
        with self.assertRaises(self.builder.BuildRefused):
            cls.tearDownClass()
        self.assertEqual(self.owner.close_calls, 1)
        self.assertTrue(marker.is_file())
        self.assertTrue(self.renamed.is_dir())
        self.observation.update(
            foreign_root_retained=marker.is_file(), exact_owned_root_retained=self.renamed.is_dir()
        )

    def test06TeardownCaptureDebtRetainsRootAndPhysicalFD(self):
        self.capture_debt()
        cls = self.prepare_teardown()
        with self.assertRaisesRegex(RuntimeError, "root cleanup remains unsettled"):
            cls.tearDownClass()
        self.assertEqual(self.owner.close_calls, 1)
        self.assertTrue(self.build.root.is_dir())
        self.assertEqual(os.fstat(self.descriptor).st_nlink, 1)
        self.observation.update(
            root_present=self.build.root.is_dir(), capture_fd_open_before_outer_cleanup=True
        )


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(ClientRootCleanupControls)
    )
    (BASE / "additional-root-cleanup-receiving.json").write_text(
        json.dumps(
            {
                "run": result.testsRun,
                "failures": len(result.failures),
                "errors": len(result.errors),
                "skipped": len(result.skipped),
                "receiving": RECEIVING,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    raise SystemExit(not result.wasSuccessful())
