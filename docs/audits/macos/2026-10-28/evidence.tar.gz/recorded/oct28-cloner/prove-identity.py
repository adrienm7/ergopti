from pathlib import Path
import subprocess,json,os,stat,sys,time,signal,ctypes,hashlib,plistlib,re,datetime
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-picker-observer');root=Path('/workspace/scratch/oct28-cloner/identity-proof');root.mkdir(mode=0o700)
resources=w/'static/ergopti_plus/macos/apps/App Cloner.app/Contents/Resources';port=w/'tools/test/lib/app-cloner-native-stat-port.cjs';node='/workspace/toolchain/node-v22.22.2-linux-x64/bin/node';epoch=str(int(time.time()));date_text=subprocess.check_output(['/bin/date'],text=True).strip();snap={n:hashlib.sha256((resources/n).read_bytes()).hexdigest() for n in ['clone_app.sh','make_shortcut.sh','reserve_bundle.sh','quote_launcher_values.py']}
if sys.platform=='linux':
 if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'Owned observer admission failed')
def retire(gid):
 deadline=time.monotonic()+5
 while time.monotonic()<deadline:
  if sys.platform=='linux':
   while True:
    try:child,_=os.waitpid(-gid,os.WNOHANG)
    except ChildProcessError:break
    if not child:break
  try:os.killpg(gid,0)
  except ProcessLookupError:return
  time.sleep(.01)
 raise RuntimeError('Owned group remains; exact fixture retained')
def executable(p,s):p.write_text(s);p.chmod(0o700)
rows=[]
for caller,shells in [('shortcut',['/usr/bin/bash','/usr/bin/zsh']),('clone',['/usr/bin/zsh'])]:
 for shell in shells:
  case=root/(caller+'-'+Path(shell).name);case.mkdir(mode=0o700);binary=case/'bin';binary.mkdir();home=case/'home';home.mkdir();source=case/'Source.app';(source/'Contents/MacOS').mkdir(parents=True);(source/'Contents/MacOS/Source').write_text('inert');(source/'Contents/Info.plist').write_bytes(plistlib.dumps({'CFBundleExecutable':'Source','CFBundleIdentifier':'org.fixture.source'}))
  subprocess.run([node,'-e','require(process.argv[1]).createNativeStatResources({resources:process.argv[2],fixtureRoot:process.argv[3],toBashPath:x=>x})',str(port),str(resources),str(case)],check=True,capture_output=True)
  ported=case/'native-stat-port-resources';actual=(resources/('make_shortcut.sh' if caller=='shortcut' else 'clone_app.sh')).read_text()
  executable(binary/'date','''#!/bin/sh
if [ "$#" = 0 ]; then printf '%s\\n' "$OWNED_DATE_TEXT"; exit 0; fi
[ "$#" = 1 ] && [ "$1" = '+%s' ] || exit 91
printf '%s\\n' "$OWNED_EPOCH"
''')
  executable(binary/'mktemp','''#!/bin/sh
[ "$#" = 2 ] && [ "$1" = -d ] && [ "$2" = "$OWNED_EXPECTED_TEMPLATE" ] || exit 92
created=$(/usr/bin/mktemp -d "$OWNED_TMP_TEMPLATE") || exit $?
printf '%s' "$created" > "$OWNED_WORKSPACE_RECEIPT" || exit $?
printf '%s\\n' "$created"
''')
  executable(binary/'qlmanage','''#!/bin/sh
[ "$#" = 6 ] && [ "$1" = -t ] && [ "$2" = -s ] && [ "$3" = 1024 ] && [ "$4" = -o ] && [ -f "$6" ] || exit 93
printf qlmanage\\n >> "$OWNED_ICON_RECEIPT"
printf png > "$5/icon.svg.png"
''')
  executable(binary/'sips','''#!/bin/sh
[ "$#" = 6 ] && [ "$1" = -z ] && [ "$2" = "$3" ] && [ -f "$4" ] && [ "$5" = --out ] || exit 94
printf sips\\n >> "$OWNED_ICON_RECEIPT"
printf png > "$6"
''')
  executable(binary/'iconutil','''#!/bin/sh
[ "$#" = 5 ] && [ "$1" = -c ] && [ "$2" = icns ] && [ -d "$3" ] && [ "$4" = -o ] || exit 95
printf iconutil\\n >> "$OWNED_ICON_RECEIPT"
printf icon > "$5"
''')
  buddy=binary/'PlistBuddy';executable(buddy,'''#!/bin/sh
[ "$#" = 3 ] && [ "$1" = -c ] && [ "$2" = 'Print :CFBundleExecutable' ] && [ "$3" = "$OWNED_SOURCE/Contents/Info.plist" ] || exit 96
printf '%s\\n' Source
''')
  if caller=='clone':
   boundary='log "USER_DATA_DIR=$USER_DATA_DIR"';assert actual.count(boundary)==1;prefix=actual[:actual.index(boundary)+len(boundary)]
   assert prefix.count('/usr/libexec/PlistBuddy')==1;prefix=prefix.replace('/usr/libexec/PlistBuddy',"'"+str(buddy)+"'")
   info_start='safe_name_xml="$(/usr/bin/python3 "$QUOTE_HELPER" xml "$safe_name")"';assert actual.count(info_start)==1;info=actual[actual.index(info_start):].split('\nPLIST\n',1)[0]+'\nPLIST\n'
   launch_start='cat > "$LAUNCHER" <<\'LAUNCHER_HEAD\'';assert actual.count(launch_start)==1;launch=actual[actual.index(launch_start):].split('\nLAUNCHER_BODY\n',1)[0]+'\nLAUNCHER_BODY\n'
   assert actual.count('LAUNCHER="$MACOS/launcher"')==1
   actual=prefix+'\n'+info+'\nLAUNCHER="$MACOS/launcher"\n'+launch+'\nCLONE_COMPLETE=1\nprintf \'%s\\n\' "$DEST"\n'
  script=ported/('make_shortcut.sh' if caller=='shortcut' else 'identity-prefix-clone.sh');executable(script,actual)
  children=[]
  for index in range(2):
   diag=case/('diag-'+str(index));diag.write_bytes(b'');workspace=case/('workspace-'+str(index));icons=case/('icons-'+str(index));env=dict(os.environ,PATH=str(binary)+os.pathsep+os.environ['PATH'],HOME=str(home),LC_ALL='C',OWNED_EPOCH=epoch,OWNED_DATE_TEXT=date_text,OWNED_WORKSPACE_RECEIPT=str(workspace),OWNED_TMP_TEMPLATE=str(case/('workspace-'+str(index)+'.XXXXXX')),OWNED_EXPECTED_TEMPLATE='/tmp/'+('shortcut' if caller=='shortcut' else 'appcloner')+'.XXXXXX',OWNED_ICON_RECEIPT=str(icons),REAL_PYTHON=sys.executable,OWNED_STAT_QUERY=str(case/'native-stat-query.py'),OWNED_STAT_FAULT='',OWNED_SOURCE=str(source))
   args=['Identity Collision','target','/Applications/Fixture.app','#123456','label'] if caller=='shortcut' else [str(source),'Identity Collision','','','tint','','0',str(diag)]
   child=subprocess.Popen([shell,str(script),*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);children.append((child,workspace,icons))
  creations=[]
  for child,workspace,icons in children:
   try:out,err=child.communicate(timeout=15)
   except subprocess.TimeoutExpired:
    if child.returncode is None:
     try:os.killpg(child.pid,signal.SIGKILL)
     except ProcessLookupError:pass
    child.communicate(timeout=5);retire(child.pid);raise
   retire(child.pid);assert child.returncode==0 and not err,(child.returncode,out,err);destination=Path(out.decode().removesuffix('\n'));assert destination.is_dir();metadata=plistlib.loads((destination/'Contents/Info.plist').read_bytes());temp=Path(workspace.read_text());assert temp.parent==case and not temp.exists()
   entry={'destination':str(destination),'bundle_identifier':metadata['CFBundleIdentifier'],'bundle_inode':destination.stat().st_ino,'workspace_retired':True,'actual_exit':child.returncode,'owned_group_retired':True}
   if caller=='shortcut':
    assert (destination/'Contents/MacOS/open_target').stat().st_mode&stat.S_IXUSR;receipt=icons.read_text();assert receipt=='qlmanagen'+('sipsn'*9)+'iconutiln',receipt;entry['execution_scope']='actual-full-shortcut-generator';entry['profile']='not applicable to shortcut'
   else:
    launcher=(destination/'Contents/MacOS/launcher').read_text();assignment=re.findall(r'^UNIQUE_ID=.*$',launcher,re.M);export=re.findall(r'^export __CFBundleIdentifier=.*$',launcher,re.M);profile=re.findall(r'^USER_DATA_DIR=.*$',launcher,re.M);assert len(assignment)==len(export)==len(profile)==1
    observed=subprocess.check_output([shell,'-c',assignment[0]+'\n'+profile[0]+'\n'+export[0]+'\nprintf \'%s\\0%s\\0\' "$__CFBundleIdentifier" "$USER_DATA_DIR"']);fields=observed.split(b'\0');assert fields[-1]==b'' and len(fields)==3;assert fields[0].decode()==metadata['CFBundleIdentifier'];assert Path(fields[1].decode()).is_dir();entry.update(profile=fields[1].decode(),launcher_environment_identifier=fields[0].decode(),execution_scope='actual-clone-prefix-through-profile plus actual Info.plist and launcher writers; no icons/signing/Dock/app launch')
   creations.append(entry)
  assert creations[0]['destination']!=creations[1]['destination'] and creations[0]['bundle_inode']!=creations[1]['bundle_inode'];assert creations[0]['bundle_identifier']==creations[1]['bundle_identifier']=='fr.b519hs.'+caller+'.'+epoch
  if caller=='clone':assert creations[0]['profile']!=creations[1]['profile']
  rows.append({'caller':caller,'shell':shell,'frozen_native_date_epoch':epoch,'same_bundle_identifier':True,'distinct_destinations':True,'distinct_profiles':caller=='clone','creations':creations})
result={'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'state':'CONFIRMED_BUNDLE_IDENTIFIER_COLLISION','source_head':'74f683f5a6ad49a62e5dad8837b8375375a01d3c','frozen_source_tree':'dc082b855e7906cea872ae863ee10c5632294fa9','source_hashes':snap,'rows':rows,'native':'Linux actual bash/zsh and filesystem; strict macOS command ports, no GUI/application/Dock launch or physicalmacOS claim','frozen_clock_boundary':'date +%s only returns one legitimate captured current epoch for both real creations; no production business logic substituted'};(root/'proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
