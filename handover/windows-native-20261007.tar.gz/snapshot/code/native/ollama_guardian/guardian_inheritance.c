#include "guardian_inheritance.h"
#include <string.h>

static int GIL_Error(GIL_Owner *owner,uint32_t error) {
    if(owner->first_error==0u)owner->first_error=error!=0u?error:13u;
    return 0;
}
int GIL_Begin(GIL_Owner *owner,uint64_t token,const uintptr_t handles[4],const GIL_Ports *ports) {
    size_t i,j;uint32_t flags,error=0u;
    if(owner==NULL || owner->used || token==0u || token>(uint64_t)INT64_MAX ||
        handles==NULL || ports==NULL || ports->get==NULL || ports->set==NULL)return 0;
    /* Reservation precedes even validation ports. GSC already owns originals. */
    owner->used=1u;owner->active=1u;owner->token=token;owner->ports=*ports;
    memcpy(owner->handles,handles,sizeof(owner->handles));
    for(i=0u;i<4u;++i){
        if(handles[i]==0u || handles[i]==UINTPTR_MAX)return GIL_Error(owner,87u);
        for(j=0u;j<i;++j)if(handles[j]==handles[i])return GIL_Error(owner,87u);
    }
    for(i=0u;i<4u;++i){
        flags=0u;error=0u;
        if(!ports->get(ports->context,handles[i],&flags,&error))return GIL_Error(owner,error);
        if((flags&1u)!=0u)return GIL_Error(owner,87u);
    }
    for(i=0u;i<4u;++i){
        /* A refusing native setter might already have effected this flag. */
        owner->pending|=1u<<(uint32_t)i;error=0u;
        if(!ports->set(ports->context,handles[i],1u,&error))return GIL_Error(owner,error);
    }
    return 1;
}
int GIL_Release(GIL_Owner *owner,uint64_t token) {
    size_t i;uint32_t bit,error;
    if(owner==NULL || !owner->used || token==0u || token!=owner->token)return 0;
    if(!owner->active)return 1;
    for(i=0u;i<4u;++i){
        bit=1u<<(uint32_t)i;
        if((owner->pending&bit)==0u)continue;
        error=0u;
        if(owner->ports.set(owner->ports.context,owner->handles[i],0u,&error))
            owner->pending&=~bit;
        else GIL_Error(owner,error);
    }
    if(owner->pending!=0u)return 0;
    owner->active=0u;
    return 1;
}
int GIL_CanRetire(const GIL_Owner *owner) {
    return owner!=NULL && !owner->active && owner->pending==0u;
}
