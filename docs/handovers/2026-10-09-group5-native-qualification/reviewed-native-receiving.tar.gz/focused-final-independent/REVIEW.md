# Final focused lease / Group 6 source revalidation

CLEAR for the exact final source composition and executed targeted portable
controls. The original independent review at /workspace/ergopti-group5-work/publications/lease-g6-focused-independent-nvqnbel1 remains immutable.
This successor authenticates the formatted author packet at /workspace/ergopti-group5-work/publications/lease-g6-focused-final-w2y63rs0.

Author manifest: 46a5364a5613e8d6272ab4c7f7ce70685439adb75fae896ca3119e611e34f915
Author census (29 subjects): aba5c809579a713377022d1c6c8856c3a69cb93a8d3262882d081b5f595c5715
Author patch: 8ad6ac3d42de791581591814f970402dc113eb478a3b6d8279955e7b150042ff

All final 29 subjects and eight exact postimages authenticate. Existing source
preimages equal the prior genuine b454/e896 images; new-path absence evidence
and all historical source custody remain the preceding review's exact bindings.
The eight-path actual reverse/check/apply roundtrip recovers original bytes and
restores final postimages. All eight postimage hashes remain exact before and
after each executed portable entry. The authored final packet is read-only and
all 29 subject hashes remain exact after execution. No peer's overlay is changed.

The workflow and frozen independent 44-case JSON corpus are byte-identical to
the predecessor. The original Group 6 44-test file prefix remains byte-whole;
the complete original 52-control qualification source and original pipeline
source reconstruct exactly after deleting additions only. The prior 24 focused
cases plus placement negative remain a byte-whole 5,179-byte body inside a
plain executed block, protected by a narrow formatting directive. No asserted
case is skipped. The native 146-method/17-filesystem source remains unchanged.

Actual Acorn AST comparison confirms the default helper, default test file and
pipeline guard differ only in formatting. The qualification guard remains
structurally equivalent after flattening its sole newly explicit frozen-control
block; all its statements are executed in the same order. The receiver's
original 44-case test AST is a whole prefix. Producer AST differs only in the
two separately reviewed evaluate/readBoundedRegular functions. Normalization
removes locations/literal quote spelling and converts only equivalent
noncomputed, nonmethod, nonshorthand string object keys to identifier keys.
The initial stricter AST comparison's quoted-versus-unquoted object-key failure
is retained with the original script; no executable source predicate changes
to obtain equivalence. A metadata-only KeyError due omitted final 'new' fields
is recorded; known authenticated path/preimage ownership was reused explicitly.

The two functional producer changes strengthen refusal: summary lines now
require a complete valid duration/count grammar without contradictory suffixes;
indented unknown test frames refuse. Physical capture allocates at most the
admitted regular-file size and reads only that fixed buffer. Same original
metadata/identity cuts, strict UTF-8 and fixed count remain. File growth refuses
without writing a success receipt. No receiver result grants full-package
qualification or runtime/hardware authority.

Serial actual final executions in my owned sparse context:

- Original 44 default controls plus 26 fixed-wrapper controls pass.
- Original 52 qualification controls, item 36's 65 constructed/source cases,
  and 82 PAC/WPAD portable controls pass.
- The historical focused corpus satisfies 2 accepts / 22 rejections and the
  old placement negative rejects.
- The original transcript corpus satisfies 2 accepts / 42 rejections. Two
  real bounded capture controls, three leading-frame refusals and two frozen
  malformed-summary refusals pass.
- My unchanged four independent foreign-wrapper mutations all reject.
- Six original Group 5 full/default acquisition/upload bodies remain exact;
  full Swift retains the exact two-parent union, original unfiltered run and
  reporters, 25-minute step and 45-minute job. ACL -> raw -> upload -> full
  adjacency and focus before ACL after Sparkle remain exact.

The primitive read proof is a generic Linux filesystem control, not Darwin
XCTest qualification. Actual XCTest output wrapper grammar and native timing
remain UNKNOWN/UNEXECUTED. Native/full JS/compiler/installation/CI were not run
by this reviewer. Future Group 3 SDK source additions are not borrowed or claimed
published by this receipt. No canonical, index, ref, generated output, workflow,
lock, running CI or authored/peer source context was mutated.
