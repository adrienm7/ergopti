from pathlib import Path
import ast,difflib,hashlib,json,re,os
root=Path('/tmp/group6-brew-timeout-capability-20261010-r3');main=Path('/workspace/ergopti')
paths=['tools/diagnostics/macos_brew_archive_acceptance_test.py','tools/test/test-homebrew-cask.cjs']
pre=[]
for name in paths:
 data=(main/name).read_bytes()
 for side in ('preimage','candidate'):
  p=root/side/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 pre.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(root/'PREIMAGES.json').write_text(json.dumps({'base':'Exact current root-formatted R2 applied sources atop591','files':pre},indent=2)+'\n')
p=root/'candidate'/paths[0];old=p.read_text();s=old
fixture='''class TimeoutEvidenceUnavailableFixture:
    """Closed test sentinel: actual capability refusal, never positive publication credit."""

    __slots__ = ()

    @staticmethod
    def packet():
        return {
            "schema": 1,
            "scope": "timeout-evidence-fixture",
            "capability": "O_NOFOLLOW",
            "status": "capability-refused",
            "positive_publication": "UNEXECUTED",
            "child_acquisitions": 0,
            "evidence_files_created": 0,
        }


def timeout_evidence_unavailable_fixture(case, world):
    """A declared negative receipt cannot silently substitute for a positive port."""
    if type(world) is not TimeoutEvidenceUnavailableFixture:
        return False
    packet = world.packet()
    case.assertEqual(packet, {
        "schema": 1,
        "scope": "timeout-evidence-fixture",
        "capability": "O_NOFOLLOW",
        "status": "capability-refused",
        "positive_publication": "UNEXECUTED",
        "child_acquisitions": 0,
        "evidence_files_created": 0,
    })
    for key in ("schema", "child_acquisitions", "evidence_files_created"):
        case.assertIs(type(packet[key]), int)
    for key in ("scope", "capability", "status", "positive_publication"):
        case.assertIs(type(packet[key]), str)
    case.assertFalse(hasattr(probe.os, "O_NOFOLLOW"))
    print("UNEXECUTED positive-publication: O_NOFOLLOW unavailable; native capability refusal verified")
    return True


'''
anchor='class FirstCommandTimeoutControls(unittest.TestCase):';assert s.count(anchor)==1;s=s.replace(anchor,fixture+anchor,1)
s=s.replace('''        with TemporaryDirectory() as directory, patch.object(probe, "NativeProcessGroups"):
            root = Path(directory)
            evidence_root = root / "evidence"
''','''        with TemporaryDirectory() as directory, patch.object(probe, "NativeProcessGroups") as native_groups:
            root = Path(directory)
            evidence_root = root / "evidence"
''',1)
oldbranch='''            if writer is None:
                self.skipTest("Private no-follow evidence publication is unavailable on this host")
'''
newbranch='''            if writer is None:
                self.assertFalse(hasattr(probe.os, "O_NOFOLLOW"))
                self.assertEqual(list(evidence_root.iterdir()), [])
                native_groups.assert_not_called()
                yield TimeoutEvidenceUnavailableFixture()
                return
'''
assert s.count(oldbranch)==1;s=s.replace(oldbranch,newbranch,1)
# Transform only ten new diagnostic consumers; every existing positive statement
# keeps its source and indentation, preceded by explicit typed refusal handling.
tree=ast.parse(s);lines=s.splitlines(keepends=True);edits=[];consumer_count=0
for node in tree.body:
 if not isinstance(node,ast.ClassDef) or node.name not in ('FirstCommandTimeoutControls','GenericCallbackTimeoutStageControls'):continue
 for f in node.body:
  if not isinstance(f,ast.FunctionDef) or not f.name.startswith('test_'):continue
  for w in ast.walk(f):
   if not isinstance(w,ast.With):continue
   matches=[item for item in w.items if isinstance(item.context_expr,ast.Call) and isinstance(item.context_expr.func,ast.Attribute) and isinstance(item.context_expr.func.value,ast.Name) and item.context_expr.func.value.id=='self' and item.context_expr.func.attr=='world']
   if not matches:continue
   assert len(matches)==1
   item=matches[0];assert isinstance(item.optional_vars,ast.Tuple)
   start=w.lineno-1;end=w.body[0].lineno-1
   header=''.join(lines[start:end]);a=item.optional_vars
   source_line=lines[a.lineno-1];assert a.lineno==a.end_lineno
   tuple_text=source_line[a.col_offset:a.end_col_offset]
   header=header.replace(tuple_text,'timeout_world',1)
   indent=' ' * w.body[0].col_offset
   check=indent+'if timeout_evidence_unavailable_fixture(self, timeout_world):\n'+indent+'    return\n'+indent+tuple_text+' = timeout_world\n'
   edits.append((start,end,header+check));consumer_count+=1
assert consumer_count==10
for start,end,value in sorted(edits,reverse=True):lines[start:end]=[value]
s=''.join(lines)
newtest='''class TimeoutEvidenceMissingCapabilityControls(unittest.TestCase):
    """Forced real constructor refusal; positive publication remains explicitly unexecuted."""

    world = FirstCommandTimeoutControls.world

    def test_actual_missing_nofollow_refuses_before_child_acquisition_and_emits_closed_unexecuted_receipt(self):
        present = hasattr(probe.os, "O_NOFOLLOW")
        original = getattr(probe.os, "O_NOFOLLOW", None)
        native_constructor = probe.PhaseEvidence
        try:
            if present:
                del probe.os.O_NOFOLLOW
            with (
                patch.object(probe, "PhaseEvidence", wraps=native_constructor) as constructors,
                patch.object(probe, "Children", wraps=probe.Children) as children,
                patch.object(probe, "acquire_owned") as acquire,
                patch.object(probe.sys, "stdout", new_callable=io.StringIO) as output,
            ):
                with self.world() as unavailable:
                    self.assertIs(type(unavailable), TimeoutEvidenceUnavailableFixture)
                    self.assertTrue(timeout_evidence_unavailable_fixture(self, unavailable))
                    self.assertEqual(unavailable.packet()["positive_publication"], "UNEXECUTED")
                    constructors.assert_called_once()
                    self.assertEqual(list(Path(constructors.call_args.args[0]).iterdir()), [])
                    children.assert_not_called()
                    acquire.assert_not_called()
                self.assertEqual(output.getvalue(), "UNEXECUTED positive-publication: O_NOFOLLOW unavailable; native capability refusal verified\\n")
        finally:
            if present:
                probe.os.O_NOFOLLOW = original
        self.assertEqual(hasattr(probe.os, "O_NOFOLLOW"), present)


'''
assert s.count('if __name__ == "__main__":')==1;s=s.replace('if __name__ == "__main__":',newtest+'if __name__ == "__main__":',1);p.write_text(s)
(root/'fixture.py.inc').write_text(fixture);(root/'new-test.py.inc').write_text(newtest)
p=root/'candidate'/paths[1];c=p.read_text();assert c.count('Ran 189 tests in ')==1;p.write_text(c.replace('Ran 189 tests in ','Ran 190 tests in ',1))
def methods(source):
 lines=source.splitlines(keepends=True)
 return {n.name+'.'+f.name:(''.join(lines[f.lineno-1:f.end_lineno]),f) for n in ast.parse(source).body if isinstance(n,ast.ClassDef) for f in n.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
a,b=methods(old),methods(s);assert len(a)==189 and len(b)==190
old178=methods(Path('/tmp/group6-brew-timeout-diagnostic-20261010-r1/preimage/tools/diagnostics/macos_brew_archive_acceptance_test.py').read_text());assert len(old178)==178
assert all(b[k][0]==v[0] for k,v in old178.items())
def assertions(node):
 return [ast.dump(call,include_attributes=False) for call in ast.walk(node) if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and isinstance(call.func.value,ast.Name) and call.func.value.id=='self' and call.func.attr.startswith('assert')]
# ast.walk order can change due to inserted if-statements; retain every original
# assertion expression with its original multiplicity, not just a loose set.
assert all(sorted(assertions(v[1]))==sorted(assertions(b[k][1])) for k,v in a.items())
assert 'self.skipTest(' not in s[s.index('class TimeoutEvidenceUnavailableFixture:'):]
patch='';inverse=''
for name in paths:
 aa=(root/'preimage'/name).read_text().splitlines(keepends=True);bb=(root/'candidate'/name).read_text().splitlines(keepends=True)
 patch+=''.join(difflib.unified_diff(aa,bb,fromfile='a/'+name,tofile='b/'+name));inverse+=''.join(difflib.unified_diff(bb,aa,fromfile='a/'+name,tofile='b/'+name))
(root/'application.patch').write_text(patch);(root/'whole-file-inverse.patch').write_text(inverse)
(root/'CONSERVATION.json').write_text(json.dumps({'kind':'source parse/read comparison; no target execution','original178_method_bodies_byte_exact':True,'current189_all_positive_assertion_AST_multisets_exact':True,'new_refusal_consumers':consumer_count,'preimage_registered_methods':189,'candidate_registered_methods':190,'strict_CJS_only_census189_to190':True,'production_helper_unchanged':True,'all_execution':'UNRUN'},indent=2)+'\n')
(root/'README.md').write_text('''# Explicit missing-capability refusal: private R3

Exact preimages are current root-formatted R2 test/census sources atopdev591. Production helper, native sources, main/index/refs are unchanged by this agent. This patch removes the new fixture skipTest only. When the actual existing PhaseEvidence constructor refuses absent O_NOFOLLOW, PhaseEvidenceControls.evidence already asserts the native AdmissionError and no files. The new world validates that exact missing capability, zero evidence files and zero native-group construction, then yields a test-only immutable zero-state typed sentinel. Each of its ten positive diagnostic consumers explicitly validates the closed exact receipt and returns after printing UNEXECUTED positive-publication: O_NOFOLLOW unavailable; native capability refusal verified. This is negative capability coverage; positive publication/timeout/retirement controls are NOT executed or credited on an incapable host.

The sentinel has exact closed schema/scope/capability/status/positive_publication and integer zero-acquisition/file facts. All keys/values and integer/string types are validated, and the host must really lack O_NOFOLLOW. Unknown worlds do not silently return; the original positive tuple/assertion path remains required. No assertion is removed or weakened. All178 original method bodies remain byte exact; every existing189 method's assertion AST multiset is unchanged. Strict CJS no-skips/OK/run assertions remain byte exact, apart from registered census189->190. Positive scope remains explicitly unexecuted on Windows without the required native capability.

One additive receiving control forces the actual missing flag on Linux too, wraps the real original constructor, asserts one constructor call, empty evidence directory, no Children/acquire_owned calls, exact sentinel and fixed UNEXECUTED message, and restores the host capability in finally. It does not require a fake publication port, skipped-test allowance, missing-method error or private data export. Root alone reviews and executes this control and the owning suite serially after application/formatting. All target imports/tests/native executions and Ruff formatting are UNRUN in this packet. No Windows positive qualification is claimed.
''')
sha=lambda b:hashlib.sha256(b).hexdigest();files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json':continue
 data=p.read_bytes();assert b'\r' not in data;os.chmod(p,0o400);files.append({'path':str(p.relative_to(root)),'sha256':sha(data),'bytes':len(data)})
for entry in pre:assert sha((main/entry['path']).read_bytes())==entry['sha256']
manifest={'schema':1,'base':'Exact root-formatted R2 sources','application_paths':paths,'main_sources_match_preimages':True,'preimage_tests':189,'candidate_tests':190,'patch_sha256':sha(patch.encode()),'all_execution':'UNRUN','Windows_positive_publication':'UNEXECUTED on incapable host','files':files}
(root/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');os.chmod(root/'MANIFEST.json',0o400)
print(json.dumps({'manifest':str(root/'MANIFEST.json'),'sha256':sha((root/'MANIFEST.json').read_bytes()),'patch_sha256':sha(patch.encode()),'original178_exact':True,'all189_positive_assertions_exact':True,'new_consumers':consumer_count,'census190':True,'execution':'UNRUN'}))
