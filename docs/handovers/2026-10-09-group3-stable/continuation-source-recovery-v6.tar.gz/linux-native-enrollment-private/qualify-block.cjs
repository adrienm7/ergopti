const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { spawnSync, execFileSync } = require('node:child_process');
const here = __dirname;
const before = fs.readFileSync(path.join(here, 'preimages/tools/test/test-ci-pipeline-wiring.cjs'), 'utf8');
const begin = before.indexOf('function logicalLines(body) {');
const end = before.indexOf('\n}\n', begin) + 3;
assert.ok(begin > 0 && end > begin);
const logical = before.slice(begin, end);
const block = fs.readFileSync(path.join(here, 'linux-enrollment-guard-block.cjs'), 'utf8');
const errors = [];
const LINUX_BOX = '.github/workflows/ci-linux.yml';
const NOT_CANCELLED = '${{ !cancelled() }}';
const context = vm.createContext({ fs, path, assert, spawnSync, errors, LINUX_BOX, NOT_CANCELLED, pipeline: require('/workspace/ergopti/tools/test/ci-pipeline.cjs'), bashExecutable: require('/workspace/ergopti/tools/lib/git-bash.cjs').bashExecutable, __dirname: path.join(here, 'candidate/tools/test') });
vm.runInContext(`${logical}\n${block}`, context, { filename: 'exact-added-enrollment-guard.cjs' });
assert.deepEqual(errors, []);
const old = fs.readFileSync(path.join(here, 'preimages/static/ergopti_plus/linux/tests/hardware/run_daemon_live.sh'), 'utf8');
assert.ok(context.linuxSimultaneousEnrollmentProblems(old).length > 0, 'actual old harness must fail');
const current = fs.readFileSync(path.join(here, 'candidate/static/ergopti_plus/linux/tests/hardware/run_daemon_live.sh'), 'utf8');
const first = 'luajit tests/hardware/run_modifier_custody.lua';
const phase = 'LLM_READY="$(mktemp -u)"';
for (const [name, open, close] of [['balanced false scope', 'if false; then\n', 'fi\n'], ['uninvoked function', 'never_run_native() {\n', '}\n'], ['quoted fake sequence', ": '\n", "'\n"], ['here document fake sequence', "cat <<'NATIVE_TEXT'\n", 'NATIVE_TEXT\n']]) {
  const changed=current.replace(first, open+first).replace(phase, close+phase);
  assert.ok(context.linuxSimultaneousEnrollmentProblems(changed).length > 0, name);
}
assert.equal(context.linuxSimultaneousEnrollmentProblems(current.replace(phase, phase+'\nexport ERGOPTI_OWNER_ADDITION=1')).length, 0);
const latestDev = execFileSync('git', ['show', 'origin/dev:.github/workflows/ci-linux.yml'], { cwd: '/workspace/ergopti', encoding: 'utf8' });
assert.equal(context.linuxSimultaneousWorkflowProblems([{rel: LINUX_BOX, text: latestDev}]).length, 0, 'latest actual dev native workflow enrollment is preserved');
const latestStepBody = context.pipeline.step(context.pipeline.jobsOfText(latestDev, LINUX_BOX).find((job) => job.id === 'e2e-linux').body, 'The whole daemon, live — a trigger typed, a tray shown');
for (const [name, changed] of [
 ['wrong native job', latestDev.replace('  e2e-linux:\n', '  foreign-native-job:\n')],
 ['wrong native step name', latestDev.replace('The whole daemon, live — a trigger typed, a tray shown', 'Unrelated native step')],
 ['earlier false exit', latestDev.replace('sudo bash static/ergopti_plus/linux/tests/hardware/run_daemon_live.sh', 'exit 0\n          sudo bash static/ergopti_plus/linux/tests/hardware/run_daemon_live.sh')],
 ['redirected package acquisition', latestDev.replace(latestStepBody, latestStepBody.replace('tools/ci/ubuntu_apt.py', 'tools/ci/unrelated_apt.py'))]
]) {
 assert.notEqual(changed, latestDev, name+' causal source mutation');
 assert.ok(context.linuxSimultaneousWorkflowProblems([{rel: LINUX_BOX, text: changed}]).length > 0, name);
}
const after=fs.readFileSync(path.join(here, 'candidate/tools/test/test-ci-pipeline-wiring.cjs'),'utf8');
assert.equal(after.replace(block, ''), before, 'whole original registered guard must remain byte-exact after removing only added block');
console.log('[OK] actual candidate envelope; 14 harness + 6 workflow embedded causal negatives; old-source RED; 4 dead-scope negatives; additive owner work accepted; whole original guard restored exactly.');
