from pathlib import Path
p=Path('/workspace/ergopti-delivery/full-group1-scope/candidate/static/ergopti_plus/linux/tests/unit/infra/test_shortcuts_scope.lua')
old=p.read_text();extra=r'''

helpers.describe("shortcut retained native release debt", function()
	local expected = {
		shortcuts = { enabled = true, wrap_text_if_selected = true, chatgpt_url = "https://old.example", unknown = "keep",
			keyboard = { ctrl_j = "open_url", ctrl_k = "enter", ctrl_p = "script_reload", foreign_slot = "keep" },
			tap_keys = { number_row_left = "send_text", unknown = "keep" } },
		gesture_parameters = { keyboard__ctrl_j__open_url = "https://old.example", tap_key__number_row_left__send_text = "typed",
			tap_3__open_url = "https://gesture.example", tap_hold__caps_lock__open_url = "https://hold.example", unknown = "keep" },
		linux = { action_parameters = { keyboard__ctrl_k__open_url = "https://legacy.example", unknown = "keep" } },
		gestures = { enabled = false, tap_3 = "enter" }, metrics = { enabled = true }, llm = { enabled = true }, other = { value = 42 },
	}
	local receipts = {
		{ name = "nil", reply = function() return nil end },
		{ name = "false", reply = function() return false end },
		{ name = "truthy string", reply = function() return "true" end },
		{ name = "wrong object", reply = function() return {} end },
		{ name = "exception", reply = function() error("native release refused") end },
	}
	--- Wraps real lease owners; an injected refusal never releases their token.
	local function controlled_scope(owners, controls, path, selected, refusal)
		local blocked, live, acknowledgements = true, {}, {}
		for _, entry in ipairs({ { "manager", "acquire_configuration", "release_configuration" },
			{ "gestures", "acquire_parameter_configuration", "release_parameter_configuration" },
			{ "url", "acquire_configuration", "release_configuration" },
			{ "keyboard", "acquire_configuration", "release_configuration" },
			{ "taps", "acquire_configuration", "release_configuration" },
			{ "chords", "acquire_configuration", "release_configuration" } }) do
			local name, native = entry[1], owners[entry[1]]
			local acquire, release = native[entry[2]], native[entry[3]]
			native[entry[2]] = function(token)
				local accepted = acquire(token)
				if accepted == true then
					helpers.assert_eq(live[name], nil, "a live acknowledged lease is never reacquired")
					live[name] = token
				end
				return accepted
			end
			native[entry[3]] = function(token)
				helpers.assert_eq(live[name], token, "a released lease is never released without a fresh acquisition")
				if name == selected and blocked then return refusal() end
				local accepted = release(token)
				if accepted == true then
					live[name] = nil
					acknowledgements[name] = (acknowledgements[name] or 0) + 1
				end
				return accepted
			end
		end
		local scope = require("infra.shortcuts_scope").new({ path = path, backup_path = path .. ".release-debt-backup",
			files = controls.files, is_paused = function() return controls.paused end })
		return scope, function() blocked = false end, live, acknowledgements
	end

	for _, mode in ipairs({ "clear", "recommended" }) do
		for _, receipt in ipairs(receipts) do
			helpers.it("retains " .. mode .. " runtime/file compensation on " .. receipt.name .. " native release", function()
				with_scope(function(_, owners, controls, path)
					local scope, unblock, live = controlled_scope(owners, controls, path, "manager", receipt.reply)
					local called, committed = pcall(scope.apply, mode)
					helpers.assert_eq(called, true, "native refusal settles rather than escaping")
					helpers.assert_eq(committed, false)
					helpers.assert_eq(scope.pending(), true)
					helpers.assert_eq(scope.release(), false)
					helpers.assert_eq(scope.apply("clear"), false, "another request cannot replace release debt")
					unblock()
					helpers.assert_eq(scope.retry_restore(), true)
					helpers.assert_eq(scope.pending(), false)
					helpers.assert_eq(Codec.decode(Sandbox.read_bytes(path)), expected)
					helpers.assert_eq(owners.manager.is_enabled(), true)
					helpers.assert_eq(owners.keyboard.get_action("ctrl_j"), "open_url")
					helpers.assert_eq(owners.taps.get_action("number_row_left"), "send_text")
					helpers.assert_eq(owners.gestures.get_action_parameter("keyboard__ctrl_j", "open_url"), "https://old.example")
					helpers.assert_eq(next(live), nil)
				end)
			end)
		end
	end

	helpers.it("stops global progression and retries the exact shortcut inverse before earlier categories", function()
		with_scope(function(_, owners, controls, path)
			local scope, unblock = controlled_scope(owners, controls, path, "keyboard", function() return false end)
			local trace = {}
			local before = { apply = function(_, done) trace[#trace + 1] = "before.apply"; done(true) end,
				revert = function(done) trace[#trace + 1] = "before.revert"; done(true) end,
				release = function() trace[#trace + 1] = "before.release" end,
				pending = function() return false end, retry_restore = function(done) done(true) end }
			local after = { apply = function(_, done) trace[#trace + 1] = "after.apply"; done(true) end,
				revert = function(done) done(true) end, release = function() end,
				pending = function() return false end, retry_restore = function(done) done(true) end }
			local actual = require("config_scope_participant").synchronous({ apply = scope.apply, owner = function() return scope end })
			local logger = {}; for _, level in ipairs({ "start", "success", "warn", "info", "error" }) do logger[level] = function() end end
			local global = require("config_scope_composition").new({ manifest = Manifest, scope = "global", logger = logger,
				participants = function() return { tap_holds = before, shortcuts = actual, llm = after } end })
			local verdict, report
			global.apply("recommended", function(ok, detail) verdict, report = ok, detail end)
			helpers.assert_eq(verdict, false)
			helpers.assert_eq(report.failed, "shortcuts")
			helpers.assert_eq(report.reverted, false)
			helpers.assert_eq(global.pending(), true)
			helpers.assert_eq(trace, { "before.apply" }, "later scopes and earlier inverses wait for exact owned debt")
			unblock()
			local restored
			global.retry_restore(function(ok) restored = ok end)
			helpers.assert_eq(restored, true)
			helpers.assert_eq(trace, { "before.apply", "before.revert" })
			helpers.assert_eq(Codec.decode(Sandbox.read_bytes(path)), expected)
			helpers.assert_eq(global.pending(), false)
		end)
	end)
end)
''';p.write_text(old+extra)
