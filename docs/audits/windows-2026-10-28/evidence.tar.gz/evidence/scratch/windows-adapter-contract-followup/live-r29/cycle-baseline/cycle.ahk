﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
#Warn All, StdOut
global LIVE_DEFAULT_TIMEOUT_MS := 1000
LiveWaitFor(Predicate, What, TimeoutMs := 0) {
	global LIVE_DEFAULT_TIMEOUT_MS
	Limit := TimeoutMs ? TimeoutMs : LIVE_DEFAULT_TIMEOUT_MS
	Started := A_TickCount
	loop {
		Value := Predicate.Call()
		if Value
			return Value
		if A_TickCount - Started > Limit
			throw Error("timed out after " . Limit . " ms waiting for " . What)
		Sleep(10)
	}
}

LiveDriveWindow(Match, Action, TimeoutMs := 0, Optional := false) {
	global LIVE_DEFAULT_TIMEOUT_MS
	State := {Done: false, Error: "", Hwnd: 0, Started: A_TickCount, Optional: Optional,
		Limit: TimeoutMs ? TimeoutMs : LIVE_DEFAULT_TIMEOUT_MS}
	Tick := _LiveDriveTick.Bind(State, Match, Action)
	State.Tick := Tick
	SetTimer(Tick, 40)
	return State
}

_LiveDriveTick(State, Match, Action, *) {
	if State.Done {
		SetTimer(State.Tick, 0)
		return
	}
	if A_TickCount - State.Started > State.Limit {
		if !State.Optional
			State.Error := "no window matched '" . (HasMethod(Match, "Call") ? "the watched window" : Match)
				. "' within " . State.Limit . " ms"
		State.Done := true
		SetTimer(State.Tick, 0)
		return
	}
	Hwnd := HasMethod(Match, "Call") ? Match.Call() : WinExist(Match)
	if !Hwnd
		return
	SetTimer(State.Tick, 0)
	State.Hwnd := Hwnd
	try Action.Call(Hwnd)
	catch as Err
		State.Error := Err.Message
	State.Done := true
}

LiveAwaitDrive(State, What) {
	LiveWaitFor(() => State.Done, What, State.Limit + 5000)
	if State.Error != ""
		throw Error(What . ": " . State.Error)
}

_R29_CycleDeleted(Observation, Self) {
    Observation.Deleted += 1
}
_R29_CycleAction(Observation, Hwnd) {
    Observation.Calls += 1
}
_R29_CycleRun() {
    Window := Gui("-DPIScale", "Owned live state cycle")
    Observation := {Deleted: 0, Calls: 0}
    Control := {Delete: _R29_CycleDeleted.Bind(Observation)}
    Control.DefineProp("__Delete", {Call: Control.Delete})
    Control := 0
    if Observation.Deleted != 1
        throw Error("The independent native destructor control did not execute.")
    Observation.Deleted := 0
    Drive := 0
    try {
        Window.Show("Hide w150 h100")
        Drive := LiveDriveWindow((*) => Window.Hwnd, _R29_CycleAction.Bind(Observation), 1000)
        Drive.DefineProp("__Delete", {Call: _R29_CycleDeleted.Bind(Observation)})
        LiveAwaitDrive(Drive, "the cycle's native window")
        if Observation.Calls != 1 || !Drive.Done
            throw Error("The actual live timer must complete exactly once first.")
        Drive := 0
        Sleep(100)
        if Observation.Deleted != 1
            throw Error("The completed live timer retained its native state through a bound-callback cycle.")
        FileAppend("PASS live-state-cycle`n", "*", "UTF-8-RAW")
        ExitApp(0)
    } catch Error as Failure {
        FileAppend("FAIL live-state-cycle: " . Failure.Message . "`n", "*", "UTF-8-RAW")
        ExitApp(1)
    } finally {
        if IsObject(Drive)
            SetTimer(Drive.Tick, 0)
        Window.Destroy()
    }
}
_R29_CycleRun()
