from pathlib import Path
import os,subprocess,json,tempfile,shutil,hashlib,tomllib,datetime
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-windows-r7-installer');p=Path('/workspace/scratch/windows-audit-round6/delivery-review/control-cli-boundaries');source=w/'tools/control/request_driver_reload.ps1';specpath=w/'static/ergopti_plus/_shared/modules/control/driver_control.json';spec=json.loads(specpath.read_text());app=tomllib.loads((w/'static/ergopti_plus/_shared/modules/paths/app_dirs.toml').read_text())['app']['folder_name'];token='a'*spec['token_hex_length'];request='ps-0123456789abcdef'
print('actual cwd:',Path.cwd(),flush=True)
assert Path.cwd()==w
poll=p/'actual-poll-receiver.ps1'
subprocess.run(['pwsh','-NoProfile','-NonInteractive','-File',str(p/'prepare-actual-poll-receiver.ps1'),'-Source',str(source),'-Destination',str(poll)],check=True,cwd=w)
root=Path(tempfile.mkdtemp(prefix='ergopti-control-cli-boundaries-'));entries=[]
def run(args,env=None):
 r=subprocess.run(args,cwd=w,env=env,capture_output=True,text=True,timeout=20)
 return {'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
try:
 baseline={'schema':spec['schema'],'driver':'windows','pid':2147483647,'token':token}
 cases=[('valid',{},True),('schema-true',{'schema':True},False),('schema-string',{'schema':'1'},False),('schema-array',{'schema':[1]},False),('schema-empty-array',{'schema':[]},False),('driver-array',{'driver':['windows']},False),('driver-uppercase',{'driver':'WINDOWS'},False),('token-final-LF',{'token':token+'\n'},False),('token-array',{'token':[token]},False),('pid-string',{'pid':'2147483647'},False),('wrong-driver',{'driver':'linux'},False),('short-token',{'token':token[:-1]},False),('wrong-schema',{'schema':0},False)]
 for name,change,allow in cases:
  base=root/('session-'+name);folder=base
  for segment in spec['folders']['windows']['segments']:folder=folder/(app if segment=='{app}' else segment)
  folder.mkdir(parents=True);(folder/spec['files']['session']).write_text(json.dumps(dict(baseline,**change))+'\n')
  env=dict(os.environ);env[spec['folders']['windows']['base']]=str(base)
  actual=run(['pwsh','-NoProfile','-NonInteractive','-File',str(source),'-TimeoutMs','1000'],env)
  rejected=actual['exit_code']!=3 and 'The driver session is malformed.' in actual['stderr']
  passed=actual['exit_code']==3 and 'unreachable' in actual['stdout'] if allow else rejected
  row={'kind':'actual-full-cli-session','case':name,'allow':allow,'passed':passed,**actual};entries.append(row);print(('PASS' if passed else 'FAIL')+' '+name+' exit='+str(actual['exit_code']),flush=True)
 record={'schema':spec['schema'],'request_id':request,'state':'completed','driver_pid':4004,'successor_pid':4004}
 cases=[('completed',{},True),('state-array',{'state':['completed']},False),('state-uppercase',{'state':'COMPLETED'},False),('state-mixedcase',{'state':'Completed'},False),('schema-true',{'schema':True},False),('schema-string',{'schema':'1'},False),('schema-array',{'schema':[1]},False),('request-array',{'request_id':[request]},False),('request-uppercase',{'request_id':request.upper()},False),('pid-true',{'driver_pid':True},False),('successor-true',{'successor_pid':True},False),('foreign-request',{'request_id':'ps-fedcba9876543210'},False),('refused',{'state':'refused','reason':'busy'},False)]
 for name,change,allow in cases:
  folder=root/('result-'+name);folder.mkdir();(folder/spec['files']['result']).write_text(json.dumps(dict(record,**change))+'\n')
  actual=run(['pwsh','-NoProfile','-NonInteractive','-File',str(poll),'-Folder',str(folder),'-SpecPath',str(specpath),'-RequestId',request])
  passed=actual['exit_code']==0 if allow else actual['exit_code']!=0
  entries.append({'kind':'actual-public-poll-ast','case':name,'allow_completion':allow,'passed':passed,**actual});print(('PASS' if passed else 'FAIL')+' poll-'+name+' exit='+str(actual['exit_code']),flush=True)
finally:
 shutil.rmtree(root)
 (p/'431-old-cli-boundaries.json').write_text(json.dumps({'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Actual full CLI session reader with genuinely absent process; actual public poll AST and real JSON files. No user32 endpoint, Windows COM or reload execution qualification.','controls':entries,'passed':sum(e['passed'] for e in entries),'failed':sum(not e['passed'] for e in entries)},indent=2)+'\n')
if any(not e['passed'] for e in entries):raise SystemExit(1)
