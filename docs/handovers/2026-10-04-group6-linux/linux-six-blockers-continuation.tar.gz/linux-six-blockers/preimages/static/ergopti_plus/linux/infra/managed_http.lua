--- infra/managed_http.lua

--- ==============================================================================
--- MODULE: Linux Managed HTTP Operation Coordinator
--- DESCRIPTION:
--- Retains one exact public owner across native proxy lookup, existing owned
--- curl dispatch and admitted ordered relay. Native children keep their own
--- physical-exit and handle-close ledgers; this coordinator never rewrites them.
--- Cancellation fences publication immediately while physical debt remains.
--- ==============================================================================

local M = {}

--- Constructs one initialized native coordinator against explicit owners.
--- @param dependencies table { policy, proxy, curl, clock, environment, report }
--- @return table|nil coordinator, string|nil error
function M.new(dependencies)
	if type(dependencies) ~= "table" or type(dependencies.policy) ~= "table"
		or type(dependencies.policy.route) ~= "function" or type(dependencies.policy.selection) ~= "function"
		or type(dependencies.policy.can_retry) ~= "function" or type(dependencies.proxy) ~= "table"
		or type(dependencies.proxy.lookup_owned) ~= "function" or type(dependencies.curl) ~= "function"
		or type(dependencies.clock) ~= "function" or type(dependencies.environment) ~= "function"
		or type(dependencies.report) ~= "function" then return nil, "managed-http-initialization-invalid" end
	local owned = {}
	local coordinator = {}
	local start_curl
	local settle_stage
	local dispatch_route

	--- Observes an exact child's physical settlement through its native API.
	--- @param record table
	--- @return boolean
	local function child_settled(record)
		if not record.child then return true end
		local ok, settled
		if record.stage == "proxy" then ok, settled = pcall(record.child.is_settled)
		else ok, settled = pcall(record.child.is_settled, record.child) end
		return ok and settled == true
	end

	--- Publishes completion once, after the current child has physically retired.
	--- @param record table
	--- @param result table
	local function finish(record, result)
		if record.operation._settled or record.uncertain or not child_settled(record) then return end
		record.operation._settled = true
		if owned[record.owner] == record then owned[record.owner] = nil end
		local successor = record.successor
		record.successor = nil
		if successor and not successor.operation._cancelled then
			successor.predecessor = nil
			owned[record.owner] = successor
			dispatch_route(successor, successor.route)
		end
		if not record.operation._cancelled and not record.logical_done and type(record.done) == "function" then
			local ok = pcall(record.done, result)
			if not ok then dependencies.report("Managed HTTP completion callback raised.") end
		end
		local listeners = record.operation._listeners
		record.operation._listeners = {}
		for _, listener in ipairs(listeners) do
			local ok = pcall(listener)
			if not ok then dependencies.report("Managed HTTP settlement callback raised.") end
		end
	end

	--- Builds a safe refusal without copying private native diagnostics.
	--- @param error_code string
	--- @return table
	local function refusal(error_code)
		return { ok = false, status = 0, body = "", error = error_code }
	end

	--- Computes remaining time from the one original monotonic deadline.
	--- @param record table
	--- @return number
	local function remaining(record)
		return math.floor(record.deadline - dependencies.clock())
	end

	--- Suppresses delivery immediately and asks only the current child to retire.
	--- @param record table
	--- @return boolean Native signal/cleanup acceptance, not settlement.
	local function request_cancel(record)
		local previously_cancelled = record.operation._cancelled
		record.operation._cancelled = true
		if record.predecessor and record.predecessor.successor == record then
			record.predecessor.successor = nil
			record.predecessor = nil
		end
		if record.operation._settled then return true end
		if record.uncertain then return false end
		if record.constructing then return true end
		if not record.child then finish(record, refusal("cancelled")); return true end
		local ok, accepted
		if record.stage == "proxy" then ok, accepted = pcall(record.child.cancel)
		else ok, accepted = pcall(record.child.request_cancel, record.child) end
		if ok and accepted == false and not record.options.owned_api and not previously_cancelled then
			record.operation._cancelled = false
		end
		if child_settled(record) then finish(record, refusal("cancelled")) end
		return ok and accepted == true
	end

	--- Attaches native retirement without treating logical completion as an ACK.
	--- @param record table
	--- @param generation number
	local function observe(record, generation)
		local function retired()
			if owned[record.owner] ~= record or record.generation ~= generation or record.constructing then return end
			settle_stage(record)
		end
		local ok, accepted
		if record.stage == "proxy" then ok, accepted = pcall(record.child.on_settled, retired)
		else ok, accepted = pcall(record.child.on_settled, record.child, retired) end
		if not ok or accepted ~= true then
			-- An uncertain producer cannot release its acquired child or start a
			-- replacement. Native owner/cancel/retry remain available to callers.
			dependencies.report("Managed HTTP child refused its retirement observer; ownership retained.")
			return
		end
		if record.operation._cancelled then request_cancel(record) end
		retired()
	end

	--- Publishes the historical boolean-port terminal event without retiring debt.
	--- @param record table
	--- @param result table
	local function logical_complete(record, result)
		if record.options.owned_api or record.logical_done or record.operation._cancelled then return end
		if type(result) ~= "table" then return end
		local choice = record.choices[record.choice]
		local file_relay_candidate = not record.options.output_path or type(record.options.proxy_retry_admit) == "function"
		local may_relay = file_relay_candidate and record.choice < #record.choices and result.ok == false
			and dependencies.policy.can_retry(result.failure_receipt, {
				selection_mode = choice.mode, delivered_bytes = record.delivered_bytes,
				proxy_used = result.proxy_used == true,
			}) == true
		if may_relay then return end
		record.logical_done = true
		result.proxy_selection_receipt = record.selection_metadata
		if type(record.done) == "function" then
			local ok = pcall(record.done, result)
			if not ok then dependencies.report("Managed HTTP logical completion callback raised.") end
		end
	end

	--- Starts an admitted curl choice only after its exact predecessor retires.
	--- @param record table
	start_curl = function(record)
		if owned[record.owner] ~= record or record.operation._cancelled then finish(record, refusal("cancelled")); return end
		local budget = remaining(record)
		if budget <= 0 then finish(record, refusal("timeout")); return end
		local choice = record.choices[record.choice]
		if not choice then finish(record, refusal("proxy-selection-invalid")); return end
		record.stage, record.child, record.result, record.done_received = "curl", nil, nil, false
		record.generation = record.generation + 1
		local generation = record.generation
		local options = {}
		for key, value in pairs(record.options) do options[key] = value end
		options.owner, options.timeout_ms, options.proxy_selection = record.owner, budget, choice
		options.proxy_metrics_available = record.curl_capabilities and record.curl_capabilities.proxy_used == true
		options.on_native_terminal = function(result)
			if owned[record.owner] ~= record or record.generation ~= generation then return end
			logical_complete(record, result)
		end
		local function complete(result)
			if owned[record.owner] ~= record or record.generation ~= generation or record.operation._cancelled then return end
			record.result, record.done_received = result, true
		end
		local function chunk(bytes)
			if owned[record.owner] ~= record or record.generation ~= generation or record.operation._cancelled then return end
			if type(bytes) ~= "string" then request_cancel(record); return end
			record.delivered_bytes = record.delivered_bytes + #bytes
			if type(record.chunk) == "function" then
				local ok = pcall(record.chunk, bytes)
				if not ok then dependencies.report("Managed HTTP chunk callback raised.") end
			end
		end
		record.constructing = true
		local called, child = pcall(dependencies.curl, record.url, record.headers, record.body, options, chunk, complete)
		record.constructing = false
		if not called or type(child) ~= "table" or type(child.is_settled) ~= "function"
			or type(child.on_settled) ~= "function" or type(child.request_cancel) ~= "function" then
			-- A throwing/malformed native producer might have acquired resources.
			-- Preserve this record; never turn uncertainty into a safe successor.
			record.uncertain = true
			dependencies.report("Managed HTTP curl producer retained uncertain native ownership.")
			return
		end
		record.child = child
		record.operation.started = record.operation.started or child.started == true
		observe(record, generation)
	end

	--- Advances one stage only after observing its actual native retirement.
	--- @param record table
	settle_stage = function(record)
		if not child_settled(record) then return end
		if record.operation._cancelled then finish(record, refusal("cancelled")); return end
		if not record.done_received then
			finish(record, refusal("managed-http-completion-missing"))
			return
		end
		if record.stage == "proxy" then
			local choices, err = dependencies.policy.selection(record.result)
			if not choices then finish(record, refusal(err)); return end
			record.choices, record.choice = choices, 1
			record.curl_capabilities = type(record.result) == "table" and record.result.curl_capabilities or nil
			record.selection_metadata = {
				backend = "gio", failure_provenance = "unavailable",
				proxy_resolution_status = type(record.result) == "table" and record.result.ok == true and "selected" or "unavailable",
				native_backend = type(record.result) == "table" and record.result.backend or nil,
			}
			if #choices == 1 and choices[1].mode == "direct" then record.selection_metadata.proxy_resolution_status = "direct" end
			start_curl(record)
			return
		end
		local result = record.result
		if type(result) ~= "table" then finish(record, refusal("managed-http-completion-invalid")); return end
		local choice = record.choices[record.choice]
		local safe_file = not record.options.output_path
		if not safe_file and type(record.options.proxy_retry_admit) == "function" then
			local admitted, acknowledged = pcall(record.options.proxy_retry_admit)
			safe_file = admitted and acknowledged == true
		end
		local can_retry = not record.logical_done and safe_file and record.choice < #record.choices and result.ok == false
			and dependencies.policy.can_retry(result.failure_receipt, {
				selection_mode = choice.mode, delivered_bytes = record.delivered_bytes,
				proxy_used = result.proxy_used == true,
			}) == true
		if can_retry then record.choice = record.choice + 1; start_curl(record); return end
		result.proxy_selection_receipt = record.selection_metadata
		finish(record, result)
	end

	--- Begins one preflighted route after exclusive public ownership admission.
	--- @param record table
	--- @param route table
	dispatch_route = function(record, route)
		local operation = record.operation
		if route.mode ~= "system" then
			record.choices, record.choice = { route }, 1
			start_curl(record)
			return operation
		end
		record.stage, record.constructing = "proxy", true
		record.generation = record.generation + 1
		local generation = record.generation
		local budget = remaining(record)
		if budget <= 0 then record.constructing = false; finish(record, refusal("timeout")); return operation end
		local called, child, lookup_error = pcall(dependencies.proxy.lookup_owned, record.url, {
			owner = record.owner, timeout_ms = budget, probe_curl = true,
			logical_cancel = record.options.owned_api == false,
			environment_exclusions = route.environment_exclusions,
		}, function(result)
			if owned[record.owner] ~= record or record.generation ~= generation or operation._cancelled then return end
			record.result, record.done_received = result, true
		end)
		record.constructing = false
		if not called then
			record.uncertain = true
			dependencies.report("Managed HTTP proxy producer retained uncertain native ownership.")
			return operation
		end
		if not child then
			record.result, record.done_received = { ok = false, error = lookup_error }, true
			settle_stage(record)
			return operation
		end
		if type(child) ~= "table" or type(child.is_settled) ~= "function" or type(child.on_settled) ~= "function"
			or type(child.cancel) ~= "function" then
			record.uncertain = true
			dependencies.report("Managed HTTP proxy producer retained uncertain native ownership.")
			return operation
		end
		record.child, operation.started = child, true
		observe(record, generation)
		return operation
	end

	--- Starts a managed request while preserving existing public owner semantics.
	--- @param url string
	--- @param headers table
	--- @param body string|nil
	--- @param options table Validated native HTTP options, including owner/deadline.
	--- @param on_chunk function|nil
	--- @param on_done function
	--- @return table operation
	function coordinator.start(url, headers, body, options, on_chunk, on_done)
		local operation = { started = false, _settled = false, _cancelled = false, _listeners = {} }
		local record = {
			url = url, headers = headers, body = body, options = options, owner = options.owner,
			chunk = on_chunk, done = on_done, operation = operation, generation = 0, delivered_bytes = 0,
			deadline = dependencies.clock() + options.timeout_ms,
		}
		function operation:is_settled() return self._settled end
		function operation:on_settled(listener)
			if type(listener) ~= "function" then return false end
			if self._settled then
				local ok = pcall(listener)
				if not ok then dependencies.report("Managed HTTP settlement callback raised.") end
			else self._listeners[#self._listeners + 1] = listener end
			return true
		end
		function operation:cancel() request_cancel(record); return self._settled end
		function operation:request_cancel() return request_cancel(record) end
		local fetched, environment = pcall(dependencies.environment)
		local route, err
		if fetched then route, err = dependencies.policy.route(url, environment) end
		if not route then finish(record, refusal(err or "proxy-environment-unavailable")); return operation end
		record.route = route
		local predecessor = owned[record.owner]
		if predecessor then
			if options.owned_api then finish(record, refusal("previous request cleanup pending")); return operation end
			if predecessor.successor then request_cancel(predecessor.successor) end
			predecessor.successor, record.predecessor = record, predecessor
			operation.started = true
			if not request_cancel(predecessor) then
				if predecessor.successor == record then predecessor.successor = nil end
				record.predecessor, operation.started = nil, false
				finish(record, refusal("previous request cancellation failed"))
			end
			return operation
		end
		owned[record.owner] = record
		dispatch_route(record, route)
		return operation
	end


	--- Preserves logical cancellation for the public boolean HTTP adapter port.
	--- @param owner string
	--- @return boolean
	function coordinator.cancel(owner)
		local record = owned[owner]
		if not record then return true end
		if record.successor then request_cancel(record.successor) end
		return request_cancel(record)
	end

	--- Reports activity across native lookup, curl and retained retirement debt.
	--- @param owner string
	--- @return boolean
	function coordinator.is_active(owner)
		local record = owned[owner]
		if record and record.successor then record = record.successor end
		return record ~= nil and not record.operation._cancelled and not record.logical_done
	end

	return coordinator
end

return M
