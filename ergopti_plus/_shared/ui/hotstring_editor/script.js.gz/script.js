// _shared/ui/hotstring_editor/script.js

// ===========================================================================
// Hotstring Editor UI Script.
//
// Manages the rich-text interface for creating and editing dynamic hotstrings.
// ===========================================================================

// ====================================
// ====================================
// ======= 1/ Globals & State =========
// ====================================
// ====================================

// Delays of this page. A page script cannot read the timing registry, so each copy
// is pinned to its [ui] key by tools/test/test-keystats-timings-single-source.cjs.
const FOCUS_DELAY_MS = 80; // [ui] hotstring_editor_focus_delay_ms
const EDIT_FOCUS_DELAY_MS = 50; // [ui] hotstring_editor_edit_focus_delay_ms
const TOAST_MS = 1400; // [ui] hotstring_editor_toast_ms
const ADD_ENTRY_DELAY_MS = 300; // [ui] hotstring_editor_add_entry_delay_ms

function _t(key) {
	return (window._i18n_strings && window._i18n_strings[key]) || null;
}

let D = null;
let TRIGGER_CHAR = '★';
let STAR = '★';
// The magic key as every UI shows it, « ★ (ù) » for another character
// (_shared/hotstrings/data/magic_key.json display_format, pinned by
// tools/test/test-magic-key-rules.cjs): never a bare ★ for another character,
// never that character alone.
const MAGIC_KEY_DISPLAY_FORMAT = '★ ({char})';

let edSec = null;
let edEntry = null;
let dragSrcIdx = null;

let compactView = false;
let autoClose = false;
let defaultSec = null;
let defaultPrio = null;
let openMode = 'menu';
let rowIdentityMode = false;
let nextNewRowId = 0;

// Lower-cased, trimmed live filter applied to the entry list (trigger + output).
let searchQuery = '';

const TOKEN_NORM = {
	esc: 'Escape',
	escape: 'Escape',
	bs: 'BackSpace',
	backspace: 'BackSpace',
	del: 'Delete',
	delete: 'Delete',
	return: 'Enter',
	enter: 'Enter',
	left: 'Left',
	right: 'Right',
	up: 'Up',
	down: 'Down',
	home: 'Home',
	end: 'End',
	tab: 'Tab'
};

const TOKEN_NAMES = [
	'Left',
	'Right',
	'Up',
	'Down',
	'Home',
	'End',
	'Tab',
	'BackSpace',
	'Delete',
	'Escape',
	'Enter'
];

function getCmdGroups() {
	return [
		{
			lbl: _t('editor.hotstrings.cmd_group_arrows') || 'Arrows',
			cmds: [
				{ token: 'Left', sym: '←', desc: _t('editor.hotstrings.cmd_left') || 'left' },
				{ token: 'Right', sym: '→', desc: _t('editor.hotstrings.cmd_right') || 'right' },
				{ token: 'Up', sym: '↑', desc: _t('editor.hotstrings.cmd_up') || 'up' },
				{ token: 'Down', sym: '↓', desc: _t('editor.hotstrings.cmd_down') || 'down' }
			]
		},
		{
			lbl: 'Navigation',
			cmds: [
				{ token: 'Home', sym: 'Home', desc: _t('editor.hotstrings.cmd_home') || 'line start' },
				{ token: 'End', sym: 'End', desc: _t('editor.hotstrings.cmd_end') || 'line end' },
				{ token: 'Tab', sym: '⇥', desc: _t('editor.hotstrings.cmd_tab') || 'tab' },
				{ token: 'Escape', sym: 'Esc', desc: _t('editor.hotstrings.cmd_escape') || 'Escape' }
			]
		},
		{
			lbl: _t('editor.hotstrings.cmd_group_edition') || 'Edition',
			cmds: [
				{ token: 'BackSpace', sym: '⌫', desc: _t('editor.hotstrings.cmd_backspace') || 'delete ←' },
				{ token: 'Delete', sym: '⌦', desc: _t('editor.hotstrings.cmd_delete') || 'delete →' },
				{ token: 'Enter', sym: '↩', desc: _t('editor.hotstrings.cmd_enter') || 'new line' }
			]
		}
	];
}

// ====================================
// ====================================
// ======= 2/ Utility Functions =======
// ====================================
// ====================================

/**
 * Normalizes known token aliases while preserving unknown literal brace text.
 * @param {string} name - The raw token name.
 * @returns {string} The normalized token name.
 */
function normToken(name) {
	const key = name.toLowerCase();
	return Object.hasOwn(TOKEN_NORM, key) ? TOKEN_NORM[key] : name;
}

/**
 * How the configured magic key is shown: the marker alone when it is the marker.
 * @param {string} char - Configured magic key.
 * @returns {string} « ★ » or « ★ (char) ».
 */
function magicKeyDisplay(char) {
	if (char === STAR) return STAR;
	return MAGIC_KEY_DISPLAY_FORMAT.replace('{char}', char);
}

/**
 * Replaces the internal star representation with the user's custom trigger character for UI display.
 * @param {string} s - The internal string containing stars.
 * @returns {string} The formatted string ready for display.
 */
function toDisplay(s) {
	if (!s || TRIGGER_CHAR === STAR) return s || '';
	return String(s).split(STAR).join(TRIGGER_CHAR);
}

/**
 * Shows a stored string as a message or a read-only view does: each ★ becomes
 * the magic key's display, « ★ (ù) ».
 * @param {string} s - The internal string containing stars.
 * @returns {string} The string as shown.
 */
function toShown(s) {
	if (!s) return '';
	return String(s).split(STAR).join(magicKeyDisplay(TRIGGER_CHAR));
}

/**
 * Replaces the custom trigger character with the internal star representation for backend storage.
 * @param {string} s - The displayed string containing custom triggers.
 * @returns {string} The canonical internal string.
 */
function toCanonical(s) {
	if (!s || TRIGGER_CHAR === STAR) return s || '';
	const regex = new RegExp(TRIGGER_CHAR.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
	return String(s).replace(regex, STAR);
}

// ====================================
// ====================================
// ======= 3/ Lua Communication =======
// ====================================
// ====================================

const _bridge = makeHostBridge('hsEditor');

/**
 * Sends an action message to the native host.
 * @param {string} action - The action identifier (e.g., 'save', 'close').
 * @param {Object} [data] - The payload to send along with the action.
 */
function toLua(action, data) {
	_bridge({ action: action, data: data || {} });
}

// ====================================
// ====================================
// ======= 4/ Modals & Validation =====
// ====================================
// ====================================

// The open dialogs, innermost last, each with the element that had the focus
// when it opened. A confirmation can open over the entry form.
const openModals = [];
// What the keyboard can reach first in a dialog that has just opened.
const MODAL_FOCUSABLE =
	'button:not([disabled]), input:not([disabled]), select:not([disabled]), ' +
	'[contenteditable="true"], summary';

/**
 * Makes everything but the innermost open dialog inert, so Tab and a screen
 * reader stay in the dialog (WCAG 2.4.3) and leave it only to the window's
 * frame. The autocomplete popup serves the entry form and stays live.
 */
function syncModalInertness() {
	const top = openModals.length ? document.getElementById(openModals.at(-1).id) : null;
	for (const child of document.body.children) {
		if (child.tagName === 'SCRIPT' || child.id === 'ac-popup') continue;
		child.inert = top !== null && child !== top;
	}
}

/**
 * Shows a dialog, keeps the keyboard inside it, and moves the focus into it
 * unless the caller already did: a dialog opened from the keyboard was
 * unreachable behind its overlay, and its Enter and Escape keys never fired.
 * @param {string} id - The modal container ID.
 */
function openModal(id) {
	const modal = document.getElementById(id);
	if (!openModals.some((entry) => entry.id === id))
		openModals.push({ id, opener: document.activeElement });
	modal.classList.add('on');
	syncModalInertness();
	if (!modal.contains(document.activeElement)) {
		const first = modal.querySelector(MODAL_FOCUSABLE);
		if (first) first.focus();
	}
}

/**
 * Hides a dialog, resets its form state, and gives the focus back to the
 * element that opened it when that element is still on the page.
 * @param {string} id - The modal container ID.
 */
function closeModal(id) {
	document.getElementById(id).classList.remove('on');
	const index = openModals.findIndex((entry) => entry.id === id);
	const closed = index >= 0 ? openModals.splice(index, 1)[0] : null;
	syncModalInertness();
	if (closed && closed.opener && closed.opener.isConnected && !closed.opener.closest('[inert]'))
		closed.opener.focus();
	if (id === 'entry-modal') clearEntryErrors();
	if (id === 'sec-modal') clearSecErrors();
}

/**
 * Displays a simple blocking alert modal.
 * @param {string} msg - The message to display.
 */
function showAlert(msg) {
	document.getElementById('msg-text').textContent = msg;
	openModal('msg-modal');
}

let _confirmCb = null;

/**
 * Displays a confirmation dialog requiring user approval before executing an action.
 * @param {string} msg - The question/warning to display.
 * @param {function} fn - The function to execute if the user approves.
 * @param {Object} [opts] - Additional UI modifiers for the dialog.
 */
function showConfirm(msg, fn, opts = {}) {
	// A warning is the dialog's heading and names it; the question describes it.
	const title = document.getElementById('confirm-title');
	const dialog = title.closest('[role="alertdialog"]');
	title.textContent = opts.isWarning ? _t('common.warning') : '';
	title.hidden = !opts.isWarning;
	if (opts.isWarning) dialog.setAttribute('aria-labelledby', 'confirm-title');
	else dialog.removeAttribute('aria-labelledby');
	document.getElementById('confirm-text').innerHTML = msg;

	const okBtn = document.getElementById('confirm-ok');
	okBtn.textContent = opts.okLabel || _t('common.delete');
	// Deep tones under the white label (7:1, WCAG 1.4.6): the system red and
	// orange are too light for it.
	okBtn.style.background = opts.okColor || 'var(--theme-hue-8a1a14)';

	_confirmCb = fn;
	openModal('confirm-modal');
}

function setFieldError(fieldId, errId, msg) {
	const field = document.getElementById(fieldId);
	const err = document.getElementById(errId);
	if (field) {
		field.classList.remove('field-error');
		void field.offsetWidth;
		field.classList.add('field-error');
	}
	if (err && msg) {
		err.textContent = msg;
		err.classList.add('on');
	}
}

function clearFieldError(fieldId, errId) {
	const field = document.getElementById(fieldId);
	const err = document.getElementById(errId);
	if (field) field.classList.remove('field-error');
	if (err) {
		err.textContent = '';
		err.classList.remove('on');
	}
}

function clearEntryErrors() {
	clearFieldError('e-trig', 'trig-err');
	clearFieldError('e-out', 'out-err');
}

function clearSecErrors() {
	clearFieldError('sec-id', 'sec-id-err');
}

// ====================================
// ====================================
// ======= 5/ UI State Updaters =======
// ====================================
// ====================================

/**
 * Dynamically updates the textual descriptions below the checkboxes.
 */
function updateCbDescs() {
	const w = document.getElementById('cb-word').checked;
	const a = document.getElementById('cb-auto').checked;
	const c = document.getElementById('cb-case').checked;
	const f = document.getElementById('cb-final').checked;

	document.getElementById('desc-word').innerHTML = w
		? _t('editor.hotstrings.desc_word_on') ||
			'Only triggers when it matches a standalone word.<br>Ex: <em>tel</em>→telephone but not <em>hotel</em>'
		: _t('editor.hotstrings.desc_word_off') ||
			'Triggers anywhere, even inside a word.<br>Ex: will trigger inside <em>hotel</em>';

	document.getElementById('desc-auto').innerHTML = a
		? (
				_t('editor.hotstrings.desc_auto_on') ||
				'Expands immediately (ideal for triggers ending with %s).'
			).replace('%s', escapeHtml(magicKeyDisplay(TRIGGER_CHAR)))
		: _t('editor.hotstrings.desc_auto_off') ||
			'Requires Space or Enter to expand (recommended for autocorrect).';

	document.getElementById('desc-case').innerHTML = c
		? _t('editor.hotstrings.desc_case_on') ||
			'Strictly distinguishes uppercase/lowercase.<br>Ex: <em>Btw</em> ≠ <em>btw</em>'
		: _t('editor.hotstrings.desc_case_off') ||
			'The engine generates lowercase, Titlecase and UPPERCASE variants.';

	document.getElementById('desc-final').innerHTML = f
		? _t('editor.hotstrings.desc_final_on') || 'The result will not be re-parsed as a trigger.'
		: _t('editor.hotstrings.desc_final_off') ||
			'The result can trigger other hotstrings in a chain.';
}

/**
 * Shows the configured magic key on the button that inserts it.
 */
function updateHints() {
	const mb = document.getElementById('magic-btn');
	if (mb) mb.textContent = magicKeyDisplay(TRIGGER_CHAR);
}

function updateCompactBtn() {
	const b = document.getElementById('compact-btn');
	if (b)
		b.textContent = compactView
			? _t('editor.hotstrings.btn_view_expanded')
			: _t('editor.hotstrings.btn_view_compact');
}

function toggleCompact() {
	compactView = !compactView;
	updateCompactBtn();
	render();
	toLua('save_pref', { key: 'compact_view', value: compactView });
}

function checkPh() {
	const ed = document.getElementById('e-out');
	const ph = document.getElementById('e-out-ph');
	const isEmpty = ed.textContent.length === 0 && ed.innerHTML.indexOf('<kbd') === -1;
	ph.style.display = isEmpty ? 'block' : 'none';
}

// ====================================
// ====================================
// ======= 6/ Chips & Editors =========
// ====================================
// ====================================

// A token of the output is a key or a command the engine types: kbd.
function makeChip(name) {
	const s = document.createElement('kbd');
	s.className = 'token-chip';
	s.contentEditable = 'false';
	s.dataset.token = name;
	s.textContent = name;
	return s;
}

function makeTrigChip() {
	const s = document.createElement('kbd');
	s.className = 'token-chip';
	s.contentEditable = 'false';
	s.dataset.trigChar = 'true';
	s.textContent = magicKeyDisplay(TRIGGER_CHAR);
	return s;
}

function setTrigContent(el, text) {
	el.innerHTML = '';
	if (!text) return;
	const display = toDisplay(text);
	const parts = display.split(TRIGGER_CHAR);
	parts.forEach((part, i) => {
		if (part) el.appendChild(document.createTextNode(part));
		if (i < parts.length - 1) el.appendChild(makeTrigChip());
	});
}

function serializeTrigEditor(el) {
	let s = '';
	el.childNodes.forEach((n) => {
		if (n.nodeType === 3) s += toCanonical(n.textContent);
		else if (n.nodeType === 1 && n.dataset && n.dataset.trigChar) s += STAR;
		else s += toCanonical(n.textContent || '');
	});
	return s.trim();
}

// Distinguish an intentional Enter command from WebKit's empty-editor BR.
function makeEnterBreak() {
	const br = document.createElement('br');
	br.dataset.enter = 'true';
	return br;
}

function parseToNodes(text) {
	if (!text) return [document.createTextNode('')];
	text = toDisplay(text);
	const nodes = [];
	const re = /\{([^}]+)\}/g;
	let last = 0;
	let m;
	while ((m = re.exec(text)) !== null) {
		if (m.index > last) nodes.push(document.createTextNode(text.slice(last, m.index)));
		const tname = normToken(m[1]);
		if (tname === 'Enter') nodes.push(makeEnterBreak());
		else nodes.push(makeChip(tname));
		last = re.lastIndex;
	}
	if (last < text.length) nodes.push(document.createTextNode(text.slice(last)));
	return nodes;
}

function serializeEditor(el) {
	const nodes = Array.from(el.childNodes);
	while (nodes.length > 0) {
		const last = nodes[nodes.length - 1];
		if (
			last.nodeType === 1 &&
			last.tagName === 'BR' &&
			!last.dataset.enter &&
			!last.classList.contains('token-chip')
		) {
			nodes.pop();
		} else {
			break;
		}
	}
	let s = '';
	nodes.forEach((n) => {
		if (n.nodeType === 3) s += toCanonical(n.textContent);
		else if (n.nodeType === 1 && n.classList.contains('token-chip'))
			s += '{' + n.dataset.token + '}';
		else if (n.nodeType === 1 && n.tagName === 'BR') s += '{Enter}';
		else s += toCanonical(n.textContent || '');
	});
	return s;
}

function setEditorContent(el, text) {
	el.innerHTML = '';
	parseToNodes(text || '').forEach((n) => el.appendChild(n));
	checkPh();
}

// ====================================
// ====================================
// ======= 7/ Editor Interactions =====
// ====================================
// ====================================

function insertBrAtCursor() {
	const ed = document.getElementById('e-out');
	ed.focus();
	let sel = window.getSelection();
	const br = makeEnterBreak();
	if (sel && sel.rangeCount) {
		const r = sel.getRangeAt(0);
		if (ed.contains(r.commonAncestorContainer)) {
			r.deleteContents();
			r.insertNode(br);
			if (!br.nextSibling) br.parentNode.appendChild(document.createTextNode(''));
			const nr = document.createRange();
			nr.setStartAfter(br);
			nr.collapse(true);
			sel.removeAllRanges();
			sel.addRange(nr);
			checkPh();
			return;
		}
	}
	ed.appendChild(br);
	ed.appendChild(document.createTextNode(''));
	checkPh();
}

function insertChipAtCursor(name) {
	if (name === 'Enter') {
		insertBrAtCursor();
		return;
	}
	const ed = document.getElementById('e-out');
	ed.focus();
	const chip = makeChip(normToken(name));
	let sel = window.getSelection();
	if (sel && sel.rangeCount) {
		const r = sel.getRangeAt(0);
		if (ed.contains(r.commonAncestorContainer)) {
			r.deleteContents();
			r.insertNode(chip);
			const nr = document.createRange();
			nr.setStartAfter(chip);
			nr.collapse(true);
			sel.removeAllRanges();
			sel.addRange(nr);
			checkPh();
			return;
		}
	}
	ed.appendChild(chip);
	const nr = document.createRange();
	nr.setStartAfter(chip);
	nr.collapse(true);
	sel = window.getSelection();
	if (sel) {
		sel.removeAllRanges();
		sel.addRange(nr);
	}
	checkPh();
}

function insertMagicKey() {
	const te = document.getElementById('e-trig');
	te.focus();
	const chip = makeTrigChip();
	let sel = window.getSelection();
	if (sel && sel.rangeCount) {
		const r = sel.getRangeAt(0);
		if (te.contains(r.commonAncestorContainer)) {
			r.deleteContents();
			r.insertNode(chip);
			const nr = document.createRange();
			nr.setStartAfter(chip);
			nr.collapse(true);
			sel.removeAllRanges();
			sel.addRange(nr);
			return;
		}
	}
	te.appendChild(chip);
	const nr = document.createRange();
	nr.setStartAfter(chip);
	nr.collapse(true);
	sel = window.getSelection();
	if (sel) {
		sel.removeAllRanges();
		sel.addRange(nr);
	}
}

function tryConvertToken(editor) {
	const sel = window.getSelection();
	if (!sel || !sel.rangeCount) return;
	const range = sel.getRangeAt(0);
	if (!range.collapsed) return;
	const node = range.startContainer;
	if (node.nodeType !== 3) return;

	const offset = range.startOffset;
	const before = node.textContent.slice(0, offset);
	const m = before.match(/\{(\w+)\}$/);
	if (!m) return;

	const tokenName = normToken(m[1]);
	if (TOKEN_NAMES.indexOf(tokenName) < 0) return;

	const matchStart = offset - m[0].length;
	const r = document.createRange();
	r.setStart(node, matchStart);
	r.setEnd(node, offset);
	r.deleteContents();

	if (tokenName === 'Enter') {
		const anch = sel.getRangeAt(0);
		const br = makeEnterBreak();
		anch.insertNode(br);
		if (!br.nextSibling) br.parentNode.appendChild(document.createTextNode(''));
		const nr = document.createRange();
		nr.setStartAfter(br);
		nr.collapse(true);
		sel.removeAllRanges();
		sel.addRange(nr);
		checkPh();
		return;
	}
	const chip = makeChip(tokenName);
	const anch = sel.getRangeAt(0);
	anch.insertNode(chip);
	const nr = document.createRange();
	nr.setStartAfter(chip);
	nr.collapse(true);
	sel.removeAllRanges();
	sel.addRange(nr);
	checkPh();
}

let _ejecting = false;
function ejectFromChip() {
	if (_ejecting) return;
	const sel = window.getSelection();
	if (!sel || !sel.rangeCount || !sel.isCollapsed) return;
	const range = sel.getRangeAt(0);
	const node = range.startContainer;
	const el = node.nodeType === 3 ? node.parentElement : node;
	if (el && el.classList && el.classList.contains('token-chip')) {
		_ejecting = true;
		const nr = document.createRange();
		nr.setStartAfter(el);
		nr.collapse(true);
		sel.removeAllRanges();
		sel.addRange(nr);
		_ejecting = false;
	}
}

// ====================================
// ====================================
// ======= 8/ Autocomplete Engine =====
// ====================================
// ====================================

let acItems = [];
let acIdx = 0;

function getAcCtx() {
	const sel = window.getSelection();
	if (!sel || !sel.rangeCount) return null;
	const r = sel.getRangeAt(0);
	if (!r.collapsed) return null;
	const n = r.startContainer;
	if (n.nodeType !== 3) return null;
	const text = n.textContent.slice(0, r.startOffset);
	const m = text.match(/\{(\w*)$/);
	if (!m) return null;
	return { partial: m[1].toLowerCase(), start: r.startOffset - m[0].length, node: n };
}

function showAc(matches) {
	const popup = document.getElementById('ac-popup');
	acItems = matches;
	acIdx = 0;
	popup.innerHTML = '';
	const sel = window.getSelection();
	if (!sel || !sel.rangeCount) {
		hideAc();
		return;
	}
	const rect = sel.getRangeAt(0).getBoundingClientRect();
	// A list box the output editor owns: the editor keeps the focus and names
	// the highlighted suggestion through aria-activedescendant, so the arrow
	// keys' choice is announced (WCAG 4.1.2).
	matches.forEach((name, i) => {
		const option = document.createElement('li');
		option.className = 'ac-item' + (i === 0 ? ' active' : '');
		option.id = 'ac-option-' + i;
		option.setAttribute('role', 'option');
		option.setAttribute('aria-selected', i === 0 ? 'true' : 'false');
		option.textContent = name;
		option.addEventListener('mousedown', (e) => {
			e.preventDefault();
			applyAc(name);
		});
		popup.appendChild(option);
	});
	popup.style.left = rect.left + 'px';
	popup.style.top = rect.bottom + 4 + 'px';
	popup.classList.add('on');
	document.getElementById('e-out').setAttribute('aria-activedescendant', 'ac-option-0');
}

function hideAc() {
	document.getElementById('ac-popup').classList.remove('on');
	acItems = [];
	document.getElementById('e-out').removeAttribute('aria-activedescendant');
}

function updateAcSel() {
	document.querySelectorAll('.ac-item').forEach((el, i) => {
		el.classList.toggle('active', i === acIdx);
		el.setAttribute('aria-selected', i === acIdx ? 'true' : 'false');
	});
	document.getElementById('e-out').setAttribute('aria-activedescendant', 'ac-option-' + acIdx);
}

function applyAc(name) {
	hideAc();
	const ctx = getAcCtx();
	if (!ctx) {
		insertChipAtCursor(name);
		return;
	}
	const r = document.createRange();
	r.setStart(ctx.node, ctx.start);
	r.setEnd(ctx.node, ctx.start + ctx.partial.length + 1);
	r.deleteContents();

	if (normToken(name) === 'Enter') {
		const sel2 = window.getSelection();
		const anch = sel2.getRangeAt(0);
		const br = makeEnterBreak();
		anch.insertNode(br);
		if (!br.nextSibling) br.parentNode.appendChild(document.createTextNode(''));
		const nr = document.createRange();
		nr.setStartAfter(br);
		nr.collapse(true);
		sel2.removeAllRanges();
		sel2.addRange(nr);
		checkPh();
		return;
	}
	const chip = makeChip(normToken(name));
	const sel3 = window.getSelection();
	const anch2 = sel3.getRangeAt(0);
	anch2.insertNode(chip);
	const nr2 = document.createRange();
	nr2.setStartAfter(chip);
	nr2.collapse(true);
	sel3.removeAllRanges();
	sel3.addRange(nr2);
	checkPh();
}

function checkAc() {
	const ctx = getAcCtx();
	if (!ctx) {
		hideAc();
		return;
	}
	const matches = TOKEN_NAMES.filter((n) => n.toLowerCase().startsWith(ctx.partial));
	if (matches.length === 0) {
		hideAc();
		return;
	}
	showAc(matches);
}

// ====================================
// ====================================
// ======= 9/ Drag & Drop Engine ======
// ====================================
// ====================================

function onDragStart(e, si) {
	dragSrcIdx = si;
	e.dataTransfer.effectAllowed = 'move';
	e.dataTransfer.setData('text/plain', String(si));
	setTimeout(() => {
		const c = document.getElementById('sc-' + si);
		if (c) c.classList.add('dragging');
	}, 0);
}

function onDragOver(e, si) {
	e.preventDefault();
	e.dataTransfer.dropEffect = 'move';
	document.querySelectorAll('.sec-card').forEach((c, i) => {
		c.classList.toggle('drag-over', i === si && i !== dragSrcIdx);
	});
}

function onDrop(e, si) {
	e.preventDefault();
	const c = document.getElementById('sc-' + si);
	if (c) c.draggable = false;
	if (dragSrcIdx === null || dragSrcIdx === si) {
		cleanDrag();
		return;
	}
	const moved = D.sections.splice(dragSrcIdx, 1)[0];
	D.sections.splice(si, 0, moved);
	dragSrcIdx = null;
	persist();
}

function onDragEnd() {
	document.querySelectorAll('.sec-card').forEach((c) => (c.draggable = false));
	cleanDrag();
}

/**
 * Moves a section one place up or down from the keyboard, the way a drag
 * does (WCAG 2.1.1, 2.5.7), keeps the focus on its handle and says where it
 * now stands.
 * @param {number} si - The section's index.
 * @param {number} step - -1 to move it up, 1 to move it down.
 */
function moveSection(si, step) {
	const to = si + step;
	if (to < 0 || to >= D.sections.length) return;
	const moved = D.sections.splice(si, 1)[0];
	D.sections.splice(to, 0, moved);
	persist();
	const handle = document.getElementById('dh-' + to);
	if (handle) handle.focus();
	document.getElementById('move-status').textContent = _t('editor.hotstrings.section_moved')
		.replace('{name}', moved.description || moved.name)
		.replace('{n}', String(to + 1))
		.replace('{total}', String(D.sections.length));
}

function cleanDrag() {
	dragSrcIdx = null;
	document
		.querySelectorAll('.sec-card')
		.forEach((c) => c.classList.remove('drag-over', 'dragging'));
}

// ====================================
// ====================================
// ======= 10/ Main Renderer ==========
// ====================================
// ====================================

function buildCmdGrid() {
	const b = document.getElementById('cmd-block');
	b.innerHTML = '';
	getCmdGroups().forEach((g, gi) => {
		if (gi > 0) {
			const s = document.createElement('hr');
			s.className = 'cmd-sep';
			b.appendChild(s);
		}
		// Each group of commands under its heading, inside the dialog's h2.
		const l = document.createElement('h3');
		l.className = 'cmd-grp-lbl';
		l.textContent = g.lbl;
		b.appendChild(l);
		g.cmds.forEach((c) => {
			// A button: the keyboard inserts a command as the mouse does.
			const el = document.createElement('button');
			el.type = 'button';
			el.className = 'cmd-ref';
			el.title = '{' + c.token + '} — ' + c.desc;
			// Label shows the canonical token name (Enter, Tab, Left…) — identical
			// across every locale and always capitalised; the localisable French
			// description stays in the hover tooltip above.
			el.innerHTML =
				'<b class="cmd-sym" aria-hidden="true" data-tok="' +
				escapeHtml(c.token) +
				'">' +
				escapeHtml(c.sym) +
				'</b><kbd class="cmd-lbl">' +
				escapeHtml(c.token) +
				'</kbd>';
			el.addEventListener('mousedown', (e) => e.preventDefault());
			el.addEventListener('click', () => insertChipAtCursor(c.token));
			b.appendChild(el);
		});
	});
}

function dispTrig(s) {
	if (!s) return '';
	return escapeHtml(toDisplay(s))
		.split(escapeHtml(TRIGGER_CHAR))
		.join('<kbd class="trig-star">' + escapeHtml(magicKeyDisplay(TRIGGER_CHAR)) + '</kbd>');
}

function dispOutput(s) {
	if (!s) return '';
	const display = toShown(s);
	const tokens = /\{([^}]+)\}/g;
	let out = '';
	let last = 0;
	let match;
	while ((match = tokens.exec(display)) !== null) {
		out += escapeHtml(display.slice(last, match.index));
		const canon = normToken(match[1]);
		out += '<kbd class="tc" data-tok="' + escapeHtml(canon) + '">' + escapeHtml(canon) + '</kbd>';
		last = tokens.lastIndex;
	}
	out += escapeHtml(display.slice(last));
	if (!compactView) {
		out = out.replace(/<kbd class="tc" data-tok="Enter">Enter<\/kbd>/g, '<br>');
	}
	return out;
}

let _rowMouseDownX = 0,
	_rowMouseDownY = 0;
function onRowMouseDown(e) {
	_rowMouseDownX = e.clientX;
	_rowMouseDownY = e.clientY;
}

/**
 * Whether a click ends a drag or a text selection rather than a plain click.
 * A click the keyboard made (detail 0, Enter or Space on a button) has no
 * pointer travel and always counts.
 * @param {MouseEvent} e
 * @returns {boolean}
 */
function isDragOrSelection(e) {
	if (e.detail === 0) return false;
	const dx = e.clientX - _rowMouseDownX,
		dy = e.clientY - _rowMouseDownY;
	if (Math.sqrt(dx * dx + dy * dy) > 4) return true;
	const sel = window.getSelection();
	return !!sel && sel.toString().length > 0;
}

function handleSecTitleClick(e, si) {
	if (isDragOrSelection(e)) return;
	showEditSec(si);
}

function handleRowClick(e, si, ei) {
	if (isDragOrSelection(e)) return;
	// The checkbox's label is its 44 px target (theme.css): a click on it
	// selects the row, the checkbox's own click following, and edits nothing.
	if (e.target.closest('.entry-cb-wrap')) return;

	let target = e.target;
	let field = null;
	while (target && target !== e.currentTarget) {
		if (target.dataset && target.dataset.f) {
			field = target.dataset.f;
			break;
		}
		target = target.parentElement;
	}
	showEditEntry(si, ei, field);
}

/**
 * Tells whether a section shows its entries. A section starts collapsed: only
 * an explicit fold choice made in this window, or a section the user just
 * created or added to, opens it.
 * @param {Object} s - The section.
 * @returns {boolean} True when the section is expanded.
 */
function isSectionExpanded(s) {
	return s._exp === true;
}

function togSec(si) {
	if (D.sections[si]) {
		D.sections[si]._exp = !isSectionExpanded(D.sections[si]);
		render();
	}
}

/**
 * Tests whether an entry matches the active search query. Matches against both
 * the raw trigger/output and their display form (so a query typed with the
 * user's magic-key character also hits stored stars).
 * @param {Object} e - The hotstring entry.
 * @returns {boolean} True when no query is active or the entry matches.
 */
function entryMatches(e) {
	if (!searchQuery) return true;
	const hay = (
		(e.trigger || '') +
		'\n' +
		(e.output || '') +
		'\n' +
		toDisplay(e.trigger || '') +
		'\n' +
		toDisplay(e.output || '')
	).toLowerCase();
	return hay.indexOf(searchQuery) !== -1;
}

window.onSearch = function (v) {
	searchQuery = (v || '').toLowerCase().trim();
	const clr = document.getElementById('search-clear');
	if (clr) clr.style.display = searchQuery ? 'flex' : 'none';
	render();
};

window.clearSearch = function () {
	const inp = document.getElementById('search-input');
	if (inp) inp.value = '';
	searchQuery = '';
	const clr = document.getElementById('search-clear');
	if (clr) clr.style.display = 'none';
	render();
};

function render() {
	const cont = document.getElementById('secs-container');
	const empty = document.getElementById('empty');
	const noRes = document.getElementById('no-results');
	const searching = searchQuery.length > 0;

	empty.style.display = 'none';
	if (noRes) noRes.style.display = 'none';

	if (!D || !D.sections || !D.sections.length) {
		cont.innerHTML = '';
		empty.style.display = 'block';
		return;
	}

	let html = '';
	let shownSections = 0;

	D.sections.forEach((s, si) => {
		const allEntries = s.entries || [];
		// Keep original indices so edit/delete/bulk keep targeting the right entry.
		const idx = [];
		allEntries.forEach((e, ei) => {
			if (entryMatches(e)) idx.push(ei);
		});
		// While searching, drop sections that have no matching entry entirely.
		if (searching && idx.length === 0) return;
		shownSections++;

		const cnt = allEntries.length;
		// Force-expand while searching so matches are always visible.
		const exp = searching ? true : isSectionExpanded(s);

		html += '<li class="sec-card" id="sc-' + si + '">';
		html += '<header class="sec-head' + (exp ? ' open' : '') + '">';
		// Buttons, not clickable spans: the keyboard folds, edits, deletes and
		// moves a section as the mouse does (WCAG 2.1.1), and the fold says its
		// state.
		const secName = escapeHtml(s.description || s.name);
		// Reordering is meaningless on a filtered view, so hide the handle. It
		// drags with the mouse and moves with the Up and Down arrows.
		if (!searching)
			html +=
				'<button type="button" class="drag-handle" id="dh-' +
				si +
				'" title="' +
				(_t('editor.hotstrings.drag_handle_title') || 'Drag') +
				'" aria-label="' +
				escapeHtml(
					_t('editor.hotstrings.move_section').replace('{name}', s.description || s.name)
				) +
				'" aria-keyshortcuts="ArrowUp ArrowDown">☰</button>';
		html +=
			'<button type="button" class="caret' +
			(exp ? ' open' : '') +
			'" aria-expanded="' +
			exp +
			'" aria-label="' +
			secName +
			'" onclick="togSec(' +
			si +
			')">▶</button>';
		html +=
			'<h2 class="sec-heading"><button type="button" class="sec-title" title="' +
			escapeHtml(_t('editor.hotstrings.click_to_edit')) +
			'" onmousedown="onRowMouseDown(event)" onclick="handleSecTitleClick(event,' +
			si +
			')">' +
			secName +
			'</button></h2>';
		html += '<small class="sec-cnt">(' + (searching ? idx.length : cnt) + ')</small>';
		html +=
			'<button type="button" class="sec-del" aria-label="' +
			escapeHtml(_t('common.delete')) +
			' ' +
			secName +
			'" title="' +
			escapeHtml(_t('common.delete')) +
			'" onclick="delSec(' +
			si +
			')" onmousedown="event.stopPropagation()">✕</button>';
		html += '</header>';

		if (exp) {
			html += '<ul class="entries ' + (compactView ? 'compact' : 'expanded') + '">';
			idx.forEach((ei) => {
				const e = allEntries[ei];
				html +=
					'<li class="entry-row" onmousedown="onRowMouseDown(event)" onclick="handleRowClick(event,' +
					si +
					',' +
					ei +
					')">';
				html +=
					'<label class="entry-cb-wrap"><input type="checkbox" class="entry-cb" data-si="' +
					si +
					'" data-ei="' +
					ei +
					'" aria-label="' +
					escapeHtml(_t('editor.hotstrings.select_entry') + ' ' + e.trigger) +
					'" onclick="event.stopPropagation(); updateBulk()" onmousedown="event.stopPropagation()"></label>';
				html +=
					'<div class="e-trig"><button type="button" class="trig-lbl" data-f="trig" title="' +
					escapeHtml(_t('editor.hotstrings.click_to_edit')) +
					'">' +
					dispTrig(e.trigger) +
					'</button></div>';
				html += '<span class="e-arrow" aria-hidden="true">→</span>';
				html +=
					'<div class="e-out-cell"><p class="e-out" data-f="out" title="' +
					escapeHtml(_t('editor.hotstrings.click_to_edit')) +
					'">' +
					dispOutput(e.output) +
					'</p></div>';
				// The options the entry has, as a list of tags.
				const tag = (field, key) =>
					'<li class="tag on" data-f="' + field + '">' + escapeHtml(_t(key)) + '</li>';
				html += '<ul class="e-tags">';
				if (e.is_word) html += tag('cb-word', 'editor.hotstrings.tag_word');
				if (e.auto_expand) html += tag('cb-auto', 'editor.hotstrings.tag_auto');
				if (e.is_case_sensitive) html += tag('cb-case', 'editor.hotstrings.tag_case');
				if (e.final_result) html += tag('cb-final', 'editor.hotstrings.tag_final');
				if (e.action) html += tag('e-action', 'editor.hotstrings.tag_action');
				if (typeof e.priority === 'number')
					html += '<li class="tag on tag-prio" data-f="prio">P' + e.priority + '</li>';
				html += '</ul>';
				html +=
					'<button type="button" class="e-del" aria-label="' +
					escapeHtml(_t('common.delete') + ' ' + e.trigger) +
					'" title="' +
					escapeHtml(_t('common.delete')) +
					'" onclick="delEntryStop(event,' +
					si +
					',' +
					ei +
					')">✕</button>';
				html += '</li>';
			});
			html += '</ul>';
			// The add button is hidden on a filtered view to avoid appending into
			// a section the user is only browsing through search results.
			if (!searching)
				html +=
					'<button class="btn-add" onclick="showAddEntry(' +
					si +
					')">' +
					(_t('editor.hotstrings.btn_add_entry') || '＋ Add a hotstring') +
					'</button>';
		}
		html += '</li>';
	});

	if (searching && shownSections === 0) {
		cont.innerHTML = '';
		if (noRes) noRes.style.display = 'block';
		return;
	}

	cont.innerHTML = html;

	// Drag-to-reorder is only wired in the unfiltered view (handles aren't rendered
	// while searching, and reordering a partial list would corrupt section order).
	if (searching) return;
	D.sections.forEach((_, si) => {
		const handle = document.getElementById('dh-' + si);
		const card = document.getElementById('sc-' + si);
		if (!handle || !card) return;

		handle.addEventListener('mousedown', () => {
			card.draggable = true;
		});
		handle.addEventListener('keydown', (e) => {
			if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
			e.preventDefault();
			moveSection(si, e.key === 'ArrowUp' ? -1 : 1);
		});
		card.addEventListener('dragstart', (e) => onDragStart(e, si));
		card.addEventListener('dragover', (e) => onDragOver(e, si));
		card.addEventListener('drop', (e) => onDrop(e, si));
		card.addEventListener('dragend', onDragEnd);
	});
}

// ====================================
// ====================================
// ======= 11/ Section CRUD ===========
// ====================================
// ====================================

function showAddSec() {
	edSec = null;
	document.getElementById('sec-modal-title').textContent = _t(
		'editor.hotstrings.sec_modal_title_new'
	);
	const idEl = document.getElementById('sec-id');
	idEl.value = '';
	idEl.disabled = false;
	document.getElementById('sec-desc').value = '';
	clearSecErrors();
	openModal('sec-modal');
	setTimeout(() => idEl.focus(), FOCUS_DELAY_MS);
}

function showEditSec(si) {
	edSec = si;
	const s = D.sections[si];
	document.getElementById('sec-modal-title').textContent = _t(
		'editor.hotstrings.sec_modal_title_rename'
	);
	const idEl = document.getElementById('sec-id');
	idEl.value = s.name;
	idEl.disabled = true;
	document.getElementById('sec-desc').value = s.description || '';
	clearSecErrors();
	openModal('sec-modal');
	setTimeout(() => document.getElementById('sec-desc').focus(), FOCUS_DELAY_MS);
}

function saveSec() {
	const id = document.getElementById('sec-id').value.trim();
	const desc = document.getElementById('sec-desc').value.trim();
	clearSecErrors();

	if (edSec === null) {
		if (!id) {
			setFieldError(
				'sec-id',
				'sec-id-err',
				_t('editor.hotstrings.err_id_required') || 'The identifier is required.'
			);
			document.getElementById('sec-id').focus();
			return;
		}
		if (!/^[a-z0-9_]+$/.test(id)) {
			setFieldError(
				'sec-id',
				'sec-id-err',
				_t('editor.hotstrings.err_id_invalid') ||
					'Invalid identifier: lowercase letters, digits and underscores only.'
			);
			document.getElementById('sec-id').focus();
			return;
		}
		if (D.sections.some((s) => s.name === id)) {
			setFieldError(
				'sec-id',
				'sec-id-err',
				(_t('editor.hotstrings.err_id_exists') || '« %s » already exists.').replace('%s', id)
			);
			document.getElementById('sec-id').focus();
			return;
		}
		D.sections.push({ name: id, description: desc || id, entries: [], _exp: true });
	} else {
		D.sections[edSec].description = desc || D.sections[edSec].name;
	}

	closeModal('sec-modal');
	persist();
}

function delSec(si) {
	const s = D.sections[si];
	showConfirm(
		(
			_t('editor.hotstrings.confirm_del_section') || 'Delete « %s » and all its hotstrings?'
		).replace('%s', s.description || s.name),
		function () {
			D.sections.splice(si, 1);
			persist();
		}
	);
}

// ====================================
// ====================================
// ======= 12/ Entry CRUD =============
// ====================================
// ====================================

/**
 * Parses the priority input into a non-negative integer, or null when empty/invalid.
 * An empty value means "inherit the source default" (no per-hotstring override),
 * so the key is then omitted from the saved TOML entry.
 * @param {string} raw - The raw input value.
 * @returns {number|null} The parsed priority or null.
 */
function parsePrio(raw) {
	const s = String(raw == null ? '' : raw).trim();
	if (s === '') return null;
	const n = parseInt(s, 10);
	if (!Number.isFinite(n)) return null;
	// Clamp to the accepted collision-priority range.
	return Math.max(0, Math.min(100, n));
}

// ========================================
// ======= Hotstring actions ==============
// ========================================

/**
 * Fills the action picker from the host's lists: nothing, the parameterless
 * actions, then the user's workflows. Hidden when the host offers none.
 */
function fillActionSelect() {
	const select = document.getElementById('e-action');
	const actions = Array.isArray(D.actions) ? D.actions : [];
	const workflows = Array.isArray(D.workflows) ? D.workflows : [];
	document.getElementById('action-box').hidden = actions.length === 0 && workflows.length === 0;
	select.replaceChildren();
	const none = document.createElement('option');
	none.value = '';
	none.textContent = _t('editor.hotstrings.action_none');
	select.appendChild(none);
	const group = (key, items, prefix) => {
		if (items.length === 0) return;
		const optgroup = document.createElement('optgroup');
		optgroup.label = _t(key);
		for (const item of items) {
			const option = document.createElement('option');
			option.value = prefix + item.value;
			option.textContent = item.label;
			optgroup.appendChild(option);
		}
		select.appendChild(optgroup);
	};
	group('editor.hotstrings.action_group_workflows', workflows, 'w:');
	group('editor.hotstrings.action_group_actions', actions, 'a:');
}

/** Shows the erase option only when an action is chosen. */
function updateActionFields() {
	const chosen = document.getElementById('e-action').value !== '';
	document.getElementById('erase-row').hidden = !chosen;
	document.getElementById('erase-desc').hidden = !chosen;
}

/**
 * The action picker's value for an entry.
 * @param {object} e
 * @returns {string}
 */
function actionValueOf(e) {
	if (!e || !e.action) return '';
	return e.action === 'run_workflow' ? 'w:' + (e.workflow || '') : 'a:' + e.action;
}

/**
 * Selects a stored action, keeping one this OS does not offer: a missing
 * option would blank the picker and the next save would drop the action.
 * @param {string} value An actionValueOf() result.
 */
function selectActionValue(value) {
	const select = document.getElementById('e-action');
	if (value !== '' && ![...select.options].some((option) => option.value === value)) {
		const option = document.createElement('option');
		option.value = value;
		option.textContent = value.slice(2);
		select.appendChild(option);
	}
	if (value !== '') document.getElementById('action-box').hidden = false;
	select.value = value;
}

/**
 * Writes the picker and the erase box into an entry being saved.
 * @param {object} entry
 */
function applyActionFields(entry) {
	const value = document.getElementById('e-action').value;
	if (value.startsWith('w:')) {
		entry.action = 'run_workflow';
		entry.workflow = value.slice(2);
	} else if (value.startsWith('a:')) entry.action = value.slice(2);
	if (entry.action && !document.getElementById('cb-erase').checked) entry.erase_trigger = false;
}

function resetEntryForm() {
	document.getElementById('e-trig').innerHTML = '';
	setEditorContent(document.getElementById('e-out'), '');
	document.getElementById('cb-word').checked = true;
	document.getElementById('cb-auto').checked = true;
	document.getElementById('cb-case').checked = false;
	document.getElementById('cb-final').checked = false;
	document.getElementById('e-prio').value = '';
	document.getElementById('e-action').value = '';
	document.getElementById('cb-erase').checked = true;
	updateActionFields();
	clearEntryErrors();
	updateHints();
	updateCbDescs();
	checkPh();
}

function showAddEntry(si) {
	edEntry = { si: si, ei: null };
	const secName = D.sections[si].description || D.sections[si].name;
	document.getElementById('entry-modal-title').textContent = (
		_t('editor.hotstrings.add_entry_title') || 'New hotstring — Section « %s »'
	).replace('%s', secName);
	resetEntryForm();
	openModal('entry-modal');
	setTimeout(() => document.getElementById('e-trig').focus(), FOCUS_DELAY_MS);
}

function showEditEntry(si, ei, focusField) {
	edEntry = { si: si, ei: ei };
	const e = D.sections[si].entries[ei];
	const secName = D.sections[si].description || D.sections[si].name;
	document.getElementById('entry-modal-title').textContent = (
		_t('editor.hotstrings.edit_entry_title') || 'Edit hotstring — Section « %s »'
	).replace('%s', secName);

	setTrigContent(document.getElementById('e-trig'), e.trigger || '');
	setEditorContent(document.getElementById('e-out'), e.output || '');

	document.getElementById('cb-word').checked = !!e.is_word;
	document.getElementById('cb-auto').checked = !!e.auto_expand;
	document.getElementById('cb-case').checked = !!e.is_case_sensitive;
	document.getElementById('cb-final').checked = !!e.final_result;
	document.getElementById('e-prio').value = typeof e.priority === 'number' ? e.priority : '';
	selectActionValue(actionValueOf(e));
	document.getElementById('cb-erase').checked = e.erase_trigger !== false;
	updateActionFields();

	clearEntryErrors();
	updateHints();
	updateCbDescs();
	checkPh();
	openModal('entry-modal');

	setTimeout(() => {
		let el = null;
		if (focusField === 'out') el = document.getElementById('e-out');
		else if (focusField === 'trig') el = document.getElementById('e-trig');
		else if (focusField === 'prio') el = document.getElementById('e-prio');
		else if (focusField && focusField.indexOf('cb-') === 0)
			el = document.getElementById(focusField);
		else el = document.getElementById('e-trig');

		if (el) {
			el.focus();
			if (el.isContentEditable && window.getSelection && document.createRange) {
				const range = document.createRange();
				range.selectNodeContents(el);
				range.collapse(false);
				const sel = window.getSelection();
				sel.removeAllRanges();
				sel.addRange(range);
			}
		}
	}, 80);
}

// Sorting uses the same normalized key for single edits and bulk moves. The
// original trigger is never changed, and ASCII punctuation keeps its old order.
function compareTriggers(a, b) {
	const key = (entry) =>
		(entry.trigger || '')
			.toLowerCase()
			.normalize('NFC')
			.replace(/[^\p{L}\p{M}\p{N}_]/gu, '');
	const left = key(a);
	const right = key(b);
	return left < right ? -1 : left > right ? 1 : 0;
}

function saveEntry(andNew) {
	clearEntryErrors();
	const trig = serializeTrigEditor(document.getElementById('e-trig'));
	const out = serializeEditor(document.getElementById('e-out'));

	if (!trig) {
		setFieldError(
			'e-trig',
			'trig-err',
			_t('editor.hotstrings.err_trigger_empty') || 'The trigger is required.'
		);
		setTimeout(() => document.getElementById('e-trig').focus(), 0);
		return;
	}
	// An entry that runs an action may type nothing.
	if (!out.trim() && document.getElementById('e-action').value === '') {
		setFieldError(
			'e-out',
			'out-err',
			_t('editor.hotstrings.err_output_empty') || 'The replacement is required.'
		);
		setTimeout(() => document.getElementById('e-out').focus(), 0);
		return;
	}

	let dupSection = null;
	D.sections.forEach((s, si2) => {
		(s.entries || []).forEach((e2, ei2) => {
			if (dupSection) return;
			if (edEntry.ei !== null && edEntry.si === si2 && ei2 === edEntry.ei) return;
			if (e2.trigger === trig) dupSection = s.description || s.name;
		});
	});

	const executeSave = () => {
		const entry = {
			trigger: trig,
			output: out,
			is_word: document.getElementById('cb-word').checked,
			auto_expand: document.getElementById('cb-auto').checked,
			is_case_sensitive: document.getElementById('cb-case').checked,
			final_result: document.getElementById('cb-final').checked,
			// The box is the user's "case-sensitive": an exact match, not only a
			// replacement kept as written. Field report of 2026-10-30: a checked
			// personal "sru" -> "SRU" still fired on a typed "SRU".
			is_case_sensitive_strict: document.getElementById('cb-case').checked
		};
		if (rowIdentityMode) {
			entry.origin_id =
				edEntry.ei === null
					? 'new:' + ++nextNewRowId
					: D.sections[edEntry.si].entries[edEntry.ei].origin_id;
		}
		// Optional collision-priority override; omitted when the field is blank
		// so the entry inherits the personal source default.
		const prio = parsePrio(document.getElementById('e-prio').value);
		if (prio !== null) entry.priority = prio;
		applyActionFields(entry);

		const si = edEntry.si;
		if (edEntry.ei === null) {
			D.sections[si].entries.push(entry);
			// Sections start collapsed; open this one so the new row is visible
			// (the shortcut mode adds to a section the user never opened).
			D.sections[si]._exp = true;
		} else D.sections[si].entries[edEntry.ei] = entry;

		D.sections[si].entries.sort(compareTriggers);

		persist();

		if (andNew) {
			edEntry = { si: si, ei: null };
			const secName = D.sections[si].description || D.sections[si].name;
			document.getElementById('entry-modal-title').textContent = (
				_t('editor.hotstrings.add_entry_title') || 'Create a hotstring — Section « %s »'
			).replace('%s', secName);
			resetEntryForm();
			setTimeout(() => document.getElementById('e-trig').focus(), EDIT_FOCUS_DELAY_MS);
			return;
		}

		if (openMode === 'shortcut' && autoClose) {
			closeModal('entry-modal');
			toLua('close', {});
			return;
		}
		closeModal('entry-modal');
	};

	if (dupSection) {
		showConfirm(
			(
				_t('editor.hotstrings.err_trigger_dup_msg') ||
				'The trigger <strong>%s</strong> already exists in <em>%s</em>.<br><br>Do you really want to redefine it?'
			)
				.replace('%s', escapeHtml(toShown(trig)))
				.replace('%s', escapeHtml(dupSection)),
			executeSave,
			{
				okLabel: _t('editor.hotstrings.btn_redefine') || 'Redefine',
				okColor: ThemeTokens.color('hue-5c3800'),
				isWarning: true
			}
		);
	} else {
		executeSave();
	}
}

function delEntryStop(e, si, ei) {
	e.stopPropagation();
	delEntry(si, ei);
}

function delEntry(si, ei) {
	const trig = toShown(D.sections[si].entries[ei].trigger);
	showConfirm(
		(_t('editor.hotstrings.confirm_del_entry') || 'Delete « %s »?').replace('%s', escapeHtml(trig)),
		function () {
			D.sections[si].entries.splice(ei, 1);
			persist();
		}
	);
}

// ====================================
// ====================================
// ======= 13/ Bulk Actions ===========
// ====================================
// ====================================

window.updateBulk = function () {
	const cbs = document.querySelectorAll('.entry-cb:checked');
	const bar = document.getElementById('bulk-bar');
	if (cbs.length > 0) {
		const cnt = cbs.length;
		document.getElementById('bulk-cnt').textContent =
			cnt +
			' ' +
			(cnt > 1
				? _t('editor.hotstrings.bulk_selected_other')
				: _t('editor.hotstrings.bulk_selected_one'));
		const sel = document.getElementById('bulk-sec-sel');
		// The list's first option names it, and is replaced on every refresh.
		sel.setAttribute('aria-label', _t('editor.hotstrings.bulk_move_placeholder'));
		sel.innerHTML =
			'<option value="">' +
			(_t('editor.hotstrings.bulk_move_placeholder') || 'Move to…') +
			'</option>';
		D.sections.forEach((s, idx) => {
			sel.innerHTML +=
				'<option value="' + idx + '">' + escapeHtml(s.description || s.name) + '</option>';
		});
		bar.style.display = 'flex';
	} else {
		bar.style.display = 'none';
	}
};

window.clearBulk = function () {
	document.querySelectorAll('.entry-cb').forEach((cb) => (cb.checked = false));
	window.updateBulk();
};

window.bulkDel = function () {
	const cnt = document.querySelectorAll('.entry-cb:checked').length;
	showConfirm(
		(_t('editor.hotstrings.confirm_del_bulk') || 'Delete %d selected item(s)?').replace('%d', cnt),
		function () {
			const cbs = Array.from(document.querySelectorAll('.entry-cb:checked'));
			const toDel = cbs.map((cb) => ({ si: parseInt(cb.dataset.si), ei: parseInt(cb.dataset.ei) }));
			toDel.sort((a, b) => (a.si !== b.si ? b.si - a.si : b.ei - a.ei));
			toDel.forEach((item) => D.sections[item.si].entries.splice(item.ei, 1));
			window.clearBulk();
			persist();
		}
	);
};

window.bulkMove = function () {
	const sel = document.getElementById('bulk-sec-sel');
	const destSi = parseInt(sel.value);
	if (isNaN(destSi)) return;

	const cbs = Array.from(document.querySelectorAll('.entry-cb:checked'));
	const toMove = cbs.map((cb) => ({ si: parseInt(cb.dataset.si), ei: parseInt(cb.dataset.ei) }));
	toMove.sort((a, b) => (a.si !== b.si ? b.si - a.si : b.ei - a.ei));

	toMove.forEach((item) => {
		const entry = D.sections[item.si].entries.splice(item.ei, 1)[0];
		D.sections[destSi].entries.push(entry);
	});

	D.sections[destSi].entries.sort(compareTriggers);

	sel.value = '';
	window.clearBulk();
	persist();
};

// ====================================
// ====================================
// ======= 14/ Data Sync & Init =======
// ====================================
// ====================================

function persist() {
	const payload = { sections_order: [], sections: {} };
	D.sections.forEach((s) => {
		payload.sections_order.push(s.name);
		payload.sections[s.name] = {
			description: s.description,
			entries: (s.entries || []).map((e) => {
				const o = {
					trigger: e.trigger,
					output: e.output,
					is_word: !!e.is_word,
					auto_expand: !!e.auto_expand,
					is_case_sensitive: !!e.is_case_sensitive,
					final_result: !!e.final_result,
					is_case_sensitive_strict: !!e.is_case_sensitive_strict
				};
				if (rowIdentityMode && typeof e.origin_id === 'string') o.origin_id = e.origin_id;
				// Carry an explicit per-hotstring priority through the save.
				if (typeof e.priority === 'number') o.priority = e.priority;
				if (e.action) {
					o.action = e.action;
					if (e.workflow) o.workflow = e.workflow;
					if (e.erase_trigger === false) o.erase_trigger = false;
				}
				return o;
			})
		};
	});
	toLua('save', payload);
	render();

	const t = document.getElementById('save-toast');
	t.classList.add('show');
	setTimeout(() => t.classList.remove('show'), TOAST_MS);
}

window.initData = function (d) {
	rowIdentityMode = d.row_identity === true;
	nextNewRowId = 0;
	D = d;
	TRIGGER_CHAR = d.trigger_char || '★';
	STAR = d.star || '★';
	compactView = !!d.compact_view;
	autoClose = !!d.auto_close;
	defaultSec = d.default_section || null;
	openMode = d.open_mode || 'menu';
	setDefaultPrio(d.default_priority);

	buildCmdGrid();
	fillActionSelect();
	updateHints();
	updateCompactBtn();

	document.getElementById('loading').style.display = 'none';
	document.getElementById('app').style.display = 'flex';
	render();

	if (openMode === 'shortcut' && defaultSec) {
		const si = D.sections.findIndex((s) => s.name === defaultSec);
		if (si >= 0) setTimeout(() => showAddEntry(si), ADD_ENTRY_DELAY_MS);
	}
};

// A host preference change must not replace the user's unsaved document.
window.updatePreferences = function (d) {
	if (!d) return;
	TRIGGER_CHAR = d.trigger_char || TRIGGER_CHAR;
	compactView = !!d.compact_view;
	autoClose = !!d.auto_close;
	defaultSec = d.default_section || null;
	updateHints();
	updateCompactBtn();
	render();
};

window.updateData = function (d) {
	if (D && D.sections && d && d.sections) {
		const m = {};
		D.sections.forEach((s) => (m[s.name] = s._exp));
		d.sections.forEach((s) => {
			if (m[s.name] !== undefined) s._exp = m[s.name];
		});
	}
	D = d;
	TRIGGER_CHAR = d.trigger_char || TRIGGER_CHAR;
	compactView = !!d.compact_view;
	autoClose = !!d.auto_close;
	defaultSec = d.default_section || null;
	setDefaultPrio(d.default_priority);

	updateHints();
	render();
};

/**
 * Records the personal source-default priority (sent by the Lua backend, which
 * reads it from the engine's single source) and shows it as the priority field's
 * placeholder — so a blank field visibly inherits that value, never a hardcoded one.
 * @param {number|undefined} value - The default priority from the backend.
 */
function setDefaultPrio(value) {
	defaultPrio = typeof value === 'number' ? value : null;
	const pe = document.getElementById('e-prio');
	if (pe) pe.placeholder = defaultPrio !== null ? String(defaultPrio) : '';
}

// ====================================
// ====================================
// ======= 15/ Event Wiring ===========
// ====================================
// ====================================

// Only the field that records a trigger holds the daemon's capture gate
// (maintainer decision of 2026-11-25): the layout emulation and the hotstrings
// keep typing in every other Ergopti field, while the trigger is typed raw, so
// writing an existing trigger there never expands it. The message keeps its
// name; `focused` now means "the trigger field has the focus".
const TRIGGER_FIELD_ID = 'e-trig';
let triggerFieldFocused = false;

/**
 * Tells the daemon whether the trigger field records the keys, once per change.
 * @param {boolean} focused - Whether the trigger field has the focus.
 */
function setTriggerFieldFocused(focused) {
	if (focused === triggerFieldFocused) return;
	triggerFieldFocused = focused;
	toLua('window_focus', { focused: focused });
}

document.addEventListener('focusin', function (e) {
	setTriggerFieldFocused(Boolean(e.target && e.target.id === TRIGGER_FIELD_ID));
});

document.addEventListener('focusout', function (e) {
	if (e.target && e.target.id === TRIGGER_FIELD_ID) setTriggerFieldFocused(false);
});

window.addEventListener(
	'blur',
	function (e) {
		if (e.target === window || e.target === document) setTriggerFieldFocused(false);
	},
	true
);

// Selection and input events may omit isComposing while an IME owns the DOM.
let imeComposing = false;
document.addEventListener('compositionstart', () => {
	imeComposing = true;
});
document.addEventListener('compositionend', () => {
	imeComposing = false;
});

document.querySelectorAll('.overlay').forEach((el) => {
	el.addEventListener('click', (e) => {
		if (e.target === el) closeModal(el.id);
	});
});

document.getElementById('msg-modal').addEventListener('keydown', (e) => {
	if (imeComposing || e.isComposing || e.keyCode === 229) return;
	if (e.key === 'Enter' || e.key === 'Escape') closeModal('msg-modal');
});

document.getElementById('confirm-modal').addEventListener('keydown', (e) => {
	if (imeComposing || e.isComposing || e.keyCode === 229) return;
	if (e.key === 'Escape') {
		_confirmCb = null;
		closeModal('confirm-modal');
	}
	if (e.key === 'Enter') {
		e.preventDefault();
		runConfirm();
	}
});

// The confirm dialog's OK/Cancel buttons carry no inline onclick (unlike the
// add/edit modals), so their behaviour must be wired here. Without this the
// pending `_confirmCb` is set but never fired — delete actions silently no-op.
document.getElementById('confirm-ok').addEventListener('click', runConfirm);
document.getElementById('confirm-cancel').addEventListener('click', () => {
	_confirmCb = null;
	closeModal('confirm-modal');
});

/**
 * Runs the pending confirmation callback (if any) and closes the dialog.
 * Clears the callback before invoking it so a callback that itself opens
 * another confirm cannot be clobbered.
 */
function runConfirm() {
	const cb = _confirmCb;
	_confirmCb = null;
	closeModal('confirm-modal');
	if (cb) cb();
}

document.getElementById('sec-modal').addEventListener('keydown', (e) => {
	if (imeComposing || e.isComposing || e.keyCode === 229) return;
	if (e.key === 'Enter') {
		e.preventDefault();
		saveSec();
	}
	if (e.key === 'Escape') closeModal('sec-modal');
});

document.getElementById('entry-modal').addEventListener('keydown', (e) => {
	if (imeComposing || e.isComposing || e.keyCode === 229) return;
	if (e.key === 'Escape') closeModal('entry-modal');
});

document.getElementById('sec-id').addEventListener('input', function () {
	clearFieldError('sec-id', 'sec-id-err');
	const p = this.selectionStart;
	const c = this.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
	if (c !== this.value) {
		this.value = c;
		this.setSelectionRange(Math.max(0, p - 1), Math.max(0, p - 1));
	}
});

document.getElementById('sec-id').addEventListener('keydown', function (e) {
	if (imeComposing || e.isComposing || e.keyCode === 229) return;
	if (
		[
			'Backspace',
			'Delete',
			'ArrowLeft',
			'ArrowRight',
			'ArrowUp',
			'ArrowDown',
			'Home',
			'End',
			'Tab',
			'Enter',
			'Escape'
		].indexOf(e.key) >= 0
	)
		return;
	if (e.metaKey || e.ctrlKey) return;
	if (!/^[a-z0-9_]$/i.test(e.key)) e.preventDefault();
});

document.addEventListener('selectionchange', function () {
	if (!imeComposing) ejectFromChip();
});

// Trigger Editor logic
(function () {
	const te = document.getElementById('e-trig');
	te.addEventListener('input', () => clearFieldError('e-trig', 'trig-err'));

	te.addEventListener('keydown', function (e) {
		if (imeComposing || e.isComposing || e.keyCode === 229) return;
		// Enter moves on to the expansion. Tab keeps the page order (the magic
		// key button, then the expansion): taking Tab here, Shift+Tab included,
		// held the focus between the two editors for good (WCAG 2.1.2).
		if (e.key === 'Enter') {
			e.preventDefault();
			document.getElementById('e-out').focus();
			return;
		}
		if (e.key === 'Backspace') {
			const sel = window.getSelection();
			if (!sel || !sel.rangeCount) return;
			const range = sel.getRangeAt(0);
			if (!range.collapsed) return;
			const node = range.startContainer,
				offset = range.startOffset;
			let chip = null;
			if (node === te && offset > 0) {
				const p = te.childNodes[offset - 1];
				if (p && p.nodeType === 1 && p.classList.contains('token-chip')) chip = p;
			} else if (node.nodeType === 3 && offset === 0 && node.previousSibling) {
				const p = node.previousSibling;
				if (p && p.nodeType === 1 && p.classList.contains('token-chip')) chip = p;
			}
			if (chip) {
				e.preventDefault();
				chip.parentNode.removeChild(chip);
				return;
			}
		}
		if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && !e.shiftKey) {
			const sel = window.getSelection();
			if (!sel || !sel.rangeCount || !sel.isCollapsed) return;
			const range = sel.getRangeAt(0);
			const node = range.startContainer,
				offset = range.startOffset;
			if (e.key === 'ArrowRight') {
				let next = null;
				if (node.nodeType === 3 && offset === node.length) next = node.nextSibling;
				else if (node.nodeType === 1 && offset < node.childNodes.length)
					next = node.childNodes[offset];
				if (next && next.nodeType === 1 && next.classList.contains('token-chip')) {
					e.preventDefault();
					const nr = document.createRange();
					nr.setStartAfter(next);
					nr.collapse(true);
					sel.removeAllRanges();
					sel.addRange(nr);
				}
			} else {
				let prev = null;
				if (node.nodeType === 3 && offset === 0) prev = node.previousSibling;
				else if (node.nodeType === 1 && offset > 0) prev = node.childNodes[offset - 1];
				if (prev && prev.nodeType === 1 && prev.classList.contains('token-chip')) {
					e.preventDefault();
					const nr = document.createRange();
					nr.setStartBefore(prev);
					nr.collapse(true);
					sel.removeAllRanges();
					sel.addRange(nr);
				}
			}
		}
	});

	te.addEventListener('input', function () {
		const sel = window.getSelection();
		if (!sel || !sel.rangeCount) return;
		const range = sel.getRangeAt(0);
		if (!range.collapsed) return;
		const node = range.startContainer;
		if (node.nodeType !== 3) return;
		const text = node.textContent;
		const idx = text.indexOf(TRIGGER_CHAR);
		if (idx < 0) return;
		const before = text.slice(0, idx);
		const after = text.slice(idx + TRIGGER_CHAR.length);
		node.textContent = before;
		const chip = makeTrigChip();
		const afterNode = document.createTextNode(after);
		const refNode = node.nextSibling;
		if (refNode) {
			node.parentNode.insertBefore(chip, refNode);
			node.parentNode.insertBefore(afterNode, chip.nextSibling);
		} else {
			node.parentNode.appendChild(chip);
			node.parentNode.appendChild(afterNode);
		}
		const nr = document.createRange();
		nr.setStart(afterNode, 0);
		nr.collapse(true);
		sel.removeAllRanges();
		sel.addRange(nr);
	});

	te.addEventListener('paste', function (e) {
		e.preventDefault();
		const text = (e.clipboardData || window.clipboardData).getData('text/plain');
		if (!text) return;
		const sel = window.getSelection();
		if (!sel || !sel.rangeCount) {
			te.appendChild(document.createTextNode(text));
			return;
		}
		const r = sel.getRangeAt(0);
		r.deleteContents();
		const frag = document.createDocumentFragment();
		const parts = text.split(TRIGGER_CHAR);
		parts.forEach((part, i) => {
			if (part) frag.appendChild(document.createTextNode(part));
			if (i < parts.length - 1) frag.appendChild(makeTrigChip());
		});
		r.insertNode(frag);
		r.collapse(false);
		sel.removeAllRanges();
		sel.addRange(r);
	});
})();

// Output Editor logic
(function () {
	const ed = document.getElementById('e-out');

	ed.addEventListener('input', () => clearFieldError('e-out', 'out-err'));

	ed.addEventListener('keydown', function (e) {
		if (imeComposing || e.isComposing || e.keyCode === 229) return;
		if (acItems.length > 0) {
			if (e.key === 'Tab') {
				e.preventDefault();
				applyAc(acItems[acIdx]);
				return;
			}
			if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
				e.preventDefault();
				acIdx = (acIdx + 1) % acItems.length;
				updateAcSel();
				return;
			}
			if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
				e.preventDefault();
				acIdx = (acIdx - 1 + acItems.length) % acItems.length;
				updateAcSel();
				return;
			}
			if (e.key === 'Enter' && !(e.metaKey || e.ctrlKey)) {
				e.preventDefault();
				applyAc(acItems[acIdx]);
				return;
			}
			if (e.key === 'Escape') {
				e.preventDefault();
				hideAc();
				return;
			}
		}
		// Tab keeps the page order (the special commands, the options, the
		// priority, then the buttons; Ctrl or Cmd + Enter saves): jumping to
		// Save on Tab and Shift+Tab alike skipped the options and held the
		// focus coming back (WCAG 2.1.2, 2.4.3).

		if (e.key === 'Enter' && e.shiftKey && (e.metaKey || e.ctrlKey)) {
			e.preventDefault();
			saveEntry(true);
			return;
		}
		if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
			e.preventDefault();
			saveEntry(false);
			return;
		}
		if (e.key === 'Enter') {
			e.preventDefault();
			insertBrAtCursor();
			return;
		}

		if (e.key === 'Backspace') {
			const sel = window.getSelection();
			if (!sel || !sel.rangeCount) return;
			const range = sel.getRangeAt(0);
			if (!range.collapsed) return;
			const node = range.startContainer,
				offset = range.startOffset;
			let chip = null;
			if (node === ed && offset > 0) {
				const p = ed.childNodes[offset - 1];
				if (p && p.nodeType === 1 && p.classList.contains('token-chip')) chip = p;
			} else if (node.nodeType === 3 && offset === 0 && node.previousSibling) {
				const p = node.previousSibling;
				if (p && p.nodeType === 1 && p.classList.contains('token-chip')) chip = p;
			}
			if (chip) {
				e.preventDefault();
				chip.parentNode.removeChild(chip);
				checkPh();
				return;
			}
		}

		if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && !e.shiftKey) {
			const sel = window.getSelection();
			if (!sel || !sel.rangeCount || !sel.isCollapsed) return;
			const range = sel.getRangeAt(0);
			const node = range.startContainer,
				offset = range.startOffset;
			if (e.key === 'ArrowRight') {
				let next = null;
				if (node.nodeType === 3 && offset === node.length) next = node.nextSibling;
				else if (node.nodeType === 1 && offset < node.childNodes.length)
					next = node.childNodes[offset];
				if (next && next.nodeType === 1 && next.classList.contains('token-chip')) {
					e.preventDefault();
					const nr = document.createRange();
					nr.setStartAfter(next);
					nr.collapse(true);
					sel.removeAllRanges();
					sel.addRange(nr);
				}
			} else {
				let prev = null;
				if (node.nodeType === 3 && offset === 0) prev = node.previousSibling;
				else if (node.nodeType === 1 && offset > 0) prev = node.childNodes[offset - 1];
				if (prev && prev.nodeType === 1 && prev.classList.contains('token-chip')) {
					e.preventDefault();
					const nr = document.createRange();
					nr.setStartBefore(prev);
					nr.collapse(true);
					sel.removeAllRanges();
					sel.addRange(nr);
				}
			}
		}
	});

	ed.addEventListener('input', function (e) {
		if (imeComposing || e.isComposing) return;
		tryConvertToken(ed);
		checkAc();
		checkPh();
	});

	ed.addEventListener('keyup', function (e) {
		if (imeComposing || e.isComposing || e.keyCode === 229) return;
		if (
			acItems.length > 0 &&
			['Tab', 'ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight', 'Escape', 'Enter'].indexOf(
				e.key
			) >= 0
		)
			return;
		if (e.key === '}') tryConvertToken(ed);
		checkAc();
		checkPh();
	});

	ed.addEventListener('blur', hideAc);

	ed.addEventListener('paste', function (e) {
		e.preventDefault();
		const text = (e.clipboardData || window.clipboardData).getData('text/plain');
		if (!text) return;
		const sel = window.getSelection();
		if (!sel || !sel.rangeCount) {
			ed.appendChild(document.createTextNode(text));
			checkPh();
			return;
		}
		const r = sel.getRangeAt(0);
		r.deleteContents();
		const frag = document.createDocumentFragment();
		parseToNodes(text).forEach((n) => frag.appendChild(n));
		r.insertNode(frag);
		r.collapse(false);
		sel.removeAllRanges();
		sel.addRange(r);
		checkPh();
	});
})();

document.addEventListener('click', function (e) {
	if (!document.getElementById('ac-popup').contains(e.target)) hideAc();
});

// Keep the priority field a bare integer within the accepted 0–100 range, even
// when typed (the number input's spinner already enforces the step and bounds).
(function () {
	const pe = document.getElementById('e-prio');
	if (!pe) return;
	pe.addEventListener('input', function () {
		let v = this.value.replace(/[^0-9]/g, '');
		if (v !== '') v = String(Math.min(100, parseInt(v, 10)));
		if (v !== this.value) this.value = v;
	});
})();

document.addEventListener('DOMContentLoaded', function () {
	toLua('ready', {});
});
