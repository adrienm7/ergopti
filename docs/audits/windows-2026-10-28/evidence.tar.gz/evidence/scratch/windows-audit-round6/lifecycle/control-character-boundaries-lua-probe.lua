local root="/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path=root.."lua/?.lua;"..package.path
local Json=require("json");local Policy=require("control.driver_control")
local function read(path) local f=assert(io.open(path,"rb"));local s=assert(f:read("*a"));assert(f:close());return s end
local spec=Policy.validate(Json.decode(read(root.."modules/control/driver_control.json")))
local corpus=Json.decode(read(root.."tests/corpus/control/driver_control.json"))
local max="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
local ids={
 {"allowed alphabet","aZ_09-",true,6},{"empty","",false,0},
 {"maximum length",max,true,64},{"oversize",max.."a",false,65},
 {"LF suffix","ok\n",false,3},{"CRLF suffix","ok\r\n",false,4},{"CR suffix","ok\r",false,3},
 {"maximum LF suffix",max.."\n",false,65},{"maximum CRLF suffix",max.."\r\n",false,66},
 {"interior LF","a\nb",false,3},{"space suffix","ok ",false,3},{"number",23,false,0},
}
local tokens={
 {"valid hexadecimal",max,true,64},{"LF suffix",max:sub(1,63).."\n",false,64},
 {"CRLF suffix",max:sub(1,62).."\r\n",false,64},{"uppercase",max:upper(),false,64},
 {"short",max:sub(1,63),false,63},{"long",max.."a",false,65},
 {"CR suffix",max:sub(1,63).."\r",false,64},{"LF prefix","\n"..max:sub(1,63),false,64},
 {"interior LF",max:sub(1,31).."\n"..max:sub(33),false,64},
}
local passed,failed=0,0
local function receipt(label,ok) print((ok and "PASS " or "FAIL ")..label);if ok then passed=passed+1 else failed=failed+1 end end
for _,row in ipairs(ids) do
 if type(row[2])=="string" then assert(#row[2]==row[4]) else assert(row[4]==0) end
 local text=Json.encode({schema=1,token=corpus.token,request_id=row[2]})
 local decoded=Json.decode(text);assert(decoded.request_id==row[2])
 local id,reason,echoed=Policy.parse_request(spec,text,corpus.token,Json.decode)
 local ok=(row[3] and id==row[2] and reason==nil and echoed==nil) or (not row[3] and id==nil and reason=="malformed" and echoed==nil)
 receipt("request id "..row[1],ok)
end
for _,row in ipairs(tokens) do
 assert(#row[2]==row[4]);receipt("token "..row[1],Policy.is_token(spec,row[2])==row[3])
end
print(passed.." passed, "..failed.." failed");os.exit(failed==0 and 0 or 1)
