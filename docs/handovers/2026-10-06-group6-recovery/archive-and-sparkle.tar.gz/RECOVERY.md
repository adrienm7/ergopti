# Finite reviewed recovery packet

Source-only preservation; this archive builder runs no candidate code, imports, tests, compiler or native fixture. Main checkout unchanged. Exact copied-file provenance/hashes are in INVENTORY.json. Original frozen manifests are preserved unchanged, including historical UNRUN labels; authentic qualification receipts supersede only the scopes actually executed below.

## Sparkle startup diagnostics

Revision2 source patch e970982f14bc35e030aed4bbb0b8fe870114153e931b67c9011bf317d17183fd, delta52250fedeb6cbe45b0f499db156aad27effd5a20a714d489051826976e6ed0fc, manifest e8d33e3abdddd88b4e3392c41046d2ab560f3a7ffcaa99b2bf6510006920b530. Bounded peer SOURCE ACK. Original26 Python controls, prior4 emission models and184 original CJS assertions preserved. Four additional primary-preservation controls:34 total. Linux zero/macOSone/Windowsten capability skips expected. Every new/revised Python/CJS/Swift diagnostic control remains UNPARSED/UNEXECUTED at preservation. No new macOS compilation or startup success. Actual471 wait.server-start10s/SIG15 startup cause UNKNOWN. Optional trace refusal preserves existing body failure; trace-only failure remains nonzero. No accept-signals/policy/bootstrap workaround.

Qualification plan: root serial exclusive slot; original26 baseline, candidate34 with exact counts/skips, affected real CJS plus isolated new guard/mutations. Causal original instrumentation must fail exact added primary-refusal expectation while candidate preserves actual socket closure/receipt and exact exception. Then root-owned macOS manual CI on exact sources with existing CI-lock and ci-validation protocols: production Swift compile, parser XCTest, authentic Sparkle acceptance readiness/update/signature refusals/old-state/new-state/retirement and authentic per-case verdict. No trace prefix or lack of stderr substitutes success. If deadline remains, retain closed bounded phase facts and primary; do not enlarge bounds or infer cause.

## Linux C publication

Reviewed C7064fd9b/headerdc98e47a, generated helper6dcd4f66. Actual unprivileged kernel6.18.44: original11+new13+two explicit injection scopes PASS26, clock256 PASS, zero skips, actual generator build PASS; exact receipt records commands/source equality/UID1000/effective capabilitieszero. Binary is the exact qualification output, never manually activate/package it. Old11 intentionally leaves native name debt until process exit; expanded controls require explicit cleanup. Trusted exclusive private0700 namespace; no malicious same-UID isolation claim. C errno can be synthetic policy refusal: UNKNOWN unless syscall provenance independently admitted.

UNRUN: kernels5.15/6.8/6.12, Ubuntu22.04/24.04 installed packaging, actual opaque Lua lease/digest/sealed-inode transfer consent/timer physical settlement chain, later install owner and production rollback joins. Private port qualification alone does not close those requirements. Native helper build/catalog/package/root publication remain root-owned.

## Tar feeder distinct qualification histories

First direct-Lua revision2: semantic6+12 PASS; actual native0 completed/1 FAIL/7 UNRUN, debt operation-retirement/publication-retained-for-consumers/native-loop. Original child PID/birth/group missing; physical descendant retirement UNKNOWN. Inputs retained at original location, no attribution/global kill/reconstructed ownership. This failure remains separate and is not erased by later passing run.

Reviewed revision4: authentic callback completion/refence and optional stdin bridge; actual kernel6.18.44 sequence bridge6→IO17→diagnostic7 all semantic30 PASS; actual native8 PASS under exact pinned sole existing run_native_subreaper.py; zero failures/skips/unrun in this scoped sequence. Guardian closure adopted5/pending0/rescue0; actual Lua+eight tar PID/PPID/group/birth receipts and one private closure checkpoint copied. Exact1898-file cohort before/after equal. Five-second case/ten-second await/forty-second guardian budgets preserved. Missing closure/rescue/debt remains FAIL.

UNRUN: full fixed-registry updater/download/hash/transfer settlement/new install-consent/async installer/listing/layout/swap/rollback/packaging chain, native lower kernels and current-origin source composition/revalidation. The private overlay8 PASS is not installed updater completion and does not identify first failure cause.

## Exclusions and resumption

Omitted full static snapshots, all raw logs/stdout/stderr, private native source/extracted fixture trees, signed URLs, release keys, certificates and host user data. Cohort inventories are receipts, not included snapshots. Some recorded source paths are local historical provenance only. Restage exact immutable dependencies using cohort hashes and root-approved source; never run absolute historical commands against a different checkout without rebinding the cohort and ownership. Do not use display names for retained FD authority or restore an old process identity. Root owns main files, tests slots, branch/CI/merge and coordination with shared_failure62.
