// Independent closed-summary controls, frozen before any parser correction.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const evidence = require(path.resolve(process.argv[2]));
const rows = JSON.parse(fs.readFileSync(path.join(__dirname, 'FROZEN-SUMMARY-CONTROLS.json'), 'utf8'));
let failures = 0;
for (const row of rows) {
  try {
    assert.equal(evidence.evaluate(row.transcript, 0, 0).complete, row.expected_complete, row.name);
    console.log('PASS ' + row.name);
  } catch (error) {
    if (error.code !== 'ERR_ASSERTION') throw error;
    failures++;
    console.error(error.stack);
  }
}
console.log(JSON.stringify({controls:2,passed:2-failures,assertion_failures:failures,native_executed:0}));
process.exitCode = failures ? 1 : 0;
