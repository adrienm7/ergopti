# Root fixed Browse receiving fence V3

Source-only preparation. This packet has not been parsed or executed and changes
no canonical Source, index, HEAD, ref, installer, saved activation, or namespace.
The outer tracked/selected-source snapshot function is byte-identical to the
reviewed original Root wizard fence V2. It captures every tracked path and the
qualification-selected union, including ignored Source, membership, file/symlink
kinds, raw index bytes and HEAD. These checks run again independently in finally.

Admission requires qualification exit0, its exact raw log hash and unchanged
input/index/HEAD acknowledgements, all qualification Source pins, exactly one
ordinary title commit with the qualification HEAD as sole parent and only
qualified added/modified paths, a clean feature branch, and matching actual
published origin feature HEAD. Neither an old commit nor a merely green subset
can replace that actual result.

V4 proposal/freeze/review and all worker/controller/actor/dependency/installer/
wrapper/helper bytes are pinned. The separate installer must already have
finished genuinely; this fence neither installs nor invokes a generic command.
It admits the original current V7 Root outer PASS receipt by its explicitly
provided SHA, checks the same qualification/published HEAD/source/index state,
and admits its genuine inner five-mode receipt and retained exact profile.
Original V7 raw logs/receipts, qualification raw data/log, and frozen sources
remain unchanged. Native caches may evolve during the new GUI session; V4's
existing independent file checks retain config/bootstrap/metrics bytes and both
new-target emptiness. No independent oracle is regenerated.

The only command is the fixed saved reaper → saved GTK namespace → frozen V4
Browse controller, with the admitted real V7 receipt. Accepted output must contain
all original four ordered phases and all original named DOM assertions, every
existing independent file-check group and actual actor retirement assertion,
raw actor/native receipts, acknowledged full session/Manager cleanup, no errors,
and final exact654 Source/Git matching. All raw new Browse outputs are retained
by hashes and checked again before the outer receipt qualifies.

V2 changes only metadata bindings from reviewed Browse V3 to its reviewed V4
verifier-only successor, plus the actual installer verifier/authenticated-output
provenance input checks. Whole tracked/selected snapshots, Root admission, all
original DOM/phase/file assertions and final reconciliation remain unchanged.
The original V1 outer packet and V3 actual installation failure are preserved.
No signature verification or installer command is executed by this outer fence.

## Root invocation after independent review and serial-slot release

First verify this packet's frozen helper SHA against its independent review.
The selected title qualification currently reported by Root is
`FINAL-TITLES-CORRECTED-SELECTED-ACTUAL-20261011.json`, SHA
`c62d8f354ef4c9533fcb88998c85289f80ccc989ca3566dd39296c1af8cf98d9`.
Its sole ordinary title child is `4a3c33546c2da8976da6ae97cbd6336b2d3d5080`.
These observations are admission inputs, not a Browse runtime PASS.

After genuine chooser installation and successful current V7 outer receiving:

```bash
python3 /workspace/ergopti-delivery/group1-complete-resume-20261007/linux-wizard-browse-root-fence-source-v3-compiler-continuation-bindings-20261011/receive-browse-with-root-fence.py \
  --qualification /workspace/ergopti-delivery/group1-complete-resume-20261007/FINAL-TITLES-CORRECTED-SELECTED-ACTUAL-20261011.json \
  --qualification-sha c62d8f354ef4c9533fcb88998c85289f80ccc989ca3566dd39296c1af8cf98d9 \
  --expected-head 4a3c33546c2da8976da6ae97cbd6336b2d3d5080 \
  --v7-root-receipt /ABSOLUTE/ACTUAL/V7-ROOT-RECEIPT.json \
  --v7-root-receipt-sha ACTUAL_RETAINED_V7_ROOT_SHA256 \
  --receipt /workspace/ergopti-delivery/group1-complete-resume-20261007/ACTUAL-BROWSE-ROOT-RECEIPT.json \
  --execute
```

The input, output receipt and log paths must be distinct, absolute and owned;
existing outputs are refused. Run only in Root's released native slot. Actual
runtime refusal preserves the raw log and primary plus independent reconciliation
debt. Source review does not establish signature, loader, GTK chooser, Browse,
physical input, Wayland or installed-driver acceptance. The V4 explicit unrun
stdout/exit and device limitations remain unchanged.

V3 adds only the reviewed exact two-package compiler continuation and its actual
compiler/default-sqv provenance as immutable receiving inputs. The genuine V4
worker/controller/actor and independent Browse oracle remain byte-identical.
The existing signed extraction failure and reviewed outer V2 are preserved.
Root must complete the separate C2 continuation before this outer runtime; no
installation, verifier or compiler is invoked by this outer fence.
