# Autonomous diagnostic Swift receiving on current Dev

Base: 591d59a942780465bca95956dc3cc9b2e960fa9e. Exactly four Swift paths;
no whole feature chain, no additional native owner, Lua, workflow, generated
artifact, schema, menu, installation or configuration change is required by
source inspection. The historical old Dev worker/test preimages are byte-exact
on current Dev; both new diagnostic paths are still absent there.

Receive only `standalone-dev591-diagnostic4.patch` using `git apply --check` in
the actual receiving checkout. Verify all four preimages from MANIFEST.json;
refuse changed preimages. The three corrected identities are taken from the
parent's exact currently reviewed uncommitted three-file diff, applied to the
original standalone packet, rather than copying feature postimages/extra owners.

The exact three corrections ignore mutable nlink only for non-strict directory
identity, preserve every strict-directory and regular-file link equality, and
construct two trusted temporary fixture URLs from Darwin realpath. The three-file
inverse restores all original diagnostic postimages. All 146 worker and 19
observer method identities and original XCTAssert lines remain unchanged.

This remains diagnostics only. It does not fix watchdog exit73/PONG/READY,
validate live generation/retirement, or qualify production fencing/hardware.

Historical native run37979226215, sourcea9e8b1722164347d56989a483675ec660063bffb:
146 worker methods =140PASS/6FAIL/0SKIP;19observer =3PASS/16FAIL/0SKIP.
All165 completed; the full package run failed. Surrounding feature source differs
from this autonomous Dev context. Those old failures are never relabelled green.

Current native run38021918215, source2e148b057967c3774f9b659ab15105923a198732:
synthetic admission probe and strict terminal verdict PASS; archive24PASS/1FAIL
of25 plus separate SDKPASS. Overall run FAIL. Probe observations support native
ancestor normalization and owned directory nlink2->3->2 while immutable identity
is equal. They do not execute the corrected store/next-observation APIs.

The current corrected worker146+observer19 (165) methods, standalone compilation,
Intel/minimal-Dev runtime, packaging/install and physical input are UNRUN. Original
assertions, incident117 and partialitem24 remain. No TODO completion is claimed.
No native, JS suite, CI or canonical/index/ref modification was performed here.
