'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const base = __dirname;
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const original = fs.readFileSync(path.join(base, 'received/tools/ci/run-windows-personal-file-caption-cohort.cjs'), 'utf8');
const originalBlock = original.slice(original.indexOf('function sameImage('), original.indexOf('let runtimeSource, buildAdmission;'));
const candidate = fs.readFileSync(path.join(base, 'candidate/tools/ci/lib/native-pac-build-source.cjs'), 'utf8');
const root = '/held/source';
const evidence = '/held/runner/windows-personal-file-caption-build-source';
const receiverPath = root + '/tools/ci/receive-windows-personal-file-caption-build-source.ps1';
const inputPath = root + '/tools/ci/windows-personal-file-caption-cohort-inputs.json';
const pair = ['static/ergopti_plus/windows/vendor/ergopti_network_pac.exe', 'static/ergopti_plus/windows/vendor/ergopti_network_pac.json'];
const license = 'static/ergopti_plus/windows/vendor/ergopti_network_pac.LICENSE.txt';
const sourceReceipt = root + '/static/ergopti_plus/windows/build/native/network_pac/prepared/source_receipt.json';
const artifactReceipt = root + '/static/ergopti_plus/windows/build/native/network_pac/artifact_receipt.json';
const msvcReceipt = root + '/static/ergopti_plus/windows/build/native/network_pac/msvc_function.source.ps1';
const environment = {
 RUNNER_TEMP: '/held/runner', GITHUB_SHA: '0123456789abcdef0123456789abcdef01234567',
 GITHUB_RUN_ID: '38173146839', GITHUB_RUN_ATTEMPT: '1', GITHUB_JOB: 'test-ahk',
 PERSONAL_CAPTION_PREBUILD_OUTCOME: 'success', PERSONAL_CAPTION_RECEIVE_OUTCOME: 'success'
};
// These byte fixtures and expected fields are authored independently of the receiver.
// They model the existing protocol; they are not Windows compiler or artifact evidence.
function fixture() {
 const files = new Map();
 const put = (name, bytes) => files.set(name, Buffer.from(bytes));
 put(receiverPath, 'reviewed original CLI bytes\n'); put(inputPath, 'sealed exact owning input bytes\n');
 put(root + '/tools/build/build_windows_network_pac.ps1', 'original publisher bytes\n');
 put(root + '/.node-version', '22.22.2\n');
 put(sourceReceipt, 'original source receipt bytes\n'); put(artifactReceipt, 'original artifact receipt bytes\n');
 put(msvcReceipt, 'original MSVC discovery function bytes\n');
 const producer = { 'tools/build/build_windows_network_pac.ps1': sha(files.get(root + '/tools/build/build_windows_network_pac.ps1')) };
 const image = { [pair[0]]: sha('old executable\n'), [pair[1]]: sha('old manifest\n'), [license]: sha('original LICENSE bytes\n') };
 // Root's original literal3262 count remains active in the counterfactual.
 // Every filler is an explicit independent model pin, never an omitted input.
 for (let i = 0; i < 3259; i++) image['model-inputs/source-' + i] = sha('frozen source bytes\n');
 const fingerprint = 'a'.repeat(64);
 const policy = {
 scope: 'personal-file-caption-v7-genuine-native-pac-rebuild', rebuilt_paths: pair,
 directory_name: 'windows-personal-file-caption-build-source', producer_sha256: producer,
 node_version_sha256: sha(files.get(root + '/.node-version')), receiver_sha256: sha(files.get(receiverPath)),
 original_build_step_id: 'native-pac-build', original_build_command: './tools/build/build_windows_network_pac.ps1 -Publish',
 expected_current_source_fingerprint: fingerprint
 };
 const inputs = { source_sha256: image, build_provenance: policy };
 const before = {
 scope: policy.scope, stage: 'prebuild', status: 'PASS', inputs_sha256: sha(files.get(inputPath)),
 ci: { sha: environment.GITHUB_SHA, run_id: environment.GITHUB_RUN_ID, run_attempt: '1', job: 'test-ahk' },
 producer_source: { ...producer }, source_before: { ...image }
 };
 const beforeBytes = JSON.stringify(before); put(evidence + '/PREBUILD.json', beforeBytes);
 const runtime = { ...image, [pair[0]]: sha('actual built executable bytes\n'), [pair[1]]: sha(files.get(artifactReceipt)) };
 const after = {
 scope: policy.scope, stage: 'receive', status: 'PASS', inputs_sha256: before.inputs_sha256, ci: { ...before.ci },
 producer_source: { ...producer }, prebuild_sha256: sha(beforeBytes),
 original_build: { step_id: policy.original_build_step_id, command: policy.original_build_command, outcome: 'success' },
 received_files: { source_receipt: sha(files.get(sourceReceipt)), artifact_receipt: sha(files.get(artifactReceipt)), msvc_function: sha(files.get(msvcReceipt)) },
 runtime_pair: { [pair[0]]: runtime[pair[0]], [pair[1]]: runtime[pair[1]] }, runtime_source: runtime,
 actual_artifact_manifest: { source_fingerprint: fingerprint, exe_sha256: runtime[pair[0]] }
 };
 const stats = new Map();
 const writeProofs = () => { put(evidence + '/PREBUILD.json', JSON.stringify(before)); put(evidence + '/POSTBUILD.json', JSON.stringify(after)); };
 writeProofs();
 const fakeFs = {
 lstatSync(name) {
  if (name === evidence) return { isDirectory: () => true, isSymbolicLink: () => stats.get(name) === 'symlink' };
  if (!files.has(name)) throw new Error('MODEL_MISSING:' + name);
  return { isFile: () => true, isSymbolicLink: () => stats.get(name) === 'symlink' };
 },
 readFileSync(name, encoding) { if (!files.has(name)) throw new Error('MODEL_MISSING:' + name); const bytes = files.get(name); return encoding ? bytes.toString(encoding) : bytes; }
 };
 return { inputs, before, after, files, stats, writeProofs, fakeFs, env: { ...environment } };
}
function loadCandidate(model) {
 const module = { exports: {} };
 vm.runInNewContext(candidate, { module, require(name) { if (name === 'node:fs') return model.fakeFs; if (name === 'node:path') return path; if (name === 'node:crypto') return crypto; throw new Error('UNDECLARED_MODULE:' + name); }, process: { env: model.env } }, { filename: 'actual-extracted-module.cjs' });
 return module.exports;
}
function receive(model, api) {
 return api.receiveBuildSource({ root, inputs: model.inputs, inputPath, receiverPath,
 expectedScope: 'personal-file-caption-v7-genuine-native-pac-rebuild', sourceCount: 3262,
 prebuildOutcome: model.env.PERSONAL_CAPTION_PREBUILD_OUTCOME, receiveOutcome: model.env.PERSONAL_CAPTION_RECEIVE_OUTCOME });
}
function loadOriginal(model) {
 const context = { fs: model.fakeFs, path, sha, root, inputs: model.inputs, __dirname: root + '/tools/ci', process: { env: model.env }, demand(ok, message) { if (!ok) throw new Error(message); } };
 vm.runInNewContext(originalBlock, context, { filename: 'authenticated-original-function-only.cjs' });
 return context.receiveBuildSource();
}
const cases = [];
function check(name, callback) { cases.push([name, callback]); }
check('module import never acquires files or invokes native owners', () => {
 let reads = 0; const api = loadCandidate({ fakeFs: new Proxy({}, { get() { reads++; throw new Error('UNEXPECTED_ACQUISITION'); } }), env: {} });
 assert.equal(typeof api.receiveBuildSource, 'function'); assert.equal(reads, 0);
});
check('exact original function and candidate receive identical whole model3262 proofs', () => {
 const a = fixture(), b = fixture();
 assert.equal(JSON.stringify(loadOriginal(a)), JSON.stringify(receive(b, loadCandidate(b))));
});
check('only built pair changes while original LICENSE and every other model pin remain', () => {
 const m = fixture(), result = receive(m, loadCandidate(m));
 assert.equal(Object.keys(result.runtime).length, 3262);
 assert.equal(result.runtime[license], m.inputs.source_sha256[license]);
 assert.deepEqual(Object.keys(result.runtime).filter((name) => result.runtime[name] !== m.inputs.source_sha256[name]).sort(), [...pair].sort());
 assert.equal(Object.keys(result.held).length, 9);
});
const mutations = [
 ['prior run attempt', (m) => { m.after.ci.run_attempt = '2'; }, /same-run/],
 ['postbuild failure', (m) => { m.after.status = 'FAIL'; }, /same-run/],
 ['wrong scope', (m) => { m.after.scope = 'foreign-scope'; }, /same-run/],
 ['input commitment changed', (m) => { m.after.inputs_sha256 = 'b'.repeat(64); }, /same-run/],
 ['producer commitment dropped', (m) => { m.before.producer_source = {}; }, /producer commitment/],
 ['original source inventory dropped', (m) => { delete m.before.source_before[license]; }, /prebuild commitment/],
 ['original license replaced as third output', (m) => { m.after.runtime_source[license] = 'c'.repeat(64); }, /Only two/],
 ['extra license in received pair', (m) => { m.after.runtime_pair[license] = m.after.runtime_source[license]; }, /pair domain/],
 ['missing executable pair', (m) => { delete m.after.runtime_pair[pair[0]]; }, /pair domain/],
 ['original build failure', (m) => { m.after.original_build.outcome = 'failure'; }, /successful build/],
 ['source receipt raw bytes changed', (m) => { m.files.set(sourceReceipt, Buffer.from('changed source receipt\n')); }, /producer receipts/],
 ['MSVC discovery raw bytes changed', (m) => { m.files.set(msvcReceipt, Buffer.from('changed discovery\n')); }, /producer receipts/],
 ['producer source changed', (m) => { m.files.set(root + '/tools/build/build_windows_network_pac.ps1', Buffer.from('changed publisher\n')); }, /producer source changed/],
 ['node version changed', (m) => { m.files.set(root + '/.node-version', Buffer.from('foreign version\n')); }, /Node contract/],
 ['prebuild raw linkage changed', (m) => { m.after.prebuild_sha256 = 'd'.repeat(64); }, /proof linkage/],
 ['artifact executable identity changed', (m) => { m.after.actual_artifact_manifest.exe_sha256 = 'e'.repeat(64); }, /compiled-output linkage/],
 ['compiler recipe source fingerprint changed', (m) => { m.after.actual_artifact_manifest.source_fingerprint = 'f'.repeat(64); }, /compiled-output linkage/],
 ['evidence aliases directory', (m) => { m.stats.set(evidence, 'symlink'); }, /actual evidence directory/]
];
for (const [name, mutate, expected] of mutations) check('refuse ' + name, () => {
 const a = fixture(), b = fixture(); mutate(a); mutate(b); a.writeProofs(); b.writeProofs();
 assert.throws(() => loadOriginal(a), expected);
 assert.throws(() => receive(b, loadCandidate(b)), expected);
});
let failures = 0;
for (const [name, callback] of cases) {
 try { callback(); console.log('PASS ' + name); }
 catch (error) { failures++; console.error('FAIL ' + name); console.error(error.stack); }
}
console.log(JSON.stringify({ scope: 'MODELED_SOFTWARE_ONLY', selected: cases.length, passed: cases.length - failures, failed: failures, errors: 0, skipped: 0, node: process.version }));
process.exitCode = failures ? 1 : 0;
