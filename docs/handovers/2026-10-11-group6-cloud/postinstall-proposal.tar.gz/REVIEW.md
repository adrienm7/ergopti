# Exact-CA post-install observation proposal

Unadopted source proposal against current Dev `5f7a8467c9`. No live checkout,
index, reference, workflow or GitHub mutation was made. Source custody is still
pending. This is not a trust-policy correction or native qualification.

## Narrow composition

Recover the distinct post-install observation idea from retained Root commit
`61d37a718f`, which is reachable on `origin/main` and is not a Dev ancestor.
Current Dev already has the passive numeric TLS projection; do not duplicate it.

The proposed two-path patch gives the original trust-add command and its optional
existing exact-CA query one absolute 15-second budget. It performs the query only
after successful add settlement and only when the owning receiver already bound
its signed fixture executable. The query retains its existing two-second cap;
that cap never extends the installation deadline. A refused settled observation
cannot overwrite the original add fact. An unsettled query preserves its exact
failure, blocking settlement fact and resource debt. Native add failures remain
primary and acquire no query.

Post-install observations use stderr, preserving the PAC fixture's stdout JSON
reply ABI. Existing removal observations and all original 63 portable methods
remain unchanged. Four exact complete spans reconstruct the original fixture;
the test-only additive inverse reconstructs every byte of the original corpus.
`manifest.json` binds both preimages and candidate files. `proposal.patch` is a
review artifact, not an instruction to apply it without custody and fresh hashes.

## Receiving and evidence limits

Seven additive controls cover actual portable add/query children, exact DER
input, shared deadlines, physical child/pipe/capture closure, stdout preservation,
primary add failure, absent callee, settled query refusal, unsettled query debt,
deadline expiry without child acquisition, and refused diagnostic output.
The original source produces five assertion failures and two passes, without
errors or skips. The genuine physical counterexample is missing query execution
after a successful add; it fails at the observed command count before any new
metadata assertion. The candidate's seven controls pass. Complete candidate
receiving executes 70 methods with zero failures, errors or skips, preserving all
original 63 methods; see `candidate-full.log` for its terminal result.
Controlled POSIX children do not qualify Security, admin trust,
Darwin signatures, native TLS, PAC/WPAD or production operation.

The first additional-only predecessor receipt remains preserved separately; its
four errors came from new controls demanding missing deadline/diagnostic fields.
The second control revision turns those missing-field checks into explicit
assertions and accepts the original no-callee behavior. This changes only new
controls, not any original test or production preimage. Preserve both receipts.

No already qualified query callee is available in the current PAC XCTest order.
That XCTest runs before independent HTTP builds its signed fixture callee, and
the Swift package executable does not contain the test-only admin-query role.
PAC's Python producer receives no such executable. This proposal therefore adds
evidence only for receivers that already possess the exact callee; it cannot
join HTTP facts to PAC's different owned CA or establish a PAC trust cause.
No new compiler, workflow, trust lookup role, native enrollment or budget is
invented here. Native callee enrollment remains a separately reviewed prerequisite.

## Final formatted receiving

Pinned Ruff0.15.8 formats only the two isolated candidate files. Format check
and lint check both pass using the repository's existing configuration. The
original full63-method corpus stays byte-exact after the additive inverse.
The fixture's four complete inverse spans still reconstruct its exact preimage;
every byte outside those spans remains unchanged. Final formatted receiving
passes70/70 in27.394seconds with no failures, errors or skips. Formatted original
receiving executes seven new controls: two pass and five fail by assertion, with
no errors or skips. Previous unformatted and first-control-revision receipts
remain separately retained. Neither formatting nor this receiving changes any
native or trust qualification claim.

Parent source review explicitly accepts the narrow source/deadline/debt shape
and the first seven controls; it does not acknowledge external source custody,
adopt the patch or qualify native receiving. `reproduce.py` checks exact existing
checkout preimages and packet hashes, requires the pinned formatter and replays
both original-red and complete candidate receiving. It reuses the existing
checkout's unchanged support graph and creates no repository duplicate. Example:

```sh
python3 -I -B reproduce.py /workspace/ergopti --ruff /workspace/ergopti-cloud/python/bin/ruff
```

Required before adoption: custody acknowledgment, independent source review,
fresh exact preimages, normal selected gates, and exact-source Darwin receiving.
Both original PAC14 cohorts and HTTP/model setup/restoration, packaging/install,
enterprise devices and Windows maintainer-PC requirements remain open. No TODO
item, assertion, production qualification guard or withdrawn item22 is changed.

## Missing canonical enrollment

The live owner at tools/test/test-managed-ollama-protocol.cjs:302 strictly
requires63 receiving-facts methods. This isolated two-path proposal adds seven
methods and is therefore incomplete for live adoption until a separately owned
exact registry change requires70. Preserve every original63 body, all status,
summary, no-skip and command-budget predicates; do not accept multiple counts or
weaken the receiver. The count-only preparation is separate and unexecuted.
The full canonical JS gate on an adopted composition and native qualification
remain outstanding; isolated70 receiving cannot substitute for either.
