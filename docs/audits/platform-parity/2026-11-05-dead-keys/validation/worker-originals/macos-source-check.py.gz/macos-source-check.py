"""Bind original fixture/source files to pinned Git bytes and current disk."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
HERE = Path(__file__).parent
PIN = "f2c3ea43542c985fb20e5f0887976f1c02525341"
RELATIVE = [
    "macos/modules/keymap/init.lua",
    "macos/modules/keymap/registry.lua",
    "macos/modules/keymap/expander.lua",
    "macos/modules/keymap/state.lua",
    "macos/adapters/synthetic_input.lua",
    "macos/adapters/text_sender.lua",
    "macos/infra/text_utils.lua",
    "macos/tests/helpers/init.lua",
    "macos/tests/stubs/hs.lua",
    "macos/tests/run.lua",
    "macos/tests/unit/modules/keymap/terminators/test_nav_invalidates_hotstring_buffer.lua",
    "macos/tests/unit/modules/keymap/registry/test_registry.lua",
    "macos/tests/unit/modules/keymap/expansion/test_expander.lua",
    "macos/tests/unit/modules/keymap/expansion/test_expander_delete_count_sanity.lua",
    "_shared/lua/hotstring_engine/injection_plan.lua",
]
files = []
for relative in RELATIVE:
    path = "static/ergopti_plus/" + relative
    disk = (ROOT / path).read_bytes()
    pinned = subprocess.check_output(["git", "show", PIN + ":" + path], cwd=ROOT)
    assert disk == pinned, path
    files.append({"path": path, "sha256": hashlib.sha256(disk).hexdigest()})
upstream = (HERE / "hammerspoon-eventtap_event.m.txt").read_bytes()
blob = hashlib.sha1(
    b"blob " + str(len(upstream)).encode() + b"\0" + upstream
).hexdigest()
metadata = json.loads((HERE / "hammerspoon-source-api.json").read_bytes())
assert blob == metadata["sha"] == "309784cd87b9e1ab4b6317a0c75f62456f3f7e43"
receipt = {
    "audited_sha": PIN,
    "files": files,
    "external_sources": [
        {
            "artifact": "hammerspoon-eventtap_event.m.txt",
            "sha256": hashlib.sha256(upstream).hexdigest(),
            "git_blob_sha1": blob,
            "metadata": "hammerspoon-source-api.json",
            "qualification": "Retained upstream Hammerspoon 1.1.1 source, not a native execution receipt.",
        }
    ],
}
(HERE / "source-receipts.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(
    json.dumps(
        {
            "audited_sha": PIN,
            "pinned_disk_files": len(files),
            "external_git_blob_matches_retained_api": True,
            "original_probe_sha256": hashlib.sha256(
                (HERE / "public-probe.lua").read_bytes()
            ).hexdigest(),
            "qualification": "Source identity only; no native behavior measured.",
        },
        indent=2,
    )
)
