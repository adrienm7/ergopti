# Independent qualification requirements (UNEXECUTED)

The native fixture must generate a private real gzip tar containing literal
linux/, _shared/, bin/ and install.sh roots, known bytes and no links. Its input
fixture is copied into a actual C-owned O_TMPFILE, staged and committed only
after original writer close. This control-only fixture loader may use explicit
generated helper/source paths; the installed registry may not fall back to them.

Required actual scopes before integration:

1. Names and verbose operations return independently literal expected roots and
   regular/directory kinds after all process/pipe/reader/timer closure ACKs.
2. Extraction of the same committed artifact produces literal expected contents
   in the retained safe workdir using unchanged owner/permission flags.
3. Rename the owned display entry temporarily and put known foreign archive
   bytes at that pathname: all three operations still consume retained original
   bytes, then control restores its own entry before exact C cleanup.
4. Withdraw exact install lineage before child dispatch: no success callback or
   external archive reopen, and every actually acquired owner retires.
5. Original deadline already expired: no new C duplicate/child acquisition.
6. Cancel with a genuinely submitted native fs_read whose callback is not yet
   delivered: cancellation is not physical settlement, no subsequent read/write
   occurs, and actual callback +descriptor/pipe/group/timer ACKs precede terminal.
7. An independently wrong captured length larger than bytes refuses actual early
   EOF; smaller length refuses overflow. No successful tar exit can override it.
8. Native pipe write backpressure permits only one pending write and blocks later
   reads. Genuine short/input failure, process failure and source withdrawal each
   preserve failure through late callback/EOF and cleanup success.

Separate explicitly injected controls (never reported as native syscall failures):
exact submitted-read callback held, duplicate/foreign callback, write submission
throws after acquiring native work, shutdown refusal, duplicate-close refusal,
stdin close callback held, supervisor exit/group absence held, timer ACK held,
callback reentry/stale generation and slow current callback crossing the original
deadline. They must independently refuse accepted=settled/success and retain debt.

Run exact unchanged old process unit/native cohort first. Against original owner,
new native stdin EOF/delivery controls must fail causally, not from missing imports
or a fake version. Against a mutated feeder with path reopen or logical-settlement
shortcut the relevant independent native/model expectation must fail. Do not
regenerate literal roots/content or old expectations from the new implementation.

Eight actual native scopes, six bridge models and12 I/O/debt models are authored,
UNPARSED/UNEXECUTED. Additional adverse I/O/debt models listed above remain
prerequisites to author/qualify before integration. Port qualification
C11+13+2/clock256 is separate; it cannot substitute these feeder/install scopes.
