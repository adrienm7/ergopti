"""Bounded lexical source witness, not an AutoHotkey interpreter or native test."""

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
PIN = "f2c3ea43542c985fb20e5f0887976f1c02525341"
OUT = Path(__file__).parent


def mask(text):
    chars = list(text)
    i = 0
    while i < len(text):
        if text.startswith("/*", i):
            end = text.find("*/", i + 2)
            if end < 0:
                raise ValueError("unclosed block")
            for j in range(i, end + 2):
                if chars[j] != "\n":
                    chars[j] = " "
            i = end + 2
        elif text[i] == ";" and (i == 0 or text[i - 1].isspace()):
            end = text.find("\n", i)
            end = len(text) if end < 0 else end
            chars[i:end] = " " * (end - i)
            i = end
        elif text[i] in "\"'":
            quote = text[i]
            end = i + 1
            while end < len(text):
                if text[end] == "`":
                    end += 2
                elif text[end] == quote:
                    end += 1
                    break
                else:
                    end += 1
            else:
                raise ValueError("unclosed quote")
            for j in range(i, end):
                if chars[j] != "\n":
                    chars[j] = " "
            i = end
        else:
            i += 1
    return "".join(chars)


def body(text, name):
    executable = mask(text)
    starts = []
    for candidate in re.finditer(r"(?m)^" + re.escape(name) + r"\(", executable):
        pos = candidate.end()
        depth = 1
        while depth and pos < len(executable):
            depth += (executable[pos] == "(") - (executable[pos] == ")")
            pos += 1
        while pos < len(executable) and executable[pos].isspace():
            pos += 1
        if not depth and pos < len(executable) and executable[pos] == "{":
            starts.append(pos + 1)
    if len(starts) != 1:
        raise ValueError("missing or duplicated function " + name)
    start = starts[0]
    depth = 1
    end = start
    while depth and end < len(executable):
        depth += (executable[end] == "{") - (executable[end] == "}")
        end += 1
    if depth or not executable[start : end - 1].strip():
        raise ValueError("empty or unclosed body")
    return text[start : end - 1], executable[start : end - 1]


controls = []
valid = '/* Fake() { } */\nReal() {\n s := "}"\n ; }\n return 1\n}\n'
assert "return 1" in body(valid, "Real")[1]
controls.append("quoted/comment braces and fake block function ignored")
for text, name in [
    (valid, "Fake"),
    ("X() {}", "X"),
    ("X() {", "X"),
    ('X() { "oops', "X"),
    ("X() { return 1 }\nX() { return 2 }", "X"),
    ("/*oops", "X"),
]:
    try:
        body(text, name)
    except ValueError:
        controls.append("rejected: " + repr(text))
    else:
        raise AssertionError("reader accepted invalid control")

prefix = "static/ergopti_plus/"
files = [
    "windows/modules/keymap/keylayout/keylayout_emulation.ahk",
    "windows/modules/keymap/keylayout/keylayout_parser.ahk",
    "windows/modules/keymap/keylayout/keylayout_tables.ahk",
    "windows/modules/keymap/keylayout/layout_registry.ahk",
    "windows/modules/keymap/layout.ahk",
    "windows/modules/keymap/layout/layout_ergopti.ahk",
    "windows/modules/keymap/layout/layout_shift_caps.ahk",
    "windows/modules/keymap/layout/layout_altgr.ahk",
    "windows/infra/master_gates.ahk",
    "windows/infra/lifecycle.ahk",
    "windows/infra/suppressive_inputhook_ownership.ahk",
    "windows/infra/hotstrings/hotstring_send.ahk",
    "windows/adapters/key_state.ahk",
    "windows/ErgoptiPlus.ahk",
    "windows/modules/hotstrings/hotstrings_helpers.ahk",
    "windows/modules/hotstrings/hotstrings_distances.ahk",
    "windows/modules/hotstrings.ahk",
    "windows/tests/unit/modules/keymap/test_keylayout_emulation.ahk",
    "windows/tests/unit/modules/keymap/test_layout_rows_policy.ahk",
    "windows/tests/unit/modules/keymap/test_ergopti_keylayout_tables.ahk",
    "windows/tests/meta/platform/remap/layers/test_deadkey_suspend_guard.ahk",
    "windows/tests/meta/platform/remap/layers/test_layout_deadkey_endkey.ahk",
    "windows/tests/meta/platform/remap/layers/test_deadkey_unmapped_base_char.ahk",
    "windows/tests/meta/platform/remap/layers/test_deadkey_timeout.ahk",
    "windows/tests/meta/platform/remap/layers/test_keymap_deadkey_emit_serialized.ahk",
    "windows/tests/meta/platform/remap/layers/test_deadkey_ring_push.ahk",
    "_shared/modules/features/layout_rows_policy.ahk",
    "_shared/lua/layout/layout_rows_policy.lua",
    "_shared/lua/layouts/keylayout.lua",
    "_shared/lua/json.lua",
    "_shared/data/keycodes/physical_keys.json",
    "_shared/modules/layouts/mac_keycodes.json",
]
paths = [prefix + path for path in files] + [
    "static/layouts/registry/ergopti_plus/ergopti_plus.keylayout"
]
receipts = []
for path in paths:
    disk = (ROOT / path).read_bytes()
    pinned = subprocess.check_output(["git", "show", PIN + ":" + path], cwd=ROOT)
    assert disk == pinned, path + " drift"
    receipts.append({"path": path, "sha256": hashlib.sha256(disk).hexdigest()})


def read(path):
    return (ROOT / prefix / path).read_text(encoding="utf-8-sig")


emulation = read(files[0])
checks = []


def check(label, condition):
    assert condition, label
    checks.append(label)


raw, executable = body(emulation, "_KLE_BaseCriterion")
check(
    "pending criterion returns before row policy",
    executable.index("if KLE_State != KEYLAYOUT_NEUTRAL_STATE")
    < executable.index("return true")
    < executable.index("LayoutRowIsEmulated(Sc)"),
)
raw, executable = body(emulation, "_KLE_OnKey")
check(
    "ordinary callback uses global base without row policy",
    "KeylayoutEmulation_LayerIsActive(ConfigLeaf.ERGOPTI_BASE) && !_KLE_DigitsOwnKey(Sc, Shift)"
    in executable
    and "LayoutRowIsEmulated" not in executable,
)
check(
    "callback distinguishes selected and native emit paths",
    "_KLE_Emit(Sc, Shift, false)" in executable
    and "KeylayoutEmulation_PressNative" in executable,
)
raw, executable = body(emulation, "_KLE_AltGrBindingOwner")
check(
    "actual registrar binds criterion and callback",
    "_KLE_BaseCriterion.Bind(Sc, false, ForegroundFn)" in executable
    and "_KLE_OnKey.Bind(Sc, false)" in executable,
)
entry = read("windows/ErgoptiPlus.ahk")
check(
    "registry boot precedes builtin layout registration",
    entry.index("KeylayoutEmulation_Boot(_ConfigDir)")
    < entry.index("#Include modules/keymap/layout.ahk")
    if "#Include modules/keymap/layout.ahk" in entry
    else entry.index("KeylayoutEmulation_Boot(_ConfigDir)")
    < entry.index("#Include modules\\keymap\\layout.ahk"),
)
raw, executable = body(read("windows/modules/keymap/layout.ahk"), "DeadKey")
check(
    "legacy capture has suspension and settled-owner guards",
    "A_IsSuspended" in executable
    and "!CaptureSettled" in executable
    and "SIHO_StartOwned" in executable
    and "SIHO_StopOwned" in executable,
)
check("legacy scalar capture bounded to two seconds", 'InputHook("L2 E C T2"' in raw)
raw, executable = body(
    read("windows/modules/hotstrings/hotstrings_helpers.ahk"), "ShouldActivateDeadkey"
)
check(
    "synthetic deadkey output success checked",
    "if SendNewResult(" in executable and "Ch3 != MK" in executable,
)
print(
    json.dumps(
        {
            "audited_sha": PIN,
            "qualification": "lexical source witness only; no AHK interpretation or native execution",
            "reader_controls": controls,
            "source_checks": checks,
            "pinned_disk_files": len(receipts),
        },
        indent=2,
    )
)
(OUT / "source-receipts.json").write_text(
    json.dumps({"audited_sha": PIN, "files": receipts}, indent=2) + "\n"
)
