local root=assert(arg[1])
local overlay=arg[2]
local paths={}
local function add(base)
 paths[#paths+1]=base.."/static/ergopti_plus/linux/?.lua"
 paths[#paths+1]=base.."/static/ergopti_plus/linux/?/init.lua"
end
if overlay then add(overlay) end
add(root)
paths[#paths+1]=root.."/static/ergopti_plus/_shared/lua/?.lua"
paths[#paths+1]=root.."/static/ergopti_plus/_shared/lua/?/init.lua"
package.path=table.concat(paths,";")..";"..package.path
require("compat.utf8").install()
require("luv")
local Fixture=require("tests.support.input_owner_fixture")
Fixture.with_manager_session({before_manager=function(s)
 s.bytes='[mod_combos]\nsimultaneous_threshold_ms = 100\nsymmetric = true\n[mod_combos.config.tab_then_caps_lock]\ncombo = "copy"\n'
end},function(s)
 s.edge("a",58,1,1000);s.edge("a",15,1,1010)
 s.edge("a",58,0,1020);s.edge("a",15,0,1021)
 print("COMPLETED_ACTIONS "..#s.actions)
 local finder=require("modules.hotstrings.device_finder")
 local slot="keyboard:"..s.paths.a
 local first=assert(s.reader.capture_source_owner(slot))
 local function reconcile()
  local result
  for _=1,s.hook.DEVICE_CHECK_TICKS do result=s.hook.check_device() end
  return result
 end
 finder.find_devices=function()return {s.paths.b},{} end
 assert(reconcile()==true,"legitimate remove must publish")
 assert(s.reader.source_owner_current(first)==false,"old Hook-owned reader must retire")
 finder.find_devices=function()return {s.paths.a,s.paths.b},{} end
 assert(reconcile()==true,"legitimate re-add must publish")
 local fresh=assert(s.reader.capture_source_owner(slot))
 assert(s.reader.source_owner_current(fresh)==true,"reconciled reader must be current before Stop")
 assert(s.hook.isRunning()==true)
 local stopped=s.hook.stop()
 print("STOP_RETURN "..tostring(stopped))
 print("RECONCILED_READER_CURRENT_AFTER_STOP "..tostring(s.reader.source_owner_current(fresh)))
 print("RECONCILED_SLOT_OPEN_AFTER_STOP "..tostring(s.reader.is_open(slot)))
 local clear=s.reader.source_owner_current(fresh)==false and s.reader.is_open(slot)==false
 -- Explicit private cleanup of this probe's captured current lease, after
 -- observing Stop. This grants no positive product or native proof.
 s.reader.retire_source(fresh)
 assert(clear,"Stop must retire the newly Hook-owned reconciled reader")
end)
