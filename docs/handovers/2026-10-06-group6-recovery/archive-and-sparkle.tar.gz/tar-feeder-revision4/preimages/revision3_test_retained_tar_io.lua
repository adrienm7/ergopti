-- UNEXECUTED adversarial semantic models, not native syscall/close proof.
-- Real pipe userdata is used only for handle-class validation, never spawned.
local part_path = assert(arg[1])
local actual_uv = require("luv")
local file = assert(io.open(part_path, "r")); local source = assert(file:read("*a")); assert(file:close())
local passed = 0
local function fixture()
	local state = { now = 100, reads = {}, writes = {}, closes = {}, shutdowns = {},
		child_closed = false, timer_closed = false, timer_cancels = 0, child_cancels = 0 }
	local pipe = actual_uv.new_pipe(false)
	local closed, close_issued = false, false
	local function cleanup()
		assert(not close_issued, "test-owned pipe close already attempted")
		close_issued = true
		actual_uv.close(pipe, function() closed = true end)
		actual_uv.run()
		assert(closed, "test-owned native pipe close ACK unavailable")
	end
	local uv = {}
	function uv.new_pipe() return pipe end
	function uv.hrtime() return state.now * 1e6 end
	function uv.fs_read(fd, capacity, offset, callback)
		local work = { fd = fd, capacity = capacity, offset = offset, callback = callback }
		state.reads[#state.reads + 1] = work
		if state.throw_read then error("INJECTED after submitted read") end
		return work
	end
	function uv.write(handle, chunk, callback)
		assert(handle == pipe); local work = { chunk = chunk, callback = callback }
		state.writes[#state.writes + 1] = work; return work
	end
	function uv.shutdown(handle, callback)
		assert(handle == pipe); local work = { callback = callback }
		state.shutdowns[#state.shutdowns + 1] = work
		if state.throw_shutdown then error("INJECTED after submitted shutdown") end
		return work
	end
	function uv.fs_close(fd, callback)
		local work = { fd = fd, callback = callback }; state.closes[#state.closes + 1] = work
		if state.refuse_close then return nil end
		return work
	end
	local deadline = {}
	function deadline.start(limit, callback)
		assert(limit == 200); state.expire = callback
		local actor = { started = true }
		function actor:cancel() state.timer_cancels = state.timer_cancels + 1; return true end
		function actor:is_settled() return state.timer_closed end
		function actor:on_settled(listener) state.timer_listener = listener; return true end
		return actor
	end
	local process = {}
	function process.start(executable, args, options, callback)
		assert(executable == "tar" and args[1] == "-tzf" and args[2] == "-")
		state.input, state.child_callback = options.stdin_owner, callback
		local actor = { started = true, result = { ok = true, stdout = "independent-model-stdout" } }
		function actor:cancel()
			state.child_cancels = state.child_cancels + 1; self.result.ok = false
			state.input:cancel(); return state.child_closed
		end
		function actor:is_settled()
			if state.child_closed and not state.callback_sent then
				state.callback_sent = true
				if not state.omit_callback then callback(state.callback_result or actor.result) end
			end
			return state.child_closed
		end
		function actor:on_settled(listener) state.child_listener = listener; return true end
		state.actor = actor
		return actor
	end
	local names = { "luv", "infra.managed_http_deadline", "adapters.owned_process" }
	local previous = {}; for _, name in ipairs(names) do previous[name] = package.loaded[name] end
	package.loaded.luv, package.loaded["infra.managed_http_deadline"], package.loaded["adapters.owned_process"] = uv, deadline, process
	local loaded, constructor = pcall(function() return assert(loadstring(source .. "\nreturn new_private_tar_feeder\n"))() end)
	local created, factory
	if loaded then
		created, factory = pcall(constructor, { ffi = { new = function() return { [0] = -1 } end },
			symbols = { allocate_reader = function(pointer, limit, output)
				assert(pointer == "MODEL-PRIVATE-POINTER" and limit == 200); output[0] = 101; return 0
			end } })
	end
	for _, name in ipairs(names) do package.loaded[name] = previous[name] end
	if not loaded or not created then pcall(cleanup); error(factory or constructor, 0) end
	function state.start(current)
		state.operation = assert(factory({ pointer = "MODEL-PRIVATE-POINTER", committed = true },
			"names", nil, 3, current or function() return true end, 200, function(result)
				state.callbacks = (state.callbacks or 0) + 1; state.result = result
			end))
		return state.operation
	end
	function state.finish_owners()
		state.child_closed = true; state.child_listener()
		state.timer_closed = true; state.timer_listener()
	end
	function state.complete_feed()
		assert(#state.reads == 1 and state.reads[1].offset == 0 and state.reads[1].capacity == 4)
		state.reads[1].callback(nil, "abc")
		assert(#state.writes == 1 and #state.reads == 1 and state.writes[1].chunk == "abc")
		state.writes[1].callback(nil)
		assert(#state.reads == 2 and state.reads[2].offset == 3 and state.reads[2].capacity == 1)
		state.reads[2].callback(nil, "")
		assert(#state.shutdowns == 1 and not state.input:can_close())
		state.shutdowns[1].callback(nil)
		assert(#state.closes == 1 and not state.input:is_settled())
		state.closes[1].callback(nil)
		assert(state.input:is_settled() and state.input:can_close())
	end
	return state, cleanup
end
local function test(name, check)
	local state, cleanup = fixture(); local ok, error = pcall(check, state)
	local cleaned, cleanup_error = pcall(cleanup)
	assert(ok, error); assert(cleaned, cleanup_error); passed = passed + 1; print("MODEL PASS " .. name)
end

test("success waits for one write then EOF shutdown duplicate close child and timer", function(state)
	local operation = state.start(); state.complete_feed()
	assert(not operation:is_settled() and state.result == nil and state.timer_cancels == 0)
	state.child_closed = true; state.child_listener()
	assert(not operation:is_settled() and state.result == nil)
	state.timer_closed = true; state.timer_listener()
	assert(operation:is_settled() and state.callbacks == 1 and state.result.ok)
	assert(state.result.stdout == "independent-model-stdout")
end)

test("cancel during submitted read cannot close duplicate or write its late bytes", function(state)
	local operation = state.start(); operation:cancel()
	assert(not operation:is_settled() and #state.closes == 0 and #state.writes == 0)
	state.reads[1].callback(nil, "abc")
	assert(#state.writes == 0 and #state.reads == 1 and #state.closes == 1)
	state.reads[1].callback(nil, "foreign-late-duplicate")
	assert(#state.closes == 1)
	state.closes[1].callback(nil); state.finish_owners()
	assert(operation:is_settled() and state.callbacks == 1 and not state.result.ok)
end)

test("cancel during backpressured write requires exact ACK before reader close", function(state)
	local operation = state.start(); state.reads[1].callback(nil, "abc"); operation:cancel()
	assert(#state.reads == 1 and #state.closes == 0 and not operation:is_settled())
	state.writes[1].callback(nil)
	assert(#state.reads == 1 and #state.closes == 1)
	state.writes[1].callback(nil); assert(#state.closes == 1)
	state.closes[1].callback(nil); state.finish_owners()
	assert(operation:is_settled() and not state.result.ok)
end)

test("slow foreign lineage probe cannot revive the original deadline", function(state)
	local probes = 0
	local operation = state.start(function()
		probes = probes + 1
		if probes == 3 then state.now = 200 end
		return true
	end)
	-- Probe3 occurs before first read; an implementation that rechecks only
	-- the earlier time would dispatch network-independent install work anyway.
	assert(#state.reads == 0 and #state.writes == 0 and #state.closes == 1)
	state.closes[1].callback(nil); state.finish_owners()
	assert(operation:is_settled() and not state.result.ok)
end)

test("throw after acquired read retains pending debt until its own callback", function(state)
	state.throw_read = true
	local operation = state.start()
	assert(not operation:is_settled() and #state.reads == 1 and #state.closes == 0)
	state.reads[1].callback(nil, "abc"); assert(#state.writes == 0 and #state.closes == 1)
	state.closes[1].callback(nil); state.finish_owners()
	assert(operation:is_settled() and not state.result.ok)
end)

test("refused duplicate close remains debt despite all external owner ACKs", function(state)
	state.refuse_close = true
	local operation = state.start()
	state.reads[1].callback(nil, "abc"); state.writes[1].callback(nil); state.reads[2].callback(nil, "")
	state.shutdowns[1].callback(nil)
	assert(#state.closes == 1 and not state.input:is_settled())
	-- This model intentionally supplies a callback AFTER explicit refusal;
	-- rejected closure cannot borrow its late success as physical authority.
	state.closes[1].callback(nil)
	state.finish_owners()
	assert(not operation:is_settled() and state.result == nil and #state.closes == 1)
end)

test("shutdown throwing after submission cannot omit its pending retirement", function(state)
	state.throw_shutdown = true
	local operation = state.start()
	state.reads[1].callback(nil, "abc"); state.writes[1].callback(nil); state.reads[2].callback(nil, "")
	assert(#state.shutdowns == 1 and #state.closes == 0 and not operation:is_settled())
	state.shutdowns[1].callback(nil); assert(#state.closes == 1)
	state.closes[1].callback(nil); state.finish_owners()
	assert(operation:is_settled() and not state.result.ok)
end)

test("timer stays armed while child group is pending and expiry cannot become success", function(state)
	local operation = state.start(); state.complete_feed()
	assert(state.timer_cancels == 0 and not operation:is_settled())
	state.now = 200; state.expire()
	assert(state.child_cancels == 1 and not operation:is_settled())
	state.finish_owners()
	assert(operation:is_settled() and not state.result.ok)
end)

for _, phase in ipairs({ "issue", "read-to-write", "eof-to-shutdown" }) do
	test("source cancellation refences " .. phase .. " before acquiring I/O", function(state)
		local probes = 0
		local limit = phase == "issue" and 3 or phase == "read-to-write" and 4 or 7
		local operation = state.start(function()
			probes = probes + 1
			if probes == limit then state.actor:cancel() end
			return true
		end)
		if phase ~= "issue" then state.reads[1].callback(nil, "abc") end
		if phase == "eof-to-shutdown" then state.writes[1].callback(nil); state.reads[2].callback(nil, "") end
		assert(#state.reads == (phase == "issue" and 0 or phase == "read-to-write" and 1 or 2))
		assert(#state.writes == (phase == "eof-to-shutdown" and 1 or 0))
		assert(#state.shutdowns == 0 and #state.closes == 1 and not operation:is_settled())
		state.closes[1].callback(nil); state.finish_owners()
		assert(operation:is_settled() and not state.result.ok)
	end)
end

-- Independent GC witness uses collectable MODEL userdata, not a native handle
-- whose binding may itself retain a registry reference. No physical-close claim.
do
	assert(type(newproxy) == "function", "LuaJIT model userdata prerequisite")
	local weak = setmetatable({}, { __mode = "k" })
	local uv = { hrtime = function() return 100000000 end }
	uv.new_pipe = function() local pipe = newproxy(true); weak[pipe] = true; return pipe end
	uv.fs_read = function() error("uncertain supervisor cannot submit reads") end
	uv.write = uv.fs_read; uv.shutdown = uv.fs_read
	uv.fs_close = function(_, callback) callback(nil); return {} end
	local deadline = { start = function()
		return { started = true, cancel = function() return true end, is_settled = function() return true end,
			on_settled = function() return true end }
	end }
	local process = { start = function() error("INJECTED supervisor throws after pipe acquisition") end }
	local previous = { package.loaded.luv, package.loaded["infra.managed_http_deadline"], package.loaded["adapters.owned_process"] }
	package.loaded.luv, package.loaded["infra.managed_http_deadline"], package.loaded["adapters.owned_process"] = uv, deadline, process
	local constructor = assert(loadstring(source .. "\nreturn new_private_tar_feeder\n"))()
	local factory = constructor({ ffi = { new = function() return { [0] = -1 } end }, symbols = {
		allocate_reader = function(_, _, output) output[0] = 101; return 0 end } })
	package.loaded.luv, package.loaded["infra.managed_http_deadline"], package.loaded["adapters.owned_process"] = previous[1], previous[2], previous[3]
	local callbacks = 0
	local operation = assert(factory({ pointer = "MODEL", committed = true }, "names", nil, 3,
		function() return true end, 200, function() callbacks = callbacks + 1 end))
	collectgarbage("collect"); collectgarbage("collect")
	local count = 0; for _ in pairs(weak) do count = count + 1 end
	assert(count == 1 and not operation:is_settled() and callbacks == 0)
	passed = passed + 1
	print("MODEL PASS exact acquired capability retained after supervisor handoff throws")
end

test("success has no error and authentic callback resists actor result mutation", function(state)
	local operation = state.start(); state.complete_feed()
	state.callback_result = { ok = true, stdout = "authenticated-terminal" }
	state.actor.result = { ok = false, stdout = "foreign-mutable-result" }
	state.finish_owners()
	assert(operation:is_settled() and state.result.ok and state.result.error == nil)
	assert(state.result.stdout == "authenticated-terminal")
end)

test("missing terminal callback cannot borrow mutable actor success", function(state)
	local operation = state.start(); state.complete_feed(); state.omit_callback = true
	state.finish_owners()
	assert(operation:is_settled() and not state.result.ok)
	assert(state.result.error == "retained tar operation failed" and state.result.stdout == nil)
end)

test("terminal callback uses raw closed fields without invoking getters", function(state)
	local operation = state.start(); state.complete_feed()
	state.callback_result = setmetatable({}, { __index = function() error("foreign getter") end })
	state.finish_owners()
	assert(operation:is_settled() and not state.result.ok and state.result.stdout == nil)
end)

test("failed authentic callback cannot borrow later mutable actor success", function(state)
	local operation = state.start(); state.complete_feed()
	state.callback_result = { ok = false, stdout = "authentic-failure" }
	state.actor.result = { ok = true, stdout = "foreign-success" }
	state.finish_owners()
	assert(operation:is_settled() and not state.result.ok)
	assert(state.result.stdout == "authentic-failure" and state.result.error == "retained tar operation failed")
end)

print(string.format("retained tar I/O semantic models: %d completed,0 skipped; no native syscall proof", passed))
