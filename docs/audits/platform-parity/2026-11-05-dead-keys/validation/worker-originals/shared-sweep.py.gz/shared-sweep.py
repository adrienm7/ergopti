"""Run final original-converter/native-Compose sweeps with exact receipts."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

P = Path(__file__).resolve().parent
ROOT = Path("/workspace/worktrees/parity-dead-keys-2026-11-05/shared")
ENV = dict(
    os.environ,
    PATH="/workspace/scratch/parity-toolchain/ci-bin:" + os.environ["PATH"],
    LOGNAME="agent",
    PYTHONDONTWRITEBYTECODE="1",
)
receipts = []
for index in (1, 2):
    runs = []
    commands = [
        (
            "enumeration",
            [
                "python",
                str(P / "shared_probe.py"),
                str(ROOT),
                "--output",
                str(P / f"enumeration-{index}.json"),
            ],
        ),
        (
            "prefix",
            [
                "python",
                str(P / "prefix_probe.py"),
                str(ROOT),
                str(P / f"prefix-{index}.json"),
            ],
        ),
        (
            "python-tests",
            [
                "python",
                str(
                    ROOT / "static/ergopti/linux/xkb_generation/tests/run_all_tests.py"
                ),
            ],
        ),
    ]
    for name, argv in commands:
        result = subprocess.run(
            argv, cwd=ROOT, env=ENV, capture_output=True, timeout=90
        )
        record = {
            "name": name,
            "argv": argv,
            "exit": result.returncode,
            "program_sha256": hashlib.sha256(Path(argv[1]).read_bytes()).hexdigest(),
            "outputs": {},
        }
        for kind, data in [("stdout", result.stdout), ("stderr", result.stderr)]:
            f = P / f"sweep-{index}-{name}.{kind}"
            f.write_bytes(data)
            record["outputs"][kind] = {
                "path": f.name,
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        assert result.returncode == 0, record
        runs.append(record)
    receipts.append({"sweep": index, "runs": runs})
(P / "sweeps.json").write_text(
    json.dumps(
        {
            "audited_sha": "f2c3ea43542c985fb20e5f0887976f1c02525341",
            "cwd": str(ROOT),
            "environment": {
                k: ENV[k] for k in ("PATH", "LOGNAME", "PYTHONDONTWRITEBYTECODE")
            },
            "sweeps": receipts,
        },
        indent=2,
    )
    + "\n"
)
