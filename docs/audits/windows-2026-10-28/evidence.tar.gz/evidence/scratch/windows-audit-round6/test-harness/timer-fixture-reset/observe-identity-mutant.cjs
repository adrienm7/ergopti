const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root='/workspace/ergopti-windows-r6-tests',packet=__dirname;
const runner=path.join(root,'static/ergopti_plus/windows/tests/run_all.ahk');
let source=fs.readFileSync(runner,'utf8');
for(const [a,b] of [['#Include ../adapters/timer_scheduler.ahk','#Include Z:'+path.join(packet,'guard-mutant-adapter.ahk').replaceAll('/','\\')],['#SingleInstance Force','#SingleInstance Off']]){
 assert.equal(source.split(a).length,2);source=source.replace(a,b);
}
const owned=path.join(path.dirname(runner),'.r6-stale-guard-'+crypto.randomBytes(6).toString('hex')+'.ahk');const fd=fs.openSync(owned,'wx');fs.writeFileSync(fd,source);fs.closeSync(fd);
const tap=path.join(packet,'guard-mutant.tap');let settled=false;
try{
 const argv=['--kill-after=5s','90s','xvfb-run','-a','wine','/workspace/toolchain/ahk/AutoHotkey64.exe','/ErrorStdOut','Z:'+owned.replaceAll('/','\\'),'--only','id-reuse regression'];
 const result=cp.spawnSync('timeout',argv,{encoding:'utf8',maxBuffer:1024*1024,env:{...process.env,WINEPREFIX:'/workspace/toolchain/wine-r3-metrics-owned',LC_ALL:'C.UTF-8',ERGOPTI_AHK_RESULTS_FILE:'Z:'+tap.replaceAll('/','\\')}});
 settled=result.status!==null&&result.status!==124&&result.signal===null&&!result.error;console.log(result.stdout,result.stderr);
 fs.writeFileSync(path.join(packet,'guard-mutant-receipt.json'),JSON.stringify({argv,status:result.status,signal:result.signal,error:result.error?.message},null,2)+'\n');
 assert(settled);const raw=fs.readFileSync(tap,'utf8');assert.equal(result.status,1);assert(raw.includes('1..1'));assert(raw.includes('before=3 old_fired=0'));assert(raw.includes('# stale_registry_guard after=2'));assert(raw.includes('# 0 passed, 1 failed.'));assert(raw.includes('a stale leaked timer\'s fire must NOT evict a live handle'));
}finally{if(settled)fs.unlinkSync(owned);}
