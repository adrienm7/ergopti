# Authenticated native HTTP prerequisite replay

The standalone Python addon embeds the 18 exact package identities observed
through the successful signed Debian APT setup and the six unchanged original
owner/pin hashes. It does not modify an installer, saved draft, existing prefix,
product curl, host package database or global trust.

Cheap existing-prefix readmission (tested, 1.15 seconds):

```sh
. /workspace/.ergopti-cloud/activate.sh
python3 -B /workspace/.ergopti-cloud/native-http-replay-20261015.py readmit \
  --repo /workspace/ergopti \
  --root /workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4 \
  --expected-admission-sha256 3dfe9522e30cfb64a7419b6a0a3acb67e5cd8fc125c59e514e49f958c773d224
```

This checks all 18 retained authenticated archive hashes, all 776 effective SDK
payloads/modes/links, the unchanged official tool admission reader, both actual
curl versions, the original pinned legacy signature/signer and real owned GIO
pkg-config flags. The caller-supplied admission digest is the retained trusted
observation; mutable cached receipt metadata is not accepted as authority.
All 7,185 existing-prefix entries retain modes, sizes, mtimes and link targets.
No compiler or native request gate ran. The already validated environment is:

```sh
. /workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/activate-native-http.sh
```

Reconstruction into a NEW owned prefix (reviewed replay of successful operations,
not executed again):

```sh
python3 -B /workspace/.ergopti-cloud/native-http-replay-20261015.py create \
  --repo /workspace/ergopti \
  --root /workspace/.ergopti-cloud/native-http-replay-example
```

Create refreshes authenticated APT metadata in the new prefix, requires every
exact signed package identity, downloads/verifies/extracts there, runs the
unchanged official 21-control/keyring/curl preparation, then physically readmits
the result. It emits a new admission digest and activation path. Retain that
fresh trusted digest outside the cache before later readmission. No current
prefix is overwritten or adopted implicitly.

The signed APT configuration/keyring from standard cloud setup and a real /usr
OpenSSL development SDK remain prerequisites. The official admission requires
/usr; the addon cannot substitute an owned OpenSSL prefix. Ordinary host build,
APT, Python, bootstrap curl and pkg-config tools must also be present. Exact
source/pin/config drift, missing/rotated package versions, authority refusal,
unsupported payloads or missing SDK cause refusal, never repinning or fallback.
The unchanged official setup retains its own bounded deadlines. Native output18,
public30, full gates, installation and physical acceptance remain unexecuted by
this addon. Saved configuration publication remains the parent's separate step.
