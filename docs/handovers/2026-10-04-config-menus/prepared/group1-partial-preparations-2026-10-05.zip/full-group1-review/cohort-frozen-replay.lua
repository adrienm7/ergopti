local source_root, packet, mode = assert(arg[1]), assert(arg[2]), assert(arg[3])
package.path=source_root..'/static/ergopti_plus/linux/?.lua;'..source_root..'/static/ergopti_plus/linux/?/init.lua;'..source_root..'/static/ergopti_plus/_shared/lua/?.lua;'..source_root..'/static/ergopti_plus/_shared/lua/?/init.lua;'..package.path
require('compat.utf8').install()
package.preload['test.config_scope_composition_contract']=function()return dofile(packet..'/postimages/static/ergopti_plus/_shared/lua/test/config_scope_composition_contract.lua')end
if mode=='old' then package.preload['config_scope_participant']=function()return dofile(packet..'/preimages/static/ergopti_plus/_shared/lua/config_scope_participant.lua')end end
local h=require('tests.helpers');h.reset_results()
require('tests.unit.infra.test_config_scope_composition')
local r=h.get_results();print('Cohort frozen:',r.passed,'passed;',r.failed,'failed');os.exit(r.failed>0 and 1 or 0)
