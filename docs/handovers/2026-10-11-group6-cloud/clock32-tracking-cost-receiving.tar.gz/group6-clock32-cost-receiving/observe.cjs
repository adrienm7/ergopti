'use strict';
const fs = require('node:fs');
const cp = require('node:child_process');
const started = process.hrtime.bigint();
const log = fs.openSync(process.env.CLOCK32_OBSERVATION, 'wx', 0o600);
let calls = 0;
const elapsed = () => Number(process.hrtime.bigint() - started) / 1e6;
const record = (value) => fs.writeSync(log, JSON.stringify(value) + '\n');
for (const role of ['execFileSync', 'spawnSync']) {
 const original = cp[role];
 cp[role] = function (...args) {
  const before = elapsed();
  let result, failure;
  try { result = Reflect.apply(original, this, args); return result; }
  catch (error) { failure = error; throw error; }
  finally {
   calls++;
   const argv = Array.isArray(args[1]) ? args[1] : [];
   record({role, executable:String(args[0]), argv, milliseconds:elapsed()-before,
    status: failure ? failure.status ?? null : result && Object.hasOwn(result,'status') ? result.status : 0,
    error: failure ? failure.code ?? failure.name : result?.error?.code ?? null,
    pid: result?.pid ?? failure?.pid ?? null});
  }
 };
}
const write = process.stdout.write;
process.stdout.write = function (...args) {
 const result = Reflect.apply(write, this, args);
 const value = String(args[0]);
 if (value.startsWith('PASS ') || value.startsWith('CLOCK_RECEIVER '))
  record({role:'original_stdout', milliseconds:elapsed(), calls, value:value.trim()});
 return result;
};
process.on('exit', code => { record({role:'terminal', milliseconds:elapsed(), calls, code}); fs.closeSync(log); });
