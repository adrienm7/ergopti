package.path='./?.lua;./?/init.lua;../_shared/lua/?.lua;../_shared/lua/?/init.lua;'..package.path
require('compat.utf8').install()
local helpers=require('tests.helpers');helpers.reset_results();helpers.set_only_filter(arg[2])
require(assert(arg[1]));local r=helpers.get_results();print('Focused:',r.passed,'passed;',r.failed,'failed');os.exit(r.failed>0 and 1 or 0)
