"""Receive actual fixed-path13 only; no compiler/helper/native TestCase runs."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import unittest

parser=argparse.ArgumentParser()
parser.add_argument('root',type=Path)
args=parser.parse_args()
path=args.root/'tools/test/macos_native_http_clock_contract_controls.py'
spec=importlib.util.spec_from_file_location('isolated_actual_clock_controls',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
assert len(module.enrolled_cases())==2
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
result=unittest.TextTestRunner(verbosity=2).run(suite)
facts={'qualification':'PORTABLE_FRAME_CONTEXT_ONLY_NO_DARWIN_NATIVE_CREDIT','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped)}
print(json.dumps(facts,sort_keys=True))
assert result.testsRun==13
sys.exit(0 if result.wasSuccessful() else 1)
