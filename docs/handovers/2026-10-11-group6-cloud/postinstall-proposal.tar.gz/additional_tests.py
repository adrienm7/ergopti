class NativePostInstallTrustObservationTests(unittest.TestCase):
    # Actual portable children qualify capture/closure only, never Apple trust.
    def setUp(self):
        self.fixture = WIRE.WireFixture(native=False)
        self.addCleanup(self.close_fixture)
        self.fixture.native = True
        self.fixture.trust_query_executable = "portable-owned-query"

    def close_fixture(self):
        self.fixture.native = False
        self.fixture.trust_attempted = False
        self.fixture.close()

    @staticmethod
    def receipt():
        return b'{"version":1,"export_status":0,"entry_count":1,"owned_status":0,"owned_present":1}'

    def test63ActualSuccessfulAddAndQueryShareBudgetAndRetireBeforeStderrReceipt(self):
        original = self.fixture._command
        children, requests = [], []
        real_popen = subprocess.Popen
        stdout, stderr = io.StringIO(), io.StringIO()

        def acquire(*arguments, **options):
            child = real_popen(*arguments, **options)
            child.output_owner, child.error_owner = options["stdout"], options["stderr"]
            children.append(child)
            return child

        def command(arguments, input_bytes=b"", **options):
            requests.append((arguments, input_bytes, options, time.monotonic()))
            if arguments[0] == "portable-owned-query":
                script = (
                    "import sys; sys.stdin.buffer.read(); sys.stdout.buffer.write("
                    + repr(self.receipt())
                    + ")"
                )
            else:
                self.assertEqual(arguments[3:5], ["add-trusted-cert", "-d"])
                script = "import sys; sys.stdout.buffer.write(b'original add output')"
            return original([sys.executable, "-I", "-B", "-c", script], input_bytes, **options)

        before = time.monotonic()
        with mock.patch.object(self.fixture, "_command", side_effect=command):
            with mock.patch.object(WIRE.subprocess, "Popen", side_effect=acquire):
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    self.fixture.trust(True)
        after = time.monotonic()
        self.assertEqual(len(requests), 2)
        self.assertEqual(requests[1][0], ["portable-owned-query", "--fixture-admin-trust-query"])
        self.assertEqual(requests[1][1], ssl.PEM_cert_to_DER_cert(self.fixture.ca.read_text()))
        add_deadline = requests[0][2]["deadline"]
        self.assertGreaterEqual(add_deadline, before + 15)
        self.assertLessEqual(add_deadline, after + 15)
        self.assertLessEqual(requests[1][2]["deadline"], add_deadline)
        self.assertLessEqual(requests[1][2]["deadline"], requests[1][3] + 2)
        self.assertEqual(len(children), 2)
        for child in children:
            self.assertEqual(child.returncode, 0)
            self.assertTrue(child.stdin.closed)
            self.assertTrue(child.output_owner.closed)
            self.assertTrue(child.error_owner.closed)
        self.assertEqual(stdout.getvalue(), "")
        lines = stderr.getvalue().splitlines()
        self.assertEqual(len(lines), 2)
        self.assertTrue(lines[0].startswith("# native_http_trust_outcome "))
        self.assertTrue(lines[1].startswith("# native_http_admin_trust_installed "))
        self.assertEqual(
            json.loads(lines[1].removeprefix("# native_http_admin_trust_installed "))[
                "owned_present"
            ],
            1,
        )
        self.assertTrue(self.fixture.trust_attempted)
        self.assertEqual(self.fixture.command_fact, {"phase": "complete", "status": 0})
        self.assertEqual(self.fixture.command_file_debt, [])

    def test64ExactAddFailureDoesNotAcquireQueryOrReplacePrimary(self):
        primary = subprocess.TimeoutExpired("owned original add", 15)
        with mock.patch.object(WIRE.time, "monotonic", return_value=100):
            with mock.patch.object(self.fixture, "_command", side_effect=primary) as command:
                with mock.patch.object(self.fixture, "_observe_admin_trust") as query:
                    with self.assertRaises(subprocess.TimeoutExpired) as caught:
                        self.fixture.trust(True)
        self.assertIs(caught.exception, primary)
        self.assertEqual(command.call_count, 1)
        self.assertEqual(command.call_args.kwargs.get("deadline"), 115)
        query.assert_not_called()
        self.assertTrue(self.fixture.trust_attempted)

    def test65UnavailableCalleeDoesNotAcquireObservationOrNewClock(self):
        self.fixture.trust_query_executable = None
        with mock.patch.object(WIRE.time, "monotonic") as clock:
            with mock.patch.object(
                self.fixture, "_command", return_value=(0, b"original")
            ) as command:
                with mock.patch.object(self.fixture, "_observe_admin_trust") as query:
                    self.fixture.trust(True)
        clock.assert_not_called()
        self.assertEqual(command.call_count, 1)
        self.assertIsNone(command.call_args.kwargs.get("deadline"))
        query.assert_not_called()
        self.assertTrue(self.fixture.trust_attempted)

    def test66ActualSettledRefusedQueryCannotOverwriteSuccessfulAddFact(self):
        original = self.fixture._command
        stdout, stderr = io.StringIO(), io.StringIO()

        def command(arguments, **options):
            if arguments[0] == "portable-owned-query":
                return original(
                    [
                        sys.executable,
                        "-I",
                        "-B",
                        "-c",
                        "import sys; sys.stdin.buffer.read(); sys.exit(7)",
                    ],
                    **options,
                )
            self.fixture.command_fact = {"phase": "complete", "status": 0}
            return 0, b"original"

        with mock.patch.object(self.fixture, "_command", side_effect=command):
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                self.fixture.trust(True)
        self.assertEqual(stdout.getvalue(), "")
        self.assertTrue(stderr.getvalue().startswith("# native_http_admin_trust_installed "))
        self.assertEqual(
            json.loads(stderr.getvalue().removeprefix("# native_http_admin_trust_installed ")),
            {"version": 1, "observed": 0},
        )
        self.assertEqual(self.fixture.command_fact, {"phase": "complete", "status": 0})
        self.assertEqual(self.fixture.command_file_debt, [])
        self.assertTrue(self.fixture.trust_attempted)

    def test67UnsettledQueryPreservesExactPrimaryAndBlockingFact(self):
        primary = RuntimeError("exact controlled query settlement refusal")

        def command(arguments, **options):
            if arguments[0] == "portable-owned-query":
                self.fixture.command_fact = {"phase": "settle", "status": None}
                raise primary
            self.fixture.command_fact = {"phase": "complete", "status": 0}
            return 0, b"original"

        with mock.patch.object(self.fixture, "_command", side_effect=command):
            with mock.patch("builtins.print") as output:
                with self.assertRaises(RuntimeError) as caught:
                    self.fixture.trust(True)
        self.assertIs(caught.exception, primary)
        self.assertEqual(self.fixture.command_fact, {"phase": "settle", "status": None})
        self.assertTrue(self.fixture.trust_attempted)
        output.assert_not_called()

    def test68ExpiredInstallationBudgetCannotAcquireQueryChildOrRenewClock(self):
        original = self.fixture._command

        def command(arguments, **options):
            if arguments[0] == "portable-owned-query":
                self.assertEqual(options["deadline"], 115)
                return original(arguments, **options)
            self.assertEqual(options.get("deadline"), 115)
            self.fixture.command_fact = {"phase": "complete", "status": 0}
            return 0, b"original"

        stderr = io.StringIO()
        with mock.patch.object(WIRE.time, "monotonic", side_effect=[100, 115, 115]):
            with mock.patch.object(self.fixture, "_command", side_effect=command):
                with mock.patch.object(WIRE.subprocess, "Popen") as acquire:
                    with contextlib.redirect_stderr(stderr):
                        self.fixture.trust(True)
        acquire.assert_not_called()
        self.assertEqual(
            json.loads(stderr.getvalue().removeprefix("# native_http_admin_trust_installed ")),
            {"version": 1, "observed": 0},
        )
        self.assertEqual(self.fixture.command_fact, {"phase": "complete", "status": 0})
        self.assertTrue(self.fixture.trust_attempted)

    def test69RefusedDiagnosticSinkCannotInvalidateSettledSuccessfulAdd(self):
        def command(arguments, **options):
            self.fixture.command_fact = {"phase": "complete", "status": 0}
            return (
                (0, self.receipt()) if arguments[0] == "portable-owned-query" else (0, b"original")
            )

        with mock.patch.object(self.fixture, "_command", side_effect=command):
            with mock.patch("builtins.print", side_effect=OSError("controlled closed stderr")):
                self.fixture.trust(True)
        self.assertEqual(self.fixture.command_fact, {"phase": "complete", "status": 0})
        self.assertTrue(self.fixture.trust_attempted)
        self.assertEqual(self.fixture.command_file_debt, [])
