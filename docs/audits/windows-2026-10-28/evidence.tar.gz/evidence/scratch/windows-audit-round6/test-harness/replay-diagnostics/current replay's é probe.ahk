﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Include Z:\workspace\ergopti-windows-r6-tests\static\ergopti_plus\windows\tests\test_framework.ahk
FileAppend("ACTUAL_RUNNER=" . A_ScriptFullPath . "`nACTUAL_INTERPRETER=" . A_AhkPath . "`n", "*", "UTF-8")
for ReplayProofIndex, ReplayProofValue in A_Args
 FileAppend("ACTUAL_ARG_" . ReplayProofIndex . "=" . ReplayProofValue . "`n", "*", "UTF-8")
Test("owned replay " . Chr(34) . "quote" . Chr(34) . " " . Chr(0xE9), () => AssertEqual("owned expected", "owned actual"))
RunTests()
