# Base URL parity inventory and bounded extraction proposal

Status: source inventory only. No test executed, source adopted or existing file
edited. Frozen Windows private publication/orchestration preparations are untouched.
All acceptance/refusal observations below are derived from the current source,
not from native execution.

## Current policy owners

- Mac `modules/llm/api_remote.lua:1036` owns the complete normalizer; its public
  `normalize_base_url` delegates to it. The Group4 endpoint tranche is already
  published at ea6e849df82f2a67e321b1ca7aa885f145101b93. Preserve its independent
  public-dispatch tests and avoid reimplementing finished behavior.
- Linux `modules/llm/api_remote.lua:274` has a shorter duplicate. It does not parse
  the bracketed IPv6 port separately and permits punctuation-only hosts.
- Windows `modules/llm/api_remote.ahk:1098`, `:1176` and `:1597` use only
  `https?://` plus nonspace text. `_LLMRemoteBuildUrl` appends paths or returns a
  full decisions endpoint; it is not a URL validator. Scalar guards additionally
  reject C0/C1 controls and escape curl configuration strings; preserve them.
- Scratch Windows panel `local_server_panel.ahk:354` trims user input, substitutes
  the provider default for empty input and uses the same weak URL regex.

## Concrete differences

| Input | Current Mac | Current Linux | Windows resolver/readiness/panel URL gate |
| --- | --- | --- | --- |
| `https://user:secret@fixture.invalid/v1` | Refuses userinfo | Refuses userinfo | Admits |
| `https://fixture.invalid/v1?route=other` | Refuses query | Refuses query | Admits |
| `https://fixture.invalid/v1#fragment` | Refuses fragment | Refuses fragment | Admits |
| `https://fixture.invalid/path\other` | Refuses backslash | Refuses backslash | Admits |
| `http://fixture.invalid:0/v1` | Refuses port | Refuses port | Admits |
| `http://fixture.invalid:65536/v1` | Refuses port | Refuses port | Admits |
| `https:///v1` | Refuses missing authority | Refuses missing authority | Admits |
| `http://fixture.invalid:abc/v1` | Refuses port | Refuses host | Admits |
| `http://[::1]:8080/v1` | Admits unchanged | Refuses | Admits unchanged |
| `http://[fe80::1%25en0]:8080/v1` | Admits unchanged | Refuses | Admits unchanged |
| `http://-/v1` | Refuses host | Admits | Admits |
| `http://[::::]/v1` | Refuses host | Admits | Admits |
| `HTTPS://Fixture.Invalid/Path///` | `https://Fixture.Invalid/Path` | Same | Retains raw scalar; builders vary |

In Windows an admitted query or fragment absorbs subsequently appended endpoint
text into that URL component. A rejected value must never reach model discovery,
request/native acquisition or private source publication. This is the concrete
local-server panel defect; actual transport behavior has not been exercised here.

## Proposed smallest shared boundary

1. Extract the existing Mac normalizer unchanged into a pure
   `_shared/lua/llm/base_url.lua` with `normalize(raw) -> normalized|nil, reason`.
   Keep the Mac public API/wrapper and all existing assertions. This moves
   finished policy into its shared owner without duplicating it.
2. Point Linux's existing public `normalize_base_url` at that owner. This restores
   valid bracketed IPv6+port/zone acceptance and rejects the two malformed host
   families above. Preserve valid input authority, leading-zero port, path case,
   encoded delimiters, interior slashes and path Unicode. Lowercase only the
   scheme and remove trailing `/`, exactly as current Mac behavior does.
3. Add a pure `_shared/modules/llm/base_url.ahk` counterpart, following the shared
   auth/discovery counterpart pattern. A proposed public helper is
   `RemoteBaseUrlNormalize(Value, &Reason := unset)` returning a String or `""`.
   It must check primitive String type before regex operations; use explicit
   ASCII scheme/host/port character classes, distinct bracket authority parsing,
   finite decimal port range 1..65535, literal userinfo/query/fragment/backslash
   refusal and the same trailing-slash rule. Refusal reasons contain categories,
   never the rejected input. No native port, timer, logger or callback belongs
   inside this pure helper.
4. Initially wire this counterpart into the Windows local-server panel address
   action and orchestration target acquisition only. Call normalization before
   any write/discovery factory, store its normalized return, preserve empty-value
   provider fallback and retain existing lifecycle/source/admission checks. Keep
   `_HTTP_CurlScalarIsSafe` and stronger transport scalar checks in place.
   These hooks require their actors' ownership; this inventory edits none.
5. General Windows remote resolver/readiness/catalogue integration is a separate
   coordinated boundary. Do not silently change `_LLMRemoteBuildUrl`'s public
   direct-call behavior: decisions endpoints deliberately return the exact input,
   including a meaningful final `/`, while other formats append paths. Prove
   complete endpoint compatibility before changing stored resolved values.

The extracted policy retains Mac's existing lexical bracket validation, not a
new comprehensive RFC IPv6 parser. Do not broaden this parity fix into DNS, IDNA,
percent decoding, slash folding, path canonicalization or locale whitespace
redesign. Existing transport-specific stronger scalar admission stays intact.
Panel whitespace treatment also needs a deliberate local rule: current Mac
normalization refuses whitespace; Windows panel calls `Trim` first. Prefer the
existing strict shared normalizer input rule rather than hiding invalid spaces,
while the exact empty string still selects the provider default.

## Ownership and registration

The inspected published remote ref is `origin/feat/release-network` at 866a9932f.
G6 commit b88d2c9689c5b7f05f8345e62ce642c782390e8d changes Windows
`modules/llm/api_remote.ahk` proxy dispatch/continuation/deadline hunks and appends
146 lines to `tests/unit/test_llm_api_remote.ahk`. Its bounded dispatch signature,
proxy ownership, cancellation, deadlines and new assertions must be preserved.
These are same-file ownership even when the proposed normalization hunk differs.
Parent must announce/reserve concrete hooks with G6 before adopting them and
recheck latest published refs/coordination; this saved observation is not a lock.
No remote ref was moved or workflow dispatched by this review.

Shared new module/corpus and native includes also need coordination with their
owners. AHK include must precede panel use and be present exactly once in its real
unit runner. Mac/Linux pure tests can load the new owner directly; native caller
tests must use the actual public wrappers and current transport/source seams.
Do not change port manifests, schemas, locales or generators for this policy.

## Independent validation preparation

`url-vectors.json` contains new hand-authored literal expectations. It is not
generated from the proposed policy or an existing implementation. Existing Mac
URL-dispatch, Linux request, Windows remote formats/control-character and G6
proxy tests must remain unchanged. Add shared-vector replay with a nonzero exact
case count in all three drivers, primitive type refusals, unchanged provider
catalogue positive cases and complete decisions endpoint compatibility.

Required composed local-server tests must assert that each invalid address makes
no private transaction/writer/native models acquisition, while valid IPv6 and
upper-scheme/trailing-slash input reaches the owner as its exact normalized value.
Add a source replacement at the final address-write seam to retain stale callback
protection. Test empty default fallback and whitespace refusal independently.
The same expected strings must be compared byte-for-byte; never regenerate them
from a normalizer. Native unit/E2E qualification needs actual Windows execution;
shared changes require Mac/Linux/Windows gates and later CI on the final sources.
Run `verify-change` serially with the parent's reserved test slot.
