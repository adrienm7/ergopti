// static/ergopti_plus/windows/native/key_combination_owner/pair_arbitration.c
/** @file pair_arbitration.c
 * @brief Portable logical plans; native ownership remains outside this module.
 */

#include "pair_arbitration.h"

#include <math.h>
#include <string.h>

static bool context_valid(const ErgoptiPair_Context *context) {
	return context != NULL && context->owner_epoch != 0 &&
		context->policy_revision != 0 && context->route_epoch != 0;
}

static bool policy_valid(const ErgoptiPair_Policy *policy) {
	size_t i, j;
	if (policy == NULL || policy->revision == 0 ||
		!isfinite(policy->simultaneous_threshold_ms) ||
		policy->simultaneous_threshold_ms <= 0 ||
		policy->row_count > ERGOPTI_PAIR_MAX_ROWS ||
		(policy->row_count != 0 && policy->rows == NULL)) return false;
	for (i = 0; i < policy->row_count; ++i) {
		const ErgoptiPair_Row *row = &policy->rows[i];
		const ErgoptiPair_Row *canonical;
		if (row->first_key == 0 || row->second_key == 0 ||
			row->first_key == row->second_key || row->pair_id == 0 ||
			row->canonical_index > i) return false;
		canonical = &policy->rows[row->canonical_index];
		if (row->canonical_index != i &&
			(canonical->first_key != row->second_key ||
			 canonical->second_key != row->first_key ||
			 canonical->canonical_index != row->canonical_index)) return false;
		for (j = 0; j < i; ++j) {
			const ErgoptiPair_Row *prior = &policy->rows[j];
			if (prior->pair_id == row->pair_id ||
				(prior->first_key == row->first_key &&
				 prior->second_key == row->second_key)) return false;
			if (prior->first_key == row->second_key &&
				prior->second_key == row->first_key &&
				row->canonical_index != j) return false;
		}
	}
	return true;
}

enum ErgoptiPair_Status ErgoptiPair_Initialize(
	ErgoptiPair_State *state, const ErgoptiPair_Policy *policy,
	const ErgoptiPair_Context *context) {
	ErgoptiPair_State candidate;
	if (state == NULL || !context_valid(context)) return ERGOPTI_PAIR_INVALID_ARGUMENT;
	if (state->initialized) return ERGOPTI_PAIR_ALREADY_INITIALIZED;
	if (!policy_valid(policy) || policy->revision != context->policy_revision)
		return ERGOPTI_PAIR_INVALID_POLICY;
	memset(&candidate, 0, sizeof(candidate));
	candidate.initialized = true;
	candidate.mode = context->current && context->enabled && !context->paused
		? ERGOPTI_PAIR_IDLE : ERGOPTI_PAIR_DISABLED;
	candidate.owner_epoch = context->owner_epoch;
	candidate.route_epoch = context->route_epoch;
	candidate.policy_revision = context->policy_revision;
	candidate.threshold_ms = policy->simultaneous_threshold_ms;
	candidate.symmetric = policy->symmetric;
	candidate.row_count = policy->row_count;
	if (policy->row_count != 0)
		memcpy(candidate.rows, policy->rows, policy->row_count * sizeof(*policy->rows));
	*state = candidate;
	return ERGOPTI_PAIR_OK;
}

static bool physical(const ErgoptiPair_Input *input) {
	return input->origin == ERGOPTI_PAIR_ORIGIN_PHYSICAL && input->key != 0 &&
		input->source != 0 && input->generation != 0 && input->press != 0;
}

static bool same_press(const ErgoptiPair_Input *left, const ErgoptiPair_Input *right) {
	return left->key == right->key && left->source == right->source &&
		left->generation == right->generation && left->press == right->press;
}

static bool same_slot(const ErgoptiPair_Input *left, const ErgoptiPair_Input *right) {
	return left->key == right->key && left->source == right->source &&
		left->generation == right->generation;
}

static bool same_context(const ErgoptiPair_State *state, const ErgoptiPair_Context *context) {
	return context->current && context->enabled && !context->paused &&
		context->owner_epoch == state->owner_epoch &&
		context->route_epoch == state->route_epoch &&
		context->policy_revision == state->policy_revision;
}

static const ErgoptiPair_Row *effective_row(const ErgoptiPair_State *state, size_t index) {
	return &state->rows[state->symmetric ? state->rows[index].canonical_index : index];
}

static bool first_candidate(const ErgoptiPair_State *state, uint32_t key) {
	size_t i;
	for (i = 0; i < state->row_count; ++i)
		if (state->rows[i].first_key == key && effective_row(state, i)->action_id != 0)
			return true;
	return false;
}

/* Integer native ticks admit a fractional positive threshold without rounding
 * it upward. Comparing the difference avoids an overflowing absolute deadline. */
static bool within_delay(const ErgoptiPair_State *state, uint64_t now) {
	uint64_t elapsed;
	if (now < state->first.at_ms) return false;
	elapsed = now - state->first.at_ms;
	if (state->threshold_ms >= (double)UINT64_MAX) return true;
	return elapsed <= (uint64_t)state->threshold_ms;
}

static const ErgoptiPair_Row *choose(const ErgoptiPair_State *state, uint32_t second) {
	size_t i;
	for (i = 0; i < state->row_count; ++i) {
		const ErgoptiPair_Row *row = &state->rows[i];
		if (row->first_key == state->first.key && row->second_key == second) {
			row = effective_row(state, i);
			return row->action_id != 0 ? row : NULL;
		}
	}
	return NULL;
}

static void retirement_plan(const ErgoptiPair_State *state, const ErgoptiPair_Input *input,
	ErgoptiPair_Plan *plan) {
	plan->requires_native_retirement = true;
	plan->withdrawal = state->withdrawal;
	if (state->first_down) plan->retirement_inputs[plan->retirement_count++] = state->first;
	if (state->second_down) plan->retirement_inputs[plan->retirement_count++] = state->second;
	if (input->kind <= ERGOPTI_PAIR_REPEAT &&
		((state->first_down && same_slot(&state->first, input)) ||
		 (state->second_down && same_slot(&state->second, input))))
		plan->current_route = ERGOPTI_PAIR_RETAIN_PROPOSAL;
}

static void withdraw(ErgoptiPair_State *state, const ErgoptiPair_Input *input,
	ErgoptiPair_Plan *plan, enum ErgoptiPair_Withdrawal reason) {
	state->withdrawal = reason;
	if (state->mode == ERGOPTI_PAIR_WAITING || state->mode == ERGOPTI_PAIR_CHORD) {
		state->mode = ERGOPTI_PAIR_RETIRING;
		retirement_plan(state, input, plan);
	} else {
		state->mode = ERGOPTI_PAIR_DISABLED;
		plan->withdrawal = reason;
	}
}

static void fallback(ErgoptiPair_State *state, ErgoptiPair_Plan *plan) {
	plan->flush_first = true;
	plan->original_first = state->first;
	state->mode = ERGOPTI_PAIR_HELD_ALONE;
}

enum ErgoptiPair_Status ErgoptiPair_Reduce(
	const ErgoptiPair_State *previous, const ErgoptiPair_Context *context,
	const ErgoptiPair_Input *input, ErgoptiPair_State *next,
	ErgoptiPair_Plan *plan) {
	ErgoptiPair_State state;
	ErgoptiPair_Plan result;
	const ErgoptiPair_Row *selection;
	bool key_event;
	if (previous == NULL || context == NULL || input == NULL || next == NULL || plan == NULL ||
		input->kind < ERGOPTI_PAIR_DOWN || input->kind > ERGOPTI_PAIR_CANCEL)
		return ERGOPTI_PAIR_INVALID_ARGUMENT;
	if (!previous->initialized) return ERGOPTI_PAIR_NOT_INITIALIZED;
	state = *previous;
	memset(&result, 0, sizeof(result));
	key_event = input->kind <= ERGOPTI_PAIR_REPEAT;
	result.current_route = key_event ? ERGOPTI_PAIR_PASS_ORIGINAL : ERGOPTI_PAIR_NO_EVENT;
	if (state.mode == ERGOPTI_PAIR_RETIRING) {
		retirement_plan(&state, input, &result);
		goto received;
	}
	if (state.mode == ERGOPTI_PAIR_DISABLED) goto received;
	if (!same_context(&state, context)) {
		withdraw(&state, input, &result, ERGOPTI_PAIR_WITHDRAW_CONTEXT);
		goto received;
	}
	if (input->kind == ERGOPTI_PAIR_CANCEL) {
		withdraw(&state, input, &result, ERGOPTI_PAIR_WITHDRAW_CANCEL);
		goto received;
	}
	if (state.observed_time && input->at_ms < state.last_at_ms) {
		withdraw(&state, input, &result, ERGOPTI_PAIR_WITHDRAW_CLOCK);
		goto received;
	}
	state.observed_time = true;
	state.last_at_ms = input->at_ms;
	if (key_event && physical(input) && (state.first_down || state.second_down) &&
		input->source == state.first.source && input->generation != state.first.generation) {
		withdraw(&state, input, &result, ERGOPTI_PAIR_WITHDRAW_SOURCE_GENERATION);
		goto received;
	}
	if (key_event && (state.mode == ERGOPTI_PAIR_WAITING || state.mode == ERGOPTI_PAIR_CHORD) &&
		((state.first_down && same_slot(&state.first, input) && !same_press(&state.first, input)) ||
		 (state.second_down && same_slot(&state.second, input) && !same_press(&state.second, input)))) {
		withdraw(&state, input, &result, ERGOPTI_PAIR_WITHDRAW_PRESS_IDENTITY);
		goto received;
	}
	if (state.mode == ERGOPTI_PAIR_HELD_ALONE) {
		if (input->kind == ERGOPTI_PAIR_UP && same_press(&state.first, input)) {
			state.first_down = false;
			state.mode = ERGOPTI_PAIR_IDLE;
		}
		goto received;
	}
	if (state.mode == ERGOPTI_PAIR_CHORD) {
		bool first = state.first_down && same_press(&state.first, input);
		bool second = state.second_down && same_press(&state.second, input);
		if (key_event && (first || second)) {
			if (!physical(input)) {
				withdraw(&state, input, &result, ERGOPTI_PAIR_WITHDRAW_ORIGIN);
				goto received;
			}
			result.current_route = ERGOPTI_PAIR_RETAIN_PROPOSAL;
			if (input->kind == ERGOPTI_PAIR_UP) {
				if (first) state.first_down = false;
				if (second) state.second_down = false;
				if (!state.first_down && !state.second_down) state.mode = ERGOPTI_PAIR_IDLE;
			}
		}
		goto received;
	}
	if (state.mode == ERGOPTI_PAIR_WAITING) {
		if (input->kind == ERGOPTI_PAIR_CLOCK) {
			if (!within_delay(&state, input->at_ms)) fallback(&state, &result);
			goto received;
		}
		if (same_press(&state.first, input) && !physical(input)) {
			withdraw(&state, input, &result, ERGOPTI_PAIR_WITHDRAW_ORIGIN);
			goto received;
		}
		selection = input->kind == ERGOPTI_PAIR_DOWN && physical(input) &&
			input->source == state.first.source && input->generation == state.first.generation &&
			input->key != state.first.key && within_delay(&state, input->at_ms)
			? choose(&state, input->key) : NULL;
		if (selection != NULL) {
			result.selected = true;
			result.pair_id = selection->pair_id;
			result.action_id = selection->action_id;
			result.actual_first = state.first;
			result.actual_second = *input;
			result.current_route = ERGOPTI_PAIR_RETAIN_PROPOSAL;
			state.second = *input;
			state.second_down = true;
			state.mode = ERGOPTI_PAIR_CHORD;
		} else {
			fallback(&state, &result);
			if (input->kind == ERGOPTI_PAIR_UP && same_press(&state.first, input)) {
				state.first_down = false;
				state.mode = ERGOPTI_PAIR_IDLE;
			}
		}
		goto received;
	}
	if (state.mode == ERGOPTI_PAIR_IDLE && input->kind == ERGOPTI_PAIR_DOWN &&
		physical(input) && context->first_available && first_candidate(&state, input->key)) {
		state.first = *input;
		memset(&state.second, 0, sizeof(state.second));
		state.first_down = true;
		state.second_down = false;
		state.mode = ERGOPTI_PAIR_WAITING;
		result.current_route = ERGOPTI_PAIR_BUFFER_PROPOSAL;
	}

received:
	*next = state;
	*plan = result;
	return ERGOPTI_PAIR_OK;
}
