# Native Sparkle startup diagnostics, revision 2

SOURCE ONLY. No candidate imports, tests, parsing or compilation have run. macOS startup cause remains UNKNOWN; this packet adds observations, not a startup workaround.

Original frozen packet `../native-startup-diagnostics` remains immutable (manifest87c7944b / patch20e4a43d). This separate revision corrects instrumentation masking an existing serve-body primary. An explicit body reservation distinguishes it from a caller's inherited exception. Both optional retirement frames defer trace refusal until the original socket close and retired receipt. Existing body exceptions resume unchanged; trace-only refusal still fails. Original close/publication refusal semantics are preserved.

Four new literal controls use the actual native bound socket and physical close: exact body primary + retirement-frame refusal; exact cancellation + final-frame refusal; trace-only failure after retirement; inherited caller context cannot suppress trace-only refusal. These remain UNEXECUTED. Existing26 controls and first4 diagnostic controls are byte-preserved,34 total. Four new POSIX socket controls add Windows4 skips (ten total); Linux remainszero, macOS remainsone. All184 original CJS assertion calls recover byte-exactly when the new block and registration-count changes are removed. Swift is byte-identical to first reviewed candidate.

Defaults, signal handlers, native exit/readiness/retirement guards, ten-second readiness and server I/O bounds remain unchanged. Trace capture uses only original O_RDWR owned stdout after existing native exit ACK, bounded512/513 bytes. No new FD/wait/signal/reaper, raw output/path/nonce/argv exposure, policy/entitlement/consent change or accepting signals.

Bounded source ACK received from review_brew_boundary for exact e970982f full patch and52250fed delta; see REVIEW-SOURCE.md. Root owns all live application and validations. Primary instrumentation correction does not qualify actual macOS compilation or startup.
