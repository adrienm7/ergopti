# Six Linux producer blockers: focused correction evidence

This packet remains scratch-only. No live repository/core, foreign branch, TODO, manifest, workflow, commit or push was changed. The old saved packet and both candidate checkpoints remain byte exact. The final native-owner bridge and whole producer are **not integrated or qualified**.

## Exact causal status

| Subject | Passed | Failed | Native command status |
| --- | ---: | ---: | ---: |
| Unchanged saved producer, same13 public cases | 2 | 11 | 1 |
| Corrected candidate, same13 public cases | 13 | 0 | 0 |
| Original preserved coordinator/GIO/runtime/policy cases, old producer | 74 | 0 | 0 |
| Original preserved cases, corrected candidate | 74 | 0 | 0 |
| New independent deadline ledger cases, corrected candidate | 10 | 0 | 0 |
| First candidate queued-expiry debt seam | 0 | 1 | 1 |
| Corrected queued-expiry debt seam | 1 | 0 | 0 |
| Queue-corrected candidate failed-arming debt seam | 0 | 1 | 1 |
| Corrected failed-arming debt seam | 1 | 0 | 0 |
| Queue-corrected candidate aggregate cancellation seam | 0 | 1 | 1 |
| Corrected aggregate cancellation seam | 1 | 0 | 0 |
| Queue-corrected candidate synchronous admission cancellation seam | 0 | 1 | 1 |
| Corrected synchronous admission cancellation seam | 1 | 0 | 0 |
| Actual owned libuv deadline timer receipts | 4 | 0 | 0 |

The final corrected snapshot passes **101 model/native-port controls**, comprising13public+74preserved+10deadline+4additional seams. Separately, **four actual libuv timer controls** pass using the exact owner-authored NativeTimer helper. No case was skipped. `VALIDATION.json` preserves the typed statuses without including raw execution logs. All direct negative command results were preserved in the originating scratch receipt.

The original producer's2/11 result has not turned into13/0:13/0 belongs exclusively to corrected source. The ten new deadline cases have no older native-ledger equivalent. The four additional seams compare their own first-candidate checkpoints, not old production. Never count these as extra original production failures or broad native coverage.

An initial before/after attempt was0/13 because the newly authored Paths fixture omitted existing shared(path). Those logs remain as fixture-incompleteness evidence. The only fixture correction supplied that exact existing native path resolver port; no assertion/expected outcome changed. The complete-fixture original replay then established2/11 and corrected replay13/0.

## Preserved independent assertions and lifecycle proof

The original two public owned-cancellation bodies, including original dev1234–1244 and1264–1270, are contiguous byte-exact source in the actual wrapper replay. They prove cancellation refusal stays active while suppressing delivery, unrelated owners remain independent, and both APIs refuse behind owned cleanup debt. The preserved74 original assertion bodies are unchanged: their only fixture migrations add the independent deadline port and uv.update_time native port. Reverse migrations reproduce all saved bytes. The canonical policy expectations are not regenerated.

The public replay loads the actual saved/corrected wrapper, actual corresponding GIO adapter and actual **older saved** native curl engine. Native libuv events are independent doubles, not actual subprocesses. The foreign new body-pipe core is not substituted or qualified by these controls. This is meaningful public boundary proof and not real curl/GIO/kernel networking.

Reviewed additional seams all have fixed controls failing the relevant checkpoint: expired queued timer closure refusal, failed arming with retained allocation, queued refusal masked by predecessor cancellation acceptance, and synchronous predecessor-listener cancellation before a system successor's admission. Corrections retain linkage/adopt retirement-only ownership until exact timer ACK, preserve public retry, aggregate refusals and fence new acquisition after cancellation. Failed native arming publishes the Boolean typed refusal while holding physical debt; owned completion retains its existing physical meaning. No assertion is weakened to erase refusal.

The actual native primitive controls execute real LuaJIT/luv timer arming/expiry, cancellation, settlement callback reentry and protected callback logging. Logical notification occurs before timer close ACK. Each case returns uv.walk to its exact initial live-handle count. No child process is created; these checks do not demonstrate HTTP process retirement. Model queue/failed-arming controls retain and close every independent timer receipt before accepting the next native child; no debt is inferred from scheduling alone.

## Scope and remaining qualification

The exact incoming timer helper dependency is ec9673283's `infra/native_timer.lua`, SHA25635db96358d9224e70b54d60cb1cadacc043186fa2dbab88d8340b570d6b49c63. Its support copy is qualification infrastructure only, not an ours-owned production file. The new deadline ledger delegates arming to it, owns only its own timer and close ACK, and never claims the curl/GIO child has retired.

The six reviewed source defects now have focused causal proof, plus the four additional corrected seams. They do **not** clear final producer composition. The native owner must publish/review the latest core/helper bridge preserving BodyPipe/descriptor retirement, complete body budgets, literal/large bodies, POST303/globoff/empty-header semantics and private proxy/metrics/terminal-observer extension. The older saved engine cannot replace it. Full historical/foreign core suites, source-of-truth/shared JS/macOS/Linux gates, actual GIO/curl/CONNECT/PAC/privacy controls on final approved core, native E2E, packaging and installation are **unexecuted** here. No Windows or native macOS claim is made.

Per-hop PAC redirects, exact updater destination retry lease, owned Ollama installer/serve/pull, real enterprise CA/auth/WPAD and the existing unrelated E2E follow-ups remain TODO62/16/38 scope. No TODO item is removed and no group-completion claim is made. The final read-only reviewer confirmed the four narrow corrections at the exact coordinator hash; `REVIEW.md` records its limited scope, independently of execution.

The serialized local test slot is CLOSED. Every invoked process completed, no running test session remains, and only source/hash freeze work occurs afterward.
