import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/workspace/ergopti')
SETUP = Path('/workspace/.ergopti-cloud')
RUN = 38539080787
DEST = ROOT / 'docs/handovers/2026-10-12-config-menus/2026-10-14-receiving.tar.gz'
members = {}
members['collect-receiving.py'] = Path(__file__).read_bytes()


def add(name, path):
    data = Path(path).read_bytes()
    assert name not in members
    members[name] = data


def api(endpoint):
    return json.loads(subprocess.check_output(['gh', 'api', endpoint], text=True))


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


for name in [
    'wizard-final-green.log', 'wizard-original-final-tests-red.log',
    'wizard-unfenced-red.log', 'wizard-restored-green.log',
    'wizard-isolated-final-verify.log', 'apple-incoming-verify.log',
    'linux-unit.log', 'linux-corrected-verify.log',
    'js-baseline.log', 'js-configured.log', 'js-final-composed.log',
]:
    add('local/' + name, SETUP / name)
for name in [
    'group1-file-watchers-comparison-20261014.json',
    'group1-file-watchers-original-lua-20261014.log',
    'group1-file-watchers-original-luajit-20261014.log',
    'group1-file-watchers-restored-lua-20261014.log',
    'group1-file-watchers-restored-luajit-20261014.log',
]:
    add('local/' + name, Path('/tmp') / name)
add('local/windows-snapshot-source-comparison.json', SETUP / 'windows-snapshot-source-comparison.json')

paths = [
    'static/ergopti_plus/macos/ui/onboarding/init.lua',
    'static/ergopti_plus/macos/tests/unit/ui/test_onboarding_import_transaction.lua',
    'static/ergopti_plus/linux/infra/file_watchers.lua',
    'static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua',
]
feature = '39672eea81e888b65bf81ec895234014aee9d49f'
for name in paths:
    data = git('show', feature + ':' + name)
    assert data == (ROOT / name).read_bytes(), name
    members['sources/final/' + name] = data
for revision, name in [
    ('c271337d8^', paths[0]), ('39672eea8^', paths[2]),
]:
    members['sources/original/' + name] = git('show', revision + ':' + name)
for name in [
    'static/ergopti_plus/_shared/ahk/tap_hold/buffered_data_snapshot_owner.ahk',
    'static/ergopti_plus/windows/tests/unit/test_buffered_data_snapshot_owner.ahk',
    'tools/test/test-ahk-suite-manifest.cjs',
]:
    members['sources/windows-receiving/' + name] = git('show', feature + ':' + name)

run = api(f'repos/adrienm7/ergopti/actions/runs/{RUN}')
assert run['head_sha'] == '64816041074ab54f822795760bc20990f9e22ee4'
assert run['event'] == 'workflow_dispatch'
jobs = []
page = 1
while True:
    batch = api(f'repos/adrienm7/ergopti/actions/runs/{RUN}/jobs?per_page=100&page={page}')['jobs']
    jobs.extend(batch)
    if len(batch) < 100:
        break
    page += 1
members['hosted/run.json'] = (json.dumps(run, indent=2) + '\n').encode()
members['hosted/jobs.json'] = (json.dumps(jobs, indent=2) + '\n').encode()
for job in jobs:
    annotations = []
    page = 1
    while True:
        batch = api(f"repos/adrienm7/ergopti/check-runs/{job['id']}/annotations?per_page=100&page={page}")
        annotations.extend(batch)
        if len(batch) < 100:
            break
        page += 1
    members[f"hosted/annotations-{job['id']}.json"] = (json.dumps(annotations, indent=2) + '\n').encode()

windows_run = api('repos/adrienm7/ergopti/actions/runs/38543647299')
assert windows_run['head_sha'] == run['head_sha']
assert windows_run['event'] == 'workflow_dispatch'
assert run['status'] == 'completed' and windows_run['status'] == 'completed', 'Retain only terminal hosted receipts'
windows_jobs = []
page = 1
while True:
    batch = api(f'repos/adrienm7/ergopti/actions/runs/38543647299/jobs?per_page=100&page={page}')['jobs']
    windows_jobs.extend(batch)
    if len(batch) < 100:
        break
    page += 1
members['hosted/windows/run.json'] = (json.dumps(windows_run, indent=2) + '\n').encode()
members['hosted/windows/jobs.json'] = (json.dumps(windows_jobs, indent=2) + '\n').encode()
for job in windows_jobs:
    annotations = []
    page = 1
    while True:
        batch = api(f"repos/adrienm7/ergopti/check-runs/{job['id']}/annotations?per_page=100&page={page}")
        annotations.extend(batch)
        if len(batch) < 100:
            break
        page += 1
    members[f"hosted/windows/annotations-{job['id']}.json"] = (json.dumps(annotations, indent=2) + '\n').encode()
final_gate = SETUP / 'checkpoint-final-verify.log'
if final_gate.exists() and 'verify-change: every required gate passed.' in final_gate.read_text():
    add('local/checkpoint-final-verify.log', final_gate)

manifest = {
    'feature_commit': feature,
    'ci_commit': run['head_sha'],
    'feature_tree': git('rev-parse', feature + '^{tree}').decode().strip(),
    'ci_tree': git('rev-parse', run['head_sha'] + '^{tree}').decode().strip(),
    'workflow_status': run['status'],
    'workflow_conclusion': run['conclusion'],
    'windows_workflow_status': windows_run['status'],
    'windows_workflow_conclusion': windows_run['conclusion'],
    'windows_refusal': {
        'assertion': 'snapshot16 exact reviewed data cases',
        'phase': 'snapshot16SourceSeal before ports.run; Snapshot16 dry/run and subsequent general units not executed',
        'owner_expected': 'd049972c3566def451dedd9e9a34747e4a0dc7c3dcac600dabc419de02c84e97',
        'owner_actual': 'c2c26f6b4a8d3bd9c86153b17ffcc919a1ad47ec57c45043dfd5cd8ba2589ab1',
        'test_expected': '411e9a737b5f65be9e9eec59f7e96075130c7fd5a72e6c08fdabc7493169d992',
        'test_actual': 'bada83f6a7d6a17c7f0a39c995ba6b8551c114a9a905474c45ba78ae31bc28c9',
        'baseline': 'Both inputs and the harness byte-identical to published Dev 3f59f730; this is a deterministic pre-launch contract input comparison, not baseline native/whole-workflow qualification',
        'required_owner_action': 'Root must independently review current source/data-only assumptions and receive its approved exact sources, preserving warnings, callbacks, assertions and complete capture; no blind pin update',
    },
    'hosted_capture': 'GitHub REST metadata and complete paginated public annotations; full hosted logs/artifacts inaccessible through live proxy',
    'local_contexts': {
        'macos_full': '3531f2901 tree plus the exact final macOS correction; native-port doubles, 19821 PASS/0 FAIL, E2E101 with one explicit skip',
        'linux_full': '0b3e033ed tree plus the exact final Linux correction; LuaJIT/luv/luaposix, 13698 PASS/0 FAIL, E2E193/193',
        'js_final': '0b3e033ed tree plus the exact final Linux correction and the initial documentation checkpoint, 426/426',
        'baseline_js': 'First 425/426 with protected Git ancestor; second 425/426 with owned bytecode cache symmetry failure',
        'baseline_linux': '13687 PASS/6 FAIL in original source and installed dependency context',
    },
    'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(members.items())},
}
assert manifest['feature_tree'] == manifest['ci_tree']
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
members['SHA256SUMS'] = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(members.items())).encode()
temporary = DEST.with_suffix('.tmp')
with tarfile.open(temporary, 'w:gz') as archive:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(temporary, 'r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    for name, data in members.items():
        assert archive.extractfile(name).read() == data
temporary.replace(DEST)
print(json.dumps({'archive': str(DEST), 'sha256': hashlib.sha256(DEST.read_bytes()).hexdigest(), 'bytes': DEST.stat().st_size, 'members': len(members), 'workflow_status': run['status'], 'workflow_conclusion': run['conclusion']}))
