from pathlib import Path
import subprocess,json,os,re,datetime
from zoneinfo import ZoneInfo
root=Path('/workspace/ergopti-windows-r6-tests');out=Path('/workspace/scratch/windows-adapter-contract-followup')
env=dict(os.environ,WINEPREFIX='/workspace/toolchain/wine-r3-metrics-owned',WINEPATH=r'Z:\workspace\toolchain\node-v22.22.2-win-x64;Z:\workspace\toolchain\mingit-2.56.0.4-x64\cmd')
argv=['timeout','--kill-after=5s','600s','xvfb-run','-a','bash','tools/test/run-ahk-under-wine.sh','--ahk','/workspace/toolchain/ahk/AutoHotkey64.exe','--runner','run_all.ahk','--results',str(out/'baseline.tap'),'--','--only','empty-message-contract']
with (out/'baseline.log').open('w') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
p=out/'baseline.tap';tap=p.read_text(errors='replace') if p.exists() else ''
record={'exit_code':r.returncode,'argv':argv,'passed':len(re.findall(r'^ok \d+',tap,re.M)),'failed':re.findall(r'^not ok .*',tap,re.M),'ended_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()}
(out/'baseline-results.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
