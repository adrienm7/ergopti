#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import json,re,hashlib,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle');w=out.parent/'verification-worker'
for stem in ['492-lifecycle-state-kind-candidate-native57','493-lifecycle-original-loader-calendar-baseline']:
 receipt=json.loads((w/'receipts'/(stem+'-exit.json')).read_text());assert receipt['exit_code']==1,receipt
text=(w/'492-lifecycle-state-kind-green57.tap').read_text(encoding='utf-8-sig');assert '# 55 passed, 2 failed.' in text
oks=re.findall(r'^ok (\d+) - (.+)$',text,re.M);bads=re.findall(r'^not ok (\d+) - (.+)$',text,re.M)
assert len(oks)==55 and len(bads)==2 and {int(p[0]) for p in oks+bads}==set(range(1,58))
expected_bad={f'keystats: reject noncanonical date case {n} (state-calendar-validation)' for n in [3,4]}
actual_bad={name.rstrip('\r').split(' — ',1)[0] for _,name in bads};assert actual_bad==expected_bad,actual_bad
names=json.loads((out/'state-numeric-kind-native57-manifest.json').read_text())['names'];new=[name for name in names if 'state-numeric-' in name];assert len(new)==15
actual_ok={name.rstrip('\r') for _,name in oks};assert set(new)<=actual_ok and actual_ok==set(names)-expected_bad
baseline=(w/'493-lifecycle-original-loader-calendar-baseline.tap').read_text(encoding='utf-8-sig');assert '# 1 passed, 2 failed.' in baseline
bound=json.loads((out/'state-calendar-hosted-enrollment-bound.json').read_text());assert bound['hosted_metadata']['job']['conclusion']=='success' and bound['no_calendar_production_change']
for p,h in json.loads((out/'state-numeric-kind-candidate-hashes.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
probe=root/'static/ergopti_plus/windows/tests/unit/modules/keystats/reader/test_klr_trusted_frames.ahk';assert probe.read_bytes()==(out/'storage-torn-ledger-expanded-probe.ahk').read_bytes()
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
print('STATE_KIND: all15 new cases PASS; complete57 remains55PASS2unchangedWineFAIL, not green.')
CHECK
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
git add -- static/ergopti_plus/windows/modules/keystats/keystats_ingest.ahk static/ergopti_plus/windows/tests/unit/modules/keystats/test_keystats_full_id_recovery.ahk
git commit -F /workspace/scratch/windows-audit-round6/lifecycle/state-numeric-kind-commit-message.txt
python3 - <<'CHECK'
from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
for p,h in json.loads((out/'state-numeric-kind-candidate-hashes.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
print(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
CHECK
