#ifndef ERGOPTI_GROUP4_GUARDIAN_FACTORY_H
#define ERGOPTI_GROUP4_GUARDIAN_FACTORY_H
#include "guardian_import_win32.h"
#include "guardian_host.h"

typedef struct GF_Owner GF_Owner;
typedef enum {
    GF_ACQUIRING=0,GF_HOST_STARTING=1,GF_READY=2,
    GF_STOPPING=3,GF_RETIRED=4,GF_RETAINED_DEBT=5
} GF_Phase;

/* Caller is the native server registry, with an already allocated/published row
   ID. Channel is the authenticated exact source intent, not caller metadata.
   Daemon job/process come only from the authentic suspended ShellRunner task.
   Guardian image is protected by the source offer's continuously held lease. */
GF_Owner *GF_Begin(uint64_t,GSC_Owner *,HANDLE,HANDLE,DWORD,const FILETIME *,
                    const wchar_t *);
/* Intake holds source release until actual curl terminal/job-zero seal. */
GF_Owner *GF_BeginIntake(uint64_t,GSC_Owner *,HANDLE,HANDLE,DWORD,const FILETIME *,const wchar_t *);
int GF_ReleaseIntakeSource(GF_Owner *);
int GF_HasIntakeContainment(const GF_Owner *);
int GF_ConfirmIntakeDirectory(GF_Owner *,const GI_Expected *,const GI_Expected *);
GF_Phase GF_Poll(GF_Owner *);
int GF_RequestStop(GF_Owner *);
DWORD GF_FirstError(const GF_Owner *);
#endif
