'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const page=loadMetricsTypingPage('windows');
const strings=JSON.parse(fs.readFileSync('/workspace/ergopti-windows-r6-ui-metrics/static/ergopti_plus/_shared/data/locales/en.json','utf8'));
// The production i18n owner explicitly supports native boot seeding this store.
page.context.window._i18n_strings=strings;
page.context.window._i18n_locale='en';
assert.equal(page.context._t('ui_typing.unit_active_apps'),'active apps');
const blob={metrics_manifest:{'2026-10-26':{'Editor.exe':{chars:5,time:500}}},_prefetch_data:{historical:{},today:{}},app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}};
page.messageListeners.filter(e=>e.name==='message').at(-1).callback({data:{type:'prefetch',blob}});
console.log(JSON.stringify({label:page.elements.get('apps_val').innerHTML,existingLocaleKey:page.context._t('ui_typing.unit_active_apps')}));
assert.ok(page.elements.get('apps_val').innerHTML.includes(strings['ui_typing.unit_active_apps']),'the active app unit follows the admitted native locale');
