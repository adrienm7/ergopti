#!/usr/bin/env python3
"""Reap this command's orphaned children in a cloud container without an init."""

import ctypes
import os
import subprocess
import sys

if len(sys.argv) < 2:
    raise SystemExit("usage: run-with-reaper.py command [arguments...]")
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:  # Linux PR_SET_CHILD_SUBREAPER.
    raise OSError(ctypes.get_errno(), "Could not become a child subreaper")
command = subprocess.Popen(sys.argv[1:])
while True:
    child, status = os.waitpid(-1, 0)
    if child == command.pid:
        code = os.waitstatus_to_exitcode(status)
        command.returncode = code
        raise SystemExit(code if code >= 0 else 128 - code)
