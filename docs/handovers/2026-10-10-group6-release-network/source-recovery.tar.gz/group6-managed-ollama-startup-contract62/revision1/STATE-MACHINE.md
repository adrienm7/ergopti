# Managed-source startup: minimal complete ownership contract

Status: read-only design. No Lua/shared/main patch or target execution. The
published ACTIVE/RETIRED slice is separate; ACTIVE proves original image
activation plus authority publication, not an accepted socket or server READY.
The production qualification gate must remain false.

## Concrete current seams

api_ollama.lua classifies Binary only inside delayed activate_server(), after
its unconditional broad pkill task. The serve task is declared published from
task.start() true. on_serve_done() clears its slot regardless of native namespace
closure. settle_ollama_start_task() also releases on generic task settled.
These are correct historical task semantics for the existing stock path, but
cannot acknowledge an owned managed daemon's session/alias/tree retirement.

SuspendedImageOwner.start() awaits IMAGE_READY then ACTIVE. The guardian emits
ACTIVE after ergopti_owned_program_activate(), without accepted-socket/API
admission. DaemonAuthority.publish() binds original mapped image and sealed
session/alias; it does not contact a listener. Keep these facts distinct.

Actual existing listener/authentication functionality is implemented:
network/native_ollama_api.py discover() admits the accepted socket's full native
PID/start/device/inode tuple without sending HTTP. BoundAliasPorts compares it
to the original daemon authority. Shared PullOwner.admit() then challenges GET
/api/ergopti-native-http-admission, verifies the signed same-session response,
matching socket identity, exact EOF/child completion and request closure. Reuse
that policy; never substitute generic localhost200, task.start or warmup200.

## Smallest coherent consumed implementation

1. Resolve and reserve a managed selection BEFORE any stale-process task.
   Capture actual generation, provisional source candidate, original authority
   callbacks and budgets in one private transaction. Pending native metadata
   fences admission; it does not authorize stock fallback or a kill. Unknown,
   unsupported or foreign active listener refuses without retiring it. Exact
   source admission remains Python's job; a UI hint grants no image authority.
   Keep the entire original stock startup branch and its assertions unchanged.

2. Spawn the canonical source-admitted Python owner with literal argv, original
   captured interpreter and caller nonce. Reserve the original task before its
   start call. Buffer synchronous stream/completion during construction; after
   registration refence same generation/identity/authorization before receiving
   any frame. A true start result means accepted task ownership only.

3. Parse complete bounded caller-nonce ACTIVE/RETIRED frames from the original
   owned Python stream. No daemon log mixing, partial line acceptance, duplicate
   terminal credit or foreign nonce. ACTIVE keeps startup pending. Unknown frame,
   excess bytes, stale epoch or callback reentry revokes authority and enters
   exact retained cleanup, never a retry/stock fallback.

4. Add native accepted-socket/session readiness within ServeOwner under its
   ORIGINAL absolute admission deadline and idle limit. Reuse BoundAliasPorts
   and the shared PullOwner.admit policy (no model submission). Source, image,
   alias and authority refences precede/follow that work. A new bounded native
   request must be registered with ServeOwner BEFORE a constructor can acquire
   its child/streams. Only after the complete challenge and helper physical
   closure may the exact original caller receive READY. No poll loop, extra
   clock, fresh deadline or endpoint-inference authority is permitted.

5. Publish the original supervised startup success only after READY, captured
   authority remains live and the exact transaction survives all callback
   reentry. Stable published ownership may remain outside pause startup debt,
   as original G4 behavior specifies. This is service readiness, not permission
   to install/migrate/replace stock or to restart arbitrary endpoints.

6. Cancellation revokes consent/generation immediately but retains acquisition,
   readiness request, daemon, session/alias and outer task debt. Reuse the exact
   original signal/EOF owner contract, not broad process names or a second
   reaper. A generic terminate acceptance/onSettled/process exit does not prove
   native namespace retirement. Completion must join both valid native RETIRED
   and the exact ShellRunner physical settlement before clearing the slot.
   RETIRED may precede task completion; completion may precede a delivered final
   stream. Neither order alone grants successor admission.

7. Refused/unknown retirement must retain the original capability or an exact
   source-bound explicit cleanup handoff. No success from a dead helper missing
   RETIRED. No source/nonce/deadline reset or automatic retries. New consent does
   not dispose old native debt. A successor is admitted only after the original
   final conjunction, and old cleanup cannot clear a replacement epoch.

## Precise missing owner contracts: why no safe Lua patch yet

- The current native serve stdout protocol supplies ACTIVE/RETIRED only. It has
  no accepted-socket READY publisher. Adding a Lua parser cannot fill that gap.
- NativeOllamaResponse has no caller registration argument; a proposed readiness
  constructor must not acquire a child before ServeOwner can retain it. Its
  existing context/close semantics must be retained and failure ownership made
  explicit; do not assume a returned exception is a closure receipt.
- ServeOwner.retire(False) is followed by CLI failure/exit. Live or uncertain
  alias/session/source debt does not currently have a source-bound external
  serve-cleanup handoff. The existing managed_ollama_cleanup.py handles a
  different pull operation authority; it is not a facade for arbitrary daemon
  session disposal. Preserve a failed Python owner or add an explicit exact
  native retained-cleanup protocol before promising recoverable migration.
- ShellRunner owned_protocol cancellation uses stdin EOF, while serve currently
  watches original captured signals. Do not set owned_protocol blindly: Python
  must consume that same cancellation channel, or keep the original exact
  signal contract with truthful pending/closed classification.

These are finite implementation requirements, not proof that native readiness
or migration is already done. A kill-skipping patch without them would create
false publication or orphan debt, so no G4 candidate is authored here.

## Ownership surface

G4 coordinates api_ollama.lua and ollama_server_command.lua, with Binary,
checker, runtime_install_offer, backend_panel and models_manager_ollama for
selection/consent/task replay and migration-wide active request retirement.
A managed branch should be a private transaction, not rewritten stock owners.
G6 supplies native ServeOwner readiness/retirement publication and existing
native listener worker ownership changes plus enrolled receiving tests.
Shared consent belongs to the existing shared policy layer by coordination;
translated replacement/migration consent is separate from missing-runtime
install labels. No locales, shared policy, manifests or workflows are changed.
Actual guarded production activation and published catalogued assets remain
external/native qualification dependencies; their generator already exists.

## Independent causal receiving requirements (all UNRUN)

Keep every original stock method/assertion/budget, original native owner/parser
controls and original missing-runtime selection vectors. Add genuine tests of:
- Native selected: zero pkill; missing catalogue/guard refuses before stock stop.
- Provisional ACTIVE: exact task live but startup/public callback still pending.
- Forged/partial/duplicate/foreign nonce frames: no publication or cleanup credit.
- Same image with foreign accepted listener; same listener with wrong challenge:
  no READY, no private request bytes before original socket provenance.
- Real signed READY + complete native request EOF/reap: one startup publication.
- Initial metadata resolution, task construction, ACTIVE and READY reentry:
  original generation/cancel retains exact acquisition debt and no successor.
- Cancellation while discovery/challenge is pending: helper/tree/session retained
  until original ACKs, no deadline reset or extra process ownership.
- Valid RETIRED before completion versus completion before final stream: both
  original conjunctions required; missing marker stays pending despite exit0.
- Native cleanup refusal/unknown close, then explicit same-owner cleanup intent:
  no new signals/clock and no clearing a replacement epoch.
- Installed stock/foreign endpoint: explicit refusal without retroactive tree
  authority, preserve old runtime; no consent inferred from download grants.

Positive socket/session readiness needs genuine signed native macOS worker and
real endpoint; POSIX modeled ports can prove state ordering and privacy only.
