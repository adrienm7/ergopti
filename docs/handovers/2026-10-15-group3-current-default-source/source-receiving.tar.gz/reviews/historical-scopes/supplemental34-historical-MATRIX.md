# PRIVATE — Root default127 supplemental custody

**Custody inventory, not final source approval.** Keep private pending the owner's published StageOwner correction/regression and reviewed current composition. No source generation, target/parser/compiler/test/native execution, network request, checkout/ref/index mutation or approval refresh was performed. Root's independent eleven-delta review `4bc66342…` / manifest `6736272c…` explicitly excludes imported runtime suppliers and is not authority for these rows.

The exact tuple epoch below is published Root `eb6cd9db17c9ebbe4dfdbba1d05141e394d777eb`, using its complete API tree/census. Parent reports current `8f181…` has the same native127 images; this report does not independently certify that later commit or Root's still-private workflow/depth0 epoch. The set is **32 target leaves outside original99 +2 external project headers =34**, not the later SDK159/176 set. All modes are `100644`.

`L/` means `static/ergopti_plus/macos/launcher/`; `C/` means `L/Sources/CPOSIXCompatibility/`; `S/` means `L/Sources/ErgoptiPlus/`; `T/` means `L/Tests/ErgoptiPlusTests/`. Extensions are literal.

Supplier/review keys:

- **D/B:** published `db596762139465e0bc74aaa59f14b0385ac51152`, exact transferred topic image also present at `ef9acb7b822c28ea6bbb89fd0723f569e13a18d3` and `70d88b885d45ae616b69f33b9826f76fb1be9493`; literal PartB per-file body, scope default compilation/initialization, named source dependencies and NumberRow noninterference only. Imported scoped review matches; acquired native-owner semantics remain **TRUSTED_NOT_REVIEWED by this inventory**.
- **A+B:** D/B plus literal PartA per-file body: bounded filter/test-declaration noninterference. Its earlier CPP dependency-census HOLD is addressed only by separately including/reviewing the three actual CPP/header inputs below, not by erasing its receipt.
- **E/V:** actual published ef9 currentDev variant; literal `VARIANT-SOURCE-REVIEW.json` explicitly reviews this different image. Not a transfer from a different SDK image.
- **E/C:** actual ef9 three-input CPP/header image (body also authenticates equality to db596 and `7a994538e4ec8754eaa7fad05e02a0e95ae4e4d2`); literal cpp-three body covers default dormancy and include closure, not full acquired-native behavior.
- **E/HOLD:** current published ef9/Root preimage is expressly held by the variant body. The different reviewed70d correction is a successor, not authority for current bytes.

All `D/B`, `A+B`, `E/V`, `E/C` rows mean **IMPORTED_REVIEW_SCOPE_MATCH**, not a new independent approval or a native grant.

| # | Current path | Git blob | SHA256 | Bytes | Supplier/body |
|---:|---|---|---|---:|---|
|1|C/OwnedInstalledConfiguration.cpp|938e17a253ee056511fd4054509651c5e653c711|9e0ddda2a9b59c90da249f2d6cf644d2d623140e8cc154746db065eb3b7807c9|3863|E/C|
|2|C/OwnedRuntimeLifecycleContract.c|57cae9cc042849b1b9febe2be0b21f3bd239da61|36e55af172965f9d4831401ec3e0127fbf944332d05f66805bf99cbf6bda60d6|315|A+B|
|3|C/include/OwnedChildReapingCompatibility.h|6f3134771dc93eadc320025323f581a45e651ca4|1274cded080f0e272f83697b0f12d267f760aedd304ac4db692be2545a4dd0e4|1454|A+B|
|4|C/include/OwnedInstalledConfiguration.h|74c188dbe0b6e1ca76e0077ff7ed326416d3c494|05a7f4c44cbfc2d1d7cce0257e51bf0dfbb6662d13ef037387176f7e9557c0dc|1407|A+B|
|5|C/include/OwnedRuntimeLifecycleContract.h|ed44655f3467ab331df17eb8c42b4ccf1f5c9ba3|318d8bbc2deab904914888d560a6ffc5537a8e9d48ccc42d50b9ae6077997474|494|A+B|
|6|C/include/OwnedRuntimeSignatureCompatibility.h|bfc1f7758088a84bf6e2bf323575c4078cc29663|a7009d19a369e35ff5fd175f822b8a63e6ef5764875e4784035e2abae3f97bb1|486|A+B|
|7|S/InstalledPhysicalSourceBridge.swift|35f7f398879f06c67703fb3442c424de552c5136|561e0014c28e2e4bdf8227b8feb7ad78aa658e5acf9d1a1d6975384f64919551|13522|D/B|
|8|S/OwnedRuntimeBootstrapStageOwner.swift|7b41109acbc7b8ec2c59cfe12811e7a55cc47f6b|ef7c2908ff59baedf85d85f29f356745d1f17ae5c3b58393c6ace9329ddd9f7c|9292|E/HOLD|
|9|S/OwnedRuntimeBuildValidationEntry.swift|b313a0be73fcce11bd6006c310bae1ad1c640700|d7b9d65973485c0e83f059ce6d5cfc230e30ff800a4beaed0f5b53d5d8a1da4f|2715|D/B|
|10|S/OwnedRuntimeCoreExitObservation.swift|679a6ac188e83a7a1258f5c85940f7eec0f93377|fbc9202b67bf72ce0b3df89f8874dcc75e805b9bcbf166da605bf2de752bc703|1704|D/B|
|11|S/OwnedRuntimeCoreLaunchctl.swift|5e5a41fbb5ec45c65196e0a1860a7d646c53dcd5|74bda94c0767fe03d749d948d3d35d0c88038e25dfd2449de91b00c203d7819e|9676|D/B|
|12|S/OwnedRuntimeCorePlistCustody.swift|ea503e241116141252172376d23aeec188002a1f|eea7d6efb9b6f59ceafdc49d7a285e2bca0b5006999935739d2dd22d0b5d2ba4|13413|D/B|
|13|S/OwnedRuntimeCoreProvisionOwner.swift|c1ae8ca24b67789ddadbee7b9714bd9107a4d336|16bc067edc68e2b3281f32f78ca70af70dd89d70cc07979eafe5a66e011bf242|14751|D/B|
|14|S/OwnedRuntimeCoreServiceOwner.swift|5bb6ae1bacc9b9d9c99b46ab05f9430c8f549eed|a6861fa2d90b31c9a4258d35d49bea7f5a2fbaf17cb82ef72831834308f1d802|18650|D/B|
|15|S/OwnedRuntimeFirstInstallOwner.swift|e8e7bfdda49bdec878577801a5c89bd248ef4af9|296a1e2e105f6bd492836e0d49a5f379666398df23ad641559042578c3b99730|9148|D/B|
|16|S/OwnedRuntimeIdleServiceEntry.swift|37333f223beadbdcdba1ef3b890b01997f793fd6|9c5826bdf19760ac2ac15d104221621a404944062f674422cfedf8200b2aac85|1810|D/B|
|17|S/OwnedRuntimeInstallJournal.swift|b1f215ea296e66e4aeb330ebc937b37189021e54|d7042f26f6c138eeb3d67f3bf4c30f3885a04eb9e0c428c5911fd1da3f5c5422|24388|D/B|
|18|S/OwnedRuntimeInstallOwner.swift|233c7fa70ff170757ff3a21fe3971a08186fda6d|06e14b89b499d0243f8001d210806149b197b6a62dbedd8cbf765827f2a489ef|21107|E/V|
|19|S/OwnedRuntimeInstallWorker.swift|53cb34837c0f444ba3fab99c7489877dd95c6a14|b1c627ec48a50307c3bfc1ec012e14bfdad67e144c822de05d36fcc35d5a21df|18999|E/V|
|20|S/OwnedRuntimeInstalledPeerOwner.swift|10f0928eda24db0ecc373921c41b8f301f49ad98|853ec757931931e6c27fdeded82460de169c07fa2c451404880a887a97f72329|18491|D/B|
|21|S/OwnedRuntimePublisherIdentity.swift|83f87fa0496bc31bdb022ae6563f0fa2b92dba91|4c01e7bd383da06fd96502725cc4a59ad25cbbcdb1c07c220f6713c55dfa9f05|12367|E/V|
|22|S/OwnedRuntimeServiceLifecycleLock.swift|2c7bbff779dea033fc3e978af50abf74466a9a38|0298108fecb7fb0c86c8fafeb90c9f8690ac117e9df635402834c71facbe6e94|13316|D/B|
|23|S/OwnedRuntimeUserConsoleOwner.swift|2426f8ace6c1f4eaa4f7bbc1c96d4b3b5a49bf2b|834d8c8d0fb3851caf193eacc764f17498952c0a56be852d5b14624946e033fe|14364|D/B|
|24|T/OwnedRuntimeCLIGuestOwnerTests.swift|6fb6d86d890b76506147e7f7635dcc642072d694|cd277db140380ccc4f6610d24f626c3536cbf2c7dfc05a13baf955d31ff6cbd0|1114|A+B|
|25|T/OwnedRuntimeConsoleConfigurationTests.swift|cc678da944b1564a0f5629cace87c56b0d693207|d304fbcc05a9b3324d3147c1b830494460a26d69edff8994126129ecdb55a190|1260|A+B|
|26|T/OwnedRuntimeCoreExitObservationTests.swift|3500e7bf9b80b7bcce905962d3cb82ddfd9e25bf|27671c94e9e190f4f55566f966ef26b7d139020ce19022bcf8e0531425235193|7130|A+B|
|27|T/OwnedRuntimeCoreProvisionOwnerTests.swift|dea62f639aa13fbb095e6ee08b264d293b7c11b1|9a22b6136786f3098615fb28749644c6bbc9690fac848956a6d40a51c1dc9a77|11328|A+B|
|28|T/OwnedRuntimeInstalledPeerOwnerTests.swift|1ddcc18be30e9bbd2a753a46bc9b0cfcafa1607c|c86edf208ada491ae6fb320c49de32ba22229ae76d7b4c9f5de3ba9a9dca7c08|7634|A+B|
|29|T/OwnedRuntimeLifecycleInitializerCustodyTests.swift|7a5d8bbc9a6de3531fe367491e323cc49d1e15ae|9f8f5c37b3ba1e88b5eb10c1709359bc115f4329b3a231362e02b57f534c716b|1585|A+B|
|30|T/OwnedRuntimeMaintenanceJournalAdmissionTests.swift|717994e631b300fa500b36d1a8e039eaf222cb70|ebece62a96f88e5e2d31b9a9cccfc3b2399473305cafe12dc7046e60f2777a9c|1637|A+B|
|31|T/OwnedRuntimeNamespaceCloseOrderTests.swift|62ca43f0f47a1bc22edba362eac385a6e0b670a5|d080963da1910b9eb20487200d5993d72bfcfa6a09580adfc65420020973fcea|1995|A+B|
|32|T/OwnedRuntimeUserConsoleOwnerTests.swift|145f060f27d4167a2b53f555a2fcc5f7d5680c0d|85ca84d604d8d40ca109956d499360313ba344ad862b9b346e5ef9e781bab9a0|4173|A+B|
|33|tools/build/InstalledRuntimePublisher.hpp|14a9a95954bf29f43707abcbdcc126e425cfc607|e097211520fc92b4751fda382b04a6055171c27b82d99a5bbb472869603017a1|17969|E/C|
|34|tools/build/InstalledUserConfiguration.hpp|cb8d9b7b9f2ed90285ba6bee278e85db0b4da545|8e9fc9da6e6bde812d02da9e7fad80ba6d227d5d4670ae6257417ce32faad18b|16204|E/C|

## Literal evidence and precise gaps

The review body root `R` is `../number-row-root-eb6-eleven-source-map-v1/literal-review-bodies/source-review-basis/reviews/`:

| Key | Actual literal body | SHA256 | Bytes / scope |
|---|---|---|---|
|B|R/part-b/PER-FILE-DEFAULT-SOURCE-REVIEW.json|922a4936c9e69a0a7c288e9137968bf01a8648184f23dd0403506ce1499aae99|83831; per-file paths/hashes/default initialization/named dependencies, not acquired-native semantics|
|B overview|R/part-b/REVIEW.json|4cf9d7033e816fb97abaebf6693ffa5afe1e21aa31ae3de977daf1fb0e3000e3|4282; retains separate SDK-only worker/archive HOLDs, whose source files are absent from this Root127 set|
|A overview|R/part-a/REVIEW.json|7b226ab42035bfa07cc2419742aeff0cba9cf6b71ebf9fe990c8732eadf2575d|2905; 27 exact original topic source files, bounded noninterference/build-closure limits|
|A per-file|`/workspace/.ergopti-cloud/continuation-2026-10-14/g5-number-row-source-basis-received-v1/members/source-review-basis/reviews/part-a/PART-A-PER-FILE.json`|6752227b8cc85f5d88a1082ca6aec76993fb53aaa28457fef069a2f530005f6d|Literal retained body, not an absent review-reference path|
|V|R/currentdev-ef9/VARIANT-SOURCE-REVIEW.json|cf594473449ad885484c758ed0cb9179f9dc731141e842408e94d4e9c480fc02|3083; three exact good runtime variants plus explicit old-bootstrap HOLD; Package/header/main separately scoped|
|C|R/cpp-three/REVIEW.json|050f9045b2581168e808dc0c7ad74576de679c3b28e35894d7c07f6eb91887d4|3192; actual CPP and two external headers, default dormancy and genuine quoted include closure|
|Original ten, separate|R/original-ten/REVIEW.json|46f1e58d2993ce7067a2bfac0f234fad181de581d38f2ae5324c193590b7e13d|3832; ten historical deltas, not blanket authority for the34|
|Corrected bootstrap, separate|R/bootstrap-independent/REVIEW.json|36d7004c55749be1e2f7938b87c63567992a2ed5904d13f8f11ed66e8c555c72|2565; removes duplicate initialized-self cleanup only, native UNRUN|

**Missing literal review bodies for the declared bounded source scopes: 0/34.** Of the current tuples, **33 have matching imported bounded findings; 1 has an explicit source HOLD**. This is not “34 approved”: whole acquired-owner semantic/native qualification was excluded by those bodies and is not supplied by the Root11 review. No count of synthetic replacement “reviews” is manufactured for this excluded scope.

Row8 is exactly the held old preimage. Required legitimate successor is the owner's separately published/reviewed correction: blob `782ffb758a904fab68aa1ccfee0a6887fab4af58`, SHA256 `66b8400858cac14557dfa71dcab6c9de9b8e8acf7824fea85b418280d84d1db7`, 9229 bytes, historically supplied at70d. The old failure defer and original initialized-self deinitializer can both close enrolled node/parent descriptors; the successor removes only the extra initialized-self failure-cleanup path. It must not be substituted into this current matrix or treated as current through a review reference. Root/private peer owns present publication/regression/custody; no competing fix is proposed. Real Swift initialization/deinitialization and FD-reuse/refusal receiving remain distinct.

Tuple transport evidence is the actual Root census `actual-root-target-source-census.json` SHA `4239e12594d98b3561b2cf1f490a5bcc77df00eb1d2b42313fb859daf38de163`, actual complete tree, and `old135-all-paths-root-comparison.json` SHA `dfe2b73db3bc41863d032269b33380029dbbaee0061cc3d53ba244022cbf51ba` in the eleven-source-map packet: every34 old135 tuple except bootstrap matches current Root. Historical `ADDITIONAL34-REVIEW-BINDINGS.json` SHA `6e9657abbfb5c36da419c1ac1fb65e061a4c1456c14b5b30b9034d31456794fa` supplies exact hashes/sizes/body joins, but its corrected-bootstrap row must be replaced by the actual held Root preimage above. This report does not turn that provisional metadata into a current envelope.

Actual Root Package SHA `34861f7e4a3520342f911ded13896941fa5e227c0a171b9258f38eebc8ac5b3f` has no installed-SDK flag and no default Brew exclusion (no selected qualification profile returns an empty exclusion list); no optional release profile is enabled by this inventory. Package lines105–106 define C `ERGOPTI_GUARDIAN_TEST_SUPPORT` only for DEBUG; Swift executable and test targets likewise define it only for DEBUG (115–117,132–134). Release compilation therefore cannot be interchanged with default DEBUG/test compilation or used as evidence for its guarded C/Swift paths. Neither profile has an installed-SDK define in this exact Package. CPP C++17/include membership and the two headers are source closure metadata, not Darwin importer/linker/signature/descriptor proof. Current policy review and later workflow epoch stay separate. Final current-source composition/controller/envelope admission, actual StageOwner fix/regression receiving and all native roles remain pending under Root custody.
