"""Bind formatting only; prove all receiving bodies and vectors stay exact."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil

BASE=Path(__file__).resolve().parent
C=BASE/'candidate';P=BASE/'preimage'
RAW=BASE.parent/'group6-native-clock149-enrollment-preparation'
CLIENT='static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
TEST='tools/test/macos_native_http_receiving_facts_test.py'
REGISTRY='tools/test/test-managed-ollama-protocol.cjs'
MAIN='static/ergopti_plus/macos/tests/support/native_http_fixture_main.swift'
NEW='tools/test/macos_native_http_clock_contract_controls.py'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def functions(source):
    out={}
    def visit(node,prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
                name=prefix+child.name
                if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    out[name]=ast.get_source_segment(source,child)
                visit(child,name+'.')
            else:visit(child,prefix)
    visit(ast.parse(source));return out
before=(P/CLIENT).read_text();after=(C/CLIENT).read_text()
old,new=functions(before),functions(after)
inv=json.loads((BASE/'enrollment-inverse.json').read_text())
assert all(new[name]==body for name,body in old.items() if name!='RealNativeClientReceiving.setUpClass')
assert new['RealNativeClientReceiving.setUpClass'].replace(inv['client']['call_addition'],'',1)==old['RealNativeClientReceiving.setUpClass']
assert functions((P/TEST).read_text())==functions((C/TEST).read_text())
start=after.index('class NativeClockRefused(RuntimeError):\n');end=after.index(inv['client']['helper_anchor'],start)
inv['client']['helper_addition']=after[start:end]
restored=after
for kind in ('call','helper','imports'):
    anchor=inv['client'][kind+'_anchor'];addition=inv['client'][kind+'_addition']
    fragment=addition+anchor if kind=='helper' else anchor+addition
    assert restored.count(fragment)==1
    restored=restored.replace(fragment,anchor,1)
assert restored==before
(BASE/'enrollment-inverse.json').write_text(json.dumps(inv,indent=2)+'\n')
classes=lambda source:{node.name:ast.dump(node,include_attributes=False) for node in ast.parse(source).body if isinstance(node,ast.ClassDef)}
assert classes((C/NEW).read_text())==classes((RAW/'candidate'/NEW).read_text())
provider=json.loads((BASE/'unchanged-provider-inputs.json').read_text())['byte_exact_inputs']
assert all(sha(C/rel)==pin for rel,pin in provider.items())
manifest=json.loads((BASE/'composition-manifest.json').read_text())
manifest['qualification']='SOURCE_ONLY_FORMAT_LINT_PASS_UNIT_NATIVE_UNRUN_NO_ADOPTION'
for rel in manifest['files']:manifest['files'][rel]['candidate']=sha(C/rel)
manifest['new_fixed13_helper']={'path':NEW,'candidate_sha256':sha(C/NEW),'independent_authored13_class_AST_vectors':'EXACT','unit':'UNRUN'}
manifest['formatters']={'ruff':'0.15.8','prettier':'3.6.2','status':'PASS','first_prettier_attempt':'cwd /workspace plugin resolution refused; no change; repo-cwd rerun PASS'}
manifest['old143_case_helper_byte_bodies_and_test10_predicates']='BYTE_EXACT'
(BASE/'composition-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
patch=''.join(''.join(difflib.unified_diff((P/rel).read_text().splitlines(keepends=True),(C/rel).read_text().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel)) for rel in (TEST,REGISTRY,CLIENT,MAIN))
patch+=''.join(difflib.unified_diff([],(C/NEW).read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+NEW))
(BASE/'proposal.patch').write_text(patch)
for path in C.rglob('*'):
    if path.is_file():
        target=BASE/'runtime-source'/path.relative_to(C);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
runtime=BASE/'runtime-source'
files={str(path.relative_to(runtime)):{'bytes':path.stat().st_size,'sha256':sha(path)} for path in sorted(runtime.rglob('*')) if path.is_file()}
(BASE/'runtime-source-inventory.json').write_text(json.dumps({'qualification':'SOURCE_ONLY_FORMAT_LINT_PASS_UNIT_NATIVE_UNRUN_FINITE_PHYSICAL_CLOSURE','files':files},indent=2)+'\n')
(BASE/'preservation-proof.json').write_text(json.dumps({'original143_owning_function_hashes':{name:hashlib.sha256(body.encode()).hexdigest() for name,body in functions((P/TEST).read_text()).items()},'caller_old_function_hashes':{name:hashlib.sha256(body.encode()).hexdigest() for name,body in old.items()},'old143_owning_helpers_tests_and_test10_byte_exact':True,'all_root_helpers_and_selectors_byte_exact':True,'caller_whole_source_single_callback_inverse':True,'authored13_class_AST_and_independent_vectors_exact':True,'native_body_roles_whole_inverse':'retained-clock-inputs/exact-native-inverse.json','unchanged_provider_inputs':provider},indent=2)+'\n')
print(json.dumps({'files':manifest['files'],'new13_helper':sha(C/NEW),'patch_sha256':sha(BASE/'proposal.patch'),'whole_old143_body_preservation':True},sort_keys=True))
