# Dedicated, extracted Debian GTK runtime; source after the normal activation.
export PATH="/workspace/.ergopti-cloud/gtk-root/usr/bin:/workspace/.ergopti-cloud/bin:$PATH"
export LD_LIBRARY_PATH="/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu:/workspace/.ergopti-cloud/sysroot/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LUA_PATH="/workspace/.ergopti-cloud/gtk-root/usr/share/lua/5.1/?.lua;/workspace/.ergopti-cloud/gtk-root/usr/share/lua/5.1/?/init.lua;${LUA_PATH:-;}"
export LUA_CPATH="/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;${LUA_CPATH:-;}"
export GI_TYPELIB_PATH="/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/girepository-1.0${GI_TYPELIB_PATH:+:$GI_TYPELIB_PATH}"
export WEBKIT_EXEC_PATH=/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1
export WEBKIT_INJECTED_BUNDLE_PATH=/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/injected-bundle
export GSETTINGS_SCHEMA_DIR=/workspace/.ergopti-cloud/gtk-root/usr/share/glib-2.0/schemas
export XDG_DATA_DIRS="/workspace/.ergopti-cloud/gtk-root/usr/share:${XDG_DATA_DIRS:-/usr/local/share:/usr/share}"
export GDK_BACKEND=x11
