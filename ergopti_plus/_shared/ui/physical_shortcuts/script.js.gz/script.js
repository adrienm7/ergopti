// _shared/ui/physical_shortcuts/script.js

/**
 * The native session retains source ownership and action parameters. This page
 * selects registry positions manually; browser key events are never capture proof.
 */
const bridge = makeHostBridge('physical_shortcuts_bridge');
// Every message crosses as JSON text, on the three OS: each host decodes it
// keeping null (the shared lossless decoder, AutoHotkey's JSON_NULL), so an
// explicit null is never read as an absent field (physical_editor_contract.lua).
const post = (message) => bridge(JSON.stringify(message));
let strings = {};
// The host names each modifier and position from the shared key name table.
let names = { modifiers: {}, positions: {} };
let entries = [];
let previous = null;
let token = null;
let selection = 0;
let pending = false;
let writable = true;
let captureAvailable = false;
// A native position capture is waiting for its key, which may be Escape.
let capturing = false;
const modifierNames = ['ctrl', 'alt', 'shift', 'super'];
const node = (id) => document.getElementById(id);

/**
 * Reads one name the host sent; a missing one is a host defect, never an id.
 * @param {object} table Id to translated name.
 * @param {string} id Modifier id or physical code.
 * @returns {string} The translated name.
 */
function named(table, id) {
	const name = table[id];
	if (typeof name !== 'string' || name === '')
		throw new Error('physical shortcuts: no name for ' + id);
	return name;
}

function status(key) {
	node('status').textContent = strings[key] || '';
}

function busy(value) {
	pending = value;
	node('capture').disabled = value || !writable || !captureAvailable;
	for (const id of ['add', 'choose', 'cancel', 'position']) node(id).disabled = value || !writable;
	for (const input of node('modifiers').querySelectorAll('input'))
		input.disabled = value || !writable;
	node('save').disabled = value || !writable || token === null;
	for (const button of node('entries').querySelectorAll('button'))
		button.disabled = value || !writable;
}

function changed() {
	capturing = false;
	post({ action: 'cancel_position' });
	selection += 1;
	token = null;
	node('selected-action').textContent = '';
	node('save').disabled = true;
}

function edit(record) {
	if (pending || !writable) return;
	previous = record ? record.slot : null;
	changed();
	node('editor').hidden = false;
	node('position').value = record
		? record.code
		: Array.from(node('position').options).find((option) => !option.disabled)?.value || '';
	for (const name of modifierNames) node('mod-' + name).checked = record?.mods[name] === true;
	status('');
	node('position').focus();
}

function render() {
	node('entries').replaceChildren();
	node('empty').hidden = entries.length !== 0 || !writable;
	for (const record of entries) {
		const row = document.createElement('li');
		row.className = 'entry';
		const label = document.createElement('p');
		label.textContent =
			modifierNames
				.filter((name) => record.mods[name])
				.map((name) => named(names.modifiers, name))
				.concat(named(names.positions, record.code))
				.join(' + ') +
			' → ' +
			record.label;
		const modify = document.createElement('button');
		modify.type = 'button';
		modify.textContent = strings.edit;
		modify.addEventListener('click', () => edit(record));
		const remove = document.createElement('button');
		remove.type = 'button';
		remove.textContent = strings.remove;
		remove.addEventListener('click', () => {
			if (pending || !writable) return;
			busy(true);
			post({ action: 'remove', slot: record.slot });
		});
		row.append(label, modify, remove);
		node('entries').appendChild(row);
	}
}

// Called only by the actual page owner after canonical/native capture.
function init(data) {
	strings = data.strings;
	names = data.names;
	entries = data.entries;
	for (const id of [
		'title',
		'manual-hint',
		'capture',
		'capture-reason',
		'empty',
		'add',
		'position-label',
		'modifier-label',
		'choose',
		'save',
		'cancel',
		'close'
	]) {
		node(id).textContent = strings[id];
	}
	document.title = strings.title;
	// The strings come in the user's language: the root says which, and its
	// direction, as for the other windows (WCAG 3.1.1, PCK-22). Every host
	// seeds it.
	if (typeof window._i18n_locale === 'string' && window._i18n_locale)
		window.setPageLocale(window._i18n_locale);
	else
		console.error('physical shortcuts: no window._i18n_locale seeded; the page language stays en');
	node('position').replaceChildren();
	for (const position of data.positions) {
		const option = document.createElement('option');
		option.value = position.code;
		option.textContent = named(names.positions, position.code);
		option.disabled = position.available !== true;
		if (position.reason) option.textContent += ' — ' + position.reason;
		node('position').appendChild(option);
	}
	node('modifiers')
		.querySelectorAll('label')
		.forEach((label) => label.remove());
	for (const name of modifierNames) {
		const label = document.createElement('label');
		const input = document.createElement('input');
		input.id = 'mod-' + name;
		input.type = 'checkbox';
		input.addEventListener('change', changed);
		label.append(input, document.createTextNode(named(names.modifiers, name)));
		node('modifiers').appendChild(label);
	}
	writable = data.readonly !== true;
	captureAvailable = data.capture === true;
	node('capture').disabled = !captureAvailable || !writable;
	node('capture-reason').hidden = data.capture === true;
	render();
	busy(false);
	status(data.reason || '');
}

// Echoed request identity keeps a late picker result out of a changed draft.
function selected(data) {
	if (data.request_id !== selection || node('editor').hidden || !writable) return;
	token = data.token;
	node('selected-action').textContent = data.label;
	busy(false);
}

// Only the still-owned native request fills the manual draft; page keys cannot mint it.
function captured(data) {
	capturing = false;
	if (data.request_id !== selection || node('editor').hidden || !writable) return;
	node('position').value = data.code;
	for (const name of modifierNames) node('mod-' + name).checked = data.mods[name] === true;
	token = null;
	node('selected-action').textContent = '';
	busy(false);
}

// Failed publication preserves fields and draft; durable success is never false.
function result(data) {
	if (data.committed !== true) {
		busy(false);
		status(data.reason || 'save_failed');
		return;
	}
	changed();
	node('editor').hidden = true;
	if (data.refreshed !== true) {
		writable = false;
		busy(false);
		status('saved_reopen');
		return;
	}
	entries = data.entries;
	render();
	busy(false);
	status('saved');
}

// Drops the open draft, as its Cancel button does.
function cancelDraft() {
	changed();
	node('editor').hidden = true;
	busy(false);
}

function refused(reason) {
	capturing = false;
	busy(false);
	status(reason || 'save_failed');
}

document.addEventListener('DOMContentLoaded', () => {
	node('add').addEventListener('click', () => edit(null));
	node('capture').addEventListener('click', () => {
		if (pending || !writable) return;
		if (node('editor').hidden) edit(null);
		else changed();
		post({ action: 'capture_position', request: { request_id: selection } });
		capturing = true;
	});
	node('position').addEventListener('change', changed);
	node('cancel').addEventListener('click', cancelDraft);
	node('choose').addEventListener('click', () => {
		if (pending || !writable) return;
		if (!node('position').value || node('position').selectedOptions[0]?.disabled) {
			status('unavailable');
			return;
		}
		changed();
		const mods = {};
		for (const name of modifierNames) mods[name] = node('mod-' + name).checked;
		post({
			action: 'choose',
			request: {
				code: node('position').value,
				mods,
				...(previous === null ? {} : { previous_slot: previous }),
				request_id: selection
			}
		});
	});
	node('editor').addEventListener('submit', (event) => {
		event.preventDefault();
		if (pending || !writable || token === null) return;
		busy(true);
		post({ action: 'save', token });
	});
	node('close').addEventListener('click', () => post({ action: 'close' }));
	post({ action: 'ready' });
});

// Escape cancels an open draft, as its Cancel button does, else closes the
// window: the page holds the keyboard, so no host window sees the key
// (PCK-19). A position capture in progress owns the keyboard, Escape included,
// and an IME composition keeps its own Escape.
document.addEventListener('keydown', (event) => {
	if (event.key !== 'Escape' || event.isComposing || event.keyCode === 229) return;
	if (event.defaultPrevented || capturing) return;
	event.preventDefault();
	if (node('editor').hidden) post({ action: 'close' });
	else cancelDraft();
});
