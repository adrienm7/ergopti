# Windows file port v2: independent source review

Status: inactive preparation, blocked for adoption. The user has deferred Windows
dependencies to TODO steps for a real PC. This review made no checkout changes
and executed no PowerShell, AHK, Win32 operation or native test.

Reviewed packet: `versions/file-port-v2`. All 24 entries in its source snapshot
matched their recorded byte counts and SHA-256 hashes. The AHK sources have a
UTF-8 BOM and LF. The exact reviewed implementation hashes are:

- File helper: `ee0a64aa40c17e15bd863e7b651043e3bd607848dd0f49bfb90b5150ea017d1f`.
- AHK file port: `6e1357c01ec29bce9f6099b412208c5d48117e13e7ba491db07fea54496b50fc`.
- Native test preparation: `a68c20221bbbfa97cf57f97f204352c37ed1e6cbfb9bfaa6953ef462d5a67f06`.

## Four source blockers

1. **Prepared child directory identity is missing.** The hashed prepared manifest
   records directory paths, whereas file entries also record native identities.
   `Open-OllamaPreparedStage` holds current child directories and checks their
   shape/DACL but never compares their originating native identities. Replacing
   a child with a new private directory and moving the original files into it
   preserves all checked file identities/digests. Publication or cleanup can then
   adopt/delete the replacement directory. Bind each child identity into the
   hashed manifest or another exact captured ownership receipt. The PC regression
   must replace a child while preserving the original file identities and verify
   refusal before publication or deletion.

2. **The AHK file-owner claim is not atomic.** `Run` forces Critical off, then
   checks `HasOwner()` separately from assigning `this.Record`. Timer/hotkey
   interruption can claim another owner between those steps and lose it when the
   original invocation resumes. Use a brief atomic claim with a second ownership
   check; restore the caller's mode before any authority/native callback. Prove
   that reentry cannot overwrite a retained construction task or its file debt.

3. **Authorization reads the caller's mutable map.** `_Current` uses the captured
   `Record["authority"]`, but authorization subsequently reads the original
   `Authority["authorize"]`. The currentness callback can replace that original
   callback synchronously. Invoke the captured authorizer. A causal regression
   must mutate the original map and show that the replacement is never called.

4. **Archive admission misses file/ancestor and receipt-root collisions.** The
   case-insensitive set rejects identical full names, but permits `ollama.exe`
   together with `ollama.exe/child`, or `prepared.json/child`. Directory creation
   conflicts with the file/receipt and can produce two intent kinds for the same
   creation-WAL key, which its own reader then rejects. Check the complete native
   namespace, implicit directories and reserved receipt roots before stage/WAL
   creation. Add independent ZIP fixtures, including case aliases, and assert
   refusal without acquiring a stage or creation journal.

The implementer acknowledged the first three findings and began a separate v3
preparation. Any later v3 files require their own frozen hashes and review; this
report does not approve them or transfer the v2 parser receipts to them.

## Reviewed boundaries and PC work still required

The helper supplies a protected current-user/SYSTEM DACL at directory creation,
rejects native reparse shapes, retains directory handles without DELETE sharing,
and reads catalogue/archive bytes through locked native file streams. Full byte
count and digest admission precedes ZIP inspection. Stream lengths, expanded-byte
overflow, path traversal, ADS/device names and equal-name collisions have explicit
checks. These are source findings, not proven Windows API results.

The creation WAL writes intent before creation and native identity before payload
bytes. Partial cleanup requires the captured journal identity and image hash;
changed images and present intent-only objects retain debt. Inventory enumeration
is one level at a time under held known directories, without recursively entering
unknown junctions. Exact-handle deletion and classified path absence precede a
retirement acknowledgement. Native Windows must qualify these operations and the
failure/retry windows, directory ancestry, DACL inheritance, journal durability,
no-replace rename while child handles remain held, and native structure layouts.

The AHK physical observer is independent of source drift and suspension. Its
atomic construction-task API still awaits the actual Group 3 adapter mapping.
The separate runtime draft's older seven-argument adapter call remains an
unclosed prerequisite. A retained immutable version lease must cover actual CLI
and library loading; version naming alone supplies no such lease. The large
download owner, TLS/proxy/redirect controls, consent, source-fenced endpoint
readiness, model-install consent and menu/session integration remain separate
unfinished work. No runtime, server, model or AI-enable success is established.

The packet contains 25 authored native cases, all unexecuted. Existing Unix
PowerShell 7.4.13 AST receipts report zero parser diagnostics and unchanged hashes;
they executed no candidate script, C# compilation or Win32 API and do not qualify
Windows PowerShell 5.1. Run the corrected native tests and required AHK/native
unit, E2E, packaging, per-user installation and restart checks on the PC. Retain
every existing assertion and independent fixture expectation. Do not count this
source review or the Unix AST check as native completion.
