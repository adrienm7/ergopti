"""Run independent receipt regressions against narrowly changed product mutants."""

from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    """Require each admitted mutant to fail its independently named regression."""
    runtime = sys.argv[1]
    repository = sys.argv[2]
    candidate = Path(__file__).resolve().parent.parent
    source = (candidate / "adapters" / "owned_process.lua").read_text(encoding="utf-8")
    tests = candidate / "tests" / "test_owned_process_seams.lua"
    mutants = [
        (
            "reentrant owner overwrite",
            "\t-- Source admission can synchronously dispatch another exact operation.\n"
            '\tif owners[request.owner] then return refuse("previous process cleanup pending") end\n',
            "",
            "reentrant source admission cannot overwrite another exact operation",
        ),
        (
            "refused monitor cannot rearm",
            'if not receipt or receipt.state ~= "open" or request.cleanup_watching then return end',
            'if not receipt or receipt.state ~= "open" or receipt.active then return end',
            "a refused cleanup monitor can be rearmed by the exact owner",
        ),
        (
            "kill acceptance invents absence",
            '\t\t\trequest.termination_accepted = Group.terminate(native, request.pid) == true\n',
            '\t\t\trequest.termination_accepted = Group.terminate(native, request.pid) == true\n'
            '\t\t\trequest.group_absent = request.termination_accepted\n',
            "accepted cancellation signals cannot release a successor",
        ),
        (
            "close call invents acknowledgement",
            '\treceipt.state = "closing"\n',
            '\treceipt.state = "closed"\n',
            "exit and native group absence still wait for every owned close ACK",
        ),
        (
            "failed result becomes success",
            '\t\t\tok = reason == nil and request.exit_code == 0,\n',
            '\t\t\tok = true,\n',
            "a leader with closed pipes cannot hide a remaining descendant group",
        ),
        (
            "daemon tail policy ignored",
            '\t\t\tif options.capture_tail == true then\n',
            '\t\t\tif false then\n',
            "explicit daemon tail capture remains bounded without killing ordinary output",
        ),
    ]
    for name, before, after, regression in mutants:
        assert source.count(before) == 1, f"mutant {name} lacks its exact unique source preimage"
        with tempfile.TemporaryDirectory(prefix="ergopti-owned-process-mutant-") as scratch:
            changed = Path(scratch) / "adapters" / "owned_process.lua"
            changed.parent.mkdir()
            changed.write_text(source.replace(before, after, 1), encoding="utf-8", newline="\n")
            result = subprocess.run(
                [runtime, str(tests), repository, scratch],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10,
            )
            assert result.returncode != 0, f"mutant {name} escaped the independent assertions"
            assert f"FAIL {regression}:" in result.stderr, (
                f"mutant {name} did not fail its causal regression: {result.stderr}"
            )
            print(f"PASS causal RED: {name}")
    print(f"Owned process causal mutants: {len(mutants)} rejected, 0 escaped")


if __name__ == "__main__":
    main()
