// Private read-only Git-object overlay; only the one source guard is executed.
'use strict';
const fs = require('fs');
const path = require('path');
const Module = require('module');
const cp = require('child_process');
require('/workspace/ergopti/node_modules/smol-toml');
const root='/workspace/ergopti';
const packet=__dirname;
const sha='cbb0efd431752da5ec8ccf38029463a76bb4ee55';
const originalRead=fs.readFileSync.bind(fs), originalDir=fs.readdirSync.bind(fs);
const rel='tools/test/test-tap-hold-key-catalog-single-source.cjs';
const deps={};
const overrides=process.argv[2] ? JSON.parse(originalRead(process.argv[2],'utf8')) : {};
fs.readFileSync=function(file, options){
 const absolute=path.resolve(String(file));
 if(absolute.startsWith(root+'/static/ergopti_plus/')){
  const relative=path.relative(root,absolute);
  let bytes;
  if(overrides[relative]) bytes=originalRead(overrides[relative]);
  else if(fs.existsSync(path.join(packet,'candidate',relative))) bytes=originalRead(path.join(packet,'candidate',relative));
  else bytes=cp.execFileSync('git',['show',sha+':'+relative],{cwd:root,maxBuffer:8*1024*1024});
  const dest=path.join(packet,'guard-dependencies',relative);
  if(!deps[relative]){fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,bytes);deps[relative]=require('crypto').createHash('sha256').update(bytes).digest('hex');}
  const encoding=typeof options==='string'?options:options?.encoding;
  return encoding?bytes.toString(encoding):bytes;
 }
 return originalRead(file,options);
};
fs.readdirSync=function(dir,options){
 const absolute=path.resolve(String(dir));
 if(absolute.startsWith(root+'/static/ergopti_plus/')){
  if(options) throw Error('Unexpected directory option in strict source overlay');
  return cp.execFileSync('git',['ls-tree','--name-only',sha+':'+path.relative(root,absolute)],{cwd:root,encoding:'utf8'}).trim().split('\n');
 }
 return originalDir(dir,options);
};
process.on('exit',()=>fs.writeFileSync(path.join(packet,'guard-dependency-pins.json'),JSON.stringify({source:sha,dependencies:deps},null,2)+'\n'));
const target=process.argv[3]||path.join(packet,'candidate',rel);
const m=new Module(path.join(root,rel),module);
m.filename=path.join(root,rel);m.paths=Module._nodeModulePaths(path.join(root,'tools/test'));
m._compile(originalRead(target,'utf8'),m.filename);
