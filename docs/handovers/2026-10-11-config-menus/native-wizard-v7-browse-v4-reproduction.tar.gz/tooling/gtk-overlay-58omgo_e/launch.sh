#!/usr/bin/env bash
set -euo pipefail
if (($# == 0)); then
    printf 'Pass an executable and its arguments.\n' >&2
    exit 2
fi
view_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec /usr/bin/bwrap \
    --unshare-user --unshare-pid --die-with-parent --new-session \
    --ro-bind / / \
    --tmpfs /run \
    --ro-bind /usr/lib/x86_64-linux-gnu /run/ergopti-system-libs \
    --ro-bind /usr/bin /run/ergopti-system-bin \
    --ro-bind "$view_root/libs" /usr/lib/x86_64-linux-gnu \
    --ro-bind "$view_root/bin" /usr/bin \
    --bind /workspace /workspace \
    --bind /tmp /tmp \
    --ro-bind /workspace/tooling/gtk /workspace/tooling/gtk \
    --ro-bind "$view_root" "$view_root" \
    --proc /proc --dev /dev --tmpfs /dev/shm \
    -- "$@"
