from pathlib import Path
p=Path('static/ergopti_plus/macos/modules/keystats/log_manager.lua');s=p.read_text();s=s.replace('local LedgerAppend = require("adapters.ledger_append")','local LedgerAppend = require("adapters.ledger_append")\nlocal LocalLedgerReplay = require("adapters.local_ledger_replay")');s=s.replace('local _recovery = nil','local _recovery = nil\n\n--- A partial raw replay never admits live ingest before a successful retry.\nlocal _local_replay_failed = false',1);s=s.replace('local _recovery_pace\n','',1)
a=s.index('--- Apply the durable portion');b=s.index('--- Flush the current recovery walker batch',a)
s=s[:a]+'''local _recovery_pace

--- Apply complete local transactions without retaining the historical SQL image.
--- The source transaction is indivisible; the slice budget is best effort for
--- one unusually large batch, while reads and scanning yield between batches.
---@param db userdata
---@return boolean, table
local function _replay_local_data_sql(db)
	local cursor = { offset = 0, date = nil }
	local attrs = fs.attributes(_paths.data_sql_path)
	if not attrs or (attrs.size or 0) == 0 then return true, cursor end
	local job = assert(_recovery, "local replay requires its recovery owner")
	local reader, failure = LocalLedgerReplay.open(_paths.data_sql_path, attrs)
	job.reader = reader
	assert(failure == nil, failure)
	while true do
		local status, bytes = LocalLedgerReplay.step(reader)
		if status == "batch" then
			local rc = db:exec(bytes)
			if rc ~= sqlite3.OK then
				pcall(function() db:exec("ROLLBACK;") end)
				error("local ledger SQL replay refused: " .. tostring(db:errmsg()), 0)
			end
			local batch_cursor = _local_ledger_replay_cursor(bytes, #bytes)
			if batch_cursor.date then cursor = batch_cursor end
		elseif status == "done" then
			local trailing = _local_ledger_replay_cursor(bytes, 0)
			if trailing.trailing_rollover then cursor = trailing end
			job.reader = nil
			Logger.done(LOG, "Replayed %d durable local-ledger byte(s).", reader.scanner.committed)
			return true, cursor
		end
		_recovery_pace()
	end
end

''' +s[b:]
# Publication is an actual checked transaction, and never rewinds a warm cache
# whose committed SQLite outbox has not reached data.sql yet.
a=s.index('\tSqliteWriter.set_next_event_id(max_id + 1)',s.index('local function _persist_recovery_state'));b=s.index('\nend',a)
s=s[:a]+'''	local cached = { offset = 0, date = nil }
	for row in db:nrows("SELECT value FROM meta WHERE key='today_log_offset'") do cached.offset = tonumber(row.value) or 0 end
	for row in db:nrows("SELECT value FROM meta WHERE key='today_log_date'") do
		if type(row.value) == "string" and row.value ~= "" then cached.date = row.value end
	end
	if cached.date and (not cursor.date or cached.date > cursor.date
		or (cached.date == cursor.date and cached.offset > cursor.offset)) then cursor = cached end
	local context_json = assert(json.encode(Aggregator.get_ngram_ctx() or {}), "cannot encode recovery context")
	local old_id = SqliteWriter.get_next_event_id()
	assert(db:exec("BEGIN TRANSACTION;") == sqlite3.OK, "cannot begin recovery publication")
	local ok, failure = pcall(function()
		SqliteWriter.set_next_event_id(max_id + 1)
		assert(SqliteWriter.persist_next_event_id() == true, "cannot publish replayed event id")
		assert(db:exec(string.format("UPDATE meta SET value='%d' WHERE key='today_log_offset';", cursor.offset)) == sqlite3.OK,
			"cannot publish replay cursor")
		assert(db:exec("UPDATE meta SET value=" .. _sq(cursor.date or "") .. " WHERE key='today_log_date';") == sqlite3.OK,
			"cannot publish replay date")
		assert(db:exec("UPDATE meta SET value=" .. _sq(context_json) .. " WHERE key='ngram_ctx_json';") == sqlite3.OK,
			"cannot publish replay context")
		assert(db:exec("COMMIT;") == sqlite3.OK, "cannot commit recovery publication")
	end)
	if not ok then
		pcall(function() db:exec("ROLLBACK;") end)
		SqliteWriter.set_next_event_id(old_id)
		error(failure, 0)
	end
	Rotation.set_offset(cursor.offset, cursor.date)
	return true''' +s[b:]
# Extend the existing owner and preserve independently tested aggregate entry.
s=s.replace('if _recovery ~= job then return end\n\tjob.slice_start_ns', 'if _recovery ~= job or job.failed or job.cancelled then return end\n\tjob.slice_start_ns',1)
s=s.replace('''	if not resumed then
		Logger.error(LOG, "Aggregate cache recovery raised: %s.", tostring(resume_err))
	end''','''	if not resumed then
		job.failed = true
		if job.local_replay then _local_replay_failed = true end
		Logger.error(LOG, "Cache recovery raised; incomplete local replay keeps ingest blocked: %s.", tostring(resume_err))
	end''',1)
s=s.replace('''	if coroutine.status(job.co) == "dead" then
		_recovery = nil''','''	if coroutine.status(job.co) == "dead" then
		if job.reader and not LocalLedgerReplay.close(job.reader) then
			Logger.error(LOG, "Local replay reader cleanup remains pending.")
			return
		end
		_recovery = nil''',1)
s=s.replace('''		_recovery = nil
		_restore_live_aggregator(job.db)
	end
end

--- Starts the aggregate''','''		job.failed = true
		if job.local_replay then _local_replay_failed = true end
		if not job.reader or LocalLedgerReplay.close(job.reader) then
			if job.handle == nil then _recovery = nil end
		end
	end
end

--- Starts the aggregate''',1)
s=s.replace('local function _start_aggregate_recovery(db)','local function _start_aggregate_recovery(db, replay_local)',1)
s=s.replace('''	job.co = coroutine.create(function() _recover_aggregate_cache(db) end)''','''	job.local_replay = replay_local == true
	job.co = coroutine.create(function()
		if job.local_replay then
			local replay_ok, cursor = _replay_local_data_sql(db)
			assert(replay_ok and _persist_recovery_state(db, cursor), "local replay publication refused")
			job.local_replay = false
			_local_replay_failed = false
		end
		_recover_aggregate_cache(db)
	end)''',1)
s=s.replace('''	_recovery = nil
	local settled = true
	if job.handle''','''	job.cancelled = true
	if job.local_replay then _local_replay_failed = true end
	local settled = true
	if job.handle''',1)
s=s.replace('''	pcall(Logger.warn, LOG, "Aggregate cache recovery interrupted''','''	if job.reader and not LocalLedgerReplay.close(job.reader) then settled = false end
	if settled then _recovery = nil end
	pcall(Logger.warn, LOG, "Aggregate cache recovery interrupted''',1)
s=s.replace('if _recovery ~= nil then return false end\n\tif not _resume_pending_rollover()', 'if _recovery ~= nil or _local_replay_failed then return false end\n\tif not _resume_pending_rollover()',1)
# Remove whole-ledger synchronous replay; recovery mismatch is also the existing
# durable retry marker for a cache interrupted after some raw batches committed.
a=s.index('\t\tlocal recovery_ready = true',s.index('local function _init(core_state)'));b=s.index('\t\t-- Restore persisted counters',a)
s=s[:a]+'''		local recovery_due = db and (cache_was_fresh
			or _aggregate_cache_revision(db) ~= AGGREGATE_CACHE_REVISION)
'''+s[b:]
s=s.replace('if recovery_due then _start_aggregate_recovery(db) end','if recovery_due then _start_aggregate_recovery(db, true) end',1)
s=s.replace('''	if _ingest_timer then
		if _physical_sink_generation''','''	if _local_replay_failed and _recovery == nil then
		_start_aggregate_recovery(assert(SqliteWriter.get_db()), true)
	end
	if _recovery and (_recovery.failed or _recovery.cancelled) then return false end

	if _ingest_timer then
		if _physical_sink_generation''',1)
s=s.replace('''	local complete = _cancel_aggregate_recovery()
	local ingest_timer = _ingest_timer''','''	local recovery_settled = _cancel_aggregate_recovery()
	local complete = recovery_settled
	local ingest_timer = _ingest_timer''',1)
a=s.index('function M.stop(opts)');i=s.index('\tlocal db_ok, db_result_or_err',a);s=s[:i]+'''	if not recovery_settled then
		Logger.error(LOG, "SQLite close waits for exact recovery cleanup.")
		return false
	end
'''+s[i:]
p.write_text(s)
