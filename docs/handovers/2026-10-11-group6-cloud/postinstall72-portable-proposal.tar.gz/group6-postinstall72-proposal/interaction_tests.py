class NativePostInstallCancellationInteractionTests(unittest.TestCase):
    setUp = NativePostInstallTrustObservationTests.setUp
    close_fixture = NativePostInstallTrustObservationTests.close_fixture
    receipt = staticmethod(NativePostInstallTrustObservationTests.receipt)

    @staticmethod
    def actual_signal_handler():
        # Acquire the exact existing worker handler without running its main role.
        import ast

        source = (SUPPORT / "native_http_wire_fixture.py").read_text()
        main = next(
            node
            for node in ast.parse(source).body
            if isinstance(node, ast.FunctionDef) and node.name == "main"
        )
        handler = next(
            node
            for node in main.body
            if isinstance(node, ast.FunctionDef) and node.name == "interrupted"
        )
        namespace = {"FixtureFailure": WIRE.FixtureFailure}
        exec(
            compile(
                ast.Module(body=[handler], type_ignores=[]), "existing-wire-signal-handler", "exec"
            ),
            namespace,
        )
        return namespace["interrupted"]

    def interrupted_installation(self, signum, actor):
        import signal

        previous = signal.getsignal(signum)
        signal.signal(signum, self.actual_signal_handler())
        interrupted = []
        children = []
        requests = []
        original = self.fixture._command
        acquire_original = subprocess.Popen
        stderr, stdout = io.StringIO(), io.StringIO()

        def dispatch(*args):
            try:
                os.kill(os.getpid(), signum)
            except BaseException as failure:
                interrupted.append(failure)
                raise

        def acquire(*arguments, **options):
            child = acquire_original(*arguments, **options)
            child.output_owner, child.error_owner = options["stdout"], options["stderr"]
            children.append(child)
            return child

        def command(arguments, input_bytes=b"", **options):
            requests.append((arguments, input_bytes, options))
            if arguments[0] == "portable-owned-query":
                if actor == "before_query":
                    dispatch()
                script = (
                    "import sys; sys.stdin.buffer.read(); sys.stdout.buffer.write("
                    + repr(self.receipt())
                    + ")"
                )
            else:
                script = "import sys; sys.stdout.buffer.write(b'original add output')"
            return original([sys.executable, "-I", "-B", "-c", script], input_bytes, **options)

        refusal = None
        try:
            parse = (
                mock.patch.object(self.fixture, "_admin_trust_fact", side_effect=dispatch)
                if actor == "after_query"
                else contextlib.nullcontext()
            )
            with parse, mock.patch.object(self.fixture, "_command", side_effect=command):
                with mock.patch.object(WIRE.subprocess, "Popen", side_effect=acquire):
                    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                        try:
                            self.fixture.trust(True)
                        except BaseException as failure:
                            refusal = failure
        finally:
            signal.signal(signum, previous)
        # Observe real original add/query closure before asserting cancellation.
        self.assertEqual(len(requests), 2)
        self.assertLessEqual(requests[1][2]["deadline"], requests[0][2]["deadline"])
        self.assertEqual(len(children), 2 if actor == "after_query" else 1)
        for child in children:
            self.assertEqual(child.returncode, 0)
            self.assertTrue(child.stdin.closed)
            self.assertTrue(child.output_owner.closed)
            self.assertTrue(child.error_owner.closed)
        self.assertEqual(stdout.getvalue(), "")
        self.assertEqual(self.fixture.command_file_debt, [])
        self.assertTrue(self.fixture.trust_attempted)
        self.assertEqual(self.fixture.command_fact, {"phase": "complete", "status": 0})
        self.assertEqual(len(interrupted), 1)
        self.assertEqual(type(interrupted[0]), WIRE.FixtureFailure)
        self.assertEqual(interrupted[0].args, ("Native fixture cancelled",))
        self.assertIs(refusal, interrupted[0])
        self.assertNotIn("# native_http_admin_trust_installed ", stderr.getvalue())

    def test82ActualSIGINTAndSIGTERMAfterSettledQueryCannotBecomeUnknownSuccess(self):
        import signal

        for signum in (signal.SIGINT, signal.SIGTERM):
            with self.subTest(signum=int(signum)):
                self.interrupted_installation(signum, "after_query")

    def test83ActualSIGINTAndSIGTERMBeforeQueryCannotBecomeUnknownSuccess(self):
        import signal

        for signum in (signal.SIGINT, signal.SIGTERM):
            with self.subTest(signum=int(signum)):
                self.interrupted_installation(signum, "before_query")
