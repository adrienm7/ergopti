from pathlib import Path
import subprocess,os,json
w=Path('/workspace/ergopti-macos-native-validation');d=Path('/workspace/scratch/oct28-runner/temp-followup');e=dict(os.environ);e.update(USER='agent',LOGNAME='agent');e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';e['TMPDIR']=str(d/'tmpdir')
helper=w/'static/ergopti_plus/macos/tests/helpers/init.lua';old=d/'old-helpers.lua';old.write_bytes(subprocess.check_output(['git','show','HEAD:static/ergopti_plus/macos/tests/helpers/init.lua'],cwd=w))
bootstrap=r'''
local f = assert(io.open(arg[1], "rb")); local source = assert(f:read("*a")); assert(f:close())
local original_path, runner = arg[2], arg[3]
package.preload["tests.helpers"] = assert(load(source, "@" .. original_path, "t"))
arg = { "--only=tests.unit.harness.test_temp_dir_native_paths" }
dofile(runner)
'''
r=subprocess.run(['lua','-',str(old),str(helper),str(w/'static/ergopti_plus/macos/tests/run.lua')],cwd=w,env=e,input=bootstrap,text=True,capture_output=True);(d/'same-final-old-helper.stdout').write_text(r.stdout);(d/'same-final-old-helper.stderr').write_text(r.stderr)
assert r.returncode==1 and 'Passed tests:  2\nFailed tests:  2' in r.stdout;assert not list((d/'tmpdir').glob('ergopti-native-temp.*'))
compat=r'''
package.path=arg[3].."/?.lua;"..arg[3].."/?/init.lua;"..arg[4].."/?.lua;"..arg[4].."/?/init.lua;"..package.path
local f = assert(io.open(arg[1], "rb")); local source = assert(f:read("*a")); assert(f:close())
local helper = assert(load(source, "@" .. arg[2], "t"))()
if arg[5] == "windows" then package.config = string.char(92) .. package.config:sub(2) end
local accepted, value = pcall(helper.temp_dir)
io.write(tostring(accepted), string.char(0), tostring(value))
'''
rows=[]
separator=chr(92)
for platform,value in [('posix','/'),('windows','C:'+separator+'scratch'+separator+'child'+separator),('windows',separator*2+'server'+separator+'scratch'+separator+'child'+separator)]:
 observations=[]
 for name,snapshot in [('old',old),('fixed',helper)]:
  env=dict(e,TMPDIR=value);p=subprocess.run(['lua','-',str(snapshot),str(helper),str(w/'static/ergopti_plus/macos'),str(w/'static/ergopti_plus/_shared/lua'),platform],cwd=w,env=env,input=compat,text=True,capture_output=True);assert p.returncode==0,p.stderr;observations.append({'name':name,'result':p.stdout})
 assert observations[0]['result']==observations[1]['result'],observations
 rows.append({'platform_model':platform,'input':value,'observations':observations})
x={'same_final_old_helper':{'actual_exit':r.returncode,'passed':2,'failed':2,'scope':'Actual frozen HEAD helper bytes loaded with their actual original source filename; active worktree never rewritten.'},'owned_fixture_residual':[],'root_and_windows_compatibility':rows,'windows_scope':'Pure host-rule compatibility model with actual unmodified NativePath API; not native Windows execution.'};(d/'same-final-old-helper-receipt.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
