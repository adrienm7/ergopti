const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const root = '/workspace/ergopti-windows-r6-tests';
const packet = __dirname;
const source = path.join(root, 'tools/test/test-ahk-test-coverage.cjs');
const sourceBytes = fs.readFileSync(source);
const owned = fs.mkdtempSync(path.join(packet, 'native-comment-fixture-'));
const tests = path.join(owned, 'static/ergopti_plus/windows/tests');
const tools = path.join(owned, 'tools/test');
fs.mkdirSync(tests, {recursive:true});
fs.mkdirSync(tools, {recursive:true});
const copied = path.join(tools, 'test-ahk-test-coverage.cjs');
fs.mkdirSync(path.join(owned,'tools/lib'),{recursive:true});
fs.copyFileSync(path.join(root,'tools/lib/script-source.cjs'),path.join(owned,'tools/lib/script-source.cjs'));
fs.writeFileSync(copied, sourceBytes);
assert.deepEqual(fs.readFileSync(copied), sourceBytes);
const framework = path.relative(tests, path.join(root, 'static/ergopti_plus/windows/tests/test_framework.ahk')).split(path.sep).join('/');
const child = path.join(tests, 'test_orphan.ahk');
fs.writeFileSync(child, '\ufeffTest("owned child registration", () => AssertEqual(1, 2))\n');
const entry = path.join(tests, 'run_all.ahk');
const alias = path.join(tests, "included_O'Brien.ahk");
fs.writeFileSync(alias, '\ufeffTest("apostrophe companion", () => AssertEqual(1,2))\n');
const cases = [{name:'active',include:'#Include test_orphan.ahk'},{name:'line comment',include:'; #Include test_orphan.ahk'},{name:'block comment',include:'/*\n#Include test_orphan.ahk\n*/'},{name:'continuation data',include:'Unused := \"\n(\n#Include test_orphan.ahk\n)\"'},{name:'apostrophe path then block',include:"#Include included_O'Brien.ahk\n/*\n#Include test_orphan.ahk\n*/"},{name:'apostrophe path then active',include:"#Include included_O'Brien.ahk\n#Include test_orphan.ahk"},{name:'active trailing comment',include:'#Include test_orphan.ahk ; active native include'},{name:'lowercase directive',include:'#include test_orphan.ahk'},{name:'include again directive',include:'#IncludeAgain test_orphan.ahk'}];
let safeToClean = true;
try {
 const observations = [];
 for (const vector of cases) {
  const text = '#Requires AutoHotkey v2.0\n#SingleInstance Off\n#NoTrayIcon\n#Include ' + framework + '\n' + vector.include + '\nCommentProbeOrphanCount := 0\nfor CommentProbeRecord in TEST_REGISTRY {\n if CommentProbeRecord.name == "owned child registration"\n  CommentProbeOrphanCount += 1\n}\nFileAppend("ORPHAN_REGISTERED=" . CommentProbeOrphanCount . "|TOTAL=" . TEST_REGISTRY.Length . "|AHK=" . A_AhkVersion, "*", "UTF-8-RAW")\nExitApp(0)\n';
  fs.writeFileSync(entry,'\ufeff'+text);
  safeToClean = false;
  const native = cp.spawnSync('timeout',['--kill-after=5s','45s','xvfb-run','-a','wine','/workspace/toolchain/ahk/AutoHotkey64.exe','/ErrorStdOut','Z:'+entry.replace(/\//g,'\\')],{encoding:'utf8',env:{...process.env,WINEPREFIX:'/workspace/toolchain/wine-r3-metrics-owned',LC_ALL:'C.UTF-8'}});
  safeToClean = native.status !== 124 && native.status !== null && native.signal === null && !native.error;
  assert.equal(native.status,0,JSON.stringify(native));
  const observed = /^ORPHAN_REGISTERED=([01])\|TOTAL=([012])\|AHK=2\.0\.26$/.exec(native.stdout);
  assert(observed,vector.name+': actual real framework registration precondition: '+native.stdout);
  const expectedCli = Number(observed[1]) ? 0 : 1;
  const cli = cp.spawnSync(process.execPath,[copied],{encoding:'utf8',cwd:owned});
  assert(cli.status === 0 || cli.status === 1, JSON.stringify(cli));
  observations.push({case:vector.name,entry_source:text,native:{status:native.status,stdout:native.stdout,stderr:native.stderr},cli:{status:cli.status,stdout:cli.stdout,stderr:cli.stderr},expected_cli:expectedCli});
 }
 const result = {source_sha256:crypto.createHash('sha256').update(sourceBytes).digest('hex'),canonical_cli_copy_byte_identical:true,real_test_framework_used:true,observations};
 fs.writeFileSync(path.join(packet,'grammar-old-native-verdicts.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify(observations.map(r=>({case:r.case,native:r.native.stdout,cli_exit:r.cli.status,expected_cli:r.expected_cli}))));
 assert.deepEqual(observations.map(r=>r.cli.status), observations.map(r=>r.expected_cli), 'coverage CLI must reject the actual unregistered child in comments');
} finally {
 if (safeToClean) fs.rmSync(owned,{recursive:true});
}
