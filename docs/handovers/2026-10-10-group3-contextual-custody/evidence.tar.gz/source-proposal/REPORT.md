# Recovered Linux contextual delivery proposal

This is a fresh source-only reconstruction against `7892616a62d6925126d4ff98b4d4818eb387813b`, which includes dev `1e0556e8`. It contains no fresh Lua, native, JavaScript, compilation or syntax execution result. The previous container's private packet, raw logs and unpublished `e1c3b2d2a` Git object are unavailable; remembered counts are not retained evidence and are not used to qualify this packet.

## Source scope and causal boundary

The proposal changes only the existing deferred portion of `M.consume()` in Linux `modules/shortcuts/keyboard_shortcuts.lua`. The original source is SHA256 `dc1334e8cc95bc294be7900fbaefa8574a2e8c65378684c91773c25bdda6d2eb`. The candidate is `4244f7a56851e445da40727b5517d258128af1311c6f97b231c05e91cefc38f2`, which exactly reconstructs the remembered final source image.

In the original source, the queued contextual decision is checked before `fire()`. `fire()` synchronously logs the action, then lazily requires the executor, then executes it. The shared logger's `set_sink()` is an actual public callback: `_shared/lua/logger/init.lua` `deliver()` calls that sink synchronously. The original deferred contextual path provides no late guard to `fire()`, while its physical path already supplies one. A genuine logger callback can therefore change the live admission, source or configuration owner between the earlier check and executor entry. This packet freezes a regression to test that source hypothesis again; it does not substitute a fake logger or claim that the old vanished reproduction has been rerun.

The repair pins the original admission and decision function references before queueing. Its contextual guard checks the configuration owner, dispatch generation and function identities before and after callbacks. It resolves through the original `M.magic_editor_decision` and shared `shortcuts.magic_editor.can_deliver` policy. It reads live admission again after source resolution, because the source getter can synchronously reenter and change the actual RAM gates. Exceptions from the deferred original admission/decision getters close delivery. The same guard runs after `fire()` logging and module loading, immediately before its existing executor seam. A current decision must additionally be active.

The `fire()` body, matching/capture behavior, ordinary slots, physical delivery guard, shared policy, schemas, manifests and capability declarations remain byte-exact. This does not grant physical/native input or output authority. No first-require-only failure is claimed: contextual decision resolution already loads the action catalogue. No independently observed inactive same-generation source receipt is claimed; checking `current.active` preserves the actual shared policy requirement.

## Test scope

The whole enrolled original test file, SHA256 `d66dde379ab583ba037c0c5c02dc32141d333a4840c387b571cfe53401ea77c3`, remains its byte-exact prefix. The appended scope uses an exact copy of the original local `with_editor` fixture, SHA256 `b3b67df955c62b33708fd66465b1d0fd1531592072ad598a2bd9b5f5da2ff9f4`. Its existing fake selected-source and executor seams are retained; no replacement executor or receipt oracle is added. A fresh actual shared logger core and shim are loaded and restored around each case, and each cancellation requires that the genuine configured sink was observed.

Ten lexical `helpers.it()` sites expand to twenty cases using the frozen loop domains:

- One unchanged-action positive control observing the real logger callback and exact action/binding.
- Six late logger changes: master, pause, inhibition, source generation, rebind, configuration acquire/release.
- Three same-generation live gate changes from the original selected-source callback after logging.
- Three configuration-owner transitions in the late admission, source and final-admission phases.
- One unavailable late selected-source callback: protected completion, actual failure count and zero actual executor count, plus the original failure/action observations.
- One refusal to query source after the original admission callback retires the configuration owner.
- Two replacement admission/decision owner cases, with zero foreign getter invocation.
- One admission issuer replacement during the original getter, with no subsequent source query or foreign invocation.
- One refusal to reread admission after the source callback retires dispatch ownership.
- One issuer replacement during the final original admission read.

The exception case uses named `completed`, `observed_failures` and `executed_actions` protected results. It asserts actual failed-source and executor observations rather than a callback return shape. It contains no inline `assert_true(pcall(...))`, scanner waiver, baseline change or weakened original assertion. The appended test image is a fresh reconstruction with a new hash; it is not represented as a retained historical test image.

Seven one-span source inverse images are frozen: remove late guard, keep stale admission after source, remove post-admission owner fence, remove post-decision owner fence, remove terminal owner fence, remove function issuer pins, let original source exceptions escape. All inverse execution remains UNRUN.

## Evidence and outstanding gates

`packet-receipt.json` pins original/candidate source and tests, additions, exact helper, patch, seven inverse images and a manifest of 2,119 current tracked Linux/shared preparation dependency files. No repository tree was copied. This is a preparation manifest, not an executed dependency trace. `git apply --check` passed against the current exact preimages with empty stdout/stderr; it did not apply the patch or edit canonical source. Bytes outside the source replacement and the entire original test prefix are checked directly by `reconstruct.py`.

Runtime is explicitly UNRUN while the parent's Mac selected gate is active. After parent source review and execution release, run original/candidate twenty-case component checks and seven inverse variants serially on LuaJIT and Lua 5.4, preserving raw stdout/stderr and exits. Pair the unchanged original magic-editor cohort and configuration-owner controls on both source images. Then parent may receive the narrow patch and run the canonical change-selected format/JS/Linux/E2E checks. Native input, desktop capture, installed startup, packaging and hardware delivery are not qualified by these fixtures.
