# Diagnostic opener receiving

Dated source boundary:15October2026, published base614970f3c, exact candidate tree5f3a0f0c5926593b8fe10802ca779d5e55222e51. Published source commit 4072b129f166f290a67a0fdc7cac19300a931079 has exactly this whole tree. Parent explicitly authorized final sealing after closed local recheck and publication automatic census.

The original paired validation is FAILED and is preserved byte-for-byte. Six selected gates passed; Linux units reported13,848PASS/1FAIL across521modules. The failing original FIFO digest exceeded its100ms budget; cause UNKNOWN. Printed112.03ms joins digest and writer completion and is not a timer-fire timestamp. There is no causal fix or historical-debt/flakiness waiver. The original unchanged9-case fixture subsequently passed, and only Linux was then rechecked in full: 13849PASS/0FAIL across521modules, unchanged source/assertions. Both closed original and recheck logs are included. The recheck does not identify or causally repair the first timeout.

|Selected gate|Original result|Source boundary|
|---|---|---|
|Format|PASS,430files|5f3a0f0c|
|JS|426PASS,0FAIL|5f3a0f0c|
|macOS Lua units with native ports stubbed|19,846PASS,0FAIL;1,604modules|5f3a0f0c|
|macOS E2E stubbed|101PASS;1explicitSKIP|5f3a0f0c|
|Linux Lua units|13,848PASS,1FAIL;521modules|5f3a0f0c;failure retained|
|Linux E2E|193PASS,0FAIL|5f3a0f0c|
|Linux managed HTTP native|18retained+30public actual controlsPASS,0SKIP|5f3a0f0c;authenticated SDK/tool admission|

Hosted manual CI38744427137 tested actual ff0fac6afe707cdb164f1cd37b7b856ed79a4384 with the exact same whole tree. It is FAILED:39jobs,30SUCCESS,5FAILURE,4SKIP. All17Linux installed scenarios succeeded. Failed jobs are both MacManagedOllama lanes, Macarchive qualification, Macverdict and selectedverdict. API job/step metadata was received; raw assertion logs/artifact contents were not received. No cause or acceptance is inferred from unavailable logs. Release is push-only guarded; this workflow_dispatch does not release.

The unchanged original diagnostics producer returned ok:true after its actual private xdg-open child exited23. The fix waits nonblockingly for child exit and both EOF receipts, then uses exact action/session/snapshot/revision/epoch ownership before acknowledgment or further side effects. Original-bug actual-child proof is distinct from newly discovered candidate cancellation reentry regressions. Final focused113/0 comprises77original+36additive subjects; native kernel save receiving is7/0. The earlier Mac UI9/0 used shared controller86bcb4 and does not qualify the final5cff controller; the fullcomposed Mac gate above receives the final image. Timeout/cancel/reentry controls through native ports remain distinct from actual child/kernel receipts. No desktop/browser rendering or installed Cocoa/WebKitGTK acceptance is claimed.

Source/before and source/after retain17ownedpath pre/postimages, with the new document explicitly absent before. All original subjects/assertions are preserved apart from the declared obsolete background-shell-string expectation replaced by exact executable/argv completion semantics; the same ordered4effects, complete bytes and stable URL assertions remain. Review is independent source review, not execution. Required convention delta is exactly one LF blank line. Historical fixture, setup, temporary-directory and initial strict failures are retained with their boundaries; no failed verdict is rewritten.

Safe environment summaries and activation sources preserve authenticated SDK/tool admission and replay limits; no private raw setup log, signed log URL, dependency binary, key, credential or duplicate earlier packet is included. Reconstructive replay was reviewed but not executed. This lot does not implement full daily-log collection or three-driver installed issue-form editability.

Final local composition:7selected gatesPASSED using6original successes and the fullunchanged Linux recheck; original pairFAILED remains authoritative for its own attempt. Hosted CI remainsFAILED as described above. A later archive-only feature publication may have a different tree solely because it adds this packet; that later commit is not the tested source commit.

SHA256SUMS covers every regular member except itself; the outer sealed receipt supplies the archive hash.
