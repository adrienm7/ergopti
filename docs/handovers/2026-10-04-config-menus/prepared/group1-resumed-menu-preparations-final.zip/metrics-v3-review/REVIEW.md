# Independent Metrics label successor review

Verdict: **CLEAR for source integration and selected verification gates**.
Reviewed packet `metrics-labels-current-v3.patch`, SHA256 `64282fbfc2268c7c0896b28371ede9f436a53c9c4f3958f926fb7b0aa9382f81`,
13 exact paths atop independently reviewed key-head packet `b3ce412465b6b071106e63a50375bba66cfb9baea5d0c0a597c8c85dc661e4d1`.
All exact head preimages and V3 postimages independently verified. Root files,
index, refs and CI were not mutated.

The shared declaration owns the two existing Linux idle/unavailable captions.
The shared renderer exposes explicitly inert provider rows: only label and
`disabled = true`, without callback, children, checked flag or behavior metadata.
Windows supplies the native port; macOS and Windows correctly hide Linux-only
statuses. Native progress-state selection, running caption and cancellation
callback preserve exact source behavior and existing return policy. No settings,
durability, recovery or cancellation acknowledgment semantics changed.
All 21 locale captions already exist and remain shared; the handwritten
independent corpus pins English/French exact text and existing progress text.
No previous corpus expectation or assertion was regenerated from implementation.
All three original native test modules remain complete exact byte prefixes.
Touched AHK files have UTF-8 BOM; packet text uses LF.

V1 is rejected and must not be applied. Its assignment to `Map.CaseSense` after
populating `Fields` throws under the official AHK v2 language contract, even
assigning the default value. V3 removes that redundant assignment, retains the
case-sensitive default, and appends uppercase foreign-field rejection tests.
V3 also distinguishes missing `unavailable` from an explicitly empty value,
matching the compiler/Lua strict contract, with independent native/Lua rejection
vectors. Only these three paths differ from V1; the ten remaining postimages,
including both generated artifacts and handwritten corpus, are exact V1 bytes.

Independent focused evidence:

- Linux owning module: **42 passed/0 failed** on Lua 5.4 and separately LuaJIT.
- macOS owning module: **18 passed/0 failed** on Lua 5.4 with repository stubs.
- Actual manifest contract and parity pass on unchanged V3 compiler/provider.
- Restoring original native Linux provider causes 36 passed/4 failed and actual
  JS provider-wiring assertion failure; restoring original shared renderer
  causes Linux 35 passed/5 failed and macOS 17 passed/1 failed. Those causes and
  relevant owner postimages are unchanged in V3; two added Linux strict vectors
  are independently green on the final source.
- Additional actual compiler mutations independently reject uppercase behavior
  fields and empty availability; both preserve the previously published output.
  Empty availability is refused by the existing shared availability validator
  before child-label validation. An initial review probe expected the later
  validator wording; its classification was corrected to the actual owner.
- Twice running the real menu generator reproduces exact generated hash
  `d440290bea37b9bde98a79525aa1290336b635340c370e4271cbbff472d4b163`.

Qualification boundary: native Windows tests are registered but unexecuted in
this Linux review. No physical input, native Hammerspoon/Karabiner, package or
installation qualification is claimed. Root owns serial full verify-change and
three-OS manual workflow_dispatch qualification for the shared native capability.
This bounded migration does not finish TODO54/81 or all native Metrics menu rows.
