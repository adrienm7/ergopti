"""Root-only serial genuine wizard receiving; preparation does not execute it."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/ergopti')
DELIVERY = Path('/workspace/ergopti-delivery/group1-complete-resume-20261007')
PACKET = DELIVERY / 'linux-wizard-real-webkit-private-harness-source-only-v7-metadata-20261011'
PROPOSAL_SHA = '36aa743baa913455d34f83c5de712aa18eaec0c76e025ff1510c4189c8d501f2'
HELPERS = {
    '/workspace/tooling/run-with-reaper.py': '3106bf9b753d7663e2dafcee2eec1421ed5a62a10e06b48e146c76ba41ee088d',
    '/workspace/tooling/run-with-gtk-namespace.py': '3f61f31c24810daf8a5036d3ab9af405691d1bb9e5a5f1511ac15b098b966ece',
    '/workspace/tooling/gtk-overlay-current.json': '5031605b50c8931505eec596c2e9f135b8f5d2e57d8facd052fd6386cd94c2d1',
    '/workspace/tooling/gtk-overlay-58omgo_e/launch.sh': '9d978cef88233d4be68cb30e19247e7857eb4d03db4882ea837537fbebe79396',
    '/workspace/tooling/gtk-overlay-58omgo_e/manifest.json': 'c91c65935b1410515f26909d05a1be32d0aa67104c5001b1cb4193f407419d01',
}
if sys.flags.optimize:
    raise RuntimeError('Optimized Python cannot enforce custody guards')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--qualification', type=Path, required=True)
parser.add_argument('--qualification-sha', required=True)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--qualified-commit', action='store_true')
parser.add_argument('--receipt', type=Path, required=True)
args = parser.parse_args()
env = os.environ.copy()
env.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*parts):
    return subprocess.check_output(['git', *parts], cwd=ROOT, env=env)

assert re.fullmatch('[0-9a-f]{40}', args.expected_head)
assert re.fullmatch('[0-9a-f]{64}', args.qualification_sha)
qualification = args.qualification.resolve(strict=True)
assert qualification.is_relative_to(DELIVERY) and sha(qualification) == args.qualification_sha
q = json.loads(qualification.read_text())
assert q['exit_code'] == 0
assert all(q[key] is True for key in ('inputs_unchanged', 'index_unchanged', 'head_unchanged'))
assert sha(qualification.with_suffix('.log')) == q['log_sha256']
head = git('rev-parse', 'HEAD').decode().strip()
assert head == args.expected_head
assert re.fullmatch('[0-9a-f]{40}', q['head'])
if args.qualified_commit:
    assert git('show', '-s', '--format=%P', head).decode().split() == [q['head']]
else:
    assert head == q['head']
assert isinstance(q['source_pins'], dict) and q['source_pins']
for name, expected in q['source_pins'].items():
    path = ROOT / name
    assert not Path(name).is_absolute() and path.resolve().is_relative_to(ROOT)
    assert path.is_file() and sha(path) == expected, name
if args.qualified_commit:
    diff = git('diff-tree', '--no-commit-id', '--name-status', '-r', '-z', '--no-renames', q['head'], head, '--')
    if diff:
        assert diff.endswith(b'\0')
        fields = diff[:-1].split(b'\0')
        assert len(fields) % 2 == 0
        for index in range(0, len(fields), 2):
            assert fields[index] in (b'A', b'M')
            assert fields[index + 1].decode() in q['source_pins']
assert not git('status', '--porcelain')
assert git('branch', '--show-current').decode().strip() == 'feat/config-menus'
assert git('rev-parse', 'refs/remotes/origin/feat/config-menus').decode().strip() == head
assert git('ls-remote', '--exit-code', '--heads', 'origin', 'refs/heads/feat/config-menus').decode().splitlines() == [head + '\trefs/heads/feat/config-menus']
assert sha(PACKET / 'SOURCE-PROPOSAL.json') == PROPOSAL_SHA
proposal = json.loads((PACKET / 'SOURCE-PROPOSAL.json').read_text())
inputs = {str(PACKET / name): value['sha256'] for name, value in proposal['files'].items()}
inputs.update(HELPERS)
inputs[str(PACKET / 'SOURCE-PROPOSAL.json')] = PROPOSAL_SHA
inputs[str(qualification)] = args.qualification_sha
inputs[str(qualification.with_suffix('.log'))] = q['log_sha256']
for name, expected in inputs.items():
    assert sha(Path(name)) == expected, name
closure = json.loads((PACKET / 'SOURCE-CLOSURE.json').read_text())
for name, expected in closure['production_sources'].items():
    assert name in q['source_pins'] and q['source_pins'][name] == expected, name
    assert sha(ROOT / name) == expected, name
receipt = args.receipt
assert receipt.is_absolute() and receipt.parent.resolve(strict=True).is_relative_to(DELIVERY)
assert not receipt.exists() and not receipt.is_symlink()
log = receipt.with_suffix('.log')
assert receipt != log and not log.exists() and not log.is_symlink()
index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
if not index_path.is_absolute():
    index_path = ROOT / index_path
index_bytes = index_path.read_bytes()

def snapshot():
    names = sorted(set(git('ls-files', '-z').decode().split('\0')) - {''})
    result = {}
    for name in sorted(set(names) | set(q['source_pins'])):
        path = ROOT / name
        if path.is_symlink():
            result[name] = {'kind': 'symlink', 'target': os.readlink(path), 'sha256': sha(path) if path.is_file() else None}
        elif path.is_file():
            result[name] = {'kind': 'file', 'sha256': sha(path)}
        else:
            result[name] = {'kind': 'missing_or_other'}
    return names, result

before_tracked, before = snapshot()
for name, expected in q['source_pins'].items():
    assert before[name]['sha256'] == expected, name
assert git('rev-parse', 'HEAD').decode().strip() == head
assert index_path.read_bytes() == index_bytes
command = ['python3', '/workspace/tooling/run-with-reaper.py', 'python3',
           '/workspace/tooling/run-with-gtk-namespace.py', 'python3',
           str(PACKET / 'run-private-wizard.py'), '--execute', '--checkout', str(ROOT)]
record = {'scope': 'genuine wizard five scenarios, raw Source/index/HEAD outer fence',
          'qualification': str(qualification), 'qualification_sha256': args.qualification_sha,
          'head': head, 'source_pins': before, 'tracked_paths': before_tracked,
          'explicit_selected_untracked_paths': sorted(set(q['source_pins']) - set(before_tracked)),
          'raw_index_sha256': hashlib.sha256(index_bytes).hexdigest(),
          'input_pins': inputs, 'command': command, 'runtime_status': 'UNRUN',
          'limitations': ['Browse UNRUN', 'physical input UNRUN', 'live engine reload UNRUN', 'installed restart UNRUN']}
primary = None
child_exit = None
reconciliation_errors = []
try:
    with log.open('xb') as output:
        child_exit = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT).returncode
    assert child_exit == 0, 'actual native controller refused; raw log preserved'
    summary = json.loads(log.read_bytes().splitlines()[-1])
    assert summary['status'] == 'PASS' and summary['primary_error'] is None
    native_receipt = Path(summary['receipt'])
    assert native_receipt.name == 'ACTUAL-RESULTS.json'
    assert native_receipt.parent.parent.resolve() == PACKET.resolve()
    assert native_receipt.parent.name.startswith('actual-wizard-')
    assert sha(native_receipt) == summary['receipt_sha256']
    actual = json.loads(native_receipt.read_text())
    modes = ['cancel', 'finish', 'reopen', 'locales', 'recommended']
    for key in ('planned_processes', 'attempted_processes', 'launched_processes', 'completed_processes', 'passed_processes'):
        assert actual[key] == modes, key
    assert actual['status'] == 'PASS' and actual['primary_error'] is None
    assert actual['cleanup_errors'] == [] and actual['qualification_errors'] == []
    assert actual['unexecuted_processes'] == [] and actual['uncompleted_processes'] == []
    assert actual['xvfb_session_disposed'] is True
    assert actual['final_source_reconciliation'] == {'status': 'MATCH', 'changed': []}
    assert [entry['mode'] for entry in actual['processes']] == modes
    for entry in actual['processes']:
        assert entry['status'] == 'PASS' and entry['exit'] == 0
        assert entry['launched'] is True and entry['completed'] is True and entry['timed_out'] is False
        assert entry['native_session_disposed'] is True
        observations = entry['native_receipt']['assertions']
        assert observations and all(observation['passed'] is True for observation in observations)
        assert entry['native_receipt']['cleanup']['manager_retired'] is True
    assert len(actual['independent_file_assertions']) >= 34
    assert all(observation['passed'] is True for observation in actual['independent_file_assertions'])
    record['native_receipt'] = str(native_receipt)
    record['native_receipt_sha256'] = sha(native_receipt)
    record['actual_native_counts'] = {entry['mode']: len(entry['native_receipt']['assertions']) for entry in actual['processes']}
    record['actual_independent_file_assertions'] = len(actual['independent_file_assertions'])
except BaseException as error:
    primary = {'type': type(error).__name__, 'error': str(error)}
finally:
    def observe(name, action):
        try:
            record[name] = action()
        except BaseException as error:
            record[name] = None
            reconciliation_errors.append({'stage': name, 'type': type(error).__name__, 'error': str(error)})
    observe('head_unchanged', lambda: git('rev-parse', 'HEAD').decode().strip() == head)
    observe('raw_index_unchanged', lambda: index_path.read_bytes() == index_bytes)
    def reconcile_sources():
        after_tracked, after = snapshot()
        record['tracked_membership_unchanged'] = before_tracked == after_tracked
        record['tracked_paths_after'] = after_tracked
        record['changed_paths'] = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
        return before_tracked == after_tracked and before == after
    observe('tracked_source_unchanged', reconcile_sources)
    observe('inputs_unchanged', lambda: all(sha(Path(name)) == expected for name, expected in inputs.items()))
    observe('log_sha256', lambda: sha(log))
    record.update(child_exit=child_exit, primary_failure=primary, reconciliation_errors=reconciliation_errors)
    record['runtime_status'] = 'PASS' if child_exit == 0 and primary is None and not reconciliation_errors and all(
        record.get(key) is True for key in ('head_unchanged', 'raw_index_unchanged', 'tracked_membership_unchanged', 'tracked_source_unchanged', 'inputs_unchanged')) else 'FAIL'
    try:
        with receipt.open('x') as output:
            json.dump(record, output, indent=2)
            output.write('\n')
    except BaseException as error:
        raise RuntimeError('Outer receipt write failed: ' + str(error) + '; preserved primary: ' + repr(primary) + '; reconciliation: ' + repr(reconciliation_errors)) from error
if record['runtime_status'] != 'PASS':
    raise SystemExit(1)
