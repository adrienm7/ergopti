// tools/test/test-windows-native-desktop.cjs

/** Requires the real desktop runner, its exact native receipts and mandatory CI evidence. */
'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const pipeline = require('./ci-pipeline.cjs');
const { stripComments } = require('../lib/script-source.cjs');

const root = path.resolve(__dirname, '../..');
const runner = fs.readFileSync(path.join(__dirname, 'run-windows-native-desktop.ps1'), 'utf8');
const expected = [
	'Console capture: real hidden Edit reads remain stale (native-console-capture)',
	'Console capture: public refresh exposes the real runtime (native-console-capture)',
	'Console capture: final-state restoration retains native disruption (native-console-capture)',
	'Console capture: KeyHistory capacity is not fresh capture (native-console-capture)',
	'Console capture: three native causal controls break independent proofs (native-console-capture)',
	'key combinations: standard AltGr suffix chooses its actual pair hold owner (todo91-altgr-suffix)',
	'key combinations: native AltGr prefix does not supply an admitted first key (todo91-altgr-suffix)',
	'key combinations: suppressed AltGr pair returns the fake Ctrl owner before action (todo91-altgr-suffix)',
	'key combinations: native AltGr pair retains and closes its Ctrl release debt (todo91-altgr-suffix)',
	'key combinations: custom AltGr variants are registered before the standalone owner (todo91-altgr-suffix)',
	'key combinations: interpreted native hook selects the earlier custom AltGr owner with bypass control (todo91-altgr-suffix)'
];

/** Preserve the reviewed canonical asynchronous native-handle and exact completion policy. */
function checkRunner(source) {
	source = source.replace(/^\s*#.*$/gm, '');
	assert.match(source, /if \(Test-Path -LiteralPath \$evidence\) \{ throw/);
	assert.match(source, /Start-Process -FilePath \$ahk/);
	assert.match(source, /\$null = \$proc\.Handle/);
	assert.match(source, /while \(-not \$proc\.HasExited\)/);
	assert.match(source, /\$proc\.WaitForExit\(\)/);
	assert.match(source, /\$record\.native_exit = \$proc\.ExitCode/);
	assert.match(source, /\$NativeExit -isnot \[int\]/);
	assert.match(source, /\$NativeExit -ne 0/);
	assert.match(source, /\$Stdout\) -cne \(& \$normalize \$Transcript\)/);
	assert.match(source, /IsNullOrWhiteSpace\(\$Stderr\)/);
	assert.match(source, /\$Manifest\.timed_count -ne \$count/);
	assert.match(source, /\$entry\.name -cne \$ExpectedNames\[\$index\]/);
	assert.match(source, /\$summary\.executed_cases -ne 11/);
	assert.match(source, /@\(\$summary\.runs\)\.Count -ne 2/);
	assert.match(source, /foreach \(\$cohort in \$cohorts\)/);
	assert.match(source, /--interactive --only \$\(\$cohort\.filter\)/);
	assert.match(source, /validate-ahk-suite-manifest\.cjs/);
	assert.match(source, /if \(\$LASTEXITCODE -ne 0\) \{ throw/);
	assert.match(source, /\$env:ERGOPTI_AHK_RESULTS_FILE = \$previousReceipt/);
	assert.match(source, /\$summary\.status = 'failed'/);
	assert.doesNotMatch(source, /--only[^\r\n]*native-console-capture\|todo91-altgr-suffix/);
	for (const name of expected) assert.equal(source.split("'" + name + "'").length, 2);
	assert.match(source, /windows\\tests\\run_native_desktop\.ahk/);
}

/** The unqualified ordinary main suite cannot stand in for interactive desktop observations. */
function checkWorkflow(body) {
	const main = pipeline.step(body, 'Run AHK test suite');
	const native = pipeline.step(body, 'Run native desktop AHK cohorts');
	const upload = pipeline.step(body, 'Publish native desktop AHK evidence');
	assert.equal(pipeline.stepField(native, 'run'), './tools/test/run-windows-native-desktop.ps1');
	assert.equal(pipeline.stepField(native, 'shell'), 'pwsh');
	assert.equal(pipeline.stepField(native, 'timeout-minutes'), '25');
	assert.equal(pipeline.stepField(native, 'if'), null);
	assert.equal(pipeline.stepField(native, 'continue-on-error'), null);
	assert.ok(body.indexOf(main) < body.indexOf(native));
	assert.ok(body.indexOf(native) < body.indexOf(upload));
	assert.equal(pipeline.stepField(upload, 'if'), 'always()');
	assert.equal(pipeline.stepField(upload, 'uses'), 'actions/upload-artifact@v4');
	assert.equal(pipeline.stepField(upload, 'continue-on-error'), null);
	assert.match(upload, /name: windows-ahk-native-desktop\n/);
	assert.match(upload, /path: \$\{\{ runner\.temp \}\}\/windows-ahk-native-desktop\/\n/);
	assert.match(upload, /if-no-files-found: error/);
	assert.match(upload, /overwrite: true/);
}

const {
	runnerPrelude,
	sharedRunnerSource,
	nativeSourceClosure,
	runnerFunctionTokens
} = require('../lib/ahk-runner-source.cjs');
const readRunnerImage = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const nativeTests = 'static/ergopti_plus/windows/tests/';
const nativeIncludes = [
	'runner_prelude.ahk',
	'../infra/tick_count.ahk',
	'../ui/console_window.ahk',
	'../infra/logger.ahk',
	'runner_log_directories.ahk',
	'../infra/toml/toml_helpers.ahk',
	'../infra/key_combinations.ahk',
	'../infra/toml/toml_loader.ahk',
	'../platform/remap/tap_hold_loader.ahk',
	'../platform/remap/tap_hold_writer.ahk',
	'../infra/json.ahk',
	'../adapters/text_sender.ahk',
	'../adapters/key_state.ahk',
	'../adapters/shell_runner.ahk',
	'unit/test_console_window.ahk',
	'unit/test_key_combinations.ahk',
	'../platform/remap/constants.ahk',
	'../platform/remap/altgr_criteria.ahk',
	'runner_completion.ahk'
];

const nativeLocalOwners = [
	['infra/toml/toml_document.ahk', '_TOML_DocumentToken', 'Run', 'TomlQuoteRunLength'],
	['infra/key_combinations.ahk', '_KeyCombinationRunTap', 'Run', 'KeyCombinationTapAction'],
	['adapters/text_sender.ahk', '_TextSenderKeystroke', 'Mod', 'TextSenderModifier'],
	['platform/remap/constants.ahk', '_TapHoldKeyTapModifiers', 'Mod', 'TapHoldTapModifier'],
	[
		'adapters/editor_replace.ahk',
		'_TextSenderNativePollReceipt',
		'OsError',
		'TextSenderNativeErrorCode'
	],
	[
		'tests/unit/test_key_combinations.ahk',
		'_KCT_SlotsAreWrittenToTheConfiguration',
		'Reload',
		'SavedReloadCalls'
	]
];

/** Keep real built-in exports intact while their original local consumers use distinct names. */
function checkNativeLocalNamespaces(read) {
	for (const [file, owner, original, local] of nativeLocalOwners) {
		const tokens = runnerFunctionTokens(read('static/ergopti_plus/windows/' + file), owner);
		assert.ok(tokens.some((t) => t.kind === 'identifier' && t.value === local));
		assert.ok(
			!tokens.some(
				(t) => t.kind === 'identifier' && t.value.toLowerCase() === original.toLowerCase()
			)
		);
	}
	const cases = read(nativeTests + 'unit/test_key_combinations.ahk');
	assert.doesNotMatch(stripComments(cases, '.ahk'), /^for Assigned\b/m);
	const registration = runnerFunctionTokens(cases, '_KCT_RegisterPairClearAvailabilityCases');
	assert.ok(registration.some((t) => t.value === 'Assigned'));
	assert.match(stripComments(cases, '.ahk'), /^_KCT_RegisterPairClearAvailabilityCases\(\)$/m);
}

/** The sparse entry retains genuine sources and every original shared admission/terminal owner. */
function checkNativeSources(read) {
	const prelude = runnerPrelude(read, 'run_native_desktop.ahk');
	assert.equal(prelude, runnerPrelude(read, 'run_all.ahk'));
	const code = stripComments(prelude, '.ahk');
	assert.match(code, /^#Requires Autohotkey v2\.0\+$/m);
	assert.equal((code.match(/^#Warn All, StdOut$/gm) || []).length, 1);
	assert.equal((code.match(/^#Warn VarUnset, Off$/gm) || []).length, 1);
	assert.match(code, /^SetWorkingDir\(A_ScriptDir\)$/m);
	assert.match(code, /^_riArgIndex := 1$/m);
	assert.match(code, /^global _AHK_DRY_RUN := false$/m);
	assert.match(code, /^global _AHK_ONLY_FILTER := ""$/m);
	assert.match(code, /^global _AHK_INTERACTIVE := false$/m);
	assert.ok(code.indexOf('_riArgIndex := 1') < code.indexOf('#Include test_framework.ahk'));
	assert.ok(code.indexOf('#Include test_framework.ahk') < code.indexOf('_TestResultsBeginRun()'));
	assert.ok(
		code.indexOf('_TestResultsBeginRun()') < code.indexOf('#Include ../infra/app_state.ahk')
	);
	assert.equal((code.match(/^_TestResultsBeginRun\(\)$/gm) || []).length, 1);
	assert.match(code, /^OnError\(_FatalErrorHandler\)$/m);
	const native = stripComments(read(nativeTests + 'run_native_desktop.ahk'), '.ahk');
	assert.deepEqual(
		[...native.matchAll(/^#Include (.+)$/gm)].map((m) => m[1]),
		nativeIncludes
	);
	assert.equal((native.match(/^InstallSendNoOps\(\)$/gm) || []).length, 1);
	assert.ok(
		native.indexOf('#Include ../adapters/text_sender.ahk') < native.indexOf('InstallSendNoOps()')
	);
	assert.ok(
		native.indexOf('InstallSendNoOps()') < native.indexOf('#Include unit/test_console_window.ahk')
	);
	assert.equal((native.match(/^TestQualificationRegisterParser\(JsonParse\)$/gm) || []).length, 1);
	assert.ok(
		native.indexOf('#Include ../infra/json.ahk') <
			native.indexOf('TestQualificationRegisterParser(JsonParse)')
	);
	assert.doesNotMatch(
		native,
		/^(?!#Include\b)[ \t]*(?:Test\(|#Warn|#Requires|#SingleInstance|SetWorkingDir\(|global\b|RunTests\()/m
	);
	const complete = stripComments(read(nativeTests + 'runner_completion.ahk'), '.ahk');
	assert.match(complete, /^global _SUITE_STARTUP_BUDGET_MS := 120000$/m);
	assert.match(complete, /^global _SUITE_PER_TEST_BUDGET_MS := 200$/m);
	assert.match(complete, /^global _SUITE_MAX_TIMEOUT_MS := 1320000$/m);
	assert.match(
		complete,
		/^global _SUITE_TIMEOUT_MS := _SuiteTimeoutForCount\(TEST_REGISTRY\.Length\)$/m
	);
	assert.match(
		complete,
		/_WatchdogFire\(\) \{[\s\S]*?_CopyTestResultsForCi\(\)[\s\S]*?ExitApp\(2\)/
	);
	assert.match(complete, /^SetTimer\(_WatchdogFire, -_SUITE_TIMEOUT_MS\)$/m);
	assert.equal((complete.match(/^RunTests\(\)$/gm) || []).length, 1);
	assert.ok(complete.indexOf('SetTimer(_WatchdogFire') < complete.indexOf('\nRunTests()'));
	const logs = stripComments(read(nativeTests + 'runner_log_directories.ahk'), '.ahk').trim();
	assert.equal(
		logs,
		'global _LogsDir := A_Temp . "\\ergopti_test_logs\\ergopti_plus\\"\nglobal _DefaultLogsDir := _LogsDir'
	);
	for (const entry of ['run_all.ahk', 'run_native_desktop.ahk']) {
		const expanded = stripComments(sharedRunnerSource(read, entry), '.ahk');
		assert.equal((expanded.match(/^#Warn All, StdOut$/gm) || []).length, 1);
		assert.doesNotMatch(
			expanded,
			/^#Warn\s+(?:All|LocalSameAsGlobal),\s*(?:Off|MsgBox|OutputDebug)$/im
		);
	}
	const graph = nativeSourceClosure(read);
	assert.equal(
		graph.size,
		32,
		'the native runner owns only its reviewed authored dependency graph'
	);
	for (const file of ['unit/test_console_window.ahk', 'unit/test_key_combinations.ahk'])
		assert.ok(graph.has(nativeTests + file), 'each exact original case file must be compiled');
	for (const image of graph.values())
		assert.doesNotMatch(
			stripComments(image, '.ahk'),
			/^\s*#Warn\s+(?:All|LocalSameAsGlobal),\s*(?:Off|MsgBox|OutputDebug)$/im
		);
	assert.ok(graph.has('static/ergopti_plus/windows/adapters/editor_replace.ahk'));
	assert.ok(graph.has('static/ergopti_plus/windows/infra/toml/toml_document.ahk'));
	checkNativeLocalNamespaces(read);
}

checkNativeSources(readRunnerImage);
let nativeSourceRefusals = 0;
for (const [file, before, after] of [
	['run_native_desktop.ahk', '#Include runner_prelude.ahk', '#Include unrelated_prelude.ahk'],
	[
		'run_native_desktop.ahk',
		'#Include runner_prelude.ahk',
		'SetWorkingDir(A_Temp)\n#Include runner_prelude.ahk'
	],
	[
		'run_all.ahk',
		'#Include runner_prelude.ahk',
		'#Include runner_prelude.ahk\n#Include runner_prelude.ahk'
	],
	['runner_prelude.ahk', '#Warn All, StdOut', '#Warn All, Off'],
	['runner_prelude.ahk', '_riArgIndex := 1', ''],
	['runner_prelude.ahk', 'global _AHK_ONLY_FILTER := ""', ''],
	['runner_prelude.ahk', '_TestResultsBeginRun()\n', ''],
	[
		'run_native_desktop.ahk',
		'#Include unit/test_console_window.ahk',
		'#Include unit/test_key_combinations.ahk'
	],
	['run_native_desktop.ahk', 'InstallSendNoOps()', ''],
	['run_native_desktop.ahk', 'TestQualificationRegisterParser(JsonParse)', ''],
	['runner_completion.ahk', '_CopyTestResultsForCi()', '_SuiteTimeoutForCount(0)'],
	['runner_completion.ahk', 'ExitApp(2)', 'ExitApp(0)'],
	['runner_completion.ahk', 'RunTests()', ''],
	['runner_completion.ahk', '1320000', '1500000'],
	['runner_log_directories.ahk', 'A_Temp', 'A_ScriptDir'],
	['run_native_desktop.ahk', '#Include runner_completion.ahk', '#Include missing_completion.ahk']
]) {
	const full = nativeTests + file;
	const original = readRunnerImage(full);
	const at = stripComments(original, '.ahk').indexOf(before);
	assert.ok(at >= 0, 'the mutation must bind real source code: ' + file + ' ' + before);
	const changed = original.slice(0, at) + after + original.slice(at + before.length);
	assert.notEqual(changed, original, 'the source mutation must change its actual owner');
	assert.throws(() =>
		checkNativeSources((target) => (target === full ? changed : readRunnerImage(target)))
	);
	nativeSourceRefusals += 1;
}
for (const file of [
	'runner_prelude.ahk',
	'runner_completion.ahk',
	'runner_log_directories.ahk',
	'../adapters/console_window.ahk'
]) {
	const full = path.posix.normalize(nativeTests + file);
	assert.throws(
		() =>
			checkNativeSources((target) => {
				if (target === full) throw new Error('independently omitted native source');
				return readRunnerImage(target);
			}),
		/unresolved|omitted/
	);
	nativeSourceRefusals += 1;
}
for (const [file, owner, original, local] of nativeLocalOwners) {
	const full = 'static/ergopti_plus/windows/' + file;
	const source = readRunnerImage(full);
	const ownerTokens = runnerFunctionTokens(source, owner);
	const token = ownerTokens.find((t) => t.kind === 'identifier' && t.value === local);
	assert.ok(token);
	const changed = source.slice(0, token.start) + original + source.slice(token.end);
	assert.throws(() =>
		checkNativeSources((target) => (target === full ? changed : readRunnerImage(target)))
	);
	nativeSourceRefusals += 1;
}
const registrationOwner = nativeTests + 'unit/test_key_combinations.ahk';
const registeredSource = readRunnerImage(registrationOwner);
const pollutedRegistration = registeredSource + '\nfor Assigned in [false, true]\n\tSleep(0)\n';
assert.throws(() =>
	checkNativeSources((target) =>
		target === registrationOwner ? pollutedRegistration : readRunnerImage(target)
	)
);
nativeSourceRefusals += 1;
for (const directive of ['#Warn All, Off', '#Warn LocalSameAsGlobal, Off']) {
	const leaf = 'static/ergopti_plus/windows/adapters/console_window.ahk';
	const altered = readRunnerImage(leaf) + '\n' + directive + '\n';
	assert.throws(() =>
		checkNativeSources((target) => (target === leaf ? altered : readRunnerImage(target)))
	);
	nativeSourceRefusals += 1;
}
console.log(
	`Native runner source ownership PASS: ${nativeSourceRefusals} independent source refusals; native execution remains unrun here.`
);

checkRunner(runner);
const body = pipeline.job('test-ahk');
checkWorkflow(body);
const registrations = ['unit/test_console_window.ahk', 'unit/test_key_combinations.ahk'].map(
	(file) =>
		stripComments(
			fs.readFileSync(path.join(root, 'static/ergopti_plus/windows/tests', file), 'utf8'),
			'.ahk'
		)
);
for (const name of expected) {
	assert.equal(registrations.join('\n').split('Test("' + name + '",').length, 2);
}
// The source registrations explicitly isolate the six true desktop cases.
assert.equal(
	(registrations[0].match(/native-console-capture\)",\s*[A-Za-z_][A-Za-z_0-9]*, true\)/g) || [])
		.length,
	5
);
assert.equal(
	(registrations[1].match(/todo91-altgr-suffix\)",\s*[A-Za-z_][A-Za-z_0-9]*, true\)/g) || [])
		.length,
	1
);
let refused = 0;
for (const [before, after] of [
	['$null = $proc.Handle', '$null = $null'],
	['$proc.WaitForExit()', '$null = $proc'],
	['$NativeExit -isnot [int]', '$false'],
	['$NativeExit -ne 0', '$false'],
	['$Manifest.timed_count -ne $count', '$false'],
	['$entry.name -cne $ExpectedNames[$index]', '$false'],
	['$summary.executed_cases -ne 11', '$summary.executed_cases -ne 0'],
	['--interactive --only $($cohort.filter)', '--only $($cohort.filter)']
]) {
	const changed = runner.replace(before, after);
	assert.notEqual(changed, runner);
	assert.throws(() => checkRunner(changed));
	refused += 1;
}
for (const [before, after] of [
	['run: ./tools/test/run-windows-native-desktop.ps1', 'run: echo skipped'],
	[
		'run: ./tools/test/run-windows-native-desktop.ps1',
		'if: false\n        run: ./tools/test/run-windows-native-desktop.ps1'
	],
	[
		'run: ./tools/test/run-windows-native-desktop.ps1',
		'continue-on-error: true\n        run: ./tools/test/run-windows-native-desktop.ps1'
	],
	[
		'name: Publish native desktop AHK evidence\n        if: always()',
		'name: Publish native desktop AHK evidence\n        if: success()'
	],
	['path: ${{ runner.temp }}/windows-ahk-native-desktop/', 'path: unrelated/'],
	['if-no-files-found: error', 'if-no-files-found: warn']
]) {
	// Bind every mutation to its own step; earlier diagnostics share upload fields.
	const target = pipeline.step(
		body,
		before.startsWith('run:')
			? 'Run native desktop AHK cohorts'
			: 'Publish native desktop AHK evidence'
	);
	const changedTarget = target.replace(before, after);
	assert.notEqual(changedTarget, target, 'the mutation must alter the native desktop step');
	const changed = body.replace(target, changedTarget);
	assert.notEqual(changed, body);
	assert.throws(() => checkWorkflow(changed));
	refused += 1;
}
// PowerShell's actual AST and guard are exercised on Windows. These handwritten
// portable inputs are not native desktop observations or qualification artifacts.
if (process.platform === 'win32') {
	const result = spawnSync(
		'pwsh.exe',
		[
			'-NoProfile',
			'-NonInteractive',
			'-File',
			path.join(__dirname, 'windows-native-desktop-controls.ps1')
		],
		{ encoding: 'utf8', timeout: 30000 }
	);
	assert.equal(result.error, undefined);
	assert.equal(result.status, 0, result.stdout + result.stderr);
	assert.match(result.stdout, /17 refusals, causal native-exit mutation exposed and restored/);
} else {
	console.log(
		'[SKIP] Windows PowerShell guard execution; workflow and source contracts were checked.'
	);
}
console.log(
	`Windows native desktop wiring PASS: eleven authored cases, six interactive registrations, ${refused} causal source/workflow refusals. Native desktop execution is not claimed.`
);
