# Final CI40727519951 evidence

All times are Paris (UTC+01:00). [Run40727519951](https://github.com/adrienm7/ergopti/actions/runs/40727519951), attempt1, exact source `c80cf8dddb3e04df4849ac501cec1ca92b9e1c71`, concludes **FAILURE**. Started **17:35:49**, last job completed **18:42:48**, final run API update **18:42:49**, observed completed **18:43:15**.

Full actual graph: **44 jobs = 28 success + 5 failure + 9 skipped + 2 cancelled**. Public REST `per_page=100` contains every job; no first-page census limit remains. Final receipt: `/workspace/scratch/oct28-ci-final30/final-receipt.json`, SHA256 `43d0e16e3898f44e69a619554fc372906501de19eebc29ec43c47b92ed693d04`. Full source/run/jobs, steps, timestamps and evidence hashes are retained.

## Actual native successes

- macOS26 default full Swift target: **674 unique passed cases, zero failures/unexpected**, qualification profile inactive. All-tests pass at **18:27:48**. Both formerly failing App Cloner result-delivery methods pass at **18:26:03** and **18:26:04**; all seven App Cloner ownership methods pass. Every executed tail/diagnostic/cleanup step succeeds. `native26-evidence.json`; full log SHA256 `1e0561704252d81746e0a1cbb4e1123f5fdc0bb432dbd9a9a5cef7bd051d1448`.
- Intel selected native cohorts: **172 passed, zero failures**. This is selected Intel coverage, not another full674 target. `native-intel-evidence.json`.
- Actual Hammerspoon Tooltip: **12 painted production captures**, zero production errors, owner group retired. Entire job including tails succeeds. `tooltip-native-evidence.json`. Physical input/TCC/packaged installation remain outside this observation.
- c80 Lua suite: **25,375 passed / zero failed / 2,038 modules**, plus virtual-keyboard E2E **185/185** and one historical explicit driver-specific NA. `lua-executed-counts.json`.

These receipts qualify **c80 only**. Later local Lua callback, MLX and source-oracle changes are not rebound to this tree.

## Failures and unavailable qualification

1. **Common data/source direct failure:** five gesture `recommended_info` labels copy English without permitted duplicate registration, and Windows gesture configuration literal count8 exceeds baseline7. Exact affected source blobs equal incoming dev f4e. Both lie in user-excluded gesture/Windows zones; no baseline was raised or test disabled. `common-data-source-failure-evidence.json`, `protected-upstream-source-pins.json`.
2. **ARM infrastructure cancellation:** native managed Ollama build job `122969814718` cancels at **18:34:21**, ARM lease job `122969814879` at **18:36:03**, each `runner_id=0`, no runner name and zero steps. Both check-run annotations explicitly state **“The job was not acquired by Runner of type hosted even after multiple attempts”**, with three macOS arm64 capacity notices. No observer/Root cancellation was issued. `cancelled-arm-build-annotations.json`, `cancelled-arm-lease-annotations.json`.
3. **ARM receiving consequence:** job `122969814532` fails closed at **18:34:32**: **“The managed Ollama build cell concluded cancelled”**. Native producer plus final model create/pull/inference receiving and ARM lease silence remain unqualified, not product regressions inferred from a missing producer. `managed-arm-infrastructure-evidence.json` and receiver log.
4. **Three downstream verdict failures:** Common cannot receive its stable browser proof after prior skips; macOS rejects skipped install predecessor; release rejects required `core` failure (its macOS lane input is `abandoned`). All exact failed-step logs are retained. These are not three additional independent bugs.

Nine whole-job skips are two unselected OS lanes, four later Common stages, macOS Build and Install/launch, and Publish. Ordinary role-specific skipped steps inside successful jobs are not counted as quarantined tests.

The former run407148 Tooltip cancellation is now attributed by later check-run annotation evidence to the same hosted runner acquisition/capacity refusal (`historical-tooltip-407148-annotations.json`). The earlier unknown-cause statement is superseded by that specific evidence. Current run407275 Tooltip actually executed successfully.

## Observer scope

Only normal public REST/connected GitHub GETs and local scratch evidence writes occurred. No rerun, workflow dispatch, cancellation, source/index edit, baseline change or credential modification. `gh` stale auth is bypassed by the supported inherited-proxy REST path without manually supplied credentials; Root separately confirms configured identity via `/user` and owns eventual publication/dispatch. No credential values were printed.
