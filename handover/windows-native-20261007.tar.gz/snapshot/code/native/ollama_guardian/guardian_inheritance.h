/* Source-channel inheritance owns no handles: its enclosing GSC owner retains
   every original until this lease acknowledges all native flag resets. */
#ifndef ERGOPTI_GUARDIAN_INHERITANCE_H
#define ERGOPTI_GUARDIAN_INHERITANCE_H
#include <stdint.h>
#include <stddef.h>

typedef struct {
    void *context;
    int (*get)(void *,uintptr_t,uint32_t *,uint32_t *);
    int (*set)(void *,uintptr_t,uint32_t,uint32_t *);
} GIL_Ports;
typedef struct {
    uint64_t token;
    uintptr_t handles[4];
    uint32_t pending,active,used,first_error;
    GIL_Ports ports;
} GIL_Owner;

/* Caller serializes operations and retains the four exact native capabilities.
   Begin burns one server token even on refusal; failed effects remain pending.
   Release retries only unacknowledged resets, never an acknowledged setter. */
int GIL_Begin(GIL_Owner *,uint64_t,const uintptr_t[4],const GIL_Ports *);
int GIL_Release(GIL_Owner *,uint64_t);
int GIL_CanRetire(const GIL_Owner *);
#endif
