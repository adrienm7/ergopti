#include "guardian_retirement.h"

int GFR_Init(GFR_Owner *owner, GFR_Port port) {
    if (owner == 0 || owner->initialized || port.host_terminal == 0 ||
        port.job_empty == 0 || port.release_copies == 0) return 0;
    owner->initialized = 1u;
    owner->port = port;
    return 1;
}

int GFR_Poll(GFR_Owner *owner) {
    int result;
    if (owner == 0 || !owner->initialized || owner->uncertain) return -1;
    if (owner->retired) return 1;
    result = owner->host_done ? 1 : owner->port.host_terminal(owner->port.context);
    if (result != 1) {
        if (result < 0 && !owner->first_error) owner->first_error = 1u;
        return result < 0 ? -1 : 0;
    }
    owner->host_done = 1u;
    result = owner->job_done ? 1 : owner->port.job_empty(owner->port.context);
    if (result != 1) {
        if (result < 0 && !owner->first_error) owner->first_error = 2u;
        return result < 0 ? -1 : 0;
    }
    owner->job_done = 1u;
    result = owner->port.release_copies(owner->port.context);
    if (result < 0) {
        if (!owner->first_error) owner->first_error = 3u;
        owner->uncertain = 1u;
        return -1;
    }
    if (result != 1) return 0;
    owner->retired = 1u;
    return 1;
}
