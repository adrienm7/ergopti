﻿; tests/unit/test_ollama_managed_coordinator.ahk

; ==============================================================================
; MODULE: Managed Coordination Source/Receipt Recording Controls
; DESCRIPTION:
; Tests the real selection, pin projection and receipt branch with source models.
; These models grant no native guardian, server, archive or HTTP evidence.
; ==============================================================================

_OMC_Snapshot() {
	local bytes := Buffer(3, 0)
	NumPut("UChar", 1, bytes, 0)
	return Map("backend", "ollama", "model", "gemma3:4b", "origin", "http://localhost:11434",
		"generation", 7, "enabled", false, "paused", false, "blocked", false,
		"source", Map("path", "C:\synthetic\config.toml", "bytes", bytes))
}

_OMC_AllSelectionChangesRefuse() {
	local captured := _OMC_Snapshot()
	AssertTrue(OllamaManagedSelectionCurrent(captured, _OMC_Snapshot()))
	for field in ["backend", "model", "origin", "generation", "enabled", "paused", "blocked"] {
		local live := _OMC_Snapshot()
		if live[field] is String
			live[field] := "different"
		else
			live[field] := field == "generation" ? 8 : !live[field]
		AssertFalse(OllamaManagedSelectionCurrent(captured, live), "Changed " . field . " refuses.")
	}
	local changed := _OMC_Snapshot()
	NumPut("UChar", 2, changed["source"]["bytes"], 1)
	AssertFalse(OllamaManagedSelectionCurrent(captured, changed))
}

_OMC_SnapshotOwnsIndependentBytes() {
	local original := _OMC_Snapshot(), captured := OllamaManagedCopySnapshot(original)
	NumPut("UChar", 99, original["source"]["bytes"], 0)
	AssertEqual(NumGet(captured["source"]["bytes"], 0, "UChar"), 1)
	AssertFalse(OllamaManagedSelectionCurrent(captured, original))
}

_OMC_NineFilesEightNativePins() {
	local pins := Map()
	for name in ["NativeModule", "Guardian", "ManagedBridge", "FilesHelper", "PublicationHelper",
		"ProducerHelper", "SourceWorker", "Launcher", "InstallWorker"]
		pins[name] := Map("path", "C:\synthetic\" . name, "bytes", 1, "sha256", "control")
	local projected := OllamaManagedPinProjection(pins)
	AssertEqual(projected["files"].Count, 9)
	AssertEqual(projected["native"].Count, 8)
	AssertTrue(projected["files"].Has("InstallWorker"))
	AssertFalse(projected["native"].Has("InstallWorker"))
	for name, pin in projected["native"]
		AssertTrue(projected["files"].Has(name))
	pins["Guardian"]["path"] := "changed"
	AssertEqual(projected["native"]["Guardian"]["path"], "C:\synthetic\Guardian")
}

class _OMC_ReceiptModel extends OllamaManagedCoordinator {
	__New() {
		this.Options := Map("on_ready", ObjBindMethod(this, "Ready"))
		this.Generation := 1
		this.FirstError := ""
		this.Current := true
		this.Done := 0
		this.Queries := []
		this.Pulls := 0
		this.Http := {HasOwner: (*) => false}
		this.Record := Map("generation", 1, "cancelled", false, "phase", "http-version",
			"captured", _OMC_Snapshot(), "asset", Map("version", "0.24.0"), "delivered", false,
			"first_error", "", "model_attempted", false)
	}
	_HttpCurrent(Record) {
		return this._Owns(Record) && this.Current && !Record["cancelled"]
	}
	_Query(Record, Kind) {
		this.Queries.Push(Kind)
		Record["phase"] := "http-" . Kind
		return true
	}
	_PullModel(Record) {
		this.Pulls += 1
		return false
	}
	Ready(Receipt) {
		AssertEqual(Receipt["origin"], "http://localhost:11434")
		AssertEqual(Receipt["model"], "gemma3:4b")
		AssertFalse(Receipt.Has("enabled"), "Receipt data cannot activate AI.")
		this.Done += 1
	}
	Feed(Kind, Body, Origin := "http://localhost:11434") {
		return this._Receipt(this.Record, Map("ok", true, "status", 200,
			"origin", Origin, "kind", Kind, "body", Body))
	}
}

_OMC_VersionThenTagsRealParsers() {
	local owner := _OMC_ReceiptModel()
	owner.Feed("version", '{"version":"0.24.0"}')
	AssertEqual(owner.Done, 0)
	AssertEqual(owner.Queries.Length, 1)
	AssertEqual(owner.Queries[1], "tags")
	owner.Feed("tags", '{"models":[{"name":"gemma3:4b"}]}')
	AssertEqual(owner.Done, 1)
	AssertEqual(owner.Pulls, 0)
	AssertFalse(owner.Record["captured"]["enabled"])
}

_OMC_ForeignOriginAndVersionRefuse() {
	local owner := _OMC_ReceiptModel()
	owner.Feed("version", '{"version":"0.24.0"}', "http://localhost:9999")
	AssertTrue(owner.Record["cancelled"])
	AssertEqual(owner.Queries.Length, 0)
	AssertEqual(owner.Done, 0)
	owner := _OMC_ReceiptModel()
	owner.Feed("version", '{"version":"different"}')
	AssertTrue(owner.Record["cancelled"])
	AssertEqual(owner.Queries.Length, 0)
}

_OMC_MalformedTagsCannotBecomeMissingModel() {
	local owner := _OMC_ReceiptModel()
	owner.Record["phase"] := "http-tags"
	owner.Feed("tags", '{"models":{}}')
	AssertEqual(owner.Pulls, 0)
	AssertEqual(owner.Done, 0)
	AssertTrue(owner.Record["cancelled"])
}

_OMC_LateReceiptCannotPublish() {
	local owner := _OMC_ReceiptModel()
	owner.Current := false
	owner.Feed("version", '{"version":"0.24.0"}')
	AssertEqual(owner.Done, 0)
	AssertEqual(owner.Queries.Length, 0)
	AssertTrue(owner.Record["cancelled"])
}

Test("ollama-managed-selection-all-fences", _OMC_AllSelectionChangesRefuse)
Test("ollama-managed-source-independent-bytes", _OMC_SnapshotOwnsIndependentBytes)
Test("ollama-managed-nine-files-eight-native", _OMC_NineFilesEightNativePins)
Test("ollama-managed-real-version-tags-parsers", _OMC_VersionThenTagsRealParsers)
Test("ollama-managed-foreign-origin-version-refusal", _OMC_ForeignOriginAndVersionRefuse)
Test("ollama-managed-malformed-tags-no-install", _OMC_MalformedTagsCannotBecomeMissingModel)
Test("ollama-managed-late-receipt-no-publication", _OMC_LateReceiptCannotPublish)

class _OMC_Files extends OllamaManagedFilesDefault {
	__New(World) {
		this.World := World
		this.Pins := Map()
		for name in ["NativeModule", "Guardian", "ManagedBridge", "FilesHelper", "PublicationHelper",
			"ProducerHelper", "SourceWorker", "Launcher", "InstallWorker"]
			this.Pins[name] := Map("path", "C:\synthetic\" . name, "bytes", 1, "sha256", "control")
	}
	HasOwner() {
		return false
	}
	HasFileDebt() {
		return this.World.FileDebt
	}
}

class _OMC_Actor extends OllamaGuardianTask {
	__New(World) {
		this.Id := 9
		this.Cancelled := false
		this.IsRetired := false
		this.ActivationAttempted := true
		this.Native := {Poll: (*) => World.Status.Clone()}
	}
}

class _OMC_Runtime extends OllamaRuntimeOwner {
	__New(World) {
		this.World := World
		this.Record := Map("guardian", _OMC_Actor(World))
	}
}

class _OMC_Session extends OllamaUserLocalSession {
	__New(World, Current, Consent, Timer) {
		this.World := World
		this.CurrentFn := Current
		this.ConsentFn := Consent
		this.Record := 0
		this.Busy := false
		this.TimerFn := Timer
		this.Timer := (*) => false
		this.Runtime := {Owner: _OMC_Runtime(World), HasOwner: (*) => World.RuntimeOwned}
	}
	Start(Plan) {
		AssertTrue(this.ConsentFn.Call(Plan["prepare"], Plan["target"]))
		AssertTrue(this.CurrentFn.Call(Plan["prepare"], Plan["target"]))
		this.World.Starts += 1
		this.World.RuntimeOwned := true
		this.Record := Map("cancelled", false)
		this.TimerFn.Call(this.Timer, -5)
		return true
	}
	Stop() {
		this.World.Stops += 1
		if this.World.AllowStop {
			this.World.RuntimeOwned := false
			if this.Record is Map {
				this.Record := 0
				this.TimerFn.Call(this.Timer, 0)
			}
		}
		return !this.World.RuntimeOwned
	}
}

class _OMC_World {
	__New() {
		this.Now := 10
		this.Live := _OMC_Snapshot()
		this.FileDebt := false
		this.RuntimeOwned := false
		this.AllowStop := false
		this.TimerStop := true
		this.Ready := 0
		this.Failed := 0
		this.Starts := 0
		this.Stops := 0
		this.Reenter := false
		this.NestedAccepted := -1
		this.Consent := true
		this.Status := Map("id", 9, "phase", 4, "error", 0, "activation_claimed", 1)
		this.Files := _OMC_Files(this)
		this.Plan := Map("version", "0.24.0", "prepare", Map("ManagedRoot", "C:\synthetic\managed",
			"CataloguePath", "C:\synthetic\catalogue.json", "CatalogueSha256", "control",
			"AssetId", "ollama-windows-amd64.zip", "ArchivePath", "C:\synthetic\archive.zip",
			"TicketId", "1234567890abcdef1234567890abcdef", "MaxExpandedBytes", 123, "MaxEntries", 7),
			"target", Map("models_dir", "C:\synthetic\models", "origin", "http://127.0.0.1:11434", "port", 11434))
		local options := Map("workflow_ms", 100, "poll_ms", 5, "snapshot", (*) => this.Live,
			"release", (*) => Map("version", "0.24.0", "asset_id", "ollama-windows-amd64.zip"),
			"consent", (*) => this.Consent, "model_consent", (*) => false,
			"on_ready", (*) => this.Ready += 1, "on_failed", (*) => this.Failed += 1,
			"session_factory", ObjBindMethod(this, "Factory"), "timer", ObjBindMethod(this, "Timer"),
			"clock", ObjBindMethod(this, "Clock"))
		this.Owner := OllamaManagedCoordinator(this.Files, Map("native_pins", this.Files.Pins,
			"launcher", this.Files.Pins["Launcher"]["path"]), options)
	}
	Factory(Files, RuntimeOptions, Current, Consent, Dispatched, PollMs, Timer) {
		AssertEqual(RuntimeOptions["native_pins"].Count, 8)
		AssertFalse(RuntimeOptions["native_pins"].Has("InstallWorker"))
		return _OMC_Session(this, Current, Consent, Timer)
	}
	Clock() {
		if this.Reenter {
			this.Reenter := false
			this.NestedAccepted := this.Owner.Start(this.Plan)
		}
		return this.Now
	}
	Timer(Callback, Period) {
		return Period != 0 || this.TimerStop
	}
	Drain() {
		this.AllowStop := true
		this.TimerStop := true
		this.Owner.Stop()
		AssertFalse(this.Owner.HasNativeOwner())
		AssertFalse(this.Owner.Record is Map)
	}
}

_OMC_StartReservesBeforeReentrantClock() {
	local world := _OMC_World()
	try {
		world.Reenter := true
		AssertTrue(world.Owner.Start(world.Plan))
		AssertFalse(world.NestedAccepted)
		AssertEqual(world.Starts, 1)
	} finally world.Drain()
}

_OMC_ConsentRefusalHasNoNativeDispatch() {
	local world := _OMC_World()
	try {
		world.Consent := false
		AssertFalse(world.Owner.Start(world.Plan))
		AssertEqual(world.Starts, 0)
		AssertEqual(world.Ready, 0)
		AssertEqual(world.Failed, 1)
		AssertFalse(world.Owner.Record is Map)
	} finally world.Drain()
}

_OMC_CancelRetainsExactRuntimeAndTimerDebt() {
	local world := _OMC_World()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record
		AssertFalse(world.Owner.Stop())
		AssertTrue(world.Owner.Record == record)
		AssertTrue(world.RuntimeOwned)
		AssertEqual(world.Failed, 0)
		AssertFalse(world.Owner.Start(world.Plan))
		world.AllowStop := true
		world.TimerStop := false
		AssertFalse(world.Owner.Stop())
		AssertTrue(world.Owner.Record == record)
		AssertFalse(world.RuntimeOwned)
		AssertEqual(world.Failed, 0)
		world.TimerStop := true
		AssertTrue(world.Owner.Stop())
		AssertEqual(world.Failed, 1)
		AssertEqual(world.Ready, 0)
	} finally world.Drain()
}

_OMC_NativeActivationTupleIsRequired() {
	local world := _OMC_World()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		AssertTrue(world.Owner._RuntimeLive())
		for field in ["id", "phase", "error", "activation_claimed"] {
			local saved := world.Status[field]
			world.Status[field] := field == "error" ? 5 : 0
			AssertFalse(world.Owner._RuntimeLive(), "Changed native " . field . " refuses.")
			world.Status[field] := saved
		}
		world.Owner.Session.Runtime.Owner.Record["guardian"].IsRetired := true
		AssertFalse(world.Owner._RuntimeLive())
	} finally world.Drain()
}

_OMC_ReadyDoesNotRefreshOrExpireDaemonOwnership() {
	local world := _OMC_World()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record, deadline := record["deadline"]
		record["phase"] := "ready"
		world.Now := 1000
		AssertTrue(world.Owner._Current(record))
		AssertEqual(record["deadline"], deadline)
		world.Live["model"] := "other:latest"
		world.Owner._PollRecord(record)
		AssertTrue(record["cancelled"])
		AssertTrue(world.Owner.Record == record)
		AssertTrue(world.RuntimeOwned)
	} finally world.Drain()
}

_OMC_ArchiveLimitsRemainSourceBound() {
	local world := _OMC_World()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		for name in ["MaxExpandedBytes", "MaxEntries"] {
			local changed := world.Plan["prepare"].Clone()
			changed[name] += 1
			AssertFalse(world.Owner._SessionCurrent(changed, world.Plan["target"]))
		}
	} finally world.Drain()
}

Test("ollama-managed-reentrant-clock-reservation", _OMC_StartReservesBeforeReentrantClock)
Test("ollama-managed-consent-before-native-dispatch", _OMC_ConsentRefusalHasNoNativeDispatch)
Test("ollama-managed-cancel-runtime-timer-handback", _OMC_CancelRetainsExactRuntimeAndTimerDebt)
Test("ollama-managed-exact-native-activation-tuple", _OMC_NativeActivationTupleIsRequired)
Test("ollama-managed-ready-daemon-source-lifetime", _OMC_ReadyDoesNotRefreshOrExpireDaemonOwnership)
Test("ollama-managed-archive-limits-source-bound", _OMC_ArchiveLimitsRemainSourceBound)

class _OMC_ModelCommand extends OllamaModelPullOwner {
	__New() {
		this.Owned := true
		this.Starts := 0
	}
	Start(Target, Authority, OnExit) {
		this.Starts += 1
		this.Owned := true
		return true
	}
	HasOwner() {
		return this.Owned
	}
	Stop() {
		return !this.Owned
	}
}

_OMC_MissingModelNeedsSeparateConsent() {
	local world := _OMC_World(), command := _OMC_ModelCommand()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record
		command.Owned := false
		world.Owner.Options["model_factory"] := (*) => command
		local root := "C:\synthetic\managed", ticket := world.Plan["prepare"]["TicketId"]
		record["publication"] := Map("ok", true, "schema", 1, "phase", "published",
			"RootPath", root, "RootIdentity", "12345678:1234567890abcdef", "Ticket", ticket,
			"StageIdentity", "12345678:1234567890abcdea", "ManifestHash", Format("{:064}", 0),
			"DescriptorIdentity", "12345678:1234567890abcdeb", "DescriptorHash", Format("{:064}", 0),
			"RecordCapacity", 16, "PathCapacity", 1024, "Executable", root . "\.stage-" . ticket . "\ollama.exe")
		record["target"] := world.Plan["target"].Clone()
		record["target"]["executable"] := record["publication"]["Executable"]
		AssertFalse(world.Owner._PullModel(record))
		AssertTrue(record["model_attempted"])
		AssertTrue(record["cancelled"])
		AssertEqual(record["first_error"], "model_consent_refused")
		AssertEqual(record["model"], 0)
		AssertEqual(command.Starts, 0)
		AssertEqual(world.Ready, 0)
	} finally {
		command.Owned := false
		world.Drain()
	}
}

_OMC_ModelHandbackPrecedesNewHttpProbe() {
	local world := _OMC_World(), transport := _OMH_World(), command := _OMC_ModelCommand()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record
		world.Owner.Http := transport.Owner
		record["model"] := command
		record["model_done"] := true
		record["model_exit"] := 0
		record["phase"] := "model-running"
		world.Owner._PollRecord(record)
		AssertEqual(transport.Request.Sends, 0)
		AssertEqual(record["phase"], "model-running")
		command.Owned := false
		world.Owner._PollRecord(record)
		AssertEqual(transport.Request.Sends, 1)
		AssertEqual(record["phase"], "http-version")
		AssertEqual(world.Ready, 0)
	} finally {
		command.Owned := false
		world.Drain()
	}
}

_OMC_ModelTerminalKeepsExactSelection() {
	local world := _OMC_World()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record, target := world.Plan["target"].Clone()
		target["executable"] := "C:\synthetic\ollama.exe"
		record["target"] := target.Clone()
		target["model_tag"] := "foreign:latest"
		world.Owner._ModelTerminal(record, 0, target)
		AssertFalse(record["model_done"])
		AssertTrue(record["cancelled"])
		AssertEqual(record["first_error"], "model_terminal_correlation_refused")
		AssertEqual(world.Ready, 0)
	} finally world.Drain()
}

Test("ollama-managed-model-explicit-separate-consent", _OMC_MissingModelNeedsSeparateConsent)
Test("ollama-managed-model-handback-before-http", _OMC_ModelHandbackPrecedesNewHttpProbe)
Test("ollama-managed-model-terminal-selection", _OMC_ModelTerminalKeepsExactSelection)

_OMC_SessionStopKeepsFailedTimerCapability() {
	local world := _OMC_World()
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		AssertEqual(world.Owner.SessionTimers.Count, 1)
		world.AllowStop := true
		world.TimerStop := false
		AssertFalse(world.Owner.Stop())
		AssertFalse(world.Owner.Session.Record is Map)
		AssertFalse(world.RuntimeOwned)
		AssertEqual(world.Owner.SessionTimers.Count, 1)
		AssertTrue(world.Owner.HasNativeOwner())
		world.TimerStop := true
		AssertTrue(world.Owner.Stop())
		AssertEqual(world.Owner.SessionTimers.Count, 0)
		AssertEqual(world.Failed, 1)
	} finally world.Drain()
}

_OMC_TimerStopCannotEraseReentrantArm() {
	local world := _OMC_World(), reenter := true, callback := (*) => false
	try {
		world.Owner.Options["timer"] := (Callback, Period) => (
			Period == 0 && reenter ? (reenter := false, world.Owner._SessionTimer(Callback, -5)) : true)
		AssertTrue(world.Owner._SessionTimer(callback, -5))
		AssertTrue(world.Owner._SessionTimer(callback, 0))
		AssertEqual(world.Owner.SessionTimers.Count, 1)
		AssertTrue(world.Owner.HasNativeOwner())
		AssertTrue(world.Owner._SessionTimer(callback, 0))
		AssertEqual(world.Owner.SessionTimers.Count, 0)
	} finally {
		world.Owner._StopSessionTimers()
		world.Drain()
	}
}

Test("ollama-managed-session-timer-reset-retention", _OMC_SessionStopKeepsFailedTimerCapability)
Test("ollama-managed-session-timer-reentrant-revision", _OMC_TimerStopCannotEraseReentrantArm)

_OMC_LastClockCannotAdmitChangedSelection() {
	local world := _OMC_World(), calls := 0
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		world.Owner.Options["clock"] := () => (
			++calls == 2 ? world.Live["model"] := "foreign:latest" : 0, world.Now)
		AssertFalse(world.Owner._Current(world.Owner.Record))
		AssertEqual(calls, 2)
		AssertEqual(world.Live["model"], "foreign:latest")
	} finally world.Drain()
}

_OMC_LastClockCannotAdmitCancelledRecord() {
	local world := _OMC_World(), calls := 0
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record
		world.Owner.Options["clock"] := () => (++calls == 2 ? world.Owner.Stop() : 0, world.Now)
		AssertFalse(world.Owner._Current(record))
		AssertEqual(calls, 2)
		AssertTrue(record["cancelled"])
		AssertTrue(world.Owner.Record == record)
		AssertTrue(world.RuntimeOwned)
	} finally world.Drain()
}

_OMC_FinalMainResetRetainsNewSessionTimer() {
	local world := _OMC_World(), armed := true, callback := (*) => false
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record
		world.AllowStop := true
		world.Owner.Options["timer"] := (Callback, Period) => (
			Period == 0 && Callback == record["timer"] && armed
				? (armed := false, world.Owner._SessionTimer(callback, -5)) : true)
		AssertFalse(world.Owner.Stop())
		AssertTrue(world.Owner.Record == record)
		AssertEqual(world.Owner.SessionTimers.Count, 1)
		AssertEqual(world.Failed, 0)
		AssertTrue(world.Owner.Stop())
		AssertEqual(world.Owner.SessionTimers.Count, 0)
		AssertEqual(world.Failed, 1)
	} finally world.Drain()
}

_OMC_FinalMainResetRetainsRearmedMainTimer() {
	local world := _OMC_World(), armed := true
	try {
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record
		world.AllowStop := true
		world.Owner.Options["timer"] := (Callback, Period) => (
			Period == 0 && Callback == record["timer"] && armed
				? (armed := false, world.Owner._Schedule(record), true) : true)
		AssertFalse(world.Owner.Stop())
		AssertTrue(world.Owner.Record == record)
		AssertTrue(record["timer_owned"])
		AssertEqual(world.Failed, 0)
		AssertTrue(world.Owner.Stop())
		AssertEqual(world.Failed, 1)
	} finally world.Drain()
}

_OMC_StopWithoutRecordStillDrainsOwnedCallbacks() {
	local world := _OMC_World(), callback := (*) => false
	try {
		AssertTrue(world.Owner._SessionTimer(callback, -5))
		AssertFalse(world.Owner.Record is Map)
		world.TimerStop := false
		AssertFalse(world.Owner.Stop())
		AssertEqual(world.Owner.SessionTimers.Count, 1)
		world.TimerStop := true
		AssertTrue(world.Owner.Stop())
		AssertEqual(world.Owner.SessionTimers.Count, 0)
	} finally world.Drain()
}

_OMC_NativeTickDomainCrossesDwordBoundary() {
	local world := _OMC_World()
	try {
		world.Now := 0xfffffffe
		AssertTrue(world.Owner.Start(world.Plan))
		local record := world.Owner.Record
		AssertEqual(record["deadline"], 0x100000062)
		world.Now := 0x100000000
		AssertTrue(world.Owner._Current(record))
		world.Now := record["deadline"]
		AssertFalse(world.Owner._Current(record))
	} finally world.Drain()
}

Test("ollama-managed-last-clock-selection-fence", _OMC_LastClockCannotAdmitChangedSelection)
Test("ollama-managed-last-clock-cancellation-fence", _OMC_LastClockCannotAdmitCancelledRecord)
Test("ollama-managed-main-reset-session-rearm", _OMC_FinalMainResetRetainsNewSessionTimer)
Test("ollama-managed-main-reset-main-rearm", _OMC_FinalMainResetRetainsRearmedMainTimer)
Test("ollama-managed-orphan-callback-stop-handback", _OMC_StopWithoutRecordStillDrainsOwnedCallbacks)
Test("ollama-managed-native-tick64-boundary", _OMC_NativeTickDomainCrossesDwordBoundary)
