#!/usr/bin/env bash
set -u
# This file is a prepared command, not an executed full165 receipt.
# Parent must release its active serial canonical validation slot first.
TASK_PACKET=/workspace/ergopti-cloud/group6-native-removal-r2-full165-preparation
cd "$TASK_PACKET/physical-source" || exit 1
export TMPDIR="$TASK_PACKET/private-tmp"
export PYTHONDONTWRITEBYTECODE=1
sha256sum --check "$TASK_PACKET/expected-source.sha256" > "$TASK_PACKET/source-before.stdout" 2> "$TASK_PACKET/source-before.stderr" || exit 1
/workspace/ergopti-cloud/python/bin/python -I -B "$TASK_PACKET/physical-source/tools/test/macos_native_http_receiving_facts_test.py" -v > "$TASK_PACKET/full165.stdout" 2> "$TASK_PACKET/full165.stderr"
TASK_TEST_STATUS=$?
sha256sum --check "$TASK_PACKET/expected-source.sha256" > "$TASK_PACKET/source-after.stdout" 2> "$TASK_PACKET/source-after.stderr"
TASK_FENCE_STATUS=$?
printf 'full165_exit=%s source_fence_exit=%s\n' "$TASK_TEST_STATUS" "$TASK_FENCE_STATUS" > "$TASK_PACKET/terminal-status.txt"
if (( TASK_TEST_STATUS != 0 || TASK_FENCE_STATUS != 0 )); then exit 1; fi
