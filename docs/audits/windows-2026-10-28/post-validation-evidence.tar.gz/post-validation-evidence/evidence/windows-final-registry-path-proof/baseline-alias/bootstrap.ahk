﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
#Warn All, StdOut
Quote(Value) => Chr(34) . Value . Chr(34)
try {
	Out := A_Args[1]
	Long := A_Temp . "\Ergopti registry native alias fixture " . DllCall("kernel32\GetCurrentProcessId", "UInt")
	DirCreate(Long)
	Size := DllCall("kernel32\GetShortPathNameW", "Str", Long, "Ptr", 0, "UInt", 0, "UInt")
	if !Size
		throw OSError(A_LastError, A_ThisFunc)
	ShortBuffer := Buffer(Size * 2)
	Written := DllCall("kernel32\GetShortPathNameW", "Str", Long, "Ptr", ShortBuffer, "UInt", Size, "UInt")
	if !Written || Written >= Size
		throw Error("Native short path did not complete.")
	Short := StrGet(ShortBuffer)
	if StrLower(Short) == StrLower(Long)
		throw Error("This native filesystem did not provide a distinct short alias; the premise is not established.")
	FileAppend("long=" . Long . "`nshort=" . Short . "`n", Out . "\native-alias.txt", "UTF-8")
	EnvSet("TEMP", Short), EnvSet("TMP", Short)
	ProbeCode := RunWait(Quote(A_AhkPath) . " /ErrorStdOut=UTF-8 " . Quote(Out . "\temp-probe.ahk")
		. " " . Quote(Out . "\child-temp.txt"), , "Hide")
	if ProbeCode != 0
		throw Error("The native child temp observation did not execute.")
	Observed := FileRead(Out . "\child-temp.txt", "UTF-8")
	if StrLower(RTrim(Observed, "\/")) != StrLower(RTrim(Short, "\/"))
		throw Error("The actual native child did not use the requested short TEMP namespace: " . Observed)
	EnvSet("ERGOPTI_AHK_RESULTS_FILE", Out . "\native.tap")
	Runner := "Z:\workspace\ergopti-windows-final-shutdown\static\ergopti_plus\windows\tests\run_all.ahk"
	Selection := "Z:\workspace\scratch\windows-catalogue-inline-callback-r32\green\selected47.txt"
	Result := RunWait(Quote(A_AhkPath) . " /ErrorStdOut=UTF-8 " . Quote(Runner)
		. " " . Quote("--list=" . Selection), , "Hide")
	FileAppend("actual_exit=" . Result . "`n", Out . "\native-alias.txt", "UTF-8")
	DirDelete(Long, true)
	ExitApp(Result)
} catch as Failure {
	FileAppend(Failure.Message . "`n", "**", "UTF-8-RAW")
	ExitApp(2)
}
