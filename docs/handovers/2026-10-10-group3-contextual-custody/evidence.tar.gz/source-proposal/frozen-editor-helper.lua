	local function with_editor(initial, body, writes_fail)
		local saved_source = package.loaded["modules.hotstrings.magic_key_source"]
		local saved_magic = package.loaded["modules.hotstrings.magic_key"]
		local saved_builder = package.loaded["ui.menu.menu_builder"]
		local gestures = require("modules.gestures.manager")
		local saved_execute = gestures.execute_action
		local state = { trigger = "★", generation = 1, master = true, paused = false, inhibited = false,
			rows = { { code = "KeyJ", native_code = 36, identity = "evdev:36", text = "★", native_text = "j", direct = true, dead = false } },
			queue = {}, fired = {} }
		package.loaded["modules.hotstrings.magic_key_source"] = {
			editor_source = function() return { generation = state.generation, status = "ready", candidates = state.rows } end,
			known_codes = function() return { KeyJ = true, KeyC = true, Quote = true, Semicolon = true } end,
		}
		package.loaded["modules.hotstrings.magic_key"] = { get = function() return state.trigger end, is_customised = function() return false end }
		gestures.execute_action = function(action, binding) state.fired[#state.fired + 1] = { action, binding } return true end
		local ok, err = pcall(function()
			local shortcuts, config = load_over_config(initial, writes_fail)
			state.options = {
				defer = function(callback) state.queue[#state.queue + 1] = callback return true end,
				admission = function() return { master = state.master, paused = state.paused, inhibited = state.inhibited } end,
			}
			state.detail = { key = "j", code = 36, physical = true, mods = { meta = true } }
			body(shortcuts, config, state)
		end)
		gestures.execute_action = saved_execute
		package.loaded["modules.hotstrings.magic_key_source"] = saved_source
		package.loaded["modules.hotstrings.magic_key"] = saved_magic
		package.loaded["ui.menu.menu_builder"] = saved_builder
		drop_config()
		if not ok then error(err, 0) end
	end
