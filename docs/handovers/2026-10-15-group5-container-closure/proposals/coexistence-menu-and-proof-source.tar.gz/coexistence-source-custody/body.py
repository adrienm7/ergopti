import json,pathlib,sys
r=pathlib.Path(__file__).parent
j=json.loads((r/'INDEX.json').read_text())
sys.stdout.buffer.write((r/j[sys.argv[1]]['body']).read_bytes())
