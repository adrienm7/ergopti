# Final formatted private source candidate

Eight-path successor to sealed uly1hlr5 (original remains immutable). Authenticated G6 b454 source is the base; canonical6e67/c80 supplies read-only G5 additions and frozen146 methods, including17 filesystem methods. Future G3 source must be composed separately before adoption. No canonical/ref/index/CI changes.

The capture reader now allocates at most its admitted pre-read size and reads only that fixed extent, then revalidates metadata and named identity. A growing physical file must refuse while allocation remains bounded. The receiver now rejects conspicuous leading-space test frames and requires full summary lines with decimal durations and no contradictory suffix. Independent original44 vectors plus independently frozen2 pre-repair failures remain unchanged. All originalG6 44 controls and52 deferral controls and priorG5 24 controls are whole. Frozen G5 control block alone uses prettier-ignore to preserve its independent original bytes; all other candidate files were formatted with canonical pinned Prettier/config.

Native UNEXECUTED, portable candidate tests NOT EXECUTED after formatting. Existing source receipt/evaluate44 on predecessor proves only parser vectors and deliberately retains bound/summary HOLDs. New candidate requires independent source review and selected portable tests. Actual selected XCTest transcript remains unknown; no optional bundle wrapper is invented or admitted. Filtered146 cannot replace full Swift mandatory25min/45min job. Eight exact fast wrappers normalize to prior default predicates; original G6 entries remain unchanged.

Proposed selected entries: test-ci-full-default.cjs; test-ci-pipeline-wiring.cjs; test-lease-xctest-evidence.cjs; independent frozen drivers. No full JS or native.
