// static/ergopti_plus/windows/native/nav_event_owner/capture_provenance.h
/**
 * @file capture_provenance.h
 * @brief Internal raw-edge identity and immutable modifier provenance.
 *
 * Only the existing native callback supplies input. This is not an AHK observer,
 * an effect permit, a sender, or an attestation of hardware input. Callers own
 * serialization. A future route dispatcher must consume reservations explicitly.
 */
#ifndef ERGOPTI_CAPTURE_PROVENANCE_H
#define ERGOPTI_CAPTURE_PROVENANCE_H

#include <stdint.h>
#include "nav_event_owner.h"

#define NAV_CAPTURE_KEY_IDENTITIES 768u

/** Immutable raw snapshot retained with one original terminal FIFO edge. */
typedef struct NavCaptureProvenanceEdge {
    uint64_t sequence;
    uint64_t down_sequence;
    uint64_t action_sequence;
    uint64_t capture_token;
    uint64_t down_capture_token;
    uint64_t navigation_generation;
    uint64_t profile_generation;
    uint64_t extra_info;
    uint32_t time;
    uint32_t flags;
    uint16_t vk;
    uint16_t sc;
    uint8_t kind;
    uint8_t physical_lr;
    uint8_t known_modifier_lr;
    uint8_t repeat;
    uint8_t repeat_known;
    uint8_t reserve_action;
    uint8_t injected_lr[ERGOPTI_NAV_AHK_SEND_LEVEL_MAX + 1];
} NavCaptureProvenanceEdge;

/** Callback-owned metadata; it never adopts a process/thread/hook capability. */
typedef struct NavCaptureProvenanceState {
    uint64_t next_sequence;
    uint64_t down_sequence[NAV_CAPTURE_KEY_IDENTITIES];
    uint64_t action_sequence[NAV_CAPTURE_KEY_IDENTITIES];
    uint64_t down_capture_token[NAV_CAPTURE_KEY_IDENTITIES];
    uint64_t navigation_generation[NAV_CAPTURE_KEY_IDENTITIES];
    uint64_t profile_generation[NAV_CAPTURE_KEY_IDENTITIES];
    uint8_t down[NAV_CAPTURE_KEY_IDENTITIES];
    uint8_t known[NAV_CAPTURE_KEY_IDENTITIES];
    uint8_t physical_lr;
    uint8_t known_modifier_lr;
    uint8_t injected_lr[ERGOPTI_NAV_AHK_SEND_LEVEL_MAX + 1];
    uint8_t faulted;
} NavCaptureProvenanceState;

/** Zeroes metadata only after the existing native lifecycle admits its reset. */
void NavCaptureProvenance_Reset(NavCaptureProvenanceState *state);
/**
 * Records one actual raw entry before any terminal suppression.
 * modifier_bit comes from the existing single modifier mapper, not a second map.
 * An unknown initial DOWN has observed identity but cannot reserve a new action.
 */
int NavCaptureProvenance_Observe(NavCaptureProvenanceState *state,
    uint16_t vk, uint16_t sc, uint32_t flags, uint64_t extra_info, uint32_t time,
    uint8_t kind, uint8_t modifier_bit, uint64_t capture_token,
    uint64_t navigation_generation, uint64_t profile_generation,
    NavCaptureProvenanceEdge *out_edge);
/** Reads captured masks only; never reconstructs them from later OS/key state. */
int NavCaptureProvenance_Effective(const NavCaptureProvenanceEdge *edge,
    uint8_t input_level, uint8_t *out_mask);

#endif
