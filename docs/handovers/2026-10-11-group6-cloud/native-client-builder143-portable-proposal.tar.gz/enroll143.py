"""Prepare additive7 root controls over repaired103+unchanged33."""
import ast, difflib, hashlib, json
from pathlib import Path
P=Path(__file__).resolve().parent
SOURCE=P/'canonical136'
TARGET=P/'canonical143'
TEST='tools/test/macos_native_http_receiving_facts_test.py'
REG='tools/test/test-managed-ollama-protocol.cjs'
HELPER='tools/test/macos_native_http_client_root_controls.py'
# Copy only finite known files from our private assembled subject.
for src in SOURCE.rglob('*'):
 if src.is_file():
  rel=src.relative_to(SOURCE);dst=TARGET/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
first=(P/'portable_root_replacement_candidate_test.py').read_text()
first=first[first.index('class ModeledNativeOwner:'):first.index('\n\nif __name__ == "__main__":')]
second=(P/'portable_root_cleanup_controls.py').read_text()
second=second[second.index('class CleanupOwner:'):second.index('\n\nif __name__ == "__main__":')]
header='''"""Caller root ownership controls; actual POSIX files/FD, native owner modeled.

The original bootstrap/teardown methods execute through fixed test source paths.
No native compiler, signing, Security, permission or clock qualification is given.
"""
import hashlib
import importlib.abc
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
PACKET = ROOT
REPOSITORY = ROOT
SUPPORT = ROOT / "static/ergopti_plus/macos/tests/support"
FACTS = {}
RECEIVING = []


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


'''
provider=header+first+'\n\n'+second+'\n\n'
classes=('RootReplacementControl','ClientRootCleanupControls')
expected={}
for name in classes:
 node=next(n for n in ast.parse(provider).body if isinstance(n,ast.ClassDef) and n.name==name)
 expected[name]=tuple(sorted(n.name for n in node.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test')))
assert [len(expected[n]) for n in classes]==[1,6]
provider+='EXPECTED_TEST_IDENTITIES = '+repr(expected)+'\n\n'
provider+='''def enrolled_cases():
    """Fixed1+6 caller controls; absent or extra methods refuse enrollment."""
    classes = (RootReplacementControl, ClientRootCleanupControls)
    for case in classes:
        if case.__module__ != __name__ or tuple(unittest.defaultTestLoader.getTestCaseNames(case)) != EXPECTED_TEST_IDENTITIES[case.__name__]:
            raise RuntimeError("Native client root control identity refused")
    if sum(len(EXPECTED_TEST_IDENTITIES[case.__name__]) for case in classes) != 7:
        raise RuntimeError("Native client root control census refused")
    return classes
'''
path=TARGET/HELPER;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(provider)
entry='''# Fixed-path caller root ownership receiving: original native test bodies remain
# unchanged; these software controls confer no native execution qualification.
NATIVE_CLIENT_ROOT_CONTROLS = load(
    "native_http_client_root_controls",
    ROOT / "tools/test/macos_native_http_client_root_controls.py",
)
(
    NativeClientRootReplacementControls,
    NativeClientRootCleanupControls,
) = NATIVE_CLIENT_ROOT_CONTROLS.enrolled_cases()


'''
original=(SOURCE/TEST).read_text()
new=original.replace('if __name__ == "__main__":',entry+'if __name__ == "__main__":',1)
assert new.replace(entry,'',1)==original
(TARGET/TEST).write_text(new)
old=(SOURCE/REG).read_text();needle="cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 136]);"
assert old.count(needle)==1
(TARGET/REG).write_text(old.replace(needle,needle.replace('136','143'),1))
# Precise original136 function body bytes; no generated corpus expectations.
def bodies(s):
 lines=s.splitlines(True)
 return [ ''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.FunctionDef)]
assert bodies(new)==bodies(original)
(P/'enrollment143-static-review.json').write_text(json.dumps({'status':'SOURCE_ONLY_RUNTIME_PENDING','original136_functions_exact':True,'additive_root_identities':expected,'strict_previous_total':136,'strict_total':143,'owning_postimage_sha256':hashlib.sha256(new.encode()).hexdigest(),'new_helper':HELPER,'imports':'Python standard library; fixed native client/builder/fixture paths','native_credit':False},indent=2,sort_keys=True)+'\n')
for role,paths in [('root-enrollment143',(TEST,REG,HELPER))]:
 patch=''
 for rel in paths:
  before=(SOURCE/rel).read_text() if (SOURCE/rel).is_file() else ''
  after=(TARGET/rel).read_text()
  patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 (P/(role+'.patch')).write_text(patch)
