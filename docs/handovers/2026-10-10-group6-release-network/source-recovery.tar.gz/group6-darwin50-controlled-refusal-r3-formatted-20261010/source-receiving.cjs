'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const acorn = require('/workspace/ergopti/node_modules/acorn');
const packet = __dirname;
const r2 = '/workspace/scratch/group6-darwin50-controlled-refusal-r2-20261010';
const relative = 'tools/test/test-macos-release-stage-native-receiving.cjs';
const pre = fs.readFileSync(path.join(r2, 'candidate', relative), 'utf8');
const post = fs.readFileSync(path.join(packet, 'candidate', relative), 'utf8');
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
function normalized(node) {
 if (Array.isArray(node)) return node.map(normalized);
 if (node && typeof node === 'object') return Object.fromEntries(Object.entries(node).filter(([key]) => !['start', 'end', 'raw'].includes(key)).map(([key, value]) => [key, normalized(value)]));
 return node;
}
function parse(source) {
 const tokens = [];
 const comments = [];
 const ast = acorn.parse(source, { ecmaVersion: 'latest', sourceType: 'script', onToken: tokens, onComment: comments });
 return { ast, tokens: tokens.map((token) => ({ type: token.type.label, value: token.value ?? null })), comments: comments.map((comment) => ({ type: comment.type, value: comment.value })) };
}
const original = parse(pre), formatted = parse(post);
assert.deepEqual(normalized(formatted.ast), normalized(original.ast));
assert.deepEqual(formatted.tokens, original.tokens);
assert.deepEqual(formatted.comments, original.comments);
const registryPath = 'tools/test/run-js-suite.cjs';
const beforeRegistry = fs.readFileSync(path.join(packet, 'preimage', registryPath), 'utf8');
const afterRegistry = fs.readFileSync(path.join(packet, 'candidate', registryPath), 'utf8');
function checks(source) {
 const ast = parse(source).ast;
 const declaration = ast.body.flatMap((node) => node.type === 'VariableDeclaration' ? node.declarations : []).find((node) => node.id.name === 'CHECKS');
 assert.equal(declaration.init.type, 'ArrayExpression');
 return declaration.init.elements;
}
const oldChecks = checks(beforeRegistry), newChecks = checks(afterRegistry);
const spreads = newChecks.filter((node) => node.type === 'SpreadElement');
assert.equal(spreads.length, 1);
const spread = spreads[0];
assert.equal(spread.argument.type, 'ConditionalExpression');
assert.deepEqual(normalized(spread.argument.test), {
 type: 'BinaryExpression', left: { type: 'MemberExpression', object: { type: 'Identifier', name: 'process' }, property: { type: 'Identifier', name: 'platform' }, computed: false, optional: false }, operator: '===', right: { type: 'Literal', value: 'linux' }
});
assert.equal(spread.argument.consequent.type, 'ArrayExpression');
assert.equal(spread.argument.consequent.elements.length, 1);
assert.equal(spread.argument.alternate.type, 'ArrayExpression');
assert.deepEqual(spread.argument.alternate.elements, []);
const entry = spread.argument.consequent.elements[0];
assert.equal(entry.type, 'ObjectExpression');
const values = Object.fromEntries(entry.properties.map((property) => [property.key.name, property.value]));
assert.deepEqual(values.args.elements.map((node) => node.value), [relative]);
assert.equal(values.repro.value, 'npm run test:macos-release-stage-native-receiving-controls');
assert.deepEqual(normalized(newChecks.filter((node) => node !== spread)), normalized(oldChecks));
const insert = afterRegistry.slice(spread.start, spread.end);
const lineStart = afterRegistry.lastIndexOf('\n', spread.start) + 1;
const lineEnd = afterRegistry.indexOf('\n', spread.end) + 1;
assert.equal(afterRegistry.slice(0, lineStart) + afterRegistry.slice(lineEnd), beforeRegistry);
const prePackage = fs.readFileSync(path.join(packet, 'preimage/package.json'), 'utf8');
const postPackage = fs.readFileSync(path.join(packet, 'candidate/package.json'), 'utf8');
const before = JSON.parse(prePackage), after = JSON.parse(postPackage);
const alias = 'test:macos-release-stage-native-receiving-controls';
assert.equal(after.scripts[alias], 'node ./tools/test/test-macos-release-stage-native-receiving.cjs');
const without = structuredClone(after); delete without.scripts[alias];
assert.deepEqual(without, before);
const aliasLine = '\t\t"' + alias + '": "node ./tools/test/test-macos-release-stage-native-receiving.cjs",\n';
assert.equal(postPackage.split(aliasLine).length, 2);
assert.equal(postPackage.replace(aliasLine, ''), prePackage);
const frozen = JSON.parse(fs.readFileSync(path.join(packet, 'FROZEN-INPUTS.json')));
for (const input of frozen.inputs) assert.equal(sha(fs.readFileSync(path.join(packet, 'candidate', input.path))), input.sha256);
const result = {
 schema: 1, scope: 'static source parsing only; no target import or runtime',
 format: { version: JSON.parse(fs.readFileSync('/workspace/ergopti/node_modules/prettier/package.json')).version, repository_config_sha256: sha(fs.readFileSync('/workspace/ergopti/.prettierrc')), original_source_sha256: sha(pre), formatted_source_sha256: sha(post), AST_exact: true, token_sequence_exact: true, comment_sequence_exact: true, token_count: original.tokens.length },
 registry: { declared_preimage_sha256: sha(beforeRegistry), proposed_postimage_sha256: sha(afterRegistry), original_entry_ASTs_exact: true, original_bytes_inverse_exact: true, original_checks: oldChecks.length, Linux_checks: oldChecks.length + 1, Windows_checks: oldChecks.length, Darwin_checks: oldChecks.length, added_linux_entry: values.name.value, conditional_exact: "process.platform === 'linux'", alternate_empty: true },
 package: { declared_preimage_sha256: sha(prePackage), proposed_postimage_sha256: sha(postPackage), original_scripts: Object.keys(before.scripts).length, proposed_scripts: Object.keys(after.scripts).length, original_values_and_metadata_exact: true, whole_byte_inverse_exact: true, added_alias: alias },
 dependencies: { all_seven_frozen_inputs_byte_exact: true, original_wrapper_exact: true, original_corpus_exact: true },
 target_runtime_execution: 0, actual_Darwin: 'UNEXECUTED', source_only_enrollment: true
};
fs.writeFileSync(path.join(packet, 'SOURCE-RECEIVING.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ AST: 'exact', tokens: original.tokens.length, comments: 'exact', old_checks: oldChecks.length, proposed_Linux_checks: oldChecks.length + 1, unchanged_Windows_checks: oldChecks.length, original_scripts: Object.keys(before.scripts).length, proposed_scripts: Object.keys(after.scripts).length, target_executions: 0 }));
