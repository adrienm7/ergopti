﻿; tests/unit/test_base_url_models_admission.ahk

; ==============================================================================
; MODULE: Local Models Base URL Admission Tests
; DESCRIPTION:
; Uses the existing actual curl/owner fixture to prove malformed target URLs
; refuse before child/artifact acquisition, preserving native source identity.
; ==============================================================================

#Requires AutoHotkey v2.0





; ===============================================
; ===============================================
; ======= 1/ Actual Models Owner Boundary =======
; ===============================================
; ===============================================

_BUP_ModelsInvalidAdmission() {
	global _SharedDir
	Corpus := JsonParse(FileRead(_SharedDir . "\tests\corpus\llm\base_url_vectors.json", "UTF-8"))
	Checked := 0
	for Case in Corpus["cases"] {
		if Case["valid"]
			continue
		Fixture := _LSM_Fixture()
		try {
			Target := Fixture.Target(), Target["base_url"] := Case["input"]
			AssertFalse(Fixture.Owner.Probe(Target, ObjBindMethod(Fixture, "Done"), Fixture.Ticket()), Case["id"])
			AssertEqual(0, Fixture.Requests.Length, Case["id"] . " acquires no actual curl request")
			AssertEqual(0, Fixture.Children.Length, Case["id"] . " acquires no child")
			AssertEqual(0, Fixture.Configs.Length, Case["id"] . " publishes no private config")
			AssertEqual(0, Fixture.Results.Length, Case["id"] . " invents no successful receipt")
			AssertEqual(0, Fixture.Owner.Records.Count, Case["id"] . " retains no owner slot")
			Checked += 1
		} finally Fixture.Dispose()
	}
	AssertEqual(20, Checked, "every exact invalid literal exercised actual owner admission")
}
Test("local models URL policy: invalid routes acquire no native resources", _BUP_ModelsInvalidAdmission)

_BUP_ModelsValidIPv6() {
	Fixture := _LSM_Fixture()
	try {
		Target := Fixture.Target(), Target["base_url"] := "HTTP://[::1]:08080/v1///"
		AssertTrue(Fixture.Owner.Probe(Target, ObjBindMethod(Fixture, "Done"), Fixture.Ticket()))
		AssertEqual(1, Fixture.Requests.Length, "one actual curl request acquired")
		AssertEqual(1, Fixture.Children.Length, "one controlled child receipt acquired")
		AssertEqual(1, Fixture.Children[1].Starts, "exact child actually started")
		AssertEqual("http://[::1]:08080/v1/models", Fixture.Requests[1].Url,
			"independent canonical transport URL keeps bracket host and original decimal port")
		AssertEqual("HTTP://[::1]:08080/v1///", Target["base_url"],
			"the configured target snapshot keeps exact source provenance")
		Fixture.Complete(1, 200, '{"data":[]}')
		AssertEqual(1, Fixture.Results.Length, "actual owner delivered one typed models receipt")
		AssertTrue(Fixture.Results[1]["ok"])
	} finally Fixture.Dispose()
}
Test("local models URL policy: valid IPv6 normalizes only the transport copy", _BUP_ModelsValidIPv6)

_BUP_ModelsPreservesC1Guard() {
	Fixture := _LSM_Fixture()
	try {
		Target := Fixture.Target(), Target["base_url"] := "http://fixture.invalid/" . Chr(0x80)
		AssertFalse(Fixture.Owner.Probe(Target, ObjBindMethod(Fixture, "Done"), Fixture.Ticket()),
			"the existing stronger Windows C1 scalar guard stays authoritative")
		AssertEqual(0, Fixture.Requests.Length)
		AssertEqual(0, Fixture.Children.Length)
		AssertEqual(0, Fixture.Configs.Length)
	} finally Fixture.Dispose()
}
Test("local models URL policy: transport C1 controls remain refused", _BUP_ModelsPreservesC1Guard)
