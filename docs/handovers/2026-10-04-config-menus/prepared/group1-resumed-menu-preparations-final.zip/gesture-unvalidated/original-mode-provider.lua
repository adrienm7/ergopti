		local modeSubmenu = {
			{
				label = i18n.get("menu.gestures.mode_single"),
				checked = (currentMode == "x1") or nil,
				action = function()
					return commit_gesture_row_value("get_mode", "set_mode", slot, "x1", "mode")
				end
			},
			{
				label = i18n.get("menu.gestures.mode_incremental"),
				checked = (currentMode == "incremental") or nil,
				action = function()
					return commit_gesture_row_value("get_mode", "set_mode", slot, "incremental", "mode")
				end
			}
		}
