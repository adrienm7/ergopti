# Historical retention addendum

This is an inert supplement to the unchanged parent 89-file handoff. [MANIFEST.json](MANIFEST.json) records every exact original source, cut patch, mutated cut body and actual run log copied here. No source or test was executed during packaging.

The `before-raw-join` snapshot contains the original draft test with the wrong `token` SQL column. It is preserved honestly, not relabelled as the corrected-run test. The parent handoff separately retains the scancode-only correction receipt and exact corrected test SHA, as well as both raw outcomes. Only the corrected 5PASS2 assertionFAIL outcome demonstrates the raw-attribution and cancellation defects; the initial wrong-column query failure receives no causal credit.

`supplier-cuts` retains the actual four omission source bodies, exact patches and captured logs authenticated by the supplier cut-custody review. `native-api` retains one complete original luv C file; its two original pinned filenames have byte-identical content, recorded in the manifest. This supports original API provenance, without claiming physical evdev, grabs, input delivery or hardware validation.

Copy this directory under the existing handoff's `retention-addendum/`. It changes no source proposal, expectations, approvals or qualification counts.
