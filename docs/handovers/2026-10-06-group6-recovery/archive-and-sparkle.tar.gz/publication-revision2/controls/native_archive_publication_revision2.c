/* Actual syscall controls plus explicitly injected metadata/libc refusals.
 * UNCOMPILED/UNEXECUTED. These do not qualify hash/HTTP/consumer joins. */
#define _GNU_SOURCE
#include "../candidate/archive_publication.h"
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

int __real_fstat(int fd, struct stat *info);
DIR *__real_fdopendir(int fd);
int __real_openat(int directory, const char *path, int flags, ...);
static int metadata_after, refuse_fdopendir, scan_opens;
int __wrap_fstat(int fd, struct stat *info) {
    if (metadata_after > 0 && --metadata_after == 0) { errno = EIO; return -1; }
    return __real_fstat(fd, info);
}
DIR *__wrap_fdopendir(int fd) {
    if (refuse_fdopendir) { refuse_fdopendir = 0; errno = EMFILE; return NULL; }
    return __real_fdopendir(fd);
}
int __wrap_openat(int directory, const char *path, int flags, ...) {
    if (!strcmp(path, ".") && (flags & O_DIRECTORY) && (flags & O_TMPFILE) != O_TMPFILE) ++scan_opens;
    if ((flags & O_CREAT) || (flags & O_TMPFILE) == O_TMPFILE) {
        va_list args; va_start(args, flags); mode_t mode = va_arg(args, mode_t); va_end(args);
        return __real_openat(directory, path, flags, mode);
    }
    return __real_openat(directory, path, flags);
}

static double now_ms(void) {
    struct timespec now; assert(clock_gettime(CLOCK_MONOTONIC, &now) == 0);
    uint64_t ns = (uint64_t)now.tv_sec * UINT64_C(1000000000) + (uint64_t)now.tv_nsec;
    return (double)ns / 1000000.0;
}
static int fresh_scan(int directory) {
    return openat(directory, ".", O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
}
static void child_name(int parent, char result[64]) {
    DIR *scan = fdopendir(fresh_scan(parent)); assert(scan != NULL);
    unsigned count = 0; errno = 0;
    for (;;) {
        struct dirent *entry = readdir(scan); if (!entry) break;
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
        assert(!strncmp(entry->d_name, ".ergopti-transfer-", 18));
        assert(strlen(entry->d_name) == 50 && ++count == 1);
        memcpy(result, entry->d_name, 51);
    }
    assert(errno == 0 && count == 1 && closedir(scan) == 0);
}
static void parent_empty(int parent) {
    DIR *scan = fdopendir(fresh_scan(parent)); assert(scan != NULL);
    errno = 0;
    for (;;) {
        struct dirent *entry = readdir(scan); if (!entry) break;
        assert(!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, ".."));
    }
    assert(errno == 0 && closedir(scan) == 0);
}
static struct ergopti_archive_publication *create(const char *parent) {
    struct ergopti_archive_publication *owner = NULL;
    assert(ergopti_archive_publication_create_directory(parent, now_ms() + 1000, &owner) == 0 && owner != NULL);
    return owner;
}
static void complete_cleanup(struct ergopti_archive_publication *owner, int parent) {
    assert(ergopti_archive_publication_cleanup(owner) == 0);
    assert(ergopti_archive_publication_descriptors_closed(owner) == 1);
    assert(ergopti_archive_publication_named_remaining(owner) == 0);
    assert(ergopti_archive_publication_dispose_unpublished(owner) == 0);
    parent_empty(parent);
}

int main(void) {
    if (geteuid() == 0) { fputs("Unprivileged native prerequisite unavailable\n", stderr); return 1; }
    char parent_path[] = "/tmp/ergopti-publication-new.XXXXXX";
    assert(mkdtemp(parent_path) != NULL);
    int parent = open(parent_path, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW); assert(parent >= 0);
    assert(ergopti_archive_publication_abi_version() == 1);
    double before = now_ms(), actual = ergopti_archive_publication_clock_ms(), after = now_ms();
    assert(before <= actual && actual <= after); /* No epoch calibration/floor. */

    /* Real creation+output FD before any network; exact same inode readers. */
    struct ergopti_archive_publication *owner = create(parent_path);
    char child[64]; child_name(parent, child);
    struct stat private_dir; assert(fstatat(parent, child, &private_dir, AT_SYMLINK_NOFOLLOW) == 0);
    assert(S_ISDIR(private_dir.st_mode) && private_dir.st_uid == geteuid() && (private_dir.st_mode & 0777) == 0700);
    int output = -1;
    assert(ergopti_archive_publication_allocate_output(owner, now_ms() + 1000, &output) == 0 && output >= 0);
    struct stat original; assert(fstat(output, &original) == 0);
    assert(S_ISREG(original.st_mode) && original.st_nlink == 0 && original.st_size == 0);
    assert((original.st_mode & 0777) == 0600 && (fcntl(output, F_GETFD) & FD_CLOEXEC));
    int denied = -1;
    assert(ergopti_archive_publication_allocate_output(owner, now_ms() + 1000, &denied) == -1 && denied == -1);
    assert(fcntl(output, F_GETFD) >= 0 && write(output, "abc", 3) == 3);
    assert(ergopti_archive_publication_stage(owner, output, 3, "archive.tar.gz", now_ms() + 1000) == 0);
    assert(ergopti_archive_publication_allocate_reader(owner, now_ms() + 1000, &denied) == -1 && denied == -1);
    assert(close(output) == 0); /* Actual ORIGINAL descriptor retired. */
    assert(ergopti_archive_publication_commit(owner) == 0); /* External timer proof remains wrapper scope. */
    char display[ERGOPTI_ARCHIVE_PUBLICATION_DISPLAY_BYTES];
    assert(ergopti_archive_publication_copy_display_path(owner, display, sizeof(display)) == 0);
    char expected[512]; assert(snprintf(expected, sizeof(expected), "%s/%s/archive.tar.gz", parent_path, child) > 0);
    assert(!strcmp(display, expected));
    char short_copy[2] = {'x', 'x'};
    assert(ergopti_archive_publication_copy_display_path(owner, short_copy, sizeof(short_copy)) == -1 && errno == ERANGE);
    assert(short_copy[0] == '\0');
    for (unsigned i = 0; i < 3; ++i) {
        int reader = -1; assert(ergopti_archive_publication_allocate_reader(owner, now_ms() + 1000, &reader) == 0);
        struct stat read_inode; assert(fstat(reader, &read_inode) == 0);
        assert(read_inode.st_dev == original.st_dev && read_inode.st_ino == original.st_ino && (fcntl(reader, F_GETFD) & FD_CLOEXEC));
        char data[4] = {0}; assert(pread(reader, data, 3, 0) == 3 && !memcmp(data, "abc", 3));
        assert(pread(reader, data, 1, 3) == 0 && close(reader) == 0);
    }
    complete_cleanup(owner, parent);

    /* Actually reuse the original output FD number with a different anonymous
     * inode. The private anchor prevents inode reuse and refuses borrowing. */
    owner = create(parent_path); output = -1;
    assert(ergopti_archive_publication_allocate_output(owner, now_ms() + 1000, &output) == 0);
    child_name(parent, child);
    int replacement_dir = openat(parent, child, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    assert(replacement_dir >= 0);
    int replacement = openat(replacement_dir, ".", O_TMPFILE | O_RDWR | O_CLOEXEC, 0600);
    assert(replacement >= 0 && write(replacement, "abc", 3) == 3);
    assert(close(output) == 0 && dup2(replacement, output) == output);
    assert(ergopti_archive_publication_stage(owner, output, 3, "borrowed", now_ms() + 1000) == -1 && errno == ESTALE);
    assert(fcntl(output, F_GETFD) >= 0); /* The foreign descriptor remains owned by control. */
    assert(close(output) == 0 && close(replacement) == 0 && close(replacement_dir) == 0);
    complete_cleanup(owner, parent);

    /* Expired output allocation cannot publish or return a guessed FD. */
    owner = create(parent_path); output = -1;
    assert(ergopti_archive_publication_allocate_output(owner, now_ms() - 1, &output) == -1 && errno == ETIMEDOUT && output == -1);
    complete_cleanup(owner, parent);

    /* Foreign/noisy entry refuses removal, preserving bytes and directory. */
    owner = create(parent_path); child_name(parent, child);
    int private_fd = openat(parent, child, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW); assert(private_fd >= 0);
    int foreign = openat(private_fd, "foreign", O_CREAT | O_EXCL | O_RDWR | O_CLOEXEC, 0600);
    assert(foreign >= 0 && write(foreign, "keep", 4) == 4);
    assert(ergopti_archive_publication_cleanup(owner) == -1 && errno == ENOTEMPTY);
    assert(ergopti_archive_publication_descriptors_closed(owner) == 0);
    char keep[4]; assert(pread(foreign, keep, 4, 0) == 4 && !memcmp(keep, "keep", 4));
    assert(close(foreign) == 0 && unlinkat(private_fd, "foreign", 0) == 0 && close(private_fd) == 0);
    complete_cleanup(owner, parent); /* Control owns/removes its deliberate entry. */

    /* INJECTED metadata and fdopendir refusals: retry MUST NOT reacquire census
     * while the actual first scan FD is still owned without its close ACK. */
    for (unsigned failure = 0; failure < 2; ++failure) {
        owner = create(parent_path);
        scan_opens = 0;
        if (failure == 0) metadata_after = 2; else refuse_fdopendir = 1;
        assert(ergopti_archive_publication_cleanup(owner) == -1);
        assert(errno == (failure == 0 ? EIO : EMFILE));
        assert(scan_opens == 1 && ergopti_archive_publication_descriptors_closed(owner) == 0);
        assert(ergopti_archive_publication_cleanup(owner) == -1 && errno == EBUSY);
        assert(scan_opens == 1); /* Original bug opened2 and lost exact firstFD. */
        assert(ergopti_archive_publication_retire(owner) == -1 && errno == EBUSY);
        complete_cleanup(owner, parent); /* Actual original scan close now ACKed. */
    }

    assert(close(parent) == 0 && rmdir(parent_path) == 0);
    puts("13 real native revision2 scenarios and2 explicitly injected scan-refusal/retry scenarios completed");
    return 0;
}
