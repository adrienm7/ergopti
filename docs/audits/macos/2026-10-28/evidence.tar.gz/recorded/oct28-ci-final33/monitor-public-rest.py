from pathlib import Path
import subprocess,json,datetime,time,collections
from zoneinfo import ZoneInfo
s=Path('/workspace/scratch/oct28-ci-final33');previous=None
for index in range(120):
 at=datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat();stamp=datetime.datetime.now(ZoneInfo('Europe/Paris')).strftime('%H%M%S');data={}
 for name,url in [('run','https://api.github.com/repos/adrienm7/ergopti/actions/runs/40739753554'),('jobs','https://api.github.com/repos/adrienm7/ergopti/actions/runs/40739753554/jobs?per_page=100')]:
  p=subprocess.run(['curl','-sS','--max-time','20','-w','\n%{http_code}',url],capture_output=True,text=True);body,_,status=p.stdout.rpartition('\n');assert p.returncode==0 and status=='200',(p.returncode,status);data[name]=json.loads(body)
 assert data['run']['head_sha']=='80e8092f2051ad4927dcc880f9585a0e69f6613a';assert len(data['jobs']['jobs'])==data['jobs']['total_count'];data['observed_paris']=at
 (s/('public-snapshot-'+stamp+'.json')).write_text(json.dumps(data,indent=2)+'\n');(s/'public-latest.json').write_text(json.dumps(data,indent=2)+'\n')
 jobs=data['jobs']['jobs'];counts=collections.Counter(j['conclusion']if j['status']=='completed'else j['status']for j in jobs);failed=[{'id':j['id'],'name':j['name'],'failed_steps':[x['name']for x in j['steps']if x['conclusion']=='failure']}for j in jobs if any(x['conclusion']=='failure'for x in j['steps'])];summary={'observed_paris':at,'status':data['run']['status'],'conclusion':data['run']['conclusion'],'jobs':len(jobs),'counts':dict(counts),'failed_steps':failed}
 (s/'public-current-summary.json').write_text(json.dumps(summary,indent=2)+'\n');compact=json.dumps({k:v for k,v in summary.items()if k!='observed_paris'},sort_keys=True)
 if compact!=previous:print(json.dumps(summary),flush=True);previous=compact
 if data['run']['status']=='completed':break
 time.sleep(40)
