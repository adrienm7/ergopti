from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/meta/infra/config/persistence/test_config_boot_read_failure_blocks_persist.ahk')
s=p.read_text(encoding='utf-8-sig');name='_CBRF_SaveFixtureRestoresPendingCaller';start=s.index(name+'() {');end=s.index('\n}\n',start)+2;body=s[start:end]
old='Threw := ""';assert body.count(old)==1;body=body.replace(old,'Threw := "", ContractThrew := false')
old='catch as Err\n\t\t\t\tThrew := Err.Message';assert body.count(old)==1;body=body.replace(old,'catch as Err {\n\t\t\t\tContractThrew := true\n\t\t\t\tThrew := Err.Message\n\t\t\t}')
needle='\t\t\tAssertEqual(FailAfterRefusal ? "CBRF fixture cleanup control after genuine refusal" : "", Threw)';assert body.count(needle)==1;body=body.replace(needle,'\t\t\tAssertEqual(FailAfterRefusal, ContractThrew, "The real cleanup fixture must preserve its actual exception outcome.")\n'+needle)
s=s[:start]+body+s[end:];p.write_text(s,encoding='utf-8-sig',newline='\n')
