local base = assert(arg[1])
for name, path in pairs({
 ["modules.llm.api_entries"] = "static/ergopti_plus/linux/modules/llm/api_entries.lua",
 ["modules.llm.api_remote"] = "static/ergopti_plus/linux/modules/llm/api_remote.lua",
 ["modules.llm.local_server_catalogue"] = "static/ergopti_plus/linux/modules/llm/local_server_catalogue.lua",
}) do
 local owned_path = base .. "/preimages/" .. path
 package.preload[name] = function() return dofile(owned_path) end
end
arg = { "tests.unit.modules.llm.test_api_entries_retired_provider", "retired-provider-source-contract" }
dofile(base .. "/focused.lua")
