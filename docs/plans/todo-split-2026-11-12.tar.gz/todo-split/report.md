# TODO cleanup and per-OS test split (prepared 2026-11-12, not committed)

Run on dev 20b9ef34e (detached worktree, removed afterwards). Apply at wrap-up on the final dev:

    python3 -I <S>/todo-split/apply.py <repo_root>            # base commit = HEAD, used in TODO.md's long-form pointer

Then read its output: "[x] items with no decision" (added by workers tonight, dropped; give any leftover a
residual line in residual_spec.py, then `python3 -I gen_tsv.py` after regenerating keys.txt with keys.py) and
"residual keys not found". Then the usual gates and commit.

## Counts (dev 20b9ef34e)

| File | Lines before | Lines after | Open `- [ ]` |
|---|---|---|---|
| TODO.md | 1783 | 626 | 62 (48 + 14 residuals) |
| TODO-tests-macos.md | (section, 129) | 127 | 57 |
| TODO-tests-windows.md | (section, 131) | 135 | 48 (44 + 4 residuals) |
| TODO-tests-linux.md | (section, 155) | 76 | 9 |

Open checkboxes: 158 before, 176 after = 158 + 18 residual lines. 292 `[x]` items removed, every one decided
(decisions.tsv: 276 drop, 16 residual). Plain `- **...**` bullets (open work in prose form) are kept as they were.

## Sections dropped (no open work left, or stale history)

One-shot Shift, CapsWord, Repeat and recovery, Word-reset and AI-context parity follow-ups; Handoff 2026-11-03;
Branch `wip/layout-composer-responsive`; Branch `wip/gesture-clear-touchpad` (no such remote branch). Emptied
`###` subsections of the WPM/wrap/personal-info, native runtime, migration, end-to-end and deep audits.
« Release 1.0.9 » becomes « Carried over from the 1.0.9 requests » (v1.0.9 is tagged) with its 3 open items.
Header: Updated 2026-11-12, latest stable v1.0.9, long form `git show <base>:TODO.md`, pointer to the 3 files.

## Residual lines added (leftovers found inside `[x]` items)

TODO.md: sign the generated Windows layout DLLs; JIS/ABNT keyboard types (deferred); retire the composer and
the navigation layer editor; pause vs pending dead key (macOS, Linux); macOS owned runtime rebuild (MRT-004
helper, one-hash report rule); macOS `events_typing.rich_text` in clear; Windows immediate-Backspace after
Notepad-paste/terminal expansions; Windows LogsDirPath old-folder rename; Windows hotstring header rows outlive
expiry; Windows restored API entry without a usable key (DPAPI); modifier-chord action labels from the key name
table; Linux keystats `open_db` spawns (~30 ms); decisions pending: one-shot Shift unlimited timeout (OSM-002),
review the coordinator's decisions of 11-11/11-12 (29 « decided by the coordinator » mentions, in the long form).
TODO-tests-windows.md: Linux ledger replay by the Windows reader; AI tooltip « both » mode; layout editor host
real UAC install/uninstall; metrics export and purge.

## Files touched besides the TODO files

`field_todo_coverage.json` (linux, macos: `todo.file` and comment), both coverage tests' describe/doc line,
`test_touchpad_container_proofs.lua` (doc), `field_check_session.lua` (doc), docs/tooling/{linux,macos}-field-
report-coverage.md and windows-maintainer-checks.md (line 3), `collect-macos-field-report.sh`,
`field-todo-summary.py`, `windows-live-checks.cjs` (comments). Generic « TODO « To confirm on … » » wording in
log strings and comments is left (it still names the section; tests assert those log strings).

## Verification on the worktree

- format.cjs --check: Prettier part clean (apply.py runs Prettier on the 4 files); exit 1 only from the Ruff
  version mismatch (0.16.9 installed, 0.15.8 pinned), same on the dev baseline worktree.
- lint-conventions --fail-on-violations: OK.
- Linux infra: 9 failures, the same 9 as the l30 baseline; `test_field_todo_coverage` passes on TODO-tests-linux.md.
- Linux modules: 5 failures, the same as l30.
- macOS meta 1876/0, core 7799/0 (holds infra/field_run/test_field_todo_coverage, 4/4 on TODO-tests-macos.md).
- node test-field-todo-summary, test-linux-field-report-contract, test-macos-field-run-contract: OK.

## Files

apply.py, todo_model.py, residual_spec.py (the judgement), gen_tsv.py, keys.py, keys.txt, decisions.tsv,
residual.tsv, run.log, preview/ (the 4 resulting files), preview.diff, diffstat.txt.
