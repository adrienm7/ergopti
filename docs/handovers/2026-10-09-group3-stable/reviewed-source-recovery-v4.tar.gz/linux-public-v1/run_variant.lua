-- A private module overlay, never a replacement of production/native ports.
local packet=assert(arg[1]);local variant=assert(arg[2]);local name=assert(arg[3])
package.path=variant..'/?.lua;'..variant..'/?/init.lua;'..package.path
arg={packet,name,variant};dofile(packet..'/run.lua')
