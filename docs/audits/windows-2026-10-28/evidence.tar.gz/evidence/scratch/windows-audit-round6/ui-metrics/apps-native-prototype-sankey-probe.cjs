'use strict';
const assert=require('node:assert/strict');
const {loadMetricsAppsPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const failures=[];
for(const host of ['windows','macos','linux'])for(const name of ['Normal.exe','__proto__','constructor','toString','hasOwnProperty']){
 const page=loadMetricsAppsPage(host);
 const manifest={'2026-10-26':{[name]:{chars:1,time:100,app_time_ms:1000,switches_to:{'Peer.exe':3}},'Peer.exe':{chars:1,time:100,app_time_ms:1000,switches_to:{[name]:7}}}};
 const blob={metrics_manifest:manifest,user_categories:{},app_icons:{}};
 if(host==='windows')page.messageListeners.find(e=>e.name==='message').callback({data:{type:'prefetch',blob}});
 else if(host==='linux')page.context.__hostBridgeResponse('metrics_apps_bridge',false,encodeURIComponent(JSON.stringify(blob)));
 else page.context.publishMetricsAppsData(manifest,{}, {},{manifest_revision:1,categories_revision:1});
 const data=page.context.getAggregatedData();page.context.renderSankey(data);
 const svg=page.elements.get('sankey_container').innerHTML;
 const invalid=/NaN|\[object Object\]|undefined/.test(svg);
 console.log(JSON.stringify({host,name,invalid,svg}));if(invalid)failures.push({host,name,svg});
}
assert.deepEqual(failures,[],'actual native app identities keep finite SVG flow coordinates');
