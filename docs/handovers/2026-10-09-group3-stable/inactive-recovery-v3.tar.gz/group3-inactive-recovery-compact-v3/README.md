# Inactive Group3 recovery v3: frozen HOLD and reviewed successor

This separate supplement preserves the actual recovery-v1 and recovery-v2
archives byte-exact, plus the immutable independent v1 HOLD proof. It adds the
two-path simultaneous-v2 repair and its independent source-only SOURCE_CLEAR.
The original archives and their historical PENDING notices are not rewritten.

The seven-path v1 proposal alone is HOLD: its completed buffered cohort could
shadow a newly Hook-owned Reader after legitimate remove/re-add and leave it
open after Stop. The proof capsule retains original/candidate observations on
both Lua ABIs. The ordered v1+v2 source combination is independently SOURCE_CLEAR:
only successful original native-complete cohort publication copies its exact
Reader leases into the retained cleanup map.189/0 both, registered predecessor
188/1, verbatim oldFAIL/newPASS, five causal omissions188/1, six refusal/cancel
barriersPASS and two early-refresh causal omissionsFAIL support that conclusion.
Source clearance does not retroactively validate v1 alone or enable a product.

All proposals remain PRIVATE and excluded from tonight's stable/dev integration.
No kernel/desktop/physical/native success is claimed. Public declarations,
defaults/menu/picker/persistence/Save/copy-tap-to-chord joins remain unimplemented;
native hotplug/full reload/backlog/timers/pointer/state-third-slot qualification
is unrun. All13 Group3 TODO items remain incomplete and16/38 are preserved.
22 remains withdrawn. SDK/Writer source reviews in v1 are separate; no SDK API,
signed-app enrollment or Linux receiving/native currency claim is added here.

Recover into a new private folder. Verify this MANIFEST and each nested archive's
MANIFEST before using it. Obtain exact canonical preimages from the original
seven-path packet in recovery-v2, then apply that packet followed by the v2
two-path patch. V2 preimages are v1 candidate images, not canonical originals.
Never apply both cumulative Writer patches twice. Join every current origin/dev
preimage and preserve other owners' changes. Coordinate G1/G5/fix-linux/G6
ownership, registry/generator/workflow and native enrollment before adoption.

The v2 source-pair archive has five safe regular entries: two preimages, two
postimages and the pinned unchanged Caps sibling. It contains no full checkout,
dependency installation or generated replacement. The review capsule contains
focused raw probe proof and exact terminal fragments; omitted full unit logs and
upstream files remain named by their original hashes. Historical absolute paths
require deliberate private relocation. Source/resource dependency pins and
original tests/oracles are immutable inputs, not authorization to overwrite a
newer checkout. Reuse proportional verify-change gates serially and record
pass/fail/expected-red/skipped/unrun separately before any eventual integration.
