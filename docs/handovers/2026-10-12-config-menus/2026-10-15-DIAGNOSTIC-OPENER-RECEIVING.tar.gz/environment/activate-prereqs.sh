# Source after /workspace/.ergopti-cloud/activate.sh; this prefix is validation-only.
export PATH="/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/sysroot/usr/bin:$PATH"
export LD_LIBRARY_PATH="/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/sysroot/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PKG_CONFIG_PATH="/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig:/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/sysroot/usr/share/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
export ERGOPTI_MANAGED_NATIVE_GIO_SYSROOT="/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/sysroot"
