from pathlib import Path
import hashlib,json,re,subprocess,time
b=Path('/workspace/.ergopti-cloud/resume-personal-topology-fixture-portability')
old=Path('/workspace/.ergopti-cloud/resume-personal-watch-topology')
source=b/'source';producer=source/'static/ergopti_plus/linux/infra/file_watchers.lua';test=source/'static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua'
sha=lambda data:hashlib.sha256(data).hexdigest()
candidate=(b/'candidate-tests.lua').read_bytes();frozen=(b/'tests-83.lua').read_bytes()
expected=re.findall(r'^  ok   (.*)$',(old/'final-candidate-lua.stdout.log').read_text(),re.M);assert len(expected)==83
optional='file_watchers subsecond polling: detects same-second edits with installed posix';assert expected.count(optional)==1
original=(b/'literal-tests.lua').read_bytes();assert candidate.startswith(original)
producer_sha=sha(producer.read_bytes());assert producer_sha=='ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768'
rows=[]
def run(label,runtime,mode,image,expect_received):
 test.write_bytes(image);start=time.monotonic()
 cmd=[runtime,str(b/'runner.lua'),mode]
 stem=f'{label}-{mode}-{runtime}'
 with (b/(stem+'.stdout.log')).open('wb')as out,(b/(stem+'.stderr.log')).open('wb')as err:
  child=subprocess.run(cmd,cwd=source/'static/ergopti_plus/linux',stdout=out,stderr=err,check=False)
 stdout=(b/(stem+'.stdout.log')).read_text();result=json.loads(stdout.splitlines()[-1]);names=re.findall(r'^  ok   (.*)$',stdout,re.M)
 wanted=[name for name in expected if mode!='global-absent'or name!=optional]
 missing=[name for name in wanted if name not in names]
 good=child.returncode==0 and result['failed']==0 and names==wanted and(mode=='available'or result['controlled_posix_refusals']>0)
 row={'label':label,'mode':mode,'runtime':runtime,'command':cmd,'producer_sha256':producer_sha,'test_sha256':sha(image),'child_exit_code':child.returncode,'receiver_exit_code':0 if good else 1,'passed':result['passed'],'failed':result['failed'],'controlled_posix_refusals':result['controlled_posix_refusals'],'expected_subjects':len(wanted),'executed_topology_subjects':sum(name.startswith('(linux-watch-topology)')for name in names),'unchanged_original_optional_unavailable':1 if mode=='global-absent'else 0,'missing_expected_subjects':missing,'failures':result['failures'],'elapsed_seconds':round(time.monotonic()-start,3),'stdout_sha256':sha((b/(stem+'.stdout.log')).read_bytes()),'stderr_sha256':sha((b/(stem+'.stderr.log')).read_bytes())}
 assert sha(producer.read_bytes())==producer_sha and test.read_bytes()==image
 (b/(stem+'-status.json')).write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
 print(json.dumps({key:row[key]for key in ['label','mode','runtime','child_exit_code','receiver_exit_code','passed','failed','executed_topology_subjects']}),flush=True)
 assert good==expect_received,stem
 if not expect_received:assert child.returncode==0 and result['failed']==0 and len(missing)==34 and row['executed_topology_subjects']==0
try:
 for runtime in('lua','luajit'):
  for mode in('topology-absent','global-absent'):run('frozen-v3',runtime,mode,frozen,False)
 for runtime in('lua','luajit'):
  for mode in('available','topology-absent','global-absent'):run('portable-fixture',runtime,mode,candidate,True)
finally:
 test.write_bytes(candidate)
 (b/'portability-matrix.json').write_text(json.dumps({'state':'COMPLETE'if len(rows)==10 else'INCOMPLETE','producer_sha256':producer_sha,'portable_test_sha256':sha(candidate),'frozen_test_sha256':sha(frozen),'original_prefix_bytes':len(original),'rows':rows},indent=2)+'\n')
