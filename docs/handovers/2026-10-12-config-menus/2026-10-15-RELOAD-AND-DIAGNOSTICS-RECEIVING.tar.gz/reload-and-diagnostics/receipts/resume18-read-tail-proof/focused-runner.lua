local driver = assert(arg[1])
local root = "/workspace/ergopti/static/ergopti_plus/"
package.path = root .. driver .. "/?.lua;" .. root .. driver .. "/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
if os.getenv("ERGOPTI_TAIL_PRODUCER") then local path = os.getenv("ERGOPTI_TAIL_PRODUCER"); package.preload["healthcheck.snapshot"] = function() return assert(loadfile(path))() end end
require("tests.unit.ui.test_healthcheck_recent_issues_source")
local results = require("tests.helpers").get_results()
print("FOCUSED_TAIL_RESULTS " .. require("json").encode(results))
os.exit(results.failed == 0 and 0 or 1)
