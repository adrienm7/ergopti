"""Consolidate exact audited results and source custody without source mutation."""

import hashlib
import json
from pathlib import Path
import subprocess

P = Path(__file__).resolve().parent
ROOT = Path("/workspace/worktrees/parity-dead-keys-2026-11-05/shared")
PIN = "f2c3ea43542c985fb20e5f0887976f1c02525341"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (P / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


# Preserve one copy of identical final payloads.
for stem in ("enumeration", "prefix"):
    a = P / f"{stem}-1.json"
    b = P / f"{stem}-2.json"
    assert a.read_bytes() == b.read_bytes()
    a.rename(P / f"{stem}.json")
    b.unlink()
s = json.loads((P / "sweeps.json").read_text())
seen = {}
for sweep in s["sweeps"]:
    for run in sweep["runs"]:
        if run["name"] in ("enumeration", "prefix"):
            name = run["name"]
            run["result"] = {
                "path": f"{name}.json",
                "sha256": sha((P / f"{name}.json").read_bytes()),
            }
        for item in run["outputs"].values():
            f = P / item["path"]
            digest = item["sha256"]
            if digest in seen:
                f.unlink()
                item["path"] = seen[digest]
            else:
                seen[digest] = f.name
write("sweeps.json", s)
enumeration = json.loads((P / "enumeration.json").read_text())
candidates = []
for layout in enumeration["layouts"]:
    for mismatch in layout["native_mismatches"]:
        candidates.append(
            {
                "layout": layout["id"],
                "classification": "new DKS001 inherited prefix collision"
                if layout["id"] == "bepo"
                else "known base_level_only magic limitation",
                "observation": mismatch,
            }
        )
write(
    "candidate-matrix.json",
    {
        "audited_sha": PIN,
        "new_roots": 1,
        "known_magic_contexts": 8,
        "candidates": candidates,
    },
)
write(
    "findings.json",
    {
        "audited_sha": PIN,
        "findings": [
            {
                "id": "DKS001",
                "title": "Inherited Compose descendants prevent explicit Bépo terminal from completing",
                "os": "linux",
                "module": "shared keylayout-to-XKB conversion",
                "priority": "medium",
                "confidence": "high for fingerprinted genuine native component and locale; desktop/application unmeasured",
                "expected": "Bépo cedille in monnaie state completes ₢ after dead_currency/dead_cedilla",
                "observed": "Generated rule exists/conflicts0; actual native status remains COMPOSING after pair; following c yields inherited ₵",
                "root": "Standard trigger reuse plus unconditional locale include imports longer descendants that shadow explicit shorter terminal; both converter implementations share construction.",
                "source_refs": [
                    "static/ergopti/linux/xkb_generation/keylayout_to_xkb.py:725",
                    "static/ergopti/linux/xkb_generation/keylayout_to_xkb.py:838",
                    "static/ergopti/linux/xkb_generation/keylayout_to_xkb.py:877",
                    "static/ergopti_plus/_shared/lua/layouts/xkb_converter.lua:420",
                    "static/ergopti_plus/_shared/lua/layouts/xkb_converter.lua:614",
                ],
                "evidence": [
                    "prefix.json",
                    "prefix_probe.py",
                    "enumeration.json",
                    "sweeps.json",
                ],
                "silent_failure": "Both converters report zero conflicts and generated text includes expected rule; native parser accepts table, but expected output never completes at pair.",
                "regression": "Actual native Compose with inherited locale descendants: assert COMPOSED and ₢ after pair; preserve ordinary locale and no-include/private-trigger positive controls.",
                "deduplication": "One root across Python/Lua and two inherited C/c descendants; excludes eight known magic contexts and DKL001 runtime consumption root.",
                "qualification": "Original converters and genuine installed libxkbcommon table state only; no evdev/desktop/nativeMac/AHK/receiving app.",
            }
        ],
    },
)
write(
    "coverage.json",
    {
        "audited_sha": PIN,
        "registry_layouts": 6,
        "states": 140,
        "converter_levels": 7,
        "unique_wire_expectations": 4391,
        "native_deviations": 9,
        "new_roots": 1,
        "known_magic_contexts": 8,
        "original_python_tests_per_sweep": 51,
        "final_sweeps": 2,
        "runtime_parity": [
            "Python canonical vs Lua5.4/LuaJIT canonical",
            "Python symbols/Compose vs Lua5.4/LuaJIT bytes for each registry layout",
        ],
        "native_controls": 5,
        "qualification": "Reachable explicit converter output expectations over original parsed XML relations; not an independent native macOS oracle, not every unspecified fallback or physical desktop sequence.",
        "excluded_harness": "rows_probe.lua failure due lossy JSON null decoding; not product defect or passing coverage",
        "unmeasured": [
            "active compositor/desktop input layout",
            "receiving app",
            "real keyboard",
            "native macOS action execution",
            "AHK runtime",
            "OS-specific lifecycle races",
        ],
    },
)
paths = {
    "AGENTS.md",
    "static/layouts/registry/index.json",
    "static/ergopti/linux/xkb_generation/keylayout_to_xkb.py",
    "static/ergopti/linux/xkb_generation/data/key_sym.json",
    "static/ergopti/linux/xkb_generation/data/xkb_types.txt",
    "static/ergopti/linux/xkb_generation/data/xkb_symbols.txt",
    "static/ergopti_plus/_shared/lua/layouts/keylayout.lua",
    "static/ergopti_plus/_shared/lua/layouts/xkb_converter.lua",
    "static/ergopti_plus/_shared/modules/layouts/mac_keycodes.json",
    "tools/test/fixtures/keylayout-canonical-dump.lua",
    "tools/test/fixtures/keylayout-xkb-convert.lua",
}
for entry in json.loads((ROOT / "static/layouts/registry/index.json").read_text())[
    "layouts"
]:
    paths.add("static/layouts/registry/" + entry["file"])
    paths.add("static/layouts/registry/" + entry["id"] + "/meta.toml")
for f in (ROOT / "static/ergopti/linux/xkb_generation/tests").glob("*.py"):
    paths.add(str(f.relative_to(ROOT)))
files = []
for rel in sorted(paths):
    raw = (ROOT / rel).read_bytes()
    assert raw == subprocess.check_output(["git", "show", PIN + ":" + rel], cwd=ROOT)
    files.append({"path": rel, "sha256": sha(raw)})
write(
    "source-receipts.json",
    {
        "audited_sha": PIN,
        "verification": "Each listed file matches pinned git object and current checkout byte-for-byte.",
        "files": files,
    },
)
(P / "rows-harness-failure.txt").write_bytes(
    (P / "sweep-1-rows-lua.stderr.txt").read_bytes()
)
keep = {
    "report.md",
    "shared_probe.py",
    "prefix_probe.py",
    "sweep.py",
    "consolidate.py",
    "enumeration.json",
    "prefix.json",
    "sweeps.json",
    "candidate-matrix.json",
    "findings.json",
    "coverage.json",
    "source-receipts.json",
    "rows_probe.lua",
    "rows-harness-failure.txt",
}
for sweep in s["sweeps"]:
    for run in sweep["runs"]:
        for item in run["outputs"].values():
            keep.add(item["path"])
for f in P.iterdir():
    if f.is_file() and f.name not in keep:
        f.unlink()
print("Retained", len(keep), "top-level files plus generated directories")
