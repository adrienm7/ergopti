# Pending minimal heading prerequisite

This new private archive starts from immutable full-group1-gesture packet `88a2659d` on root889091244. No new production changes yet. Reviewed Metrics V3 inert-label primitive must be composed on this check-template API, using root's exact serialized current source. Root publishes all shared records/artifacts.

Existing sensitivity heading uses the shared decorated `i18n.section` form; raw inert label would change its caption. Proposed template support for existing `section_header` delegates the existing decoration policy, with strict no-behavior validation. Existing generic section_header records have no id and two carry established platform reason_key: do not broaden enforcement over old root headers accidentally. Need explicit owner sequencing with Delay's separate compiler captioned-check allowance.

Reserved new sections: gesture_sensitivity_head (decorated heading, inert hint, separator), gesture_change_action (same existing command/callback and readiness). Numeric sensitivity choices and native assignment/persistence/rollback/picker remain original owners. Old caption snapshots independently captured from immutable locale dictionaries before edits, with all 21 source hashes. Complete old assertion retention and real production callback tests remain necessary.
