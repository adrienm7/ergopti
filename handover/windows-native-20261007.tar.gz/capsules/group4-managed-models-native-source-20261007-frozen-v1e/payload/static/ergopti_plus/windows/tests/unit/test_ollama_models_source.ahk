﻿; tests/unit/test_ollama_models_source.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Managed Models Source Regression
; DESCRIPTION:
; Models directory hints cannot replace the exact tuple validated by the source.
; These controls call real source/argument bodies without launching a task.
; ==============================================================================

Test("ollama-models-source-complete-tuple", _OMS_Complete)
Test("ollama-models-source-foreign-directory", _OMS_Foreign)
Test("ollama-models-source-partial-tuple", _OMS_Partial)
Test("ollama-models-source-legacy-unchanged", _OMS_Legacy)
Test("ollama-models-source-worker-transport", _OMS_Transport)

_OMS_Receipt(Models := true) {
	local ticket := "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	local result := Map("ok", true, "schema", 1, "phase", "published",
		"RootPath", "C:\synthetic\runtime", "RootIdentity", "00000001:0000000000000001",
		"Ticket", ticket, "StageIdentity", "00000001:0000000000000002",
		"ManifestHash", "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", "DescriptorIdentity", "00000001:0000000000000003",
		"DescriptorHash", "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc", "RecordCapacity", 12, "PathCapacity", 1000,
		"Executable", "C:\synthetic\runtime\.stage-" . ticket . "\ollama.exe")
	if Models {
		result["ModelsDirectory"] := "C:\synthetic\runtime\model-data"
		result["ModelsFolderName"] := "model-data"
		result["ModelsIdentity"] := "00000001:0000000000000004"
	}
	return result
}
_OMS_Target(Receipt) {
	return Map("executable", Receipt["Executable"], "models_dir", Receipt.Get("ModelsDirectory", "C:\synthetic\legacy-models"),
		"models_folder_name", Receipt.Get("ModelsFolderName", "model-data"))
}
_OMS_Complete() {
	local receipt := _OMS_Receipt(), spec := OllamaRuntimeSourceSpec(receipt)
	local result := spec.ForTarget(_OMS_Target(receipt))
	AssertEqual(result["ModelsDirectory"], "C:\synthetic\runtime\model-data")
	AssertEqual(result["ModelsIdentity"], "00000001:0000000000000004")
	AssertEqual(result["ModelsFolderName"], "model-data")
	AssertFalse(result.Has("Executable"))
}
_OMS_Foreign() {
	local receipt := _OMS_Receipt(), spec := OllamaRuntimeSourceSpec(receipt), target := _OMS_Target(receipt)
	target["models_dir"] := "C:\synthetic\foreign\model-data"
	AssertThrows(() => spec.ForTarget(target), "A valid source cannot authorize another models target.")
	target := _OMS_Target(receipt)
	target.Delete("models_folder_name")
	AssertThrows(() => spec.ForTarget(target), "An acquired policy cannot become a legacy unbound directory.")
}
_OMS_Partial() {
	for name in ["ModelsDirectory", "ModelsFolderName", "ModelsIdentity"] {
		local receipt := _OMS_Receipt()
		receipt.Delete(name)
		AssertThrows(() => OllamaRuntimeSourceSpec(receipt), "Every model tuple member is mandatory once selected.")
	}
	local receipt := _OMS_Receipt()
	receipt["ModelsIdentity"] := "copied-boolean"
	AssertThrows(() => OllamaRuntimeSourceSpec(receipt), "The models identity must keep its native FileID shape.")
}
_OMS_Legacy() {
	local receipt := _OMS_Receipt(false), spec := OllamaRuntimeSourceSpec(receipt)
	local target := Map("executable", receipt["Executable"], "models_dir", "C:\synthetic\legacy-models")
	local result := spec.ForTarget(target)
	AssertEqual(result.Count, 9)
	AssertFalse(result.Has("ModelsDirectory"))
	AssertFalse(result.Has("ModelsIdentity"))
}
_OMS_Transport() {
	local receipt := _OMS_Receipt(), spec := OllamaRuntimeSourceSpec(receipt), target := _OMS_Target(receipt)
	local task := OllamaGuardianTask((*) => 0, spec.ForTarget(target), "C:\synthetic\powershell.exe", [],
		(*) => 0, (*) => true, 1000, 5, 1000)
	local pins := Map()
	for name in ["SourceWorker", "ManagedBridge", "FilesHelper", "PublicationHelper", "ProducerHelper", "NativeModule", "Guardian", "Launcher"]
		pins[name] := Map("path", "C:\synthetic\" . name, "sha256", "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd")
	task.Native := {Pins: pins}
	local args := task._SourceArguments([1, 2, 3, 4]), found := Map()
	loop args.Length - 1 {
		if args[A_Index] == "-ModelsDirectory" || args[A_Index] == "-ModelsFolderName" || args[A_Index] == "-ModelsIdentity"
			found[args[A_Index]] := args[A_Index + 1]
	}
	AssertEqual(found.Count, 3)
	AssertEqual(found["-ModelsDirectory"], receipt["ModelsDirectory"])
	AssertEqual(found["-ModelsFolderName"], receipt["ModelsFolderName"])
	AssertEqual(found["-ModelsIdentity"], receipt["ModelsIdentity"])
	AssertFalse(task.Started)
	AssertFalse(IsObject(task.Source))
	AssertFalse(IsObject(task.Daemon))
}