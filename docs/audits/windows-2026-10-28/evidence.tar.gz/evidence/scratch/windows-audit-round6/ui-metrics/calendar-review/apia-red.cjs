const vm = require('node:vm');
process.env.TZ = 'Pacific/Apia';
const { loadMetricsAppsPage } = require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const page = loadMetricsAppsPage('windows');
vm.runInContext("currentSelectedDate='2011-12-30';currentPeriod='day';", page.context);
const manifest = Object.fromEntries([
  ['2011-12-29', 1], ['2011-12-30', 2], ['2011-12-31', 4],
].map(([key, chars]) => [key, { Editor: { category: 'Productivity', chars, app_time_ms: 60000 } }]));
page.messageListeners.find(x => x.name === 'message').callback({ data: { type: 'prefetch', blob: {
  metrics_manifest: manifest, user_categories: {}, app_icons: {},
} } });
const actual = page.context.getAggregatedData();
console.log(JSON.stringify({ timezone: process.env.TZ, requestedKey: '2011-12-30',
  display: page.context.formatDisplayDate('2011-12-30'), selectedKeys: Object.keys(actual.rich.by_date),
  days: actual.rich.date_range.days, chars: actual.apps.Editor.chars,
  errorLogs: page.diagnostics.filter(x => x.level === 'error'),
}, null, 2));
