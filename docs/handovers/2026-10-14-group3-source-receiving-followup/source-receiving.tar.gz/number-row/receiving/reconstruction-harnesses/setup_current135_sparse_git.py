from pathlib import Path
import subprocess,json,hashlib,os
r=Path('/workspace/ergopti');o=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');scratch=o/'sparse-source-fixtures';scratch.mkdir(exist_ok=True);h=lambda x:hashlib.sha256(x).hexdigest()
common=subprocess.check_output(['git','rev-parse','--git-common-dir'],cwd=r,text=True).strip();objects=(r/common/'objects').resolve();assert objects.is_dir()
recipe=json.loads((r/'tools/diagnostics/fixtures/number-row-native-causal/projection-manifest.original-c15.json.raw').read_text());envelope=json.loads((o/'provisional-current135-envelope.json').read_text());lease=json.loads((r/'tools/diagnostics/fixtures/number-row-native-causal/g5-source-approvals.json.raw').read_text());lease_map={x['path']:x for x in lease['approvals']}
controls=['tools/diagnostics/number_row_native_causal.py','tools/diagnostics/prepare_number_row_native_causal.py','tools/diagnostics/generate_number_row_source_composition.py','tools/diagnostics/test_number_row_source_composition.py'];fixed=['tools/diagnostics/test_number_row_native_causal.py','tools/diagnostics/keyboard_geometry_xctest_receipt.py','tools/diagnostics/tis_evidence_transport.cjs'];fixed += [str(p.relative_to(r)) for p in (r/'tools/diagnostics/fixtures/number-row-native-causal').rglob('*') if p.is_file()]
records=[]
for name,parent,rows in [('legacy69','69fcb820ee5062ad445b93927cc536c543a3a878',recipe['paths']),('current135','70d88b885d45ae616b69f33b9826f76fb1be9493',envelope['sources'])]:
 root=scratch/name;assert not root.exists();root.mkdir();subprocess.run(['git','init','--quiet',str(root)],check=True);(root/'.git/objects/info/alternates').write_text(str(objects)+'\n');subprocess.run(['git','read-tree',parent],cwd=root,check=True)
 for row in rows:
  path=row['path'];data=subprocess.check_output(['git','show',parent+':'+path],cwd=r);expected=(lease_map[path]['sha256'] if name=='legacy69' and path in lease_map else row['sha256']);assert h(data)==expected,(name,path,h(data),expected);target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 # Only actual controller postimages and unchanged independently committed
 # controls/corpus are overlaid. The genuine parent135/99 source inputs stay exact.
 for path in controls+fixed:
  data=(o/'postimages'/path).read_bytes() if path in controls else (r/path).read_bytes();target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=root,input=data,text=False).decode().strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+path],cwd=root,check=True)
 tree=subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip();env=os.environ.copy();env.update({'GIT_AUTHOR_NAME':'Ergopti private source controls','GIT_AUTHOR_EMAIL':'source-controls@invalid','GIT_COMMITTER_NAME':'Ergopti private source controls','GIT_COMMITTER_EMAIL':'source-controls@invalid'})
 commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent],cwd=root,env=env,input='test: provisional '+name+' receiver source fixture\n',text=True).strip();subprocess.run(['git','update-ref','--no-deref','HEAD',commit],cwd=root,check=True);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
 records.append({'fixture':name,'root':str(root),'actual_private_controller_commit':commit,'real_source_parent':parent,'source_rows':len(rows),'controller_postimages':controls,'unchanged_control_and_corpus_paths':fixed,'canonical_object_alternate_read_only':str(objects),'public_adoption':False,'native_execution':'UNRUN'})
(o/'sparse-fixtures.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
