from pathlib import Path
import subprocess,json,shutil
b=Path(__file__).parent
node=shutil.which('node');assert node
results=[]
def run(name,overrides=None,guard=None):
 mapping=b/'guard-variants'/f'{name}.json';mapping.parent.mkdir(exist_ok=True)
 mapping.write_text(json.dumps(overrides or {}))
 cmd=[node,str(b/'run_guard.cjs'),str(mapping)]
 if guard: cmd.append(str(guard))
 p=subprocess.run(cmd,capture_output=True,text=True)
 (b/'evidence'/f'guard-{name}.log').write_text(p.stdout+p.stderr)
 results.append({'case':name,'exit':p.returncode,'command':cmd})
run('original',guard=b/'preimages/tools/test/test-tap-hold-key-catalog-single-source.cjs')
mutants=[('linux/platform/remap/tap_hold_manager.lua','_buffered_ports'),
 ('linux/platform/remap/key_combination_engine.lua','buffered_settings_current'),
 ('linux/platform/remap/key_combination_engine.lua','buffer_request'),
 ('linux/modules/shortcuts/key_combinations.lua','Features.default_for==original_default'),
 ('linux/modules/shortcuts/key_combinations.lua','buffered_settings[configured]'),
 ('linux/modules/shortcuts/key_combinations.lua','options.files == nil and options.route == nil'),
 ('linux/adapters/keyboard_hook.lua','capture_buffered_input'),
 ('linux/ui/menu/key_combinations.lua','Scope.set_chord_settings('),
 ('linux/ui/menu/key_combinations.lua','pairs.chord_pair(pair)'),
 ('linux/infra/key_combinations_scope.lua','pcall(parameters.stop_programs)'),
 ('linux/infra/key_combinations_scope.lua','transaction.apply("key_combinations_chord","configured")'),
 ('linux/infra/key_combinations_scope.lua','tap_section=Shared.TAP_SECTION'),
 ('linux/infra/key_combinations_scope.lua','release_delivery_fence(owner)')]
for i,(rel,token) in enumerate(mutants):
 relative='static/ergopti_plus/'+rel
 p=b/'guard-variants'/f'omission-{i}.txt'
 source=(b/'candidate'/relative).read_text();assert token in source
 p.write_text(source.replace(token,'OMITTED_SOURCE_BOUNDARY'))
 run('omission-'+str(i),{relative:str(p)})
rel='static/ergopti_plus/_shared/modules/features/manifest.toml'
s=(b/'candidate'/rel).read_text()
# Change only the newly declared Linux timing feature's neutral default.
pos=s.index('id = "simultaneous_threshold_ms"');a=s[:pos];z=s[pos:];assert 'default = 100' in z
p=b/'guard-variants/wrong-default.txt';p.write_text(a+z.replace('default = 100','default = 101',1));run('wrong-default',{rel:str(p)})
run('candidate')
(b/'guard-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert results[-1]['exit']==0
assert all(x['exit']!=0 for x in results[:-1]),results
print('GUARD_OLD_RED_CANDIDATE_PASS_14_MUTANTS_RED')
