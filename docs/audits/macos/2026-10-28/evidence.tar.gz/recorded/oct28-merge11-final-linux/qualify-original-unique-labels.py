from pathlib import Path
import datetime,hashlib,json,re,subprocess
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-merge11-final-linux');R=Path('/workspace/ergopti-macos-release-linux')
def load(name):return json.loads((O/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
go=load('go.json');receipt=load('receipt.json');exit_record=load('tool-exit.json');observer=load('residual-observer.json')
assert go['authorized_by_parent'] and receipt['state']=='COMPLETE'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==go['commit']
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()==go['tree']
gates=receipt['gates'];assert len(gates)==15,gates
assert all(row['actual_exit']==0 for row in gates),gates
assert exit_record['actual_child_wait_exit']==0,exit_record
snapshots=receipt['snapshots'];assert snapshots and snapshots[0]['label']=='initial' and snapshots[-1]['label']=='final'
assert len({x['stage_digest'] for x in snapshots})==1
for x in snapshots:
 assert x['commit']==go['commit'] and x['index_tree']==go['tree'] and not x['mismatches'] and not x['unstaged'] and not x['untracked']
assert observer['qualified'] and not observer['live_refs'] and not observer['unreadable_live_same_uid']
inv=load('linux-groups-inventory.log');names=[x['name'] for x in inv['groups']];assert names==['integration','meta','core','infra','input','modules','ui']
expected=set(inv['modules']);assert len(expected)==len(inv['modules']) and len(expected)>=700
seen=set();groups=[];total=0;timing_rows=[]
for group in inv['groups']:
 log=O/('linux-'+group['name']+'.log');text=log.read_text(errors='replace')
 summary=re.findall(r'OVERALL RESULTS:\s*Total modules: (\d+)\s*Passed tests:  (\d+)\s*Failed tests:  (\d+)',text)
 assert len(summary)==1,(group['name'],summary)
 modules,passed,failed=map(int,summary[0]);assert modules>0 and passed>0 and failed==0
 rows=[json.loads(line.split('# lua_timing ',1)[1]) for line in text.splitlines()if line.startswith('# lua_timing ')]
 assert rows and all(x['schema']==1 and x['driver']=='linux' and x['status']=='pass' and x['timing_error']=='' for x in rows)
 assert len({x['id'] for x in rows})==len(rows)
 module_rows=[x for x in rows if x['kind']=='module'];case_rows=[x for x in rows if x['kind']=='case'];assert len(module_rows)+len(case_rows)==len(rows)
 assert len(module_rows)==modules and len(case_rows)==passed
 actual=[x['module'] for x in module_rows];assert len(set(actual))==len(actual) and set(actual)==set(group['modules'])
 assert not seen.intersection(actual);seen.update(actual);total+=passed;timing_rows+=rows
 groups.append({'name':group['name'],'modules':modules,'passed':passed,'failed':failed,'log_sha256':sha(log)})
assert seen==expected
text=(O/'linux-e2e.log').read_text(errors='replace');plans=re.findall(r'^1\.\.(\d+)$',text,re.M);counts=re.findall(r'^# pass (\d+) / (\d+)$',text,re.M);passes=re.findall(r'^  PASS\s+(.+)$',text,re.M)
assert len(plans)==len(counts)==1 and int(plans[0])>0
assert int(plans[0])==int(counts[0][0])==int(counts[0][1])==len(passes)
assert not re.search(r'^  FAIL\s+',text,re.M) and '# All E2E scenarios passed.' in text
assert len(set(passes))==len(passes)
result={'state':'COMPLETE_PASS','qualified_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_commit':go['commit'],'source_tree':go['tree'],'source_phase':'committed','actual_child_wait_exit':0,'all_gates_actual0':True,'gate_count':len(gates),'gates':[{'name':x['name'],'command':x['command'],'actual_exit':x['actual_exit']}for x in gates],'linux_units':{'groups':groups,'passed':total,'failed':0,'modules':len(seen),'unique_modules':len(seen),'canonical_partition_complete':True,'timing_cases_positive_and_complete':True},'linux_e2e':{'planned':int(plans[0]),'passed':len(passes),'failed':0,'unique_names_complete':True,'log_sha256':sha(O/'linux-e2e.log')},'source_physical_invariant':receipt['physical_latest'],'residual_observer':observer,'receipt_sha256':sha(O/'receipt.json'),'tool_exit_sha256':sha(O/'tool-exit.json'),'inventory_sha256':sha(O/'linux-groups-inventory.log'),'native_macos_executed':False,'scope':'Linux unit/integration canonical seven-group partition and POSIX E2E only, to verify shared locale imports in the macOS branch. No desktop/XKB/kernel hardware installation or interactive input qualification is claimed. No source edits, test skips, retry, baseline relaxation or commit.'}
(O/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'state':result['state'],'source_commit':go['commit'],'unit_passed':total,'unit_modules':len(seen),'e2e_passed':len(passes),'gates_actual0':len(gates),'qualification_sha256':sha(O/'qualification.json')}))
