﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
#Warn All, StdOut
global LIVE_DEFAULT_TIMEOUT_MS := 1000
LiveWaitFor(Predicate, What, TimeoutMs := 0) {
	global LIVE_DEFAULT_TIMEOUT_MS
	Limit := TimeoutMs ? TimeoutMs : LIVE_DEFAULT_TIMEOUT_MS
	Started := A_TickCount
	loop {
		Value := Predicate.Call()
		if Value
			return Value
		if A_TickCount - Started > Limit
			throw Error("timed out after " . Limit . " ms waiting for " . What)
		Sleep(10)
	}
}

LiveDriveWindow(Match, Action, TimeoutMs := 0, Optional := false) {
	global LIVE_DEFAULT_TIMEOUT_MS
	State := {Done: false, Error: "", Hwnd: 0, Started: A_TickCount, Optional: Optional,
		Limit: TimeoutMs ? TimeoutMs : LIVE_DEFAULT_TIMEOUT_MS}
	Tick := _LiveDriveTick.Bind(State, Match, Action)
	State.Tick := Tick
	SetTimer(Tick, 40)
	return State
}

_LiveDriveTick(State, Match, Action, *) {
	if State.Done {
		SetTimer(State.Tick, 0)
		return
	}
	if A_TickCount - State.Started > State.Limit {
		if !State.Optional
			State.Error := "no window matched '" . (HasMethod(Match, "Call") ? "the watched window" : Match)
				. "' within " . State.Limit . " ms"
		State.Done := true
		SetTimer(State.Tick, 0)
		return
	}
	Hwnd := HasMethod(Match, "Call") ? Match.Call() : WinExist(Match)
	if !Hwnd
		return
	SetTimer(State.Tick, 0)
	State.Hwnd := Hwnd
	try Action.Call(Hwnd)
	catch as Err
		State.Error := Err.Message
	State.Done := true
}

LiveAwaitDrive(State, What) {
	LiveWaitFor(() => State.Done, What, State.Limit + 5000)
	if State.Error != ""
		throw Error(What . ": " . State.Error)
}

R29_Action(Observation, Mode, Hwnd) {
    Observation.Calls += 1
    Observation.Hwnd := Hwnd
    if Mode == "empty"
        throw Error("")
    if Mode == "message"
        throw Error("owned action refusal")
}
Mode := A_Args[1]
Window := Gui("-DPIScale", "Owned live harness action")
Observation := {Calls: 0, Hwnd: 0}
R29_DriveState := 0
try {
    Window.Show("Hide w150 h100")
    R29_DriveState := LiveDriveWindow(() => Window.Hwnd, R29_Action.Bind(Observation, Mode), 1000)
    Threw := false
    try LiveAwaitDrive(R29_DriveState, "the actual driven window")
    catch Error {
        Threw := true
    }
    if Observation.Calls != 1 || Observation.Hwnd != Window.Hwnd || !R29_DriveState.Done
        throw Error("The actual timer action must complete once on its exact native window.")
    if Threw != (Mode != "healthy")
        throw Error("The public live await must reject an action failure even with an empty message.")
    FileAppend("PASS live-action " . Mode . "`n", "*", "UTF-8-RAW")
    ExitApp(0)
} catch Error as Failure {
    FileAppend("FAIL live-action " . Mode . ": " . Failure.Message . "`n", "*", "UTF-8-RAW")
    ExitApp(1)
} finally {
    if IsObject(R29_DriveState)
        SetTimer(R29_DriveState.Tick, 0)
    Window.Destroy()
}
