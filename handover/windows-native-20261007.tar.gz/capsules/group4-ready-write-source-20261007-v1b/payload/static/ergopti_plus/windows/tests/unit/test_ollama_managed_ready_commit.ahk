﻿; tests/unit/test_ollama_managed_ready_commit.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Managed Ready Commit Recording Controls
; DESCRIPTION:
; Runs the real coordinator/ticket/actor hold and persistence callback bodies
; against controlled sources. No config lease, file write, process or TCP evidence
; is manufactured by these recording controls; native receiving remains separate.
; ==============================================================================

Test("ollama-ready-write-live-after-startup-deadline", _OMRW_Healthy)
Test("ollama-ready-write-exact-post-source", _OMRW_PostSource)
Test("ollama-ready-write-selection-before-stop", _OMRW_Before)
Test("ollama-ready-write-selection-after-stop", _OMRW_After)
Test("ollama-ready-write-timer-refusal-retains-owner", _OMRW_TimerRefusal)
Test("ollama-ready-write-forged-ticket-refused", _OMRW_Forged)
Test("ollama-ready-write-resume-reentry-revokes", _OMRW_ResumeReentry)
Test("ollama-ready-write-callback-persistence-order", _OMRW_CallbackOrder)
Test("ollama-ready-write-actual-writer-refusal", (*) => _OMRW_CallbackOrder(false))
Test("ollama-ready-write-sealed-source-independent", _OMRW_IndependentSeal)

_OMRW_World() {
	local world := _OMC_World()
	world.OldText := Chr(0xFEFF) . "[llm]`nenabled = false`n"
	world.NewText := Chr(0xFEFF) . "[llm]`nenabled = true`n"
	world.Live["source"]["bytes"] := _OllamaManagedReadyUtf8Bytes(world.OldText)
	world.Owner.Session.Archive := 0
	AssertTrue(world.Owner.Start(world.Plan))
	world.Owner.Record["phase"] := "ready"
	world.Actor := world.Owner.Session.Runtime.Owner.Record["guardian"]
	world.Actor.ReadyWriteHold := 0
	world.Actor.Busy := false
	world.Actor.Building := false
	world.Actor.PollMilliseconds := 5
	world.Actor.Timer := (*) => 0
	world.Actor.TimerFn := ObjBindMethod(world, "Timer")
	world.Expected := Map("path", world.Live["source"]["path"],
		"bytes", _OllamaManagedReadyUtf8Bytes(world.NewText))
	return world
}

_OMRW_Acknowledge(World, Ticket) {
	AssertTrue(World.Owner.SealReadyWrite(Ticket, World.Expected))
	AssertTrue(World.Owner.AcknowledgeReadyWrite(Ticket, World.Expected))
	World.Live["enabled"] := true
	World.Live["source"]["bytes"] := _OllamaManagedReadyUtf8Bytes(World.NewText)
}

_OMRW_Healthy() {
	local world := _OMRW_World()
	try {
		local record := world.Owner.Record, deadline := record["deadline"], ticket := world.Owner.BeginReadyWrite()
		AssertTrue(ticket is OllamaManagedReadyWriteTicket)
		AssertFalse(ticket.HasOwnProp("Row"))
		AssertFalse(world.Owner.ReadyForUse(), "An owned write cannot admit inference.")
		AssertTrue(world.RuntimeOwned)
		AssertEqual(0, world.Stops)
		_OMRW_Acknowledge(world, ticket)
		world.Now := deadline + 1000
		AssertTrue(world.Owner.FinishReadyWrite(ticket))
		AssertTrue(world.Owner.Record == record)
		AssertTrue(world.RuntimeOwned)
		AssertEqual(0, world.Stops, "Its own durable enable does not stop the exact daemon.")
		AssertEqual(deadline, record["deadline"])
		AssertTrue(world.Owner.ReadyForUse())
		AssertFalse(world.Owner.FinishReadyWrite(ticket), "A consumed ticket cannot replay.")
	} finally world.Drain()
}

_OMRW_PostSource() {
	local world := _OMRW_World()
	try {
		local ticket := world.Owner.BeginReadyWrite(), wrong := world.Expected.Clone()
		AssertTrue(world.Owner.SealReadyWrite(ticket, world.Expected))
		wrong["bytes"] := _OllamaManagedReadyUtf8Bytes(world.NewText . "; foreign`n")
		AssertFalse(world.Owner.AcknowledgeReadyWrite(ticket, wrong))
		AssertFalse(world.Owner.FinishReadyWrite(ticket))
		AssertTrue(world.Owner.Record["cancelled"])
		AssertTrue(world.RuntimeOwned, "A failed observation cannot discard physical debt.")
	} finally world.Drain()
}

_OMRW_Before() {
	local world := _OMRW_World()
	try {
		world.Live["model"] := "foreign:latest"
		AssertFalse(world.Owner.BeginReadyWrite())
		AssertTrue(world.Owner.Record["cancelled"])
		AssertTrue(world.Stops > 0)
		AssertTrue(world.RuntimeOwned)
	} finally world.Drain()
}

_OMRW_After() {
	for field in ["backend", "model", "origin", "generation", "paused", "blocked"] {
		local world := _OMRW_World()
		try {
			local ticket := world.Owner.BeginReadyWrite()
			_OMRW_Acknowledge(world, ticket)
			world.Live[field] := world.Live[field] is String ? "foreign" : field == "generation" ? 8 : true
			AssertFalse(world.Owner.FinishReadyWrite(ticket), "Changed " . field . " cannot refresh authority.")
			AssertTrue(world.Owner.Record["cancelled"])
			AssertTrue(world.Stops > 0)
			AssertTrue(world.RuntimeOwned)
		} finally world.Drain()
	}
}

_OMRW_TimerRefusal() {
	local world := _OMRW_World()
	try {
		; Other observer cancellations succeed, isolating the actual actor ACK.
		world.Actor.TimerFn := (Callback, Period) => false
		AssertFalse(world.Owner.BeginReadyWrite())
		AssertTrue(world.Actor.ReadyWriteHold is OllamaManagedReadyWriteTicket)
		AssertTrue(world.Owner.Record["cancelled"])
		AssertTrue(world.Owner.HasNativeOwner())
		AssertTrue(world.RuntimeOwned)
	} finally {
		world.Actor.TimerFn := ObjBindMethod(world, "Timer")
		world.Drain()
	}
}

_OMRW_Forged() {
	local world := _OMRW_World()
	try {
		local ticket := world.Owner.BeginReadyWrite(), forged := OllamaManagedReadyWriteTicket(world.Owner)
		AssertFalse(world.Owner.SealReadyWrite(forged, world.Expected))
		AssertFalse(world.Owner.AcknowledgeReadyWrite(forged, world.Expected))
		AssertFalse(world.Owner.FinishReadyWrite(forged))
		AssertTrue(world.Actor.ReadyWriteHold == ticket)
		AssertTrue(world.RuntimeOwned)
		world.Owner.AbortReadyWrite(ticket)
	} finally world.Drain()
}

_OMRW_ResumeReentry() {
	local world := _OMRW_World()
	try {
		local ticket := world.Owner.BeginReadyWrite()
		_OMRW_Acknowledge(world, ticket)
		world.Actor.TimerFn := (Callback, Period) => (Period < 0 ? world.Live["model"] := "foreign" : 0, true)
		AssertFalse(world.Owner.FinishReadyWrite(ticket))
		AssertTrue(world.Owner.Record["cancelled"])
		AssertTrue(world.Stops > 0)
		AssertTrue(world.RuntimeOwned)
	} finally world.Drain()
}

_OMRW_CallbackOrder(WriterSucceeds := true) {
	local world := _OMRW_World(), order := [], owner := 0
	try {
		local source_path := world.Live["source"]["path"]
		local ports := Map("build", (Path, Updates) => (order.Push("build"),
			Map("status", "ok", "kind", "rendered", "source_present", 1,
				"source_content", world.OldText, "content", world.NewText)),
			"writer", (Path, Updates) => (order.Push("write"), WriterSucceeds),
			"read_source", () => (order.Push("read-after-write"), world.Expected),
			"publish", (FeatureState, Candidate) => (order.Push("publish"),
				world.Live["enabled"] := Candidate["enabled"],
				world.Live["source"]["bytes"] := _OllamaManagedReadyUtf8Bytes(world.NewText), true),
			"apply", (Candidate, ShowUi) => (order.Push("apply"), AssertTrue(world.Owner.ReadyForUse()), true))
		owner := OllamaManagedReadyCommit(world.Owner, ports)
		owner.Committing := true
		local candidate := Map("backend", "ollama", "model", "gemma3:4b", "enabled", false)
		AssertTrue(owner._Mutate(candidate))
		local ticket := owner._Prepare(candidate)
		AssertTrue(ticket is OllamaManagedReadyWriteTicket)
		local written := owner._Write(source_path, [])
		AssertEqual(WriterSucceeds, written)
		if !WriterSucceeds {
			AssertEqual(2, order.Length)
			AssertFalse(owner._Publish(Map(), candidate, ticket))
			AssertFalse(owner._Apply(candidate))
			AssertFalse(owner.Completed)
			AssertTrue(world.RuntimeOwned)
			return
		}
		AssertTrue(owner._Publish(Map(), candidate, ticket))
		AssertTrue(owner._Apply(candidate))
		AssertTrue(owner.Completed)
		AssertEqual("build,write,read-after-write,publish,apply", _OMRW_Join(order))
		AssertEqual(0, world.Stops)
	} finally {
		if IsObject(owner) && !owner.Completed && owner.Ticket is OllamaManagedReadyWriteTicket
			world.Owner.AbortReadyWrite(owner.Ticket)
		world.Drain()
	}
}

_OMRW_Join(Items) {
	local result := ""
	for item in Items
		result .= (result == "" ? "" : ",") . item
	return result
}

_OMRW_IndependentSeal() {
	local world := _OMRW_World()
	try {
		local ticket := world.Owner.BeginReadyWrite()
		AssertTrue(world.Owner.SealReadyWrite(ticket, world.Expected))
		NumPut("UChar", 99, world.Expected["bytes"], 0)
		local actual := Map("path", world.Expected["path"], "bytes", _OllamaManagedReadyUtf8Bytes(world.NewText))
		AssertTrue(world.Owner.AcknowledgeReadyWrite(ticket, actual), "The sealed expected byte image is independent.")
		world.Live["enabled"] := true
		world.Live["source"]["bytes"] := _OllamaManagedReadyUtf8Bytes(world.NewText)
		AssertTrue(world.Owner.FinishReadyWrite(ticket))
	} finally world.Drain()
}
