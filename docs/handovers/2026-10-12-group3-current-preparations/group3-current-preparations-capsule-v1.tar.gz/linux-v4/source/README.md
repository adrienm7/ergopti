# Future V4 adoption cut — source only, custody pending

Five paths against prospective committed merge tree8261a837: four exact reviewed
V4 code/test postimages plus one append within item93 of its actual merged TODO.
The code preimages are byte-exact all previous reviews; tests preserve every
original assertion/body. The TODO whole inverse is exact, preserving Snapshot91,
new G6 notes, every foreign block and headings. No item is removed. Focused58
controls means separate55 and3 executed cohorts; genuine filesystem8 is distinct
from physical input/output and whole-driver/native installed qualification.

Actual private git apply/check and reverse/check completed, with every post and
whole inverse verified. Only private finite scratch files changed; no canonical
source/index/refs, native/tests/generator/API actions occurred. G6 generic helper
and exact-unit cuts are granted in6116082222; final Loader/unit handback remains
pending. Parent may adopt only after that explicit grant and current gate terminal.
