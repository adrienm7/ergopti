from pathlib import Path
import hashlib,json,subprocess,os,re
B=Path('/workspace/.ergopti-cloud/reviews/linux93-native-supplement-v2-independent'); B.mkdir(mode=0o700)
A=Path('/workspace/.ergopti-cloud/continuation-2026-10-09/linux93-simultaneous-native-supplement-v2')
H=Path('/workspace/.ergopti-cloud/reviews/linux93-native-supplement-independent')
Q=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-current-g1-union-independent/projection')
R=Q.parent/'review-scripts/run.lua'
def digest(x): return hashlib.sha256(x).hexdigest()
def verify(folder):
 rows=[]
 for line in (folder/'SHA256SUMS').read_text().splitlines():
  value,name=line.split('  ',1); p=Path(name); assert not p.is_absolute() and '..' not in p.parts
  actual=digest((folder/p).read_bytes()); assert value==actual,(folder,name); rows.append({'path':name,'sha256':value})
 return rows
before={'author':verify(A),'original_HOLD':verify(H),'union_review':verify(Q.parent)}
old=(H/'original-supplement.lua').read_bytes();new=(A/'static/ergopti_plus/linux/tests/hardware/run_simultaneous_configuration_real.lua').read_bytes()
assert digest(old)=='b358fb0f76d38acbdc11fbe3242970bb25e6b12bd6467dc9d38c0d237d945cd7'
assert digest(new)=='6ecc2719d142d4108a3a2ea4303d5f78f9589ff21125ca1298408fa97fb0ef4e'
assert old.count(b'caps_lock_then_tab')==5 and new.count(b'tab_then_caps_lock')==5
assert old.replace(b'caps_lock_then_tab',b'tab_then_caps_lock')==new
assert new.replace(b'tab_then_caps_lock',b'caps_lock_then_tab')==old
assert b'\r' not in new
pins=json.loads((H/'source-pins.json').read_text())
for pin in pins: assert digest((Q/pin['path']).read_bytes())==pin['sha256']
(B/'source-pins.json').write_bytes((H/'source-pins.json').read_bytes())
(B/'original-supplement.lua').write_bytes(old); (B/'candidate-supplement.lua').write_bytes(new)
(B/'author-receipt.json').write_bytes((A/'receipt.json').read_bytes());(B/'author-SHA256SUMS').write_bytes((A/'SHA256SUMS').read_bytes()); (B/'direction-only.diff').write_bytes((A/'direction-only.diff').read_bytes())
# Use the actual candidate saved-file expression within the previously reviewed
# original software constructor/copy/reload/pause graph. No native receipts.
source=(H/'canonical-direction-software-only.lua').read_text(); candidate=new.decode()
start=candidate.index('\tassert(Files.write(config_path,');end=candidate.index('\n\tassert(Files.write(tap_path,',start)
write_block=candidate[start:end].lstrip('\t')
oldline=next(row for row in source.splitlines() if row.startswith('assert(Files.write(config_path,'))
assert oldline.count('tab_then_caps_lock')==2
source=source.replace(oldline,write_block)
(B/'candidate-actual-saved-expression-software-only.lua').write_text(source)
(B/'original-symmetric.lua').write_bytes((H/'original-symmetric.lua').read_bytes())
(B/'original-run-native-subreaper.py').write_bytes((H/'original-run-native-subreaper.py').read_bytes())
env=os.environ.copy();env['TMPDIR']='/tmp';env['PATH']='/workspace/.ergopti-cloud/bin:'+env['PATH'];results=[]
def run(case,cmd,expected,native=False):
 cp=subprocess.run(cmd,cwd=Q/'static/ergopti_plus/linux',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
 (B/(case+'.log')).write_bytes(cp.stdout)
 row={'case':case,'command':cmd,'exit':cp.returncode,'expected_exit':expected,'native_executed':native,'stdout_sha256':digest(cp.stdout),'output':cp.stdout.decode(errors='replace')};results.append(row);print(case,cp.returncode,row['output'][-1000:],flush=True);assert cp.returncode==expected
run('original-symmetric', ['luajit',str(R),str(Q),str(B/'original-symmetric.lua')],1)
run('candidate-software-functional',['luajit',str(R),str(Q),str(B/'candidate-actual-saved-expression-software-only.lua')],0)
for abi in ['luajit','lua5.4']:run(abi+'-syntax',[abi,'-e','assert(loadfile("'+str(B/'candidate-supplement.lua')+'"))'],0)
run('original-wrapper-environment-refusal',['python3',str(B/'original-run-native-subreaper.py'),'luajit',str(B/'candidate-supplement.lua')],2)
assert verify(A)==before['author'] and verify(H)==before['original_HOLD'] and verify(Q.parent)==before['union_review']
(B/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(B/'preservation.json').write_text(json.dumps({'status':'PASS','five_occurrences_only':True,'full_reverse_exact':True,'source_dependencies_exact':pins,'preserved_seals':{k:len(v) for k,v in before.items()},'seal_rows':before,'native_scenarios_executed':0,'devices_created':False,'kernel_UNRUN':True},indent=2)+'\n')
