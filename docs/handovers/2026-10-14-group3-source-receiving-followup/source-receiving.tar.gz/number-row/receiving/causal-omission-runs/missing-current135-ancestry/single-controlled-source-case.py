"""Source-composition controls keep the original fifty-one-case oracle intact.

Legacy controls use the real published strict69 approval and actual Git inputs.
The finite current135 controls use genuine published source, real private
controller commits and an explicitly provisional envelope pending independent
receiver review. No published commit, GHA receipt or native transcript is faked.
Source composition/projection digests are provenance, never approval or native
qualification. Original53 controls and historical/native role boundaries remain.
"""

import argparse
import copy
import hashlib
from types import ModuleType
import json
from pathlib import Path
import shutil
import sys
import tempfile
import subprocess
import unittest

parser = argparse.ArgumentParser(description=__doc__)
for name in (
    "repo",
    "recipe",
    "approval",
    "composition",
    "projection",
    "original-producer",
    "receiver",
    "positive-receiver",
    "receiving",
    "controls-projection",
):
    parser.add_argument("--" + name, type=Path, required=True)
for name in ("head", "approval-sha256", "composition-sha256"):
    parser.add_argument("--" + name, required=True)
parser.add_argument("--current-build", action="store_true")
parser.add_argument("--source-basis", type=Path)
parser.add_argument("--canonical-repo", type=Path)
args, unittest_args = parser.parse_known_args()
if not args.receiving.is_dir() or args.receiving.is_symlink():
    raise ValueError("owned receiving directory required")
admitted_images = {}
for name, path in (
    ("keyboard_geometry_xctest_receipt", args.positive_receiver),
    ("number_row_composition_under_test", args.receiver),
):
    expected = (
        "9cef4f9256f3604ac07d710d77c95424718012f23c6a8b472f9e5936253ac094"
        if name == "keyboard_geometry_xctest_receipt"
        else "b858e420b3ff3dda67db781ae6a6b6ac34700143d881224bc551096b87125333"
    )
    data = path.read_bytes()
    if path.is_symlink() or not path.is_file() or hashlib.sha256(data).hexdigest() != expected:
        raise ValueError("explicit reviewed test dependency required")
    admitted_images[name] = data
positive_name = "keyboard_geometry_xctest_receipt"
missing = object()
previous = sys.modules.get(positive_name, missing)
positive = ModuleType(positive_name)
positive.__file__ = str(args.positive_receiver.resolve())
subject = ModuleType("number_row_composition_under_test")
subject.__file__ = str(args.receiver.resolve())
try:
    sys.modules[positive_name] = positive
    exec(compile(admitted_images[positive_name], positive.__file__, "exec"), positive.__dict__)
    exec(
        compile(admitted_images["number_row_composition_under_test"], subject.__file__, "exec"),
        subject.__dict__,
    )
finally:
    if previous is missing:
        sys.modules.pop(positive_name, None)
    else:
        sys.modules[positive_name] = previous
baseline = subject._closed_json(args.composition, args.composition_sha256)
approval = subject._closed_json(args.approval, args.approval_sha256)
if args.current_build:
    if args.source_basis is None or args.canonical_repo is None:
        raise ValueError("explicit independently received source basis required")
    active_auxiliary_path = approval["sources"][0]["path"]
else:
    active_auxiliary_path = (
        approval["approvals"][0]["path"] if "approvals" in approval else subject.AUXILIARY_PATH
    )
original = args.original_producer.read_bytes()


class CompositionControls(unittest.TestCase):
    def setUp(self):
        self.owned = tempfile.TemporaryDirectory(dir=args.receiving)
        self.root = Path(self.owned.name)

    def tearDown(self):
        self.owned.cleanup()

    def contract_refuses(self, mutation):
        # Mutated inputs are explicitly negative controlled records. They never
        # replace the real independently reviewed baseline or authorize a run.
        changed = copy.deepcopy(baseline)
        mutation(changed)
        with self.assertRaises(ValueError):
            subject._composition_contract(args.recipe, args.approval, args.approval_sha256, changed)

    def projection_refuses(self, mutation):
        # One method can exercise multiple independent refusal variants.
        parent = Path(tempfile.mkdtemp(dir=self.root))
        projected = parent / "projection"
        shutil.copytree(args.projection, projected)
        mutation(projected)
        with self.assertRaises(ValueError):
            subject.verify_composed_projection(
                args.repo,
                args.head,
                args.recipe,
                args.approval,
                args.approval_sha256,
                args.composition,
                args.composition_sha256,
                projected,
                original,
            )

    def approval_refuses(self, mutation, join_git=False):
        changed = copy.deepcopy(approval)
        mutation(changed["approvals"][0] if "approvals" in changed else changed)
        path = self.root / "negative-approval.json"
        data = json.dumps(changed).encode()
        path.write_bytes(data)
        with self.assertRaises(ValueError):
            legacy, rejected, composition = subject._composition_contract(
                args.recipe, path, hashlib.sha256(data).hexdigest()
            )
            if join_git:
                subject._current_composition_inputs(
                    args.repo, args.head, legacy, rejected, composition
                )

    def test_actual_approved_current_composition(self):
        proof = subject.verify_composed_projection(
            args.repo,
            args.head,
            args.recipe,
            args.approval,
            args.approval_sha256,
            args.composition,
            args.composition_sha256,
            args.projection,
            original,
        )
        self.assertEqual(proof["actual_commit"], args.head)
        self.assertEqual(len(proof["paths"]), 99)
        self.assertIs(proof["counterfactual_git_blob"], None)

    def test_historical_branch_still_refuses_new_auxiliary(self):
        with self.assertRaises(ValueError):
            subject.verify_projection(args.recipe, args.projection, original)

    def test_missing_path_refused(self):
        self.contract_refuses(lambda manifest: manifest["paths"].pop())

    def test_duplicate_path_refused(self):
        self.contract_refuses(
            lambda manifest: manifest["paths"].append(copy.deepcopy(manifest["paths"][0]))
        )

    def test_unknown_path_refused(self):
        self.contract_refuses(lambda manifest: manifest["paths"][0].update(path="unadmitted.swift"))

    def test_wrong_auxiliary_digest_refused(self):
        self.contract_refuses(
            lambda manifest: next(
                row for row in manifest["paths"] if row["path"] == active_auxiliary_path
            ).update(sha256="0" * 64)
        )

    def test_wrong_auxiliary_blob_refused(self):
        self.contract_refuses(
            lambda manifest: next(
                row for row in manifest["paths"] if row["path"] == active_auxiliary_path
            ).update(git_blob="0" * 40)
        )

    def test_second_auxiliary_or_package_change_refused(self):
        self.contract_refuses(
            lambda manifest: next(
                row for row in manifest["paths"] if row["path"].endswith("/Package.swift")
            ).update(sha256="0" * 64)
        )

    def test_producer_change_refused(self):
        self.contract_refuses(
            lambda manifest: next(
                row
                for row in manifest["paths"]
                if row["path"].endswith("/NumberRowSourceProbe.swift")
            ).update(sha256="0" * 64)
        )

    def test_test_and_embedded_glyph_oracle_change_refused(self):
        self.contract_refuses(
            lambda manifest: next(
                row
                for row in manifest["paths"]
                if row["path"].endswith("/NumberRowSourceProbeTests.swift")
            ).update(sha256="0" * 64)
        )

    def test_stale_source_commit_refused(self):
        with self.assertRaises(ValueError):
            subject.verify_composed_projection(
                args.repo,
                json.loads(args.recipe.read_bytes())["original_head"],
                args.recipe,
                args.approval,
                args.approval_sha256,
                args.composition,
                args.composition_sha256,
                args.projection,
                original,
            )

    def test_unknown_approval_digest_refused(self):
        with self.assertRaises(ValueError):
            subject._composition_contract(args.recipe, args.approval, "0" * 64, baseline)

    def test_wrong_original_blob_refused(self):
        self.approval_refuses(lambda record: record.update(original_git_blob="0" * 40))

    def test_wrong_original_digest_refused(self):
        self.approval_refuses(lambda record: record.update(original_sha256="0" * 64))

    def test_foreign_auxiliary_approval_refused(self):
        self.approval_refuses(lambda record: record.update(path="unadmitted.swift"))

    def test_wrong_new_committed_blob_refused(self):
        self.approval_refuses(lambda record: record.update(git_blob="0" * 40), join_git=True)

    def test_wrong_new_committed_digest_refused(self):
        self.approval_refuses(lambda record: record.update(sha256="0" * 64), join_git=True)

    def test_wrong_published_source_commit_refused(self):
        self.approval_refuses(
            lambda record: record.update(
                published_source_commit=json.loads(args.recipe.read_bytes())["original_head"]
            ),
            join_git=True,
        )

    def test_unclaimed_approval_fields_refused(self):
        self.approval_refuses(lambda record: record.update(native_ready=True))

    def test_altered_projection_refused(self):
        self.projection_refuses(
            lambda root: (root / active_auxiliary_path).write_bytes(b"unadmitted source\n")
        )

    def test_extra_projection_path_refused(self):
        self.projection_refuses(lambda root: (root / "unadmitted.swift").write_bytes(b"// extra\n"))

    def test_missing_projection_path_refused(self):
        self.projection_refuses(lambda root: (root / active_auxiliary_path).unlink())

    def test_source_symlink_refused(self):
        def replace(root):
            item = root / active_auxiliary_path
            item.unlink()
            item.symlink_to(args.repo / active_auxiliary_path)

        self.projection_refuses(replace)

    def test_second_or_missing_omission_refused(self):
        path = json.loads(args.recipe.read_bytes())["permitted_omission"]["path"]
        self.projection_refuses(lambda root: (root / path).write_bytes(original))
        self.projection_refuses(
            lambda root: (root / path).write_bytes(
                original.replace(subject.NEEDLE, b"true", 1) + b"\n// second alteration\n"
            )
        )

    def approval_list_refuses(self, mutation, join_git=False):
        changed = copy.deepcopy(approval)
        if "approvals" not in changed:
            raise ValueError("new list controls require genuine independently reviewed list")
        mutation(changed)
        path = self.root / "negative-approval-list.json"
        data = json.dumps(changed).encode()
        path.write_bytes(data)
        with self.assertRaises(ValueError):
            legacy, rejected, composition = subject._composition_contract(
                args.recipe, path, hashlib.sha256(data).hexdigest()
            )
            if join_git:
                subject._current_composition_inputs(
                    args.repo, args.head, legacy, rejected, composition
                )

    def test_received_two_row_g5_source_list(self):
        self.assertEqual(approval["role"], "independently-reviewed-committed-source-inputs")
        self.assertEqual(len(approval["approvals"]), 2)
        self.assertEqual(
            {row["path"] for row in approval["approvals"]},
            {
                "static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/RemapLeaseWorker.swift",
                "static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/RemapLeaseWorkerTests.swift",
            },
        )
        proof = subject.verify_composed_projection(
            args.repo,
            args.head,
            args.recipe,
            args.approval,
            args.approval_sha256,
            args.composition,
            args.composition_sha256,
            args.projection,
            original,
        )
        self.assertEqual(
            proof["approved_auxiliary_sources"],
            [
                {
                    "path": row["path"],
                    "published_source_commit": row["published_source_commit"],
                    "git_blob": row["git_blob"],
                    "sha256": row["sha256"],
                    "source_review_sha256": row["source_review_sha256"],
                }
                for row in approval["approvals"]
            ],
        )
        historical = json.loads(args.recipe.read_bytes())["paths"]
        approved_paths = {row["path"] for row in approval["approvals"]}
        self.assertEqual(
            [row for row in baseline["paths"] if row["path"] not in approved_paths],
            [row for row in historical if row["path"] not in approved_paths],
        )
        self.assertEqual(
            len([row for row in baseline["paths"] if row["path"] not in approved_paths]), 97
        )

    def test_empty_source_list_refused(self):
        self.approval_list_refuses(lambda envelope: envelope.update(approvals=[]))

    def test_duplicate_source_list_row_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope["approvals"].append(copy.deepcopy(envelope["approvals"][0]))
        )

    def test_four_source_list_rows_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope.update(approvals=envelope["approvals"] * 2)
        )

    def test_unknown_envelope_field_refused(self):
        self.approval_list_refuses(lambda envelope: envelope.update(native_ready=True))

    def test_boolean_envelope_schema_refused(self):
        self.approval_list_refuses(lambda envelope: envelope.update(schema=True))

    def test_missing_g5_source_approval_refuses_actual_input(self):
        self.approval_list_refuses(lambda envelope: envelope["approvals"].pop(), join_git=True)

    def test_missing_first_g5_source_approval_refuses_actual_input(self):
        self.approval_list_refuses(lambda envelope: envelope["approvals"].pop(0), join_git=True)

    def test_second_source_original_blob_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope["approvals"][1].update(original_git_blob="0" * 40)
        )

    def test_second_source_original_digest_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope["approvals"][1].update(original_sha256="0" * 64)
        )

    def test_second_source_committed_blob_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope["approvals"][1].update(git_blob="0" * 40), join_git=True
        )

    def test_second_source_committed_digest_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope["approvals"][1].update(sha256="0" * 64), join_git=True
        )

    def test_second_source_commit_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope["approvals"][1].update(
                published_source_commit=json.loads(args.recipe.read_bytes())["original_head"]
            ),
            join_git=True,
        )

    def test_missing_source_review_digest_refused(self):
        self.approval_list_refuses(
            lambda envelope: envelope["approvals"][1].pop("source_review_sha256")
        )

    def test_unreceived_third_managed_http_tuple_refused(self):
        def add(envelope):
            row = copy.deepcopy(envelope["approvals"][0])
            row["path"] = subject.AUXILIARY_PATH
            envelope["approvals"].append(row)

        self.approval_list_refuses(add)

    def test_number_row_producer_approval_refused(self):
        path = json.loads(args.recipe.read_bytes())["permitted_omission"]["path"]
        self.approval_list_refuses(lambda envelope: envelope["approvals"][1].update(path=path))

    def test_number_row_test_oracle_approval_refused(self):
        path = json.loads(args.recipe.read_bytes())["original_test_source_unchanged"]
        self.approval_list_refuses(lambda envelope: envelope["approvals"][1].update(path=path))

    def test_package_source_approval_refused(self):
        path = next(
            row["path"] for row in baseline["paths"] if row["path"].endswith("/Package.swift")
        )
        self.approval_list_refuses(lambda envelope: envelope["approvals"][1].update(path=path))

    def test_reordered_or_reduced_approval_bytes_refused_by_received_digest(self):
        changed = copy.deepcopy(approval)
        changed["approvals"].reverse()
        path = self.root / "unreceived-envelope.json"
        path.write_text(json.dumps(changed))
        with self.assertRaises(ValueError):
            subject._composition_contract(args.recipe, path, args.approval_sha256, baseline)
        changed["approvals"].pop()
        path.write_text(json.dumps(changed))
        with self.assertRaises(ValueError):
            subject._composition_contract(args.recipe, path, args.approval_sha256, baseline)

    def test_second_source_projection_alteration_refused(self):
        path = approval["approvals"][1]["path"]
        self.projection_refuses(
            lambda root: (root / path).write_bytes(b"unadmitted second source\n")
        )

    def test_original_legacy_single_record_branch_retained(self):
        old = next(
            row
            for row in json.loads(args.recipe.read_bytes())["paths"]
            if row["path"] == subject.AUXILIARY_PATH
        )
        negative = {
            "schema": 1,
            "role": "independently-reviewed-committed-source-input",
            "path": subject.AUXILIARY_PATH,
            "original_git_blob": old["git_blob"],
            "original_sha256": old["sha256"],
            "published_source_commit": args.head,
            "git_blob": old["git_blob"],
            "sha256": old["sha256"],
            "source_review_sha256": "0" * 64,
        }
        path = self.root / "legacy-unchanged-negative.json"
        data = json.dumps(negative).encode()
        path.write_bytes(data)
        with self.assertRaisesRegex(ValueError, "unchanged input is not a new composition"):
            subject._composition_contract(args.recipe, path, hashlib.sha256(data).hexdigest())

    def test_historical_controls_projection_preserves_original_99(self):
        proof = subject.verify_projection(args.recipe, args.controls_projection, original)
        self.assertIs(proof["counterfactual_git_blob"], None)
        recipe = json.loads(args.recipe.read_bytes())
        producer = recipe["permitted_omission"]["path"]
        actual_paths = {
            item.relative_to(args.controls_projection).as_posix()
            for item in args.controls_projection.rglob("*")
            if item.is_file()
        }
        self.assertEqual(actual_paths, {row["path"] for row in recipe["paths"]})
        self.assertEqual(len(actual_paths), 99)
        for row in recipe["paths"]:
            data = (args.controls_projection / row["path"]).read_bytes()
            expected = (
                hashlib.sha256(original.replace(subject.NEEDLE, b"true", 1)).hexdigest()
                if row["path"] == producer
                else row["sha256"]
            )
            self.assertEqual(hashlib.sha256(data).hexdigest(), expected)
        for row in approval["approvals"]:
            self.assertNotEqual(
                (args.controls_projection / row["path"]).read_bytes(),
                (args.projection / row["path"]).read_bytes(),
            )

    def test_historical_controls_cannot_be_used_as_current_native_projection(self):
        with self.assertRaises(ValueError):
            subject.verify_composed_projection(
                args.repo,
                args.head,
                args.recipe,
                args.approval,
                args.approval_sha256,
                args.composition,
                args.composition_sha256,
                args.controls_projection,
                original,
            )

    def test_current_native_projection_cannot_be_used_as_historical_controls(self):
        with self.assertRaises(ValueError):
            subject.verify_projection(args.recipe, args.projection, original)

    def test_historical_control_destination_overlap_refused(self):
        with self.assertRaises(ValueError):
            subject.materialize_historical_controls(
                args.repo,
                args.head,
                args.recipe,
                args.approval,
                args.approval_sha256,
                args.composition,
                args.composition_sha256,
                self.root,
                self.root,
                args.projection,
            )

    def test_occupied_historical_control_destination_refused(self):
        destination = self.root / "occupied"
        destination.mkdir()
        (destination / "owned.txt").write_text("occupied")
        with self.assertRaises(ValueError):
            subject.materialize_historical_controls(
                args.repo,
                args.head,
                args.recipe,
                args.approval,
                args.approval_sha256,
                args.composition,
                args.composition_sha256,
                destination,
                self.root,
                args.projection,
            )

    def test_historical_control_destination_symlink_refused(self):
        destination = self.root / "linked"
        destination.symlink_to(args.controls_projection, target_is_directory=True)
        with self.assertRaises(ValueError):
            subject.materialize_historical_controls(
                args.repo,
                args.head,
                args.recipe,
                args.approval,
                args.approval_sha256,
                args.composition,
                args.composition_sha256,
                destination,
                self.root,
                args.projection,
            )


class CurrentBuildControls(unittest.TestCase):
    """Finite source controls on genuine Git; the draft envelope is not approval."""

    def setUp(self):
        self.owned = tempfile.TemporaryDirectory(dir=args.receiving)
        self.root = Path(self.owned.name)

    def tearDown(self):
        self.owned.cleanup()

    def contract(self):
        return subject._composition_contract(
            args.recipe, args.approval, args.approval_sha256, baseline
        )

    def verify(self, root=None):
        return subject.verify_composed_projection(
            args.repo, args.head, args.recipe, args.approval, args.approval_sha256,
            args.composition, args.composition_sha256, root or args.projection, original,
        )

    def approval_refuses(self, mutation, reason):
        changed = copy.deepcopy(approval)
        mutation(changed)
        path = self.root / "negative-current-build-envelope.json"
        data = json.dumps(changed).encode()
        path.write_bytes(data)
        with self.assertRaisesRegex(ValueError, reason):
            subject._composition_contract(args.recipe, path, hashlib.sha256(data).hexdigest())

    def projection_refuses(self, mutation, reason):
        parent = Path(tempfile.mkdtemp(dir=self.root))
        projected = parent / "negative-source-projection"
        shutil.copytree(args.projection, projected)
        mutation(projected)
        with self.assertRaisesRegex(ValueError, reason):
            self.verify(projected)

    def test_01_original_historical_guard_remains_exact(self):
        proof = subject.verify_projection(args.recipe, args.controls_projection, original)
        self.assertEqual(proof["original_producer_sha256"], subject.PRODUCER_SHA)
        self.assertEqual(len(json.loads(args.recipe.read_bytes())["paths"]), 99)
        self.assertIsNone(proof["counterfactual_git_blob"])

    def test_02_source_review_basis_alone_is_not_admission(self):
        manifest = args.source_basis / "MANIFEST.json"
        with self.assertRaisesRegex(ValueError, "exact source approval record required"):
            subject._composition_contract(
                args.recipe, manifest, hashlib.sha256(manifest.read_bytes()).hexdigest()
            )

    def test_03_actual_current135_source_join(self):
        proof = self.verify()
        self.assertEqual(len(proof["paths"]), 135)
        self.assertEqual(len({row["path"] for row in proof["paths"]}), 135)
        self.assertEqual(proof["published_source_commit"], "70d88b885d45ae616b69f33b9826f76fb1be9493")
        self.assertEqual(proof["native_execution"], "UNRUN")
        self.assertIs(proof["native_authority"], False)
        historical = json.loads(args.recipe.read_bytes())["paths"]
        historical_paths = {row["path"] for row in historical}
        changed = [row for row in proof["paths"] if row["path"] in historical_paths
                   and row["sha256"] != row["historical_sha256"]]
        self.assertEqual(len(changed), 12)
        self.assertEqual(len(proof["paths"]) - len(historical_paths), 36)
        self.assertEqual(
            {row["path"] for row in proof["paths"] if row["source_review_role"] == "whole workflow identity only"},
            {".github/workflows/ci.yml", ".github/workflows/ci-macos.yml"},
        )
        self.assertEqual(proof["source_review_scope"],
                         "current compiler-source closure and NumberRow filter noninterference only; not native qualification")

    def test_04_frozen_canonical_cannot_impersonate_current_supplier(self):
        legacy, received, composition = self.contract()
        # Genuine frozen canonical HEAD and working source, not a supplied
        # mismatched HEAD in the candidate fixture. Admission stops at the real
        # missing70 ancestry; independently observe the genuine bootstrap delta.
        frozen = "3f59f730a680ba4d8a509267b6b50d192789e317"
        self.assertEqual(subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=args.canonical_repo, text=True
        ).strip(), frozen)
        with self.assertRaisesRegex(ValueError, "approved committed source is not an ancestor"):
            subject._current_composition_inputs(
                args.canonical_repo, frozen, legacy, received, composition
            )
        path = "static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/OwnedRuntimeBootstrapStageOwner.swift"
        actual, _, _ = subject._git_input(args.canonical_repo, frozen, path)
        self.assertEqual(actual, (args.canonical_repo / path).read_bytes())
        self.assertNotEqual(actual, (args.projection / path).read_bytes())

    def test_05_old_two_lease_approvals_do_not_authorize_current_deltas(self):
        leases = args.recipe.with_name("g5-source-approvals.json.raw")
        legacy, received, composition = subject._composition_contract(
            args.recipe, leases, hashlib.sha256(leases.read_bytes()).hexdigest()
        )
        with self.assertRaisesRegex(ValueError, "reviewed actual source input drift refused"):
            subject._current_composition_inputs(args.repo, args.head, legacy, received, composition)

    def test_06_changed_historical_predecessor_refused(self):
        def mutate(envelope):
            row = next(row for row in envelope["sources"] if row["path"].endswith("/Package.swift"))
            row["historical_sha256"] = row["sha256"]
        self.approval_refuses(mutate, "historical current build predecessor refused")

    def test_07_missing_scoped_review_or_native_scope_refused(self):
        self.approval_refuses(
            lambda envelope: envelope["sources"][0].update(review_bindings=[]),
            "exact scoped current build source review required",
        )
        self.approval_refuses(
            lambda envelope: envelope.update(review_scope="native ownership approved"),
            "independently received current build source review required",
        )

    def test_08_missing_actual_cpp_or_quoted_header_refused(self):
        for suffix in ("/OwnedInstalledConfiguration.cpp", "/InstalledRuntimePublisher.hpp", "/InstalledUserConfiguration.hpp"):
            with self.subTest(source=suffix):
                self.approval_refuses(
                    lambda envelope, name=suffix: envelope.update(
                        sources=[row for row in envelope["sources"] if not row["path"].endswith(name)]
                    ), "exact current build source census required",
                )

    def test_09_absent_topic_sdk_cannot_enroll(self):
        def mutate(envelope):
            row = copy.deepcopy(envelope["sources"][-1])
            row["path"] = "static/ergopti_plus/macos/launcher/Sources/CPOSIXCompatibility/OwnedVHDInstalledCompatibility.c"
            envelope["sources"].append(row)
        self.approval_refuses(mutate, "exact current build source census required")

    def test_10_duplicate_foreign_or_symlink_source_refused(self):
        self.approval_refuses(
            lambda envelope: envelope["sources"].__setitem__(1, copy.deepcopy(envelope["sources"][0])),
            "exact current build source census required",
        )
        def foreign(envelope):
            row = envelope["sources"][-1]
            row["path"] = "tools/build/unreviewed-source.hpp"
            envelope["sources"].sort(key=lambda row: row["path"])
        self.approval_refuses(foreign, "reviewed current build source closure refused")
        def symlink(root):
            path = root / "tools/build/InstalledRuntimePublisher.hpp"
            path.unlink()
            path.symlink_to(args.repo / "tools/build/InstalledRuntimePublisher.hpp")
        self.projection_refuses(symlink, "regular projection members required")

    def test_11_independent_original_and_sole_omission_preserved(self):
        recipe = json.loads(args.recipe.read_bytes())
        producer = recipe["permitted_omission"]["path"]
        self.projection_refuses(
            lambda root: (root / producer).write_bytes(original),
            "composed projection source image refused",
        )
        self.projection_refuses(
            lambda root: (root / recipe["original_test_source_unchanged"]).write_bytes(b"unreviewed oracle\n"),
            "composed projection source image refused",
        )

    def test_12_parent_before_initializer_fix_is_not_supplier(self):
        self.approval_refuses(
            lambda envelope: envelope.update(published_source_commit="7a994538e4ec8754eaa7fad05e02a0e95ae4e4d2"),
            "actual reviewed current build source commit required",
        )
        path = "static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/OwnedRuntimeBootstrapStageOwner.swift"
        before, _, _ = subject._git_input(args.repo, "7a994538e4ec8754eaa7fad05e02a0e95ae4e4d2", path)
        self.assertNotEqual(before, (args.projection / path).read_bytes())
        self.projection_refuses(
            lambda root: (root / path).write_bytes(before), "composed projection source image refused",
        )

    def test_13_unreceived_authority_digest_or_zero_review_refused(self):
        with self.assertRaisesRegex(ValueError, "reviewed provenance image refused"):
            subject._composition_contract(args.recipe, args.approval, "0" * 64, baseline)
        self.approval_refuses(
            lambda envelope: envelope.update(source_review_sha256="0" * 64),
            "independently received current build source review required",
        )
        self.approval_refuses(
            lambda envelope: envelope.update(native_ready=True),
            "exact current build source approval envelope required",
        )

        # Real missing-history observation in our private object metadata.
        # No hosted-shallow assertion or fabricated Git return is made.
        self.assertNotEqual(args.repo.resolve(), args.canonical_repo.resolve())
        alternate = args.repo / ".git/objects/info/alternates"
        unavailable = alternate.with_name("alternates-source-control-unavailable")
        alternate.rename(unavailable)
        try:
            missing = subprocess.run(["git", "cat-file", "-e", approval["published_source_commit"]],
                                     cwd=args.repo, capture_output=True)
            self.assertNotEqual(missing.returncode, 0)
            legacy, received, composition = self.contract()
            with self.assertRaisesRegex(ValueError, "approved committed source is not an ancestor"):
                subject._current_composition_inputs(args.repo, args.head, legacy, received, composition)
        finally:
            unavailable.rename(alternate)
        # Change the real private HEAD during an original real Git source read;
        # the wrapper forwards actual Git bytes unchanged and adds only this
        # controlled source-currency interruption. It never mocks Git answers.
        getter = subject._git_input
        changed = False
        def change_head(repo, head, path):
            nonlocal changed
            result = getter(repo, head, path)
            if not changed:
                subprocess.run(["git", "update-ref", "--no-deref", "HEAD",
                                "3f59f730a680ba4d8a509267b6b50d192789e317"], cwd=args.repo, check=True)
                changed = True
            return result
        subject._git_input = change_head
        try:
            legacy, received, composition = self.contract()
            with self.assertRaisesRegex(ValueError, "actual current source commit changed"):
                subject._current_composition_inputs(args.repo, args.head, legacy, received, composition)
            self.assertTrue(changed)
        finally:
            subject._git_input = getter
            subprocess.run(["git", "update-ref", "--no-deref", "HEAD", args.head], cwd=args.repo, check=True)
        # A late genuine file change after earlier source rows were checked
        # must be found by the final working-image join. Source reads remain
        # original and the altered bytes/fixture are restored in finally.
        victim = args.repo / approval["sources"][0]["path"]
        prior = victim.read_bytes()
        last = approval["sources"][-1]["path"]
        calls = 0
        def change_working(repo, head, path):
            nonlocal calls
            result = getter(repo, head, path)
            if head == args.head and path == last:
                calls += 1
                if calls == 2:
                    victim.write_bytes(prior + b"\nsource-control late negative image\n")
            return result
        subject._git_input = change_working
        try:
            legacy, received, composition = self.contract()
            with self.assertRaisesRegex(ValueError, "reviewed working source changed after reads"):
                subject._current_composition_inputs(args.repo, args.head, legacy, received, composition)
            self.assertEqual(calls, 2)
        finally:
            subject._git_input = getter
            victim.write_bytes(prior)

    def test_14_source_join_cannot_certify_native_success(self):
        proof = self.verify()
        self.assertIs(proof["native_authority"], False)
        self.assertIs(proof["receiver_approval_from_source_basis"], False)
        self.assertEqual(proof["native_execution"], "UNRUN")
        self.assertEqual(len(subject.METHODS), 12)
        self.assertEqual(subject.TARGET,
                         "testActualFrozenProbeRefusesChangedFinalBytesOnSamePrivateDataObject")
        test_source = (args.projection / json.loads(args.recipe.read_bytes())["original_test_source_unchanged"]).read_bytes()
        with self.assertRaisesRegex(ValueError, "actual Swift expected-red status refused"):
            subject.evaluate(test_source, "", 0, 0, {}, 0)

    def test_15_historical_and_current_source_roles_cannot_swap(self):
        with self.assertRaisesRegex(ValueError, "exact current build composed projection inputs required"):
            self.verify(args.controls_projection)
        with self.assertRaisesRegex(ValueError, "exact projection input census refused"):
            subject.verify_projection(args.recipe, args.projection, original)


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromName('CurrentBuildControls.test_04_frozen_canonical_cannot_impersonate_current_supplier')
    )
    raise SystemExit(0 if result.wasSuccessful() else 1)
