from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
v=json.loads((r/"PUBLIC-MANIFEST.json").read_text())
for n,row in v["files"].items():
 p=r/n
 if p.is_symlink() or not p.is_file() or p.stat().st_size!=row["bytes"] or hashlib.sha256(p.read_bytes()).hexdigest()!=row["sha256"]:raise SystemExit("Custody mismatch: "+n)
print("PASS inert payload hashes; no application imports or native execution")
