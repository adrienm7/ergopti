# Publication library only. The native test/lease host owns initialization.
Set-StrictMode -Version Latest

function Initialize-OllamaPublicationOwner {
	if (Get-Variable -Name OP_Rows -Scope Script -ErrorAction SilentlyContinue) {
		throw 'Publication owner initialization is exclusive.'
	}
	if ('Ergopti.Ollama.PublicationNative' -as [type]) {
		throw 'A preloaded publication native type cannot be adopted.'
	}
	Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
namespace Ergopti.Ollama {
    public static class PublicationNative {
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        private static extern uint GetFinalPathNameByHandleW(IntPtr h, StringBuilder b, uint n, uint flags);
        public static string FinalPath(IntPtr handle) {
            StringBuilder buffer = new StringBuilder(32768);
            uint length = GetFinalPathNameByHandleW(handle, buffer, (uint)buffer.Capacity, 0);
            if (length == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
            if (length >= (uint)buffer.Capacity) throw new InvalidOperationException("Native final path is not complete.");
            string value = buffer.ToString();
            if (!value.StartsWith(@"\\?\", StringComparison.Ordinal)) throw new InvalidOperationException("Native final path is not local DOS form.");
            return value.Substring(4);
        }
    }
}
'@
	$script:OP_Rows = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal)
}

function Get-OllamaPublicationRow([string]$Id) {
	if (-not $script:OP_Rows.ContainsKey($Id)) { throw 'Unknown native publication owner.' }
	return $script:OP_Rows[$Id]
}

function Get-OllamaPublicationNativeRoot($Root) {
	if ($Root.root_handle -eq [IntPtr]::Zero -or $Root.versions_handle -eq [IntPtr]::Zero -or
		-not $Root.handles.Contains($Root.root_handle) -or -not $Root.handles.Contains($Root.versions_handle)) {
		throw 'Publication root and versions handles are not exact members of this root owner.'
	}
	if ([Ergopti.Ollama.ManagedNative]::Identity($Root.root_handle) -ne $Root.identity -or
		[Ergopti.Ollama.ManagedNative]::Identity($Root.versions_handle) -ne $Root.versions_identity) {
		throw 'Publication root or versions native identity changed.'
	}
	$nativeRoot = [Ergopti.Ollama.PublicationNative]::FinalPath($Root.root_handle)
	$nativeVersions = [Ergopti.Ollama.PublicationNative]::FinalPath($Root.versions_handle)
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals($nativeVersions, [IO.Path]::Combine($nativeRoot, 'versions'))) {
		throw 'Publication versions is not the exact held native root child.'
	}
	return [ordered]@{ root_native_path = $nativeRoot; versions_native_path = $nativeVersions;
		versions_identity = $Root.versions_identity }
}

function Assert-OllamaPublicationLocation($Row) {
	$captured = Get-OllamaPublicationNativeRoot $Row.root
	$expected = [IO.Path]::Combine($captured.versions_native_path, $Row.final_leaf)
	$actual = [Ergopti.Ollama.PublicationNative]::FinalPath($Row.descriptor.SafeFileHandle.DangerousGetHandle())
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals($Row.destination, $expected) -or
		-not [StringComparer]::OrdinalIgnoreCase.Equals($actual, $expected) -or
		-not [StringComparer]::OrdinalIgnoreCase.Equals([IO.Path]::GetDirectoryName($actual), $captured.versions_native_path) -or
		-not [StringComparer]::Ordinal.Equals([IO.Path]::GetFileName($actual), $Row.final_leaf)) {
		throw 'The exact descriptor is outside its owned advertised location.'
	}
}

function Add-OllamaPublicationRecord($Row, [string]$Kind, $Fields) {
	$record = [ordered]@{ sequence = $Row.sequence + 1; kind = $Kind }
	foreach ($key in $Fields.Keys) { $record[$key] = $Fields[$key] }
	$bytes = [Text.UTF8Encoding]::new($false).GetBytes(($record | ConvertTo-Json -Compress -Depth 10) + "`n")
	$Row.wal.Write($bytes, 0, $bytes.Length)
	$Row.wal.Flush($true)
	$Row.sequence = $record.sequence
}

function Set-OllamaPublicationDebt($Row, [string]$Reason) {
	if ($Row.first_error -eq '') { $Row.first_error = $Reason }
	$Row.phase = 'retained-debt'
}

function New-OllamaPublicationOwner($Root, [string]$Ticket, [string]$Identity, [string]$ManifestHash) {
	if ($Ticket -notmatch '\A[0-9a-f]{32}\z') { throw 'Publication needs an exact private ticket.' }
	$id = [Guid]::NewGuid().ToString('N')
	$row = [ordered]@{ id = $id; root = $Root; ticket = $Ticket; stage = $null;
		wal = $null; wal_path = [IO.Path]::Combine($Root.path, '.publication-' + $Ticket + '.jsonl');
		wal_identity = ''; sequence = 0; descriptor = $null; descriptor_identity = '';
		descriptor_bytes = $null; descriptor_hash = ''; temporary = ''; destination = '';
		native_root = ''; native_versions = ''; native_container = ''; versions_identity = ''; final_leaf = '';
		phase = 'acquiring'; rename_attempted = $false; first_error = ''; consumers = 0;
		manifest_hash = $ManifestHash;
		close_debt = [Collections.Generic.List[object]]::new(); closed = $false }
	# Publish the row before any native acquisition. Constructor failure is owned.
	$script:OP_Rows.Add($id, $row)
	try {
		$captured = Get-OllamaPublicationNativeRoot $Root
		$row.native_root = $captured.root_native_path
		$row.native_versions = $captured.versions_native_path
		$row.versions_identity = $captured.versions_identity
		$row.wal_path = [IO.Path]::Combine($row.native_root, '.publication-' + $Ticket + '.jsonl')
		$row.stage = Open-OllamaPreparedStage $Root $Ticket $Identity $ManifestHash
		$row.native_container = [Ergopti.Ollama.PublicationNative]::FinalPath($row.stage.handle)
		if (-not [StringComparer]::OrdinalIgnoreCase.Equals($row.native_container, [IO.Path]::Combine($row.native_root, '.stage-' + $Ticket))) {
			throw 'Publication container is outside the exact held native root.'
		}
		$m = $row.stage.manifest
		$leaf = $m.version + '-' + $m.asset + '-' + $m.archive_sha256 + '.json'
		[void](Assert-OllamaRelativePath $leaf)
		$row.final_leaf = $leaf
		$row.destination = [IO.Path]::Combine($row.native_versions, $leaf)
		$row.temporary = [IO.Path]::Combine($row.native_versions, '.publish-' + $Ticket + '.json')
		$row.wal = [Ergopti.Ollama.ManagedNative]::CreateOwnedFile($row.wal_path)
		$row.wal_identity = [Ergopti.Ollama.ManagedNative]::Identity($row.wal.SafeFileHandle.DangerousGetHandle())
		Add-OllamaPublicationRecord $row 'publication-owner' ([ordered]@{
			owner_id = $id; ticket = $Ticket; root_identity = $Root.identity;
			container_identity = $Identity; manifest_sha256 = $ManifestHash;
			wal_identity = $row.wal_identity; final_leaf = $leaf; root_native_path = $row.native_root; versions_identity = $row.versions_identity })
		$row.phase = 'prepared'
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		# A typed owner ID remains available even when construction is partial.
		$_.Exception.Data['ollama_publication_owner'] = $id
		throw
	}
	return $id
}

function Assert-OllamaPublicationImage($Row) {
	$captured = Get-OllamaPublicationNativeRoot $Row.root
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals($captured.root_native_path, $Row.native_root) -or
		-not [StringComparer]::OrdinalIgnoreCase.Equals($captured.versions_native_path, $Row.native_versions) -or
		$captured.versions_identity -ne $Row.versions_identity) { throw 'Publication native root bindings changed.' }
	$handle = $Row.descriptor.SafeFileHandle.DangerousGetHandle()
	if ([Ergopti.Ollama.ManagedNative]::Identity($handle) -ne $Row.descriptor_identity) {
		throw 'Publication descriptor identity changed.'
	}
	if ((Get-OllamaStreamHash $Row.descriptor) -ne $Row.descriptor_hash) {
		throw 'Publication descriptor image changed.'
	}
	if ([Ergopti.Ollama.ManagedNative]::Identity($Row.stage.handle) -ne $Row.stage.manifest.identity) {
		throw 'Publication container identity changed.'
	}
}

function Publish-OllamaVersionDescriptor([string]$Id, [scriptblock]$AfterNativeRename = $null) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.phase -ne 'prepared' -or $row.closed) { throw 'Publication is a one-shot prepared operation.' }
	try {
		$m = $row.stage.manifest
		$image = [ordered]@{ kind = 'ollama-immutable-container-reference'; schema = 1;
			root_identity = $row.root.identity; root_native_path = $row.native_root; versions_identity = $row.versions_identity; container = '.stage-' + $row.ticket;
			container_identity = $m.identity; ticket = $row.ticket;
			manifest_sha256 = $row.manifest_hash;
			catalogue_sha256 = $m.catalogue_sha256; archive_sha256 = $m.archive_sha256;
			version = $m.version; asset = $m.asset }
		$row.descriptor_bytes = [Text.UTF8Encoding]::new($false).GetBytes(($image | ConvertTo-Json -Compress -Depth 10) + "`n")
		Add-OllamaPublicationRecord $row 'descriptor-intent' ([ordered]@{ name = [IO.Path]::GetFileName($row.temporary) })
		$row.descriptor = [Ergopti.Ollama.ManagedNative]::CreateOwnedFile($row.temporary)
		$row.descriptor_identity = [Ergopti.Ollama.ManagedNative]::Identity($row.descriptor.SafeFileHandle.DangerousGetHandle())
		Add-OllamaPublicationRecord $row 'descriptor-owned' ([ordered]@{ identity = $row.descriptor_identity })
		$row.descriptor.Write($row.descriptor_bytes, 0, $row.descriptor_bytes.Length)
		$row.descriptor.Flush($true)
		$hasher = [Security.Cryptography.SHA256]::Create()
		try { $row.descriptor_hash = [BitConverter]::ToString($hasher.ComputeHash($row.descriptor_bytes)).Replace('-', '').ToLowerInvariant() }
		finally { $hasher.Dispose() }
		Add-OllamaPublicationRecord $row 'descriptor-complete' ([ordered]@{
			sha256 = $row.descriptor_hash; bytes = $row.descriptor_bytes.Length })
		Assert-OllamaPublicationImage $row
		Add-OllamaPublicationRecord $row 'rename-intent' ([ordered]@{ final_leaf = [IO.Path]::GetFileName($row.destination) })
		$row.rename_attempted = $true
		$row.phase = 'publication-indeterminate'
		# Rename only the small file. Never rename or release its content container.
		[Ergopti.Ollama.ManagedNative]::RenameCreate($row.descriptor.SafeFileHandle.DangerousGetHandle(), $row.destination)
		if ($null -ne $AfterNativeRename) { & $AfterNativeRename $Id }
		return Confirm-OllamaVersionDescriptor $Id
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		throw
	}
}

function Confirm-OllamaVersionDescriptor([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	if (-not $row.rename_attempted -or $row.closed -or $null -eq $row.descriptor) {
		throw 'Publication confirmation requires its retained native file owner.'
	}
	# Published observations still revalidate exact native identity and location.
	try {
		Assert-OllamaPublicationImage $row
		Assert-OllamaPublicationLocation $row
		if ($row.phase -ne 'published') {
			Add-OllamaPublicationRecord $row 'published' ([ordered]@{ identity = $row.descriptor_identity; sha256 = $row.descriptor_hash })
		}
		$row.phase = 'published'
		return Get-OllamaPublicationObservation $Id
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		throw
	}
}

function Get-OllamaPublicationObservation([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	return [ordered]@{ owner_id = $Id; phase = $row.phase; closed = $row.closed;
		container_path = $row.native_container; logical_container_path = if ($null -ne $row.stage) { $row.stage.path } else { '' };
		container_identity = if ($null -ne $row.stage) { $row.stage.manifest.identity } else { '' };
		descriptor_path = $row.destination; descriptor_identity = $row.descriptor_identity;
		descriptor_sha256 = $row.descriptor_hash; rename_attempted = $row.rename_attempted;
		consumers = $row.consumers; first_error = $row.first_error; close_debt = $row.close_debt.Count;
		executable = if ($row.native_container -ne '') { [IO.Path]::Combine($row.native_container, 'ollama.exe') } else { '' } }
}

function Reserve-OllamaPublicationLeaseHost([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.phase -ne 'published' -or $row.closed -or $row.consumers -ne 0) {
		throw 'A lease host requires one retained published container.'
	}
	Assert-OllamaPublicationImage $row
	$row.consumers = 1
	# No release API accepts a caller Boolean. Actual daemon/job attachment and
	# terminal receipt binding are the next host slice; reservation retains debt.
	return Get-OllamaPublicationObservation $Id
}

function Close-OllamaPublicationFileOnce($Row, [string]$Name) {
	$stream = $Row[$Name]
	if ($null -eq $stream) { return }
	$Row[$Name] = $null
	try { $stream.Dispose() }
	catch {
		$Row.close_debt.Add([ordered]@{ kind = 'stream'; name = $Name; resource = $stream; state = 'uncertain' })
		Set-OllamaPublicationDebt $Row $_.Exception.Message
	}
}

function Close-OllamaPublicationOwner([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.closed) { return $true }
	if ($row.consumers -ne 0 -or $row.phase -ne 'published' -or $row.close_debt.Count -ne 0) {
		return $false
	}
	# This release is allowed only before any runtime host reservation. Durable
	# reference/WAL files remain; ordinary stage cleanup stays forbidden.
	foreach ($stream in $row.stage.streams) {
		try { $stream.Dispose() }
		catch {
			$row.close_debt.Add([ordered]@{ kind = 'stage-stream'; resource = $stream; state = 'uncertain' })
			Set-OllamaPublicationDebt $row $_.Exception.Message
		}
	}
	$row.stage.streams.Clear()
	foreach ($name in @($row.stage.directory_handles.Keys)) {
		$handle = $row.stage.directory_handles[$name]
		$row.stage.directory_handles[$name] = [IntPtr]::Zero
		if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($handle)) {
			$row.close_debt.Add([ordered]@{ kind = 'directory'; resource = $handle; state = 'uncertain' })
		}
	}
	$parent = $row.stage.handle
	$row.stage.handle = [IntPtr]::Zero
	if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($parent)) {
		$row.close_debt.Add([ordered]@{ kind = 'container'; resource = $parent; state = 'uncertain' })
	}
	Close-OllamaPublicationFileOnce $row 'descriptor'
	Close-OllamaPublicationFileOnce $row 'wal'
	if ($row.close_debt.Count -ne 0) {
		Set-OllamaPublicationDebt $row 'Publication resource close was not acknowledged.'
		return $false
	}
	$row.closed = $true
	$row.phase = 'published-no-host'
	[void]$script:OP_Rows.Remove($Id)
	return $true
}


# Produces allocation/lookup hints, never a lease or native READY authority.
function Get-OllamaRuntimeSourceExpectation([string]$Id, [string]$GuardianPath, [string]$LauncherPath) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.phase -ne 'published' -or $row.closed -or $row.consumers -ne 0 -or $row.close_debt.Count -ne 0) {
		throw 'Source expectations require one unreserved live publication.'
	}
	Assert-OllamaPublicationImage $row
	Assert-OllamaPublicationLocation $row
	[void](Assert-OllamaLocalPath $GuardianPath)
	[void](Assert-OllamaLocalPath $LauncherPath)
	$paths = [Collections.Generic.List[string]]::new()
	foreach ($handle in $row.root.handles) { $paths.Add([Ergopti.Ollama.PublicationNative]::FinalPath($handle)) }
	$paths.Add($row.native_container)
	foreach ($handle in $row.stage.directory_handles.Values) { $paths.Add([Ergopti.Ollama.PublicationNative]::FinalPath($handle)) }
	foreach ($relative in @('prepared.json', 'stage-owner.json')) { $paths.Add([IO.Path]::Combine($row.native_container, $relative)) }
	$paths.Add($row.destination)
	foreach ($file in $row.stage.manifest.files) { $paths.Add([IO.Path]::Combine($row.native_container, $file.path.Replace('/', '\'))) }
	if ($row.root.ContainsKey('models')) {
		if ($row.root.models.phase -ne 'held') { throw 'Models capacity requires its retained native acquisition.' }
		$paths.Add([Ergopti.Ollama.PublicationNative]::FinalPath($row.root.models.marker.SafeFileHandle.DangerousGetHandle()))
	}
	# Code paths remain hints and are authenticated by the later source worker.
	# Its native FinalPath port rejects paths >=32768 UTF-16 units. Reserve that
	# documented port capacity per image, including its terminator, so MSIX path
	# virtualization cannot silently underallocate the otherwise exact channel.
	[uint64]$units = 0
	foreach ($path in $paths) { $units += [uint64]$path.Length + 1 }
	$units += [uint64]2 * 32768
	[uint64]$records = [uint64]$paths.Count + 2
	[uint64]$bytes = 80 + $records * 72 + $units * 2
	if ($records -eq 0 -or $units -eq 0 -or $bytes -gt [uint32]::MaxValue) { throw 'Source channel capacity exceeds its native wire.' }
	$expectation = [ordered]@{ ok = $true; phase = 'published'; schema = 1;
		RootPath = $row.native_root; RootIdentity = $row.root.identity; Ticket = $row.ticket;
		StageIdentity = $row.stage.manifest.identity; ManifestHash = $row.manifest_hash;
		DescriptorIdentity = $row.descriptor_identity; DescriptorHash = $row.descriptor_hash;
		RecordCapacity = $records; PathCapacity = $units;
		Executable = [IO.Path]::Combine($row.native_container, 'ollama.exe');
		Version = $row.stage.manifest.version; Asset = $row.stage.manifest.asset;
		CatalogueHash = $row.stage.manifest.catalogue_sha256; ArchiveHash = $row.stage.manifest.archive_sha256 }
	if ($row.root.ContainsKey('models')) {
		$expectation.ModelsDirectory = $row.root.models.requested_path
		$expectation.ModelsFolderName = $row.root.models.leaf
		$expectation.ModelsIdentity = $row.root.models.identity
	}
	return $expectation
}
