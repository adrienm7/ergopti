# Group 3 current preparation capsule

This is a selected, inactive handover. It contains exact patches, receipts,
source reviews and fixture-only receiving logs, not a checkout or an executable
runtime. **No source is adopted by extracting this archive or applying a private
patch without its owner handback and current-source qualification.** All 13
Group 3 TODO items remain partial; none is removed. Items 16 and 38 remain open,
and other groups' TODO blocks and existing archives must stay unchanged.

`manifest.json` lists every selected member's exact bytes, SHA256 and original
source path. The tar contains only that finite list of ordinary relative files.
Existing complete packets remain authoritative at those origins; their omitted
checkouts, binaries, caches and unselected evidence are not reproduced here.
Use the original corpus/receivers and acknowledged native owners; never regenerate
an oracle from the candidate implementation.

| Preparation | Received evidence | Remaining boundary |
| --- | --- | --- |
| Linux V4 identity, `linux-v4/` | Four reviewed code/test postimages plus only TODO93, prospective tree 8261a837. On each ABI: prior 55 and new 3 controls pass; real filesystem 8 passes with 72 actual closes and immediate EBADF. Original/V3 LuaJIT safe-integer controls fail 2; original shipped-route 0/2 is retained by the original packets. Shipped inode 9223372036855917341/mode 0600/full metadata remain unchanged; owned fixtures are removed. | G6 cuts granted in 6116082222; Loader/unit final handback pending. Final V4 runtime independent review PENDING; its source review is clear. Complete owning suites, whole Linux and final-source hosted qualification UNRUN. File observations grant no input/GUI authority. |
| PowerShell POSIX, `powershell-posix/` | Exact prospective8261 five-path source cut; prior actual Linux 7.5.4 one-completion, argv, PID/group retirement receipt. Mac provider cases use controlled ports. Historical d316 whole Linux 13277/2 and HS 18611/0 are retained as their own source epoch. | Prospective source is not qualified by the historical whole-driver results. No runtime/binary is embedded. Mac genuine interpreter/Swift acceptance remains separate. |
| Snapshot e101, `snapshot-e101/` | Source commit e10136d3a60d01d5fd4a5c955b51a84f04544115 and remote exact publication. Selected verification exit0; 22 pure Snapshot receiving controls pass. | Native AHK UNRUN for this source; JS acceptance does not supply its native 16 receipt. Preserve pending native first-failure/retirement receiving. |
| SourceB, `source-b/` | Inactive four-path 90c713cd source proposal and prior finite source review. Original native 16+12 names, 28 census and budgets stay intact. | Root workflow grant carry-forward pending; new current preimages and actual native receiving must be joined before enrollment/adoption. No budget/order change or whole-Windows transfer. |
| Portable regular146, `regular146/` | Final formatted15-path source patch; actual serial 146 passes 18+16+8+53+51. Earlier final-V3 historical 51 timeout remains a failure receipt. Six fixed raw independent fixtures are retained byte-for-byte. | SDK 112 APIs and native 99/100 checks remain unavailable/unexecuted. Source registration and portable146 do not qualify native Carbon, hardware or installed delivery. |
| Mac PowerShell, `powershell-macos/` | Frozen helperV2 source/controlled review, native SwiftV2 source review, workflowV2 source plus four real POSIX retained-origin controls and the genuine old cached-origin failure. | WorkflowV2 final independent review PENDING at capsule preparation. Genuine signed-Hammerspoon/Swift/pwsh hosted execution UNRUN; four POSIX controls do not qualify Mac native execution. |
| Official Windows381887, `windows381887/` | Exact finite actual receiving: 11165 planned, 1983 terminals/PASS, 0 assertion failures; case 1984 started without terminal, watchdog/whole-run failure. Timing excludes later replay. | Incomplete suite is not green. Timing supports cumulative budget exhaustion, not a proven individual hang or an authorized budget change. Preserve actual native/source frame and missing canonical BOM provenance. |
| Main 71/96, `main71-96/` | Decisive source census/review stops at indispensable current dependency mismatch. | Main's reported green run cannot transfer to current 71/96; current full-save/schema/startup/migration owners and native fixtures require their own qualification. |

## Remaining work

| Item | Concrete continuation |
| --- | --- |
| 63 | Preserve provider/cancellation receipts; qualify genuine brightness effects and supported keyboard/wheel layers on target displays. |
| 71 | Bind current retired-Metrics preservation/full-save/compiled-upgrade and installed acceptance; Main source mismatch prevents transfer. |
| 73 | Retain all182 catalogue-label/hidden-pair assertions and21-language coverage. Qualify current actual providers; historical French-category writer cause remains unproved. |
| 91 | Preserve original Windows hook, snapshots, callback/raw-stream framing, buffering and retirement; receive exact new-source native 16/28 before closure. |
| 93 | Complete Linux simultaneous/source/modifier/server-output custody and current composed daemon/installed acceptance. Bounded XI2/property or filesystem probes supply only their stated component evidence. |
| 96 | Finish current all-driver AltGr/emulation migration and runtime parity on the actual source; no Main-native transfer. |
| 97 | Complete all-owner collision admission, genuine physical capture/assignment and output joins; retain old menus until the generic route is qualified. Dead-key composition is distinct from literal Unicode output. |
| 98 | Join arbitrary physical-position/None/output choices to the same qualified model and runtime; unavailable capture/delivery must stay honest. |
| 106 | Finish actual automation discovery/execution/parameter retirement and hosted Mac pwsh/Swift receiving on current sources; Linux component success is not three-OS installed acceptance. |
| 107 | Receive original positive number-row native judge, causal first-failure/restoration records and actual Carbon/TIS source; portable146 is only portable qualification. |
| 108 | Qualify actual physical magic-character source, admission/transaction, publication and current installed default-shortcut handoff on each driver. |
| 109 | Preserve shared application title composition and native owned notifications/dialogs; remaining native caption, callback, receiver and safe capture boundaries require actual receipts. |
| 111 | Complete current cursor-display/window broker/source/route/retirement and installed acceptance, keeping genuine native family receipts distinct from physical two-screen behavior. |

Windows-native continuation remains recorded for the maintainer workstation as
requested. Linux/macOS software ports, shared-owner handbacks and hosted CI are
explicit remaining work. Genuine device acceptance includes actual keypresses,
brightness and two-screen cursor/window behavior; it cannot be replaced by Xvfb,
recording tables, a portable unit count or a native constructor alone.

No tests, SDK/native processes, network calls or Git/source/index/ref changes
occurred while assembling this capsule. The parent's active 40793 source fence
remained untouched. Retained raw logs contain fixed fixtures and public source
facts; API private headers, signed URLs, credentials and runtime payloads are
excluded. One initial unsealed archive-name length assertion is retained outside
the archive as preparation history; it ran no receiving test and published no
archive or source.
