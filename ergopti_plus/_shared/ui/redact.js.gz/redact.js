// _shared/ui/redact.js

/**
 * ==============================================================================
 * MODULE: Diagnostics Redaction (Shared Page Port)
 * DESCRIPTION:
 * Removes what must not leave the machine from diagnostic text before it is
 * copied, saved or sent to a GitHub issue: token-like secrets (URL credentials
 * included), the home folder, the account name, other accounts' profile folders,
 * the folder and file names under the configuration directory and e-mail
 * addresses. The diagnostics page builds that text and shows a
 * preview of it, so the page redacts it; the rules are data in
 * _shared/modules/diagnostics/redaction.json, handed over by the host.
 *
 * FEATURES & RATIONALE:
 * 1. One algorithm, three languages: the Lua port
 *    (_shared/lua/diagnostics/redact.lua) and the AHK port
 *    (windows/infra/redact.ahk) replay the same vectors
 *    (_shared/tests/corpus/diagnostics/redaction_vectors.json).
 * 2. Secrets first, so a token that happens to contain the account name is
 *    removed whole rather than half-rewritten.
 * 3. The home folder in every spelling a log can hold (both slash styles),
 *    case-insensitively where the file system is (Windows), and only as a
 *    whole path: /Users/jdoe2 is not /Users/jdoe.
 * 4. The account name only as a whole word of a minimum length: a one-letter
 *    account name replaced everywhere would shred the report.
 * 5. Case folding is ASCII-only, as in the other ports. toLowerCase() would
 *    also fold non-ASCII letters and change the length of some strings, which
 *    would shift every index found in the folded copy.
 * 6. Folder and file names chosen by the user are masked whole, spaces and
 *    non-ASCII letters included; under the configuration directory only the
 *    names the product ships stay.
 * ==============================================================================
 */

(function (global) {
	'use strict';

	// ====================================
	// ====================================
	// ======= 1/ Character Classes =======
	// ====================================
	// ====================================

	// The charsets redaction.json may name
	var CHARSETS = {
		alnum: /^[A-Za-z0-9]$/,
		word: /^[A-Za-z0-9_]$/,
		word_dash: /^[A-Za-z0-9_-]$/
	};

	// A character that continues an identifier: a match next to one is part of a
	// longer word and is left alone
	var WORD_CHAR = /^[A-Za-z0-9_]$/;

	// A character that continues a path segment after the home folder
	var PATH_CHAR = /^[A-Za-z0-9_.-]$/;

	// A character of a folder or file name chosen by a person: the path characters
	// plus every non-ASCII one, so "José" is one name, not "Jos" and a leak. The
	// ellipsis a log appends to a shortened path ends a name, so it is excluded
	var NAME_CHAR = /^[A-Za-z0-9_.\-\u0080-‥‧-￿]$/;

	// What can follow a complete name: a path separator, a quote, a line break
	var NAME_END_CHAR = /^[\\/"'\r\n]$/;

	// The characters of an e-mail local part and of a domain
	var EMAIL_LOCAL = /^[A-Za-z0-9._%+-]$/;
	var EMAIL_DOMAIN = /^[A-Za-z0-9.-]$/;
	var LETTER = /^[A-Za-z]$/;

	// The characters of the credential in front of the @ of a URL
	var URL_USERINFO = /^[A-Za-z0-9._~%+:=!*-]$/;

	// The characters a bearer token is made of
	var BEARER_CHAR = /^[A-Za-z0-9._~+/=-]$/;

	// Blanks between a key, its separator and its value
	var BLANK = /^[ \t]$/;

	// Quotes around a key or a value
	var QUOTE = /^["']$/;

	// The characters that end an unquoted key=value secret. Spelled out rather
	// than \s: a JavaScript \s also matches a no-break space, Lua's %s does not
	var VALUE_STOP = /^[ \t\n\v\f\r"',;)}&]$/;

	/**
	 * True when the character at `index` exists and matches the class.
	 * @param {string} text
	 * @param {number} index 0-based.
	 * @param {RegExp} pattern Matches one character.
	 * @returns {boolean}
	 */
	function charIs(text, index, pattern) {
		if (index < 0 || index >= text.length) return false;
		return pattern.test(text.charAt(index));
	}

	/**
	 * Counts the code points of a string (a surrogate pair is one).
	 * @param {string} text
	 * @returns {number}
	 */
	function codePointCount(text) {
		return Array.from(text).length;
	}

	/**
	 * Lower-cases A-Z only, keeping every other character and the length.
	 * @param {string} text
	 * @returns {string}
	 */
	function asciiLower(text) {
		return text.replace(/[A-Z]/g, function (ch) {
			return String.fromCharCode(ch.charCodeAt(0) + 32);
		});
	}

	/**
	 * Returns the index of the first character of the run of `pattern` that ends
	 * at `from`.
	 * @param {string} text
	 * @param {number} from 0-based, the run's last index.
	 * @param {RegExp} pattern
	 * @returns {number} The run's first index, from + 1 when the run is empty.
	 */
	function runStart(text, from, pattern) {
		var i = from;
		while (charIs(text, i, pattern)) i--;
		return i + 1;
	}

	/**
	 * Returns the index of the last character of the run of `pattern` starting
	 * at `from`.
	 * @param {string} text
	 * @param {number} from 0-based.
	 * @param {RegExp} pattern
	 * @returns {number} The run's last index, from - 1 when the run is empty.
	 */
	function runEnd(text, from, pattern) {
		var i = from;
		while (charIs(text, i, pattern)) i++;
		return i - 1;
	}

	// ======================================
	// ======================================
	// ======= 2/ Generic Replacement =======
	// ======================================
	// ======================================

	/**
	 * Replaces every accepted occurrence of `needle`, scanning left to right.
	 * @param {string} text
	 * @param {string} needle Non-empty literal.
	 * @param {boolean} caseInsensitive ASCII-only folding.
	 * @param {function(string, number, number): (null|{text: string, last: number, first?: number})} accept
	 *   Receives the text and the first and last index of the occurrence; returns
	 *   the replacement and the last index it consumes, or null to keep it. It may
	 *   also return `first`, an earlier index the replacement starts at (never
	 *   before the end of the previous replacement).
	 * @returns {string}
	 */
	function replaceOccurrences(text, needle, caseInsensitive, accept) {
		var haystack = caseInsensitive ? asciiLower(text) : text;
		var target = caseInsensitive ? asciiLower(needle) : needle;
		var out = '';
		var pos = 0;
		for (;;) {
			var first = haystack.indexOf(target, pos);
			if (first < 0) break;
			var last = first + target.length - 1;
			var accepted = accept(text, first, last);
			if (accepted) {
				var from = typeof accepted.first === 'number' ? Math.max(pos, accepted.first) : first;
				out += text.substring(pos, from) + accepted.text;
				pos = accepted.last + 1;
			} else {
				out += text.substring(pos, first + 1);
				pos = first + 1;
			}
		}
		return out + text.substring(pos);
	}

	// ============================
	// ============================
	// ======= 3/ The Rules =======
	// ============================
	// ============================

	/**
	 * Replaces token-like secrets (prefix + a long run of its charset).
	 * @param {string} text
	 * @param {object} rules Decoded redaction.json.
	 * @returns {string}
	 */
	function redactTokens(text, rules) {
		rules.token_prefixes.forEach(function (token) {
			var pattern = CHARSETS[token.charset];
			if (!pattern) throw new Error('redact: unknown charset ' + token.charset);
			text = replaceOccurrences(text, token.prefix, false, function (source, first, last) {
				if (charIs(source, first - 1, WORD_CHAR)) return null;
				var stop = runEnd(source, last + 1, pattern);
				if (stop - last < token.min_length) return null;
				return { text: rules.secret_placeholder, last: stop };
			});
		});
		return text;
	}

	/**
	 * Replaces the credential of a URL ("scheme://user:password@host"), keeping
	 * the scheme and the host.
	 * @param {string} text
	 * @param {object} rules
	 * @returns {string}
	 */
	function redactUrlCredentials(text, rules) {
		return replaceOccurrences(text, '://', false, function (source, first, last) {
			var stop = runEnd(source, last + 1, URL_USERINFO);
			if (stop <= last || !charIs(source, stop + 1, /^@$/)) return null;
			return { text: '://' + rules.secret_placeholder, last: stop };
		});
	}

	/**
	 * Replaces e-mail addresses: a local part, an @, and a dotted domain ending
	 * in a top-level label of at least two letters.
	 * @param {string} text
	 * @param {object} rules
	 * @returns {string}
	 */
	function redactEmails(text, rules) {
		return replaceOccurrences(text, '@', false, function (source, first, last) {
			var start = runStart(source, first - 1, EMAIL_LOCAL);
			if (start === first) return null;
			var stop = runEnd(source, last + 1, EMAIL_DOMAIN);
			// A trailing dot or dash is the sentence's, not the domain's
			while (stop > last && /^[.-]$/.test(source.charAt(stop))) stop--;
			var domain = source.substring(last + 1, stop + 1);
			var dot = domain.lastIndexOf('.');
			if (dot < 1) return null;
			var tld = domain.substring(dot + 1);
			if (
				tld.length < 2 ||
				!Array.from(tld).every(function (ch) {
					return LETTER.test(ch);
				})
			)
				return null;
			return { text: rules.email_placeholder, last: stop, first: start };
		});
	}

	/**
	 * Returns the index of the last character of the name that starts at `from`:
	 * a run of name characters, extended over single spaces (at most maxWords
	 * words) when that makes the name end at a separator, a quote or the end of
	 * the line, so "John Smith" is one folder but "jdoe and more" is the folder
	 * "jdoe".
	 * @param {string} source
	 * @param {number} from 0-based.
	 * @param {number} maxWords The most words one name may hold.
	 * @returns {number} The name's last index, from - 1 when there is none.
	 */
	function nameEnd(source, from, maxWords) {
		var firstEnd = runEnd(source, from, NAME_CHAR);
		if (firstEnd < from) return firstEnd;
		var stop = firstEnd;
		var ends = function (index) {
			return index >= source.length || charIs(source, index, NAME_END_CHAR);
		};
		for (var word = 1; word < maxWords; word++) {
			if (ends(stop + 1)) return stop;
			if (source.charAt(stop + 1) !== ' ') break;
			var nextEnd = runEnd(source, stop + 2, NAME_CHAR);
			if (nextEnd < stop + 2) break;
			stop = nextEnd;
		}
		return ends(stop + 1) ? stop : firstEnd;
	}

	/**
	 * Masks the folder and file names under the configuration directory: the
	 * directory becomes its placeholder, each name below it the name placeholder
	 * unless it is a name the product ships. Those names are chosen by the user
	 * (a hotstring pack, a backup), so they identify a person.
	 * @param {string} text
	 * @param {object} rules
	 * @param {string|undefined} dir The configuration directory as the text spells it.
	 * @param {boolean} caseInsensitive
	 * @returns {string}
	 */
	function maskConfigDir(text, rules, dir, caseInsensitive) {
		if (typeof dir !== 'string') return text;
		var trimmed = dir.replace(/[\/\\]+$/, '');
		if (trimmed === '') return text;
		var known = {};
		rules.config_known_names.forEach(function (name) {
			known[asciiLower(name)] = true;
		});
		var spellings = [];
		[trimmed, trimmed.replace(/\\/g, '/'), trimmed.replace(/\//g, '\\')].forEach(
			function (spelling) {
				if (spellings.indexOf(spelling) < 0) spellings.push(spelling);
			}
		);
		spellings.forEach(function (spelling) {
			text = replaceOccurrences(text, spelling, caseInsensitive, function (source, first, last) {
				if (charIs(source, last + 1, NAME_CHAR)) return null;
				// A path right after a quote ends at the closing quote, spaces included
				var quote = first > 0 ? source.charAt(first - 1) : '';
				if (quote !== "'" && quote !== '"') quote = '';
				var out = rules.config_placeholder;
				var i = last + 1;
				while (charIs(source, i, /^[\\/]$/)) {
					var start = i + 1;
					var stop;
					if (quote !== '') {
						stop = start - 1;
						while (
							stop + 1 < source.length &&
							!charIs(source, stop + 1, /^[\\/\r\n]$/) &&
							source.charAt(stop + 1) !== quote
						)
							stop++;
					} else {
						stop = nameEnd(source, start, rules.path_name_max_words);
					}
					var name = source.substring(start, stop + 1);
					if (name === '') {
						out += source.charAt(i);
						i = start;
					} else {
						out +=
							source.charAt(i) + (known[asciiLower(name)] ? name : rules.config_name_placeholder);
						i = stop + 1;
					}
				}
				return { text: out, last: i - 1 };
			});
		});
		return text;
	}

	/**
	 * Replaces the profile folder of any other account (a Users folder on
	 * Windows, /home/other, /Users/other) by the account placeholder, except the shared
	 * profiles every machine has.
	 * @param {string} text
	 * @param {object} rules
	 * @returns {string}
	 */
	function redactForeignHomes(text, rules) {
		rules.foreign_home_markers.forEach(function (marker) {
			text = replaceOccurrences(text, marker, true, function (source, first, last) {
				var stop = nameEnd(source, last + 1, rules.path_name_max_words);
				if (stop <= last) return null;
				var name = asciiLower(source.substring(last + 1, stop + 1));
				if (rules.shared_profile_names.indexOf(name) >= 0) return null;
				return { text: source.substring(first, last + 1) + rules.account_placeholder, last: stop };
			});
		});
		return text;
	}

	/**
	 * Replaces the credential of an "Authorization: Bearer <token>" value.
	 * @param {string} text
	 * @param {object} rules
	 * @returns {string}
	 */
	function redactBearer(text, rules) {
		return replaceOccurrences(text, 'bearer', true, function (source, first, last) {
			if (charIs(source, first - 1, WORD_CHAR)) return null;
			var spaces = runEnd(source, last + 1, BLANK);
			if (spaces === last) return null;
			var stop = runEnd(source, spaces + 1, BEARER_CHAR);
			if (stop - spaces < rules.bearer_min_length) return null;
			return { text: source.substring(first, spaces + 1) + rules.secret_placeholder, last: stop };
		});
	}

	/**
	 * Replaces the value of a key=value or "key": "value" secret, keeping the key.
	 * @param {string} text
	 * @param {object} rules
	 * @returns {string}
	 */
	function redactKeyValues(text, rules) {
		rules.secret_keys.forEach(function (key) {
			text = replaceOccurrences(text, key, true, function (source, first, last) {
				if (charIs(source, first - 1, WORD_CHAR) || charIs(source, last + 1, WORD_CHAR))
					return null;
				var i = last + 1;
				if (charIs(source, i, QUOTE)) i++;
				i = runEnd(source, i, BLANK) + 1;
				if (!charIs(source, i, /^[=:]$/)) return null;
				i = runEnd(source, i + 1, BLANK) + 1;
				if (charIs(source, i, QUOTE)) i++;
				var stop = i;
				while (stop < source.length && !charIs(source, stop, VALUE_STOP)) stop++;
				stop--;
				if (codePointCount(source.substring(i, stop + 1)) < rules.secret_value_min_length)
					return null;
				return { text: source.substring(first, i) + rules.secret_placeholder, last: stop };
			});
		});
		return text;
	}

	/**
	 * Replaces the home folder, in both slash styles, by its placeholder.
	 * @param {string} text
	 * @param {object} rules
	 * @param {string|undefined} home
	 * @param {boolean} caseInsensitive
	 * @returns {string}
	 */
	function redactHome(text, rules, home, caseInsensitive) {
		if (typeof home !== 'string') return text;
		var trimmed = home.replace(/[\/\\]+$/, '');
		if (trimmed === '') return text;
		var spellings = [];
		[trimmed, trimmed.replace(/\\/g, '/'), trimmed.replace(/\//g, '\\')].forEach(
			function (spelling) {
				if (spellings.indexOf(spelling) < 0) spellings.push(spelling);
			}
		);
		spellings.forEach(function (spelling) {
			text = replaceOccurrences(text, spelling, caseInsensitive, function (source, first, last) {
				if (charIs(source, last + 1, PATH_CHAR)) return null;
				return { text: rules.home_placeholder, last: last };
			});
		});
		return text;
	}

	/**
	 * Replaces the account name, as a whole word, by its placeholder.
	 * @param {string} text
	 * @param {object} rules
	 * @param {string|undefined} user
	 * @param {boolean} caseInsensitive
	 * @returns {string}
	 */
	function redactAccount(text, rules, user, caseInsensitive) {
		if (typeof user !== 'string' || codePointCount(user) < rules.min_account_name_length)
			return text;
		return replaceOccurrences(text, user, caseInsensitive, function (source, first, last) {
			if (charIs(source, first - 1, WORD_CHAR) || charIs(source, last + 1, WORD_CHAR)) return null;
			return { text: rules.account_placeholder, last: last };
		});
	}

	// =============================
	// =============================
	// ======= 4/ Public API =======
	// =============================
	// =============================

	/**
	 * Redacts diagnostic text before it leaves the machine.
	 * @param {string} text
	 * @param {object} rules Decoded _shared/modules/diagnostics/redaction.json.
	 * @param {{home?: string, user?: string, case_insensitive?: boolean}} context
	 *   The platform's home folder, account name, and whether its paths compare
	 *   case-insensitively.
	 * @returns {string}
	 * @throws {Error} When the text is not a string or the rules are missing.
	 */
	function apply(text, rules, context) {
		if (typeof text !== 'string') throw new Error('redact: text must be a string');
		if (!rules || typeof rules !== 'object')
			throw new Error('redact: rules must be the decoded redaction.json');
		context = context && typeof context === 'object' ? context : {};
		var folded = context.case_insensitive === true;
		text = redactTokens(text, rules);
		text = redactUrlCredentials(text, rules);
		text = redactBearer(text, rules);
		text = redactKeyValues(text, rules);
		if (
			typeof rules.path_name_max_words !== 'number' ||
			rules.path_name_max_words < 1 ||
			typeof rules.config_placeholder !== 'string' ||
			typeof rules.config_name_placeholder !== 'string' ||
			!Array.isArray(rules.config_known_names)
		)
			throw new Error('redact: the rules lack the path name and configuration directory settings');
		// The directory is searched as it is spelled, then as the home pass leaves
		// it (a log written earlier already holds "~" for the home folder)
		text = maskConfigDir(text, rules, context.config_dir, folded);
		text = redactHome(text, rules, context.home, folded);
		if (typeof context.config_dir === 'string')
			text = maskConfigDir(
				text,
				rules,
				redactHome(context.config_dir, rules, context.home, folded),
				folded
			);
		text = redactForeignHomes(text, rules);
		text = redactEmails(text, rules);
		text = redactAccount(text, rules, context.user, folded);
		return text;
	}

	global.ErgoptiRedact = { apply: apply };
})(window);
