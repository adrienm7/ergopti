#!/usr/bin/env python3
"""Qualify actual Browse receiving, reusing the original unreaped-session owner."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import tempfile
import time

PACKET = Path(__file__).resolve().parent
V7 = PACKET.parent / "linux-wizard-real-webkit-private-harness-source-only-v7-metadata-20261011"
PREFIX = Path("/workspace/tooling/wizard-browse-zenity-v1")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def atomic_json(path, value):
    pending = path.with_suffix(".pending")
    with pending.open("x") as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write("\n")
    pending.replace(path)


def process_identity(pid):
    tail = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
    return int(tail[2]), tail[19]


def existing_environment(profile):
    env = os.environ.copy()
    for key in ("DISPLAY", "WAYLAND_DISPLAY", "DBUS_SESSION_BUS_ADDRESS", "XAUTHORITY"):
        env.pop(key, None)
    for key, child in {
        "XDG_CONFIG_HOME": "config", "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state",
        "XDG_CACHE_HOME": "cache", "XDG_RUNTIME_DIR": "runtime", "TMPDIR": "tmp",
    }.items():
        folder = profile / child
        if folder.is_symlink() or not folder.is_dir():
            raise RuntimeError("Original owned V7 XDG directory absent/changed: " + child)
        env[key] = str(folder)
    env["PATH"] = ":".join((str(PREFIX / "bin"), "/workspace/tooling/graphical-bin",
                            "/workspace/tooling/gtk/usr/bin", "/workspace/tooling/native/usr/bin",
                            env.get("PATH", "")))
    env["LD_LIBRARY_PATH"] = ":".join(filter(None, (
        "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu",
        "/workspace/tooling/native/usr/lib/x86_64-linux-gnu", env.get("LD_LIBRARY_PATH", ""))))
    env["LUA_PATH"] = (
        "./?.lua;./?/init.lua;../_shared/lua/?.lua;../_shared/lua/?/init.lua;"
        "/workspace/tooling/gtk/usr/share/lua/5.1/?.lua;"
        "/workspace/tooling/gtk/usr/share/lua/5.1/?/init.lua;"
        "/workspace/tooling/native/usr/share/lua/5.1/?.lua;"
        "/workspace/tooling/native/usr/share/lua/5.1/?/init.lua;;")
    env["LUA_CPATH"] = (
        "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;"
        "/workspace/tooling/native/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;;")
    env["GI_TYPELIB_PATH"] = "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/girepository-1.0"
    env["WEBKIT_INJECTED_BUNDLE_PATH"] = "/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/injected-bundle"
    env["GSETTINGS_SCHEMA_DIR"] = str(PREFIX / "state/schemas")
    env.update(GDK_BACKEND="x11", PYTHONDONTWRITEBYTECODE="1")
    return env


def git_fence(checkout):
    environment = os.environ.copy()
    environment["GIT_OPTIONAL_LOCKS"] = "0"
    return {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True, env=environment),
            "status": subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=normal"],
                                               cwd=checkout, text=True, env=environment),
            "index": digest(checkout / ".git/index")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, default=Path("/workspace/ergopti"))
    parser.add_argument("--v7-receipt", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print("SOURCE ONLY: no chooser installation, profile mutation, or native execution.")
        return 0
    report = {"status": "running", "planned_phases": ["cancel", "accept", "cancel", "retry"],
              "completed_phases": [], "actors": [], "file_assertions": [], "cleanup_errors": [],
              "qualification_errors": [], "unrun": ["physical input", "Wayland", "Windows/macOS",
              "installed daemon restart", "direct capture of production chooser stdout/exit",
              "standalone chooser stdout/exit oracle"]}
    primary = server = native = actor = None
    reader = writer = None
    run_dir = profile = checkout = old_files = frozen = original = fence = None
    all_sessions = []

    def verify(condition, name):
        report["file_assertions"].append({"name": name, "passed": condition is True})
        if condition is not True:
            raise RuntimeError(name)

    def retire(label, session):
        if session is not None and not session.disposed:
            try:
                session.dispose()
            except BaseException as error:
                report["cleanup_errors"].append(label + ": " + str(error))

    def files():
        # Actual config/bootstrap/presets and metrics bytes are independent of
        # GTK caches/logs. Absence, symlinks and newly created files are observed.
        roots = [profile / child for child in ("config", "chosen-config", "recommended-config")]
        result = {str(path.relative_to(profile)): original.snapshot(path) for path in roots}
        metrics = profile / "data/ergopti"
        result["data/ergopti"] = original.snapshot(metrics)
        return result

    def file_checks(label):
        verify(files() == old_files, label + " exact original config/bootstrap/metrics bytes unchanged")
        for relative in (oracle["accepted_directory_relative"], oracle["second_retry_directory_relative"]):
            target = profile / relative
            verify(target.is_dir() and not target.is_symlink() and not any(target.iterdir()),
                   label + " new target remains empty: " + relative)

    try:
        proposal = read_json(PACKET / "SOURCE-PROPOSAL.json")
        for name, expected in proposal["files"].items():
            verify(digest(PACKET / name) == expected["sha256"], "reviewed adapter byte pin: " + name)
        checkout = args.checkout.resolve(strict=True)
        frozen = read_json(PACKET / "SOURCE-CLOSURE.json")
        verify(all(digest(checkout / p) == h for p, h in frozen["production_sources"].items()),
               "all654 production sources match frozen input")
        fence = git_fence(checkout)
        pins = read_json(PACKET / "V7-UNCHANGED-PINS.json")
        verify(all(digest(V7 / p) == h for p, h in pins.items()), "original V7 five-mode packet exact")
        dependencies = read_json(PACKET / "DEPENDENCIES.json")
        verify(all(digest(Path(p)) == h for p, h in dependencies["unmodified_environment_pins"].items()),
               "existing environment/namespace/actor bytes unchanged")
        verify(all(digest(Path(p)) == h for p, h in proposal["additional_environment_pins"].items()),
               "original reaper byte pin unchanged")
        installed = read_json(PREFIX / "INSTALL-RECEIPT.json")
        verify(installed["status"] == "DEPENDENCIES_EXTRACTED; native chooser and Browse remain UNRUN"
               and installed["prefix"] == str(PREFIX)
               and installed["source_manifest_sha256"] == digest(PACKET / "DEPENDENCIES.json")
               and installed["old_environment_pins_unchanged"] is True, "trusted owned installation receipt")
        verify(installed["packages"] == [{"name": p["name"], "version": p["version"], "sha256": p["sha256"]}
                                         for p in dependencies["packages"]], "installed package provenance exact")
        for item in dependencies["packages"]:
            payload = PREFIX / "packages" / Path(item["filename"]).name
            verify(payload.stat().st_size == item["bytes"] and digest(payload) == item["sha256"],
                   "signed payload retained unchanged: " + item["name"])
        verify(digest(PREFIX / "usr/bin/zenity") == installed["binary_sha256"]
               and digest(PREFIX / "bin/zenity") == digest(PACKET / "zenity-owned-wrapper.sh") == installed["wrapper_sha256"]
               and digest(PREFIX / "state/schemas/gschemas.compiled") == installed["schemas_sha256"],
               "actual chooser/wrapper/schema installation bytes retained")
        # Import only the already reviewed controller's genuine lifecycle owner.
        # Its CLI/main is not invoked, and none of its five modes is changed.
        sys.dont_write_bytecode = True
        spec = importlib.util.spec_from_file_location("owned_original_wizard", V7 / "run-private-wizard.py")
        original = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(original)
        actual_receipt_path = args.v7_receipt.resolve(strict=True)
        previous = read_json(actual_receipt_path)
        profile = Path(previous["profile"])
        verify(profile.is_dir() and not profile.is_symlink() and profile.parent == V7
               and profile.name.startswith("actual-wizard-") and profile.resolve() == profile,
               "genuine retained V7 owned profile")
        verify(actual_receipt_path == profile / "ACTUAL-RESULTS.json", "actual V7 receipt belongs to profile")
        planned = ["cancel", "finish", "reopen", "locales", "recommended"]
        verify(previous["status"] == "PASS" and previous["planned_processes"] == planned
               and previous["passed_processes"] == planned and not previous["cleanup_errors"]
               and not previous["qualification_errors"] and previous["xvfb_session_disposed"] is True
               and previous["final_source_reconciliation"]["status"] == "MATCH"
               and previous["source_closure_sha256"] == digest(PACKET / "SOURCE-CLOSURE.json")
               and previous["worker_sha256"] == pins["wizard-native-worker.lua"]
               and previous["controller_sha256"] == pins["run-private-wizard.py"],
               "all five original V7 actual scenarios and cleanup qualified")
        actual_snapshot = original.snapshot(profile)
        actual_snapshot.pop("ACTUAL-RESULTS.json", None)
        verify(actual_snapshot == previous["final_profile_files"], "retained V7 profile exact before new allocation")
        oracle = read_json(PACKET / "ORIGINAL-BROWSE-EXPECTATIONS.json")
        old_files = files()
        run_dir = Path(tempfile.mkdtemp(prefix="actual-browse-", dir=PACKET))
        report.update(run_dir=str(run_dir), profile=str(profile), v7_receipt_sha256=digest(actual_receipt_path),
                      source_closure_sha256=digest(PACKET / "SOURCE-CLOSURE.json"),
                      original_oracle_sha256=digest(PACKET / "ORIGINAL-BROWSE-EXPECTATIONS.json"))
        for relative in (oracle["accepted_directory_relative"], oracle["second_retry_directory_relative"]):
            (profile / relative).mkdir(mode=0o700)
        file_checks("before native receiving")
        env = existing_environment(profile)
        binaries = {name: shutil.which(name, path=env["PATH"]) for name in ("luajit", "Xvfb", "dbus-run-session")}
        verify(all(binaries.values()), "actual native executables available")
        cwd = checkout / "static/ergopti_plus/linux"
        reader, writer = os.pipe()
        with (run_dir / "xvfb.log").open("xb") as log:
            server = original.OwnedSession([binaries["Xvfb"], "-displayfd", str(writer), "-screen", "0",
                         "1024x768x24", "-nolisten", "tcp", "-noreset"], run_dir / "xvfb-status.json",
                         log, log, env, (writer,), cwd=cwd)
        all_sessions.append(("Xvfb", server))
        os.close(writer)
        writer = None
        verify(bool(select.select([reader], [], [], 5)[0]), "actual owned Xvfb readiness")
        display = os.read(reader, 32).decode("ascii").strip()
        verify(display.isdecimal(), "actual owned X11 display identity")
        env.update(DISPLAY=":" + display, NO_AT_BRIDGE="1")
        worker_receipt = run_dir / "native.json"
        with (run_dir / "native.log").open("xb") as log:
            native = original.OwnedSession([binaries["dbus-run-session"], "--", binaries["luajit"],
                         str(PACKET / "wizard-browse-worker.lua"), str(profile), str(run_dir),
                         str(worker_receipt), str(PACKET / "ORIGINAL-BROWSE-EXPECTATIONS.json")],
                         run_dir / "native-status.json", log, log, env, cwd=cwd)
        all_sessions.append(("native Browse", native))
        owner = process_identity(native.pgid)
        verify(owner[0] == native.pgid, "original unreaped native ownership anchor retained")
        report.update(owned_display=env["DISPLAY"], owned_native_pgid=native.pgid, anchor_starttime=owner[1])
        deadline = time.monotonic() + 180
        next_index, active = 1, None
        while native.status() is None and time.monotonic() < deadline:
            if active is None and next_index <= 4:
                request_path = run_dir / ("request-" + str(next_index) + ".json")
                if request_path.is_file():
                    request = read_json(request_path)
                    phase_id, mode = str(next_index), report["planned_phases"][next_index - 1]
                    verify(request == {"id": phase_id, "mode": mode}, "real worker request matches ordered phase " + phase_id)
                    verify(process_identity(native.pgid) == owner, "native anchor current before actor " + phase_id)
                    actor_receipt = run_dir / ("actor-" + phase_id + ".json")
                    with (run_dir / ("actor-" + phase_id + ".log")).open("xb") as log:
                        actor = original.OwnedSession([sys.executable, str(PACKET / "chooser-input-actor.py"),
                              "--execute", "--anchor-pgid", str(native.pgid), "--anchor-starttime", owner[1],
                              "--profile", str(profile), "--mode", mode, "--receipt", str(actor_receipt)],
                              run_dir / ("actor-" + phase_id + "-status.json"), log, log, env, cwd=cwd)
                    all_sessions.append(("actor " + phase_id, actor))
                    active = {"id": phase_id, "mode": mode, "receipt": actor_receipt, "started": time.monotonic()}
                    atomic_json(run_dir / ("started-" + phase_id + ".json"),
                                {"id": phase_id, "mode": mode, "status": "OWNED_ACTOR_STARTED"})
            if active is not None:
                status = actor.status()
                if status is not None:
                    phase_id, mode = active["id"], active["mode"]
                    actual = read_json(active["receipt"])
                    report["actors"].append({"id": phase_id, "command_status": status, "receipt": actual,
                                             "receipt_sha256": digest(active["receipt"]), "owned_actor_pgid": actor.pgid})
                    verify(status["exit_code"] == 0 and actual["mode"] == mode
                           and actual["status"] == "INPUT_SEQUENCE_COMPLETED; receiving UNQUALIFIED"
                           and actual["owned_window"]["title"] == oracle["original_locale_titles"]["en"]["original_native_title"]
                           and bool(actual["commands"]), "real owned chooser input completed " + phase_id)
                    retire("actor " + phase_id, actor)
                    verify(actor.disposed and not report["cleanup_errors"], "actual actor session retired " + phase_id)
                    file_checks("after real chooser " + phase_id)
                    atomic_json(run_dir / ("completed-" + phase_id + ".json"),
                                {"id": phase_id, "mode": mode, "status": "INPUT_AND_FILES_ACKNOWLEDGED"})
                    report["completed_phases"].append(mode)
                    active = None
                    next_index += 1
                elif time.monotonic() - active["started"] > 50:
                    raise RuntimeError("actual chooser actor deadline: " + active["id"])
            time.sleep(0.05)
        status = native.status()
        verify(status is not None, "bounded genuine native Browse worker completed")
        report["native_command_status"] = status
        actual = read_json(worker_receipt)
        report["native_receipt"] = actual
        report["native_receipt_sha256"] = digest(worker_receipt)
        verify(status["exit_code"] == 0 and actual["status"] == "PASS"
               and actual["cleanup"].get("manager_retired") is True
               and not actual["cleanup"].get("stream_errors"), "actual native receiving and manager retirement passed")
        verify(report["completed_phases"] == report["planned_phases"]
               and [p["mode"] for p in actual["phases"]] == report["planned_phases"]
               and all(p["status"] == "PASS" for p in actual["phases"]), "all four actual DOM Browse phases passed")
        file_checks("after chosen-folder reads and reopen")
    except BaseException as error:
        primary = error
        report.update(primary_error=str(error), primary_type=type(error).__name__)
    finally:
        # Each phase independently attempts cleanup; raw primary is never
        # replaced by a later session/file/receipt failure. Original anchors
        # cannot be poll/wait/communicated before their exact group teardown.
        for label, session in reversed(all_sessions):
            retire(label, session)
        for label, fd in (("display reader", reader), ("display writer", writer)):
            if fd is not None:
                try:
                    os.close(fd)
                except BaseException as error:
                    report["cleanup_errors"].append(label + ": " + str(error))
        report["owned_sessions_disposed"] = all(session.disposed for _, session in all_sessions)
        if old_files is not None:
            try:
                file_checks("after all owned native cleanup")
            except BaseException as error:
                report["qualification_errors"].append("final files: " + str(error))
        if checkout is not None and frozen is not None:
            try:
                changed = [p for p, h in frozen["production_sources"].items() if digest(checkout / p) != h]
                report["final_source_reconciliation"] = {"status": "DRIFT" if changed else "MATCH", "changed": changed}
                if changed or (fence is not None and git_fence(checkout) != fence):
                    report["qualification_errors"].append("production Source or Git fence changed")
                if original is not None and any(digest(V7 / p) != h for p, h in pins.items()):
                    report["qualification_errors"].append("original V7 packet changed")
            except BaseException as error:
                report["qualification_errors"].append("Source accounting: " + str(error))
        report["status"] = "FAIL" if primary is not None or report["cleanup_errors"] or report["qualification_errors"] else "PASS"
        receipt = (run_dir / "ACTUAL-RESULTS.json") if run_dir else PACKET / ("FAILED-BROWSE-" + str(time.time_ns()) + ".json")
        try:
            atomic_json(receipt, report)
            receipt_hash = digest(receipt)
        except BaseException as error:
            report["cleanup_errors"].append("durable receipt: " + str(error))
            report["status"] = "FAIL"
            receipt_hash = None
        try:
            print(json.dumps({"status": report["status"], "receipt": str(receipt), "sha256": receipt_hash,
                              "primary_error": report.get("primary_error"), "cleanup_errors": report["cleanup_errors"],
                              "qualification_errors": report["qualification_errors"]}))
        except BaseException as error:
            report["cleanup_errors"].append("final stdout: " + str(error))
            report["status"] = "FAIL"
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
