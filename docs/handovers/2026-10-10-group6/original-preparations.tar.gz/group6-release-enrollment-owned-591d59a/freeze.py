from pathlib import Path
import ast, difflib, hashlib, json, subprocess
root = Path('/tmp/group6-release-enrollment-owned-591d59a')
repo = Path('/workspace/ergopti')
recovered = Path('/tmp/group6-release-corpus-recovered-opyfdruv')
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head == '591d59a942780465bca95956dc3cc9b2e960fa9e'
def sha(data): return hashlib.sha256(data).hexdigest()
def bind(path):
    data=path.read_bytes()
    return {'path':str(path),'sha256':sha(data),'size':len(data)}
js='tools/test/test-macos-opaque-network-admission.cjs'
py='tools/diagnostics/macos_release_stage_route_test.py'
old=(root/'preimage'/js).read_bytes()
new=(root/'candidate'/js).read_bytes()
assert old == (repo/js).read_bytes()
assert new == old + (root/'APPEND.cjs').read_bytes()
assert not (repo/py).exists()
original=(recovered/'release/receiving.py').read_text()
candidate=(root/'candidate'/py).read_text()
mapping=json.loads((root/'MECHANICAL-MAPPING.json').read_text())
assert sha(original.encode())==mapping['original_sha256']
assert sha(candidate.encode())==mapping['candidate_sha256']
inverse=candidate
for op in reversed(mapping['operations']):
    assert inverse.count(op['after'])==1
    inverse=inverse.replace(op['after'],op['before'])
assert inverse.startswith(mapping['header_added'])
inverse=inverse[len(mapping['header_added']):]
assert inverse==original
start=original.index('URL = '); stop=original.index('\n\n# Portable adapters')
fragment=original[start:stop]
assert sha(fragment.encode())==mapping['corpus_sha256']
assert candidate[candidate.index('URL = '):candidate.index('\n\n# Portable adapters')]==fragment
original_ast=ast.parse(original)
perms=next(n.value for n in original_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PERMUTATIONS' for t in n.targets))
extras=next(n.value for n in original_ast.body if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='CASES')
assert len(perms.elts)==6 and len(extras.elts)==44
ast_sha=sha(ast.dump(ast.parse(candidate),include_attributes=False).encode())
(root/'FROZEN-PYTHON-AST.sha256').write_text(ast_sha+'\n')
(root/'CHECK-FORMAT-AST.py').write_text('''# Source-only AST guard for root-owned formatter rebind, not a receiving run.
import ast, hashlib, pathlib, sys
expected = pathlib.Path(__file__).with_name("FROZEN-PYTHON-AST.sha256").read_text().strip()
actual = hashlib.sha256(ast.dump(ast.parse(pathlib.Path(sys.argv[1]).read_text()), include_attributes=False).encode()).hexdigest()
if actual != expected:
    raise SystemExit("Formatter changed the frozen Python AST")
print("Frozen Python AST preserved; no receiving execution")
''')
def diff(before,after,label):
    return ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+label if before else '/dev/null',tofile='b/'+label))
patch=diff(old.decode(),new.decode(),js)+diff('',candidate,py)
(root/'enrollment.patch').write_text(patch)
# Independent unified-hunk reconstruction; do not execute git apply or target code.
def reconstruct(before, patch_lines):
    import re
    lines=before.splitlines(True); output=[]; pos=0; i=2
    while i<len(patch_lines):
        m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',patch_lines[i]); assert m
        at=int(m.group(1))-1 if int(m.group(1)) else 0
        output.extend(lines[pos:at]); pos=at; i+=1
        while i<len(patch_lines) and not patch_lines[i].startswith('@@ '):
            row=patch_lines[i]; i+=1
            if row.startswith(' '): assert lines[pos]==row[1:]; output.append(lines[pos]); pos+=1
            elif row.startswith('-'): assert lines[pos]==row[1:]; pos+=1
            elif row.startswith('+'): output.append(row[1:])
            else: raise AssertionError('Unexpected diff record')
    output.extend(lines[pos:]); return ''.join(output)
for before,after,label in [(old.decode(),new.decode(),js),('',candidate,py)]:
    forward=diff(before,after,label)
    assert reconstruct(before,forward.splitlines(True))==after
    reverse=diff(after,before,label)
    assert reconstruct(after,reverse.splitlines(True))==before
contexts=[
 'static/ergopti_plus/macos/adapters/release_stage.sh',
 'static/ergopti_plus/macos/modules/updater/release_installer.lua',
 'tools/lib/python.cjs',
 'tools/test/run-linux-managed-http-native.cjs',
 'tools/test/run-linux-managed-http-phase.py',
 'tools/build/stage-linux-network-runtime.py',
 'tools/lib/git_bash.py','tools/__init__.py',
 'tools/diagnostics/macos_owned_process.py',
 'tools/test/run-js-suite.cjs',
]
evidence=[recovered/'RECOVERY-RECEIPT.json',recovered/'MANIFEST.json']
evidence.extend(sorted((recovered/'release').iterdir()))
metadata={
 'version':1,'kind':'private-source-only-safe-corpus-enrollment', 'head':head,
 'candidate_paths':[js,py], 'new_path_absent':py,
 'preimages':[bind(root/'preimage'/js)], 'postimages':[bind(root/'candidate'/js),bind(root/'candidate'/py)],
 'patch':bind(root/'enrollment.patch'),
 'source_proof':{'original_cjs_whole_prefix_exact':True,'original_controls_preserved':61,
 'original_python_whole_mechanical_inverse_exact':True,'independent_patch_forward_and_inverse_exact':True,
 'original_python_sha256':sha(original.encode()),'corpus_fragment_sha256':sha(fragment.encode()),
 'literal_case_count':50,'compact_permutation_count':6,'explicit_other_case_count':44,
 'no_expected_literal_or_assertion_changes':True,'python_ast_sha256':ast_sha},
 'packet_inputs':[bind(root/p) for p in ['APPEND.cjs','MECHANICAL-MAPPING.json','CONTRACT.md','FROZEN-PYTHON-AST.sha256','CHECK-FORMAT-AST.py','prepare.py','freeze.py']],
 'production_and_owner_context':[bind(repo/p) for p in contexts],
 'recovered_evidence':[bind(p) for p in evidence],
 'archive':bind(repo/'docs/handovers/2026-10-10-group6-continuation/receiving-evidence.tar.gz'),
 'reuse':{'linux':'unchanged ownPhase(kind=command), original phase/kernel owner and source imports, CPython spawnChild seam',
 'darwin':'unchanged macos_owned_process.py run guardian120s, exact ChildProcess close and strict six-field closed packet'},
 'shared_owner_edits':0,'workflow_edits':0,'product_edits':0,'live_edits':0,'index_ref_edits':0,
 'author_target_executions':0,'author_native_executions':0,'author_suites':0,'author_formatter_executions':0,
 'qualification':{'current_enrollment':'UNRUN','archived_frozen_portable_candidate':'50 PASS / 0 FAIL; prior root receipt, not this revision execution',
 'archived_frozen_portable_preimage':'6 PASS / 44 FAIL; prior root receipt',
 'linux_and_darwin':'mandatory actual corpus and original owner closure replay required',
 'darwin_native':'genuine NativeProcessGroups capability and TERM/INT cancellation replay required',
 'windows':'61 original deterministic controls retained; corpus explicitly UNEXECUTED unsupported POSIX capability, zero native credit',
 'unknown_host':'refused','ruff':'pending root-owned AST-preserving formatting and exact hash rebind'},
 'limits':['Darwin inherited-PGID only; no escaped-session guarantee','no immediate parent-death monitor','visible source identity checks do not prove ABA resistance','unknown retirement retains all fixture inputs','portable corpus gives no genuine macOS network/package/image acceptance','transversal16/38 remains OPEN CODE']
}
(root/'MANIFEST.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'packet':str(root),'manifest':bind(root/'MANIFEST.json'),'patch':bind(root/'enrollment.patch'),'postimages':metadata['postimages'],'all_source_proofs':True}))
