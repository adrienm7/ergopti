"""Preserve exact reviewed preparations and bounded existing receiving evidence."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

PACKETS = {
    "catalogue-r5": Path(
        "/workspace/scratch/group6-managed-ollama-migration-preparation62/"
        "revision5-formatted-receiving"
    ),
    "debug-certificate-code": Path("/tmp/group6-http-debug-certificate-code-4e9-tb831oxi"),
    "leaf-digest-pin": Path("/tmp/group6-wire-leaf-sha256-4e9-kxr2b817"),
}
CHECKPOINT = Path("/workspace/scratch/group6-restored-next-slices-20261010")
RECEIPTS = {
    "catalogue-r5-review.json": Path(
        "/tmp/group6-review-resume-20261010/"
        "OLLAMA-CATALOGUE-R5-SOURCE-AND-SAVED-RECEIVING-ACK.json"
    ),
    "catalogue-r5-root-receiving.json": Path(
        "/tmp/group6-catalogue-receiving-cETm4T/RESULTS.json"
    ),
    "debug-certificate-code-review.json": Path(
        "/tmp/group6-review-resume-20261010/"
        "HTTP-DEBUG-CERTIFICATE-CODE-PREPARATORY-SOURCE-ACK.json"
    ),
    "leaf-digest-review.json": Path(
        "/tmp/group6-independent-leaf-digest-source-review-xtuc973p/SOURCE-ACK.json"
    ),
    "native-tls-code-scan.json": Path(
        "/tmp/group6-native-tls-codes-4e9-728ff1ol/RETAINED-CODE-SCAN.json"
    ),
    "native-4e9-terminal.json": CHECKPOINT / "CI-MONITOR-38027004065-TERMINAL.json",
    "native-4e9-wpad.json": CHECKPOINT / "CI-MONITOR-38027004065-WPAD-BOTH.json",
    "native-4e9-brew.json": CHECKPOINT / "CI-MONITOR-38027004065-BREW.json",
    "snapshot-generator.py": Path(__file__),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(filename):
    if filename.is_symlink() or not filename.is_file():
        raise RuntimeError("Only regular owned preparation files are accepted")
    data = filename.read_bytes()
    data.decode("utf-8")
    if b"\r" in data or len(data) > 2 * 1024 * 1024:
        raise RuntimeError("Preparation source must be bounded LF text")
    return data


members = {}
for prefix, directory in PACKETS.items():
    for filename in sorted(directory.rglob("*")):
        if filename.is_symlink():
            raise RuntimeError("Preparation aliases are refused")
        if filename.is_file():
            members[prefix + "/" + filename.relative_to(directory).as_posix()] = read_regular(
                filename
            )
for name, filename in RECEIPTS.items():
    members["receipts/" + name] = read_regular(filename)
manifest = {
    "version": 1,
    "kind": "reviewed-source-preparations-and-existing-receiving-evidence",
    "feature_predecessor": "4e9f92fdc88367b087e4b15a0130d23972b6ba88",
    "members": {
        name: {"sha256": digest(data), "size": len(data)}
        for name, data in sorted(members.items())
    },
    "limits": [
        "Archiving does not execute sources or validate installation",
        "Catalogue R5 alone has executed original/candidate Linux receiving",
        "Darwin host admission in those controls is explicitly modeled",
        "The DEBUG diagnostic needs exact historical-source inverse enrollment",
        "The leaf digest pin is not a proved certificate cause or correction",
        "No primary native trust or Homebrew consent failure is claimed fixed",
        "Full migration remains code, coordinated ownership and native qualification work",
        "Historical source locators are provenance, not live filesystem authority",
    ],
}
members["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
destination = Path("/tmp/group6-receiving-followup-preparations.tar.gz")
if destination.exists():
    raise RuntimeError("An existing snapshot must not be overwritten")
with destination.open("xb") as output:
    with gzip.GzipFile(fileobj=output, filename="", mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o600
                entry.mtime = entry.uid = entry.gid = 0
                archive.addfile(entry, io.BytesIO(data))
with tarfile.open(destination, "r:gz") as archive:
    entries = archive.getmembers()
    if len(entries) != len(members) or any(not entry.isfile() for entry in entries):
        raise RuntimeError("Snapshot regular-member census refused")
    for entry in entries:
        if archive.extractfile(entry).read() != members[entry.name]:
            raise RuntimeError("Snapshot bytes refused")
receipt = {
    "version": 1,
    "archive": str(destination),
    "sha256": digest(destination.read_bytes()),
    "bytes": destination.stat().st_size,
    "regular_members": len(members),
    "source_execution": 0,
}
Path("/tmp/group6-receiving-followup-snapshot.json").write_text(
    json.dumps(receipt, indent=2) + "\n"
)
print(json.dumps(receipt))
