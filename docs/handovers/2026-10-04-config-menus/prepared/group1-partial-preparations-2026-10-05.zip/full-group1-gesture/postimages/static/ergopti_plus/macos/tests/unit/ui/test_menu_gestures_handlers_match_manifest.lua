--- tests/unit/ui/test_menu_gestures_handlers_match_manifest.lua

--- ==============================================================================
--- MODULE: Regression — a gesture menu row vanished from the menu (F-HIGH-5)
--- DESCRIPTION:
--- A gestures_menu entry carrying an `id` with a real registered handler was
--- declared with `type = "feature"` in manifest.toml — the generic path-based
--- idiom for items rendered elsewhere. ManifestMenu.build's "feature" branch is
--- an INTENTIONAL silent no-op reserved for legitimate path-only entries, so the
--- misclassified id-bearing entry produced identical silence: the row never
--- appeared in the rendered menu, with no error or log.
---
--- The row that was lost (the circular Spaces checkbox) is retired since the
--- wrap became its own pair of actions; the class of defect is not. This test
--- therefore holds every id-bearing gestures_menu entry to a rendered type, and
--- drives ManifestMenu.build against the REAL manifest data to prove a
--- declared, command-backed row is built, ticked from its checked_when getter
--- and wired to the command the driver registers.
--- ==============================================================================

local helpers = require("tests.helpers")

--- Builds a dyn_handlers table shaped like menu_gestures.lua's real one.
--- @return table dyn_handlers id -> function(items, ctx)
local function make_dyn_handlers()
	local function noop_handler(items, _ctx)
		table.insert(items, { title = "noop" })
	end

	return {
		gesture_slots_2 = noop_handler,
		gesture_slots_3 = noop_handler,
		gesture_slots_4 = noop_handler,
		gesture_slots_5 = noop_handler,
	}
end

helpers.describe("menu_gestures: every id-bearing row is rendered by the manifest (F-HIGH-5)", function()
	helpers.it("menu_manifest.json declares no id-bearing gestures_menu entry as type=feature", function()
		-- Goes through ManifestMenu.get_array (not a bare hs.json.decode call) so this
		-- test is immune to an earlier test file's load_with_stubs({json = {...}})
		-- override permanently clobbering the shared _G.hs.json stub (test isolation
		-- footgun unrelated to this finding) — load_with_stubs always hands back a
		-- freshly `__reset()` stub regardless of what a previous test left behind.
		local ManifestMenu = helpers.load_with_stubs("infra.manifest_menu")
		local gestures_menu = ManifestMenu.get_array("gestures_menu")
		helpers.assert_true(type(gestures_menu) == "table" and #gestures_menu > 0,
			"menu_manifest.json must have a non-empty gestures_menu array")

		local with_id, misclassified = 0, {}
		for _, e in ipairs(gestures_menu) do
			if type(e) == "table" and type(e.id) == "string" then
				with_id = with_id + 1
				if e.type == "feature" then misclassified[#misclassified + 1] = e.id end
			end
		end
		helpers.assert_true(with_id >= 5, "the gestures menu must declare its id-bearing rows")
		helpers.assert_eq(#misclassified, 0,
			"type=feature is silently skipped by ManifestMenu.build (F-HIGH-5), so these rows "
				.. "would vanish with nothing said: " .. table.concat(misclassified, ", "))
	end)

	helpers.it("ManifestMenu.build renders the category switch from its declaration", function()
		local ManifestMenu = helpers.load_with_stubs("infra.manifest_menu")

		-- The row is built by the RENDERER, so what the driver supplies is the
		-- behaviour and the state — which is exactly what is stubbed here.
		local fired = false
		local built = ManifestMenu.build("gestures_menu", "Gestures", make_dyn_handlers(), nil, {
			commands = { gestures_toggle = function() fired = true end },
			state_getters = {
				gestures_enabled = function() return true end,
			},
		})

		local row = nil
		for _, item in ipairs(built) do
			if type(item.fn) == "function" and item.checked == true then row = item end
		end
		helpers.assert_true(row ~= nil,
			"the gestures switch must be present, ticked from its checked_when getter — " ..
			"a type=feature misclassification makes ManifestMenu.build skip it silently (F-HIGH-5)")

		row.fn()
		helpers.assert_true(fired,
			"and clicking it must run the command the driver registered, not a no-op: a row " ..
			"rendered with no behaviour looks identical to one that works")
	end)

	-- The maintainer's first group (2026-09-30): the switch, « Restaurer les
	-- valeurs conseillées », « Tout effacer », then a separator. The two scope
	-- rows stood below the system rows until then.
	helpers.it("ManifestMenu.build opens the menu with the switch, the restore and the clear", function()
		local ManifestMenu = helpers.load_with_stubs("infra.manifest_menu")
		local i18n = require("infra.i18n")
		local fired = {}
		local function record(name) return function() fired[#fired + 1] = name end end
		local built = ManifestMenu.build("gestures_menu", "Gestures", make_dyn_handlers(), nil, {
			commands = { gestures_toggle = record("toggle"), scope_restore = record("restore"),
				scope_clear = record("clear"), system_gesture_settings = record("settings") },
			state_getters = { gestures_enabled = function() return true end },
		})
		helpers.assert_eq(built[1].title, i18n.get("menu.gestures.enable"))
		helpers.assert_eq(built[2].title, i18n.get("common.restore_recommended"))
		helpers.assert_eq(built[3].title, i18n.get("common.clear_to_system"))
		helpers.assert_eq(built[4].title, "-")
		for index = 5, #built do
			helpers.assert_true(built[index].title ~= built[2].title and built[index].title ~= built[3].title,
				"no scope row may follow the first group")
		end
		built[2].fn()
		built[3].fn()
		helpers.assert_eq(fired, { "restore", "clear" }, "each row runs the command registered under its id")
	end)
end)

-- Independent mode expectations predate this presentation migration. Drive the
-- actual native menu owner and renderer; only the host/runtime ports are controlled.
local mode_fixture_modules = {
	"json", "menu.renderer", "infra.manifest_menu", "infra.i18n", "infra.logger",
	"modules.gestures", "ui.menu.menu_utils", "infra.dialog_util", "ui.action_picker",
	"ui.menu.shortcut_utils", "infra.deferred_work", "ui.menu.menu_gestures",
}
local function mode_json(path)
	local file = assert(io.open(path, "rb"))
	local bytes = file:read("*a")
	file:close()
	return require("json").decode(bytes)
end
local function with_mode_fixture(options, callback)
	return helpers.with_fresh_modules(mode_fixture_modules, function()
		options = options or {}
		local corpus = mode_json(helpers.shared("tests/corpus/menus/gesture_slot_modes.json"))
		local locale = options.locale or "en"
		local strings = mode_json(helpers.shared("data/locales/" .. locale .. ".json"))
		local i18n = {
			get = function(key) return strings[key] or key end,
			section = function(key) return strings[key] or key end,
		}
		local logger = helpers.make_logger_stub()
		local renderer = assert(require("menu.renderer").new({
			platform = options.platform or "hs",
			manifest_path = function() return helpers.shared("modules/menu/menu_manifest.json") end,
			json_decode = require("json").decode, i18n = i18n, logger = logger,
		}))
		local root = renderer.get_root()
		root.gesture_slots = { ["2"] = { "swipe_2_left" }, ["3"] = {}, ["4"] = {}, ["5"] = {} }
		local fixture = { mode = options.mode or "x1", writes = {}, saves = 0, updates = 0,
			renderer = renderer, root = root, corpus = corpus, strings = strings, locale = locale }
		fixture.gestures = {
			get_action = function() return "none" end,
			get_action_label = function() return "None" end,
			get_action_parameter = function() return "" end,
			get_mode = function() return fixture.mode end,
			get_sensitivity = function() return 3.5 end,
			get_sg_names = function() return {} end,
			system_gesture_conflicts = function() return {} end,
			system_pinch_enabled = function() return nil end,
			open_system_gestures = function() return true end,
			refresh_system_gestures = function() return true end,
			set_mode = function(slot, value)
				fixture.writes[#fixture.writes + 1] = { slot, value }
				fixture.mode = value
				if options.setter and #fixture.writes == 1 then return options.setter() end
				return true
			end,
		}
		package.loaded["infra.manifest_menu"] = renderer
		package.loaded["infra.i18n"] = i18n
		package.loaded["infra.logger"] = logger
		package.loaded["modules.gestures"] = { DEFAULT_STATE = { gestures = true } }
		for _, name in ipairs({ "ui.menu.menu_utils", "infra.dialog_util", "ui.action_picker",
			"ui.menu.shortcut_utils", "infra.deferred_work" }) do package.loaded[name] = {} end
		local owner = require("ui.menu.menu_gestures")
		function fixture.build()
			return owner.build({
				gestures = fixture.gestures, state = { gestures = true }, paused = false,
				save_prefs = function()
					fixture.saves = fixture.saves + 1
					if options.save then return options.save() end
					return true
				end,
				updateMenu = function() fixture.updates = fixture.updates + 1 end,
			})
		end
		function fixture.rows()
			local item = fixture.build()
			for _, row in ipairs(item.submenu) do
				if row.title == i18n.get("gesture.slots.swipe_2_left") .. " : None" then
					return assert(row.menu[3].menu)
				end
			end
			error("actual rendered swipe slot missing")
		end
		return callback(fixture)
	end)
end

helpers.describe("Gestures: shared swipe mode declaration and actual native mutation owner", function()
	helpers.it("pins independent mode declarations without inventing other-platform capabilities", function()
		with_mode_fixture({}, function(f)
			local actual = f.root[f.corpus.section]
			helpers.assert_eq(#actual, #f.corpus.rows)
			for index, expected in ipairs(f.corpus.rows) do
				for key, value in pairs(expected) do
					if key ~= "value" then helpers.assert_eq(actual[index][key], value, key) end
				end
			end
		end)
	end)
	for _, locale in ipairs({ "ar", "cs", "da", "de", "en", "es", "fr", "he", "hi", "it", "ja",
		"ko", "nl", "no", "pl", "pt", "ru", "sv", "tr", "uk", "zh" }) do
		helpers.it("renders both existing locale captions through the actual owner: " .. locale, function()
			with_mode_fixture({ locale = locale }, function(f)
				local rows = f.rows()
				helpers.assert_eq(#rows, 2)
				for index, expected in ipairs(f.corpus.captions[locale]) do
					helpers.assert_eq(rows[index].title, expected)
					helpers.assert_type(rows[index].fn, "function")
				end
			end)
		end)
	end
	for _, platform in ipairs({ "ahk", "hs", "linux" }) do
		helpers.it("projects only existing mode capability: " .. platform, function()
			with_mode_fixture({ platform = platform }, function(f)
				local fired = {}
				local rows = f.renderer.template_rows(f.corpus.section, {
					gesture_mode_single = function() fired[#fired + 1] = "x1"; return true end,
					gesture_mode_incremental = function() fired[#fired + 1] = "incremental"; return true end,
				}, { gesture_mode_is_single = function() return true end,
					gesture_mode_is_incremental = function() return false end })
				helpers.assert_eq(#rows, #f.corpus.platform_rows[platform])
				if platform == "hs" then
					helpers.assert_true(rows[1].action())
					helpers.assert_eq(fired, { "x1" })
				end
			end)
		end)
	end
	for _, state in ipairs({ { "x1", true, false }, { "incremental", false, true }, { "future_mode", false, false } }) do
		helpers.it("checks only the actual native mode: " .. state[1], function()
			with_mode_fixture({ mode = state[1] }, function(f)
				local rows = f.rows()
				helpers.assert_eq(rows[1].checked == true, state[2])
				helpers.assert_eq(rows[2].checked == true, state[3])
			end)
		end)
	end
	helpers.it("follows shared order while retaining each value's actual callback", function()
		with_mode_fixture({}, function(f)
			local definition = f.root[f.corpus.section]
			definition[1], definition[2] = definition[2], definition[1]
			local rows = f.rows()
			helpers.assert_eq(rows[1].title, f.corpus.captions.en[2])
			helpers.assert_true(rows[1].fn())
			helpers.assert_eq(f.writes, { { "swipe_2_left", "incremental" } })
			helpers.assert_eq(f.saves, 1)
			helpers.assert_eq(f.updates, 1)
		end)
	end)
	helpers.it("reads caption, check predicate and platform mutations from the declaration", function()
		with_mode_fixture({}, function(f)
			local row = f.root[f.corpus.section][1]
			row.i18n = "menu.gestures.mode_incremental"
			row.checked_when = { "gesture_mode_is_incremental" }
			local rows = f.rows()
			helpers.assert_eq(rows[1].title, f.corpus.captions.en[2])
			helpers.assert_eq(false, rows[1].checked == true)
			row.platforms = { "linux" }
			rows = f.rows()
			helpers.assert_eq(#rows, 1)
			helpers.assert_eq(rows[1].title, f.corpus.captions.en[2])
		end)
	end)
	helpers.it("actual swipe provider independently honors platform hiding", function()
		with_mode_fixture({}, function(f)
			f.root[f.corpus.section][1].platforms = { "linux" }
			local rows = f.rows()
			helpers.assert_eq(#rows, 1)
			helpers.assert_eq(rows[1].title, f.corpus.captions.en[2])
			helpers.assert_true(rows[1].fn())
			helpers.assert_eq(f.mode, f.corpus.rows[2].value)
		end)
	end)
	helpers.it("actual swipe provider independently honors the declared checked reader", function()
		with_mode_fixture({}, function(f)
			f.root[f.corpus.section][1].checked_when = { "gesture_mode_is_incremental" }
			helpers.assert_eq(false, f.rows()[1].checked == true)
		end)
	end)
	helpers.it("a held callback rereads current native mode before compensating refused publication", function()
		with_mode_fixture({ save = function() return false end }, function(f)
			local held = f.rows()[2].fn
			f.mode = "future_mode"
			helpers.assert_eq(false, held())
			helpers.assert_eq(f.mode, "future_mode")
			helpers.assert_eq(f.writes, { { "swipe_2_left", "incremental" }, { "swipe_2_left", "future_mode" } })
			helpers.assert_eq(f.updates, 0)
		end)
	end)
	for _, refusal in ipairs({
		{ "false", function() return false end }, { "nil", function() return nil end },
		{ "truthy", function() return "accepted" end }, { "throw", function() error("native refusal") end },
	}) do
		for _, edge in ipairs({ "setter", "save" }) do
			helpers.it("preserves exact mutation/publication acknowledgement: " .. edge .. " " .. refusal[1], function()
				local options = {}; options[edge] = refusal[2]
				with_mode_fixture(options, function(f)
					helpers.assert_eq(false, f.rows()[2].fn())
					helpers.assert_eq(f.mode, "x1")
					helpers.assert_eq(f.writes, { { "swipe_2_left", "incremental" }, { "swipe_2_left", "x1" } })
					helpers.assert_eq(f.saves, edge == "save" and 1 or 0)
					helpers.assert_eq(f.updates, 0)
				end)
			end)
		end
	end
	for _, edge in ipairs({ "get_mode", "set_mode" }) do
		helpers.it("held callback refuses a withdrawn native owner: " .. edge, function()
			with_mode_fixture({}, function(f)
				local held = f.rows()[2].fn
				f.gestures[edge] = nil
				helpers.assert_eq(false, held())
				helpers.assert_eq(f.writes, {})
				helpers.assert_eq(f.saves, 0)
			end)
		end)
	end
	for _, transition in ipairs({ { "incremental", "x1", 1 }, { "x1", "incremental", 2 } }) do
		helpers.it("publishes both existing native mode directions: " .. transition[2], function()
			with_mode_fixture({ mode = transition[1] }, function(f)
				helpers.assert_true(f.rows()[transition[3]].fn())
				helpers.assert_eq(f.mode, transition[2])
				helpers.assert_eq(f.writes, { { "swipe_2_left", transition[2] } })
				helpers.assert_eq(f.saves, 1)
				helpers.assert_eq(f.updates, 1)
			end)
		end)
	end
	for _, refusal in ipairs({ { "nil", function() return nil end },
		{ "throw", function() error("mode unavailable") end } }) do
		helpers.it("held mode callback refuses unreadable current state: " .. refusal[1], function()
			with_mode_fixture({}, function(f)
				local held = f.rows()[2].fn
				f.gestures.get_mode = refusal[2]
				helpers.assert_eq(false, held())
				helpers.assert_eq(f.writes, {})
				helpers.assert_eq(f.saves, 0)
			end)
		end)
	end
	for _, platform in ipairs({ "ahk", "hs", "linux" }) do
		helpers.it("check template delegates retained readiness and strict callback receipt: " .. platform, function()
			with_mode_fixture({ platform = platform }, function(f)
				f.root.mode_template_probe = { {
					type = "check", id = "mode_probe", i18n = "menu.gestures.mode_single",
					checked_when = { "mode_probe_checked" }, disabled_when = { "mode_probe_blocked" },
				} }
				local blocked, calls = false, 0
				local commands = { mode_probe = function() calls = calls + 1; return false end }
				local getters = { mode_probe_checked = function() return true end,
					mode_probe_blocked = function() return not blocked end }
				local rows = f.renderer.template_rows("mode_template_probe", commands, getters)
				helpers.assert_true(rows[1].checked)
				blocked = true
				helpers.assert_eq(false, rows[1].action())
				helpers.assert_eq(calls, 0)
				blocked = false
				helpers.assert_eq(false, rows[1].action())
				helpers.assert_eq(calls, 1)
				helpers.assert_nil(f.renderer.template_rows("mode_template_probe", {}, getters))
			end)
		end)
	end
end)
