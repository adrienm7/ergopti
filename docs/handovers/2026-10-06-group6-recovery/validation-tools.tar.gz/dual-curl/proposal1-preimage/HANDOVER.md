# Two genuine validation curl prerequisites — source proposal

This packet is SOURCE ONLY and UNEXECUTED. It changes no repository, product,
cloud configuration, global curl, trust store, or global library path. No source
archive/package has been downloaded, extracted, configured, built, or executed
for this proposal. Official HTTPS release metadata and existing authenticated
Debian receipts were read. The existing native30 assertions and scoped legacy
argument handling remain unchanged.

## Independent artifact authority

Modern curl 8.14.1 uses the official `curl/curl` release asset digest obtained
independently from GitHub's release API. Release 222954438, asset 260804610,
2,817,248 bytes, SHA256
`f4619a1e2474c4bbfedc88a7c2191209c8334b48fa1f4e53fd584cc12e9120dd`.
`official-modern-release.json` retains the independent metadata. The setup
requires the exact size/hash before archive extraction.

The official curl 7.88.1 release API provides NO digests for its eight historical
assets, and its release body provides NO checksum. Official curl.se checksum
metadata returned HTTP 403. No upstream checksum was invented. The authorized
alternative is genuine Debian bookworm curl 7.88.1-10+deb12u15, separately labeled
`official_debian_signed_distribution_packages`. `legacy-provenance.json` retains
the earlier authenticated official distribution evidence; `PINS.json` binds
InRelease, its SHA256 Packages commitment, and exact curl/libcurl4/libldap-2.5-0
package sizes/hashes. The script must freshly verify the official stable signer
`4D64FEC119C2029067D6E791F8D2585B8783D481` through the installed Debian archive
keyring and freshly match signed package records BEFORE extraction. It does not
run maintainer scripts or install packages globally.

Pinned official point-release metadata has no Valid-Until. The script preserves
that declared contract, rejects future dates and any present expired Valid-Until,
and does not disable expiry checks. If the mutable Debian URL advances to a new
signed point release, the exact pinned SHA refuses: update the independently
reviewed metadata/package commitments or use a separately authenticated exact
snapshot; do not weaken verification or silently select latest.

## Proposed setup invocation and dependencies

Run a dedicated Linux x86_64 setup process, with no existing direct children:

```bash
python3 setup_validation_curl.py \
  --repo /path/to/ergopti \
  --destination "$RUNNER_TEMP/validation-curl-owned" \
  --openssl-prefix /usr \
  --keyring /usr/share/keyrings/debian-archive-keyring.gpg \
  --jobs 2
```

The destination must be absent. Inputs/builds/receipts remain inside a new private
0700 canonical root. The trusted same-UID setup namespace must be exclusive:
this source proposal has no arbitrary concurrent-root writer threat model.
Destination replacement is refused before/after every native command and before
receipt publication; failed inputs are retained, never removed as a success.

The repository's already qualified native build command owner is SHA-pinned in
PINS.json. It supplies the original WNOWAIT-reserved session, actual PPID census,
private subreaper, capture/stream close acknowledgements and escaped-descendant
retirement. There is no extra shell timeout/guardian that can destroy that
ledger. Whole-operation original budget: 1,800 seconds; each HTTPS fetch 190,
configure 300, compilation 900, installation 180; other commands 120. Each phase
is additionally capped by the original total. A physical retirement debt keeps
the owner alive and the inputs retained; an outer runner/job cancellation cannot
be interpreted as closure. Compile `make -s` avoids routine compiler chatter
exceeding the owner's original 1 MiB capture ceiling.

CI prerequisite packages (through the runner's authenticated package manager):
Python >=3.12, build-essential, make, binutils, pkg-config, libssl-dev, zlib1g-dev,
xz-utils, curl, ca-certificates, gpgv, Debian archive keyring, and the compatible
host dependencies of Debian libcurl4. On Ubuntu 24.04 this includes actual
libbrotli1, libnghttp2-14, libssh2-1t64, libpsl5t64, libidn2-0, librtmp1,
libgssapi-krb5-2 and libsasl2-2; distribution names/provider availability must be
resolved from real signed runner metadata, not guessed from this list. These
are additional prerequisites to the existing native30 LuaJIT/luv/GIO/libproxy/
GNOME/private-D-Bus/SDK prerequisites, not replacements.

The modern source builds into its private prefix against an explicitly selected
LOCAL installed OpenSSL SDK (normally `/usr`). No separate OpenSSL source build
is supplied or claimed: a separate-source OpenSSL requirement would need its
own authenticated source pin. Shared OpenSSL/zlib remain actual host libraries;
static libcurl is linked into the genuine modern curl ELF. Optional protocols
not needed by these HTTP controls are excluded to reduce setup dependencies.
TLS verification/trust remains intact. The actual version must name OpenSSL and
both HTTP and HTTPS. Future native TLS rejection controls remain mandatory.

Legacy extraction selects only old libcurl/libldap/liblber into a private
library directory, with immutable extracted-file hashes. It does NOT place old
libc/loader or the whole old rootfs on the library path. Actual ELF interpreter
closure is required on the real runner; unavailable ABI/SONAME dependencies
refuse. Only the legacy version probe and the existing legacy fixture child
receive that directory. Existing inherited library paths remain a suffix so the
private LuaJIT/libuv dependency stays available. Product curl remains unchanged.

## Native admission and gate wiring

Setup requires actual x86_64 ELF headers, exact real curl AND libcurl versions,
OpenSSL HTTP/HTTPS support and the real interpreter's `--list` loader closure.
TOOLS-ADMISSION.json records actual executable hashes, version text and loader
facts privately. Its state is `tools_admitted`; native30 is explicitly UNEXECUTED.
Version text alone does not prove proxy_used/legacy refusal or network behavior.

Root owns workflow/normal-runner wiring. Pass the admitted modern `bin` directory
in PATH ONLY to the native gate process. Pass the admitted old ELF and library
directory through unchanged `--legacy-curl-path` and
`--legacy-curl-library-path`. Never use GITHUB_PATH, a fake curl wrapper, global
LD_LIBRARY_PATH, TLS bypass flags, or product command replacement. The current
native30 qualifier must then exercise both real versions and all original tests
on the exact joined sources. Build/setup admission is not a native test pass.

Initial proposal intentionally has NO cache restore path. A future cache key
must bind setup/PINS/command-owner SHA, OS/architecture, compiler and local
OpenSSL SDK/package identities. It needs an authenticated producer artifact and
fresh ELF/loader/version/library-hash admission on EVERY hit; an arbitrary
writable TOOLS-ADMISSION.json is not a cache authority. Refuse existing
unqualified destinations. Allow at least 30 minutes of isolated setup execution
plus explicit physical cleanup time at the job level; native30 has its own
unchanged budget/ownership and runs after setup retirement.

## Prospective qualification before application

Review/parse/format this source first; none has run here. Independent future
controls should corrupt the upstream archive size/hash, Debian signer/index/
package commitment, actual old selected library and unavailable loader closure;
each must refuse before corresponding extraction/native admission. Exercise
actual timeout/escaped child against the unchanged shared command owner, not a
new guessed-kill ledger. Then run actual modern build and old loader/version
admission, followed by unchanged native30 on the exact registered producer.
Record exit/count/pass/fail/skip/unexecuted separately. Preserve all failed
inputs and original native assertions.
