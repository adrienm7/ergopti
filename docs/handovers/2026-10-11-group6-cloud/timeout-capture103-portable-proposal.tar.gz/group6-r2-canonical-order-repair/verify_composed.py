"""Prove exact three-file inverse; no implementation-derived expectations."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
WIRE = 'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
TEST = 'tools/test/macos_native_http_receiving_facts_test.py'
REGISTRY = 'tools/test/test-managed-ollama-protocol.cjs'
old = json.loads((BASE / 'guard90-r2-insertion-inverse.json').read_text())
setup = json.loads((BASE / 'exact-inverse.json').read_text())
wire = (BASE / 'candidate' / WIRE).read_text()
for item in reversed(old['wire_insertions']):
    assert wire.count(item['addition'] + item['anchor']) == 1
    wire = wire.replace(item['addition'] + item['anchor'], item['anchor'], 1)
assert wire == (BASE / 'guard90-preimage' / WIRE).read_text()
test = (BASE / 'candidate' / TEST).read_text()
assert test.count(setup['after_setup']) == 1
test = test.replace(setup['after_setup'], setup['before_setup'], 1)
assert test.count(old['test_addition'] + old['test_anchor']) == 1
test = test.replace(old['test_addition'] + old['test_anchor'], old['test_anchor'], 1)
assert test == (BASE / 'guard90-preimage' / TEST).read_text()
registry = (BASE / 'candidate' / REGISTRY).read_text()
assert registry.count(old['registry_after']) == 1
registry = registry.replace(old['registry_after'], old['registry_before'], 1)
assert registry == (BASE / 'guard90-preimage' / REGISTRY).read_text()
print(json.dumps({'whole_three_path_guard90_inverse': True, 'type_allocator_mutation': 'absent', 'registry': '103'}, sort_keys=True))
