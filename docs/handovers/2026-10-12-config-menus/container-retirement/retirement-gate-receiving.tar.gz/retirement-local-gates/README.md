# Closed container-retirement local receiving

RECEIVING.json binds the actual source M to the exact candidate G tree and records literal terminal footers. The original Linux cohort remains FAILED solely at its managed HTTP prerequisite admission; its E2E, units and strict command succeeded. A separate unchanged-source invocation supplies the exact expected HEAD and receives the native HTTP controls. Its success does not retroactively change the failed original receipt.

Windows native units and E2E are UNEXECUTED. The parse runner own printed outcome is retained separately; encoding and portable Lua tests do not replace native Windows or installed-device acceptance.

Only allowlisted JSON records and safe closed gate logs are included. A conservative credential/signed-URL scan can omit a raw log; its size, SHA256 and reason remain in RECEIVING.json, together with safe JSON receipts and parsed technical footer counts. No stderr file, SDK, runtime key or executable binary is copied.

git/candidate.commit is the exact raw commit object payload, not a pretty-printed log. Its Git object SHA1 was independently checked. The source M raw payload is git/source.commit. Their common tree and its referenced source objects belong to source M; retain M in Dev history before deleting owned refs. The raw commit payload alone is not a replacement for those tree/blob objects. To check G without writing, run `git hash-object -t commit --stdin < git/candidate.commit`; after an explicitly chosen recovery, `git hash-object -t commit -w --stdin < git/candidate.commit` can recreate that commit object from the preserved payload. This seal itself never writes Git objects or refs.

All tar entries are regular files with deterministic metadata. MANIFEST.json hashes every payload; SHA256SUMS also hashes MANIFEST.json and excludes itself. The sealed archive is independently reopened and all names, types, byte counts and hashes verified before its external receipt is written.
