from pathlib import Path
import subprocess,json,hashlib,shutil
b=Path(__file__).parent;repo=Path('/workspace/ergopti');cwd=repo/'static/ergopti_plus/linux'
variants={}
def variant(name,module,text):
 p=b/'variants'/name/(module.replace('.','/')+'.lua');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 variants[name]={'module':module,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
owner='static/ergopti_plus/linux/modules/shortcuts/key_combinations.lua'
scope='static/ergopti_plus/linux/infra/key_combinations_scope.lua'
global_scope='static/ergopti_plus/linux/infra/shortcuts_scope.lua'
oldowner=(Path('/workspace/.ergopti-cloud/preparations/group3-linux93-simultaneous-runtime-v1/freeze/candidate')/owner).read_text()
variant('old_source_owner','modules.shortcuts.key_combinations',oldowner)
variant('old_local_scope','infra.key_combinations_scope',(b/'preimages'/scope).read_text())
variant('old_global_scope','infra.shortcuts_scope',(b/'preimages'/global_scope).read_text())
s=(b/'candidate'/scope).read_text()
assert 'tap_section=Shared.TAP_SECTION' in s
variant('copy_wrong_namespace','infra.key_combinations_scope',s.replace('tap_section=Shared.TAP_SECTION','tap_section=nil'))
s=(b/'candidate'/owner).read_text()
assert 'value~="run_program" and value~="alt_tab_monitor"' in s
variant('native_receiver_filter_omitted','modules.shortcuts.key_combinations',s.replace('value~="run_program" and value~="alt_tab_monitor" and ',''))
s=(b/'candidate'/global_scope).read_text()
assert 'desired.chords and desired.chords[pair] ~= nil and type(row)' in s
variant('future_pair_filter_omitted','infra.shortcuts_scope',s.replace('desired.chords and desired.chords[pair] ~= nil and type(row)','type(row)'))
(b/'variants.json').write_text(json.dumps(variants,indent=2)+'\n')
results=[]
for abi in ['luajit','lua5.4']:
 binary=Path('/workspace/.ergopti-cloud/bin')/abi
 for name,module in [('runtime','tests.unit.modules.test_key_combinations'),('scope','tests.unit.infra.test_key_combinations_scope'),('menu','tests.unit.ui.test_key_combinations_menu'),('global','tests.unit.infra.test_global_shortcuts_pair_scope')]:
  p=subprocess.run([str(binary),str(b/'run.lua'),str(b),module],cwd=cwd,capture_output=True,text=True)
  (b/'evidence'/f'qualified-{abi}-{name}.log').write_text(p.stdout+p.stderr)
  rows=[x for x in p.stdout.splitlines() if x.startswith('PUBLIC_JOIN_CONTROLLED')]
  results.append({'abi':abi,'case':name,'exit':p.returncode,'summary':rows[-1:]}); print(results[-1],flush=True)
 for name,module in [('old_source_owner','tests.unit.modules.test_key_combinations'),('old_local_scope','tests.unit.infra.test_key_combinations_scope'),('old_global_scope','tests.unit.infra.test_global_shortcuts_pair_scope'),('copy_wrong_namespace','tests.unit.infra.test_key_combinations_scope'),('native_receiver_filter_omitted','tests.unit.infra.test_key_combinations_scope'),('future_pair_filter_omitted','tests.unit.infra.test_global_shortcuts_pair_scope')]:
  p=subprocess.run([str(binary),str(b/'run_variant.lua'),str(b),str(b/'variants'/name),module],cwd=cwd,capture_output=True,text=True)
  (b/'evidence'/f'{abi}-{name}.log').write_text(p.stdout+p.stderr)
  rows=[x for x in p.stdout.splitlines() if x.startswith('PUBLIC_JOIN_CONTROLLED')]
  results.append({'abi':abi,'case':name,'exit':p.returncode,'summary':rows[-1:]}); print(results[-1],flush=True)
(b/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(x['exit']==0 for x in results if x['case'] in ['runtime','scope','menu','global'])
assert all(x['exit']!=0 for x in results if x['case'] not in ['runtime','scope','menu','global'])
