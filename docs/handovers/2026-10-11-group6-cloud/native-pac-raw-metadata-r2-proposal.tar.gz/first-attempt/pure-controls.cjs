'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const raw = require('./finite/tools/test/ci-pipeline.cjs');
const base = __dirname;
const files = raw.files();
const windows = '.github/workflows/ci-windows.yml';
const name = 'Retain native PAC raw source and command observations';
const body = fs.readFileSync(path.join(base, 'raw-retention-step.yml'), 'utf8').replace(/\n+$/, '');
function defaultValidator(role) {
	const source = fs.readFileSync(path.join(base, role, 'tools/test/ci-full-default.cjs'), 'utf8');
	const begin = source.indexOf('const JOBS = [');
	const end = source.indexOf('function fromFiles(', begin);
	assert.ok(begin > 0 && end > begin);
	const context = { raw, ROOT: raw.ROOT, ENTRY_REL: raw.ENTRY_REL };
	vm.runInNewContext(source.slice(begin, end), context);
	return context.validateRaw;
}
const original = defaultValidator('preimage');
const candidate = defaultValidator('candidate');
assert.doesNotThrow(() => original(files));
assert.doesNotThrow(() => candidate(files));
const mut = (replacement) => files.map((f) => f.rel === windows ? { ...f, text: f.text.replace(body, () => replacement) } : f);
let defaultRefusals = 0;
for (const [label, replacement] of [
	['deleted', ''],
	['renamed', body.replace(name, 'Unowned raw retention')],
	['duplicate', body + '\n\n' + body],
	['forgiven', body.replace('        uses:', '        continue-on-error: true\n        uses:')],
	['success-only', body.replace('always()', 'success()')],
	['failure suppressed', body.replace(" || steps.native-pac-build.outcome == 'failure'", '')],
	['cancelled suppressed', body.replace(" || steps.native-pac-build.outcome == 'cancelled'", '')]
]) {
	const changed = mut(replacement);
	assert.notDeepEqual(changed, files);
	assert.doesNotThrow(() => original(changed), label + ': actual preimage has no new tuple guard');
	assert.throws(() => candidate(changed), /ci-full-default|no step named|appears 2 times/, label);
	defaultRefusals++;
}
const originalWiring = fs.readFileSync(path.join(base, 'preimage/tools/test/test-ci-pipeline-wiring.cjs'), 'utf8');
const mustStart = originalWiring.indexOf('function mustCatch(');
const mustEnd = originalWiring.indexOf('\n// ========================================', mustStart);
const context = { assert, pipeline: raw, WINDOWS_BOX: windows, errors: [], console };
vm.runInNewContext(originalWiring.slice(mustStart, mustEnd), context);
const newGuard = fs.readFileSync(path.join(base, 'new-guard.cjs'), 'utf8');
vm.runInNewContext(newGuard, context);
assert.deepEqual(context.errors, [], 'the actual additive guard and all20 causal controls must receive');
const harmless = files.map((f) => f.rel === windows ? {
	...f, text: f.text.replace('      - name: Read AutoHotkey runtime contract\n', '      - name: Unrelated private harmless observation\n        run: echo harmless\n\n      - name: Read AutoHotkey runtime contract\n')
} : f);
assert.deepEqual(context.nativePacRawRetentionProblems(harmless), [], 'unrelated ordinary steps remain editable');
console.log(JSON.stringify({ scope: 'FINITE_PRIVATE_SOURCE_ONLY', default: { positive: 1, refusals: defaultRefusals, preimage_causally_admitted: defaultRefusals }, additive_named_guard: { positive: 2, refusals: 20 }, full_canonical_suite: 'UNRUN', native: false }));
