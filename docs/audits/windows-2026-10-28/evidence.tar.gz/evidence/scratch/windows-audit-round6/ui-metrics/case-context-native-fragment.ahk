﻿; Private actual native context/control histories for fixed-token case projection.
_R6CaseContext_Native(Scalars, Id) {
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	Db := 0
	try {
		OutputDir := EnvGet("ERGOPTI_R6_CASE_CONTEXT_DIR")
		AssertTrue(OutputDir != "" && DirExist(OutputDir))
		KLW.ctx := Map()
		KLW_ResetBatch()
		Events := []
		for Scalar in Scalars
			Events.Push([Scalar, 100, Map("st", "none")])
		KLW_WalkTypingEntry(Map("timestamp", "2026-10-26 12:00:00.000",
			"app", "expanding-case.exe", "events", Events))
		App := KLW.batch["app_day"]["2026-10-26" . Chr(1) . "expanding-case.exe"]
		AssertEqual(Scalars.Length, App["chars"])
		Manifest := Map("2026-10-26", Map("expanding-case.exe", Map("chars", App["chars"], "time", App["time_ms"])))
		Db := _KLRShortcut_OpenFixture()
		AssertTrue(SQLite_Exec(Db, KLW_BuildBatchSql(SQLite_Q("case-context"), false)))
		Historical := KLR_BuildNgramsJson(Db, "2026-10-26", "2026-10-26", ["expanding-case.exe"])
		Decoded := JsonParse(Historical)
		AssertEqual(Scalars.Length, Decoded["c"].Count, "distinct original events remain distinct character keys")
		for Scalar in Scalars {
			AssertTrue(Decoded["c"].Has(Scalar))
			AssertEqual(1, Decoded["c"][Scalar]["c"])
		}
		if Id == "corrected-i-dot" {
			AssertEqual(1, Decoded["c"]["İ"]["e"], "the native correction remains attached to one original scalar")
			AssertEqual(1, Decoded["bg"]["İ[BS]"]["c"])
		} else if Id == "greek-word-context" {
			AssertTrue(Decoded["w"].Has("İΟΣ"), "the actual completed word retains its original Unicode spelling")
			AssertEqual(1, Decoded["w"]["İΟΣ"]["c"])
			AssertEqual(3, Decoded["bg"].Count)
			AssertEqual(2, Decoded["tg"].Count)
			AssertEqual(1, Decoded["qg"].Count)
		} else {
			AssertTrue(Decoded["bg"].Has("ıI"))
			AssertTrue(Decoded["bg"].Has("Iİ"))
			AssertEqual(1, Decoded["tg"]["ıIİ"]["c"])
		}
		FileAppend('{"id":' . JsonStringLiteral(Id) . ',"events":' . KL_JsonEncode(Scalars)
			. ',"manifest":' . KL_JsonEncode(Manifest) . ',"range":{"historical":'
			. Historical . ',"today":{}}}', OutputDir . "\" . Id . ".json", "UTF-8-RAW")
		FileAppend("NATIVE_CASE_CONTEXT " . Id . " chars=" . App["chars"] . "`n", "*")
	} finally {
		if Db
			SQLite_Close(Db)
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
	}
}
for _R6CaseContextSpec in [
	Map("id", "corrected-i-dot", "scalars", ["İ", "[BS]"]),
	Map("id", "greek-word-context", "scalars", ["İ", "Ο", "Σ", " "]),
	Map("id", "dotless-i", "scalars", ["ı", "I", "İ"])
]
	Test("audit: native case context " . _R6CaseContextSpec["id"] . " (r6-native-case-context)",
		_R6CaseContext_Native.Bind(_R6CaseContextSpec["scalars"], _R6CaseContextSpec["id"]))
