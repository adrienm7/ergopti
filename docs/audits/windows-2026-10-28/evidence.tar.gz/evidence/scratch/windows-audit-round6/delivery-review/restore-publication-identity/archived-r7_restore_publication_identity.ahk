﻿; A successful native pathname rename cannot publish a foreign replacement.
_R7PI_RestorePublicationIdentity() {
 static GENERIC_READ := 0x80000000, FILE_SHARE_READ := 0x00000001, OPEN_EXISTING := 3
 static FILE_ATTRIBUTE_NORMAL := 0x00000080
 Root := A_Temp . "\ergopti_r7_restore_replaced_" . PLC_CurrentProcessId() . "_" . A_TickCount
 Cfg := Root . "\cfg", Stage := Cfg . "\config.toml.ergopti-restore.tmp", Moved := Root . "\owned-moved.tmp"
 Mover := FSAtomicMoveReplace
 AssertFalse(Mover.HasOwnProp("Call"), "a foreign rename observer cannot be detached")
 Completed := false
 ForeignBytes := "replacement restore sidecar bytes`n"
 Observe(Self, ActualSource, ActualDestination) {
  Mover.DeleteProp("Call")
  AssertEqual(Stage, ActualSource)
  AssertEqual(Cfg . "\config.toml", ActualDestination)
  BeforeFile := FileOpen(Stage, "r")
  try Before := FSHandleSnapshot(BeforeFile.Handle)
  finally BeforeFile.Close()
  AssertTrue(Before["ok"], "the verified restore copy must have a native identity")
  FileMove(Stage, Moved, false)
  AssertTrue(FSWriteCreateDurable(Stage, ForeignBytes))
  AfterFile := FileOpen(Stage, "r")
  try After := FSHandleSnapshot(AfterFile.Handle)
  finally AfterFile.Close()
  AssertTrue(After["ok"], "the replacement sidecar must have a native identity")
  AssertTrue(Before["volume"] == After["volume"] && (Before["index_high"] != After["index_high"] || Before["index_low"] != After["index_low"]),
   "the pathname must now refer to a genuinely different file")
  Published := Mover.Call(ActualSource, ActualDestination, &NativeError)
  AssertTrue(Published, "the real unlocked native pathname rename must complete")
  AssertEqual(ForeignBytes, FSReadUtf8Exact(ActualDestination), "the actual native rename must expose the genuinely different replacement bytes")
  FileAppend("# actual-unlocked-foreign-publication error=" . NativeError . "`n", "*")
  Completed := true
  return Published
 }
 try {
  _RIT_WriteFile(Cfg . "\config.toml", "generation = 1`n")
  Rules := ConfigBackup_Rules()
  Clock := () => Map("stamp", "20260930-101500", "iso", "2026-09-30T10:15:00Z")
  Later := () => Map("stamp", "20260930-111500", "iso", "2026-09-30T11:15:00Z")
  Backup := ConfigBackup_Create(Cfg, "pre_install", "", "", Rules, Clock)
  Control := ConfigBackup_Restore(Cfg, Backup["id"], Rules, Later)
  AssertTrue(Control["ok"], "the same real restore must first succeed before any foreign sidecar replacement")
  AssertTrue(FSWriteDurable(Cfg . "\config.toml", "generation = 2`n"))
  Mover.DefineProp("Call", {Call: Observe})
  Result := ConfigBackup_Restore(Cfg, Backup["id"], Rules, Later)
  if Mover.HasOwnProp("Call")
   Mover.DeleteProp("Call")
  AssertTrue(Completed, "the actual foreign replacement and successful native publication must complete")
  AssertFalse(Result["ok"], "the public restore must not report success after publishing an unverified foreign file")
  AssertEqual("write", Result["reason"])
  AssertEqual("generation = 2`n", FSReadUtf8Exact(Cfg . "\config.toml"))
  AssertEqual("generation = 1`n", FSReadUtf8Exact(Moved), "the moved original copy must remain independently observable")
  AssertTrue(FileExist(Stage), "a native rename refusal cannot delete the foreign replacement sidecar")
  AssertEqual(ForeignBytes, FSReadUtf8Exact(Stage))
 } finally {
  if Mover.HasOwnProp("Call")
   Mover.DeleteProp("Call")
  if DirExist(Root)
   DirDelete(Root, true)
 }
}
Test("Config restore ownership: native publication never admits a foreign stage (restore-publication-identity)", _R7PI_RestorePublicationIdentity)
