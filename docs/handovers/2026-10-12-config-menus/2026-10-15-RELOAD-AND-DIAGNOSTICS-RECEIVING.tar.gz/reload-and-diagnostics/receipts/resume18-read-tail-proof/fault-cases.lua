

local observations = {}
helpers.describe("recent errors file closed IO receipts", function()
	for _, fault in ipairs({ "read", "close" }) do
		helpers.it("literal errors-file-issues " .. fault .. " failure remains unavailable", function()
			local path = TMP .. "/literal-" .. fault .. ".log"
			local file = assert(io.open(path, "wb"))
			assert(file:write("2026-09-23 10:00:01:002 [ERROR] [Probe] synthetic retained error\n")); assert(file:close())
			local real_open, calls = io.open, { read = 0, close = 0 }
			io.open = function(name, mode)
				local fh, err, code = real_open(name, mode)
				if name ~= path or not fh then return fh, err, code end
				return {
					seek = function(_, ...) return fh:seek(...) end,
					read = function(_, ...)
						calls.read = calls.read + 1
						if fault == "read" then return nil, "controlled synthetic EIO read refusal", 5 end
						return fh:read(...)
					end,
					close = function()
						calls.close = calls.close + 1
						local closed, detail = fh:close(); calls.actual_closed = closed == true
						if fault == "close" then return nil, "controlled close receipt refusal", 5 end
						return closed, detail
					end,
				}
			end
			local ran, primary = pcall(with_errors_path, path, function(Bridge)
				local issues = Bridge.build_snapshot({}, false).sections.issues
				observations[#observations + 1] = { fault = fault, recent_source = issues.recent_source,
					recent = issues.recent, read_calls = calls.read, close_calls = calls.close,
					actual_native_close_completed = calls.actual_closed }
				helpers.assert_eq(issues.recent_source, "unavailable", "an existing unreadable or unclosed source cannot claim errors_file")
				helpers.assert_eq(issues.recent, {})
			end)
			io.open = real_open
			assert(os.remove(path))
			assert(calls.read == 1 and calls.close == 1 and calls.actual_closed == true, "the private real file must be closed once")
			if not ran then error(primary, 0) end
		end)
	end
end)
print("LITERAL_IO_OBSERVATIONS " .. require("json").encode(observations))
