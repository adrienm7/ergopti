# Personal default construction: INACTIVE remote handover

This compact packet backs up a proposal for owner review. **INACTIVE. NATIVE
UNRUN. No feature adoption, source-census reduction, TODO item removal, publication
or CI dispatch is authorized by these files.** Root can publish this docs-like
packet separately so a local coordinator can fetch its exact reviewed inputs.

Nine forward patches are under `patches/`: seven exact V5 source/witness patches,
the final repository-formatted cleanup71 helper patch (`df2e75c…` postimage),
and the sealed69 API-caller patch. No full postimage, independent corpus, generated
artifact, framework, runner, workflow or inventory copy is included. Source patch
bytes and copied fixed-control/receipt bytes are preserved exactly.

`PATCH-MANIFEST.json` names each exact preimage/postimage/patch hash and scope.
`PREIMAGE-PINS.json` confirms all nine source preimages still match fresh current
HEAD `0fc80d950a5a8bebe946481c25036059d09cc243`; the proposal's original base is289a0bb2.
`POSTIMAGE-PINS.json` carries hashes only. `RECEIPT-MANIFEST.json` distinguishes
source review, actual generator/validator/71Source checks and unrun native work.
`SHA256SUMS` seals the portable packet bytes. Compare these pins before integrating
into any changed checkout; a hash mismatch requires a fresh explicit owner join.

The proposal transfers actual default-child allocation and ledger registration,
original callback DATA construction, two frame materializations, whole-tree
admission/placement and the post-return count to a closed shared recipe. The
caller retains one captured returned child after exact ledger custody. Existing
outer-finally primary/cleanup behavior and G2 callback factory/setter authority
are retained. The two native-language source witnesses keep their old negative
kinds, direct donor assertions, provider scanner/floor and independent expectations.

Actual evidence is limited: the owning generator preserved every old menu field
and startup projection byte while adding the handwritten recipe; the candidate
validator accepted one policy and refused19malformed ones; repository-formatted
helper71Source receiving preserved old69results and added two genuine cleanup
controls. These results do not establish AHK parsing or native callback/lifetime/
primary-error/cleanup behavior. New API controls absent from the original donor
must use a genuine V1/V2/V4 subject; unknown-function errors earn no regression
credit. Source witnesses are finite lexical contracts, not general flow proofs.

Main owns shared proof/helper and mixed schema infrastructure. The helper and
API-caller deltas need Main's concrete ownership receipt; existing JS editor
provenance joins, actual owning generator regeneration and native/gate receiving
still remain integration dependencies. Do not delete old assertions or reduce
the raw-site baseline to make these patches pass. No new G2 producer is proposed.

The unrelated immutable private26ba CI gate/run382964 is outside this packet.
Nothing here modifies, resumes, dispatches or publishes that gate. This packet
does not mark the personal-menu feature or its TODO item complete.
