# Prompt de reprise n° 1 — intégrer le travail fait et préparer une première release

Colle ce texte dans une session neuve de Claude Code ouverte dans
`D:/Documents/GitHub/ergopti`.

---

Objectif de cette session : prendre tout ce qui a déjà été implémenté par la
refonte ErgoptiPlus (8 lanes de travail en pause), l'intégrer par-dessus mes
derniers commits de `dev` (dont une centaine de correctifs Linux), vérifier le
tout et préparer une première release. Le reste de la todo sera fait dans
quelques jours, dans une autre session : ne l'implémente pas ici.

## 0. Règles impératives

- Lis `AGENTS.md`, `docs/memory/README.md`, puis les skills `commit-and-push`,
  `verify-change`, `cross-driver-parity` et `workflow-change-control`.
- Si tu lances un workflow multi-agents et que je t'envoie une nouvelle demande
  pendant qu'il tourne, ne l'arrête JAMAIS pour l'ajouter : route-la vers un run
  suivant. Mesure toujours les durées avec les horodatages, jamais au nombre de
  messages.
- Quota limité : peu d'agents, au plus 3 en parallèle. Fais toi-même ce qui est
  mécanique (cherry-picks, conflits simples) et réserve les agents aux
  relectures ou aux conflits lourds.
- Ne pousse JAMAIS `dev` ni `main` sans mon accord explicite dans cette
  conversation. Un push sur `dev` déclenche la CI et publie une release.
  Pousser la branche de fonctionnalité `feat/overhaul` est permis.
- Historique linéaire et atomique : pas de merge, pas de squash, pas de
  `Co-Authored-By`.

## 1. Où tout se trouve

- **8 worktrees `D:/ewt/<lane>` sur les branches `feat/ovh-<lane>` :** state,
  menu, logging, updater, actions, diag, navlayer, layouts. Elles partent toutes
  de la base `f4d0bfd633ab7af50044199917e1e3db4241d8be`. Environ 190 commits au
  total. Chaque worktree a des jonctions `node_modules` et `.venv` vers le
  checkout principal : avant de supprimer un worktree, retire-les avec
  `cmd /c rmdir <chemin>`, sinon le contenu partagé est effacé.
- **Branche d'intégration :** `feat/overhaul`, encore vide, au commit de base.
- **`dev` local :** porte mon commit `f5eabcfe6` (skill workflow-change-control)
  par-dessus `origin/dev`. Il n'est pas poussé et doit faire partie de la
  release.
- **Contexte :** `D:/ewt/_context/`
  - `feature_map_script_with_R1-R35.js` : liste des demandes ;
  - `overhaul_workflow_script.js` : constante `DECISIONS` = mes décisions produit
    validées, spec de chaque tâche dans `LANES` ;
  - `map/*.txt` et `map/critique.md` : rapports d'analyse.
- **Journal du run en pause :**
  `C:/Users/admin/.claude/projects/D--Documents-GitHub-ergopti/7b42cfbe-60d7-41bb-87b3-b1a03baf7926/subagents/workflows/wf_97b8817b-99f/journal.jsonl`.
  Chaque ligne `result` donne `status`, `commits`, `not_done`, `risks` et
  `user_questions` d'une tâche ; les transcripts `agent-<id>.jsonl` sont dans le
  même dossier. Ne relance pas ce run avec `resumeFromRunId`.
- **Disque :** D: est presque plein (~4 Go libres). Crée les worktrees
  temporaires sous `C:/ewtb/`.

## 2. Ce qui est fait (à confirmer avec le journal et `git log` de chaque lane)

| Lane (commits) | Tâches implémentées et relues | Implémentées, jamais relues | Trous connus (`not_done` à lire) |
|---|---|---|---|
| state (20) | S1 préférences raccourcis, S2 synchro au démarrage + arrêt réel des gestes désactivés, G1 moteur de migration de config versionnée | — | — |
| menu (24) | A1 case à cocher en 1er item de chaque sous-menu (corrige le bug bloquant macOS), A2 top-level piloté par le manifest + nouvel ordre + sous-menu Configuration | A3 (9 commits) : clés partagées Restaurer / Tout effacer, « Versions », « Sources de saisie », sélecteur d'icône, clavier laissé sur la disposition de pause en quittant (macOS) | A1 : les items d'une catégorie désactivée restent grisés. A3 : R17 Linux laissé à l'updater (`menu.updates.open_releases`) ; titres des fenêtres GTK Linux en anglais en dur |
| logging (27) | B1 regroupement des lignes répétées (×N), B2 stall budget du logger natif + message runtime vs boot, B3 dossiers de logs `ergopti_plus` + LogsDirPath (relu : 4 correctifs) | — | B3 : Swift et launch gate macOS non compilés ici (CI macOS) ; libellé de la ligne « éditeur de chemins » |
| updater (25) | C1 notes de version (`<details>`, changelog d'abord), C2 registre des canaux + sélecteur | C3 (8 commits) : préréglages de fréquence partagés, dernier contrôle persisté sur les 3 OS, cadence macOS pilotée en Lua au lieu de Sparkle (comble le trou de fréquence macOS de C2), 304 Linux | C3 : la fenêtre de résultat du contrôle manuel reste pour C4 (Windows installe encore directement, Linux ne fait que logguer) ; Linux lit l'intervalle dans `config.toml [updater]` |
| actions (24) | D1 catalogue d'actions généré, D2 coller sans mise en forme, casse Unicode, encadrer la sélection | D6 (4 commits) : 3 touches personnalisables + actions texte / touche / raccourci éditables dans le sélecteur + libellés dynamiques | D2 : `copy_selected_path` absent sous Linux. D6 : risques listés dans le journal (ISO macOS, Linux en mode grab seulement, libellés Windows rafraîchis au rebuild) |
| diag (33) | E1 corrections rapides, tail du fichier d'erreurs, formulaires d'issue GitHub, menus Signaler un bug / Proposer une fonctionnalité ; E2 diagnostic v2 (sections, collecte asynchrone, anonymisation, boutons) | E3 : fenêtre d'erreur avec dédup / limite de débit (__E3_STATUS__) | — |
| navlayer (22) | N1 registre des touches physiques + couche conseillée ; N2 couche générée par driver | — | — |
| layouts (25) | L1 registre `.keylayout` dans un dossier du dépôt + Ergo-L ; L2 AHK lit le `.keylayout` directement | L3 (11 commits, partiel) : installation / mise à jour / désinstallation des dispositions du registre sur les 3 OS, fenêtre gestionnaire partagée, section Ergopti = section « Disposition personnalisée » | L3 : sous macOS et Linux, les hotstrings propres à Ergopti (SFB, rolls) ne sont pas coupées sous une autre disposition (Windows oui) ; le commit intermédiaire `64c6f319d` casse seul le ratchet driver-tree-parity |

**Agents lancés malgré la pause.** N3 (éditeur de la couche de nav) et D4 (prédiction IA)
ont démarré après la pause et ont ignoré la note. J'ai arrêté le workflow dès la fin des
tâches autorisées. __ROGUE_STATUS__ Traite leurs commits et leur travail non commité comme
du travail NON relu, à exclure de la release sauf s'il est complet et que je l'accepte.

**Questions produit en attente (pose-les-moi au début de la session) :**
1. A3 — Gestes conseillés macOS : le manifest s'aligne maintenant sur le runtime. Le
   glissement 2 doigts vers la gauche et les glissements horizontaux 3 / 4 / 5 doigts
   n'ont plus d'action conseillée. Avant : flèche haut, mots, Spaces, fenêtres. Les
   garder sans action ?
2. L3 — Sous macOS et Linux, quand la disposition active est une disposition du registre
   non-Ergopti : couper à la volée les groupes de hotstrings propres à Ergopti (SFB,
   rolls) et les réactiver au retour, sans toucher à la config enregistrée, comme
   Windows ? Ou seulement griser leurs lignes du menu avec la raison ?

Pas encore faits (session suivante) : W1, W2, A4, A5, B4, C4, D3, D4, D5, F2, N3.
F1 est abandonnée.

## 3. Travail de cette session

1. **Nettoyage.**
   - Supprime les notes non suivies `_PAUSED_READ_FIRST.txt` et
     `_UPSTREAM_NOTE.txt` des 8 worktrees.
   - Dans chaque worktree, regarde `git status` : des agents interrompus ont pu
     laisser du travail non commité. Commite ce qui est correct et complet ;
     restaure fichier par fichier ce qui est cassé ou à moitié fait, en le notant
     pour la session suivante.

2. **Relire les 5 tâches jamais relues (A3, C3, D6, E3, L3).**
   - Fais-le avant de les inclure : une relecture adversariale par tâche, contre
     sa spec dans `overhaul_workflow_script.js`.
   - Si le quota ne permet pas les 5, demande-moi lesquelles exclure de la
     release. D6 et L3 sont les plus risquées.

3. **Rebaser sur mes commits Linux de `dev` — obligatoire.**
   - Lance `git fetch origin dev` : j'ai peut-être poussé d'autres commits
     depuis.
   - L'amont a RETIRÉ kanata sous Linux. Le démon exécute lui-même les tap-holds
     et la couche de navigation (`linux/platform/remap/tap_hold_engine.lua`,
     `tap_hold_loader.lua`, `tap_hold_manager.lua` ; commits `a5616e7fa`,
     `2b7b9269f` pour le menu Tap-Holds dans le tray Linux, `6eec7b633`,
     `339f7c65c`).
   - Déplace `feat/overhaul` sur le `dev` local (= `origin/dev` + `f5eabcfe6`) :
     `git branch -f feat/overhaul dev`. Crée ensuite un worktree d'intégration
     dessus.
   - Cherry-picke les commits de chaque lane dans cet ordre : state, logging,
     menu, actions, updater, diag, navlayer, layouts.
   - Résolution des conflits (environ 60 fichiers se recouvrent) :
     - locales et `manifest.toml` : union des clés et des lignes ;
     - fichiers générés : régénère-les avec leurs générateurs, ne les édite
       jamais à la main ;
     - code Linux : l'amont fait foi. Retire tout ce que nos lanes ont ajouté
       pour kanata. La génération Linux de la couche de nav (N2) doit alimenter
       le moteur du démon, ou être retirée proprement si c'est trop gros : dis-le
       moi. Les changements de menu Linux doivent partir du menu tray amont.

4. **Vérifications.**
   - `node tools/test/verify-change.cjs --range=origin/dev..HEAD`, puis
     `--all --diagnose`. Corrige les régressions.
   - Rouges connus liés à cette machine, à classer avec preuves sur la base :
     Node local 22.16 alors que le dépôt épingle 22.22.2 ; le générateur
     `codegen-unicode-case-linux.cjs` exige Unicode 17 ; le test RTK ne trouve
     pas `dirname`.
   - Pousse `feat/overhaul` et suis la CI : `gh run watch` redirigé vers un
     fichier, puis `gh run view --json conclusion`. La CI macOS (launch gate,
     tests Swift du launcher) valide ce qui ne tourne pas sous Windows. Corrige
     jusqu'au vert.

5. **Préparer la release et me la présenter, sans la publier.**
   - Commits intégrés par lane ; tâches exclues et pourquoi ; trous connus (les
     `not_done`).
   - Résultats des tests et de la CI.
   - Liste précise de ce que je dois tester à la main sur Windows (AHK marche
     bien aujourd'hui : l'émulation Ergopti lue depuis le `.keylayout` et la
     couche de nav générée sont les plus risquées), sur macOS (menus, cases à
     cocher, bug bloquant corrigé, logs, mises à jour) et sur Linux.
   - Juste avant de pousser : refais `git fetch origin dev`, rebase
     `feat/overhaul` si `dev` a bougé et relance les vérifications. Puis
     demande-moi l'accord explicite pour avancer `dev` en fast-forward sur
     `feat/overhaul` et pousser.

6. **Préparer la suite.** Mets à jour
   `D:/ewt/_context/PROMPT_REPRISE_2_SUITE.md` avec le nouvel état : ce qui a été
   intégré, les tâches restantes, les commits exclus et les worktrees encore
   utiles.
