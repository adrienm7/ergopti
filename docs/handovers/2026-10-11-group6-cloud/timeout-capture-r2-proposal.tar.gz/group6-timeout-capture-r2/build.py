"""Prepare a source-only, unadopted narrow timeout capture diagnostic."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

ROOT = Path("/workspace/ergopti")
OUT = Path(__file__).resolve().parent
WIRE = Path("static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py")
TEST = Path("tools/test/macos_native_http_receiving_facts_test.py")
spans = [('        trust_callee = None\n        try:\n', '        trust_callee = None\n        trust_install_stream = {"observed": False}\n        try:\n'), ('            for stream in streams:\n', '            if trust_operation == "add":\n                # A timeout still owns its captures until exact native settlement.\n                # Inspect that existing stderr once before its original close.\n                try:\n                    if owned is not None and getattr(owned, "reaped", False) is True:\n                        trust_install_stream = self._trust_install_stream(errors)\n                except BaseException as observation_failure:\n                    # Preserve the original primary. A fresh control interruption\n                    # on success still flows through original file closure below.\n                    if failure is None and (\n                        not isinstance(observation_failure, Exception)\n                        or isinstance(observation_failure, FixtureFailure)\n                    ):\n                        failure = observation_failure\n            for stream in streams:\n'), ('        if trust_operation in ("add", "remove"):\n            # stderr is outside', '        if trust_operation == "add":\n            try:\n                if self.groups:\n                    child_settled = owned is not None and getattr(owned, "reaped", False) is True\n                    child_status = getattr(process, "returncode", None) if child_settled else None\n                    fact = {\n                        "version": 1,\n                        "action": "add_trusted_cert",\n                        "domain": "admin",\n                        "keychain": "owned_private",\n                        "phase": self.command_fact["phase"],\n                        "child_settled": child_settled,\n                        "child_exit_status": child_status if type(child_status) is int and -(2**31) <= child_status < 2**31 else None,\n                        "streams_closed": not closure_refused and all(stream is None or stream.closed for stream in streams),\n                        "command_file_debt": bool(self.command_file_debt),\n                        "stderr": trust_install_stream,\n                    }\n                    print("# native_http_trust_install " + json.dumps(fact, sort_keys=True), file=sys.stderr, flush=True)\n            except BaseException as observation_failure:\n                # Technical observations cannot replace command results; genuine\n                # control interruptions preserve cancellation on prior success.\n                if failure is None and (\n                    not isinstance(observation_failure, Exception)\n                    or isinstance(observation_failure, FixtureFailure)\n                ):\n                    failure = observation_failure\n        if trust_operation in ("add", "remove"):\n            # stderr is outside'), ('    @staticmethod\n    def _trust_callee_fact(raw, operation):\n', '    @staticmethod\n    def _trust_install_stream(stream):\n        """Project the existing settled capture without retaining private bytes."""\n        if stream is None:\n            return {"observed": False}\n        stream.seek(0)\n        raw = stream.read(1025)\n        callee = None\n        category = "empty" if not raw else "unknown"\n        if type(raw) is bytes and len(raw) <= 1024:\n            for name in (b"SecTrustSettingsSetTrustSettings", b"SecKeychainItemImport", b"SecKeychainUnlock"):\n                for prefix in (name + b": ", b"security: " + name + b": "):\n                    if raw.startswith(prefix):\n                        callee = name.decode("ascii")\n                        category = {\n                            b"User interaction is not allowed.\\n": "user_interaction_required",\n                            b"The keychain is locked.\\n": "keychain_locked",\n                            b"Access denied.\\n": "access_denied",\n                            b"Authorization denied.\\n": "access_denied",\n                        }.get(raw[len(prefix):], "unknown")\n                        break\n                if callee is not None:\n                    break\n        return {"observed": True, "captured_bytes": min(1024, len(raw)),\n                "truncated": len(raw) > 1024, "callee": callee, "category": category}\n\n    @staticmethod\n    def _trust_callee_fact(raw, operation):\n')]
before = (ROOT / WIRE).read_text()
after = before
for old, new in spans:
    assert after.count(old) == 1
    after = after.replace(old, new, 1)
inverse = after
for old, new in reversed(spans):
    assert inverse.count(new) == 1
    inverse = inverse.replace(new, old, 1)
assert inverse == before
test_before = (ROOT / TEST).read_text()
extra = (OUT / "additional_tests.py").read_text()
anchor = '\n\nif __name__ == "__main__":\n    unittest.main()\n'
assert test_before.count(anchor) == 1
test_after = test_before.replace(anchor, "\n\n" + extra + anchor, 1)
assert test_after.replace("\n\n" + extra + anchor, anchor, 1) == test_before
manifest = {"schema": 1, "base": "5f7a8467c9696b26a75de104f6329b39c181b8cb", "qualification": "UNEXECUTED_SOURCE_ONLY_NO_ADOPTION", "files": {}, "exact_fixture_inverse_spans": len(spans), "all_original_63_method_bytes_preserved": True}
patch = ""
for name, old, new in [(WIRE, before, after), (TEST, test_before, test_after)]:
    ast.parse(new)
    manifest["files"][str(name)] = {}
    for role, source in [("preimage", old), ("candidate", new)]:
        path = OUT / role / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source)
        manifest["files"][str(name)][role] = hashlib.sha256(path.read_bytes()).hexdigest()
    patch += "".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile="a/" + str(name), tofile="b/" + str(name)))
(OUT / "proposal.patch").write_text(patch)
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
ruff = "/workspace/ergopti-cloud/python/bin/ruff"
assert subprocess.run([ruff, "--version"], check=True, capture_output=True, text=True).stdout.strip() == "ruff 0.15.8"
subprocess.run([ruff, "format", "--config", str(ROOT / "pyproject.toml"), str(OUT / "candidate" / WIRE), str(OUT / "candidate" / TEST)], check=True)
formatted = (OUT / "candidate" / WIRE).read_text()
formatted_tests = (OUT / "candidate" / TEST).read_text()
start = formatted_tests.index("class NativeTimedAddCaptureObservationTests(unittest.TestCase):")
end = formatted_tests.index(anchor, start)
assert formatted_tests[:start - 2] + formatted_tests[end:] == test_before
original_methods = {item.name: ast.get_source_segment(before, item) for item in ast.walk(ast.parse(before)) if isinstance(item, ast.FunctionDef)}
candidate_methods = {item.name: ast.get_source_segment(formatted, item) for item in ast.walk(ast.parse(formatted)) if isinstance(item, ast.FunctionDef)}
assert all(candidate_methods[name] == body for name, body in original_methods.items() if name != "_command")
inverse_spans = []
old_lines, new_lines = before.splitlines(keepends=True), formatted.splitlines(keepends=True)
for kind, old_start, old_end, new_start, new_end in difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_opcodes():
    if kind != "equal":
        inverse_spans.append({"preimage": "".join(old_lines[old_start:old_end]), "candidate": "".join(new_lines[new_start:new_end]), "candidate_start_line": new_start + 1, "candidate_end_line": new_end})
reconstructed = new_lines[:]
for item in reversed(inverse_spans):
    reconstructed[item["candidate_start_line"] - 1:item["candidate_end_line"]] = item["preimage"].splitlines(keepends=True)
assert "".join(reconstructed) == before
(OUT / "exact-formatted-inverse.json").write_text(json.dumps(inverse_spans, indent=2) + "\n")
manifest["formatter"] = "Ruff 0.15.8"
manifest["formatted_exact_inverse_hunks"] = len(inverse_spans)
manifest["all_existing_fixture_functions_except_command_byte_exact"] = True
patch = ""
for name, old, new in [(WIRE, before, formatted), (TEST, test_before, formatted_tests)]:
    manifest["files"][str(name)]["candidate"] = hashlib.sha256((OUT / "candidate" / name).read_bytes()).hexdigest()
    patch += "".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile="a/" + str(name), tofile="b/" + str(name)))
(OUT / "proposal.patch").write_text(patch)
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

manifest["qualification"] = "SOURCE_ONLY_NO_NATIVE_NO_ADOPTION; portable-receipt.json records executed controls"
manifest["first_proposal_total"] = 69
manifest["successor_total"] = 75
manifest["all_first_proposal_method_bytes_preserved_except_command"] = True
for role, name in [("first_tested_fixture", WIRE), ("first_tested_receiving_tests", TEST)]:
    relative = Path("comparison") / name
    manifest[role] = {"path": str(relative), "sha256": hashlib.sha256((OUT / relative).read_bytes()).hexdigest()}
    predecessor = (OUT / relative).read_text()
    successor = (OUT / "candidate" / name).read_text()
    old_methods = {item.name: ast.get_source_segment(predecessor, item) for item in ast.walk(ast.parse(predecessor)) if isinstance(item, ast.FunctionDef)}
    new_methods = {item.name: ast.get_source_segment(successor, item) for item in ast.walk(ast.parse(successor)) if isinstance(item, ast.FunctionDef)}
    assert all(new_methods[key] == value for key, value in old_methods.items() if key != "_command")
assert sum(isinstance(node, ast.FunctionDef) and node.name.startswith("test") for node in ast.walk(ast.parse(formatted_tests))) == 75
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
