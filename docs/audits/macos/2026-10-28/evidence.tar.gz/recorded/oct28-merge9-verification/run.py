import os,subprocess,json,concurrent.futures,time
from pathlib import Path
r=Path('/workspace/ergopti-macos-integration');s=Path('/workspace/scratch/oct28-merge9-verification');env=dict(os.environ)
env['PATH']='/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:'+env['PATH']
commands={'gen-check':['npm','run','-s','gen:check'],'format':['npm','run','-s','format:check'],'strict':['npm','run','-s','lint:conventions:strict'],'ahk-locals':['npm','run','-s','test:ahk-local-same-as-global'],'windows-source':['node','tools/test/test-windows-updater-original-source.cjs'],'encoding':['node','tools/test/test-source-encoding.cjs'],'ahk-encoding':['npm','run','-s','test:ahk-encoding'],'undefined-lua':['node','tools/test/test-lua-undefined-globals.cjs'],'linux-floor':['python3','-m','unittest','discover','-s','static/ergopti/linux/xkb_installation/tests','-p','test_python_floor_compatibility.py'],'plan':['node','tools/test/verify-change.cjs','--plan']}
def run(item):
 name,cmd=item;start=time.monotonic()
 with(s/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'actual_exit':p.returncode,'seconds':round(time.monotonic()-start,3)};print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:rows=list(ex.map(run,commands.items()))
(s/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(0 if all(x['actual_exit']==0 for x in rows)else 1)
