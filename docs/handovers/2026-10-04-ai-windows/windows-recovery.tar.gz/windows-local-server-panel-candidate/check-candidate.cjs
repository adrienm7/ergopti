// windows-local-servers-candidate/check-candidate.cjs
'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const root = '/workspace/ergopti';
const candidates = ["local_server_panel.ahk", "hooks/ErgoptiPlus.ahk", "hooks/ui/menu/menu_llm/_index.ahk", "hooks/ui/menu/menu_llm/init.ahk", "hooks/ui/menu/menu_llm/actions.ahk", "hooks/ui/menu/menu_llm/menu_models.ahk", "hooks/ui/menu/menu_llm/menu_main.ahk", "hooks/infra/lifecycle.ahk"].map((name) => path.join(__dirname, name));
let lint = fs.readFileSync(path.join(root, 'tools/lint/lint-conventions.js'), 'utf8');
lint = lint.slice(0, lint.indexOf('const ahkSourceDirs'));
lint = lint.replace(/^#!.*\n/, '').replace(/^import .*;\n/gm, '').replace(
  /const REPO_ROOT = [\s\S]*?;\n/, 'const REPO_ROOT = ' + JSON.stringify(root) + ';\n'
);
const prelude = 'const {readFileSync,writeFileSync,readdirSync,statSync}=require("fs"); '
  + 'const {join,relative,extname}=require("path"); const {execSync}=require("child_process"); '
  + 'const sharedPaths=require(' + JSON.stringify(path.join(root, 'tools/lib/paths.cjs')) + ');\n';
const checks = '\nfor(const candidate of conventionCandidates){checkFileHeader(candidate);'
  + 'checkSectionSpacing(candidate);checkBannerAlignment(candidate);'
  + 'checkAhkAntiPatterns(candidate);checkAhkStringEscaping(candidate);}'
  + 'if(totalViolations)throw Error(totalViolations+" scoped violations");'
  + 'console.log("PASS: exact repository convention functions on panel and six convention-scanned scratch hooks");';
const conventionCandidates = candidates.filter((candidate) => !candidate.endsWith('/hooks/ErgoptiPlus.ahk'));
vm.runInNewContext(prelude + lint + checks, { require, console, process, conventionCandidates });
// The repository linter deliberately scans driver subdirectories, not the bootstrap
// entrypoint. Preserve its actual baseline findings without fixing unrelated sources.
function bootstrapFindings(candidate) {
  const messages = [];
  const captureConsole = { ...console, log() {}, warn(value) { messages.push(value.replace(/^  WARN .*?  /, '')); } };
  const checks = '\ncheckFileHeader(candidate);checkSectionSpacing(candidate);checkBannerAlignment(candidate);'
    + 'checkAhkAntiPatterns(candidate);checkAhkStringEscaping(candidate);';
  vm.runInNewContext(prelude + lint + checks, { require, console: captureConsole, process, candidate });
  return messages;
}
const bootstrap = candidates.find((candidate) => candidate.endsWith('/hooks/ErgoptiPlus.ahk'));
const baselineBootstrap = bootstrapFindings(path.join(root, 'static/ergopti_plus/windows/ErgoptiPlus.ahk'));
const candidateBootstrap = bootstrapFindings(bootstrap);
if (JSON.stringify(baselineBootstrap) !== JSON.stringify(candidateBootstrap)) {
  throw Error('Bootstrap convention findings differ from actual preimage: ' + JSON.stringify(candidateBootstrap));
}
console.log('PASS: bootstrap retains exact baseline convention findings (' + baselineBootstrap.length
  + '); entrypoint is outside the ordinary lint directory scan');
let capture = fs.readFileSync(path.join(root, 'tools/test/test-ahk-loop-capture.cjs'), 'utf8');
capture = capture.slice(0, capture.indexOf('selfTest();\n\nconst findings'));
vm.runInNewContext(capture + '\nselfTest(); for(const candidate of candidates){'
  + 'const findings=analyse(fs.readFileSync(candidate,"utf8"));'
  + 'if(findings.length)throw Error(JSON.stringify(findings));}'
  + 'console.log("PASS: repository closure analyser and self-tests on panel and seven scratch hook candidates");',
{ require, console, process, __dirname: path.join(root, 'tools/test'), candidates });
for (const candidate of candidates) {
  const bytes = fs.readFileSync(candidate);
  if (!bytes.subarray(0, 3).equals(Buffer.from([0xEF, 0xBB, 0xBF])) || bytes.includes(13)) {
    throw Error('Encoding failed: ' + candidate);
  }
}
console.log('PASS: UTF-8 BOM and LF on panel and seven scratch hook candidates');
const verify = require(path.join(root, 'tools/test/verify-change.cjs'));
console.log('Selected normal verification gates:', [...verify.selectGates([
  'static/ergopti_plus/windows/ui/menu/menu_llm/local_server_panel.ahk'
]).keys()].join(', '));
