const fs = require('node:fs');
const path = require('node:path');
const original = fs.cpSync;
const source = '/workspace/ergopti-macos-verify-batch18-hs/static/ergopti_plus/macos/tests';
const oldEntry = fs.readFileSync('/workspace/scratch/oct28-e2e-sdk-fix/before/static/ergopti_plus/macos/tests/e2e/run_e2e.lua');
fs.cpSync = function(from, to, options) {
 const result = original.call(this, from, to, options);
 if (from === source) fs.writeFileSync(path.join(to, 'e2e/run_e2e.lua'), oldEntry);
 return result;
};
