# Current native menu census source handover

Root source HEAD `2f031af598fe3daa0ad85da8d61dc95c37d8385e`; exact current working-tree hashes and line excerpts are in the sibling JSON. READ-ONLY; no production, detector, baseline, generator, workflow or runtime change. This is source assessment, not fresh native qualification.

The actual baseline lists **32 sites: Windows 22, macOS 6, Linux 4**. It counts lexical native constructors/allocators, including AppendTemplate/AppendGroup/AppendRows and localized nontray window/dialog titles. It is not a count of 32 missing declarations. Do not exempt or lower any recorded site on this assessment alone.

| Windows recorded family | Sites | Actual source ownership and remaining seam |
| --- | ---: | --- |
| Startup inert native Add | 1 | `tray_bootstrap.ahk:49-63,74-95` consumes `SharedStartupTrayProjection`; shared declaration `tray_startup_inert_frame` at manifest:9520. Explicit Label ABI remains native. |
| Hotstring personal file/directory frames | 4 | `menu_hotstrings.ahk:928,1089,1266,1280` consumes actual shared templates at manifest:8432-8441,8535-8568. File/folder counts and native ownership remain data. |
| Personal shortcut frame | 1 | `menu_init.ahk:45-49` consumes `personal_shortcuts_frame` at manifest:7375-7380. |
| Agent System and excluded-app providers | 2 | `menu_agent.ahk:50,55` renders native Maps; System captions at75-112 and app count at123-126 still format translations natively. Dynamic IDs exist at manifest:4376-4389; hs/Linux-only frames do not admit an ahk caption contract. |
| LLM model parent native Add | 1 | `menu_main.ahk:252-256,378-404` formats health marker/model label and attaches native child. Shared llm_model at manifest:4074-4084 supplies identity/layout but is not consumed as a declared parent caption. |
| Backend/thinking/profile frame placements | 3 | `menu_main.ahk:372,410,437` places actual shared-template/GroupRow results; manifest backend/profile frames9434/9329 and thinking template. |
| LLM trigger/generation/display/navigation | 4 | `menu_main.ahk:444,448,452,456` calls genuine AppendGroup; helper admits selected group/i18n/builder at manifest_menu:1706-1723. |
| Model picker/catalogue native allocation | 4 | `menu_models.ahk:259,291,297,338` combines shared fixed frames/commands and actual model/tag/provider data. AppendRows2075 does not itself consume a declaration. Rich catalogue caption policy remains native at449-468; do not infer whole-child closure from the four recorded sites. |
| Shortcut extension status placements | 2 | `menu_shortcuts.ahk:195,200` consumes declared error/empty templates at manifest:7701-7721. |

**19 Windows sites already allocate declared/shared frames or real dynamic data; 3 recorded sites expose concrete translated native caption seams.** This is a bounded family mapping, not proof that all descendants of the 19 are closed or that only three logical presentation obligations remain. In particular, shared data-driven catalogue labels are appropriate native data, while fixed affix/layout policy still needs a genuine declared consumer.

The six macOS sites are ActionPicker title/label (`menu_keyboard_slots.lua:152,217,218`), HF login window title (`models_manager_mlx_hf.lua:830`), shortcut prompt title (`profiles_manager.lua:1068`) and paths editor window title (`menu_paths.lua:537`). The four Linux sites are notification title (`menu_builder.lua:628`), trigger delay Prompt title2345, Tap-Hold Picker title4095 and uninstall dialog title4770. They are localized nontray presentation surfaces, not ten proven missing tray rows. Their native presentation policy remains source-owned; any future shared presentation migration must preserve the real window/prompt owner and independent captions.

## Remaining native/software qualification

Run **38033725841** really executed **1954/10962** planned tests: **1952 PASS, 2 FAIL, 9008 UNEXECUTED, no footer**. All eleven formerly failed configuration subjects and four full-save families pass in that run. Root receives the two separate Windows fixture-only repairs; this ledger does not duplicate them or turn their source fixes into native PASS.

The genuine 34-store case passed but took **238768.561 ms**, including Apply127281.460 ms and refusal110858.479 ms. Guard32 reports397.775 ms for32 accepted ready-source calls; that does **not** price the active owned bundle. Actual bundle cardinality is unobserved: at least35 intended paths; default lease acquisition also prepends active global ConfigurationFile and may add another.

All **nine** acquired-read temporal controls (three recovery, six guarded adapter) remain UNEXECUTED. They can run in real Windows manual CI; they are not inherently physical-device tasks. Full unit qualification still requires their actual acquired native handle/read interval, mutation refusal/Hits0, exact same-authority repair, and complete unchanged22-minute suite footer. Native desktop/startup/packaging/install stages were not completed by this partial run.

TODO5/42 software performance/native CI remains open. The pinned V2 latency ledger and inactive genuine profiling seam are unchanged. There is no measured safe optimization, new deadline/filter/sharding proposal or active new diagnostic; do not add a canonical timing subject that consumes the remaining22-minute budget before original controls can execute. TODO54/81 shared presentation completion and TODO16/38 full native/installed acceptance remain honest separate obligations.

The sibling JSON pins the actual partial raw evidence, immutable current line snippets, all referenced source hashes, and the unchanged V2 latency packet. Current source/excerpts are not a post-merge final-tree qualification.
