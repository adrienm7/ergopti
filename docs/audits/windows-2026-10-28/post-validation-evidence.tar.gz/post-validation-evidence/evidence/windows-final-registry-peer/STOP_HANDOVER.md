# Stopped read-only registry CI review

Stopped immediately at the maintainer's explicit request. No source edits, native executions, commits, or queued jobs were performed by this reviewer.

## Established source facts

1. `modules/keymap/keylayout/layout_registry_download.ahk`, `_LayoutRegistryDownload.__New`, resolves its input directory through `FSResolveDirectoryPath` before publishing `this.Path`. The resolver (`adapters/file_system.ahk:390`) uses actual `GetFullPathNameW` and `GetLongPathNameW`. `_Open` registers read activity against **this canonical path**.
2. `infra/file_read_activity.ahk:14`, `FileReadActivityKey`, is explicitly a **lexical** lower-case/slash key. It performs no filesystem alias resolution. Its early publication before native I/O is intentional; `config_write_lease.ahk` shares this key. Do not introduce arbitrary native I/O into this helper as a quick compatibility shim.
3. Production `LayoutRegistry_Request` passes `Job.OutputOwner.Path` to the transport (`layout_registry.ahk:402`). The custody tests query `FileReadActivityBusy(Stage)` using the original raw temporary path (`test_layout_registry_download_custody.ahk:29,111`). On Windows, `A_Temp` may use `RUNNER~1`, while the owner resolves the long spelling. This establishes a source-level coordinate mismatch. An actual short-path native execution is still needed before calling all nine errors a reproduced alias failure. Query the authoritative owner path and independently prove physical-file equivalence; do not weaken the busy assertion.
4. The late-completion fake is not faithful to acknowledged retirement: `_LCR_Request.Abort` (`test_layout_catalogue_refresh_owner.ahk:78`) returns true after merely setting `Aborted`; `World.Complete` (`:119`) still writes a file after that acknowledgement. `test_layout_refresh_completion.ahk` deliberately calls `Complete(Old)` after the old owner has retired and removed its stage. That creates a **new unowned pathname object**. The genuine `CurlAsyncRequest.Abort` (`adapters/http_client.ahk:655`) acknowledges only completion or successful owned process termination, then marks completion and cleans up. No admissible managed writer should write after that acknowledgement.
5. `_LayoutRegistryPoll` on an already settled job calls `Req.Abort` and does not delete a now-unowned path. Do NOT restore blind pathname deletion merely to satisfy the fake's recreated-file assertion. A faithful queued readiness signal after an ACK should not write new bytes. Add an independent foreign-replacement preservation control when work resumes.
6. A clear teardown leak mechanism follows the late-completion failure: the live successor has received bytes but has not yet been polled when the old-file assertion fails. `_LCR_World.Retire` discards all queued tasks **before** fake abort, so the real successor job never settles and its active download/read-activity owner survives. `_LCRA_Case` then removes callback bookkeeping and attempts directory removal while preserving the primary assertion. This is a strong source-level explanation of downstream configuration refusals, but no native cascade execution was performed by this reviewer.
7. Global read activity alone causes `_ConfigWriteTerminalTryAcquire` (`config_write_lease.ahk:273`) to refuse; `ConfigScopeCommitOperations` returns a refused receipt before building when acquisition fails (`infra/config_scope.ahk:81`). This supplies a direct possible cascade into the eight later key-combination pending-versus-refused cases.

## Important unresolved alternative for the eight config-scope failures

A separate raw/canonical path split may also exist, so do not assume the eight are only cascades:

- `_ScopeOwnerFixture` (`tests/unit/test_config_scope_manifest.ahk:110`) constructs `Fixture.path` and locator directly under raw `A_Temp`.
- `ConfigScopeCommitOperations` keeps the original `Options.path` in local `Path` (`infra/config_scope.ahk:65`) and later calls `ConfigCommitBuilt(Path, ..., Bundle)` (`:179`).
- `ConfigTransitionAcquireLifecycleBundle` normalizes every intended path before acquiring its terminal bundle (`infra/config_transition_runtime.ahk:350-370`).
- The bundle's ownership keys use the lexical `FileReadActivityKey`. If `ConfigCommitBuilt` selects the borrowed owner using the unnormalized original path, it may reject that owner even with no leaked registry activity. The downstream `ConfigCommitBuilt` selection was **not yet inspected**, so this remains a concrete hypothesis, not a proved bug.

## Next bounded causal checks when resumed

1. Fresh process: run the original eight key-combination semantic-scope cases alone under normal and genuine short-name `A_Temp`; record `Receipt.detail`, global read-activity/registry-owner counts, the raw path, normalized path, and lease token keys.
2. Separate process: run only the two exceptional late-completion cases, then those same eight cases; compare with the fresh process and record teardown ownership counts.
3. Native short-path custody test: use genuine Win32 `GetShortPathNameW` and directory/file identity checks; compare original `Stage`, `Owner.Path`, both activity keys, and actual handle identities. Do not synthesize a short string that the filesystem does not resolve.
4. Repair faithful fake completion and actual queued-poll teardown before attributing later failures to production configuration behavior. Preserve the first failure and still drain every exact owner; never clear global owner maps as a workaround.
5. Inspect borrowed-owner selection in `ConfigCommitBuilt` before considering any independent config-scope path correction. Do not alter recommendation values, gesture/tap-hold behavior, or protected sources.

All native hypotheses remain unqualified. Existing CI annotations are under `/workspace/scratch/windows-final-delivery/failed-job-123111092632-annotations.json`.
