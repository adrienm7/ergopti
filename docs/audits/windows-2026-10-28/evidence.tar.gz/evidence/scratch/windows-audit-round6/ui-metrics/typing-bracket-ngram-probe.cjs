const assert=require('node:assert/strict');
const vm=require('node:vm');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const observations=[];
for(const token of ['abcd','abc[BS]','[ab]','[BS]']){
 const page=loadMetricsTypingPage('windows');
 page.messageListeners.filter(e=>e.name==='message').at(-1).callback({data:{type:'prefetch',blob:{metrics_manifest:{'2026-10-26':{'Editor.exe':{chars:28,time:1000}}},_prefetch_data:{historical:{qg:{[token]:{c:7,t:0}}},today:{}},app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}}}});
 vm.runInContext("app_state.current_tab='qg';",page.context);
 page.context.render_current_tab();page.timers.at(-1)();
 observations.push({token,actualTokenCount:page.context.count_key_tokens(token),projectedKeys:vm.runInContext('Object.keys(app_state.data.qg)',page.context),renderedCount:vm.runInContext('app_state.rendered_list.length',page.context),html:page.elements.get('metrics_table_body').innerHTML,diagnostics:page.diagnostics});
}
for(const observation of observations)console.log(JSON.stringify(observation));
assert.equal(observations[0].renderedCount,1,'plain native four-character positive');
assert.equal(observations[1].renderedCount,1,'native three characters and actual backspace positive');
assert.equal(observations[2].renderedCount,1,'literal brackets and two letters form four native characters');
assert.equal(observations[3].renderedCount,1,'literal bracket-B-S-bracket also forms four native characters');
