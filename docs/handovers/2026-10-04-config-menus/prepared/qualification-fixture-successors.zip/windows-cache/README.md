# Windows dynamic scope cache-prime fixture repair

## Actual failure and source cause

Manual CI 37276807199, projection ab142045e4c3460ad184ddf8c1ca09482fa835a7,
source a550193ebc31aa819c369f701a61ebed72d86216, reported six native
`hotstring-dynamic-menu-owner` failures at the existing assertion
`pending publication preserves the live text cache`: enabled/disabled commands,
committed/late-refusal outcomes and paused late refusal.

The fixture calls `ApplyConfigToml` and `ParseTomlFile` before publication. Its
first explicit `ReadTomlFile(Fixture.path)` comes after the pending candidate is
on disk. Earlier `ApplyConfigToml` incidentally primed the raw cache through
`Content := ReadTomlFile(FilePath)`. Group1 commit
7339f6fc097286b557a469d6637f6dcdd9a3efd9 replaced that call with semantic
`ConfigTomlReadSnapshot`; this reads `FileRead` directly without publishing raw
cache state. `ParseTomlFile` also reads directly and publishes only its parsed
cache. The unique private fixture path starts uncached, so the first raw read
after pending publication reads the candidate. This assertion failure does not
by itself show that publication mutated an existing raw cache.

Relevant ownership and concrete boundaries:

- `windows/tests/unit/test_hotstring_category_scope.ahk`,
  `_HSCS_DynamicMenuOwner`: fixture setup and existing pending cache assertions.
- `windows/infra/toml/toml_config_loader.ahk`, `ApplyConfigToml`: semantic reader.
- `windows/infra/toml/config_snapshot.ahk`, `ConfigTomlReadSnapshot`: raw file read
  without publication; `ParseConfigTomlFile` is the separate boot publication
  owner that seeds raw, parsed and snapshot caches.
- `windows/infra/toml/toml_helpers.ahk`, `_ParseTomlFileImpl`: parsed cache only.
- `windows/infra/toml/toml_loader.ahk`, `ReadTomlFile`: raw cache or native read.
- `windows/infra/config_scope.ahk` and
  `windows/infra/hotstrings/hotstrings_scope.ahk`: Group2 publication owners,
  untouched by this packet.

## Minimal patch and evidence

The patch explicitly primes and verifies the source raw cache before constructing
the menu. All 203 original assertion statements retain their literal text and
order. It adds one setup assertion and its comment, changing no hotstring
production code or independent expected data. Manifest hashes identify exact
source/preimage/postimage and show all audited files byte-identical original
dev 3b4afeba128bdcf9fb1155754742792c95f250fc to integrated A550.

`previous-feature-reader.txt` and `snapshot-feature-reader.txt` preserve exact
source excerpts before/after 7339f6fc. `static-cache-mechanism-controls.json`
is expressly a source-derived cache-effects model: six old-reader preserved
sources, six unprimed new-reader mismatches, six explicitly primed preserved
sources and six negative-control pending cache evictions still mismatching.
It executes no AHK source and is not native test qualification.

Isolated patch applicability and byte-exact output/BOM/LF passed. The repository
checkout, index, refs and CI were untouched. Ownership of the semantic reader
change is Group1 per the parent's bounded commit and final integration ledgers.

## Required qualification

Windows AutoHotkey is unavailable locally. Real Windows CI must still execute
the original six cases and the full unit suite. All original publication,
rollback, pause, master-gate, backup, future-family, source and parsed-pointer
assertions remain required. Actual native results may expose further failures;
the frozen fixture patch does not qualify unfinished Group2 functionality.
