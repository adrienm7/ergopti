

-- ======================================================================
-- Personal watcher topology (independent real native source controls)
-- ======================================================================

helpers.describe("file_watchers Personal topology", function()
	if not native_ok or not CAN_STAT or package.config:sub(1, 1) ~= "/" then
		print("  [Personal topology receiving not executed: POSIX/native luv filesystem unavailable]")
		return
	end
	local posix_ok, actual_posix = pcall(require, "posix")
	if not posix_ok or type(actual_posix.dir) ~= "function" then
		print("  [Personal topology fault receiving not executed: native POSIX directory API unavailable]")
		return
	end
	local function session(backend_name, run)
		local root = assert(native_luv.fs_mkdtemp((os.getenv("TMPDIR") or "/tmp") .. "/ergopti_topology_XXXXXX"))
		local directories, files, records = { root }, {}, {}
		local state = { root = root, now = 0, reloads = 0, scans = 0, callbacks = {},
			fail_callback = false, denied = nil, start_refused = nil, stop_refused = nil, close_refused = nil }
		local backend, scan_port = {}, {}
		for key, value in pairs(native_luv) do backend[key] = value end
		for key, value in pairs(actual_posix) do scan_port[key] = value end
		function scan_port.dir(path)
			state.scans = state.scans + 1
			if state.denied == path then error("controlled native enumeration refusal") end
			return actual_posix.dir(path)
		end
		function backend.new_fs_event()
			local handle = assert(native_luv.new_fs_event())
			records[handle] = { handle = handle, retired = false }
			return handle
		end
		function backend.fs_event_start(handle, path, flags, callback)
			local record = assert(records[handle])
			record.path, record.callback = path, callback
			state.callbacks[#state.callbacks + 1] = record
			if state.start_refused == path then return nil, "controlled native activation refusal", "EACCES" end
			return native_luv.fs_event_start(handle, path, flags, callback)
		end
		function backend.fs_event_stop(handle)
			if state.stop_refused == records[handle].path then return nil, "controlled native stop refusal" end
			return native_luv.fs_event_stop(handle)
		end
		function backend.close(handle, callback)
			local record = assert(records[handle])
			if state.close_refused == record.path then return nil, "controlled native close refusal" end
			return native_luv.close(handle, function(...)
				record.retired = true
				if callback then callback(...) end
			end)
		end
		function state.directory(path)
			assert(native_luv.fs_mkdir(path, 448)); directories[#directories + 1] = path; return path
		end
		local sequence = 0
		function state.file(path)
			files[path] = true
			local handle = assert(io.open(path, "w"))
			local wrote, detail = handle:write('[personal.topology]\ntrigger = "before"\n')
			local closed, close_detail = handle:close()
			assert(wrote, detail); assert(closed, close_detail)
			sequence = sequence + 1
			assert(native_luv.fs_utime(path, 1700000000 + sequence, 1700000000 + sequence))
			return path
		end
		function state.rename(from, to)
			assert(native_luv.fs_rename(from, to))
			for index, path in ipairs(directories) do
				if path == from or path:sub(1, #from + 1) == from .. "/" then directories[index] = to .. path:sub(#from + 1) end
			end
			local moved = {}
			for path in pairs(files) do
				if path == from or path:sub(1, #from + 1) == from .. "/" then moved[path] = to .. path:sub(#from + 1) end
			end
			for old, new in pairs(moved) do files[old], files[new] = nil, true end
		end
		function state.remove_file(path) assert(native_luv.fs_unlink(path)); files[path] = nil end
		function state.remove_directory(path)
			assert(native_luv.fs_rmdir(path))
			for index, value in ipairs(directories) do if value == path then table.remove(directories, index); break end end
		end
		local previous_watch = package.loaded["infra.file_watchers"]
		local previous_posix = package.loaded["posix"]
		local watcher
		function state.start()
			package.loaded["posix"] = scan_port
			watcher = helpers.load_module_with_dependency("infra.file_watchers", "luv", backend_name == "native" and backend or false)
			package.loaded["posix"] = previous_posix
			watcher.start({ personal_dir = state.personal, now_ms = function() return state.now end,
				on_reload = function()
					state.reloads = state.reloads + 1
					if state.fail_callback then error("controlled reload callback refusal") end
				end })
			helpers.assert_eq(watcher.has_inotify(), backend_name == "native")
		end
		function state.drain()
			local deadline = native_luv.hrtime() + 50000000
			repeat native_luv.run("nowait"); native_luv.sleep(1) until native_luv.hrtime() >= deadline
		end
		function state.settle(expected)
			local before = state.reloads
			state.drain(); watcher.pump()
			state.now = state.now + 600
			watcher.pump(); state.drain(); watcher.pump()
			if expected ~= nil then helpers.assert_eq(state.reloads, before + expected, "one settled source/topology burst must deliver exactly the expected reload") end
		end
		function state.idle()
			local scans, before = state.scans, state.reloads
			for _ = 1, 10 do state.now = state.now + 600; watcher.pump() end
			helpers.assert_eq(state.reloads, before, "idle pumps cannot synthesize reloads")
			helpers.assert_eq(state.scans, scans, "idle pumps cannot recursively enumerate Personal")
		end
		function state.active(path)
			local count = 0
			for _, record in pairs(records) do
				if record.path == path and not record.retired and native_luv.is_active(record.handle) then count = count + 1 end
			end
			return count
		end
		function state.pump() watcher.pump(); state.drain() end
		function state.stop() return watcher.stop() end
		state.personal = state.directory(root .. "/personal")
		local ok, primary = xpcall(function() run(state) end, debug.traceback)
		local failures = {}
		state.start_refused, state.stop_refused, state.close_refused = nil, nil, nil
		if watcher then local called, detail = pcall(watcher.stop); if not called then failures[#failures + 1] = tostring(detail) end end
		native_luv.run("nowait")
		-- Every native handle below was created by this exact private fixture.
		-- An old producer may lose its close ownership; still retire only ours.
		for handle, record in pairs(records) do
			if not record.retired then
				local called, detail = pcall(function()
					native_luv.fs_event_stop(handle)
					if not native_luv.is_closing(handle) then native_luv.close(handle, function() record.retired = true end) end
				end)
				if not called then failures[#failures + 1] = tostring(detail) end
			end
		end
		native_luv.run("nowait")
		package.loaded["infra.file_watchers"], package.loaded["posix"] = previous_watch, previous_posix
		for path in pairs(files) do local deleted, detail = native_luv.fs_unlink(path); if not deleted then failures[#failures + 1] = tostring(detail) end end
		for index = #directories, 1, -1 do local deleted, detail = native_luv.fs_rmdir(directories[index]); if not deleted then failures[#failures + 1] = tostring(detail) end end
		for _, record in pairs(records) do if not record.retired then failures[#failures + 1] = "owned native handle did not acknowledge retirement" end end
		if not ok then error(tostring(primary) .. (#failures > 0 and (" | cleanup: " .. table.concat(failures, " | ")) or ""), 0) end
		helpers.assert_eq(#failures, 0, "every independent private cleanup must acknowledge retirement: " .. table.concat(failures, " | "))
	end

	for _, backend in ipairs({ "native", "pump" }) do
		helpers.it("(linux-watch-topology) " .. backend .. " admits a moved-in populated tree and its later edits", function()
			session(backend, function(s)
				local staging = s.directory(s.root .. "/staging"); local sub = s.directory(staging .. "/nested")
				s.file(sub .. "/rules.toml"); s.start()
				s.rename(staging, s.personal .. "/incoming"); s.settle(1)
				s.file(s.personal .. "/incoming/nested/rules.toml"); s.settle(1); s.idle()
			end)
		end)
		helpers.it("(linux-watch-topology) " .. backend .. " observes a later TOML in a directory created after start", function()
			session(backend, function(s)
				s.start(); local sub = s.directory(s.personal .. "/later"); s.settle(1)
				local file = s.file(sub .. "/rules.toml"); s.settle(1)
				s.file(file); s.settle(1)
			end)
		end)
		helpers.it("(linux-watch-topology) " .. backend .. " observes a new direct TOML and later in-place edits", function()
			session(backend, function(s)
				s.start(); local file = s.file(s.personal .. "/new.toml"); s.settle(1)
				local scans = s.scans; s.file(file); s.settle(1)
				helpers.assert_eq(s.scans, scans, "an in-place file edit cannot recursively rescan Personal")
				s.idle()
			end)
		end)
		helpers.it("(linux-watch-topology) " .. backend .. " refreshes renamed and removed/recreated directory bindings", function()
			session(backend, function(s)
				local old = s.directory(s.personal .. "/old"); local file = s.file(old .. "/rules.toml"); s.start()
				local moved = s.personal .. "/renamed"; s.rename(old, moved); s.settle(1)
				s.file(moved .. "/rules.toml"); s.settle(1)
				if backend == "native" then helpers.assert_eq(s.active(old), 0, "removed lexical bindings cannot remain active") end
				s.remove_file(moved .. "/rules.toml"); s.remove_directory(moved); s.settle(1)
				s.directory(moved); s.file(moved .. "/new.toml"); s.settle(1)
				s.file(moved .. "/new.toml"); s.settle(1)
			end)
		end)
		helpers.it("(linux-watch-topology) " .. backend .. " keeps reconciled coverage after the reload callback refuses", function()
			session(backend, function(s)
				s.start(); s.fail_callback = true
				local sub = s.directory(s.personal .. "/refused"); s.file(sub .. "/rules.toml"); s.settle(1)
				s.fail_callback = false; s.file(sub .. "/rules.toml"); s.settle(1)
			end)
		end)
		helpers.it("(linux-watch-topology) " .. backend .. " keeps prior coverage after an unacknowledged directory scan", function()
			session(backend, function(s)
				local old = s.file(s.personal .. "/old.toml"); s.start()
				s.denied = s.personal; s.file(s.personal .. "/new.toml"); s.settle(0)
				if backend == "native" then helpers.assert_eq(s.active(s.personal), 1, "ambiguous emptiness cannot retire the original directory owner") end
				s.denied = nil; s.settle(1); s.file(old); s.settle(1)
			end)
		end)
	end

	helpers.it("(linux-watch-topology) native ignores unrelated regular files without scanning Personal", function()
		session("native", function(s)
			s.start(); local scans = s.scans; s.file(s.personal .. "/ignored.txt"); s.settle(0)
			helpers.assert_eq(s.scans, scans); s.idle()
		end)
	end)
	helpers.it("(linux-watch-topology) native retains original coverage across a refused descendant activation", function()
		session("native", function(s)
			local existing = s.file(s.personal .. "/existing.toml"); s.start()
			local new = s.directory(s.personal .. "/new"); s.file(new .. "/rules.toml"); s.start_refused = new; s.settle(0)
			helpers.assert_eq(s.active(s.personal), 1, "a refused staging candidate cannot replace admitted coverage")
			s.start_refused = nil; s.settle(1); s.file(existing); s.settle(1); s.file(new .. "/rules.toml"); s.settle(1)
		end)
	end)
	helpers.it("(linux-watch-topology) native rejects an obsolete callback after removal and after a new session", function()
		session("native", function(s)
			local sub = s.directory(s.personal .. "/old"); local file = s.file(sub .. "/rules.toml"); s.start()
			local held
			for _, record in ipairs(s.callbacks) do if record.path == sub then held = record.callback end end
			helpers.assert_true(type(held) == "function", "capture the actual originally admitted native callback")
			s.remove_file(file); s.remove_directory(sub); s.settle(1)
			held(nil, "forged.toml", { change = true }); s.settle(0)
			s.stop(); s.start(); held(nil, "forged.toml", { change = true }); s.settle(0)
		end)
	end)
	for _, field in ipairs({ "stop_refused", "close_refused" }) do
		helpers.it("(linux-watch-topology) native retains owned retirement after " .. field, function()
			session("native", function(s)
				local sub = s.directory(s.personal .. "/old"); local file = s.file(sub .. "/rules.toml"); s.start()
				s[field] = sub; s.remove_file(file); s.remove_directory(sub); s.settle(1)
				s[field] = nil; s.pump()
				for _, record in ipairs(s.callbacks) do
					if record.path == sub then helpers.assert_true(record.retired, "the owner must retain and repair its exact refused retirement") end
				end
			end)
		end)
	end
end)
