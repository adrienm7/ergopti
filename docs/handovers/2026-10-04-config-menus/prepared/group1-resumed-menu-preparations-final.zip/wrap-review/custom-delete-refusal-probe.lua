
helpers.describe("independent rendered custom-delete persistence refusal", function()
 for _, receipt in ipairs({"false", "nil", "truthy"}) do
  helpers.it("preserves custom model after " .. receipt .. " save refusal", function()
   with_wrap_controls({custom={{left="a",right="b"}},receipt_kind=receipt}, function(f)
    local row=wrap_row(f.build().menu,"a … b : menu.shortcuts.wrap_symbols_custom_label")
    helpers.assert_eq(row.menu[1].fn(),false)
    helpers.assert_eq(f.calls.saves,1)
    helpers.assert_eq(f.calls.updates,0)
    helpers.assert_eq(f.state.custom_wrap_symbols,{{left="a",right="b"}},"refusal must retain native model")
   end)
  end)
  helpers.it("preserves live wrap pair after " .. receipt .. " save refusal", function()
   with_wrap_controls({custom={{left="a",right="b"}},receipt_kind=receipt}, function(f)
    local live
    f.ctx.shortcuts.set_wrap_pairs_getter=function(getter)live=getter end
    local row=wrap_row(f.build().menu,"a … b : menu.shortcuts.wrap_symbols_custom_label")
    helpers.assert_eq(live().a,{left="a",right="b"})
    helpers.assert_eq(row.menu[1].fn(),false)
    helpers.assert_eq(live().a,{left="a",right="b"},"refusal must retain eventtap's active wrapping pair")
   end)
  end)
 end
end)
