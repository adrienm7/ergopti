from pathlib import Path
import importlib.util,json,os,tempfile
root=Path('/workspace/ergopti-macos-native-validation');scratch=Path(__file__).parent
spec=importlib.util.spec_from_file_location('bridge',root/'tools/diagnostics/hs274_persistence_test.py');bridge=importlib.util.module_from_spec(spec);spec.loader.exec_module(bridge)
with tempfile.TemporaryDirectory(prefix='ergopti-startup-replay-') as temporary:
 folder=Path(temporary);ledger=folder/'data.sql';(folder/'.gitignore').write_text('today.log\n')
 with ledger.open('w') as out:
  for batch in range(32):
   out.write('-- === ingest batch 2026-10-28 12:00:00.000 (offset %d -> %d, 100 entry(ies)) ===\nBEGIN TRANSACTION;\n'%(batch*100,(batch+1)*100))
   for item in range(batch*100,(batch+1)*100): out.write("INSERT OR IGNORE INTO events_system VALUES ('bootstrap-proof',%d,'2026-10-28 12:00:00','2026-10-28','wake','{\"pad\":\"%s\"}');\n"%(item,'x'*1000))
   out.write('COMMIT;\n')
 os.environ.update(HOME=temporary,ERGOPTI_PHYSICAL_SOURCE_ROOT=str(root))
 result=bridge.run_fixture('/workspace/toolchain/bin/lua',temporary,scratch/'cold-cache.lua');result['ledger_bytes']=ledger.stat().st_size
 (scratch/('old-public-init.json' if os.getenv('ERGOPTI_STARTUP_REPLAY_OLD_SOURCE') else 'new-partial-public-init.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
 assert result['stopped'] is True
 if os.getenv('ERGOPTI_STARTUP_REPLAY_OLD_SOURCE'): assert result['native_rows']==3200 and not result['sentinel_before_complete']
 else: assert result['native_rows']<3200 and result['sentinel_before_complete']
