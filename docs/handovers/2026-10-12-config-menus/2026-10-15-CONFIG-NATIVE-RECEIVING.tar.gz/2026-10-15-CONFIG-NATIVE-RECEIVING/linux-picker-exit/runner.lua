local root = "/workspace/.ergopti-cloud/resume-personal-topology-fixture-portability/source/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local helpers = require("tests.helpers")
require("tests.unit.ui.test_native_dialog_titles")
local results = helpers.get_results()
print(require("json").encode(results))
os.exit(results.failed == 0 and 0 or 1)
