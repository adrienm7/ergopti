#!/bin/bash
export PATH="/workspace/tooling/node22/node_modules/.bin:/workspace/tooling/python/bin:/workspace/tooling/native/usr/bin:$PATH"
export LD_LIBRARY_PATH="/workspace/tooling/native/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LUA_CPATH="/workspace/tooling/native/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;;"
export LUA_CPATH_5_4="/workspace/tooling/native/usr/lib/x86_64-linux-gnu/lua/5.4/?.so;;"
export LUA_PATH="/workspace/tooling/native/usr/share/lua/5.1/?.lua;/workspace/tooling/native/usr/share/lua/5.1/?/init.lua;;"
export LUA_PATH_5_4="/workspace/tooling/native/usr/share/lua/5.4/?.lua;/workspace/tooling/native/usr/share/lua/5.4/?/init.lua;;"
export XKB_CONFIG_ROOT="/workspace/tooling/native/usr/share/X11/xkb"
export XDG_DATA_HOME="/workspace/.local/share"
export XDG_CONFIG_HOME="/workspace/.config"
export XDG_CACHE_HOME="/workspace/.cache"
export XDG_STATE_HOME="/workspace/.local/state"
export npm_config_cache="/workspace/.cache/npm"
export UV_CACHE_DIR="/workspace/.cache/uv"
export TMPDIR="/var/tmp/ergopti-cloud-validation"
mkdir -p "$TMPDIR"

# Source-only pixel observer and isolated native X11 fixture prerequisites.
export PYTHONPATH="/workspace/tooling/python-lib${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/tooling/graphical-bin:$PATH"
