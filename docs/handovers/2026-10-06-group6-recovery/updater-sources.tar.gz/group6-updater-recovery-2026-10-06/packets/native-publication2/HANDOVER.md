# Private native archive publication revision2

SOURCE ONLY. No candidate import, compiler, control, native test, generated binary,
main-tree edit, stage/commit/push/CI or installed qualification executed.
Predecessor cec03249 packet remains immutable. Original11 native control source
is byte-exact318a52a0; original tri-state getter defect is corrected only here.
Bounded SOURCE ACK received from archive36 for current C7064fd9b/headerdc98e47a
and additive controls336f84f9; see SOURCE-REVIEW.md. This is no native runtime ACK.

## Ownership and private interfaces

This packet owns C/header, native-port controls, generator recipe and clock-domain
source/control. shared_failure62 owns opaque Lua registry/wrapper, private sealing
lease adapter, original-budget caller, native reader/tar consumer and asynchronous
installer joins. Root owns main manifest/catalogue/generator/package integration.

Private reserve before checksum captures meta/txn/freshLineage/outputCurrent and
one original total deadline. `create_directory` uses the native selected parent,
component-wise retained-parent NOFOLLOW/CLOEXEC acquisition,128-bit getrandom
GRND_NONBLOCK, one exclusive0700 child and retained parent+child identity. mkdir
ambiguity keeps acquired namespace debt. This is a trusted exclusive namespace;
a hostile same-UID process capable of altering it is NOT isolated by this scheme.

`allocate_output` creates actual parent-only O_TMPFILE0600 via held directory FD,
validates anonymous empty regular inode/private identity and retains a private
native inode anchor. Success transfers ONLY its new descriptor to the original
lease. Partial failures keep exact pending native FD; no manager/integer getter.
The anchor prevents a closed/recycled output FD from borrowing a foreign inode.
`stage` validates the anchored created inode, actual acknowledged length and
original hash deadline, links the private duplicate through admitted held procfs
directory FD into held destination FD without replacement, validates post-link,
then physically closes the anchor before stage0. Name ambiguity is retained.

Only the branded adapter may invoke private commit AFTER exact old original FD,
timer, producer, writer and hash owners physically settle and a separate fresh
generation/selection fence admits artifact adoption. C cannot establish those
external facts or matching checksum; no stage/Ccommit substitutes for them.

`allocate_reader` is available only after commit/new install consent. It validates
actual retained inode/type/UID/private mode/length and held directory before/after
new close-on-exec duplication under original NEW install deadline. This new FD
goes only to the captured native asynchronous reader, never arbitrary callbacks
or manager. Parent explicit-offset reads and tar pipes/consumer/group retirement
must join before cleanup. C knows nothing about a transferred reader's settlement;
its descriptors_closed result alone is not whole artifact/transfer settlement.

`copy_display_path` is bounded and only available after commit; it copies original
recorded allocation location plus immutable captured archive name. It does not
prove the path currently maps to this inode. Display strings never authorize
installer/reader/publication/cleanup or trigger a pathname fallback.

## Actual native cleanup and debt

Cleanup is allowed only under the captured exclusive namespace owner AFTER all
actual external lease/read/tar consumers join. It uses ONLY retained dir/parent
FDs and captured names, checks inode/type/private identity, refuses any foreign or
noisy entry, removes only its known same-inode entry and own empty created child,
then closes exact native descriptors once. It never guesses/removes a displayed
name. It does not claim atomically inode-conditional unlink against a hostile
same-UID external mutator; Linux unlinkat provides no such primitive, and that
is outside the explicitly approved exclusive namespace premise.

Each census uses a new openat(dirfd,'.') OFD, preserving native identity; dup would
share offsets and lose a complete second scan. A failed fstat/fdopendir retains
its exact new scan FD. A retry refuses before another acquisition until the
actual retained scan owner retires. Close ambiguity never permits bare-FD retry,
memory disposal or successful physical closure. Foreign/noisy namespace retains
actual inode+directory authority for explicit later recovery; no raced fallback.

C policy errno and actual syscall errno are currently NOT distinguished by a
provenance port. Wrapper therefore emits canonical UNKNOWN C-refusal receipt and
keeps errno privately; do not classify policy EPERM/EINVAL/ESTALE as verified disk
or permission failures. Existing actual uv write/read typed receipts stay intact.
A separately reviewed syscall/stage provenance extension remains optional work.

## Clock, build and loading

Actual helper ABI1 uses Linux CLOCK_MONOTONIC uint64 nanoseconds/double/1e6, matching
actual luv.hrtime conversion without floor/calibration or deadline restart.
Pinned libuvv1.50.0 unix/core.c routes uv_hrtime to UV_CLOCK_PRECISE; linux.c uses
CLOCK_MONOTONIC for PRECISE (COARSE only FAST). This source proves that contract,
not the current installed runtime version. The actual loader must require high
resolution backend and bracket helper clock with actual luv.hrtime before/after;
the256-bracket native Lua control is authored UNEXECUTED. os.time fallback refuses.

Root approved generation through tools/build/build-linux-native-output.sh from
these same C/header files, producing driver-root/bin/libergopti_archive_publication.so.
Source recipe has no new external library dependency or handwritten stat ABI.
It uses native compiler/system headers, no-replace output publication, and retains
its owned stage on compiler failure/cancellation until external build owner settles.
No binary was manually built/copied. Canonical production source directory will
be static/ergopti_plus/linux/native/archive_output; root performs tracked inventory,
build-linux-driver/package catalogue integration after qualification.

Private Lua loader binds ONLY Paths.driver_root()/bin/libergopti_archive_publication.so,
captures original native functions/receiver, requires ABI1+all ports+actual clock
admission, and refuses absent/incompatible backend. No alternate library or
pathname updater fallback is enabled. Actual Ubuntu22.04/24.04, kernel5.15/6.8/6.12,
distribution libc/architecture and installed packaging compatibility are UNRUN.

## Independent controls and future exclusive commands

Original11 source remains byte-exact. New revision2 control separately covers13
real native scoped scenarios: precise clock bracket; private random directory;
empty anonymous close-on-exec output; second-allocation refusal; same output inode
staging; precommit reader refusal; exact informational display; bounded-copy
refusal; three exact-inode explicit-offset readers+EOF+close; physical namespace/
descriptor cleanup; actual original FD-number reuse refusal under inode anchor;
expired output allocation; foreign/noisy bytes preserved on cleanup refusal.
These native Cport scenarios DO NOT establish authenticated checksum/timer/hash/
HTTP/tar-group/installer proof. Two additional EXPLICITLY INJECTED fstat(scan)
and fdopendir refusals independently require no second scan acquisition/lost FD
before actual scan retirement. No injected failure is reported as a genuine OS
permission/disk event. Root invocation refuses unprivileged prerequisite; zero
skipped success. Parent qualification must clear child effective/ambient/inherited
capabilities and record actual UID/kernel/source/library hashes and FD closures.

All commands below are proposals UNRUN; use an exclusive parent slot and owned
temporary build/evidence roots, retaining direct stdout/stderr/status. Compiler
and native execution may need approved sandbox escalation for actual temporary
filesystem writes. Do not run alongside JS/native drift gates.

```sh
cc -std=c11 -Wall -Wextra -Werror -O2 candidate/archive_publication.c \
  controls/native_archive_publication.c -o <owned-build>/original11
cc -std=c11 -Wall -Wextra -Werror -O2 candidate/archive_publication.c \
  controls/native_archive_publication_revision2.c -Wl,--wrap=fstat \
  -Wl,--wrap=fdopendir -Wl,--wrap=openat -o <owned-build>/revision2-controls
bash candidate/tools/build/build-linux-native-output.sh \
  --source-directory <absolute-candidate> --output-directory <owned-empty-build>
luajit controls/native_clock_domain.lua <actual-generated-helper>
```

Required causal comparisons: exact predecessor getter+unchanged original11 must
fail state2 assertion; new controls against producer with ONLY scan debt guard
removed must fail acquired scan count/EBUSY witness; producer with ONLY output
identity/anchor guard removed must fail actual reused-FD refusal. No old assertion
is removed/weakened. Root must retain old/candidate/mutation results separately.
No real production source/consumer/installer or packaging acceptance may be
inferred from a port/unit green count.
