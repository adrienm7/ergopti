package.path='./?.lua;./?/init.lua;../_shared/lua/?.lua;../_shared/lua/?/init.lua;'..package.path
require('compat.utf8').install()
local Manifest=require('infra.manifest_reader')
local Transaction=require('config_scope_transaction')
local Fenced=require('config_scope_fenced_transaction')
local Preferences=require('infra.metrics_preferences')
local file,backup=os.tmpname(),os.tmpname();os.remove(backup)
local original='[gestures]\nenabled=true\nswipe_3_down="copy"\n[foreign]\nkeep=73\n'
local function read(path)
 local stream=io.open(path,'rb');if not stream then return nil,'absent' end
 local data=assert(stream:read('*a'));assert(stream:close());return data,'ok'
end
local function write(path,data)
 local stream=assert(io.open(path,'wb'));assert(stream:write(data));assert(stream:close())
end
local fs={read_with_status=read,write=write,write_if_unchanged=function(path,data,expected)
 local actual,status=read(path);if status~=expected.status or(status=='ok' and actual~=expected.content)then return false end
 write(path,data);return true
end}
write(file,original)
local runtime='original'
local tx=Transaction.new({path=file,backup_path=backup,manifest=Manifest,files=fs,
 capture=function()return{runtime=runtime}end,apply=function()runtime='candidate';return true end,
 restore=function(snapshot)runtime=snapshot.runtime;return true end})
local owner=Fenced.new({owner={},transaction=tx,scope='gestures',available=function()return true end,
 fences={{acquire=Preferences.acquire,release=Preferences.release}}})
local committed,detail=owner.apply('clear')
local observed={committed=committed,pending=owner.pending(),primary_pending=tx.pending(),native_admit=Preferences.admit(),runtime=runtime,source_original=read(file)==original,detail=detail}
print(require('json').encode(observed))
os.remove(file);os.remove(backup)
-- This separate fixture process retires its private in-memory preference owner.
assert(committed==true,'the actual existing pending-gated native release must admit a settled primary transaction')
