#include "guardian.h"
#include <string.h>

static void GG_Error(GG_Owner *o, uint32_t code) {
    if (o->first_error == 0u) o->first_error = code;
}

int GG_Init(GG_Owner *o, uintptr_t job, uintptr_t parent, uintptr_t stop,
            uintptr_t setup_process, GG_Content *contents, size_t count,
            GG_Port port) {
    size_t i;
    if (o == NULL || o->initialized != 0u) return 0;
    /* Own the donated capabilities before any validation can refuse. The
       caller retains original copies until this owner reports genuine READY. */
    o->initialized = 1u;
    o->job = job; o->parent = parent; o->stop = stop;
    o->setup_process = setup_process;
    o->contents = contents; o->count = count; o->port = port;
    o->phase = GG_CONSTRUCTION_DEBT;
    if (job == 0u || parent == 0u || stop == 0u || setup_process == 0u ||
        contents == NULL || count == 0u || count > SIZE_MAX / sizeof(*contents) ||
        port.validate_job == NULL || port.wait_parent == NULL ||
        port.wait_stop == NULL || port.query_members == NULL ||
        port.terminate_job == NULL || port.close_handle == NULL) {
        GG_Error(o, 1u);
        return 0;
    }
    for (i = 0; i < count; ++i) {
        if (contents[i].handle == 0u || contents[i].attempted != 0u ||
            contents[i].uncertain != 0u) {
            GG_Error(o, 1u);
            return 0;
        }
    }
    if (port.validate_job(port.context, setup_process, job) != 1) {
        GG_Error(o, 2u);
        return 0;
    }
    o->job_bound = 1u;
    /* A retained exited setup process reference can prevent job accounting
       reaching zero. This is its one close; refusal is never retried. */
    if (port.close_handle(port.context, setup_process) != 1) {
        GG_Error(o, 3u);
        return 0;
    }
    o->setup_process = 0u;
    o->phase = GG_READY;
    return 1;
}

static GG_Phase GG_Retire(GG_Owner *o) {
    size_t i;
    uint32_t uncertain = 0u;
    for (i = 0; i < o->count; ++i) {
        GG_Content *f = &o->contents[i];
        if (f->attempted != 0u) {
            if (f->uncertain != 0u) uncertain = 1u;
            continue;
        }
        f->attempted = 1u;
        if (o->port.close_handle(o->port.context, f->handle) == 1) {
            f->handle = 0u;
        } else {
            f->uncertain = 1u;
            uncertain = 1u;
            GG_Error(o, 8u);
        }
    }
    if (uncertain != 0u || o->setup_process != 0u) {
        o->phase = GG_CLOSE_DEBT;
        return o->phase;
    }
    if (o->port.close_handle(o->port.context, o->job) != 1) {
        GG_Error(o, 9u);
        o->phase = GG_CLOSE_DEBT;
        return o->phase;
    }
    o->job = 0u;
    if (o->port.close_handle(o->port.context, o->parent) != 1) {
        GG_Error(o, 9u);
        o->phase = GG_CLOSE_DEBT;
        return o->phase;
    }
    o->parent = 0u;
    if (o->port.close_handle(o->port.context, o->stop) != 1) {
        GG_Error(o, 9u);
        o->phase = GG_CLOSE_DEBT;
        return o->phase;
    }
    o->stop = 0u;
    o->phase = GG_RETIRED;
    return o->phase;
}

GG_Phase GG_Step(GG_Owner *o) {
    int parent, stop, queried;
    uint32_t members = UINT32_MAX;
    uint32_t requested = 0u;
    if (o == NULL || o->initialized == 0u) return GG_EMPTY;
    if (o->phase == GG_RETIRED || o->phase == GG_CLOSE_DEBT) return o->phase;
    if (o->job_bound == 0u) return GG_CONSTRUCTION_DEBT;
    parent = o->port.wait_parent(o->port.context, o->parent);
    stop = o->port.wait_stop(o->port.context, o->stop);
    if (parent == 1 || stop == 1) requested = 1u;
    if (parent != 0 && parent != 1) { GG_Error(o, 4u); requested = 1u; }
    if (stop != 0 && stop != 1) { GG_Error(o, 5u); requested = 1u; }
    queried = o->port.query_members(o->port.context, o->job, &members);
    if (queried == 1) {
        o->observed_members = members;
        if (members == 0u) {
            o->queried_zero = 1u;
            return GG_Retire(o);
        }
    } else {
        GG_Error(o, 6u);
        requested = 1u;
    }
    if (requested != 0u) {
        o->phase = GG_STOPPING;
        if (o->termination_attempted == 0u) {
            o->termination_attempted = 1u;
            if (o->port.terminate_job(o->port.context, o->job) != 1) GG_Error(o, 7u);
        }
    }
    return o->phase;
}
