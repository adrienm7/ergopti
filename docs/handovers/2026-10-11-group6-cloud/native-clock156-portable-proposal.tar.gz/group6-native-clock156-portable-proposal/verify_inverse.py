"""Finite source-only additive inverses; no tests or native qualification."""
from pathlib import Path
import ast
import hashlib
import json

BASE=Path(__file__).resolve().parent
CLOCK=BASE/'retained-clock-inputs'
C=BASE/'candidate'
P=BASE/'preimage'
manifest=json.loads((BASE/'composition-manifest.json').read_text())
for rel,pins in manifest['files'].items():
    assert hashlib.sha256((P/rel).read_bytes()).hexdigest()==pins['preimage']
    assert hashlib.sha256((C/rel).read_bytes()).hexdigest()==pins['candidate']
inv=json.loads((BASE/'enrollment-inverse.json').read_text())
rel='tools/test/macos_native_http_receiving_facts_test.py'
source=(C/rel).read_text()
assert source.count(inv['owning_addition']+inv['owning_anchor'])==1
assert source.replace(inv['owning_addition']+inv['owning_anchor'],inv['owning_anchor'],1)==(P/rel).read_text()
rel='tools/test/test-managed-ollama-protocol.cjs'
assert (C/rel).read_text().replace(inv['registry_after_entry'],inv['registry_before_entry'],1)==(P/rel).read_text()
rel='static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
source=(C/rel).read_text()
for kind in ('call','helper','imports'):
    anchor=inv['client'][kind+'_anchor'];addition=inv['client'][kind+'_addition']
    fragment=addition+anchor if kind=='helper' else anchor+addition
    assert source.count(fragment)==1
    source=source.replace(fragment,anchor,1)
assert source==(P/rel).read_text()
rel='static/ergopti_plus/macos/tests/support/native_http_fixture_main.swift'
native=json.loads((CLOCK/'exact-native-inverse.json').read_text())
source=(C/rel).read_text()
for kind in ('dispatch','role'):
    anchor=native[kind+'_anchor'];addition=native[kind+'_addition']
    fragment=anchor+addition if kind=='dispatch' else addition+anchor
    assert source.count(fragment)==1
    source=source.replace(fragment,anchor,1)
assert source==(P/rel).read_text()
inputs=json.loads((BASE/'unchanged-provider-inputs.json').read_text())['byte_exact_inputs']
for rel,expected in inputs.items():
    assert hashlib.sha256((C/rel).read_bytes()).hexdigest()==expected
helper=(C/'tools/test/macos_native_http_clock_contract_controls.py').read_text()
assert sum(isinstance(node,ast.FunctionDef) and node.name.startswith('test') for node in ast.walk(ast.parse(helper)))==13
print(json.dumps({'state':'SOURCE_ONLY_NO_TEST_NATIVE_CREDIT','whole_four_existing_path_inverse':True,'unchanged143_provider_files_exact':True,'new13_methods':13},sort_keys=True))
