# Private retained tar feeder source draft

SOURCE ONLY, unparsed/unimported/unexecuted. Root approved a scratch optional
stdin_owner bridge; root serializes its eventual rebase on other process owners.
The reviewed/qualified publication C7064/headerdc98 packet is unchanged.

The native_tar_feeder.part.lua is a lexical part of archive_output's fixed opaque
registry. It is not installed as an exported module and does not publish a
constructor receiving an integer, arbitrary C pointer or FD getter. Its captured
constructor receives the registry's previously admitted backend, including the
fixed C allocate_reader symbol. Only that registry invokes the returned closure:

`start(record, names|verbose|extract, work_dir, sealed_length,
 fresh_install_lineage, original_install_deadline, callback)`

Before invoking it the registry reserves its exact record/selection/installation
generation and records this in-flight owner, refusing another reader/install or
native cleanup. The committed artifact pointer and sealed byte length remain
private; they are never supplied by a menu/manager callback. Install admission
captures a separate cap180000 once; its absolute deadline is unchanged across all
three operations and final physical settlement. It never calls retired network
admission or checksum/archive/hash budgets. Current must independently bind the
same registry record, selected release and actual installer transaction.

Each operation privately allocates a fresh duplicate from the actual committed
inode and uses explicit parent read offsets. One bounded <=65536 read is followed
by one complete native pipe write callback before another read; a separate EOF
read proves the captured length, followed by native shutdown ACK. Feeder owns the
duplicate's actual fs_close ACK; supervisor exclusively owns raw stdin pipe close.
The C reader API and duplication metadata admission are unchanged.

OwnedProcess optional stdin_owner carries only the raw newly allocated pipe and
captured original receiver/methods cancel/is_settled/on_settled/can_close/result.
The supervisor captures ownership before native allocation/source callbacks,
includes worker retirement in settlement, closes the pipe only after worker
pending read/write/shutdown operations retire, and joins original exit/group
absence/output-pipe/process close receipts. It does not accept archive descriptors
or C publication pointers. Default operations have no stdin owner and preserve
their original behavior. The bridge requires actual userdata on production paths.

Final callback is an outcome after combined worker, original canonical timer and
supervisor physical ACK. Accepted start/cancel is never success/settlement. Result
stdout is private tar output for existing canonical layout/link policy checks;
it is not logged or exported as diagnostic evidence. Exceptions during native
submission may retain exact pending work; missing/ambiguous acquisition or close
acknowledgements remain honest debt. No displayed archive path is opened.

Commands are exact existing semantics with archive operand '-': tar -tzf -,
tar -tvzf -, tar -xzf - -C <owned-work> --no-same-owner --no-same-permissions.
The current canonical roots/traversal/link/mode checks, same-filesystem workdir,
version/build-stamp check, receipt preservation, candidate swap/smoke and rollback
remain owned by shared_failure62's asynchronous installer/caller adaptation.
This draft does not implement or qualify those joins.

Original process preimage343bd9fa and installer preimaged0a6935a are preserved.
All existing process tests must run unchanged against the final rebased source.
Native controls must run in an actual referenced libuv loop with original source
hashes, actual child/process group receipts and no stale-generation callback.
Revision1 remains preserved. Revision2 fixes post-current cancellation admission,
retains acquired raw pipe in the module-lifetime private ledger on partial handoff,
and protects every prospective native control acquisition with independent
cleanup/primary-error preservation. Files remain WIP pending refreshed bounded
review and actual qualification; no parser/import/model/native run executed.
