const assert=require('node:assert/strict');
const vm=require('node:vm');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const observations=[];
for(const host of ['windows','macos','linux'])for(const token of ['abcd','abc[BS]','[ab]','[BS]']){
 const page=loadMetricsTypingPage(host);
 const manifest={'2026-10-26':{'Editor.exe':{chars:28,time:1000}}};
 const initial={historical:{qg:{[token]:{c:7,t:0}}},today:{}};
 const blob={metrics_manifest:manifest,_prefetch_data:initial,app_icons:{},keycode_layout:{},driver_meta:{os:host,heatmap_id:'sc'}};
 if(host==='windows')page.messageListeners.filter(e=>e.name==='message').at(-1).callback({data:{type:'prefetch',blob}});
 else if(host==='macos')page.context.publishTypingMetricsData({manifest,initial_data:initial,app_icons:{},kc_layout:{}},{manifest_revision:1,assets_revision:1});
 else page.context.__hostBridgeResponse('metrics_typing_bridge',false,encodeURIComponent(JSON.stringify(blob)));
 vm.runInContext("app_state.current_tab='qg';",page.context);
 page.context.render_current_tab();page.timers.at(-1)();
 observations.push({host,token,actualTokenCount:page.context.count_key_tokens(token),projectedKeys:vm.runInContext('Object.keys(app_state.data.qg)',page.context),renderedCount:vm.runInContext('app_state.rendered_list.length',page.context),html:page.elements.get('metrics_table_body').innerHTML,errorCount:page.diagnostics.filter(e=>e.level==='error').length});
}
for(const observation of observations)console.log(JSON.stringify(observation));
for(const host of ['windows','macos','linux']) {
 assert.equal(observations.find(o=>o.host===host&&o.token==='abcd').renderedCount,1,'plain native four-character positive');
 assert.equal(observations.find(o=>o.host===host&&o.token==='abc[BS]').renderedCount,1,'native three characters and actual backspace positive');
}
assert.equal(observations.filter(o=>o.renderedCount===1&&o.errorCount===0).length,12,'every valid native four-token sequence must remain visible');
