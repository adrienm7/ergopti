// Outside-checkout behavioral receiving for the exact original/candidate loop.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { spawnSync } = require('node:child_process');
const loops = Object.fromEntries(
	['original', 'candidate'].map((role) => [
		role,
		fs.readFileSync(path.join(__dirname, `${role}-loop.cjs`), 'utf8')
	])
);
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'group6-passive-output-'));
const results = [];
let activePid = null;
function retired(pid) {
	if (!pid) return true;
	try {
		process.kill(pid, 0);
		return false;
	} catch (error) {
		assert.equal(error.code, 'ESRCH');
		return true;
	}
}
function observe(role, result, sinkFailure = false) {
	const writes = [];
	let caught = null;
	try {
		vm.runInNewContext(
			loops[role],
			{
				cases: [['receiver.cjs', 1]],
				assert,
				path,
				__dirname: path.join(root, 'tools/test'),
				pythonExecutable: () => process.execPath,
				spawnSync: () => result,
				process: {
					stdout: { write: (value) => writes.push({ stream: 'stdout', value }) },
					stderr: {
						write: (value) => {
							if (sinkFailure) throw new Error('diagnostic sink refused');
							writes.push({ stream: 'stderr', value });
						}
					}
				}
			},
			{ timeout: 1000 }
		);
	} catch (error) {
		caught = error;
	}
	return { writes, caught };
}
function child(code, missing = false) {
	fs.writeFileSync(path.join(root, 'receiver.cjs'), code);
	let options;
	let argv;
	let result;
	let caught = null;
	const writes = [];
	const started = process.hrtime.bigint();
	try {
		vm.runInNewContext(loops.candidate, {
			cases: [['receiver.cjs', 1]],
			assert,
			path,
			__dirname: path.join(root, 'tools/test'),
			pythonExecutable: () => (missing ? path.join(root, 'missing-executable') : process.execPath),
			spawnSync: (exe, args, opts) => {
				argv = Array.from(args);
				options = { ...opts };
				result = spawnSync(exe, args, opts);
				activePid = result.pid || null;
				return result;
			},
			process: {
				stdout: { write: (value) => writes.push({ stream: 'stdout', value }) },
				stderr: { write: (value) => writes.push({ stream: 'stderr', value }) }
			}
		});
	} catch (error) {
		caught = error;
	}
	assert.deepEqual(argv, ['receiver.cjs']);
	assert.deepEqual(options, { cwd: root, encoding: 'utf8', timeout: 60000 });
	assert.equal(retired(activePid), true, 'the real spawned child must already be reaped');
	activePid = null;
	return { result, caught, writes, elapsed_ms: Number(process.hrtime.bigint() - started) / 1e6 };
}
function guard(error) {
	return (
		error && {
			name: error.name,
			code: error.code,
			message: error.message,
			operator: error.operator,
			actual: error.actual,
			expected: error.expected
		}
	);
}
function diagnostic(writes) {
	assert.equal(writes.length, 1);
	assert.equal(writes[0].stream, 'stderr');
	assert.match(writes[0].value, /^PORTABLE_RECEIVER_FAILURE /);
	const fact = JSON.parse(writes[0].value.slice('PORTABLE_RECEIVER_FAILURE '.length));
	assert.equal(fact.script, 'receiver.cjs');
	assert.equal(fact.native_qualified, false);
	return fact;
}
function control(name, code, expected, missing = false) {
	const actual = child(code, missing);
	const before = observe('original', actual.result);
	assert.deepEqual(
		guard(actual.caught),
		guard(before.caught),
		'every original guard outcome must remain exact'
	);
	if (expected === 'success') {
		assert.equal(actual.caught, null);
		assert.deepEqual(actual.writes, before.writes);
		assert.deepEqual(actual.writes, [
			{ stream: 'stdout', value: actual.result.stdout },
			{ stream: 'stdout', value: actual.result.stderr }
		]);
	} else {
		assert.equal(actual.caught.code, 'ERR_ASSERTION');
		assert.equal(
			before.writes.length,
			0,
			'original loop must demonstrably lose captured failure output'
		);
		const fact = diagnostic(actual.writes);
		assert.equal(fact.status, actual.result.status);
		assert.equal(fact.signal, actual.result.signal);
		assert.equal(fact.error_code, actual.result.error?.code || null);
		assert.equal(fact.stdout_tail, actual.result.stdout?.slice(-8192) || '');
		assert.equal(fact.stderr_tail, actual.result.stderr?.slice(-8192) || '');
		const refusedSink = observe('candidate', actual.result, true);
		assert.deepEqual(
			guard(refusedSink.caught),
			guard(actual.caught),
			'optional diagnostic refusal must preserve the original primary assertion'
		);
	}
	if (expected === 'timeout') {
		assert.equal(actual.result.error.code, 'ETIMEDOUT');
		assert.equal(actual.result.signal, 'SIGTERM');
		assert.match(actual.result.stdout, /TIMEOUT_STDOUT/);
		assert.match(actual.result.stderr, /TIMEOUT_STDERR/);
	} else if (expected === 'ENOENT') assert.equal(actual.result.error.code, 'ENOENT');
	else if (expected === 'signal') assert.equal(actual.result.signal, 'SIGTERM');
	else if (expected === 'nonzero') assert.equal(actual.result.status, 7);
	else if (expected === 'bounded') {
		const fact = diagnostic(actual.writes);
		assert.equal(fact.stdout_tail.length, 8192);
		assert.equal(fact.stderr_tail.length, 8192);
		assert.ok(fact.stdout_tail.endsWith('LAST_STDOUT'));
		assert.ok(fact.stderr_tail.endsWith('LAST_STDERR'));
		assert.ok(!fact.stdout_tail.includes('FIRST_STDOUT'));
		assert.ok(!fact.stderr_tail.includes('FIRST_STDERR'));
	}
	const record = {
		name,
		passed: true,
		elapsed_ms: actual.elapsed_ms,
		pid: actual.result.pid || null,
		reaped: true,
		status: actual.result.status,
		signal: actual.result.signal,
		error_code: actual.result.error?.code || null,
		original_guard_preserved: true,
		original_loses_failure_output: expected !== 'success',
		sink_refusal_preserves_primary: expected !== 'success',
		output_emitted_before_primary: expected !== 'success'
	};
	results.push(record);
	fs.writeFileSync(
		path.join(__dirname, 'behavior-receiving.json'),
		JSON.stringify(
			{ node: process.version, executable: process.execPath, controls: results, native: false },
			null,
			2
		) + '\n'
	);
	console.log(`PASS ${name} ${record.elapsed_ms.toFixed(1)}ms`);
}
try {
	control(
		'success argv/options/output remain exact',
		"process.stdout.write('SUCCESS_STDOUT'); process.stderr.write('Ran 1 test in 0.001s\\nOK\\n');",
		'success'
	);
	control(
		'real nonzero child output precedes unchanged refusal',
		"process.stdout.write('FAILED_STDOUT'); process.stderr.write('FAILED_STDERR'); process.exit(7);",
		'nonzero'
	);
	control(
		'real terminated child output precedes unchanged retirement refusal',
		"process.stdout.write('SIGNAL_STDOUT'); process.stderr.write('SIGNAL_STDERR'); process.kill(process.pid, 'SIGTERM');",
		'signal'
	);
	control('genuine missing executable preserves admission refusal', '', 'ENOENT', true);
	control(
		'failure output tails are finite and retain last bytes',
		"process.stdout.write('FIRST_STDOUT' + 'O'.repeat(12000) + 'LAST_STDOUT'); process.stderr.write('FIRST_STDERR' + 'E'.repeat(12000) + 'LAST_STDERR'); process.exit(8);",
		'bounded'
	);
	control(
		'genuine original 60000ms spawn timeout retains captured output',
		"process.stdout.write('TIMEOUT_STDOUT'); process.stderr.write('TIMEOUT_STDERR'); setInterval(() => {}, 1000);",
		'timeout'
	);
} finally {
	if (activePid && !retired(activePid)) {
		process.kill(activePid, 'SIGKILL');
		throw new Error('unexpected unretired child; root retained');
	}
	fs.rmSync(root, { recursive: true });
}
