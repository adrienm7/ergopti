# Current Dev merged-source qualification

The no-ff feature checkpoint c3a49a115c21d98d05626d847ad3e416ca77987a has parents c23982e1cc1e3a0e350dc05ce9e9eea2bf7a0456 and actual Dev da74809cd1bfae395ebb0e402bcf3c130a286cab. Its tree 53d02a1d79d10ebf05c72548759fdd42cff8ffd6 equals the index tested by verify-change. All110 before/after source hashes, HEAD and logical index agree; temporary drift-guard mutations may occur and are restored. This is a before/after fence, not continuous immutability.

The six gates run serially: format388, registered JS413, virtual Hammerspoon E2E101 PASS/one explicit host or driver scenario SKIP, Lua unit18609 PASS/zero FAIL, Linux E2E193 PASS, Linux unit13268 PASS/zero FAIL. Terminal verify-change exit0 in1554.954s. Original log6322353B/SHA256f41ae1912e2c8814d20f0a1c320df51f469793924c2a5bd0ba4dff8912b4feaa is retained as exact decompressed gzip bytes. No simultaneous JS/native suite was launched in this checkout.

Linux has no DISPLAY/WAYLAND session or physical input device authorization; virtual and stub Lua/E2E checks do not prove native Hammerspoon, X11, Wayland or physical input. Actual original23, full Windows unit/E2E/packaging/install, Darwin system trust, Brew six scenarios and installed release acceptance remain incomplete. The separate Group3 official manual38176924058 tested da748, is terminal FAILURE and does not qualify this feature SHA. No official CI ref/lease/manual/main release was modified.

The feature push is exact, with four all-event exact-SHA automatic censuses finding zero runs. No Dev integration or TODO closure is claimed. Items36/62 and transversal16/38 remain open;22 stays withdrawn. This historical tree receiving remains distinct from later documentation-only checkpoints.
