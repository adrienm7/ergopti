from pathlib import Path
import subprocess,os,json,datetime
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-combined34-hs')
with(O/'producer.log').open('wb')as out:
 p=subprocess.Popen(['python3',str(O/'run.py')],stdout=out,stderr=subprocess.STDOUT)
 (O/'producer.json').write_text(json.dumps({'wrapper_pid':os.getpid(),'producer_pid':p.pid})+'\n')
 rc=p.wait()
(O/'tool-exit.json').write_text(json.dumps({'actual_child_wait_exit':rc,'finished_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()})+'\n')
