# Portable Windows pair arbitration component

PRIVATE proposal: three new, isolated source files under
`windows/native/key_combination_owner/`. No canonical file, index, builder,
DLL, manifest, runner, workflow or capability was changed. The earlier two-path
AHK assignment repair remains independently frozen in its separate packet.

The existing shared `tap_hold/key_combinations.lua` owns pair identifiers,
catalogue order, None, symmetry and positive delay configuration. This component
contains no production key/action IDs, config parser, defaults or translated
labels. A future shared-policy adapter supplies immutable directional rows,
their canonical row index and opaque pair/action references. Test IDs are a
literal three-row miniature, independently authored in C.

## Actual implementation

`ErgoptiPair_Initialize` copies and validates a bounded supplied policy exactly
once. `ErgoptiPair_Reduce` computes a detached next-state and plan without
mutating the prior state. It has no callbacks, allocator, I/O, hook, timer,
physical state query, injection, release, native ACK or ACK factory.

- An eligible genuine first-down starts a bounded wait with exact original
  key/source/generation/press/time facts. Unknown, injected and AltGr synthetic
  Ctrl origins never start or complete a pair. Raw provenance is supplied by
  the real owner; this module does not infer it from RAlt or GetKeyState.
- The inclusive positive delay admits a second down at the exact boundary.
  A clock at the boundary leaves the first undecided; strictly later resolves
  it as held alone. Integer native milliseconds do not round a fractional
  positive threshold upward; subtraction avoids deadline overflow.
- Symmetry chooses the already supplied canonical row while preserving actual
  event order. A canonical None stays None even when the reverse row has an
  action. Empty/unknown choices preserve the original route.
- Fallback releases the original first down plan before the current original
  edge, retaining its original timestamp and complete identity. Once resolved
  alone, a later join cannot become a simultaneous pair. Early repeat or Up
  follows the same ordered fallback. A joined chord emits its action once and
  retains matching repeats/Ups through either release order.
- Source generation replacement, context/policy/route withdrawal, pause,
  cancellation, backwards time, changed origin or conflicting press identity
  requests native retirement. Conflicting identities on an already retained
  physical slot stay retained for the real host to resolve; they do not supply
  a new pair or leak an orphan Up. Retirement remains latched and preserves
  all still-retained original down identities. No input clears it or fabricates
  successful retirement.

## Required host bridge

This is useful compiled planning code, not a Windows feature claim. A sole
actual hook/RawInput owner must establish event provenance, source generation,
press identity, monotonic time, live route/config custody and original first
availability. It must obtain pair rows/action bindings from the existing shared
policy, rejoin the original action/output owner and independently admit every
plan before actual suppression/replay or action invocation. On fallback it
routes the first down at its retained original time through the existing ordered
tap/hold owner, advances that owner to the current input/clock time, then routes
the current edge. Replaying a new down at the later clock would restart the
standalone hold threshold and would not implement this contract. It may commit a
logical proposal only with its own genuine accepted transition. Failed effects
must retain actual cleanup debt; logical states are not receipts.

A retiring state has no resume/clear operation here. The native owner keeps it
and the real resources until its existing native retirement protocol succeeds;
only then may a separately initialized fresh logical generation be used. The
core never acknowledges an input/modifier/output release, native child exit or
hook join. Its public facts and IDs confer no physical/source/output authority.

Cloud247 owns the live navigation DLL and current native recipes; Root owns
builder/CI enrollment. This private proposal does not touch or regenerate either.
The genuine raw-event and existing hook/action bridge, AHK integration, Windows
MSVC compilation, registration, native desktop/AltGr, package, install and
physical validation remain absent or NOT_RUN. Simultaneous menus stay disabled.

## Actual local verification

GCC 14.2.0, `-std=c11 -Wall -Wextra -Wpedantic -Werror -O2`: compile PASS,
15 named test functions and 640 handwritten assertion checks PASS, exit 0.
The same unchanged cases pass 640/0 with AddressSanitizer and
UndefinedBehaviorSanitizer (`-O1 -g -fsanitize=address,undefined
-fno-omit-frame-pointer`), exit 0, empty stderr.

Nine isolated product omissions all compile and fail the unchanged handwritten
expectations with exit 1: exclusive deadline, ignored symmetry, accepted
unproven origin, ignored context, lost original timestamp, resurrected retired
state, cross-source chord, discarded retirement debt and source-generation
fallback. Test expectations were not generated from reducer output. Exact
commands, outputs, source digests and failing assertions are retained in
`final-receiving.json`; binaries and logs remain in its unique owned `/tmp`
directory. These are Linux executions of pure portable C, not Windows/native
input execution. No whole JS suite or native actor was launched.
