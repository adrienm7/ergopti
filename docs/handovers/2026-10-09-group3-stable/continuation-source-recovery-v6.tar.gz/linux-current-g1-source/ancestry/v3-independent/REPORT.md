# Independent source review: Linux public93 additive V3

Verdict: **SOURCE_CLEAR_PRIVATE_ORDERED_SOURCE_ONLY**. Apply only after the reviewed runtime and public V1+V2 chain, against the seven exact preimages from Git tree `92d6a358adac6bae4fd4c698bbbbe3c377d889ef`. V1 alone retains its immutable HOLD. This is an inactive preparation; this review did not integrate code or enable native capability.

The original complete gate recorded four JS failures and Linux units 12563 PASS/1 FAIL. The original Manager assertion at line344 exposed the actual captured-loader boundary defect: reload could run captured original functions after their live original exports had been replaced. V3 refuses the exact original module/ports at entry, after decoding, and after construction callbacks. It retains captured ports for execution and publishes all four running tuple members only after the checks. Existing native teardown/installation and private Manager option issuance remain unchanged.

## Independently executed controls

Both actual LuaJIT and Lua5.4, in a separate sparse Git-object projection:

| Cohort | PASS | FAIL | Exit |
|---|---:|---:|---:|
| Candidate Manager |37|0|0|
| Candidate original runtime |216|0|0|
| Candidate local scope |81|0|0|
| Candidate global scope |27|0|0|
| Candidate original menu/locales |8|0|0|
| Exact old Manager with final tests |33|4|1|
| Entry fences omitted |35|2|1|
| Final construction fences omitted |36|1|1|
| Six independent read/construction revocation probes |6|0|0|
| Same probes on old Manager |0|6|1|
| Same probes without post-read fences |2|4|1|
| Same probes without final construction fences |4|2|1|

The additional probes use the original parser and final original Logger callback, for both reload and candidate apply. They assert actual callback execution, no foreign loader invocation, exact original loaded/one_shot/engine/combinations identities, unchanged Hook engine/call count, and no construction callback after read refusal. Restoring the mutated export during construction makes omission of the post-read fence specifically causal: the candidate rejects before that callback, whereas the omission publishes and fails the refusal assertion. An unobserved transient mutation that restores itself before every sampled boundary remains outside this source observation contract.

Four complete unchanged JS guards execute their genuine main entrypoints: menu-first-group PASS10 menus/29 projections; restrictions PASS101/104 (148 actual restrictions); feature parity PASS364 classified/182 supported, zero software gaps; false-green scan PASS0/0. Each exact Git92 old input independently reproduces its original failure: missing separator, unexplained mod_combos restriction, two unsupported software-evidence claims, and the pcall-only rejection. All four candidate guards were replayed once to preserve separate original/candidate dependency pins. No guard, budget, baseline or original expected corpus was edited.

Two reviewer harness attempts used a nonexistent global module name and exited before tests. Their raw logs remain retained and are not product failures or expected inverse controls. The corrected genuine `tests.unit.infra.test_global_shortcuts_pair_scope` ran27/0 on each ABI. The author's earlier mutable Lua5.4 entry omission had two extra original failures; this historical observation is retained without a fabricated source cause. Frozen author replay and independent same-byte replay both observed35/2 on both ABIs; no assertion was changed to obtain that result.

## Preservation and ownership

All107 frozen V3 seals, all seven actual Git preimages, safe fourteen-member regular-file source archive and four private forward/inverse patch operations verify. The complete35686-byte original Manager test prefix is byte-exact: all34 original cases precede three additions. The original shared-copy call and false result assertion remain, strengthened with a string type and exact existing refusal diagnostic. No production shared copy behavior changes.

Manifest changes are exactly the existing Linux separator and the existing translated per-driver reason for mod_combos. All21 reason values identify Linux's own daemon tap-hold engine; only Czech and Polish change exactly that one existing leaf. Every other locale byte remains exact. The evidence JSON adds exactly two typed settings under a software unit proof, explicitly hardware_proven=no; all existing evidence remains structurally identical. Producer, menu, persistence and scope source paths referenced by that proof are present in the pinned graph.

The five prior/current seal sets remain exact: publicV1 425, publicV2 168, independentV1 HOLD32, independentV2 SOURCE_CLEAR132, currentV3 107. Sparse dependencies come from immutable Git92 objects; generated feature/menu outputs are frozen private reference outputs, not reviewed generated-source admission. Regeneration through original owners is still required. The schema, builders, workflows and architecture generators are unchanged by this seven-path patch.

G1 retains shared source custody: cs/pl string custody was explicitly granted, while manifest/evidence adoption is conditional on G1's31-path publication and current preimage reconciliation. This review is not an ownership override. Root must run final complete selected gates on the final ordered, regenerated sources.

## Limits

No kernel uinput, physical receiving application/Xorg/Wayland, real native source transaction, packaging, installation or cross-platform native CI executed here. Controlled FFI transports and Hook doubles prove bounded software behavior only. The original third-slot Program/window/CapsWord/OneShot restrictions, master-state semantics and copy transaction scope remain as reviewed in V2. No full TODO93 completion, no TODO removal and no permission/grant claims follow from this verdict. All13 Group3 items remain partial;16/38 retained;22 excluded.

The reviewer wrote only its own private evidence/projections. Canonical/index/refs/workflows and Root's active projection were not mutated by the reviewer. Root may change canonical concurrently, so this report does not claim the whole workspace stayed unchanged.
