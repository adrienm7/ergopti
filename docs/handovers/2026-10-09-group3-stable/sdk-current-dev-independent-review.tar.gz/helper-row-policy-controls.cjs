'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const candidate='/workspace/.ergopti-cloud/preparations/shortcuts-sdk-current-dev-forward/candidate';
const filename=path.join(candidate,'tools/test/ci-full-default.cjs');
const source=fs.readFileSync(filename,'utf8');
const row="\t[MAC, 'item36-native', 'Observe the actual no-prompt SDK permission API independently', 7, 8],\n";
assert.equal(source.split(row).length,2);
function load(text){const m=new Module(filename);m.filename=filename;m.paths=Module._nodeModulePaths(path.dirname(filename));m._compile(text,filename);return m.exports;}
const full=load(source),raw=require(path.join(candidate,'tools/test/ci-pipeline.cjs'));
const name='Observe the actual no-prompt SDK permission API independently',rel='.github/workflows/ci-macos.yml';
const rawstep=raw.step(raw.job('item36-native'),name),fullstep=full.step(full.job('item36-native'),name);
assert.equal(raw.stepField(rawstep,'if'),'${{ !inputs.fast_prerelease && (!cancelled()) }}');
assert.equal(full.stepField(fullstep,'if'),'${{ !cancelled() }}');
assert.equal(raw.stepField(rawstep,'run'),full.stepField(fullstep,'run'));
const results=[{case:'exact raw/full view preserves runtime run body',status:'PASS'}];
for(const [label,changed] of [['missing indispensable row',''],['wrong owner job',row.replace('item36-native','package-macos')],['wrong exact step',row.replace('independently','unowned')],['wrong raw predicate index',row.replace('7, 8','4, 8')],['swapped predicate indices',row.replace('7, 8','8, 7')],['duplicate row',row+row]]){
 let error;try{load(source.replace(row,changed));}catch(e){error=e;}
 assert.ok(error,label);assert.match(error.message,/ci-full-default/);results.push({case:label,status:'CAUSAL_REFUSAL',message:error.message});
}
const condition=raw.stepField(rawstep,'if'),head='      - name: '+name+'\n';
for(const changed of ['${{ !cancelled() }}','${{ !inputs.fast_prerelease || !cancelled() }}','${{ !inputs.fast_prerelease && false }}','${{ !inputs.fast_prerelease && always() }}']){
 const files=raw.files().map(f=>f.rel===rel?{...f,text:f.text.replace(head+'        if: '+condition+'\n',head+'        if: '+changed+'\n')}:{...f});
 assert.throws(()=>full.fromFiles(files));results.push({case:'wrong raw wrapper '+changed,status:'CAUSAL_REFUSAL'});
}
fs.writeFileSync(path.join(__dirname,'helper-row-policy-controls.json'),JSON.stringify({source_controls:results,source_only:true,native_executed:false},null,2)+'\n');console.log('PASS: exact raw/full body; six helper-row and four raw-policy causal refusals; native UNRUN.');
