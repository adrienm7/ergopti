# Post-seal conflict-count correction

The immutable original source receipt contains one metadata count error: its
“three other conflict paths” must read “two other conflict paths”. The captured
preview has 25 unique stage-1 conflict paths: 23 reviewed source paths, the macOS
workflow and the pipeline-wiring guard. The original 120-subject packet is
unchanged. This correction does not change any source verdict or postimage.

Current Dev e896bd3ee047eb4795b0bd13c2ac715d626042ea preserves all 23 captured
source preimages and all eight recorded generated artifact snapshots from Dev
9652. Nineteen of twenty generator input blobs are identical; package.json adds
only G6’s genuine default-CI guard registration. The four relevant owner commands
remain exact. No generator or suite is executed by this source revalidation.
