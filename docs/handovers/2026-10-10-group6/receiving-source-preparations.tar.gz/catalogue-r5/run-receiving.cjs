// Private serial receiving; the original physical phase owner remains sole owner.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const packet = __dirname;
const root = '/workspace/ergopti';
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const bindings = JSON.parse(fs.readFileSync(path.join(packet, 'SOURCE-BINDINGS.json')));
const sourceFiles = ['receiving_launcher.py', 'run-receiving.cjs', 'candidate/tools/test/macos_managed_ollama_catalogue_refusal_test.py'];
const ownFiles = bindings.originals.filter(row => row.path.startsWith('tools/'));
const pinned = new Map(sourceFiles.map(name => [path.join(packet,name), sha(path.join(packet,name))]));
for (const row of ownFiles) pinned.set(path.join(packet,'owner',row.path),row.sha256);
for (const variant of ['before','after']) {
  const base = path.join(packet,'cohorts',variant);
  for (const row of bindings.originals.filter(row=>row.path.startsWith('static/'))) {
    const expected = variant==='after' && row.path.endsWith('/modules/llm/managed_ollama_runtime.py')
      && row.path.includes('/macos/') ? 'a913d36ac05f31d6b8b8158c8f40c320b2804ed303677cf662009e741ef176e6' : row.sha256;
    pinned.set(path.join(base,row.path),expected);
  }
  pinned.set(path.join(base,'tools/test/macos_managed_ollama_catalogue_refusal_test.py'),sha(path.join(packet,sourceFiles[2])));
}
function refence() {
  for (const row of bindings.originals) if (sha(path.join(root,row.path)) !== row.sha256) throw Error('original source changed');
  for (const [file,digest] of pinned) if (!fs.lstatSync(file).isFile() || fs.lstatSync(file).isSymbolicLink() || sha(file)!==digest) throw Error('private source changed');
}
refence();
const owner = require(path.join(packet,'owner/tools/test/run-linux-managed-http-native.cjs'));
refence();
const work = fs.mkdtempSync('/tmp/group6-catalogue-receiving-');
const deadline = process.hrtime.bigint()+120000000000n;
let cancelled = false;
const cancel = () => { cancelled=true; owner.requestActiveCancellation(); };
process.on('SIGTERM',cancel); process.on('SIGINT',cancel);
(async()=>{
  const results=[];
  for (const [variant, expected] of [['before', {pass:7,fail:5,status:1}],['after',{pass:12,fail:0,status:0}]]) {
    refence();
    if (cancelled || process.hrtime.bigint()>=deadline) throw Error('private receiving deadline');
    const cohort=path.join(packet,'cohorts',variant);
    const result=await owner.ownPhase({command:'python3',args:['-B',path.join(packet,'receiving_launcher.py'),path.join(cohort,'tools/test/macos_managed_ollama_catalogue_refusal_test.py'),path.join(work,variant+'.json')],
      env:{...process.env,TMPDIR:'/tmp',PYTHONDONTWRITEBYTECODE:'1'},cwd:cohort,work,label:variant,
      worker:path.join(packet,'owner/tools/test/run-linux-managed-http-phase.py'),owner:path.join(packet,'owner/tools/build/stage-linux-network-runtime.py'),
      ownerSha:'ac48a4e9755fb2b9e9cbe35c81b097942bf7be76d14466e03b891b4c78f302f5',kind:'command',budgetMs:30000,gateDeadline:deadline});
    refence();
    const closed=JSON.parse(fs.readFileSync(path.join(work,variant+'.owner/closed.json')));
    const summary=JSON.parse(fs.readFileSync(path.join(work,variant+'.json')));
    const ok=result.status===expected.status && result.signal===null && result.error===null && !owner.hasRetainedPhases() && !cancelled && !closed.cancelled
      && owner.phaseReceipt(closed,closed.pid,'command',expected.status) && summary.total===12 && summary.pass===expected.pass && summary.fail===expected.fail && summary.errors===0 && summary.skip===0;
    results.push({variant,ok,status:result.status,signal:result.signal,error:result.error,retained:owner.hasRetainedPhases(),closed,summary});
    fs.writeFileSync(path.join(work,'RESULTS.json'),JSON.stringify({work,results,native_macos_credit:false},null,2)+'\n');
    console.log(JSON.stringify({variant,ok,status:result.status,pass:summary.pass,fail:summary.fail,errors:summary.errors,skip:summary.skip,retained:owner.hasRetainedPhases()}));
    if (!ok) throw Error('focused receiving refusal');
  }
  refence();
  if (cancelled || process.hrtime.bigint()>=deadline || owner.hasRetainedPhases()) throw Error('private final admission');
  console.log('RESULT_DIRECTORY='+work);
})().catch(error=>{console.error('FOCUSED_RECEIVING_REFUSED work='+work);process.exitCode=1;}).finally(()=>{
  if (!owner.hasRetainedPhases()) {process.removeListener('SIGTERM',cancel);process.removeListener('SIGINT',cancel);}
});
