'use strict';
// Private, bounded source preservation and consumer qualification. No native result is inferred.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const parser = require('/workspace/ergopti/node_modules/@babel/parser');
const packet = __dirname, projection = path.join(packet, 'projection'), preimage = path.join(packet, 'preimage');
const tests = 'static/ergopti_plus/windows/tests/';
const read = (base, file) => fs.readFileSync(path.join(base, file), 'utf8');
const image = file => read(projection, file);
const source = require(path.join(projection, 'tools/lib/script-source.cjs'));
const owners = require(path.join(projection, 'tools/lib/ahk-runner-source.cjs'));
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const results = [];
function check(name, fn) { fn(); results.push({ name, status: 'PASS' }); }
const tokens = text => source.scriptTokens(text, '.ahk').map(t => [t.kind, t.value]);
const alpha = JSON.parse(fs.readFileSync(path.join(packet, 'alpha-renames.json')));
function reverseAlpha(text, row) {
  const owned = owners.runnerFunctionTokens(text, row.fn).filter(t => t.kind === 'identifier' && t.value === row.newName);
  assert.equal(owned.length, row.replacements, row.fn);
  for (const token of owned.reverse()) text = text.slice(0, token.start) + row.oldName + text.slice(token.end);
  return text;
}
const originalLoop = 'for Assigned in [false, true]\n\tTest("key combinations: shared clear availability assigned=" . Assigned . " (key-combination-pair-menu)",\n\t\t_KCT_PairClearAvailability.Bind(Assigned))';
const wrappedLoop = '_KCT_RegisterPairClearAvailabilityCases() {\n' + originalLoop.split('\n').map(line => '\t' + line).join('\n') + '\n}\n_KCT_RegisterPairClearAvailabilityCases()';
check('expanded ordinary runner preserves every original code token and execution order', () => {
  assert.deepEqual(tokens(owners.sharedRunnerSource(image, 'run_all.ahk')), tokens(read(preimage, tests + 'run_all.ahk')));
});
for (const row of alpha) check('exact inverse scoped alpha: ' + row.fn, () => {
  let restored = reverseAlpha(image(row.file), row);
  if (row.file.endsWith('test_key_combinations.ahk')) {
    assert.equal(restored.split(wrappedLoop).length, 2);
    restored = restored.replace(wrappedLoop, originalLoop);
  }
  assert.equal(restored, read(preimage, row.file));
});
check('original watchdog meta assertions remain with only two source-owner path updates', () => {
  const file = tests + 'meta/test_suite_watchdog_manifest.ahk';
  const candidate = image(file);
  assert.equal(candidate.split('"\\runner_completion.ahk"').length, 3);
  assert.equal(candidate.replaceAll('"\\runner_completion.ahk"', '"\\run_all.ahk"'), read(preimage, file));
});
check('strict collector source is byte-exact except native entry path and missing-entry message', () => {
  const file = 'tools/test/run-windows-native-desktop.ps1';
  const original = read(preimage, file), candidate = image(file);
  assert.equal(candidate.replace('windows\\tests\\run_native_desktop.ahk', 'windows\\tests\\run_all.ahk')
    .replace("throw 'Native desktop test runner not found.'", "throw 'Canonical test runner not found.'"), original);
  const fragment = fs.readFileSync('/workspace/.ergopti-cloud/preparations/windows-native-desktop-entry-feasibility-v1/Assert-DesktopNativeManifest.original.fragment.ps1', 'utf8');
  assert.ok(candidate.includes(fragment));
});
function clean(node) {
  if (Array.isArray(node)) return node.map(clean);
  if (!node || typeof node !== 'object') return node;
  return Object.fromEntries(Object.entries(node).filter(([key]) => !['start', 'end', 'loc', 'extra', 'leadingComments', 'trailingComments', 'innerComments', 'comments', 'tokens'].includes(key)).map(([key, value]) => [key, clean(value)]));
}
const ast = text => clean(parser.parse(text, { sourceType: 'script' }).program);
check('original native desktop JS module AST recovered by peeling only additive controls', () => {
  const file = 'tools/test/test-windows-native-desktop.cjs';
  const old = ast(read(preimage, file)), now = ast(image(file));
  const runner = now.body.find(n => n.type === 'FunctionDeclaration' && n.id.name === 'checkRunner');
  assert.equal(runner.body.body.pop().expression.arguments[1].pattern, 'windows\\\\tests\\\\run_native_desktop\\.ahk');
  const restored = []; let index = 0;
  const matchedIndices = [];
  for (const original of old.body) {
    while (index < now.body.length && JSON.stringify(now.body[index]) !== JSON.stringify(original)) index++;
    assert.ok(index < now.body.length, 'an original AST statement disappeared or changed: ' + original.type);
    restored.push(now.body[index]); matchedIndices.push(index++);
  }
  assert.deepEqual({ ...now, body: restored }, old);
  fs.writeFileSync(path.join(packet, 'native-guard-ast-preservation.json'), JSON.stringify({ originalNodes: old.body.length, candidateNodes: now.body.length, matchedIndices, removedOriginalNodes: 0, alteredOriginalNodes: 0, soleAppendedRunnerAssertion: true }, null, 2) + '\n');
});
check('original argument JS whole-module AST recovered after exact shared-reader seam reversal', () => {
  const file = 'tools/test/test-ahk-runner-arguments.cjs';
  const old = ast(read(preimage, file)), now = ast(image(file));
  now.body = now.body.filter(n => !(n.type === 'VariableDeclaration' && n.declarations[0].id.type === 'ObjectPattern' && n.declarations[0].id.properties[0].key.name === 'runnerPrelude'));
  const index = now.body.findIndex(n => n.type === 'VariableDeclaration' && n.declarations[0].id.name === 'entry');
  now.body[index] = old.body.find(n => n.type === 'VariableDeclaration' && n.declarations[0].id.name === 'entry');
  assert.deepEqual(now, old);
});
check('28 original runtime sources and four original child inputs retain exact images modulo approved scoped changes', () => {
  const closure = JSON.parse(fs.readFileSync('/workspace/.ergopti-cloud/preparations/windows-native-desktop-entry-feasibility-v1/closure.json'));
  const children = JSON.parse(fs.readFileSync('/workspace/.ergopti-cloud/preparations/windows-native-desktop-entry-feasibility-v1/native-child-inputs.json'));
  for (const row of [...closure.files, ...children]) {
    assert.equal(hash(fs.readFileSync(path.join(preimage, row.file))), row.sha256);
    if (!alpha.some(a => a.file === row.file)) assert.equal(image(row.file), read(preimage, row.file), row.file);
  }
  assert.equal(closure.files.length, 28); assert.equal(children.length, 4);
  assert.equal(owners.nativeSourceClosure(image).size, 32);
});
check('eleven actual original selected registrations and callback bodies remain token-identical', () => {
  const census = JSON.parse(fs.readFileSync('/workspace/.ergopti-cloud/preparations/windows-native-desktop-entry-feasibility-v1/exact-case-census.json'));
  const observed = [];
  for (const relative of ['unit/test_console_window.ahk', 'unit/test_key_combinations.ahk']) {
    const file = tests + relative, original = read(preimage, file), candidate = image(file);
    const pattern = /Test\("([^"\n]*(?:native-console-capture|todo91-altgr-suffix)[^"\n]*)",\s*(?:\(\)\s*=>\s*)?([A-Za-z_][A-Za-z_0-9]*)/g;
    for (const match of source.stripComments(original, '.ahk').matchAll(pattern)) {
      const [registration, name, callback] = match;
      assert.ok(source.stripComments(candidate, '.ahk').includes(registration));
      const before = owners.runnerFunctionTokens(original, callback).map(t => [t.kind, t.value]);
      const after = owners.runnerFunctionTokens(candidate, callback).map(t => [t.kind, t.value]);
      assert.deepEqual(after, before, callback);
      observed.push({name, callback, file, functionTokens: before.length});
    }
  }
  assert.deepEqual(observed.map(row => row.name), census.names);
  assert.equal(observed.length, 11);
  fs.writeFileSync(path.join(packet, 'selected-case-preservation.json'), JSON.stringify(observed, null, 2) + '\n');
});

const file = 'tools/test/test-windows-native-desktop.cjs';
const guard = image(file), prefix = guard.slice(0, guard.indexOf('\ncheckNativeSources(readRunnerImage);'));
const requireGuard = createRequire(path.join(projection, file));
const expose = text => new Function('require', '__dirname', text + '\nreturn {checkNativeSources, checkNativeLocalNamespaces};')(requireGuard, path.join(projection, 'tools/test'));
const consumer = expose(prefix);
check('actual consumer accepts complete candidate sources', () => consumer.checkNativeSources(image));
check('original runner source is causally refused by the new shared admission consumer', () => assert.throws(() => consumer.checkNativeSources(target => target === tests + 'run_all.ahk' ? read(preimage, target) : image(target)), /shared prelude/));
for (const row of alpha) check('complete old local binding causally refused: ' + row.fn, () => {
  const restored = reverseAlpha(image(row.file), row);
  assert.throws(() => consumer.checkNativeSources(target => target === row.file ? restored : image(target)), { name: 'AssertionError' });
});
check('complete original registration loop is refused while original Bind and case expressions stay exact', () => {
  const file = tests + 'unit/test_key_combinations.ahk', restored = image(file).replace(wrappedLoop, originalLoop);
  assert.throws(() => consumer.checkNativeSources(target => target === file ? restored : image(target)), { name: 'AssertionError' });
});
check('omitting local namespace consumption admits each original pollution and demonstrates its necessity', () => {
  assert.equal(prefix.split('\tcheckNativeLocalNamespaces(read);').length, 2);
  const omitted = expose(prefix.replace('\tcheckNativeLocalNamespaces(read);', ''));
  for (const row of alpha) {
    const restored = reverseAlpha(image(row.file), row);
    omitted.checkNativeSources(target => target === row.file ? restored : image(target));
  }
});
check('omitting graph-leaf warning policy admits an actual off directive and demonstrates its necessity', () => {
  const start = prefix.indexOf('\tfor (const image of graph.values())'), end = prefix.indexOf("\tassert.ok(graph.has('static/ergopti_plus/windows/adapters/editor_replace.ahk'));", start);
  assert.ok(start >= 0 && end > start);
  const omitted = expose(prefix.slice(0, start) + prefix.slice(end));
  const leaf = 'static/ergopti_plus/windows/adapters/console_window.ahk', altered = image(leaf) + '\n#Warn LocalSameAsGlobal, Off\n';
  assert.throws(() => consumer.checkNativeSources(target => target === leaf ? altered : image(target)), { name: 'AssertionError' });
  omitted.checkNativeSources(target => target === leaf ? altered : image(target));
});
check('bounded named-function parser accepts literals/comments and rejects duplicate or unclosed scopes', () => {
  const literal = 'ActualOwner(Value := "x,){}") {\n; } {\n local := "}"\n return Value\n}\n';
  assert.ok(owners.runnerFunctionTokens(literal, 'ActualOwner').some(t => t.value === 'local'));
  assert.throws(() => owners.runnerFunctionTokens(literal + literal, 'ActualOwner'), /unique/);
  assert.throws(() => owners.runnerFunctionTokens('ActualOwner() {\n local := "}"\n', 'ActualOwner'), /unclosed/);
  assert.throws(() => owners.runnerFunctionTokens('; ActualOwner() {}\n', 'ActualOwner'), /unique/);
});
for (const [name, script] of [['complete registered native desktop guard', 'test-windows-native-desktop.cjs'], ['portable argument source admission', 'test-ahk-runner-arguments.cjs']]) check(name, () => {
  const result = cp.spawnSync(process.execPath, [path.join(projection, 'tools/test', script)], { encoding: 'utf8' });
  fs.writeFileSync(path.join(packet, script + '.log'), (result.stdout || '') + (result.stderr || ''));
  assert.equal(result.status, 0, result.stdout + result.stderr);
});
check('unchanged loop-capture scanner and its 14 fixtures accept only this compact candidate tree', () => {
  const script = 'tools/test/test-ahk-loop-capture.cjs';
  assert.equal(image(script), read(preimage, script));
  const result = cp.spawnSync(process.execPath, [path.join(projection, script)], {encoding:'utf8'});
  fs.writeFileSync(path.join(packet, 'loop-capture-private.log'), (result.stdout || '') + (result.stderr || ''));
  assert.equal(result.status, 0, result.stdout + result.stderr);
});
fs.writeFileSync(path.join(packet, 'qualification.json'), JSON.stringify({ status: 'SOURCE_ONLY_PASS', checks: results, nativeAHK: 'UNRUN', nativePowerShell: 'SKIP_NON_WINDOWS', nativeArgumentCases: 'SKIP_NON_WINDOWS', fullJS: 'UNRUN', fullWindowsSuite: 'UNRUN', packaging: 'UNRUN', notes: 'Lexical source and JS AST preservation evidence cannot certify native parsing or desktop behavior.' }, null, 2) + '\n');
console.log(JSON.stringify({ sourceChecks: results.length, status: 'PASS', native: 'UNRUN' }));
