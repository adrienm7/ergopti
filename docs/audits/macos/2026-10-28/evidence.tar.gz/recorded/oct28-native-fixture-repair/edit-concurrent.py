from pathlib import Path
p=Path('/workspace/ergopti-macos-cloner-i18n/static/ergopti_plus/macos/tests/support/release_swap_concurrent_probe.py')
s=p.read_text();start=s.index('def emitted(');end=s.index('\n\nMOVER =',start)
s=s[:start]+'''def command_from(driver, physical, arming, app, staged, pid, emission_source):
    """Keep native script-only observation distinct from executing real arm_swap Lua."""
    if emission_source == "actual-lua":
        result = subprocess.run(
            [arming.resolve_lua(), "-", str(driver), str(driver.parent / "_shared"),
             str(app), str(staged), str(pid), ""],
            input=arming.CAPTURE, text=True, capture_output=True,
            timeout=CONTROL_TIMEOUT, check=True,
        )
        return json.loads(result.stdout)
    if emission_source != "strict-source":
        raise ValueError("An explicit supported release emission source is required")
    source = (driver / "modules/updater/release_installer.lua").read_text(encoding="utf-8")
    # This fixture supplies positional script inputs. It does not run arm_swap:
    # the common Lua gate compares this entire vector with the actual Lua call.
    return {"executable": "/bin/sh", "args": [
        "-c", physical.extract_program(source, "DETACH_SCRIPT"), "detach",
        physical.extract_program(source), str(pid), str(app), str(staged),
        str(app) + ".previous", str(staged.parent.parent / "swap.log"),
    ]}


def command_digest(command):
    """Bind the executable and every raw argv byte, before or after explicit ports."""
    values = [command["executable"], *command["args"]]
    if any("\\0" in value for value in values):
        raise ValueError("A release command cannot contain native NUL bytes")
    return hashlib.sha256("\\0".join(values).encode()).hexdigest()


def emitted(driver, root, emission_source):
    """Bind one explicit script source; never discover a substitute interpreter."""
    arming = load("concurrent_arming", driver / "tests/support/modules/updater/release_arming_fixture.py")
    physical = load("concurrent_physical", driver / "tests/support/release_swap_physical_probe.py")
    command = command_from(driver, physical, arming, root / "ErgoptiPlus.app",
                           root / "stage/app/ErgoptiPlus.app", os.getpid(), emission_source)
    source = (driver / "modules/updater/release_installer.lua").read_text(encoding="utf-8")
    if command["args"][3] != physical.extract_program(source):
        raise RuntimeError("The physical concurrent probe does not match actual swap bytes")
    if command["args"][1] != physical.extract_program(source, "DETACH_SCRIPT"):
        raise RuntimeError("The physical concurrent probe does not match actual detach bytes")
    return command["args"][3], command["args"][1], physical, arming


def emission_controls(driver, root):
    """Compare real Lua calls and reject malformed detached literal authorities."""
    _, _, physical, arming = emitted(driver, root, "actual-lua")
    commands = []
    for name in ["ordinary", "quote ' and slash\\\\", "native\\ntrailing\\n"]:
        app = root / name / "Installed.app"
        staged = root / name / "stage/app/ErgoptiPlus.app"
        actual = command_from(driver, physical, arming, app, staged, os.getpid(), "actual-lua")
        parsed = command_from(driver, physical, arming, app, staged, os.getpid(), "strict-source")
        assert actual["interpreter_version"] == "Lua 5.4"
        assert actual["executable"] == parsed["executable"] and actual["args"] == parsed["args"]
        commands.append({"name": name, "interpreter_version": actual["interpreter_version"],
                         "argv_equal": True, "swap_equal": True, "detach_equal": True,
                         "argv_sha256": command_digest(actual)})
    source = (driver / "modules/updater/release_installer.lua").read_text(encoding="utf-8")
    marker = "local DETACH_SCRIPT = table.concat({"
    assert source.count(marker) == 1
    head, tail = source.split(marker)
    variants = {
        "missing": source.replace(marker, "local OTHER_SCRIPT = table.concat({"),
        "duplicate": source + "\\n" + marker,
        "reassigned": source + '\\nDETACH_SCRIPT = "foreign"\\n',
        "unknown-term": head + marker + tail.replace('"set -u"', 'UNKNOWN_CONSTANT', 1),
        "dynamic-term": head + marker + tail.replace('"set -u"', 'os.getenv("SHELL")', 1),
        "unterminated-entry": head + marker + tail.replace('"set -u",', '"set -u"', 1),
        "same-line-suffix": head + marker + tail.replace('}, "\\\\n")', '}, "\\\\n") .. "foreign"', 1),
        "continued-suffix": head + marker + tail.replace('}, "\\\\n")', '}, "\\\\n")\\n .. "foreign"', 1),
        "missing-separator": head + marker + tail.replace('}, "\\\\n")', '})', 1),
        "missing-constant": source.replace('local EXECUTABLE_SUFFIX = ', 'local OTHER_SUFFIX = ', 1),
    }
    for name, changed in variants.items():
        assert changed != source, name
        try:
            physical.extract_program(changed, "DETACH_SCRIPT")
        except ValueError:
            continue
        raise AssertionError("The detach literal extractor accepted " + name)
    return {"emission_source": "actual-lua-compared-with-strict-source", "commands": commands,
            "parser_refusals": list(variants)}
'''+s[end:]
s=s.replace('def lease_case(driver, physical, arming, root, native, mutant):','def lease_case(driver, physical, arming, root, native, mutant, emission_source):')
a=s.index('            capture = subprocess.run(',s.index('def lease_case'));b=s.index('            command["args"][3] =',a)
s=s[:a]+'''            command = command_from(driver, physical, arming, app, staged, parent.pid, emission_source)
            raw_digest = command_digest(command)
'''+s[b:]
s=s.replace('        receipts = []\n        for staged','        receipts = []\n        commands = []\n        for staged')
a='            read_fd, write_fd = os.pipe()';i=s.index(a,s.index('def lease_case'))
s=s[:i]+'''            commands.append({"executable": command["executable"], "args": command["args"],
                             "unported_argv_sha256": raw_digest,
                             "argv_sha256": command_digest(command)})
'''+s[i:]
# Bind the actual two script invocations to the lease scenario, not just its wrapper.
a='"name": "two-installers-before-arming",';assert s.count(a)==1;s=s.replace(a,a+'\n            "commands": commands,')
s=s.replace('    parser.add_argument("--native-launcher", type=Path)','''    parser.add_argument("--native-launcher", type=Path)
    parser.add_argument("--emission-source", choices=["actual-lua", "strict-source"], default="actual-lua")
    parser.add_argument("--emission-controls", action="store_true")''')
s=s.replace('    own_detached_descendants()','''    if args.emission_controls:
        print(json.dumps(emission_controls(args.driver.resolve(strict=True), args.root)))
        return
    own_detached_descendants()''')
s=s.replace('program, physical, arming = emitted(args.driver.resolve(strict=True), root)','program, detach, physical, arming = emitted(args.driver.resolve(strict=True), root, args.emission_source)')
s=s.replace('                args.mutant,\n            )','                args.mutant,\n                args.emission_source,\n            )')
s=s.replace('"program_sha256": hashlib.sha256(program.encode()).hexdigest(),','''"program_sha256": hashlib.sha256(program.encode()).hexdigest(),
                    "detach_sha256": hashlib.sha256(detach.encode()).hexdigest(),
                    "emission_source": args.emission_source,
                    "execution_scope": "script-only/source-parser" if args.emission_source == "strict-source" else "actual-arm-swap-lua",''')
p.write_text(s)
