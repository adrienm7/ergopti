import sys; sys.path.insert(0, sys.argv[2])
from todo_model import done_items
lines = open(sys.argv[1], encoding='utf-8').read().split('\n')
for n, (a, b, s, k) in enumerate(done_items(lines)):
    print(f'{n}\t{k}')
