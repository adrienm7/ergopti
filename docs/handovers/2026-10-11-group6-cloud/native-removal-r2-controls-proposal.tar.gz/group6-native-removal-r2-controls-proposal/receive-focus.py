from pathlib import Path
import os,subprocess,hashlib,json,shutil,tempfile
P=Path(__file__).resolve().parent;repo=Path('/workspace/ergopti');physical=Path(tempfile.mkdtemp(prefix='focused-source-',dir=P));tmp=P/'private-tmp';tmp.mkdir(mode=0o700,exist_ok=True)
files=['tools/test/macos_native_http_receiving_facts_test.py','tools/test/macos_native_http_fixture_builder_controls.py','tools/test/macos_native_http_client_root_controls.py','tools/test/macos_native_http_clock_contract_controls.py','tools/diagnostics/macos_owned_process.py']
files += [str(f.relative_to(repo)) for f in sorted((repo/'static/ergopti_plus/macos/tests/support').glob('*.py'))]
pins={}
for rel in files:
 raw=(repo/rel).read_bytes();pins[rel]=hashlib.sha256(raw).hexdigest();f=physical/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
owning='tools/test/macos_native_http_receiving_facts_test.py';fixture='static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py';(physical/owning).write_bytes((P/'candidate'/owning).read_bytes())
runner=physical/'focus.py';runner.write_text('''from pathlib import Path\nimport importlib.util,sys,unittest\np=Path(__file__).parent/'tools/test/macos_native_http_receiving_facts_test.py'\ns=importlib.util.spec_from_file_location('focused_owned_receiving',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)\nif sys.argv[1]=='new9':\n suite=unittest.defaultTestLoader.loadTestsFromTestCase(m.NativeTimedRemovalCaptureObservationTests);assert suite.countTestCases()==9\nelse:\n suite=unittest.TestSuite([m.NativeTimedAddCancellationTests('test69ActualSIGINTAndSIGTERMCaptureCancellationCannotReturnSuccess')]);assert suite.countTestCases()==1\nr=unittest.TextTestRunner(verbosity=2).run(suite)\nprint('FOCUS count=%d failures=%d errors=%d skipped=%d native=false'%(r.testsRun,len(r.failures),len(r.errors),len(r.skipped)))\nsys.exit(0 if r.wasSuccessful() else 1)\n''')
env=os.environ.copy();env.update({'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'});records=[]
def run(name,fixture_source,selector):
 for rel,pin in pins.items():assert hashlib.sha256((repo/rel).read_bytes()).hexdigest()==pin,rel
 (physical/fixture).write_bytes(fixture_source)
 with (P/(name+'.stdout')).open('wb') as out,(P/(name+'.stderr')).open('wb') as err:r=subprocess.run(['python','-I','-B',str(runner),selector],cwd=physical,env=env,stdout=out,stderr=err,timeout=30)
 for rel,pin in pins.items():assert hashlib.sha256((repo/rel).read_bytes()).hexdigest()==pin,rel
 row={'name':name,'exit':r.returncode,'stdout_sha256':hashlib.sha256((P/(name+'.stdout')).read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((P/(name+'.stderr')).read_bytes()).hexdigest(),'candidate_fixture_sha256':hashlib.sha256(fixture_source).hexdigest(),'canonical_source_fence':True,'native':False};records.append(row);(P/'receipts.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
(P/'runtime-source-inventory.json').write_text(json.dumps(pins,indent=2)+'\n')
run('original-nine-red',(P/'preimages'/fixture).read_bytes(),'new9')
run('frozen140-original-adaptor-red',(P/'frozen/native_http_wire_fixture_140.py').read_bytes(),'old1')
run('candidate-original-adaptor-green',(P/'candidate'/fixture).read_bytes(),'old1')
run('candidate-nine-green',(P/'candidate'/fixture).read_bytes(),'new9')
print(json.dumps({'terminal':True,'physical_source':str(physical),'runtime_source_files':len(pins)}))
