-- Complete target module; no test-case filter and no assertion changes.
local root = "/workspace/ergopti"
local target = "tests.unit.ui.test_menu_pause_greys_features"
local mode = assert(arg[1], "candidate or original mode required")
assert(mode == "candidate" or mode == "original")
assert(#arg == 1, "bounded module has no case filter")
arg = {}
if mode == "original" then
 local searchers = package.searchers or package.loaders
 assert(type(searchers) == "table", "actual native package loader required")
 table.insert(searchers, 1, function(name)
  if name ~= "ui.menu.menu_builder" then return "\nNo original provider override" end
  local file = "/workspace/ergopti-delivery/group1-complete-resume-20261007/menu-private-peer-oct10/linux-active-paused-header-existing-template-source-only-20261010/preimages/static/ergopti_plus/linux/ui/menu/menu_builder.lua"
  return assert(loadfile(file)), file
 end)
end
local file = assert(io.open(root .. "/static/ergopti_plus/linux/tests/run.lua", "rb"))
local source = assert(file:read("*a")); assert(file:close())
local before = "RunnerContract.load_modules(TEST_MANIFEST, function(mod_name)"
local first, last = assert(source:find(before, 1, true))
assert(not source:find(before, last + 1, true), "one actual module-loader receiving site")
-- Full unchanged discovery + audit_manifest validates every original registration.
-- Only the execution cohort is bounded to this real registered complete module.
source = source:sub(1, first - 1)
 .. 'RunnerContract.load_modules({ "tests.unit.ui.test_menu_pause_greys_features" }, function(mod_name)'
 .. source:sub(last + 1)
local compile = loadstring or load
local chunk = assert(compile(source, "@" .. root .. "/static/ergopti_plus/linux/tests/run.lua"))
chunk()
