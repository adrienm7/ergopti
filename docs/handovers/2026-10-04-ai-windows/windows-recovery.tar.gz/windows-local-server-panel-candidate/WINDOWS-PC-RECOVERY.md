# Windows PC recovery — frozen preparations

Windows coding and test execution stopped on explicit user steering. This report freezes preparations; none of the pending panels/JOIN sources below was adopted by this actor. Observed repository HEAD: `eeb2d87e45469d782ee19bf0836f2a00fd084953`.

## Source-reviewed prerequisites

Preserve the entire `windows-local-servers-candidate/` packet: `local_servers.ahk`, `local_server_menu.ahk`, their three test files, `source-port-contract.md`, `candidate-receipt.json`, and `check-candidate.cjs`. Independent reviewer `/root/review_discovery` approved the five frozen sources. Exact SHA-256 and absent destination preimages are in `candidate-receipt.json`. Scoped repository convention, closure/self-test, and BOM/LF checks passed. The 16 composition + 2 policy + 19 write cases are prepared, **native UNEXECUTED**. The 19 write cases deliberately use refused fake persistence and do not prove production save success. No source modifications occurred after this review.

The native models transport prerequisite is already committed by root; its actual child/private-curl debt remains distinct from ShellRunner's separately retained capture-deletion debt. Root owns the actual CI result and qualification status.

## JOIN preparation — unreviewed, unexecuted

Preserve `windows-local-server-join-candidate/test_local_server_join.ahk`.
Destination: `static/ergopti_plus/windows/tests/unit/test_local_server_join.ahk`; expected preimage: absent. Nine literal test registrations are present. **Independent review not performed; static gates not run; native 0 executed.** Do not register/adopt as qualified source until the findings below are resolved.

The fixture composes actual private source receipts, actual filesystem, DPAPI serialization, production lease acquisition/settlement, full config collector, TOML generation, joint WAL and compensation with actual shared controller/native model cache/write admission. Controlled HTTP children and runtime apply/notification seams do not claim real networking, backend application or menu input. Prepared controls: model save+selection; wrong originating receipt during otherwise nominal save; exact address/key preserving selection; stale admission before persistence; durable view/controller refusals; revocation at final classified reread; foreign durable bytes retained; actual Windows HANDLE blocking WAL deletion.

Known preparation defects left untouched because Windows work was stopped. A suspected max-age-key typo was disproved by direct read-only inspection: JOIN and panel both use the actual `local_server_detection_max_age_ms` catalogue key. No source correction was needed.

- Controller-only invalidation is fenced by the retained write claim, but general `Native.IsCurrent` does not compare shared Controller.Generation. The JOIN durable-controller case currently asserts general receipt invalidation, which is unsupported by that frozen contract. Review the intended contract and replace the preparation with an independent precise controller/write-claim assertion or implement a separately reviewed source fix; do not weaken existing registered assertions.
- Full collector runs under real `run_all` bootstrap globals (ScriptInformation, I18n, metrics and WPM owners). Preserve these identities; do not fabricate a minimal full-collector fake. Nominal assertions must verify AI durable values and an independent unrelated TOML sentinel, without pretending the full collector changes only AI leaves. That sentinel control is not yet added.
- Reconcile fixture lifecycle/epoch preconditions with root's newer 41-case shutdown source. No refused/settled shutdown recovery JOIN control has yet been prepared.

## Production panel/hooks — blocked, repairs not implemented

Preserve the entire `windows-local-server-panel-candidate/` packet. The standalone `local_server_panel.ahk` targets `static/ergopti_plus/windows/ui/menu/menu_llm/local_server_panel.ahk` (preimage absent). `integration-hooks.patch` and seven full hook copies target the bootstrap, index, init, actions, models, main submenu and lifecycle paths listed in `hook-preimages.json`. Those original exact preimages/candidate hashes remain authoritative historical patch bases. Scoped conventions, closure/self-tests, BOM/LF and read-only patch application passed **against those historical preimages**; native tests/E2E/full gates remain **UNEXECUTED**. Independent review found blocking defects. The original panel is **not approved**. No post-finding repair was implemented.

Remaining production blockers:

1. Actual resume calls `LLM_Menu_OnResume` before `LifecycleTransitionFinish`. Private source Admit correctly rejects unfinished transition, but panel requests a synchronous build there and may permanently ACK unavailable rows. Add an exact post-successful-Finish panel hook retaining only originating resume intent/generation, then fresh build after admission permits it. Preserve other resume ordering. No new timer is required if the already reserved lifecycle hook is used. Add a causal actual hook-level control. Current panel/hook packet has neither this correction nor control.
2. `_ReportSweepNonCritical` reads a current verdict, formats/translates outside Critical, then checks only source Admit before TrayTip. It can publish stale success after source/cache/view/controller replacement during formatting. Capture originating source/native receipt/cache/controller/model/rescan identities before verdict derivation; revalidate after formatting and perform a bounded final claim. Do not stamp a fresh source beside old verdict. Add inverse formatting-mutation/valid-authority notification controls. Current code is still defective.
3. Root adopted exact AI shutdown attempt/epoch authority at `eeb2d87`; historical `_LifecycleShutdownReason` remains audit data. Rebase lifecycle hook patch over that current source, preserve exact Begin/Refuse hooks, and design post-unwind canceled-shutdown repair only after exact attempt cleared and source/lease/retained debt admission succeeds. Do not clear historical reason or blanket-enable writes. Panel retirement currently invalidates views but has no canceled-shutdown recovery build/control.
4. Shared strict base-URL prerequisite is a separate frozen proposal in `base-url-policy-candidate/` with tiny wiring patches. Do not adopt old panel generic URL validation as parity completion. Reconcile reviewed policy and exact transport/source URL provenance; do not edit independent corpus expectations.
5. Root's renderer actor owns duplicate labels; retain raw ordered model receipts and qualify UI disambiguation independently. All 13 reused panel/policy keys were independently checked nonempty in 21 locale files (273 values); no locale edit was prepared.
6. Every accepted cache publication, including Changed=false, must recapture the source/view and refresh rows. Preserve that intended on_publish contract in final UI wiring. Paused rows may retain display-only detached snapshots, never live actions.

Actual Windows qualification still required: prepared native suites on final sources; real loopback models/chat; exact endpoint/key edit and DPAPI restart; paused/stale/reentrant input, resume and canceled-shutdown behavior; shared renderer duplicate IDs/labels; physical input/menu E2E; packaging/install/restart. Chat fallback TODO48 and other unfinished Windows TODO47/46 requirements are not completed by these prerequisites.

## Exact frozen/current inventory

| Frozen preparation | SHA-256 |
| --- | --- |
| `windows-local-server-join-candidate/test_local_server_join.ahk` | `bad3a73ae474e83f1106c91a0e893e90461a0dfed68eb91e2605b60899780808` |
| `windows-local-server-panel-candidate/local_server_panel.ahk` | `dd8da23d24a622260ae5515adfe327ae2cca82e643d453179c726564794ec71e` |
| `windows-local-server-panel-candidate/integration-hooks.patch` | `6bd099b7881d43e2f6189bf51ec0da55efd95ee6c5eecfc5a195524f08e646f2` |
| `windows-local-server-panel-candidate/hook-preimages.json` | `18867bb06ad87ba9f4e7b9d483d057a892a523582dddab9bffe9d542f5133e8d` |
| `windows-local-server-panel-candidate/panel-receipt.json` | `bbba576e9502257033b9c1dc59d6d935bb70582dbd69c6a73fdb4578b8a997b3` |

Current repository dependency snapshots (read-only; root owns adoption and native execution):

| Path | SHA-256 |
| --- | --- |
| `static/ergopti_plus/windows/ui/menu/menu_llm/menu_api_entries.ahk` | `ecbc1321fecf3f4e0f3c9f51642e43aaca7bb3e483359e5e85d43357ed2702bc` |
| `static/ergopti_plus/windows/ui/menu/menu_llm/transactions.ahk` | `1190f02ea005aff1bc30b57c89a15a2b9bbffcc7ab5ddbc7644cd5553b50d0c6` |
| `static/ergopti_plus/windows/tests/unit/test_local_server_private_publication.ahk` | `81bd71db40502ce72256ef381c015bbe01623b9c38543a6bf1274cafc21a15bb` |
| `static/ergopti_plus/windows/infra/lifecycle.ahk` | `caf175a613dd2c90305170041c1dc0eaab8d0ee17c245314fa856b5365a14151` |

The current lifecycle hash differs from the historical hook preimage; never replace it with the full scratch copy. Rebase only the reviewed minimal future hunks and preserve root/other-group changes. Register new tests only through the runner owner after source review; no runner change was prepared by this actor. Archive whole packets, not only patch text.
