# Native managed HTTP gate registration proposal

This packet only authors five hardware fixture sources. Root owns their actual
registration in tools/test, package.json, verify-change and ci.yml. Nothing here
has imported production Lua, built the extension or executed a native control.
The source-ready fixture has 30 independent public HTTP/GIO/PAC/TLS methods and
18 independent retained-parent-output checks. No expected result was derived
from production. The complete old Python class/test methods, Lua guardian,
original C extension and output18 source tail are retained verbatim.

## Proposed source paths

- `linux/tests/hardware/run_managed_http_native.py`: same 30 methods and owned
  cleanup; replaces historical literal snapshot admissions with explicit
  mandatory source hash, dependency commit, snapshot phase and inventory inputs.
- `linux/tests/hardware/run_managed_http_native.lua`: exact original production
  public adapter observer and guardian; no repository fallback or test-mode hook.
- `linux/tests/hardware/managed_http_gio_error.c`: exact native GIO extension. Its
  actual supported GError establishes unknown provenance, never PAC/WPAD failure.
- `linux/tests/hardware/run_http_output_target_native.lua`: full original
  LuaJIT18 parent-FD fixture with a canonical header prepended.
- `linux/tests/hardware/run_http_output_target_native_entry.lua`: source-only
  explicit driver bootstrap. It loads no external checkout defaults.

The Lua public observer and C extension receive only a canonical path prefix;
their entire historical body bytes follow unchanged. No guardian, assertion or
compiler implementation is edited by that header addition.

## Dependency snapshot contract

Current observed HEAD is 5598c7b93ea4c79ceb9aeb6629563b5bf88f8f22. Its dirty
GET/sink/normal-registration sources are part of the candidate, not an immutable
published HEAD qualification. `prepare_snapshot.py.source` authors a new snapshot
of all literal `static/ergopti_plus` files plus exact Git HEAD/status/index hashes.
It rechecks source bytes and complete file inventory before admitting the copy.
It refuses symlinks and existing output directories, never edits the checkout,
and labels the receipt `working-tree-snapshot`. No website sources are copied.

Do not run it while JS drift writers or generators are active. Root's source
header/corpus projection/formatting repairs are still pending at this draft.
After they finish, capture the final dirty snapshot once, then pass its exact
ADMISSION.json values to the native CLI. Source hashes bind the tested candidate;
assertions and literal body expectations are not regenerated.

The Python fixture consumes a mandatory exact inventory-byte SHA256 and verifies
the copied dependency bytes/kinds and complete path set again before any producer admission. Mutating both a
non-core source and the inventory cannot pass the admitted inventory digest.
The Python fixture preserves its full dependency inventory checks and sole-core
SHA admission. `--dependency-inventory` is explicit because the normal hardware
path differs from the historical scratch layout. `--error-module` MUST name the
DIRECTORY containing `libergopti-native-error.so`, never the shared object itself.
Wrong directory/module absence refuses preparation before native child creation.

## Mandatory native prerequisites

Use native Linux LuaJIT with actual luv/FFI, Python3, `/proc`, pidfd support,
subreaper permission, O_TMPFILE/CLOEXEC support on the private fixture directory,
and a locally assigned non-loopback IPv4 address. The 18 output controls use FFI
fcntl and are deliberately not claimed on Lua5.4. Both ABIs have separate model
qualification; that does not replace the actual18 native fixture.

The 30 public cases need a genuine modern curl supporting proxy_used (>=8.7) and
a genuine older curl (<8.7) for the negative, GNOME GProxyResolver/libproxy with
real PAC evaluation, GNOME proxy gsettings schemas, gsettings, private dbus-daemon,
OpenSSL, and genuine gio/gmodule development headers plus C compiler/pkg-config.
Missing prerequisites FAIL this explicit native profile; there is no green skip,
script announcing a fake curl version, dummy PAC resolver or handwritten ABI.

Official curl7.88.1 plus its private shared libraries qualified the old control in
this container. Ubuntu's installed curl may be too old for the positive controls
or too new for the negative. Root must provide real pinned/download-verified
versions in CI and separately admit their runtime paths. Do not alter system
curl or global LD_LIBRARY_PATH. The old path/library arguments affect only that
one old-curl test. Positive curl resolves through the explicit gate environment.

Compiler input is the included unmodified C source. Build into one owned module
directory, with actual headers/libraries selected by pkg-config:

```sh
cc -fPIC -shared -Wall -Wextra -Werror managed_http_gio_error.c \
  -o "$native_module_dir/libergopti-native-error.so" \
  $(pkg-config --cflags --libs gio-2.0 gmodule-2.0)
```

The extracted signed GIO SDK used previously is a container setup dependency,
not a checkout fallback. CI may install genuine development packages instead.
No enterprise credentials, external network endpoint, system proxy setting or
actual private certificate is needed during the tests. They own private D-Bus,
loopback/non-loopback local HTTP/PAC/proxy servers and a generated fixture CA.
Controlled CA trust does not qualify an enterprise certificate deployment.

## Root-owned runner contract

Run output18 and public30 serially after format/JS drift gates. Public30 already
owns its subreaper/Python/Popen/pidfd/Lua guardian; do not wrap it with a second
competing process cleanup owner. Use direct children into bounded private logs,
retain exit code before reading summaries, publish scalar counts/source hashes
only, and preserve failed sinks/retirement refusals. Soft timeout must request
owned cleanup and allow its bounded grace; force kill cannot establish closure.

Output18 runs LuaJIT from the captured driver with the included bootstrap and
existing repository `run_native_subreaper.py` as the sole adopted-child reaper.
Require its literal18/0/18 receipt and actual subreaper retirement receipt.
Public30 uses these explicit CLI inputs:

```text
--composition SNAPSHOT
--repository SNAPSHOT/dependencies
--dependency-inventory SNAPSHOT/DEPENDENCY-FILES.json
--expected-manifest ADMISSION.expected_manifest
--expected-inventory-sha256 ADMISSION.expected_inventory_sha256
--expected-native-sha256 ADMISSION.expected_native_sha256
--expected-dependency-commit ADMISSION.expected_dependency_commit
--expected-dependency-phase working-tree-snapshot
--control SNAPSHOT/dependencies/static/ergopti_plus/linux/tests/hardware/run_managed_http_native.lua
--error-module OWNED_COMPILED_MODULE_DIRECTORY
--legacy-curl-path ACTUAL_OLDER_ELF_NAMED_CURL
--legacy-curl-library-path OPTIONAL_PRIVATE_LIBRARY_DIRECTORY
-f -v
```

The --control path is restricted to the admitted snapshot hardware Lua fixture;
its bytes are therefore covered by the expected inventory digest. The root runner
must provide LUA_PATH containing only that captured driver/shared tree, excluding
external Lua source fallback. Preserve the actual platform LUA_CPATH for luv/FFI.

Require all30 tests, zero failures/errors/skips and complete native cleanup.
Historical30/0 and output18/0 are prior source evidence; this normal registration
and final snapshot remain UNEXECUTED. Installed relocation, enterprise auth/WPAD,
ETag-aware per-hop release pages and the later streaming updater/output-hop work
are distinct remaining acceptance/implementation boundaries.

## Existing three-fixture correction

Preserve revision3 inventory3350086d and patch00f00a3c untouched. Its native
before/after replay must use the exact current public API/core dependency snapshot,
subreaper per orphan-control owner, and original body-limit84/literal55/CLI50
inventories/assertions. No raw-engine retargeting or expectation relaxation.
Hosted CI has now confirmed first literal get_owned refusal and orphan wait
failures at the exact boundaries335 addresses; those source findings do not
establish causal native success until replay. The separately discovered body
cleanup14 fixture is a fourth source boundary, not implicitly fixed by335.
