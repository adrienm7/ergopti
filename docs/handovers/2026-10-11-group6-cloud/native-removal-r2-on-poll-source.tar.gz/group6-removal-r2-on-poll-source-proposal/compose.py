from pathlib import Path
import ast, difflib, hashlib, json, subprocess, tarfile
root=Path(__file__).resolve().parent
repo=Path('/workspace/ergopti')
legacy=Path('/workspace/ergopti-cloud/group6-native-removal-r2-controls-proposal-capsule.tar.gz')
assert hashlib.sha256(legacy.read_bytes()).hexdigest()=='086876e32237cf8d30e291cf46486f7a580d32811c359aa4eedcea3dfd0eb207'
paths=['static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py','tools/test/macos_native_http_receiving_facts_test.py','tools/test/test-managed-ollama-protocol.cjs']
pins=['10c923949060a3fc04a3d596c03c3851efce3815b443f6f40ccafdfd2d13c979','8bf9638f78aa3bcc15b19ba282ad9106df764f50c0857f2728ef679094af2281','f17d989ed87f173756cea59ec633d3ddaa621653bc50d1345427b0bcd830347e']
with tarfile.open(legacy) as tar:
 prefix='group6-native-removal-r2-controls-proposal/'
 old_fixture=tar.extractfile(prefix+'preimages/'+paths[0]).read()
 old_tests=tar.extractfile(prefix+'preimages/'+paths[1]).read()
 proposed_tests=tar.extractfile(prefix+'candidate/'+paths[1]).read()
 patch=tar.extractfile(prefix+'candidate.patch').read().decode()
 sections=patch.split('--- a/')
 selected=['--- a/'+s for s in sections[1:] if s.splitlines()[0] in paths[:2]]
 assert len(selected)==2
 assert sum(line.startswith('@@') for line in selected[0].splitlines())==7
 (root/'frozen-two-path.patch').write_text(''.join(selected))
 # Frozen cohort helper/class and all old bodies are retained, no expectation generation.
 (root/'frozen-owning-test.candidate.py').write_bytes(proposed_tests)
 (root/'legacy-original-owning.py').write_bytes(old_tests)
 (root/'legacy-original-fixture.py').write_bytes(old_fixture)
for p,pin in zip(paths,pins):
 data=(repo/p).read_bytes();assert hashlib.sha256(data).hexdigest()==pin,p
 for stage in ['preimages','candidate']:
  dest=root/stage/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
records=[]
for argv in [['--check',str(root/'frozen-two-path.patch')],[str(root/'frozen-two-path.patch')]]:
 subprocess.run(['git','apply',*argv],cwd=root/'candidate',check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 records.append({'action':'git apply','arguments':argv,'exit':0})
wrapper=root/'candidate'/paths[2]
old_literal=b"cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 156]);"
new_literal=old_literal.replace(b'156',b'165')
s=wrapper.read_bytes();assert s.count(old_literal)==1;s=s.replace(old_literal,new_literal);wrapper.write_bytes(s)
assert (root/'candidate'/paths[1]).read_bytes()==proposed_tests
poll_lines=b'        # Idle server polling must not consume the original bounded shutdown.\n        server_poll_interval_seconds = 0.05\n'
poll_thread=b'            worker = threading.Thread(\n                target=server.serve_forever,\n                kwargs={"poll_interval": server_poll_interval_seconds},\n                daemon=True,\n            )'
new_fixture=(root/'candidate'/paths[0]).read_bytes()
assert new_fixture.count(poll_lines)==1 and new_fixture.count(poll_thread)==1

# Function source comparison includes every nested helper without importing it.
def functions(data):
 lines=data.splitlines(keepends=True);result={}
 def visit(node,scope=''):
  for n in ast.iter_child_nodes(node):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    qualified=scope+'.'+n.name
    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):result[qualified]=b''.join(lines[n.lineno-1:n.end_lineno])
    visit(n,qualified)
   else:visit(n,scope)
 visit(ast.parse(data.decode('utf-8-sig')));return result
before_functions=functions((root/'preimages'/paths[0]).read_bytes());after_functions=functions(new_fixture)
assert before_functions.keys()==after_functions.keys()
changed=[name for name in before_functions if before_functions[name]!=after_functions[name]]
assert changed==['.WireFixture._command','.WireFixture._trust_install_stream'],changed
assert before_functions['.WireFixture._servers']==after_functions['.WireFixture._servers']
old_functions=functions(old_tests);new_functions=functions(proposed_tests)
for name,body in old_functions.items():assert new_functions[name]==body,name
new_methods=[name for name in new_functions if name not in old_functions and name.rsplit('.', 1)[-1].startswith('test')]
assert len(new_methods)==9
class_marker=b'class NativeTimedRemovalCaptureObservationTests(unittest.TestCase):\n'
start=proposed_tests.index(class_marker);end=proposed_tests.index(b'if __name__ == "__main__":',start)
assert proposed_tests[:start]+proposed_tests[end:]==old_tests
assert wrapper.read_bytes().replace(new_literal,old_literal)==(root/'preimages'/paths[2]).read_bytes()
forward=[];inverse=[];pairs=[]
for p in paths:
 old=(root/'preimages'/p).read_text();new=(root/'candidate'/p).read_text()
 forward.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
 inverse.extend(difflib.unified_diff(new.splitlines(keepends=True),old.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
 pairs.append({'path':p,'preimage_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest()})
(root/'candidate.patch').write_text(''.join(forward));(root/'candidate.inverse.patch').write_text(''.join(inverse))
(root/'source-preservation.json').write_text(json.dumps({'paths':pairs,'fixture_original_function_identities':len(before_functions),'fixture_changed_functions':changed,'poll_servers_body_byte_exact':True,'old_owning_function_bodies_byte_exact':len(old_functions),'old_156_selectors_providers_unchanged':True,'new_methods':new_methods,'owning_candidate_byte_exact_frozen_R2':True,'wrapper_inverse_single_literal_only':True,'test_execution':'NOT_RUN; active parent gate serialized','native':'NOT_RUN','legacy_capsule_sha256':'086876e32237cf8d30e291cf46486f7a580d32811c359aa4eedcea3dfd0eb207','operations':records},indent=2)+'\n')
print(json.dumps(pairs))
