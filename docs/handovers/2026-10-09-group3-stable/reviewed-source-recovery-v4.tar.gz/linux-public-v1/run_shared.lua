-- Reuses the original shared/Mac copy policy assertions with Linux's pure helper.
local packet=assert(arg[1]);local root='/workspace/ergopti/static/ergopti_plus'
package.path=packet..'/candidate/static/ergopti_plus/_shared/lua/?.lua;'..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..root..'/linux/?.lua;'..root..'/linux/?/init.lua;'..package.path
require('compat.utf8').install()
local helpers=require('tests.helpers')
require('test.key_combination_chords_contract').register(helpers)
local results=helpers.get_results();print('ORIGINAL_SHARED_COPY_CONTRACT '..results.passed..'/'..results.failed)
os.exit(results.failed>0 and 1 or 0)
