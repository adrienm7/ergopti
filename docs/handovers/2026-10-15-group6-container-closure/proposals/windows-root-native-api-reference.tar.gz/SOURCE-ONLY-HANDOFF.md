# Root immutable inert acquisition source handoff

These four literal source bodies are the V2 capability Root actually received.
They are NOT an enrolled production provider and do NOT qualify original23.
No runtime path, trusted caller, profile or source-role may be inferred from
successful inert cases. The receiver is supplied for source review, not import
or replay authorization. Its old manifest says author NOT_RUN; subsequent Root
receiving observed four transport/cancel/image cases, two forced retirement
cases and three top-level caller-to-authenticated-Node-to-first-PowerShell cases.
Eleven older class44/image/job cases are independent, not new provider credit.

OwnedInertCase(directory, image, image_sha256, launch_image, launch_sha256,
script, script_sha256, role, environment, lifetime_ms=30000) permits only the
explicit node-inert/powershell-inert roles. start(resume=False) acquires held
source/image identities and creates the initial process suspended. resume()
requires authenticated suspended state. exchange(payload) accepts bounded bytes.
retire(cancel=False) distinguishes natural/forced/cancel/deadline/IO ambiguity;
custody() reports failure state and never establishes physical retirement.
Native() is Windows x64 only. Exact API bodies, validation and native ABI are
in the literal source; this short map is not a replacement implementation.

Remaining software: current source-root/runtime dependency admission, original
23 and interpreted-AHK role binding, externally chosen trusted top-level caller,
closed capture/source/role nonce custody, genuine descendant/CRT/lifetime and
failure settlement, then production adapter enrollment. Do not open arbitrary
roles, accept booleans as authority, use ordinary spawn as a replacement root,
silently retry native acquisition, or flip qualification from these examples.
Group6 may privately design the current bridge from these literal sources;
Root owns independent actual Windows receiving and final integration. Existing
C/DLL/Cloud247 boundaries and all original controls remain in force.
