local root = "/workspace/ergopti/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local proof = "/workspace/.ergopti-cloud/resume18-read-tail-proof/"
package.preload["healthcheck.snapshot"] = function() return assert(loadfile(proof .. "snapshot.lua"))() end
local file = assert(io.open(proof .. "linux-original-fixture.lua", "rb"))
local source = assert(file:read("*a")); assert(file:close())
file = assert(io.open(proof .. "fault-cases.lua", "rb"))
source = source .. assert(file:read("*a")); assert(file:close())
assert((loadstring or load)(source, "@literal-existing-recent-issues-fixture.lua"))()
local results = require("tests.helpers").get_results()
print("LITERAL_IO_RESULTS " .. require("json").encode(results))
os.exit(results.failed == 0 and 0 or 1)
