<!-- linux-runtime-candidate/INSTALLER-QUALIFICATION.md -->

# Scratch installer qualification

All tests ran serially in the parent's explicitly granted exclusive local native
slot. Activation used `/workspace/ergopti-env.sh` and
`/workspace/ergopti-native-env.sh`; actual native UID was 1000. Required writable
`/var/tmp/ergopti-ai-validation` fixtures used the authorized escalated tool mode.
No checkout file was modified and no official Ollama archive was downloaded.

| Runtime | Transaction seams | File seams | Actual native file cases | Causal mutants |
| --- | ---: | ---: | ---: | ---: |
| `/workspace/.native/bin/luajit` | 21 passed, 0 failed | 22 passed, 0 failed | 11 passed, 0 failed | 10 rejected, 0 escaped |
| `/workspace/.native/bin/lua5.4` | 21 passed, 0 failed | 22 passed, 0 failed | 11 passed, 0 failed | 10 rejected, 0 escaped |

Final current product qualification: 108 cases passed, 0 failed, 0 skipped. The independent
wrapper's live-leader and exited-leader timeout/failure teardown cases also
passed 2/2, physically asserting child/descendant absence after cleanup. These
20 causal red receipts are expected mutant failures, not passing product cases.

All nine final commands exited 0 and observed their exact independent receipts.
Raw stdout/stderr, command vectors, statuses, UTC timestamps, UID and source/
transcript hashes are preserved at
`installer-results/final-string-owner-20261004/summary.json` and sibling log files.
Before/after source hashes match. These are actual fresh execution transcripts,
not reconstructed output. `installer-qualified-sha256.json` records complete
source and fixture hashes:

- Archive transaction: `8a9c9a4c076a5c38878bfe087fd11990f6bafdde956c5b9f528c063d5efe70f6`.
- Native file owner: `32a543091b81abbc1bf18c12d475ba81f2d4f6a2e96bb7e9bf49b1d636d4f26c`.
- Approved exact process prerequisite: `3f175c7a1c92df4e835912551efab00115611f806e5be62e462796b399934d5f`.

## Diagnosed failures and review corrections

The original 19 transaction + 18 file seams passed on both ABIs before read-only
review. Review then identified missing asset snapshots, intermediate bin/lib
symlink checks and post-hash archive identity admission. Corrections gained
independent seam/native cases and causal mutants. Repeat refused checksum and
extraction receipts now revoke previous admission flags.

A prior candidate passed 106 product cases plus 20 causal red receipts and 2 wrapper
cases. Read-only ABI inspection then found that existing owned HTTP and the
approved process prerequisite both require nonempty string owners. The final
candidate uses the captured named transaction owner for both ports, with explicit
independent seam assertions and one additional real composition case per ABI.
Those changes are qualified by the fresh 108-case capture above; previous 106-case
results are historical evidence for their earlier source hashes.

Three initial native attempts failed without relaxing any assertion:

1. The Python archive fixture used unsupported `zstd --output PATH`; corrected to
   documented `zstd -o PATH`. The failure occurred before native Lua dispatch.
2. Its helper passed a table owner, whereas the approved process prerequisite
   requires a string owner. Corrected to unique retained fixture owner strings.
3. GNU tar 1.35 help lacks the assumed `gnu.org/software/tar` URL. The production
   preflight now separately requires successful `tar --version` containing
   `GNU tar` and successful help showing each required extraction option. The
   independent transaction sequence consequently verifies nine exact operations.

The final tiny native archive is 216 bytes, built deterministically by independent
Python tarfile and zstd, with SHA256
`758348c5365a4d12aee014ef8bb2ccd41e70c8a74c7966b4c1d937d436abf8b2`.
It contains an inert executable fixture and full sibling library fixture. It is
not Ollama. Python computes bytes/digest independently of product code. Actual
GNU hashing, zstd extraction, mv no-clobber behavior, exact inode transfer,
symlink non-traversal and refusal of replaced paths were exercised. Each owned
helper checked actual settlement and `uv.loop_alive()==false`; the subreaper
reported zero leaked/adopted descendants in both successful runs.
The composition case uses actual native file and process owners plus a local-copy
port whose file handles are actually closed before its settled receipt. It sends
no HTTP request and makes no TLS or official-download qualification claim.

## Reproduction

Run each command serially after reserving the local native slot. Use each native
Lua ABI for the three applicable commands; the wrapper teardown runs once.

```sh
source /workspace/ergopti-env.sh
source /workspace/ergopti-native-env.sh
cd /workspace/ergopti-validation/linux-runtime-candidate
/workspace/.native/bin/luajit tests/test_archive_installer_seams.lua "$PWD"
/workspace/.native/bin/luajit tests/test_install_files_seams.lua "$PWD"
python3 tests/run_install_files_native.py /workspace/ergopti "$PWD" --lua /workspace/.native/bin/luajit
python3 tests/run_archive_installer_mutants.py /workspace/.native/bin/luajit "$PWD"
python3 tests/run_native_subreaper_teardown.py
```

## Limits

These results qualify scratch injected-port transaction behavior and actual tiny
native file/process receipts. Production reuse of Group3's announced common
worker remains untested because its API is unpublished. The native transaction
has not downloaded through the real owned HTTPS transport. Official runtime
installation, daemon serve/version, model handling, UI consent wiring, hosted
packaging/installation and TODO16/38 remain unrun. Existing ancestor symlink and
canonical-path ownership must be resolved before adoption. Path-based receipts
are not atomic defenses against a hostile same-UID concurrent process; private
stage ownership and settled internal writers are explicit assumptions.
