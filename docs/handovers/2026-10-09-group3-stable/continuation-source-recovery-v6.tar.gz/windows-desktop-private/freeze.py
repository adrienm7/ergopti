import pathlib, subprocess, hashlib, json, difflib, shutil

packet = pathlib.Path(__file__).parent
root = pathlib.Path('/workspace/ergopti')
preimage = packet / 'preimage'
projection = packet / 'projection'
sha = lambda data: hashlib.sha256(data).hexdigest()
read_git = lambda ref, name: subprocess.check_output(['git', 'show', ref + ':' + name], cwd=root, stderr=subprocess.DEVNULL)
changed = []
for candidate in sorted(projection.rglob('*')):
    if not candidate.is_file():
        continue
    name = str(candidate.relative_to(projection))
    previous = preimage / name
    before = previous.read_bytes() if previous.exists() else None
    after = candidate.read_bytes()
    if before == after or name.startswith('.github/workflows/'):
        continue
    assert b'\r' not in after, name
    if name.endswith('.ahk'):
        assert after.startswith(b'\xef\xbb\xbf'), name
    after.decode('utf-8')
    changed.append({'file': name, 'new': before is None,
                    'before_sha256': sha(before) if before is not None else None,
                    'after_sha256': sha(after)})
assert len(changed) == 16 and sum(row['new'] for row in changed) == 5
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
dev = subprocess.check_output(['git', 'rev-parse', 'origin/dev'], cwd=root, text=True).strip()
pins = []
for original in sorted(preimage.rglob('*')):
    if not original.is_file():
        continue
    name = str(original.relative_to(preimage))
    before = original.read_bytes()
    row = {'file': name, 'preimage_sha256': sha(before)}
    for key, ref in [('actual_head', head), ('upstream', dev), ('native_failure', '6d2c8b001c25bc1e55f235d0147a80886fb9cff4'), ('index', '')]:
        try:
            observed = read_git(ref, name)
            row[key] = {'sha256': sha(observed), 'matches_preimage': observed == before}
        except subprocess.CalledProcessError:
            row[key] = {'present': False}
    if not name.startswith('.github/workflows/'):
        assert row['actual_head']['matches_preimage'] and row['upstream']['matches_preimage'] and row['index']['matches_preimage'], name
    pins.append(row)
(packet / 'source-pairs.json').write_text(json.dumps({'actual_head': head, 'origin_dev': dev, 'changed_paths': changed, 'inputs': pins}, indent=2) + '\n')

def patch_text(inverse=False):
    result = []
    for row in changed:
        name = row['file']
        old = (preimage / name).read_text(encoding='utf-8') if not row['new'] else ''
        new = (projection / name).read_text(encoding='utf-8')
        if inverse:
            old, new = new, old
        result.append('diff --git a/' + name + ' b/' + name + '\n')
        if row['new']:
            result.append(('deleted file mode' if inverse else 'new file mode') + ' 100644\n')
        left = 'a/' + name if not row['new'] or inverse else '/dev/null'
        right = 'b/' + name if not row['new'] or not inverse else '/dev/null'
        result.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile=left, tofile=right))
    return ''.join(result)

(packet / 'forward.patch').write_text(patch_text())
(packet / 'inverse.patch').write_text(patch_text(True))
roundtrip = packet / 'roundtrip-final'
assert not roundtrip.exists(), 'fresh private roundtrip required'
roundtrip.mkdir()
for row in changed:
    if not row['new']:
        target = roundtrip / row['file']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((preimage / row['file']).read_bytes())
for mode in ['forward', 'inverse']:
    patch = str(packet / (mode + '.patch'))
    subprocess.run(['git', 'apply', '--check', patch], cwd=roundtrip, check=True)
    subprocess.run(['git', 'apply', patch], cwd=roundtrip, check=True)
    for row in changed:
        target = roundtrip / row['file']
        if mode == 'inverse' and row['new']:
            assert not target.exists(), row['file']
        else:
            expected = (projection if mode == 'forward' else preimage) / row['file']
            assert target.read_bytes() == expected.read_bytes(), row['file']
(packet / 'patch-roundtrip.json').write_text(json.dumps({'paths': len(changed), 'new_files': 5, 'forward': 'PASS_BYTE_EXACT', 'inverse': 'PASS_BYTE_EXACT', 'canonical_writes': False}, indent=2) + '\n')
print(json.dumps({'paths': len(changed), 'new_files': 5, 'source_pairs': sha((packet / 'source-pairs.json').read_bytes()), 'forward': sha((packet / 'forward.patch').read_bytes()), 'inverse': sha((packet / 'inverse.patch').read_bytes())}))
