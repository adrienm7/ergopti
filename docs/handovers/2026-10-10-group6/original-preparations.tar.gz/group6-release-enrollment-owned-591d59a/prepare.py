from pathlib import Path
import ast,hashlib,json
repo=Path('/workspace/ergopti');recovered=Path('/tmp/group6-release-corpus-recovered-opyfdruv');out=Path('/tmp/group6-release-enrollment-owned-591d59a')
py='tools/diagnostics/macos_release_stage_route_test.py';js='tools/test/test-macos-opaque-network-admission.cjs'
assert not (repo/py).exists()
pre=out/'preimage'/js;pre.parent.mkdir(parents=True,exist_ok=True);pre.write_bytes((repo/js).read_bytes())
old=(recovered/'release/receiving.py').read_text();s='# '+py+'\n'+old
s=s.replace('import argparse\n','import argparse\nfrom contextlib import nullcontext\n',1)
needle="    original=Path(args.script).read_text(); observations=[]; failures=[]"
replace="""    if sys.platform not in ('linux', 'darwin'):
        raise SystemExit('Unsupported POSIX cohort capability; no receiving cases executed')
    case_root = Path(args.receipt).resolve().parent / 'cases'
    if not case_root.is_dir() or case_root.is_symlink() or case_root.stat().st_mode & 0o777 != 0o700:
        raise SystemExit('An existing private owner-held case directory is required')
"""+needle
assert s.count(needle)==1;s=s.replace(needle,replace)
needle2="        with tempfile.TemporaryDirectory(prefix='release-route-receiving-') as tmp:"
replace2="""        # The enclosing native owner, not this worker, retires and removes
        # all inputs. Ambiguous cancellation leaves these paths intact.
        with nullcontext(tempfile.mkdtemp(prefix='release-route-receiving-', dir=case_root)) as tmp:"""
assert s.count(needle2)==1;s=s.replace(needle2,replace2)
start=s.index('            try:\n                result=subprocess.run(argv,env=env,capture_output=True,timeout=20)')
end=s.index('            rows=',start)
old_actor=s[start:end]
new_actor="""            stdout_path, stderr_path = root / 'child.stdout', root / 'child.stderr'
            with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
                result = subprocess.run(argv, env=env, stdout=stdout, stderr=stderr)
            if stdout_path.stat().st_size > 1048576 or stderr_path.stat().st_size > 1048576:
                raise RuntimeError('Owned case capture exceeds its bound')
            result = subprocess.CompletedProcess(argv, result.returncode,
                                                 stdout_path.read_bytes(), stderr_path.read_bytes())
"""
s=s[:start]+new_actor+s[end:]
post=out/'candidate'/py;post.parent.mkdir(parents=True,exist_ok=True);post.write_text(s)
# Freeze exact reversible source seams; every expectation and assertion outside
# these storage/timeout substitutions is retained byte-for-byte.
operations=[{'before':'import argparse\n','after':'import argparse\nfrom contextlib import nullcontext\n'}, {'before':needle,'after':replace}, {'before':needle2,'after':replace2}, {'before':old_actor,'after':new_actor}]
inverse=s.removeprefix('# '+py+'\n')
for op in reversed(operations):
 assert inverse.count(op['after'])==1;inverse=inverse.replace(op['after'],op['before'],1)
assert inverse==old
corpus=old[old.index('URL = '):old.index('\n\n# Portable adapters')]
assert corpus in s
(out/'MECHANICAL-MAPPING.json').write_text(json.dumps({'version':1,'original_source':str(recovered/'release/receiving.py'),'original_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_path':str(post),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'header_added':'# '+py+'\n','operations':operations,'whole_inverse_exact':True,'case_and_constant_bytes_exact':True,'corpus_sha256':hashlib.sha256(corpus.encode()).hexdigest()},indent=2)+'\n')
print(json.dumps({'python_sha256':hashlib.sha256(s.encode()).hexdigest(),'whole_inverse_exact':True,'corpus_sha256':hashlib.sha256(corpus.encode()).hexdigest()}))
