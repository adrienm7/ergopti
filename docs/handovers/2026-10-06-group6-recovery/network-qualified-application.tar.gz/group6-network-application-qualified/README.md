<!-- README.md -->

# Qualified prepared headers and retirement application supplement

This is a source-only proposal for root application, pinned to clean root
9f4b8e9c16b2b916c5a5e630f5ac6a1b22c91b13. No checkout, index, ref, generator,
compiler or test was modified or executed while preparing this supplement.

`APPLICATION.json` binds 16 exact candidate paths and each current regular-file
preimage or explicit absence. `application.patch` contains only those paths.
`registration.patch` is a separate six-row additive normal manifest proposal;
root owns registration and must rebase it if its preimage advances. The 48
added models comprise the original prepared34 and descriptor14. Existing
owned-authorization27 and forwarding12 assertions remain registered and retain
their expectations; their fixture ports gain genuine immutable preparation
receipts. The original native ownership suite is unchanged by this patch.

The source-selection baseline is the exact corrected e7a qualification stage,
with final 25a cancellation-variable rename. The shared header module, native
capability registry, public immutable snapshot, and managed live-boolean queue
admission preserve prepared input without repeated caller conversion. Existing
owned-to-owned refusal occurs before metadata conversion. Construction delivery
waits for its real physical debt. The descriptor cancellation receipt is scoped
to terminal, never-spawned retained body descriptors; handle-only cancellation
and failed started-process signaling keep their prior contract.

Two installation-only source headers differ from the qualified stage: the
prepared support factory has its canonical first-line path, and the new native
11-case file has a canonical module banner. Every byte of their executable
control tail is preserved. No independent expectation was regenerated.
`PRESERVATION.json` also checks all 50 original preflight assertion lines and32
original body-cleanup assertion lines as ordered literal subsequences. The
preflight construction-only scenario180 uses the actual native engine explicitly;
168/196 and all other existing scenarios retain the public API. A separate25th
public bad-header case proves no native allocation. This scoped disposition was
source-reviewed before qualification; there is no blanket fixture retarget.

`pending-output-hop/` contains the exact same reviewed changes composed against
its separate a336/d39/c35 preimages. Its output-hop46 and full runtime are
UNEXECUTED. Ordinary results do not qualify the pending output pipeline. Root
must coordinate with shared_failure62 before choosing that variant or composing
its subsequent lease, digest, updater and artifact changes.

The evidence directory preserves typed receipts and finite source provenance.
Final ordinary qualification: original528/0 LuaJIT and525/0 Lua5.4, original34/0
and descriptor14/0 on each runtime, actual public preflight25/0 and body14/0.
Three original FFI-gated cases are not registered under Lua5.4; they were run
under LuaJIT. All four final actual guardian invocations physically reaped their
known direct child and reported adopted/pending/rescue0/0/0. Genuine model
before14 remains9PASS/5FAIL on each runtime. Same corrected producer with the
original temporal body fixture remains8PASS/6FAIL; original producer with the
corrected fixture remains13PASS/1FAIL. These causal failures are preserved,
not counted as candidate successes. The earlier body7PASS/7FAIL and later
preserved527PASS/1FAIL cancellation-shadow regression remain in typed evidence.
The name-only25a fix closes that regression without changing any assertion.

These results belong to immutable root471e/runtime-catalog8a admissione7a,
not a future root application. Normal registration, final current-main full
gates and targeted CI must run after root composition. Initial ordinary
preflight24, pending output-hop46, native335 cohorts and historical bodypipe20
are not part of this final qualification. Enterprise credentials, real corporate
PAC/WPAD and customer TLS are not claimed by refusal-injected local controls.

The historical-bodypipe report records four concrete local implementation or
fixture-contract gaps still requiring causal work. These are not external
blockers and do not justify removing TODO62. No new cancellation exception or
budget change is implemented in this supplement.

The earlier finite network archivea5ce4363 and cancellation supplement42e888a8
remain untouched. This supplement includes final typed qualification and current
application preimages, without private transcripts, secret/environment files,
binaries or thousands-file stages. Root owns durable handover persistence.
