local root="/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path=root.."lua/?.lua;"..package.path
local Json=require("json");local Policy=require("control.driver_control")
local f=assert(io.open(root.."modules/control/driver_control.json","rb"));local raw=assert(f:read("*a"));assert(f:close());local spec=Policy.validate(Json.decode(raw))
assert(spec.state_set.requested==true and spec.state_set.REQUESTED==nil)
local rows={
 {"canonical", [=["state":"requested"]=],true},
 {"escaped canonical", [=["state":"\u0072equested"]=],true},
 {"uppercase", [=["state":"REQUESTED"]=],false},
 {"title case", [=["state":"Requested"]=],false},
 {"mixed case", [=["state":"rEqUeStEd"]=],false},
 {"other declared state", [=["state":"claimed"]=],false},
 {"boolean", [=["state":true]=],false},
 {"integer", [=["state":1]=],false},
 {"array", [=["state":[]]=],false},
 {"object", [=["state":{}]=],false},
 {"null", [=["state":null]=],false},
 {"last uppercase", [=["state":"requested","state":"REQUESTED"]=],false},
 {"last canonical", [=["state":"REQUESTED","state":"requested"]=],true},
}
local passed,failed=0,0
for _,phase in ipairs({"completion","resolution"}) do
 for _,row in ipairs(rows) do
  local text='{"schema":1,"request_id":"state-enum","driver_pid":100,"successor_pid":200,'..row[2]..'}'
  local decoded=Json.decode(text);assert(decoded.request_id=="state-enum" and decoded.successor_pid==200)
  local kind,result
  if phase=="completion" then result=Policy.completion(spec,text,200,Json.decode)
  else kind,result=Policy.resolve(spec,text,200,1700000000,Json.decode) end
  local expected='{"schema":1,"request_id":"state-enum","state":"completed","driver_pid":200,"successor_pid":200}\n'
  local ok=(row[3] and result==expected and (phase=="completion" or kind=="completed")) or (not row[3] and result==nil and kind==nil)
  print((ok and "PASS " or "FAIL ")..phase.." "..row[1]);if ok then passed=passed+1 else failed=failed+1 end
 end
end
print(passed.." passed, "..failed.." failed");os.exit(failed==0 and 0 or 1)
