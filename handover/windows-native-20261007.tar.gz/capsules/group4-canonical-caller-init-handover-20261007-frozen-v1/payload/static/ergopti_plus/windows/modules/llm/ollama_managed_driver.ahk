﻿; modules/llm/ollama_managed_driver.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Canonical Managed Windows Ollama Caller
; DESCRIPTION:
; Holds inspection, official preparation and the existing ready coordinator.
; Runtime expectations become authority only in the later source/guardian path.
; ==============================================================================

global _OllamaManagedDriver := 0

/** Initializes the unique default caller before any managed lifecycle use. */
OllamaManagedDriverInit() {
	global _OllamaManagedDriver, _SharedDir, _VendorDir, HTTP_CURL_MAX_RESPONSE_BYTES
	local previous := Critical("On")
	try {
		if !(_OllamaManagedDriver is Integer && _OllamaManagedDriver == 0)
			throw Error("Managed Ollama driver initialization is exclusive.")
		local owner := OllamaManagedDriver()
		_OllamaManagedDriver := owner
	} finally Critical(previous)
	try {
		owner.Initialize(OllamaGuardianCodePins(), _SharedDir . "\modules\llm\ollama_release.json",
			EnvGet("LOCALAPPDATA") . "\" . AppDirsWindowsManagedOllamaFolderName(),
			EnvGet("SystemRoot") . "\System32\WindowsPowerShell\v1.0\powershell.exe",
			TimingsGet("llm", "poll_interval_ms"), TimingsGet("llm", "dependency_bootstrap_timeout_ms"),
			HTTP_CURL_MAX_RESPONSE_BYTES)
		LLM_ManagedWindows_Init(owner.Coordinator, owner)
		return true
	} catch as Err {
		owner.Phase := "initialization-refused"
		owner.FirstError := "managed_driver_initialization_refused"
		throw Err
	}
}

OllamaManagedDriverRequireState() {
	global _OllamaManagedDriver
	if !(_OllamaManagedDriver is OllamaManagedDriver) || _OllamaManagedDriver.Phase != "ready"
		throw Error("Managed Ollama driver has not completed its exclusive initialization.")
	return _OllamaManagedDriver
}

/** Intent-only directory paths are validated by the native Root owner. */
class OllamaManagedDriver {
	__New() {
		this.Phase := "reserved"
		this.FirstError := ""
		this.Record := 0
		this.Generation := 0
		this.Coordinator := 0
		this.Preparation := 0
		this.Files := 0
	}

	Initialize(Pins, CataloguePath, RootIntent, PowerShell, PollMs, WorkflowMs, CaptureBytes) {
		if this.Phase != "reserved" || !(Pins is Map) || !(PollMs is Integer) || PollMs <= 0
				|| !(WorkflowMs is Integer) || WorkflowMs <= 0 || WorkflowMs > 0x7fffffff
				|| !(CaptureBytes is Integer) || CaptureBytes <= 0
			throw TypeError("Managed caller requires one explicit generated dependency closure.")
		for value in [CataloguePath, RootIntent, PowerShell]
			if !(value is String) || !RegExMatch(value, "\A[A-Za-z]:\\") || InStr(value, "`r") || InStr(value, "`n")
				throw ValueError("Managed caller requires complete native path intents.")
		local projection := OllamaManagedPinProjection(Pins)
		this.CataloguePath := CataloguePath
		this.RootIntent := RootIntent
		this.ModelsLeaf := AppDirsWindowsManagedOllamaModelsFolderName()
		this.CaptureBytes := CaptureBytes
		this.PollMs := PollMs
		this.WorkflowMs := WorkflowMs
		this.RuntimeOptions := Map("native_pins", projection["native"], "launcher", Pins["Launcher"]["path"],
			"powershell", PowerShell, "startup_ms", WorkflowMs, "poll_ms", PollMs,
			"source_capture_bytes", CaptureBytes, "direct_daemon", true)
		this.Files := OllamaManagedFilesDefault(Map("pins", projection["files"], "powershell", PowerShell, "capture_bytes", CaptureBytes))
		this.Coordinator := OllamaManagedCoordinator(this.Files, this.RuntimeOptions,
			Map("workflow_ms", WorkflowMs, "poll_ms", PollMs, "timer", TimerSetCallback,
				"consent", ObjBindMethod(this, "_StartConsent"), "model_consent", OllamaManagedModelConsent,
				"on_ready", ObjBindMethod(this, "_Ready"), "on_failed", ObjBindMethod(this, "_CoordinatorFailed")))
		this.Preparation := OllamaUserLocalSession(this.Files, this.RuntimeOptions,
			ObjBindMethod(this, "_PreparationCurrent"), ObjBindMethod(this, "_PreparationConsent"),
			(*) => this._UnexpectedPreparationRuntime(), PollMs, ObjBindMethod(this.Coordinator, "_SessionTimer"))
		this.Phase := "ready"
	}

	/** Async accepted dispatch; does not report version/model readiness or enable. */
	Check(Model, OnReady, OnFailed, ShowUi := true) {
		if !HasMethod(OnReady, "Call") || !HasMethod(OnFailed, "Call") || !(Model is String)
			throw TypeError("Managed check requires its originating model and callbacks.")
		local previous := Critical("On")
		try {
			if this.Phase != "ready" || this.Record is Map || this.HasNativeOwner() || this.Files.HasFileDebt()
				return false
			if this.Generation == 0x7fffffffffffffff
				throw Error("Managed caller request identities are exhausted.")
			local record := Map("generation", ++this.Generation, "captured", 0, "asset", 0, "plan", 0,
				"phase", "capturing", "building", true, "cancelled", false, "first_error", "",
				"ready_callback", OnReady, "failed_callback", OnFailed, "show_ui", ShowUi ? true : false,
				"install_consented", false, "failure_notified", false, "timer_owned", false,
				"busy", false, "deadline", A_TickCount + this.WorkflowMs)
			record["timer"] := ObjBindMethod(this, "_Poll", record)
			this.Record := record
		} finally Critical(previous)
		local accepted := false
		try {
			record["captured"] := OllamaManagedCopySnapshot(OllamaManagedSnapshot())
			if record["captured"]["model"] != Model || !this._Current(record)
				return false
			record["asset"] := OllamaWindowsRelease()
			record["plan"] := this._Plan(record)
			if !this._Current(record)
				return false
			if !FSStrictExists(this.RootIntent)
				accepted := this._Install(record)
			else {
				record["phase"] := "inspecting"
				local request := record["plan"]["prepare"].Clone()
				for name in ["ArchivePath", "TicketId", "MaxExpandedBytes", "MaxEntries"]
					request.Delete(name)
				request["InspectMetadataBytes"] := this.CaptureBytes
				accepted := this.Files.Dispatch("inspect", request, this._Authority(record), ObjBindMethod(this, "_Inspected", record))
			}
			return accepted && this._Current(record)
		} catch Any as Err {
			this._Fault(record, "managed_caller_dispatch_refused")
			return false
		} finally {
			record["building"] := false
			if !accepted || !this._Current(record)
				this._Fault(record, "managed_caller_admission_refused")
			this._Poll(record)
		}
	}

	_Plan(Record) {
		local text := FSReadUtf8ExactBounded(this.CataloguePath, this.CaptureBytes)
		if !(text is String)
			throw Error("The canonical release source is unavailable or exceeds its bound.")
		local data := JsonParse(text), asset := Record["asset"], pin := data["assets"].Get(asset["asset_id"], 0)
		if !(pin is Map) || data.Get("schema_version", 0) != 1 || data.Get("version", "") != asset["version"]
			throw Error("The canonical release source differs from its generated selection.")
		for name in ["filename", "bytes", "sha256"]
			if Type(pin.Get(name, 0)) != Type(asset[name]) || !(pin[name] == asset[name])
				throw Error("The canonical release asset differs from its generated selection.")
		local policy := OllamaWindowsArchivePolicy(), origin := 0
		if !RegExMatch(Record["captured"]["origin"], "\Ahttp://(?:localhost|127\.0\.0\.1):([0-9]+)\z", &origin)
				|| StrLen(origin[1]) > 5 || Integer(origin[1]) < 1 || Integer(origin[1]) > 65535
			throw ValueError("Managed caller requires its exact configured local origin.")
		local models := this.RootIntent . "\" . this.ModelsLeaf, ticket := OllamaManagedNewTicketId()
		return Map("version", asset["version"], "archive_mode", "official", "deadline", Record["deadline"],
			"prepare", Map("ManagedRoot", this.RootIntent, "CataloguePath", this.CataloguePath,
				"CatalogueSha256", StrLower(CryptoSha256Bytes(_OllamaManagedReadyUtf8Bytes(text))), "AssetId", asset["asset_id"],
				"TicketId", ticket, "ArchivePath", "", "MaxExpandedBytes", policy["max_expanded_bytes"],
				"MaxEntries", policy["max_entries"], "ModelsDirectory", models, "ModelsFolderName", this.ModelsLeaf),
			"target", Map("models_dir", models, "models_folder_name", this.ModelsLeaf,
				"origin", "http://127.0.0.1:" . Integer(origin[1]), "port", Integer(origin[1])))
	}

	_Owns(Record) {
		return this.Record is Map && this.Record == Record && this.Generation == Record["generation"]
	}

	_Current(Record) {
		if !this._Owns(Record) || Record["cancelled"] || A_IsSuspended || !(Record["captured"] is Map)
			return false
		local now := A_TickCount, live := OllamaManagedSnapshot()
		return this._Owns(Record) && !Record["cancelled"] && !A_IsSuspended
			&& (Record["phase"] == "ready" || now < Record["deadline"])
			&& OllamaManagedSelectionCurrent(Record["captured"], live)
	}

	_Authority(Record) {
		local current := (*) => this._Current(Record)
		return Map("authorize", current, "is_current", current)
	}

	_Install(Record) {
		if !this._Current(Record) || !Record["show_ui"]
			return false
		if !OllamaManagedArchiveConsent(Record["captured"], Record["asset"]) || !this._Current(Record)
			return false
		Record["install_consented"] := true
		Record["phase"] := "installing"
		return this.Preparation.Start(Record["plan"], OllamaOfficialSessionArchive, ObjBindMethod(this, "_Published", Record))
			&& this._Current(Record)
	}

	_PreparationCurrent(Prepare, Target) {
		local record := this.Record
		return record is Map && this._Current(record) && Prepare["TicketId"] == record["plan"]["prepare"]["TicketId"]
			&& Prepare["CatalogueSha256"] == record["plan"]["prepare"]["CatalogueSha256"]
			&& Target["models_dir"] == record["plan"]["target"]["models_dir"]
			&& Target["origin"] == record["plan"]["target"]["origin"]
			&& this._Current(record)
	}

	_PreparationConsent(Prepare, Target) {
		return this.Record is Map && this.Record["install_consented"] && this._PreparationCurrent(Prepare, Target)
	}

	_UnexpectedPreparationRuntime() {
		throw Error("A publication-only preparation must never dispatch a runtime.")
	}

	_Inspected(Record, Receipt) {
		if !this._Current(Record)
			return this._Fault(Record, "managed_inspection_source_refused")
		if !(Receipt is Map) || Receipt.Get("ok", false) != true
			return this._Fault(Record, "managed_inspection_refused")
		if Receipt.Get("phase", "") == "missing"
			return this._Install(Record) || this._Fault(Record, "managed_install_consent_refused")
		return this._Reuse(Record, Receipt)
	}

	_Published(Record, Receipt) {
		if !this._Current(Record)
			return this._Fault(Record, "managed_publication_source_refused")
		if !this.Preparation.Stop()
			return this._Fault(Record, "managed_preparation_handback_pending")
		return this._Reuse(Record, Receipt)
	}

	_Reuse(Record, Receipt) {
		local captured := OllamaManagedCopyExistingReceipt(Receipt), plan := Record["plan"].Clone(), target := plan["target"].Clone()
		if captured.Get("ModelsFolderName", "") != this.ModelsLeaf
				|| captured.Get("ModelsDirectory", "") != captured["RootPath"] . "\" . this.ModelsLeaf
			throw ValueError("Native models expectation is outside its exact managed Root/leaf.")
		; Native worker output selected this spelling through the retained Root/FID.
		; No textual prefix rewrite or path reopening establishes authority here.
		target["models_dir"] := captured["ModelsDirectory"]
		plan["target"] := target
		OllamaOfficialIntakeNative(this.RuntimeOptions["native_pins"])
		if !this._Current(Record)
			return this._Fault(Record, "managed_native_initialization_source_refused")
		Record["phase"] := "starting"
		if !this.Coordinator.StartExisting(plan, captured) || !this._Current(Record)
			return this._Fault(Record, "managed_existing_start_refused")
		return true
	}

	_StartConsent(Captured, Asset) {
		local record := this.Record
		return record is Map && record["show_ui"] && this._Current(record)
			&& OllamaManagedExistingConsent(Captured, Asset) && this._Current(record)
	}

	_Ready(Receipt) {
		local record := this.Record
		if !(record is Map) || !this._Current(record) || !this.Coordinator.ReadyForUse() || !this._Current(record)
			return
		record["phase"] := "ready"
		; This reports ready only. The existing preference writer still owns enable.
		record["ready_callback"].Call()
		if !this._Current(record)
			this._Fault(record, "managed_ready_delivery_source_refused")
	}

	_CoordinatorFailed(Reason) {
		if this.Record is Map
			this._Fault(this.Record, Reason)
	}

	_Fault(Record, Reason) {
		if !this._Owns(Record)
			return false
		if Record["first_error"] == ""
			Record["first_error"] := Reason
		Record["cancelled"] := true
		Record["phase"] := "retiring"
		return false
	}

	_Poll(Record) {
		local previous := Critical("On")
		try {
			if !this._Owns(Record) || Record["building"] || Record["busy"]
				return
			Record["busy"] := true
		} finally Critical(previous)
		try this._PollOwned(Record)
		finally Record["busy"] := false
	}

	_PollOwned(Record) {
		if !Record["cancelled"] && !this._Current(Record)
			this._Fault(Record, "managed_caller_source_changed")
		if Record["cancelled"] {
			if this.Coordinator._SessionTimer(Record["timer"], 0)
				Record["timer_owned"] := false
			this.Files.Cancel()
			this.Preparation.Stop()
			this.Coordinator.Stop()
			if !Record["failure_notified"] {
				Record["failure_notified"] := true
				Record["failed_callback"].Call(t("ollama.runtime_repair_failed"))
			}
			if !this.Files.HasOwner() && !this.Preparation.Runtime.HasOwner() && !this.Preparation.Busy
					&& !this.Preparation.ArchiveOwned && !this.Coordinator.HasNativeOwner()
					&& !this.Files.HasFileDebt() && !Record["timer_owned"] && this._Owns(Record) {
				this.Record := 0
				return
			}
		}
		Record["timer_owned"] := true
		if !this.Coordinator._SessionTimer(Record["timer"], -this.PollMs)
			this._Fault(Record, "managed_caller_timer_refused")
	}

	ReadyForUse() {
		local record := this.Record
		return record is Map && record["phase"] == "ready" && this._Current(record)
			&& this.Coordinator.ReadyForUse() && this._Current(record)
	}

	HasNativeOwner() {
		return this.Record is Map && this.Record["building"]
			|| IsObject(this.Files) && this.Files.HasOwner()
			|| IsObject(this.Preparation) && (this.Preparation.Busy || this.Preparation.ArchiveOwned || this.Preparation.Runtime.HasOwner())
			|| IsObject(this.Coordinator) && this.Coordinator.HasNativeOwner()
	}

	Stop() {
		local record := this.Record
		if record is Map {
			this._Fault(record, "managed_caller_lifecycle_revoked")
			this._Poll(record)
		}
		return !(this.Record is Map) && !this.HasNativeOwner()
	}
}
