# Publication-only session handoff

An explicit third completion argument allows the existing official archive/session path to finish preparation and real native descriptor publication without launching a runtime. The copied expectation is delivered once and its final current source is checked again. The later canonical caller binds the native models tuple before StartExisting and still requires separate start consent and native source/guardian READY. Legacy two-argument starts retain their original path. No process or data closure is inferred from this callback.
