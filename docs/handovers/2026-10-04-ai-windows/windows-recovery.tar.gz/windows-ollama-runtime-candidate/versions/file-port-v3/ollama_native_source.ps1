# modules/llm/ollama_native_source.ps1
# Reads captured native helper code without reopening its pathname to execute.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Read-OllamaNativeCode([string]$Path, [string]$ExpectedHash) {
	if ($Path -notmatch '^[A-Za-z]:\\' -or $ExpectedHash -notmatch '^[0-9a-f]{64}\z') {
		throw 'Native helper code requires its captured absolute path and exact SHA-256.'
	}
	$stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
	try {
		$hash = [Security.Cryptography.SHA256]::Create()
		try { $actual = ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
		finally { $hash.Dispose(); $stream.Position = 0 }
		if ($actual -ne $ExpectedHash) { throw 'The captured native helper source changed.' }
		$reader = [IO.StreamReader]::new($stream, [Text.UTF8Encoding]::new($false, $true), $false, 1024, $true)
		try { $code = $reader.ReadToEnd() } finally { $reader.Dispose(); $stream.Position = 0 }
		# Parsing these verified bytes avoids a second pathname read. The source
		# stream remains locked through the caller's explicit dot-source boundary.
		return @{ stream = $stream; block = [scriptblock]::Create($code); sha256 = $actual }
	} catch { $stream.Dispose(); throw }
}
