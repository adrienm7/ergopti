'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const proof='/workspace/scratch/windows-audit-round6/ui-metrics/literal-unicode-native-producer/';
const failures=[];let controls=0;
for(const host of ['windows','macos','linux'])for(const sensitive of [true,false])for(const id of ['nbsp-only','nnbsp-only','ordinary-nbsp','literal-capital-a-nbsp','literal-c1-sequence']){
 const page=loadMetricsTypingPage(host),native=JSON.parse(fs.readFileSync(proof+id+'.json','utf8'));
 const blob={metrics_manifest:native.manifest,_prefetch_data:native.range,app_icons:{},keycode_layout:{},driver_meta:{os:host,heatmap_id:'sc'}};
 if(host==='windows')page.messageListeners.filter(e=>e.name==='message').at(-1).callback({data:{type:'prefetch',blob}});
 else if(host==='macos')page.context.publishTypingMetricsData({manifest:native.manifest,initial_data:native.range,app_icons:{},kc_layout:{}},{manifest_revision:1,assets_revision:1});
 else page.context.__hostBridgeResponse('metrics_typing_bridge',false,encodeURIComponent(JSON.stringify(blob)));
 if(sensitive)page.elements.get('btn_case_sensitive').classList.add('active');else page.elements.get('btn_case_sensitive').classList.remove('active');page.context.apply_local_filters();
 for(const tab of ['c','bg','tg']){
  vm.runInContext('app_state.current_tab='+JSON.stringify(tab),page.context);page.context.render_current_tab();page.timers.at(-1)();
  const rows=JSON.parse(vm.runInContext('JSON.stringify(app_state.rendered_list.map(r=>({key:r.key,count:r.count})))',page.context));
  const expected=Object.values(native.range.historical[tab]).reduce((n,row)=>n+row.c,0),actual=rows.reduce((n,row)=>n+row.count,0);
  controls++;if(actual!==expected)failures.push({host,sensitive,id,tab,expected,actual,rows,nativeKeys:Object.keys(native.range.historical[tab])});
 }
}
console.log(JSON.stringify({controls,failures},null,2));
assert.equal(controls,90);
assert.deepEqual(failures,[],'valid native Unicode pairs and triples must never be decoded as another text sequence');
