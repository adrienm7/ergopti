# Extraction creation ownership, candidate v2

The previous candidate remains frozen in `../file-port-v1`; its root-level
source snapshot also remains unchanged. This version adds installation-specific
native creation receipts. It does not borrow config/API source-WAL authority.

Preparation exclusively creates `.creation-<private-ticket>.jsonl` under the
held managed root. Its durable header binds the ticket, root and journal
physical identities and exact catalogue/archive source hashes. Every stage,
directory and file has an ordered durable intent record, followed by its exact
native physical identity before any file content writes. The output stream
that created each extracted file also computes its final digest before closing;
the final manifest binds that identity and digest.

Inventory validation enumerates only one level in directories whose exact
native handles are already held. Unknown or reparse children refuse before any
recursive traversal, including on Windows PowerShell 5.1.

The CLI emits an initial `creation-owned` receipt before extraction and a final
prepared/refused result. Physical completion consumers must handle these JSON
frames as private evidence; they are not UI or logical success acknowledgements.
A caught extraction refusal includes the final journal identity/hash. An abrupt
process death can leave an older captured receipt: cleanup must reject a changed
journal image rather than acquiring permission from the later image.

`cleanup_partial` requires the exact original journal identity and captured
SHA-256. It holds the complete declared native inventory and verifies physical
identities before removal. Foreign files, replacements, reparses or present
intent-only objects refuse cleanup. Already absent owned objects support retry;
the journal retires only after classified stage absence. Missing journal cannot
substitute for a captured ownership receipt and is an error. Creation-before-
identity windows remain discoverable ambiguous debt; they are not automatically
claimed or recursively removed. A fully published/retired stage can retire its
creation journal through the same exact receipt without touching its version.

The original 20 native cases/assertions are preserved. Five added native cases
cover interruption before the first extracted byte with real native identities,
wrong journal image, foreign file replacement, actual partial retirement, and
intent-only crash-window refusal. The last fixture repairs only through its own
independently retained original creation handle; a real crash has no such proof.
All **25 native cases are unexecuted**.

The official portable PowerShell 7.4.13 Linux parser obtained ASTs for the helper,
test and runtime launcher with zero diagnostics and unchanged source hashes.
That initial receipt is retained as `parser-v2-pre-inventory.json`. A second
exclusive AST-only slot parsed the final bounded inventory correction with zero
diagnostics and unchanged hashes; `parser-v2.json` contains that final receipt.
No candidate script was dot-sourced, no Add-Type/Win32 API ran, and no native
test or archive extraction ran. This parse does not qualify Windows PowerShell
5.1 runtime semantics or the native APIs. Exact evidence is in `parser-v2.json`
and `PARSER-COMMANDS.md`.

Remaining independent prerequisites are the real adapter construction receipt,
large native download owner, immutable runtime-version loading lease, shared
consent/readiness composition and Windows native unit/E2E/package/install proof.
This v2 source still needs independent review before adoption.
