# Official Group 6 terminal receiving

Manual run 38166806073 attempt 1 received through completion on exact original
producer 5173d4f: 43 jobs, 29 success, eight failure, six skipped. Release is
skipped. All 17 Linux install jobs succeed; Windows and macOS delivery is not
qualified. Exact owned CI lease was compared, deleted and read back absent.

The later reader589 receives the actual completed AMD clock metadata without
changing producer provenance. Pure JSON comparison cannot authenticate itself;
actual API, received ZIP and 424 independently joined producer blobs were
received separately. Earlier frozen source receipt still says terminal pending;
this companion records the subsequent terminal observation without rewriting it.
Kernel identity is unknown and Swift factory remains held.

Raw CoreJS and Windows logs preserve real timeout failures. The hosted facts156
cause remains unknown; the local performance proposal is not historical proof.
No tests, watchdogs, assertions, CI refs, other owners or release workflows are
modified by this archive. Items36/62 stay open; no Dev integration.
