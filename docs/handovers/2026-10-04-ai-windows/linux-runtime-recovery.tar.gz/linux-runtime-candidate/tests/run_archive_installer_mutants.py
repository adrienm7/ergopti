"""Causal scratch mutants. Expected receipts are frozen in independent fixtures."""
import argparse
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("lua")
parser.add_argument("candidate")
args = parser.parse_args()
candidate = Path(args.candidate).resolve()
transaction_path = "modules/llm/ollama_archive_installer.lua"
files_path = "modules/llm/ollama_install_files.lua"
mutants = (
    ("consent bypass", transaction_path,
     "or options.explicit_consent ~= true or not valid_asset(asset)",
     "or false or not valid_asset(asset)",
     "test_archive_installer_seams.lua", "explicit consent prevents automatic installation"),
    ("owner overwrite", transaction_path,
     'if owners[owner] then files = nil finish("install_owner_busy") return operation end',
     'if false then files = nil finish("install_owner_busy") return operation end',
     "test_archive_installer_seams.lua", "same target cannot acquire live predecessor"),
    ("borrowed cancellation/exit", transaction_path,
     "if not checked or retired ~= true then break end",
     "if not checked then break end",
     "test_archive_installer_seams.lua", "ordered receipts wait for every native retirement"),
    ("source bypass", transaction_path,
     "return ok and allowed == true and not cancelled and not terminal",
     "return not cancelled and not terminal",
     "test_archive_installer_seams.lua", "stale source suppresses archive callback and successors"),
    ("mutable asset retention", transaction_path,
     "local asset = {}",
     'local asset = type(options) == "table" and options.asset or {}',
     "test_archive_installer_seams.lua", "authorizer cannot mutate admitted official asset scalars"),
    ("digest bypass", files_path,
     "or digest ~= asset.sha256 or path ~= paths.archive",
     "or false or path ~= paths.archive",
     "test_install_files_seams.lua", "wrong authoritative checksum cannot extract"),
    ("borrowed mv zero skip", files_path,
     'if not owner.observe_publication() then return false, "install_publication_not_owned" end',
     'owner.published = true',
     "test_install_files_seams.lua", "mv zero exit with skipped foreign target is refused"),
    ("borrowed same-name identity", files_path,
     "and first.ino == second.ino and first.uid == second.uid",
     "and true and first.uid == second.uid",
     "test_install_files_seams.lua", "same named replacement is not downloaded archive"),
    ("post-hash inode bypass", files_path,
     'if not same(archive_identity, archive) then return nil, "archive_identity_changed" end',
     'if false then return nil, "archive_identity_changed" end',
     "test_install_files_seams.lua", "post-hash replacement cannot become extraction input"),
    ("link-kind bypass", files_path,
     "value.type ~= kind",
     "false",
     "test_install_files_seams.lua", "intermediate bin symlink cannot redirect executable chmod"),
)
for name, source_path, before, after, fixture, expected in mutants:
    source = (candidate / source_path).read_text()
    if source.count(before) != 1:
        raise RuntimeError(f"mutant source seam changed: {name}")
    with tempfile.TemporaryDirectory(prefix="ergopti-install-mutant-") as temporary:
        root = Path(temporary)
        target = root / source_path
        target.parent.mkdir(parents=True)
        target.write_text(source.replace(before, after, 1))
        result = subprocess.run(
            [args.lua, str(candidate / "tests" / fixture), str(root)],
            capture_output=True, text=True, timeout=15,
        )
        transcript = result.stdout + result.stderr
        if result.returncode == 0 or f"FAIL {expected}:" not in transcript:
            raise RuntimeError(f"mutant escaped its exact independent assertion: {name}\n{transcript}")
        print(f"REJECTED {name}: {expected}")
print(f"Archive installer causal mutants: {len(mutants)} rejected, 0 escaped")
