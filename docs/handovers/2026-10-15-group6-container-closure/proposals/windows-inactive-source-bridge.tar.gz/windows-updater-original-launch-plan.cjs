// Private source-only binding proposal; no runtime admission or native launch.
'use strict';

const path = require('node:path');

const PROVIDER_SHA256 = 'd02912f92dc73444b1f7ff8ff03ea3df91e292523c42aa632b0c3f0f30beee36';
const FILTERS = Object.freeze([
	'(updater-channel-replacement-transaction)',
	'(updater-global-config-barrier)',
	'(updater-channel-inherited-critical)'
]);

function refuse(message) {
	throw new TypeError(message);
}

function record(value, keys) {
	if (!value || Object.getPrototypeOf(value) !== Object.prototype)
		refuse('Plain declaration required.');
	const own = Reflect.ownKeys(value);
	if (own.length !== keys.length || own.some((key) => !keys.includes(key)))
		refuse('Declaration shape refused.');
	for (const key of keys) {
		const field = Object.getOwnPropertyDescriptor(value, key);
		if (!field || !Object.hasOwn(field, 'value')) refuse('Accessor declaration refused.');
	}
	return value;
}

function digest(value, length = 64) {
	if (typeof value !== 'string' || !new RegExp(`^[0-9a-f]{${length}}$`).test(value))
		refuse('Digest declaration refused.');
	return value;
}

function windowsPath(value) {
	if (
		typeof value !== 'string' ||
		!value.isWellFormed() ||
		!/^[A-Za-z]:\\/.test(value) ||
		/[\x00-\x1f/]/.test(value)
	)
		refuse('Explicit local Windows path required.');
	const parts = value.slice(3).split('\\');
	if (
		!parts.length ||
		parts.some(
			(part) =>
				!part || part === '.' || part === '..' || /[:<>"|?*]/.test(part) || /[ .]$/.test(part)
		)
	)
		refuse('Path alias refused.');
	if (path.win32.normalize(value) !== value) refuse('Path normalization refused.');
	return value;
}

function image(value) {
	record(value, ['path', 'sha256']);
	return { path: windowsPath(value.path), sha256: digest(value.sha256) };
}

function explicitEnvironment(value) {
	if (!value || Object.getPrototypeOf(value) !== Object.prototype)
		refuse('Explicit environment declaration required.');
	const output = {};
	const seen = new Set();
	for (const key of Reflect.ownKeys(value)) {
		if (typeof key !== 'string' || !key || /[=\x00]/.test(key)) refuse('Environment name refused.');
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		if (!Object.hasOwn(descriptor, 'value')) refuse('Environment accessor refused.');
		const content = descriptor.value;
		const upper = key.toUpperCase();
		if (seen.has(upper) || /^(NODE_|PYTHON|DOTNET_|COMPLUS_)/.test(upper))
			refuse('Environment alias or preload refused.');
		if (typeof content !== 'string' || !content.isWellFormed() || content.includes('\0'))
			refuse('Environment value refused.');
		seen.add(upper);
		Object.defineProperty(output, key, { value: content, enumerable: true });
	}
	if (
		!seen.size ||
		Buffer.byteLength(
			Object.entries(output)
				.map(([key, content]) => `${key}=${content}`)
				.join('\0') + '\0\0',
			'utf16le'
		) > 4194304
	)
		refuse('Environment size refused.');
	return output;
}

function freeze(value) {
	if (value && typeof value === 'object') {
		for (const member of Object.values(value)) freeze(member);
		Object.freeze(value);
	}
	return value;
}

/**
 * Binds declarations to the intended original argv/source/runtime/caller cut.
 * The expected declaration is also data, never proof of a trusted caller.
 * This function has no provider port and cannot grant execution authority.
 */
function bindLaunchRequirements(expected, request) {
	record(expected, [
		'role',
		'candidate',
		'source_manifest_sha256',
		'caller',
		'runtime',
		'entry',
		'nonce',
		'captures',
		'filter',
		'dry_run'
	]);
	record(request, [
		'role',
		'candidate',
		'source_manifest_sha256',
		'caller',
		'runtime',
		'entry',
		'nonce',
		'captures',
		'environment',
		'filter',
		'dry_run'
	]);
	if (!['original23', 'interpreted-startup'].includes(request.role))
		refuse('Closed consumer role required.');
	if (
		request.role !== expected.role ||
		request.filter !== expected.filter ||
		request.dry_run !== expected.dry_run
	)
		refuse('Consumer role/filter declaration changed.');
	const candidate = digest(request.candidate, 40);
	const manifest = digest(request.source_manifest_sha256);
	if (
		candidate !== digest(expected.candidate, 40) ||
		manifest !== digest(expected.source_manifest_sha256)
	)
		refuse('Source declaration changed.');
	const bound = {};
	for (const name of ['caller', 'runtime', 'entry']) {
		const given = image(request[name]);
		const wanted = image(expected[name]);
		if (given.path !== wanted.path || given.sha256 !== wanted.sha256)
			refuse(`${name} declaration changed.`);
		bound[name] = given;
	}
	if (!/\.exe$/i.test(bound.runtime.path) || !/\.ahk$/i.test(bound.entry.path))
		refuse('Interpreted AHK source/image pair required.');
	if (
		typeof request.nonce !== 'string' ||
		!/^[0-9a-f]{32}$/.test(request.nonce) ||
		request.nonce !== expected.nonce
	)
		refuse('Nonce declaration changed.');
	record(request.captures, ['stdout', 'stderr']);
	record(expected.captures, ['stdout', 'stderr']);
	const captures = {};
	for (const name of ['stdout', 'stderr']) {
		captures[name] = digest(request.captures[name]);
		if (captures[name] !== digest(expected.captures[name])) refuse('Capture declaration changed.');
	}
	if (captures.stdout === captures.stderr) refuse('Capture identities must remain distinct.');
	const environment = explicitEnvironment(request.environment);
	let argv;
	let lifetime;
	if (request.role === 'original23') {
		if (!FILTERS.includes(request.filter) || typeof request.dry_run !== 'boolean')
			refuse('Original cohort/filter declaration refused.');
		argv = ['/ErrorStdOut', bound.entry.path, `--only=${request.filter}`];
		if (request.dry_run) argv.push('--dry-run');
		lifetime = 300000;
	} else {
		if (request.filter !== null || request.dry_run !== false)
			refuse('Mixed startup/cohort declaration refused.');
		const keys = Object.fromEntries(
			Object.entries(environment).map(([key, value]) => [key.toUpperCase(), value])
		);
		if (
			keys.ERGOPTI_STARTUP_SMOKE_NONCE !== request.nonce ||
			keys.ERGOPTI_STARTUP_SMOKE_DIR !== keys.LOCALAPPDATA
		)
			refuse('Isolated startup environment changed.');
		windowsPath(keys.LOCALAPPDATA);
		argv = ['/ErrorStdOut', bound.entry.path];
		lifetime = 120000;
	}
	return freeze({
		status: 'SOURCE_BINDING_ONLY_NO_RUNTIME_AUTHORITY',
		executable: false,
		provider_qualified: false,
		native23_qualified: false,
		role: request.role,
		candidate,
		source_manifest_sha256: manifest,
		...bound,
		nonce: request.nonce,
		captures,
		environment,
		argv,
		original_budget_ms: lifetime,
		original_clock_scope:
			request.role === 'original23'
				? 'shared_collector_deadline_no_rearm'
				: 'one_original_fixture_deadline',
		provider_source_sha256: PROVIDER_SHA256,
		provider_roles_unchanged: ['node-inert', 'powershell-inert'],
		unreceived_native_contract: [
			'externally_authenticated_top_level_caller',
			'production_role_and_exact_argv',
			'original_lifetime_without_30000ms_truncation',
			'held_runtime_and_complete_source_dependency_closure',
			'original_caller_owned_capture_transfer',
			'original23_stream_and_cancel_protocol',
			'actual_suspended_creation_image_mapping_and_descendant_retirement'
		]
	});
}

module.exports = { bindLaunchRequirements, PROVIDER_SHA256, FILTERS };
