# Private essential-save selection plan

Only passive byte copying/hashing, manifest construction and finite tar packing are authorized here. No subject/test/helper/parser/native execution, canonical/Git/index/ref/environment change, adoption or public save is performed.

The explicit allowlist is stored in `selection.json`. Each selected file must be regular, read twice with stable byte identity, copied byte-exact to an inert relative `.raw` member, and bound by original path/bytes/SHA in the capsule manifest. No recursive checkout or binary collection is allowed. The manifest and archive use deterministic member order/metadata; Parent reviews the final count/bytes/hashes before any public save.

Selected sections:

- **Mac40:** consumer proposal/deltas and necessary exact two preimages; frozen independent EXPECTED-FAILURES and prior30-name manifest; published dependency reference/pins; exact receiving payload/manifests/pins, actual parent receipt and complete finite raw child/status/source/packet frames; independent consumer/receiver reviews. No real G5 publisher code or integrated MacV3 proposal is copied.
- **AHK metadata/guard:** whole manually authored model/component/normal-graph controls and original Json/number/catalogue include graph; original metadata/corpus pins and independent immutable data; V3 closed policy guard plus byte-identical original/V2 controls and two escape controls, Source receipts/reviews and exact Root enrollment proposal. All native/parser/encoding/guard receiving remains UNRUN. No generated product outputs or loader publication are adopted.
- **Connected107/108:** four V3 baseline files from V4's exact preimages; narrow Shift V4 and union deltas, original inverse/composition records, controlled opaque-Reader protocol/row assertions. Existing public129 capsule lacks these new exact slices. No complete canonical checkout or extra whole postimage set is needed.
- **Root/G1 warning:** current source-only review only; existing public archive/reference suffices. No thirty-two-span patch or separately owned fixtures are copied.
- **Current status/reference:** this English handover, exact current parent facts and existing public capsule manifest hash/reference. Integrated MacV3/LinuxV3 software and the current Linux positive-fixture correction remain Parent-owned and are referenced only.

Restoration from `.raw` members preserves the original bytes; each original destination is in the manifest. Reconstruction is review material, not permission to apply a patch. Stored absolute paths/old statuses in original raw receipts are historical provenance; use the new handover for current status. Existing test corpora/assertions/names are never regenerated. Source/runtime/device prerequisites and items16/38 remain separate.
