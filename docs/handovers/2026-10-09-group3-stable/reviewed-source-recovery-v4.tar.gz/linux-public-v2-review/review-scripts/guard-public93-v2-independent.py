"""Run only the unchanged focused source guard in an immutable-object overlay."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

r=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-public-join-v2-independent')
v1=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v1/freeze')
wrapper=(v1/'run_guard.cjs').read_text()
wrapper=wrapper.replace('const packet=__dirname;', 'const packet='+json.dumps(str(r/'projection'))+';')
start=wrapper.index('  const dest=path.join(packet,')
end=wrapper.index('  const encoding=',start)
wrapper=wrapper[:start]+"  deps[relative]=require('crypto').createHash('sha256').update(bytes).digest('hex');\n"+wrapper[end:]
start=wrapper.index("process.on('exit',")
end=wrapper.index('\nconst target=',start)
wrapper=wrapper[:start]+"process.on('exit',()=>fs.writeFileSync(process.argv[4],JSON.stringify({source:sha,dependencies:deps},null,2)+'\\n'));"+wrapper[end:]
(r/'focused-guard-overlay.cjs').write_text(wrapper)
node=shutil.which('node');assert node
results=[]
cases=[('candidate',{},None),('original',{},str(v1/'preimages/tools/test/test-tap-hold-key-catalog-single-source.cjs'))]
for path in sorted((v1/'guard-variants').glob('*.json')):
 if path.stem in ['candidate','original']:continue
 values=json.loads(path.read_text())
 exact={key:str(v1/'guard-variants'/Path(value).name) for key,value in values.items()}
 for value in exact.values():assert Path(value).is_file()
 cases.append((path.stem,exact,None))
for name,mapping,target in cases:
 map_path=r/('focused-guard-'+name+'.json');map_path.write_text(json.dumps(mapping)+'\n')
 target=target or str(v1/'candidate/tools/test/test-tap-hold-key-catalog-single-source.cjs')
 command=[node,str(r/'focused-guard-overlay.cjs'),str(map_path),target,str(r/('focused-guard-'+name+'-reads.json'))]
 proc=subprocess.run(command,cwd=r,capture_output=True,timeout=30)
 log=r/('focused-guard-'+name+'.log');log.write_bytes(proc.stdout+proc.stderr)
 assert proc.returncode==(0 if name=='candidate' else 1),(name,proc.stdout,proc.stderr)
 assert b'MODULE_NOT_FOUND' not in proc.stderr and b'ENOENT' not in proc.stderr
 rows={'case':name,'exit':proc.returncode,'command':command,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 results.append(rows);print(name,proc.returncode,flush=True)
(r/'focused-guard-results.json').write_text(json.dumps({'results':results,'only_focused_guard_not_whole_JS':True,'canonical_writes':False,'all_source_reads':'immutable cbb objects, owned frozen proposals, existing node dependency'},indent=2)+'\n')

# Preserve each original executable error assertion using an actual JS parser.
parser='''const fs=require('fs'), acorn=require('/workspace/ergopti/node_modules/acorn');
const [oldFile,newFile,out]=process.argv.slice(2);
function calls(file){const text=fs.readFileSync(file,'utf8'),ast=acorn.parse(text,{ecmaVersion:'latest'}),found=[];
 function walk(n){if(!n||typeof n!=='object')return;
  if(n.type==='CallExpression' && n.callee.type==='MemberExpression' && n.callee.object.name==='errors' && n.callee.property.name==='push')found.push(text.slice(n.start,n.end));
  for(const v of Object.values(n)){if(Array.isArray(v))v.forEach(walk);else if(v && typeof v==='object')walk(v)}
 }walk(ast);return found;
}
const old=calls(oldFile),post=calls(newFile);if(old.length<30)throw Error('original guard assertion floor');
let i=0;for(const body of old){const at=post.indexOf(body,i);if(at<0)throw Error('original error assertion changed: '+body);i=at+1;}
fs.writeFileSync(out,JSON.stringify({original_error_assertions:old.length,post_error_assertions:post.length,all_original_executable_assertion_bodies_exact_ordered:true},null,2)+'\\n');
console.log('Original executable guard error assertions preserved: '+old.length+'/'+post.length);
'''
(r/'guard-assertion-preservation.cjs').write_text(parser)
proc=subprocess.run([node,str(r/'guard-assertion-preservation.cjs'),str(v1/'preimages/tools/test/test-tap-hold-key-catalog-single-source.cjs'),str(v1/'candidate/tools/test/test-tap-hold-key-catalog-single-source.cjs'),str(r/'guard-assertion-preservation.json')],capture_output=True)
(r/'guard-assertion-preservation.log').write_bytes(proc.stdout+proc.stderr)
assert proc.returncode==0,(proc.stdout,proc.stderr)
print(proc.stdout.decode().strip(),flush=True)
