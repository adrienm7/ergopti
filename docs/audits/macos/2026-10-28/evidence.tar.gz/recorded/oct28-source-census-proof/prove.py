import datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
from zoneinfo import ZoneInfo
repository=Path('/workspace/ergopti-macos-integration');driver=repository/'static/ergopti_plus/macos';shared=repository/'static/ergopti_plus/_shared';root=Path('/workspace/scratch/oct28-source-census-proof');cases=root/'cases';cases.mkdir(exist_ok=True)
helper=driver/'tests/helpers/init.lua';source=driver/'adapters/ledger_append.lua';anchor='MODULE: Durable SQL Ledger Append Ownership';assert source.read_text().count(anchor)==1
entry=root/'observe.lua';env=dict(os.environ);env['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:'+env.get('LD_LIBRARY_PATH','')
rows=[]
for label,prefix in [('ordinary','ordinary'),('newline','line\nbreak'),('tests-prefix','tests/checkout'),('posix-backslash-tests',r'literal\tests\checkout'),('quote-control',"quote' checkout")]:
 base=cases/label;fixture=base/prefix/'macos';(fixture/'tests/helpers').mkdir(parents=True,exist_ok=True);(fixture/'adapters').mkdir();shutil.copy2(helper,fixture/'tests/helpers/init.lua');shutil.copy2(source,fixture/'adapters/ledger_append.lua');(fixture.parent/'_shared').symlink_to(shared,target_is_directory=True)
 command=['lua',str(entry),str(fixture),str(driver),str(shared/'lua'),anchor,str(source)];result=subprocess.run(command,cwd=repository,env=env,capture_output=True,text=True,timeout=15)
 row={'case':label,'command':command,'actual_exit':result.returncode,'stderr':result.stderr,'stdout':result.stdout};assert result.returncode==0,row
 row['observation']=json.loads(result.stdout);data=row['observation'];assert data['root_exact'];assert data['actual_production_bytes']>0;assert data['source_file_owner']=='@'+str(driver/'tests/support/source_file.lua');assert data['command_lines_owner']=='@'+str(driver/'tests/support/command_lines.lua')
 if label in ['ordinary','quote-control']:assert data['source_exact'] and data['unit_exact'],row
 elif label=='newline':assert not data['source_call_ok'] and not data['unit_call_ok'] and 'source open failed' in data['source_error'] and 'No such file' in data['source_error'],row
 else:assert data['source_call_ok'] and data['source_type']=='nil' and data['unit_call_ok'] and data['unit_type']=='nil' and 'no production file contains' in data['unit_error'],row
 rows.append(row)
receipt={'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'current_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repository,text=True).strip(),'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'production_source':str(source),'production_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'anchor':anchor,'scope':'Owned minimal root uses actual helper copy + one unchanged actual productionLua file. SourceFile/CommandLines/json/configkeys/format dependencies are actual repository owners, not doubles; no production module executed.','cases':rows,'production_or_index_ref_edits':False}
(root/'proof.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'proof':str(root/'proof.json'),'helper_sha256':receipt['helper_sha256'],'summary':[{ 'case':r['case'],'source_exact':r['observation']['source_exact'],'unit_exact':r['observation']['unit_exact'],'error':r['observation']['source_error'] or r['observation']['unit_error']}for r in rows]},indent=2))
