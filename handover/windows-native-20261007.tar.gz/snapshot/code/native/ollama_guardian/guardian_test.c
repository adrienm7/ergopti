#include "guardian.h"
#include <stdio.h>
#include <string.h>

#define CHECK(n, e) do { if (!(e)) { fprintf(stderr, "FAIL %s:%d: %s\n", n, __LINE__, #e); return 0; } } while (0)

typedef struct {
    int valid, parent, stop, query_ok, terminate_ok;
    uint32_t members, queries, terminations, closes;
    uintptr_t refuse_close;
    uint32_t close_calls[16];
    uint32_t closed_without_zero;
} World;

static int Validate(void *p, uintptr_t process, uintptr_t job) {
    World *w = p;
    return w->valid && process == 4u && job == 1u;
}
static int Parent(void *p, uintptr_t h) { return h == 2u ? ((World *)p)->parent : -1; }
static int Stop(void *p, uintptr_t h) { return h == 3u ? ((World *)p)->stop : -1; }
static int Query(void *p, uintptr_t h, uint32_t *n) {
    World *w = p;
    w->queries++;
    if (h != 1u || !w->query_ok) return 0;
    *n = w->members;
    return 1;
}
static int Terminate(void *p, uintptr_t h) {
    World *w = p;
    if (h != 1u) return 0;
    w->terminations++;
    return w->terminate_ok;
}
static int Close(void *p, uintptr_t h) {
    World *w = p;
    w->closes++;
    if (h < 16u) w->close_calls[h]++;
    if (h >= 10u && (!w->query_ok || w->members != 0u)) w->closed_without_zero++;
    return h != w->refuse_close;
}
static GG_Port Port(World *w) {
    GG_Port p = { w, Validate, Parent, Stop, Query, Terminate, Close };
    return p;
}
static World Healthy(void) {
    World w;
    memset(&w, 0, sizeof(w));
    w.valid = 1; w.query_ok = 1; w.terminate_ok = 1; w.members = 1u;
    return w;
}
static int Begin(const char *name, World *w, GG_Owner *o, GG_Content *f) {
    CHECK(name, GG_Init(o, 1u, 2u, 3u, 4u, f, 2u, Port(w)));
    CHECK(name, o->phase == GG_READY && o->job_bound && w->close_calls[4] == 1u);
    return 1;
}
static int StopRetains(void) {
    const char *n = "stop retains content until exact job zero";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.stop = 1;
    CHECK(n, GG_Step(&o) == GG_STOPPING && w.terminations == 1u && w.close_calls[10] == 0u);
    CHECK(n, GG_Step(&o) == GG_STOPPING && w.terminations == 1u && w.close_calls[11] == 0u);
    w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_RETIRED && w.close_calls[10] == 1u && w.close_calls[11] == 1u && w.closed_without_zero == 0u);
    return 1;
}
static int ParentDeath(void) {
    const char *n = "parent death retires exact bound job before files";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.parent = 1;
    CHECK(n, GG_Step(&o) == GG_STOPPING && w.terminations == 1u && w.close_calls[10] == 0u);
    w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_RETIRED && w.closed_without_zero == 0u);
    return 1;
}
static int CancelSuspended(void) {
    const char *n = "cancel suspended daemon waits for kernel member retirement";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.stop = 1;
    CHECK(n, GG_Step(&o) == GG_STOPPING && w.close_calls[10] == 0u);
    w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_RETIRED && o.queried_zero);
    return 1;
}
static int DisableEmpty(void) {
    const char *n = "disable after native idle closes without another terminate";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.stop = 1; w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_RETIRED && w.terminations == 0u && w.closed_without_zero == 0u);
    return 1;
}
static int QueryFailure(void) {
    const char *n = "query failure cannot impersonate empty job";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.query_ok = 0; w.parent = 1;
    CHECK(n, GG_Step(&o) == GG_STOPPING && w.close_calls[10] == 0u && o.first_error != 0u);
    w.query_ok = 1; w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_RETIRED && o.first_error != 0u && w.closed_without_zero == 0u);
    return 1;
}
static int TerminateFailure(void) {
    const char *n = "failed termination remains once only and diagnostic survives";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.parent = 1; w.terminate_ok = 0;
    CHECK(n, GG_Step(&o) == GG_STOPPING && w.terminations == 1u && o.first_error != 0u);
    CHECK(n, GG_Step(&o) == GG_STOPPING && w.terminations == 1u && w.close_calls[10] == 0u);
    w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_RETIRED && o.first_error != 0u);
    return 1;
}
static int CloseFailure(void) {
    const char *n = "uncertain file close retains job capability without retry";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.members = 0u; w.refuse_close = 10u;
    CHECK(n, GG_Step(&o) == GG_CLOSE_DEBT && f[0].uncertain && f[0].attempted);
    CHECK(n, GG_Step(&o) == GG_CLOSE_DEBT && w.close_calls[10] == 1u && w.close_calls[1] == 0u && o.job == 1u);
    return 1;
}
static int InvalidBinding(void) {
    const char *n = "foreign job relationship never authorizes terminate or close";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    w.valid = 0;
    CHECK(n, !GG_Init(&o, 1u, 2u, 3u, 4u, f, 2u, Port(&w)) && o.phase == GG_CONSTRUCTION_DEBT);
    w.parent = 1; w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_CONSTRUCTION_DEBT && w.queries == 0u && w.terminations == 0u && w.close_calls[10] == 0u);
    return 1;
}
static int DuplicateInit(void) {
    const char *n = "duplicate init cannot reset live ownership";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f));
    CHECK(n, !GG_Init(&o, 9u, 9u, 9u, 9u, f, 2u, Port(&w)) && o.job == 1u && o.phase == GG_READY);
    return 1;
}
static int NaturalExit(void) {
    const char *n = "natural job idle releases files once without stop Boolean";
    World w = Healthy(); GG_Owner o = {0}; GG_Content f[2] = {{10u,0,0},{11u,0,0}};
    CHECK(n, Begin(n, &w, &o, f)); w.members = 0u;
    CHECK(n, GG_Step(&o) == GG_RETIRED && w.terminations == 0u);
    CHECK(n, GG_Step(&o) == GG_RETIRED && w.close_calls[10] == 1u && w.close_calls[11] == 1u);
    return 1;
}
int main(void) {
    int (*cases[])(void) = { StopRetains, ParentDeath, CancelSuspended, DisableEmpty, QueryFailure, TerminateFailure, CloseFailure, InvalidBinding, DuplicateInit, NaturalExit };
    const char *names[] = { "stop retains", "parent death", "cancel suspended", "disable idle", "query failure", "terminate failure", "close debt", "foreign binding", "duplicate init", "natural idle" };
    size_t i;
    for (i = 0; i < sizeof(cases)/sizeof(cases[0]); ++i) {
        if (!cases[i]()) { printf("not ok %zu - %s\n", i+1u, names[i]); return 1; }
        printf("ok %zu - %s\n", i+1u, names[i]);
    }
    return 0;
}
