from pathlib import Path
import hashlib,json,re,subprocess,time,os,tempfile
b=Path('/workspace/.ergopti-cloud/resume-personal-topology-exact-causal')
source=b/'source';producer=source/'static/ergopti_plus/linux/infra/file_watchers.lua';test=source/'static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua'
sha=lambda data:hashlib.sha256(data).hexdigest()
corpus=(b/'candidate-tests.lua').read_bytes();literal=(b/'literal-producer.lua').read_bytes();candidate=(b/'candidate3-prepared.lua').read_bytes()
assert test.read_bytes()==corpus and sha(corpus)=='2340d5e638fbf0660839991d3f96de74d55908e805c53028f5b3e9552d276658'
assert sha(literal)=='c0809fe78b188fa84afa2cba16bf557b081131a9d43d1f28b754881131ccfdb4'
assert sha(candidate)=='ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768'
expected=json.loads((b/'expected-subjects.json').read_text())['names'];assert len(expected)==83
optional='file_watchers subsecond polling: detects same-second edits with installed posix';assert expected.count(optional)==1
rows=[]
def run(label,runtime,mode,image):
 assert test.read_bytes()==corpus
 producer.write_bytes(image);start=time.monotonic()
 cmd=[runtime,str(b/'runner.lua'),mode];stem=f'{label}-{mode}-{runtime}'
 temporary_root=Path(tempfile.mkdtemp(prefix='ergopti_topology_exact_',dir='/var/tmp/ergopti-cloud-validation'))
 child_env=os.environ.copy();child_env.update({'TMPDIR':str(temporary_root),'TEMP':str(temporary_root)})
 with(b/(stem+'.stdout.log')).open('wb')as out,(b/(stem+'.stderr.log')).open('wb')as err:
  child=subprocess.run(cmd,cwd=source/'static/ergopti_plus/linux',stdout=out,stderr=err,check=False,env=child_env)
 stdout=(b/(stem+'.stdout.log')).read_text();result=json.loads(stdout.splitlines()[-1])
 passing=re.findall(r'^  ok   (.*)$',stdout,re.M);failures=result['failures']or[];failed_names=[row['name']for row in failures]
 wanted=[name for name in expected if mode!='global-absent'or name!=optional]
 remaining=[str(p)for p in temporary_root.iterdir()]
 if not remaining:temporary_root.rmdir()
 row={'label':label,'mode':mode,'runtime':runtime,'command':cmd,'producer_sha256':sha(image),'test_sha256':sha(corpus),'child_exit_code':child.returncode,'passed':result['passed'],'failed':result['failed'],'passing_names':passing,'failures':failures,'executed_topology_subjects':sum(name.startswith('(linux-watch-topology)')for name in passing+failed_names),'controlled_posix_refusals':result['controlled_posix_refusals'],'original_installed_posix_optional_unavailable':1 if mode=='global-absent'else 0,'temporary_root':str(temporary_root),'environment_overrides':{'TMPDIR':str(temporary_root),'TEMP':str(temporary_root)},'remaining_owned_fixture_paths':remaining,'elapsed_seconds':round(time.monotonic()-start,3),'stdout_sha256':sha((b/(stem+'.stdout.log')).read_bytes()),'stderr_sha256':sha((b/(stem+'.stderr.log')).read_bytes())}
 (b/(stem+'-status.json')).write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
 print(json.dumps({key:row[key]for key in ['label','mode','runtime','child_exit_code','passed','failed','executed_topology_subjects']}),flush=True)
 assert producer.read_bytes()==image and test.read_bytes()==corpus
 assert not remaining and sorted(passing+failed_names)==sorted(wanted)and row['executed_topology_subjects']==34
 assert len(passing)==row['passed']and len(failed_names)==row['failed']
 assert all(name.startswith('(linux-watch-topology)')for name in failed_names),'original prefix subject failed'
 if mode=='global-absent':assert row['controlled_posix_refusals']>0
 if label=='literal':assert child.returncode==1 and row['failed']>0
 else:assert child.returncode==0 and row['failed']==0
try:
 for runtime in('lua','luajit'):
  for mode in('available','global-absent'):run('literal',runtime,mode,literal)
 for runtime in('lua','luajit'):
  for mode in('available','global-absent'):run('restored',runtime,mode,candidate)
finally:
 producer.write_bytes(candidate)
 (b/'exact-causal-matrix.json').write_text(json.dumps({'state':'COMPLETE'if len(rows)==8 else'INCOMPLETE','test_sha256':sha(corpus),'literal_producer_sha256':sha(literal),'restored_producer_sha256':sha(candidate),'restoration_sha256':sha(producer.read_bytes()),'rows':rows},indent=2)+'\n')
