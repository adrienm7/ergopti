"""Real POSIX bootstrap cleanup; Swift/Security/client dependencies are modeled.

This control invokes the frozen real setUpClass and real builder/environment
implementation. It never launches a compiler, Security command, or native child.
All files belong to one private outer temporary-directory owner.
"""

import hashlib
import importlib.abc
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

BASE = Path(__file__).resolve().parent
PACKET = BASE / "prospective-candidate"
SUPPORT = PACKET / "static/ergopti_plus/macos/tests/support"
REPOSITORY = Path("/workspace/ergopti")
FACTS = {}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ModeledNativeOwner:
    """Only compiler/signing/Security are modeled; root replacement is real."""

    native = True
    groups = object()
    closed = False
    trust_attempted = False
    keychain_created = False

    def __init__(self):
        self.command_group_debt = []
        self.command_file_debt = []
        self.calls = []
        self.close_calls = 0

    def _command(self, arguments, *, timeout=15, deadline=None):
        self.calls.append((list(arguments), timeout, deadline))
        if arguments[:2] == ["/usr/bin/xcrun", "swiftc"]:
            executable = Path(arguments[arguments.index("-o") + 1])
            executable.write_bytes(b"EXPLICIT MODELED SWIFT IMAGE: NO NATIVE CREDIT\n")
            executable.chmod(0o700)
        return 0, b""

    def close(self):
        self.close_calls += 1
        self.closed = True

    def receiving_facts(self):
        return {"active": 0}


class RootReplacementControl(unittest.TestCase):
    def test_same_name_foreign_root_survives_actual_bootstrap_cleanup(self):
        client_path = SUPPORT / "native_http_wire_client_receiving.py"
        builder_path = SUPPORT / "native_http_fixture_builder.py"
        FACTS["client_sha256"] = hashlib.sha256(client_path.read_bytes()).hexdigest()
        FACTS["builder_sha256"] = hashlib.sha256(builder_path.read_bytes()).hexdigest()
        FACTS["qualification"] = (
            "actual POSIX files; modeled compiler/Security; no native credit"
        )
        client = load("root_replacement_real_client", client_path)
        real_spec = importlib.util.spec_from_file_location
        real_mkdtemp = tempfile.mkdtemp
        owner = ModeledNativeOwner()
        with tempfile.TemporaryDirectory(prefix="ergopti-root-counter-") as outer_name:
            outer = Path(outer_name)
            self.addCleanup(
                lambda: FACTS.update(outer_private_directory_retired=not outer.exists())
            )
            source_root = outer / "source"
            source_root.mkdir(mode=0o700)
            state = {}

            class BuilderLoader(importlib.abc.Loader):
                def create_module(self, spec):
                    return None

                def exec_module(self, module):
                    module.__file__ = str(builder_path)
                    exec(
                        compile(builder_path.read_bytes(), str(builder_path), "exec"),
                        module.__dict__,
                    )
                    module.ROOT = source_root
                    for relative in module.SOURCE_INPUTS:
                        source = PACKET / relative
                        if not source.is_file():
                            source = REPOSITORY / relative
                        target = source_root / relative
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(source.read_bytes())
                    original = module.OwnedFixtureBuild

                    class ReplacedAfterRealBuild(original):
                        def _root_owned(self):
                            try:
                                return super()._root_owned()
                            except module.BuildRefused as failure:
                                state.setdefault("root_refusal", failure)
                                raise

                        def build(self):
                            result = super().build()
                            retained = self.root.with_name(
                                self.root.name + "-exact-owned"
                            )
                            self.root.rename(retained)
                            self.root.mkdir(mode=0o700)
                            marker = self.root / "foreign-owner-marker"
                            marker.write_bytes(b"KEEP FOREIGN ROOT\n")
                            state.update(
                                root=self.root, retained=retained, marker=marker
                            )
                            FACTS["owned_root_identity"] = [
                                self.root_identity.st_dev,
                                self.root_identity.st_ino,
                            ]
                            foreign = self.root.lstat()
                            FACTS["foreign_root_identity"] = [
                                foreign.st_dev,
                                foreign.st_ino,
                            ]
                            FACTS["foreign_present_before_environment"] = (
                                marker.is_file()
                            )
                            return result

                    module.OwnedFixtureBuild = ReplacedAfterRealBuild

            def builder_spec(name, location, *arguments, **keywords):
                if name == "owned_native_http_build":
                    self.assertEqual(Path(location), builder_path)
                    return importlib.util.spec_from_loader(name, BuilderLoader())
                return real_spec(name, location, *arguments, **keywords)

            def private_mkdtemp(*arguments, **keywords):
                keywords["dir"] = outer
                return real_mkdtemp(*arguments, **keywords)

            caught = None
            try:
                with (
                    mock.patch.object(sys, "platform", "darwin"),
                    mock.patch.dict(
                        sys.modules,
                        {
                            "httpx": SimpleNamespace(__version__="0.28.1"),
                            "huggingface_hub": SimpleNamespace(__version__="1.13.0"),
                        },
                    ),
                    mock.patch.object(client.wire, "WireFixture", return_value=owner),
                    mock.patch.object(
                        importlib.util,
                        "spec_from_file_location",
                        side_effect=builder_spec,
                    ),
                    mock.patch.object(tempfile, "mkdtemp", side_effect=private_mkdtemp),
                ):
                    try:
                        client.RealNativeClientReceiving.setUpClass()
                    except BaseException as failure:
                        caught = failure
                FACTS.update(
                    bootstrap_failure_type=type(caught).__name__,
                    exact_root_refusal_preserved=caught is state.get("root_refusal"),
                    fixture_close_calls=owner.close_calls,
                    fixture_closed=owner.closed,
                    foreign_present_after_bootstrap=state["marker"].is_file(),
                    retained_owned_root_present=state["retained"].is_dir(),
                    modeled_command_count=len(owner.calls),
                    command_group_debt=len(owner.command_group_debt),
                    command_file_debt=len(owner.command_file_debt),
                )
                self.assertIs(caught, state["root_refusal"])
                self.assertEqual(owner.close_calls, 1)
                self.assertTrue(owner.closed)
                self.assertTrue(state["retained"].is_dir())
                self.assertTrue(
                    state["marker"].is_file(),
                    "Caller deleted a genuine same-name foreign root",
                )
            finally:
                # The exact private outer owner retires both genuine names.
                for key in ("root", "retained"):
                    path = state.get(key)
                    if path is not None and path.exists():
                        shutil.rmtree(path)
                FACTS["outer_exact_root_names_retired"] = all(
                    not state[key].exists()
                    for key in ("root", "retained")
                    if key in state
                )
        FACTS["outer_private_directory_retired"] = not outer.exists()


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(RootReplacementControl)
    )
    (BASE / "root-replacement-receiving.json").write_text(
        json.dumps(
            {
                "facts": FACTS,
                "run": result.testsRun,
                "failures": len(result.failures),
                "errors": len(result.errors),
                "skipped": len(result.skipped),
            },
            sort_keys=True,
            indent=2,
        )
        + "\n"
    )
    raise SystemExit(not result.wasSuccessful())
