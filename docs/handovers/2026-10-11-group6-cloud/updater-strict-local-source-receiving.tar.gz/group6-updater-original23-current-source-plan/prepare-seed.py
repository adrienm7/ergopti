from pathlib import Path
import json,subprocess,hashlib,shutil
root=Path(__file__).resolve().parent;repo=Path('/workspace/ergopti');ref='d316a83127fb212232f2bcd7fd8c6d63b0f1e4a8'
seed=root/'immutable-seed';seed.mkdir(exist_ok=True)
inputs=json.loads((root/'proposal-candidate/tools/ci/windows-updater-original-diagnostic-cohort-inputs.json').read_text())
files=set(inputs['source_sha256'])|{'tools/ci/manual-ci-lanes.cjs','tools/ci/dev-release-qualification.cjs','.github/ci/dev_release_qualification_exceptions.json','.github/ci/stable_release_qualification_exception.json','.github/workflows/ci.yml','.github/workflows/ci-windows.yml','.node-version','package.json','package-lock.json','static/ergopti_plus/windows/vendor/ergopti_network_pac.exe','static/ergopti_plus/windows/vendor/ergopti_network_pac.json','static/ergopti_plus/windows/vendor/ergopti_network_pac.LICENSE.txt'}
inventory=[]
for relative in sorted(files):
 data=subprocess.check_output(['git','show',ref+':'+relative],cwd=repo)
 if relative in inputs['source_sha256']:assert hashlib.sha256(data).hexdigest()==inputs['source_sha256'][relative]
 p=seed/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 inventory.append({'path':relative,'git_source':ref,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in (root/'proposal-candidate').rglob('*'):
 if p.is_file():
  relative=p.relative_to(root/'proposal-candidate');target=seed/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
  inventory.append({'path':str(relative),'source':'reviewed_new_candidate','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(root/'immutable-seed-inventory.json').write_text(json.dumps({'entries':inventory,'qualified':'SOURCE_INPUTS_ONLY_NOT_WHOLE_NATIVE_GIT_PROFILE'},indent=2)+'\n')
print('immutable_template_files',len(inventory))
