from pathlib import Path
import difflib,hashlib,json
p=Path('/workspace/ergopti-cloud/group6-root-cli-receiver-extraction');r=p/'received';c=p/'candidate'
pspath='tools/ci/receive-windows-personal-file-caption-build-source.ps1';jspath='tools/ci/run-windows-personal-file-caption-cohort.cjs'
ps=(r/pspath).read_text();js=(r/jspath).read_text()
psbody=ps[ps.index('$Inputs = '):]; assert psbody.count('3262')==2
psnew=psbody.replace('$Inputs.source_sha256.Count -eq 3262','$Inputs.source_sha256.Count -eq $SourceCount').replace('$Receipt.runtime_source.Count -eq 3262','$Receipt.runtime_source.Count -eq $SourceCount')
moduleps="""# Finite extraction of the authenticated f1db before/after CLI receiver.
# Import defines a function; it does not receive sources or invoke compilers.
function Invoke-NativePacBuildSourceReceipt {
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidateSet('prebuild', 'receive')][string]$Stage,
    [Parameter(Mandatory = $true)][string]$Root,
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][ValidateRange(1, 2147483647)][int]$SourceCount
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
"""+psnew+"}\nExport-ModuleMember -Function Invoke-NativePacBuildSourceReceipt\n"
psmodulepath='tools/ci/lib/native-pac-build-source.psm1'
pswrapper=ps[:ps.index('$Inputs = ')]+"""# Loader admission must be sealed into the owning input/producer source image.
$LoaderInputs = Get-Content -LiteralPath $InputPath -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable
$LibraryPath = Join-Path $PSScriptRoot 'lib/native-pac-build-source.psm1'
$LibraryItem = Get-Item -LiteralPath $LibraryPath
if ($LibraryItem.PSIsContainer -or ($LibraryItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
    (Get-FileHash -LiteralPath $LibraryPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $LoaderInputs.build_provenance.receiver_library_sha256) {
    throw 'Reviewed build receiver library changed.'
}
Import-Module $LibraryPath -Force -ErrorAction Stop
# Frozen Root census, not a count derived from the supplied object.
Invoke-NativePacBuildSourceReceipt -Stage $Stage -Root $Root -InputPath $InputPath -SourceCount 3262
"""
a=js.index('function sameImage(');b=js.index('let runtimeSource, buildAdmission;',a);block=js[a:b]
fn=block[block.index('function receiveBuildSource()'):];assert fn.count('3262')==1
changes={"function receiveBuildSource() {":"function receiveBuildSource({ root, inputs, inputPath, receiverPath, expectedScope, sourceCount, prebuildOutcome, receiveOutcome }) {", "policy.scope === 'personal-file-caption-v7-genuine-native-pac-rebuild'":"policy.scope === expectedScope", "Object.keys(inputs.source_sha256).length === 3262":"Object.keys(inputs.source_sha256).length === sourceCount", "process.env.PERSONAL_CAPTION_PREBUILD_OUTCOME === 'success'":"prebuildOutcome === 'success'", "process.env.PERSONAL_CAPTION_RECEIVE_OUTCOME === 'success'":"receiveOutcome === 'success'", "const receiver = path.join(\n\t\troot,\n\t\t'tools/ci/receive-windows-personal-file-caption-build-source.ps1'\n\t);":"const receiver = receiverPath;", "\tconst inputPath = path.join(__dirname, 'windows-personal-file-caption-cohort-inputs.json');\n":""}
for old,new in changes.items():assert fn.count(old)==1;fn=fn.replace(old,new)
same=block[:block.index('function receiveBuildSource()')]
modulejs="'use strict';\nconst fs = require('node:fs');\nconst path = require('node:path');\nconst crypto = require('node:crypto');\nconst sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');\nconst demand = (ok, message) => { if (!ok) throw new Error(message); };\n"+same+fn+"module.exports = { sameImage, receiveBuildSource };\n"
jsmodulepath='tools/ci/lib/native-pac-build-source.cjs'
wrapper="""const { sameImage, receiveBuildSource: receiveOriginalBuildSource } = require('./lib/native-pac-build-source.cjs');
function receiveBuildSource() {
	return receiveOriginalBuildSource({
		root,
		inputs,
		inputPath: path.join(__dirname, 'windows-personal-file-caption-cohort-inputs.json'),
		receiverPath: path.join(root, 'tools/ci/receive-windows-personal-file-caption-build-source.ps1'),
		expectedScope: 'personal-file-caption-v7-genuine-native-pac-rebuild',
		sourceCount: 3262,
		prebuildOutcome: process.env.PERSONAL_CAPTION_PREBUILD_OUTCOME,
		receiveOutcome: process.env.PERSONAL_CAPTION_RECEIVE_OUTCOME
	});
}
"""
jswrapper=js[:a]+wrapper+js[b:]
images={pspath:(ps,pswrapper),jspath:(js,jswrapper),psmodulepath:('',moduleps),jsmodulepath:('',modulejs)}
forward=[];inverse=[];pins=[]
for name,(old,new) in images.items():
 d=c/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(new);forward+=difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name);inverse+=difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile='a/'+name,tofile='b/'+name if old else '/dev/null');pins.append({'path':name,'preimage_sha256':hashlib.sha256(old.encode()).hexdigest() if old else None,'candidate_sha256':hashlib.sha256(new.encode()).hexdigest(),'bytes':len(new.encode())})
(p/'extraction.patch').write_text(''.join(forward));(p/'extraction.inverse.patch').write_text(''.join(inverse))
restore=psnew.replace('$Inputs.source_sha256.Count -eq $SourceCount','$Inputs.source_sha256.Count -eq 3262').replace('$Receipt.runtime_source.Count -eq $SourceCount','$Receipt.runtime_source.Count -eq 3262');assert restore==psbody
restorefn=fn
for old,new in reversed(list(changes.items())):
 if not new:continue
 restorefn=restorefn.replace(new,old)
restorefn=restorefn.replace('\tconst inputHash = retain(inputPath);',"\tconst inputPath = path.join(__dirname, 'windows-personal-file-caption-cohort-inputs.json');\n\tconst inputHash = retain(inputPath);")
assert same+restorefn==block
assert pswrapper[:pswrapper.index('# Loader admission')]==ps[:ps.index('$Inputs = ')]
assert jswrapper.replace(wrapper,block)==js
(p/'source-preservation.json').write_text(json.dumps({'state':'SOURCE_ONLY_UNRUN_INCOMPLETE_ENROLLMENT','images':pins,'ps_original_entire_body_exact_after_two_count_inverse':True,'js_original_entire_function_block_exact_after_seven_binding_inverse':True,'js_all_outside_receiver_bytes_exact':True,'root_wrapper_frozen_count':3262,'original_updater_21_subset_exact':True,'scope':'no file IO/compiler/source acquisition on module import; invocation still performs original IO','missing':'actual new current sealed input/module loader pins and candidate Source count; G6 wrapper splice; explicit publication/canonical owner custody; software receiving; Windows native'},indent=2)+'\n')
print(json.dumps(pins,indent=2))
