from pathlib import Path
import subprocess,json,hashlib,shutil,datetime
root=Path('/workspace/ergopti');view=Path('/workspace/.ergopti-cloud/config-healthcheck-opener-view');proof=Path('/workspace/.ergopti-cloud/resume-healthcheck-opener');base='614970f3c2f8c2c1b6c27e27ff1c513dd6c933d7';tree='5f3a0f0c5926593b8fe10802ca779d5e55222e51';owned=json.loads((proof/'owned-paths.json').read_text());pins=json.loads((proof/'refreshed-frozen-candidate.json').read_text())['source_sha256']
def git(*a,cwd=root):return subprocess.check_output(['git',*a],cwd=cwd,text=True).strip()
assert git('rev-parse','HEAD')==base and not git('status','--porcelain')
assert git('rev-parse','HEAD',cwd=view)==base and git('write-tree',cwd=view)==tree
assert not git('diff','--name-only',cwd=view) and not git('ls-files','--others','--exclude-standard',cwd=view)
for p in owned:
 content=(view/p).read_bytes();assert hashlib.sha256(content).hexdigest()==pins[p]
 assert subprocess.check_output(['git','show',tree+':'+p],cwd=root)==content
 current=subprocess.run(['git','show',base+':'+p],cwd=root,capture_output=True)
 if current.returncode==0:assert (root/p).read_bytes()==current.stdout
 else:assert p=='docs/handovers/2026-10-12-config-menus/2026-10-15-DIAGNOSTIC-OPENER.md' and not (root/p).exists()
for p in owned:shutil.copyfile(view/p,root/p)
subprocess.run(['git','add','--',*owned],cwd=root,check=True)
assert git('write-tree')==tree and not git('diff','--name-only') and not git('ls-files','--others','--exclude-standard')
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':base,'candidate_tree':tree,'canonical_js_view':str(root),'native_view':str(view),'owned_paths':owned,'source_sha256':pins,'source_images_byte_identical':True,'views_frozen_until_all_own_gates_naturally_terminal':True}
(proof/'paired-gate-composition.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'tree':tree,'paths':len(owned),'canonical_and_native_equal':True}))
