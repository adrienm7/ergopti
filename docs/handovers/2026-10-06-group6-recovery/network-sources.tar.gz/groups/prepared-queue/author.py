from pathlib import Path
import difflib,hashlib,json,sys
BASE=Path(__file__).parent
ROOT=Path('/workspace/ergopti')
HOP=Path('/workspace/scratch/group6-linux-output-hop62/revision3/candidate')
IS_HOP='--output-hop' in sys.argv
R=BASE/'output-hop-composition' if IS_HOP else BASE
INPUT=HOP if IS_HOP else ROOT
CORE=INPUT/'static/ergopti_plus/linux/adapters/curl_http_client.lua'
PREFIX='static/ergopti_plus/'
def emit(path,content):
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
def replace(source,a,b):
 assert source.count(a)==1,(a[:100],source.count(a));return source.replace(a,b,1)
def capture(path,origin):
 s=origin.read_text();emit('preimages/'+path,s);return s
shared='''--- network/http_headers.lua

--- ==============================================================================
--- MODULE: Shared Immutable HTTP Header Preparation
--- DESCRIPTION:
--- Converts caller metadata once in its original sorted order. Native consumers
--- retain the ordered rows; the detached string view supports redirect filtering.
--- No URL, proxy, timeout or native ownership state is cached with headers.
--- ==============================================================================

local M = {}

--- Captures immutable header strings using the original wire conversion order.
--- @param headers table
--- @param validate function Canonical forbidden-byte policy.
--- @return table rows Ordered detached string pairs.
--- @return table view Last value for each normalized field name.
function M.capture(headers, validate)
    if type(headers) ~= "table" or type(validate) ~= "function" then error("HTTP headers are invalid") end
    local names, rows, view = {}, {}, {}
    for name in pairs(headers) do names[#names + 1] = name end
    table.sort(names)
    for _, name in ipairs(names) do
        local header_name, header_value = tostring(name), tostring(headers[name])
        local allowed, err = validate(header_name, header_value)
        if not allowed then error(err) end
        rows[#rows + 1] = { name = header_name, value = header_value }
        view[header_name] = header_value
    end
    return rows, view
end

--- Copies only immutable strings; the caller cannot mutate the retained view.
--- @param view table
--- @return table
function M.copy(view)
    local detached = {}
    for name, value in next, view do detached[name] = value end
    return detached
end

--- Compares only detached plain string fields; this never evaluates metadata.
--- @param headers table
--- @param view table
--- @return boolean
function M.matches(headers, view)
    if type(headers) ~= "table" or getmetatable(headers) ~= nil then return false end
    local count, expected = 0, 0
    for name, value in next, view do
        expected = expected + 1
        if rawget(headers, name) ~= value then return false end
    end
    for name, value in next, headers do
        count = count + 1
        if type(name) ~= "string" or type(value) ~= "string" or rawget(view, name) ~= value then return false end
    end
    return count == expected
end

--- Selects only unchanged fields from a previously admitted ordered snapshot.
--- @param rows table
--- @param view table
--- @param subset table
--- @return table|nil rows
--- @return table|nil view
function M.subset(rows, view, subset)
    if type(subset) ~= "table" or getmetatable(subset) ~= nil then return nil end
    local selected, copy = {}, {}
    for name, value in next, subset do
        if type(name) ~= "string" or type(value) ~= "string" or rawget(view, name) ~= value then return nil end
        copy[name] = value
    end
    -- Preserve every original duplicate wire field and its exact order; a
    -- redirect may remove a field, but cannot rewrite its admitted values.
    for _, row in ipairs(rows) do
        if rawget(copy, row.name) ~= nil then
            selected[#selected + 1] = { name = row.name, value = row.value }
        end
    end
    return selected, copy
end

return M
'''
emit('candidate/'+PREFIX+'_shared/lua/network/http_headers.lua',shared.replace('    ','\t'))
path=PREFIX+'linux/adapters/curl_http_client.lua';s=capture(path,CORE)
s=replace(s,'local HeaderPolicy = require("infra.http_header_policy")','local HeaderPolicy = require("infra.http_header_policy")\nlocal HeaderSnapshot = require("network.http_headers")')
s=replace(s,'local MAX_SAFE_INTEGER = 9007199254740991','''local MAX_SAFE_INTEGER = 9007199254740991
-- Only genuine preflight capabilities can reuse admitted private header bytes.
local prepared_headers = setmetatable({}, { __mode = "k" })''')
a='''	local names = {}
	for name in pairs(headers) do names[#names + 1] = name end
	table.sort(names)
	for _, name in ipairs(names) do
		local header_name, header_value = tostring(name), tostring(headers[name])
		local allowed, err = HeaderPolicy.validate(header_name, header_value)
		if not allowed then error(err) end
		-- Curl's empty colon form removes a field; semicolon sends an empty
		-- value, preserving the caller's distinction between present and absent.
		local wire_header = header_value:match("^[ \\t]*$") and header_name .. ";"
			or header_name .. ": " .. header_value
		lines[#lines + 1] = "header = " .. config_quote(wire_header)
	end'''
b='''	local prepared = options.prepared_headers and prepared_headers[options.prepared_headers]
	if options.prepared_headers then
		if not prepared or not HeaderSnapshot.matches(headers, prepared.view) then error("HTTP prepared headers refused") end
		for _, row in ipairs(prepared.rows) do
			local wire_header = row.value:match("^[ \\t]*$") and row.name .. ";" or row.name .. ": " .. row.value
			lines[#lines + 1] = "header = " .. config_quote(wire_header)
		end
	else
'''+''.join('\t'+line+'\n' for line in a.splitlines()).rstrip('\n')+'''
	end'''
s=replace(s,a,b)
s=replace(s,'	local request_options = {\n		protocols = protocols,','''	if options.prepared_headers ~= nil then
		local prepared = prepared_headers[options.prepared_headers]
		if not prepared or not HeaderSnapshot.matches(headers, prepared.view) then
			return nil, "HTTP prepared headers refused"
		end
	end
	local request_options = {
		prepared_headers = options.prepared_headers,
		protocols = protocols,''')
a='''function M.preflight(url, headers, body, options)
	local normalized, err = admit_metadata(url, headers, body, options)
	if not normalized then return false, err end
	local composed, argv = pcall(curl_args, url, headers, body, normalized)
	if not composed then return false, "curl configuration refused" end
	local refused = ShellRunner.validate_spawn_args(normalized.curl_executable, argv)
	if refused ~= "" then return false, "curl argument vector refused: " .. refused end
	return true
end'''
b='''function M.preflight(url, headers, body, options)
	local normalized, err = admit_metadata(url, headers, body, options)
	if not normalized then return false, err end
	local captured, rows, view = pcall(HeaderSnapshot.capture, headers, HeaderPolicy.validate)
	if not captured then return false, "curl configuration refused" end
	local token = {}
	prepared_headers[token] = { rows = rows, view = view }
	normalized.prepared_headers = token
	local composed, argv = pcall(curl_args, url, view, body, normalized)
	if not composed then return false, "curl configuration refused" end
	local refused = ShellRunner.validate_spawn_args(normalized.curl_executable, argv)
	if refused ~= "" then return false, "curl argument vector refused: " .. refused end
	return true, nil, token, HeaderSnapshot.copy(view)
end

--- Rebinds an admitted snapshot after canonical redirect field removal.
--- @param token table Genuine private header capability.
--- @param headers table Detached string subset.
--- @return table|nil New private capability; no caller values are evaluated.
function M.rebind_prepared_headers(token, headers)
	local prepared = prepared_headers[token]
	if not prepared then return nil end
	local rows, view = HeaderSnapshot.subset(prepared.rows, prepared.view, headers)
	if not rows then return nil end
	local rebound = {}
	prepared_headers[rebound] = { rows = rows, view = view }
	return rebound
end'''
s=replace(s,a,b);emit('candidate/'+path,s)
# The ordinary and output-hop variants have separately pinned exact inputs.
path=PREFIX+'linux/adapters/http_client.lua';s=capture(path,INPUT/path)
s=replace(s,'clock = Monotonic.now_ms, deadline = Deadline.start, environment = PolicyBinding.environment,','clock = Monotonic.now_ms, deadline = Deadline.start, environment = PolicyBinding.environment,\n\t\tprepare_headers = Curl.rebind_prepared_headers,')
s=s.replace('request.single_hop_redirect, request.single_hop_receipt_bytes, request.single_hop_url_bytes = nil, nil, nil','request.single_hop_redirect, request.single_hop_receipt_bytes, request.single_hop_url_bytes = nil, nil, nil\n\trequest.prepared_headers = nil')
s=replace(s,'local allowed, err = Curl.preflight(url, headers, body, request)\n\tif not allowed then return rejected(err, callback) end','''local allowed, err, token, prepared = Curl.preflight(url, headers, body, request)
	if not allowed then return rejected(err, callback) end
	if type(token) ~= "table" or type(prepared) ~= "table" then return rejected("HTTP prepared headers unavailable", callback) end
	request.prepared_headers, headers = token, prepared''')
s=replace(s,'captured.single_hop_redirect, captured.single_hop_receipt_bytes, captured.single_hop_url_bytes = nil, nil, nil','captured.single_hop_redirect, captured.single_hop_receipt_bytes, captured.single_hop_url_bytes = nil, nil, nil\n\t\tcaptured.prepared_headers = nil')
s=replace(s,'local allowed, err = Curl.preflight(url, headers, body, captured)\n\t\tif not allowed then return nil, err end\n\t\treturn captured','''local allowed, err, token, prepared = Curl.preflight(url, headers, body, captured)
		if not allowed then return nil, err end
		if type(token) ~= "table" or type(prepared) ~= "table" then return nil, "HTTP prepared headers unavailable" end
		captured.prepared_headers = token
		return captured, nil, prepared''')
emit('candidate/'+path,s)
path=PREFIX+'linux/infra/managed_http.lua';s=capture(path,INPUT/path)
s=replace(s,'\tif dependencies.redirect ~= nil and type(dependencies.redirect) ~= "function" then return nil, "managed-http-initialization-invalid" end','''	if dependencies.redirect ~= nil and type(dependencies.redirect) ~= "function" then return nil, "managed-http-initialization-invalid" end
	if dependencies.prepare_headers ~= nil and type(dependencies.prepare_headers) ~= "function" then return nil, "managed-http-initialization-invalid" end''')
a='\t--- Rechecks only the captured source under its original public reservation.'
s=replace(s,a,'''	--- Includes a tentative queued reservation without replacing its native owner.
	local function reservation_current(record)
		local incumbent = owned[record.owner]
		return incumbent == record or (incumbent ~= nil and record.predecessor == incumbent
			and incumbent.successor == record and not incumbent.options.owned_api)
	end

'''+a)
# Only source_current changes: all native physical ownership checks remain strict.
a=s.index('\tlocal function source_current(record)');b=s.index('\n\tend',a)+len('\n\tend');block=s[a:b].replace('owned[record.owner] ~= record','not reservation_current(record)').replace('owned[record.owner] == record','reservation_current(record)');s=s[:a]+block+s[b:]
s=replace(s,'\t\toptions.owner, options.timeout_ms, options.proxy_selection = record.owner, budget, choice','''		options.owner, options.timeout_ms, options.proxy_selection = record.owner, budget, choice
		if options.prepared_headers ~= nil then
			if not dependencies.prepare_headers then finish(record, refusal("HTTP prepared headers unavailable")); return end
			local called, token = pcall(dependencies.prepare_headers, options.prepared_headers, record.headers)
			if owned[record.owner] ~= record or record.generation ~= generation or record.operation._cancelled or record.operation._settled then return end
			if not called or type(token) ~= "table" then finish(record, refusal("HTTP prepared headers refused")); return end
			options.prepared_headers = token
			local adjusted = remaining(record)
			if owned[record.owner] ~= record or record.generation ~= generation or record.operation._cancelled or record.operation._settled then return end
			if adjusted <= 0 then expire(record); return end
			options.timeout_ms = adjusted
		end''')
a='''			if owned[record.owner] then
				if admission.authorized then operation._settled = true
				else finish(record, refusal("previous request cleanup pending")) end
				return operation
			end
			owned[record.owner] = record'''
b='''			local incumbent = owned[record.owner]
			if incumbent and (incumbent.options.owned_api or incumbent.successor) then
				if admission.authorized then operation._settled = true
				else finish(record, refusal("previous request cleanup pending")) end
				return operation
			end
			if incumbent then
				incumbent.successor, record.predecessor = record, incumbent
			else owned[record.owner] = record end'''
s=replace(s,a,b)
s=replace(s,'local prepared, native_options, preparation_error = pcall(admission.prepare)','local prepared, native_options, preparation_error, prepared_headers = pcall(admission.prepare)')
s=replace(s,'\t\t\trecord.options = native_options\n\t\tend','''			if prepared_headers ~= nil then
				if type(prepared_headers) ~= "table" then
					record.admitting = false
					finish(record, refusal("HTTP prepared headers unavailable")); return operation
				end
				record.headers, headers = prepared_headers, prepared_headers
			elseif native_options.prepared_headers ~= nil then
				record.admitting = false
				finish(record, refusal("HTTP prepared headers unavailable")); return operation
			end
			record.options = native_options
		end''')
s=replace(s,'or (admission and owned[record.owner] ~= record) then','or (admission and not reservation_current(record)) then')
s=replace(s,'\t\t-- A delayed timer close ACK cannot admit success past the original budget.', '\t\t-- Accepted owned replacements retain the old physical debt too; invalid\n\t\t-- preflight refusals were never admitted and leave the incumbent valid.\n\t\tif record.predecessor and record.admitted and record.options.owned_api\n\t\t\tand not record.predecessor.operation._settled then return end\n\t\t-- A delayed timer close ACK cannot admit success past the original budget.')
a='''			record.admitting = false
			if record.operation._cancelled then finish(record, refusal("cancelled")); return operation end
			if remaining(record) <= 0 then expire(record); return operation end
			if owned[record.owner] ~= record or operation._cancelled or operation._settled then
				finish(record, refusal("cancelled")); return operation
			end
			if not route then finish(record, refusal(err or "proxy-environment-unavailable")); return operation end
			record.route, record.admitted, record.visible_active = route, true, true
			if not arm_deadline(record) then return operation end
			dispatch_route(record, route)
			return operation'''
b='''			if record.operation._cancelled then
				record.admitting = false; finish(record, refusal("cancelled")); return operation
			end
			local budget = remaining(record)
			if not reservation_current(record) or operation._cancelled or operation._settled then
				record.admitting = false; finish(record, refusal("cancelled")); return operation
			end
			if budget <= 0 then record.admitting = false; expire(record); return operation end
			if not route then
				record.admitting = false; finish(record, refusal(err or "proxy-environment-unavailable")); return operation
			end
			record.route, record.admitted, record.visible_active = route, true, true
			-- Keep the tentative successor fenced while timer ports may reenter
			-- predecessor settlement. Its absolute wait budget is already running.
			if not arm_deadline(record) then
				record.admitting = false
				-- Failed arming never accepts a replacement or cancels its valid
				-- predecessor; the exact allocated timer debt remains linked.
				if record.deadline_failed then record.admitted = false end
				if record.pending_result then finish(record, record.pending_result) end
				return operation
			end
			if record.operation._cancelled or record.expired then
				record.admitting = false; finish(record, record.pending_result or refusal("cancelled")); return operation
			end
			local incumbent = record.predecessor
			if incumbent then
				operation.started = true
				if not request_cancel(incumbent) then
					operation.started, record.admitted, record.visible_active, record.admitting = false, false, false, false
					finish(record, refusal("previous request cancellation failed")); return operation
				end
			end
			record.admitting = false
			if record.operation._cancelled or record.operation._settled or record.expired then
				finish(record, record.pending_result or refusal("cancelled")); return operation
			end
			if not record.predecessor then dispatch_route(record, route) end
			return operation'''
s=replace(s,a,b)
s=replace(s,'		record.stage, record.child, record.result, record.done_received = "curl", nil, nil, false', '		record.stage, record.child, record.result, record.done_received = "curl", nil, nil, false\n		record.construction_terminal = nil')
s=replace(s,'''		options.on_native_terminal = function(result)
			if owned[record.owner] ~= record or record.generation ~= generation then return end
			logical_complete(record, result)
		end''','''		options.on_native_terminal = function(result)
			if owned[record.owner] ~= record or record.generation ~= generation then return end
			-- A pre-start refusal can still own pipes, timers or descriptors.
			-- Its original failure publishes through physical completion, while
			-- an admitted native child keeps ordinary early logical terminals.
			if record.constructing then record.construction_terminal = result; return end
			logical_complete(record, result)
		end''')
s=replace(s,'''		record.child = child
		record.operation.started = record.operation.started or child.started == true
		observe(record, generation)''','''		record.child = child
		record.operation.started = record.operation.started or child.started == true
		local construction_terminal = record.construction_terminal
		record.construction_terminal = nil
		if construction_terminal and child.started == true then logical_complete(record, construction_terminal)
		elseif type(construction_terminal) == "table" and construction_terminal.ok == false then
			-- The actual child refused to start. Its failure already became
			-- terminal before the deadline; cleanup is not a new timeout phase.
			record.prestart_refused, record.pending_result = true, construction_terminal
			local accepted, closed = pcall(record.deadline_child.cancel, record.deadline_child)
			if not accepted or closed ~= true then
				dependencies.report("Managed HTTP deadline cleanup refused; ownership retained.")
			end
		end
		observe(record, generation)''')
# This is a known terminal construction failure, not an admitted transfer whose
# deadline can publish while its pipes/descriptors are intentionally retained.
s=replace(s,'if record.operation._settled or record.expired or record.operation._cancelled then return end','if record.operation._settled or record.expired or record.operation._cancelled or record.prestart_refused then return end')
s=s.replace('if record.admitted and not record.operation._cancelled and remaining(record) <= 0 then','if record.admitted and not record.prestart_refused and not record.operation._cancelled and remaining(record) <= 0 then')
# Final source transformation operates only on the literal physical settlement guard.
s=replace(s,'''		if record.expired or remaining(record) <= 0 then
			expire(record)
			finish(record, refusal("timeout"))''','''		if not record.prestart_refused and (record.expired or remaining(record) <= 0) then
			expire(record)
			finish(record, refusal("timeout"))''')
emit('candidate/'+path,s)
patch=[]
for p in sorted((R/'candidate').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R/'candidate').as_posix();old=R/'preimages'/rel
 patch+=difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],p.read_text().splitlines(True),fromfile='a/'+rel if old.exists() else '/dev/null',tofile='b/'+rel)
emit('prepared-queue.patch',''.join(patch))
