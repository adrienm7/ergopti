#ifndef ERGOPTI_GROUP4_GUARDIAN_IMPORT_WIN32_H
#define ERGOPTI_GROUP4_GUARDIAN_IMPORT_WIN32_H
#include "source_channel.h"
#include "guardian_win32.h"

typedef struct {
    GSC_Owner *channel;
    HANDLE source;
    DWORD source_pid;
    FILETIME source_creation;
    DWORD first_os_error;
    const GI_Expected *held_candidates;
    size_t held_count;
} GI_Win32Context;

/* Only a DATA_READY source channel may create this port. It carries the
   exclusively inherited pinned-helper authority, not a supplied verified flag.
   Its exact source process must stay borrowed/alive through all duplication. */
int GI_Win32ContextInit(GI_Win32Context *, GSC_Owner *);
/* Internal intake registry only. It has already captured this original source
   capability during its genuine suspended constructor, before private-job bind.
   The candidate array is copied/owned by that row and is not admission by itself. */
int GI_Win32ContextInitIntake(GI_Win32Context *,HANDLE,const FILETIME *,
                            const GI_Expected *,size_t);
GI_Port GI_Win32ImportPort(GI_Win32Context *);
#endif
