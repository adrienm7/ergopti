Private artifact installation and production updater join: bounded source review
=============================================================================

Inputs are immutable artifact revision5 manifest4972056b / leasebeb3bfec / targete82717df and admission supplementb3809960 (six cases); production updater revision2 manifest39979dd5 / managerc34f9cd8 / archive_transfer93b01fe3 and supplement51b7f8b5 (eight cases). All thirteen manifest/source/patch bindings were independently verified with SHA256. Ordinary lease/default-factory prefix is exact to acknowledged6325; embedded feeder is exactlyade35. No imports, parser execution, tests, native build, live writes or qualification occurred.

Blocked production publication
------------------------------

1. archive_transfer dispatch.publish lacks a publication reservation and a post-probe delivery/state fence. A captured physical probe or source admission can invoke its saved retirement listener; nested publication completes the stage, then the outer frame completes it again. Protect the whole observation/admission interval and refence the exact transaction and request before one completion. Independent reentry controls must pin one stage completion and one next-stage acquisition.

2. Manager cancellation publication can be reentered during artifact namespace retirement. An already registered artifact settlement listener is synchronously invoked by actual cleanup; nested deliver publishes and clears native_transfer, then the outer successful retire call resumes without a record.done/native_transfer fence and publishes again. Hold publication intent before physical/artifact probes and release in finally; refence exact record/result before commit.

3. The accepted install join has no typed pre-acquisition refusal path. Installer revision4 explicitly returns nil when its first original install_current probe refuses before any reader allocation. begin_install has already reserved the private work; manager marks the missing operation as unknown indefinitely without finishing the reservation. Real original deadline expiry between begin and the installer probe reaches this path. Return an explicit owned refusal receipt/operation from the fixed producer and join original finish_install physical closure; do not infer no acquisition from arbitrary nil/throw or clear busy state speculatively.

Complementary Archive source findings (separately reviewed, author informed): manager final transfer publication does not recheck native_source after the external physical probe; channel persistence and in-memory channel assignment precede artifact retirement refusal. These require distinct original-consent and commit-order controls. Accepted install execution intentionally preserves its captured identity after page/pause retirement; transfer source must not be applied to accepted install cancellation.

Bounded registry observations
-----------------------------

New install tokens and transaction matching use raw branded identity. The fixed lexical factory holds native publication pointers, captured original lease/reader methods, and original descriptor sealing; ordinary injected factories have no adopter. Install work reservation precedes budget/native/source probes, captures one fresh canonical install deadline, and refuses retired transfer phase borrowing. Cleanup has a private reservation before lease/reader/native probes and checks all descriptor plus namespace counts before disposal; finish-readers independently joins all captured child acknowledgments. Transfer success does not claim namespace disposal. No displayed pathname supplies download, digest or tar authority. The reviewed default lease prefix and native feeder remain exact.

No additional concrete defect found in those narrow new registry sections during this read. This does not clear the overall pipeline: feederade35 first actual settlement failed; composite reader/cleanup controls remain missing; six admission plus eight receiving models are authored/unexecuted; installer legacy assertions and actual acquisition/ABI/filesystem/deadline/disposal qualification are still required. Preserve all current preimages and failed native evidence.
