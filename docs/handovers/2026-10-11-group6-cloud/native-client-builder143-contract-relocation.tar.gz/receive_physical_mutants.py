"""Two existing original case assertions against actual changed recipe bytes."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

PACKET = Path(__file__).resolve().parent
REPO = Path("/workspace/ergopti")
PYTHON = "/workspace/ergopti-cloud/python/bin/python3"
BUILDER = "static/ergopti_plus/macos/tests/support/native_http_fixture_builder.py"
DIAGNOSTIC = "tools/diagnostics/macos_native_wire_swift_dependencies_test.py"
facts = {"qualification": "real staged bytes/compiler argument model; no native compiler credit",
         "results": []}
closure = json.loads((PACKET / "receiving.json").read_text())["candidate_physical_inputs"]
with tempfile.TemporaryDirectory(prefix="ergopti-contract-physical-mutants-") as name:
    outer = Path(name)
    source = outer / "source"
    temporary = outer / "temporary"
    temporary.mkdir(mode=0o700)
    for relative, expected in closure.items():
        assert not Path(relative).is_absolute() and ".." not in Path(relative).parts
        actual = PACKET / "candidate" / relative
        if not actual.is_file():
            actual = REPO / relative
        raw = actual.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    builder = source / BUILDER
    original = builder.read_bytes()
    cases = (
        ("physical-staged-guard-omission-red",
         b"if _digest(regular_bytes(path)[0]) != digest:", b"if False:",
         "test_modified_certificate_copy_refuses_before_compiler",
         "modified source reached compiler"),
        ("physical-compiler-pac-omission-red", b"*map(str, swift),",
         b'*map(str, [path for path in swift if path.name != "ManagedPACSource.swift"]),',
         "test_compiler_receives_exact_real_pac_source_owner", "not found in"),
    )
    for label, old, new, case, marker in cases:
        assert original.count(old) == 1
        changed = original.replace(old, new)
        try:
            builder.write_bytes(changed)
            result = subprocess.run(
                [PYTHON, "-I", "-B", str(source / DIAGNOSTIC),
                 "StandaloneSwiftDependencies." + case],
                cwd=source, env=dict(os.environ, TMPDIR=str(temporary),
                                   PYTHONDONTWRITEBYTECODE="1"),
                capture_output=True, text=True, timeout=30)
            (PACKET / (label + ".stdout.log")).write_text(result.stdout)
            (PACKET / (label + ".stderr.log")).write_text(result.stderr)
            assert result.returncode == 1
            assert "Ran 1 test" in result.stderr and "FAILED (failures=1)" in result.stderr
            assert marker in result.stderr and "errors=" not in result.stderr
            assert "ImportError" not in result.stderr and not any(temporary.iterdir())
            facts["results"].append({"label": label, "status": 1,
                                     "actual_mutant_sha256": hashlib.sha256(changed).hexdigest(),
                                     "failures": 1, "errors": 0, "skips": 0,
                                     "caller_private_root_cleanup_complete": True})
        finally:
            builder.write_bytes(original)
        assert builder.read_bytes() == original
    facts["all_child_rounds_terminal"] = True
facts["outer_receiving_tree_retired"] = not outer.exists()
(PACKET / "physical-mutants-receiving.json").write_text(json.dumps(facts, indent=2) + "\n")
print(json.dumps(facts))
