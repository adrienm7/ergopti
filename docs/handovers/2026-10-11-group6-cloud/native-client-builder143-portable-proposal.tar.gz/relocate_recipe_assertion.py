"""Parent-authorized central recipe/source consumer test relocation."""
import ast,difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
REL='tools/test/macos_native_http_receiving_facts_test.py'
path=P/'canonical143'/REL
old=path.read_text()
needle='''        compiler = (SUPPORT / "native_http_wire_client_receiving.py").read_text(encoding="utf-8")
        self.assertIn(
            '\"-D\",\\n                    \"ERGOPTI_MANAGED_HTTP_FIXTURE_DIAGNOSTICS\",',
            compiler,
        )
'''
assert old.count(needle)==1
replacement='''        import ast

        compiler = ast.parse(
            (SUPPORT / "native_http_fixture_builder.py").read_text(encoding="utf-8")
        )
        builder = next(
            node for node in compiler.body
            if isinstance(node, ast.ClassDef) and node.name == "OwnedFixtureBuild"
        )
        build = next(
            node for node in builder.body
            if isinstance(node, ast.FunctionDef) and node.name == "build"
        )
        compiler_calls = [
            node for node in ast.walk(build)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and ast.unparse(node.func) == "self._command"
            and node.args and isinstance(node.args[0], ast.List)
            and len(node.args[0].elts) >= 5
            and isinstance(node.args[0].elts[0], ast.Constant)
            and node.args[0].elts[0].value == "/usr/bin/xcrun"
        ]
        self.assertEqual(len(compiler_calls), 1)
        self.assertEqual(
            [node.value for node in compiler_calls[0].args[0].elts[:5]],
            ["/usr/bin/xcrun", "swiftc", "-parse-as-library", "-D",
             "ERGOPTI_MANAGED_HTTP_FIXTURE_DIAGNOSTICS"],
        )
        caller = ast.parse(
            (SUPPORT / "native_http_wire_client_receiving.py").read_text(encoding="utf-8")
        )
        receiving = next(
            node for node in caller.body
            if isinstance(node, ast.ClassDef) and node.name == "RealNativeClientReceiving"
        )
        bootstrap = next(
            node for node in receiving.body
            if isinstance(node, ast.FunctionDef) and node.name == "setUpClass"
        )
        calls = [node for node in ast.walk(bootstrap) if isinstance(node, ast.Call)]
        fixed_loads = [node for node in calls
                       if ast.unparse(node.func) == "importlib.util.spec_from_file_location"]
        self.assertEqual(
            [(ast.unparse(node.args[0]), ast.unparse(node.args[1])) for node in fixed_loads],
            [("'owned_native_http_build'", "Path(__file__).with_name('native_http_fixture_builder.py')"),
             ("'actual_native_managed_http'", "native / 'managed_http.py'")],
        )
        for expression in (
            "importlib.util.module_from_spec(build_spec)",
            "build_spec.loader.exec_module(builder)",
            "builder.OwnedFixtureBuild(cls.fixture)",
            "cls.build.build()",
        ):
            self.assertEqual(sum(ast.unparse(node) == expression for node in calls), 1)
'''
new=old.replace(needle,replacement,1)
path.write_text(new)
(P/'recipe-assertion-relocation.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+REL,tofile='b/'+REL)))
assert new.replace(replacement,needle,1)==old
oldlines=old.splitlines(True);newlines=new.splitlines(True)
name='test10FixtureFlagCannotChangeReleaseOperationsOrMoveCausalBoundaries'
oldfn=next(n for n in ast.walk(ast.parse(old)) if isinstance(n,ast.FunctionDef) and n.name==name)
newfn=next(n for n in ast.walk(ast.parse(new)) if isinstance(n,ast.FunctionDef) and n.name==name)
oldbody=''.join(oldlines[oldfn.lineno-1:oldfn.end_lineno]);newbody=''.join(newlines[newfn.lineno-1:newfn.end_lineno])
assert oldbody[:oldbody.index(needle)]==newbody[:newbody.index(replacement)]
(P/'recipe-assertion-relocation-review.json').write_text(json.dumps({'old_function_sha256':hashlib.sha256(oldbody.encode()).hexdigest(),'new_function_sha256':hashlib.sha256(newbody.encode()).hexdigest(),'changed_original_function':name,'original_causal_stage_assertions_byte_exact':True,'finite_inverse':True,'authorization':'Parent explicit relocation test correction after physical136 ASSERTION FAIL','runtime':'PENDING','new_import':'Python standard library ast; local import only'},indent=2)+'\n')
