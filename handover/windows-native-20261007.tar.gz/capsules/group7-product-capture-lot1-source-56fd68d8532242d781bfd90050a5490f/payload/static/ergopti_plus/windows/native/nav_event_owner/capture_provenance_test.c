// static/ergopti_plus/windows/native/nav_event_owner/capture_provenance_test.c
/** @file capture_provenance_test.c
 * @brief Hook-free raw provenance and real retained terminal-queue controls.
 *
 * Literal raw entries and deterministic replay sinks are recording ports.
 * No test installs a hook, opens a GUI, sends input or claims hardware provenance.
 */
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "capture_provenance.h"

#define CAPTURE_ASSERT(value) do { if (!(value)) { \
    fprintf(stderr, "Capture provenance control refused: %s at line %u.\n", __func__, (unsigned)__LINE__); \
    return false; } } while (0)

static bool Observe(NavCaptureProvenanceState *state, NavCaptureProvenanceEdge *edge,
    uint16_t vk, uint16_t sc, uint32_t flags, uint64_t extra, uint8_t modifier,
    uint64_t token, uint64_t generation)
{
    return NavCaptureProvenance_Observe(state, vk, sc, flags, extra, 1234,
        (flags & LLKHF_UP) ? ERGOPTI_NAV_EVENT_UP : ERGOPTI_NAV_EVENT_DOWN,
        modifier, token, generation, generation + 1, edge) != 0;
}

static bool InitialDownIsNotReleasedProof(void)
{
    NavCaptureProvenanceState state;
    NavCaptureProvenanceEdge edge;
    NavCaptureProvenance_Reset(&state);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, 0, 0, 0, 17, 9));
    CAPTURE_ASSERT(edge.sequence == 1 && edge.down_sequence == 1);
    CAPTURE_ASSERT(!edge.repeat_known && !edge.reserve_action && edge.action_sequence == 0);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, 0, 0, 0, 17, 9));
    CAPTURE_ASSERT(edge.repeat_known && edge.repeat && !edge.reserve_action && !edge.action_sequence);
    return true;
}

static bool DownRepeatUpKeepsOriginalGeneration(void)
{
    NavCaptureProvenanceState state;
    NavCaptureProvenanceEdge edge;
    uint64_t down;
    NavCaptureProvenance_Reset(&state);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, LLKHF_UP, 0, 0, 0, 1));
    CAPTURE_ASSERT(!edge.action_sequence);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, 0, 0, 0, 17, 9));
    down = edge.sequence;
    CAPTURE_ASSERT(edge.reserve_action && edge.action_sequence == down && !edge.repeat);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, 0, 0, 0, 18, 19));
    CAPTURE_ASSERT(edge.repeat && !edge.reserve_action && edge.action_sequence == down);
    CAPTURE_ASSERT(edge.down_capture_token == 17 && edge.navigation_generation == 9 && edge.profile_generation == 10);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, LLKHF_UP, 0, 0, 18, 19));
    CAPTURE_ASSERT(edge.action_sequence == down && !edge.reserve_action && edge.navigation_generation == 9);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, 0, 0, 0, 18, 19));
    CAPTURE_ASSERT(edge.reserve_action && edge.action_sequence > down && edge.navigation_generation == 19);
    return true;
}

static bool ModifierLevelsRemainIndependentAndFrozen(void)
{
    NavCaptureProvenanceState state;
    NavCaptureProvenanceEdge edge, frozen;
    uint8_t mask = 0;
    NavCaptureProvenance_Reset(&state);
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LSHIFT, 0x2A, 0, 0, 0x10, 0, 1));
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LCONTROL, 0x1D, LLKHF_INJECTED,
        ERGOPTI_NAV_AHK_SEND_LEVEL_BASE - 5, 0x01, 17, 1));
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LCONTROL, 0x1D, LLKHF_INJECTED | LLKHF_UP,
        ERGOPTI_NAV_AHK_SEND_LEVEL_BASE - 7, 0x01, 17, 1));
    CAPTURE_ASSERT(edge.injected_lr[5] == 0x01 && edge.injected_lr[7] == 0);
    frozen = edge;
    CAPTURE_ASSERT(NavCaptureProvenance_Effective(&frozen, 4, &mask) && mask == 0x11);
    CAPTURE_ASSERT(NavCaptureProvenance_Effective(&frozen, 5, &mask) && mask == 0x10);
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LSHIFT, 0x2A, LLKHF_UP, 0, 0x10, 17, 1));
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LCONTROL, 0x1D, LLKHF_INJECTED | LLKHF_UP,
        ERGOPTI_NAV_AHK_SEND_LEVEL_BASE - 5, 0x01, 17, 1));
    CAPTURE_ASSERT(NavCaptureProvenance_Effective(&frozen, 4, &mask) && mask == 0x11);
    CAPTURE_ASSERT(NavCaptureProvenance_Effective(&edge, 4, &mask) && mask == 0);
    mask = 0x77;
    CAPTURE_ASSERT(!NavCaptureProvenance_Effective(&edge, 101, &mask) && mask == 0x77);
    return true;
}

static bool ReplayAndLowerIntegrityCannotClearPhysical(void)
{
    NavCaptureProvenanceState state;
    NavCaptureProvenanceEdge edge;
    NavCaptureProvenance_Reset(&state);
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LSHIFT, 0x2A, 0, 0, 0x10, 17, 1));
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LSHIFT, 0x2A, LLKHF_INJECTED | LLKHF_UP,
        ERGOPTI_NAV_TERMINAL_REPLAY_MARKER, 0x10, 17, 1));
    CAPTURE_ASSERT(edge.physical_lr == 0x10 && !edge.reserve_action && !edge.action_sequence);
    CAPTURE_ASSERT(Observe(&state, &edge, VK_LSHIFT, 0x2A, LLKHF_INJECTED | LLKHF_LOWER_IL_INJECTED | LLKHF_UP,
        ERGOPTI_NAV_AHK_SEND_LEVEL_BASE - 5, 0x10, 17, 1));
    CAPTURE_ASSERT(edge.physical_lr == 0x10 && edge.injected_lr[5] == 0);
    return true;
}

static bool InvalidRawFrameCannotAdvanceIdentity(void)
{
    NavCaptureProvenanceState state;
    NavCaptureProvenanceEdge edge;
    NavCaptureProvenance_Reset(&state);
    CAPTURE_ASSERT(!NavCaptureProvenance_Observe(&state, 'A', 0x1E, 0, 0, 1234,
        ERGOPTI_NAV_EVENT_UP, 0, 17, 1, 2, &edge));
    CAPTURE_ASSERT(state.next_sequence == 0);
    CAPTURE_ASSERT(!Observe(&state, &edge, 'A', 0x1E, LLKHF_LOWER_IL_INJECTED, 0, 0, 17, 1));
    CAPTURE_ASSERT(state.next_sequence == 0);
    CAPTURE_ASSERT(Observe(&state, &edge, 'A', 0x1E, LLKHF_EXTENDED, 0x9911, 0, 17, 1));
    CAPTURE_ASSERT(edge.flags == LLKHF_EXTENDED && edge.time == 1234 && edge.extra_info == 0x9911);
    CAPTURE_ASSERT(edge.vk == 'A' && edge.sc == 0x1E && edge.sequence == 1);
    return true;
}

static bool CounterFaultCannotRecoverSilently(void)
{
    NavCaptureProvenanceState state;
    NavCaptureProvenanceEdge edge;
    NavCaptureProvenance_Reset(&state);
    state.next_sequence = UINT64_MAX;
    CAPTURE_ASSERT(!Observe(&state, &edge, 'A', 0x1E, 0, 0, 0, 17, 1));
    CAPTURE_ASSERT(state.faulted && state.next_sequence == UINT64_MAX);
    state.next_sequence = 0;
    CAPTURE_ASSERT(!Observe(&state, &edge, 'A', 0x1E, 0, 0, 0, 17, 1));
    CAPTURE_ASSERT(state.faulted);
    return true;
}

static bool HookFreeFlow(uint16_t vk, uint16_t sc, uint8_t kind, uint8_t injection, uint64_t extra)
{
    ErgoptiNav_TestEvent event;
    ErgoptiNav_DispatchResult result;
    uint8_t mask, pass, order;
    memset(&event, 0, sizeof(event));
    event.vk = vk; event.sc = sc; event.kind = kind; event.injected = injection; event.extra_info = extra;
    return ErgoptiNav_TestHookFlow(&event, &result, 0, &mask, &pass, &order) == ERGOPTI_NAV_STATUS_OK;
}

static bool RealRetainedQueueUsesStockNativeTracker(void)
{
    NavCaptureProvenanceEdge first, repeat, released, tail;
    ErgoptiNav_TestEvent sent[8];
    uint32_t count = 0;
    uint8_t mask;
    const uint64_t token = 17;
    CAPTURE_ASSERT(ErgoptiNav_Stop() == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(ErgoptiNav_TestSetRunning(1) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(HookFreeFlow('A', 0x1E, ERGOPTI_NAV_EVENT_UP, ERGOPTI_NAV_INJECTION_PHYSICAL, 0));
    CAPTURE_ASSERT(HookFreeFlow(VK_LSHIFT, 0x2A, ERGOPTI_NAV_EVENT_DOWN, ERGOPTI_NAV_INJECTION_PHYSICAL, 0));
    CAPTURE_ASSERT(ErgoptiNav_BeginTerminalCapture(token) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(HookFreeFlow(VK_LCONTROL, 0x1D, ERGOPTI_NAV_EVENT_DOWN, ERGOPTI_NAV_INJECTION_STANDARD,
        ERGOPTI_NAV_AHK_SEND_LEVEL_BASE - 5));
    CAPTURE_ASSERT(HookFreeFlow('A', 0x1E, ERGOPTI_NAV_EVENT_DOWN, ERGOPTI_NAV_INJECTION_PHYSICAL, 0x9911));
    CAPTURE_ASSERT(HookFreeFlow('A', 0x1E, ERGOPTI_NAV_EVENT_DOWN, ERGOPTI_NAV_INJECTION_PHYSICAL, 0x9911));
    CAPTURE_ASSERT(HookFreeFlow('A', 0x1E, ERGOPTI_NAV_EVENT_UP, ERGOPTI_NAV_INJECTION_PHYSICAL, 0x9911));
    CAPTURE_ASSERT(HookFreeFlow(VK_LSHIFT, 0x2A, ERGOPTI_NAV_EVENT_UP, ERGOPTI_NAV_INJECTION_PHYSICAL, 0));
    CAPTURE_ASSERT(ErgoptiNav_TestCapturedProvenance(token, 0, &first) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(ErgoptiNav_TestCapturedProvenance(token, 1, &repeat) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(ErgoptiNav_TestCapturedProvenance(token, 2, &released) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(first.sequence && first.capture_token == token && first.extra_info == 0x9911);
    CAPTURE_ASSERT(first.reserve_action && first.action_sequence == first.sequence);
    CAPTURE_ASSERT(repeat.repeat && !repeat.reserve_action && repeat.action_sequence == first.action_sequence);
    CAPTURE_ASSERT(released.kind == ERGOPTI_NAV_EVENT_UP && (released.flags & LLKHF_UP));
    CAPTURE_ASSERT(released.action_sequence == first.action_sequence);
    CAPTURE_ASSERT(NavCaptureProvenance_Effective(&first, 4, &mask) && mask == 0x11);
    CAPTURE_ASSERT(ErgoptiNav_TestReleaseTerminalCapture(token, ERGOPTI_NAV_TERMINAL_RELEASE_COMMIT,
        1, sent, 8, &count) == ERGOPTI_NAV_STATUS_OS_ERROR && count == 1);
    CAPTURE_ASSERT(ErgoptiNav_TestCapturedProvenance(token, 0, &tail) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(tail.sequence == repeat.sequence && tail.action_sequence == first.action_sequence);
    CAPTURE_ASSERT(NavCaptureProvenance_Effective(&tail, 4, &mask) && mask == 0x11);
    CAPTURE_ASSERT(ErgoptiNav_TestCapturedProvenance(token + 1, 0, &tail) == ERGOPTI_NAV_STATUS_OWNER_MISMATCH);
    CAPTURE_ASSERT(ErgoptiNav_TestReleaseTerminalCapture(token, ERGOPTI_NAV_TERMINAL_RELEASE_COMMIT,
        UINT32_MAX, sent, 8, &count) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(ErgoptiNav_TestCapturedProvenance(token, 0, &tail) == ERGOPTI_NAV_STATUS_NOT_FOUND);
    CAPTURE_ASSERT(ErgoptiNav_TestSetRunning(0) == ERGOPTI_NAV_STATUS_OK);
    CAPTURE_ASSERT(ErgoptiNav_Stop() == ERGOPTI_NAV_STATUS_OK);
    return true;
}

/** Registered through the unchanged original native test runner. */
bool ErgoptiNav_TestCaptureProvenance(void)
{
    if (!InitialDownIsNotReleasedProof() || !DownRepeatUpKeepsOriginalGeneration()
            || !ModifierLevelsRemainIndependentAndFrozen() || !ReplayAndLowerIntegrityCannotClearPhysical()
            || !InvalidRawFrameCannotAdvanceIdentity() || !CounterFaultCannotRecoverSilently()
            || !RealRetainedQueueUsesStockNativeTracker())
        return false;
    printf("Capture provenance controls passed: 7/7 (recording; hook=0 input=0).\n");
    return true;
}
