-- Private native fixture instrumentation. Every original luv callback/return is
-- delegated unchanged; fixed scalar receipts never authorize native retirement.
local retained_diagnostics = {} -- Exact diagnostic FD debt survives constructor refusal.
return function(uv, ffi, directory, guardian_pid)
	local original = {}
	for _, name in ipairs({ "fs_open", "fs_read", "fs_write", "fs_close", "fs_fstat", "fs_fsync",
		"spawn", "write", "shutdown", "close", "new_timer", "timer_start", "hrtime" }) do
		original[name] = assert(uv[name])
	end
	local diagnostic = { refused = false, cases = {}, processes = {}, handles = {}, files = {}, sequence = 0 }
	retained_diagnostics[#retained_diagnostics + 1] = diagnostic
	local allowed = { producer = true, names = true, verbose = true, extract = true }
	local function raw_write(name, bytes)
		local fd = original.fs_open(directory .. "/" .. name, "wx", 384)
		if not fd then return false end
		local owner = { fd = fd, state = "open" }; diagnostic.files[#diagnostic.files + 1] = owner
		local called, ack = pcall(function()
			return original.fs_write(fd, bytes, 0) == #bytes and original.fs_fsync(fd) == true
		end)
		owner.state = "closing"
		local closed, result = pcall(original.fs_close, fd)
		owner.state = closed and (result == true or result == 0) and "closed" or "uncertain-close"
		return called and ack == true and owner.state == "closed"
	end
	local function identity(pid)
		assert(type(pid) == "number" and pid > 0 and pid % 1 == 0)
		local fd = assert(original.fs_open("/proc/" .. string.format("%.0f", pid) .. "/stat", "r", 0))
		local owner = { fd = fd, state = "open" }; diagnostic.files[#diagnostic.files + 1] = owner
		local called, result = pcall(function()
			local bytes = assert(original.fs_read(fd, 2049, 0)); assert(#bytes <= 2048)
			local actual, rest = bytes:match("^(%d+) %(.+%) (.+)$"); assert(tonumber(actual) == pid)
			local fields = {}; for field in rest:gmatch("%S+") do fields[#fields + 1] = field end
			local parent, group, birth = tonumber(fields[2]), tonumber(fields[3]), tonumber(fields[20])
			assert(parent and group and birth and parent > 0 and group > 0 and birth > 0)
			return { pid = pid, parent = parent, group = group, birth = birth }
		end)
		owner.state = "closing"
		local closed, ack = pcall(original.fs_close, fd)
		owner.state = closed and (ack == true or ack == 0) and "closed" or "uncertain-close"
		assert(called and owner.state == "closed", "private spawn identity receipt unavailable")
		return result
	end
	local function persist_identity(role, receipt)
		assert(allowed[role] or role == "lua")
		local bytes = string.format('{"schema":1,"role":"%s","pid":%.0f,"parent_pid":%.0f,"group_id":%.0f,"birth_ticks":%.0f}\n',
			role, receipt.pid, receipt.parent, receipt.group, receipt.birth)
		assert(raw_write(string.format("spawn-%03d.json", #diagnostic.processes), bytes), "private spawn receipt publication unavailable")
	end
	-- The fixture retains this owner before any fallible identity/FD acquisition.
	function diagnostic:initialize()
		assert(not self.initialized and not self.initializing, "private diagnostics already acquired")
		self.initializing = true
		local receipt = identity(tonumber(ffi.C.getpid()))
		assert(receipt.parent == guardian_pid and tonumber(ffi.C.getppid()) == guardian_pid,
			"existing native subreaper guardian is mandatory")
		self.processes[1] = receipt; persist_identity("lua", receipt)
		self.initialized, self.initializing = true, false
		return true
	end
	function diagnostic:begin(role)
		assert(self.initialized and allowed[role] and #self.cases < 16)
		local case = { role = role, read_pending = false, write_pending = false, shutdown_pending = false,
			reader_close_pending = false, reader_closed = false, child_exit_ack = false,
			read_submission = "absent", write_submission = "absent", shutdown_submission = "absent", reader_close_submission = "absent",
			stdin_closed = false, stdout_closed = false, stderr_closed = false,
			process_closed = false, timer_closed_count = 0, callback_count = 0 }
		self.cases[#self.cases + 1] = case; self.active = case; return case
	end
	local function boolean(value) return value == true and "true" or "false" end
	function diagnostic:checkpoint(reason)
		if reason ~= "timer-fired" and reason ~= "await-deadline" and reason ~= "cleanup" then return false end
		if self.sequence >= 32 then self.refused = true; return false end
		self.sequence = self.sequence + 1
		local case = self.active
		if not case then return false end
		local bytes = string.format('{"schema":1,"phase":"%s","reason":"%s","read_submission":"%s","write_submission":"%s","shutdown_submission":"%s","reader_close_submission":"%s","read_pending":%s,"write_pending":%s,"shutdown_pending":%s,"reader_close_pending":%s,"reader_closed":%s,"child_exit_ack":%s,"stdin_closed":%s,"stdout_closed":%s,"stderr_closed":%s,"process_closed":%s,"timer_closed_count":%d,"completion_callback_count":%d,"diagnostic_refused":%s}\n',
			case.role, reason, case.read_submission, case.write_submission, case.shutdown_submission, case.reader_close_submission, boolean(case.read_pending), boolean(case.write_pending), boolean(case.shutdown_pending),
			boolean(case.reader_close_pending), boolean(case.reader_closed), boolean(case.child_exit_ack),
			boolean(case.stdin_closed), boolean(case.stdout_closed), boolean(case.stderr_closed), boolean(case.process_closed),
			case.timer_closed_count, case.callback_count, boolean(self.refused))
		local called, ack = pcall(raw_write, string.format("checkpoint-%03d.json", self.sequence), bytes)
		if not called or ack ~= true then self.refused = true; return false end
		return true
	end
	function diagnostic:available()
		if not self.initialized or self.refused then return false end
		for _, file in ipairs(self.files) do if file.state ~= "closed" then return false end end
		return true
	end
	uv.spawn = function(executable, options, callback)
		local case = diagnostic.active
		local process, pid, err = original.spawn(executable, options, function(...)
			if case then case.child_exit_ack = true end
			return callback(...)
		end)
		if process then
			-- Hold actual process/stdio capabilities before fallible receipt capture.
			diagnostic.handles[process] = { case = case, role = "process" }
			for index, role in ipairs({ "stdin", "stdout", "stderr" }) do
				local handle = options.stdio[index]
				if handle then diagnostic.handles[handle] = { case = case, role = role } end
			end
			local held = { process = process, pid = pid }; diagnostic.processes[#diagnostic.processes + 1] = held
			local captured, receipt = pcall(identity, pid)
			if captured then
				held.identity = receipt
				local saved = pcall(persist_identity, case and case.role or "producer", receipt)
				if not saved then diagnostic.refused = true end
			else diagnostic.refused = true end
		end
		return process, pid, err
	end
	uv.fs_read = function(fd, capacity, offset, callback)
		if not callback then return original.fs_read(fd, capacity, offset) end
		local case = diagnostic.active
		if case then case.read_pending = true; case.read_submission = "submitting" end
		local request, err, code = original.fs_read(fd, capacity, offset, function(...)
			if case then case.read_pending = false; case.read_submission = "callback" end
			return callback(...)
		end)
		if case and case.read_submission == "submitting" then
			case.read_submission = request ~= nil and "accepted" or "refused"
			case.read_pending = request ~= nil
		end
		return request, err, code
	end
	uv.write = function(handle, bytes, callback)
		local case = diagnostic.active
		if case then case.write_pending = true; case.write_submission = "submitting" end
		local request, err, code = original.write(handle, bytes, function(...)
			if case then case.write_pending = false; case.write_submission = "callback" end
			return callback(...)
		end)
		if case and case.write_submission == "submitting" then
			case.write_submission = request ~= nil and "accepted" or "refused"
			case.write_pending = request ~= nil
		end
		return request, err, code
	end
	uv.shutdown = function(handle, callback)
		local case = diagnostic.active
		if case then case.shutdown_pending = true; case.shutdown_submission = "submitting" end
		local request, err, code = original.shutdown(handle, function(...)
			if case then case.shutdown_pending = false; case.shutdown_submission = "callback" end
			return callback(...)
		end)
		if case and case.shutdown_submission == "submitting" then
			case.shutdown_submission = request ~= nil and "accepted" or "refused"
			case.shutdown_pending = request ~= nil
		end
		return request, err, code
	end
	uv.fs_close = function(fd, callback)
		if not callback then return original.fs_close(fd) end
		local case = diagnostic.active
		if case then case.reader_close_pending = true; case.reader_close_submission = "submitting" end
		local request, err, code = original.fs_close(fd, function(err, ...)
			if case then case.reader_close_pending = false; case.reader_close_submission = "callback"; case.reader_closed = err == nil end
			return callback(err, ...)
		end)
		if case and case.reader_close_submission == "submitting" then
			case.reader_close_submission = request ~= nil and "accepted" or "refused"
			case.reader_close_pending = request ~= nil
		end
		return request, err, code
	end
	uv.new_timer = function(...)
		local handle, err = original.new_timer(...)
		if handle then diagnostic.handles[handle] = { case = diagnostic.active, role = "timer" } end
		return handle, err
	end
	uv.timer_start = function(handle, delay, repeat_delay, callback)
		return original.timer_start(handle, delay, repeat_delay, function(...)
			if repeat_delay == 0 then pcall(diagnostic.checkpoint, diagnostic, "timer-fired") end
			return callback(...)
		end)
	end
	uv.close = function(handle, callback)
		local captured = diagnostic.handles[handle]
		return original.close(handle, function(...)
			if captured and captured.case then
				if captured.role == "timer" then captured.case.timer_closed_count = captured.case.timer_closed_count + 1
				else captured.case[captured.role .. "_closed"] = true end
			end
			if callback then return callback(...) end
		end)
	end
	return diagnostic
end
