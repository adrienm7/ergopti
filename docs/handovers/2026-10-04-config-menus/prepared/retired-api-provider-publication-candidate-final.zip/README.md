# Stored retired API-provider publication candidate

Frozen source patch SHA256:6ddf9980736c14495640c66ca1803d12d5bf72e11f4d3c2db35db025d1a3b9bd. Six exact paths in patch-manifest.json: shared pure identity policy, three Linux native owners, one new registered test module and one manifest insertion. preimages/ and postimages/ reconstruct exactly with git apply; LF and Lua5.4 parse pass. No TODO hunk is included. Independent peer source review and full qualification remain pending; this is a prepared candidate, not integrated work.

The Linux store previously admitted a removed provider into its runtime entries and active selection. Ordinary usable-neighbor writes normalized that obsolete row by adding model/base_url defaults. The new stored-row classifier consumes an explicitly published detached identity receipt from the existing native catalogue owner. Actual cloud/local projection must each be nonempty and admitted; both physical read/close acknowledgements must succeed. Missing, malformed, valid-but-empty, zero projected and unacknowledged catalogues never prove retirement. Native exceptions are reported and leave configuration authority unavailable for that owner generation, including its partial cache.

Only existing-source rows consume the retirement policy. Unsupported text types retain the existing outdated owner; unprovable optional-auth choices remain carried until an actual publication. Explicit add/local mutation authentication and provider registration/transport semantics remain unchanged. Ignored source rows, future fields, list order, dangling active references and JSON null/array identities travel through the existing private-file publication owners. One warning per exact row/reason plus the dangling active reference uses config_outdated.report_in_file. Tokens are never logged.

Mac already warns and disables retired-provider warmup/predictions while retaining durable settings/Keychain entries. No Mac credential or transport changes are included. No generated contracts or shared corpus was changed. Provider registration and authentication formats remain their actual owners.

Composition: archive feature6370e0d9344f1a94ce2caeddced4a0528ba93dfd plus exact api_remote.lua and its unchanged remote_formats/text_utils dependencies from dev3b4afeba128bdcf9fb1155754742792c95f250fc. The new IPv6, error-envelope and UTF8 transport guards are preserved. Linux test_manifest preimage is the actual feature6370 inventory; integration must compose its single inserted module with all newer dev inventory entries rather than replace the manifest. Saved unchanged dependency hashes are in newdev-unchanged-dependencies.json.

Causal evidence: the original frozen invented-credential/private-file probe fails on exact old owners at the independent reader and complete-model expectations; both pass on the candidate. Six registered cases using only preexisting native APIs fail0/6 on the exact old owner bytes and pass on the candidate on both Lua runtimes. No old failure depends on missing new APIs. The full new module passes36/0 on LuaJIT and Lua5.4. It exercises actual read/close boundaries over real files, both initialization orders, empty/unavailable inventories, nil/false/truthy/wrong/exception receipts, publication refusal/retry, source models, warning privacy and explicit lifecycle repair. Stock Lua's fixture uses actual libuv private-file syscalls in place of unavailable FFI; LuaJIT keeps the production libc writer. This is not a physical device or actual remote-server test.

Original selected modules remain unchanged: LuaJIT API store28/0, remote17/0 and local discovery9/0 (54/0). Lua5.4 remote17/0 and local discovery9/0 (26/0). No assertions were removed/weakened and no corpus expectations were regenerated. Results/logs and exported verify-change selection are included. Full suites, E2E, packaging/installation, actual network servers, hardware and CI were not executed.

Portable replay after ZIP extraction, with source root/review directory supplied explicitly:

    cd <candidate-root>/static/ergopti_plus/linux
    luajit <review-dir>/focused.lua tests.unit.modules.llm.test_api_entries_retired_provider
    lua5.4 <review-dir>/focused.lua tests.unit.modules.llm.test_api_entries_retired_provider
    luajit <review-dir>/old-owner-focused.lua <review-dir>
    luajit <review-dir>/old-owner-probe.lua <review-dir> <candidate-root> reader
    luajit <review-dir>/old-owner-probe.lua <review-dir> <candidate-root> preservation
    luajit <review-dir>/frozen-original-probe.lua <candidate-root> reader
    luajit <review-dir>/frozen-original-probe.lua <candidate-root> preservation

The two old probes and old-focused runner intentionally exit1; the candidate commands exit0. The old runners load exact native source bytes from saved preimages through package.preload; all other unchanged dependencies and real source IO stay in the candidate archive. No root checkout, refs/index, CI or system packages were modified. One failed redundant full-archive preparation exhausted disk; only that newly created incomplete archive was discarded via the narrow authorized cleanup. All candidate/evidence data remain intact.
