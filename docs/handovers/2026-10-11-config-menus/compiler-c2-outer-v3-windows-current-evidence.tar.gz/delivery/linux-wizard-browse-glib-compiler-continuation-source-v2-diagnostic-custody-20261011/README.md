# Genuine partial chooser installation continuation

Source-only preparation; no parser, verifier, download, extraction, compilation,
native process, namespace, canonical Source, index or ref operation executed by
the author. Root's actual V4 installer passed genuine default sqv verification
and extracted all11 trusted payloads, then failed because the system schema
compiler is absent. Its raw failure log and refusal are preserved here unchanged.
The existing owned prefix must be continued, never deleted or blindly reinstalled.

The signed original index contains compiler bin2.84.4-3~deb13u5 with an exactu5
library dependency; host library isu3. Only two genuine packages are required:
libglib2.0-bin and the exact libglib2.0-0t64, 1,653,608 download bytes. The existing
unconstrained libglib2.0-data package remains untouched. All other host dependency
versions are captured and checked with the genuine Debian version comparator.

The continuation admits the exact1592 partial prefix entries (1591children plus
the root), membership/kinds/modes/bytes, all44 effective schema source files,
original11 payload hashes, authenticated Release, prior actual failure, frozen
V4 sources, host package state, Root's actual successful qualification, exact
sole title commit4a3 and clean published feature. It freshly verifies the exact
same InRelease using pinned genuine sqv with default current-time/expiry/crypto
policy and trust, comparing its authentic cleartext with the preserved output.
It never uses a fake compiler or a signature/time/policy waiver.

New packages are hash/size/control-checked and extracted only to the new owned
`/workspace/tooling/wizard-browse-zenity-v1/compiler` child prefix. Only the schema
compiler process receives this child's GLib library path. The original zenity,
GTK environment, host data and old eleven packages are unchanged. The real
compiler runs --strict on the actual preserved44 schema inputs. The original
reviewed wrapper and the actual INSTALL-RECEIPT are created only at previously
absent owned paths. All old partial entries and Root Source/raw-index/HEAD/input
guards are reconciled independently; a raw primary survives secondary fence debt.

The completed receipt retains original V4 signature provenance, new actual
compiler-index signature/command/output, compiler payloads/binary/command/exit,
strict compilation output and continuation Source pins. It records dependencies
installed, with native chooser and Browse explicitly UNRUN. Existing receipts and
failure evidence are never rewritten. Root must still qualify actual loader/GUI
and execute the separately reviewed Browse outer fence.

V2 preserves the entire V1 executable except protecting a best-effort secondary
error diagnostic: stdout refusal must not replace an already retained raw
compiler/download failure. V1 and its Source review remain immutable.

## Exact Root execution after review

Verify this packet's helper/proposal/manifest SHA against its independent Source
review, retain the published4a3 checkout and native slot, then run:

```bash
python3 /workspace/ergopti-delivery/group1-complete-resume-20261007/linux-wizard-browse-glib-compiler-continuation-source-v2-diagnostic-custody-20261011/continue-owned-chooser.py --execute
```

Capture the actual exit/raw log and the new INSTALL-RECEIPT SHA. A failed attempt
keeps its new compiler/authentication files and requires a newly reviewed exact
partial successor; do not rerun through changed preimages or delete the prefix.
The existing V4 worker/controller/actor/oracles remain unchanged. The Browse outer
fence needs only the continuation provenance/input metadata binding before its
genuine runtime, not new native expectations or regenerated corpora.
