const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const source=fs.readFileSync('/workspace/ergopti-windows-r6-ui-metrics/tools/test/test-metrics-filter-cache.cjs','utf8');
const a=source.indexOf('function publishTypingPage('),b=source.indexOf("for (const host of ['windows', 'macos', 'linux']) {",a);
process.env.TZ='UTC';
eval(source.slice(a,b)+fs.readFileSync(__dirname+'/typing-live-chart-probe-body.cjs','utf8'));
