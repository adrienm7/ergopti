
package.path = "/workspace/ergopti-validation/linux-runtime-candidate/resolver-preparation/shared/?.lua;/workspace/ergopti-validation/linux-runtime-candidate/resolver-preparation/linux/?.lua;/workspace/ergopti/static/ergopti_plus/linux/?.lua;/workspace/ergopti/static/ergopti_plus/_shared/lua/?.lua;" .. package.path
local uv = require("luv")
local Resolver = require("modules.llm.ollama_install_resolver")
local root = assert(uv.fs_lstat("/"))
local uid = uv.getuid()
local writes = 0
local backend = { getuid=uv.getuid, os_uname=uv.os_uname, fs_lstat=uv.fs_lstat, fs_access=uv.fs_access,
 fs_mkdir=function() writes=writes+1 error("read-only namespace probe refused any write") end }
local resolver, reason = Resolver.new({ native=backend })
print("actual_uid=" .. uid .. " root_inode_uid=" .. root.uid .. " root_mode=" .. root.mode .. " reason=" .. tostring(reason) .. " attempted_writes=" .. writes)
assert(uid == 1000 and root.uid == 65534, "actual namespace identity changed; do not fabricate expected ancestry")
assert(resolver == nil and reason == "install_ancestor_foreign_owner", "unmapped root must refuse exact owner admission")
assert(writes == 0 and not uv.loop_alive(), "read-only refusal must acquire no writes or native handles")
print("Actual namespace refusal: 1 passed, 0 failed; no positive installation claim")
