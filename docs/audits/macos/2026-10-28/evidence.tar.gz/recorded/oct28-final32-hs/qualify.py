from pathlib import Path
import json,re,hashlib,datetime
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-final32-hs');d=json.loads((O/'receipt.json').read_text());assert d['state']=='ALL_SELECTED_GATES_ACTUAL0' and d['actual_producer_exit']==0
allmods=[];declared=[];cases=[];groups=[]
for g in d['gates']:
 p=Path(g['log']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==g['log_sha256'];s=raw.decode(errors='replace');name=g['name']
 if name.startswith('hs-') and name not in ('hs-groups-inventory','hs-e2e'):
  h=re.search(r'Module group "([^"]+)": (\d+) of (\d+) module\(s\)',s);assert h,name
  loaded=re.findall(r'^>>> Loading ([^\r\n]+)',s,re.M);assert int(h[2])==len(loaded);declared.append(int(h[3]));allmods.extend(loaded)
  for line in s.splitlines():
   if line.startswith('# lua_timing '):
    x=json.loads(line[len('# lua_timing '):])
    if x.get('module')=='tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_deferred_errors' and x.get('kind')=='case':cases.append(x)
assert len(declared)==8 and len(set(declared))==1 and len(allmods)==len(set(allmods))==declared[0]
assert len(cases)==2 and all(x['status']=='pass' for x in cases)
s=(O/'hs-e2e.log').read_text(errors='replace');m=re.search(r'^# pass (\d+) / (\d+)$',s,re.M);assert m and int(m[1])==int(m[2])==185
skip=re.search(r'^# skip (\d+) driver-specific vector\(s\) or host-specific scenario\(s\)$',s,re.M);assert skip and int(skip[1])==1
obs=d['after_observer'];assert not obs['live_refs'] and not obs['unreadable_live_same_uid']
full=__import__('subprocess').check_output(['git','diff','--cached','--binary','--full-index'],cwd=d['worktree']);(O/'full-staged.patch').write_bytes(full)
q={'qualified_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_commit':d['source_commit'],'source_tree':d['source_tree'],'actual_producer_exit':0,'selected_gates_all_actual0':True,'full_mac_unit_tests':d['hs_partition'],'canonical_partition_complete':True,'new_deferred_error_regression_cases':cases,'e2e':{'pass':185,'total':185,'preexisting_driver_or_host_specific_na':1,'scenario_bodies_not_modified_by_this_validator':True},'residual_observer':obs,'zombie_count_note':'Observer field preexisting_zombie_count is an observed count at each checkpoint; before/after counts do not establish cause, reaping, or ownership. Zombies are not live test readers.','before_observed_zombie_count':d['before_observer']['preexisting_zombie_count'],'after_observed_zombie_count':obs['preexisting_zombie_count'],'receipt_sha256':hashlib.sha256((O/'receipt.json').read_bytes()).hexdigest(),'full_staged_patch_sha256':hashlib.sha256(full).hexdigest(),'scope':'Linux-host Lua54/Hammerspoon modeled native ports, actual LuaJIT/luv/lfs/SQLite helpers. No Darwin/AppKit/Carbon/physical keyboard qualification inferred.'}
(O/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in ('full_mac_unit_tests','new_deferred_error_regression_cases','residual_observer')},indent=2));print(d['hs_partition'])
