
const page=loadMetricsTypingPage('windows');freezePageClock(page,'2026-01-01T00:30:00Z');
const charts=[];const canvas=page.context.document.createElement('canvas');canvas.getContext=()=>({owner:'wpm'});page.elements.set('wpm_chart',canvas);
page.context.Chart=class ChartPort{constructor(port,config){assert.equal(port.owner,'wpm');charts.push(config);}destroy(){}};
const manifest={
 '2025-12-31':{Editor:{chars:7,wpm_chars:7,time:7000,hourly:{'23':{c:7}},hourly_min5:{'23:35':{c:7}}}},
 '2026-01-01':{Editor:{chars:3,wpm_chars:3,time:3000,hourly:{'00':{c:3}},hourly_min5:{'00:05':{c:3}}}}
};
publishTypingPage(page,'windows',manifest);
page.elements.get('quick_range').value='last_hour';page.context.apply_quick_date_range();
page.timers.at(-1)();
const request=JSON.parse(page.posts.at(-1));const chart=charts.at(-1);const points=Array.from(chart.data.datasets[0].data,p=>({x:p.x.toISOString(),y:p.y}));
console.log(JSON.stringify({request,points,title:page.elements.get('wpm_chart_title')?.textContent,cutoff:vm.runInContext('app_state.hour_cutoff',page.context),errors:page.diagnostics.filter(x=>x.level==='error')}));
assert.equal(request.start_date,'2025-12-31','a last-hour request at00:30 must admit the previous evening');
assert.deepEqual(points,[{x:'2025-12-31T23:35:00.000Z',y:7},{x:'2026-01-01T00:05:00.000Z',y:3}]);
