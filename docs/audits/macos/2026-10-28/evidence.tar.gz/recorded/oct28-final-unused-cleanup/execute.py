exec(open('/workspace/scratch/oct28-final-unused-cleanup/retire.py').read().split('TARGETS=')[0])
r=json.loads((S/'preparation.json').read_text());assert r['before']['root']==snapshot(ROOT);assert r['before']['original']==snapshot(ORIG)
refs=['fix/macos']+[x['branch'] for x in r['targets']]
bundle=S/'source-history.bundle';res=git(ROOT,'bundle','create',str(bundle),*refs,'^origin/dev',check=False)
r['bundle']={'path':str(bundle),'create_exit':res.returncode,'stderr':res.stderr.decode(errors='replace')};assert res.returncode==0
v=git(ROOT,'bundle','verify',str(bundle),check=False);r['bundle'].update(verify_exit=v.returncode,sha256=sha(bundle.read_bytes()),bytes=bundle.stat().st_size,heads=git(ROOT,'bundle','list-heads',str(bundle)).stdout.decode());assert v.returncode==0
(S/'bundle-verify.log').write_bytes(v.stdout+v.stderr)
for row in r['targets']:
 p=Path(row['path']);zone=row['zone']
 try:
  assert row['ready'];assert git(p,'rev-parse','HEAD').stdout.decode().strip()==row['expected_head']
  assert git(p,'symbolic-ref','--short','HEAD').stdout.decode().strip()==row['branch']
  assert git(p,'write-tree').stdout.decode().strip()==row['tree']
  assert physical(p)==row['physical'];assert git(p,'diff','--exit-code',check=False).returncode==0
  assert git(p,'ls-files','--others','--exclude-standard','-z').stdout==b''
  ignored=[os.fsdecode(v) for v in git(p,'ls-files','--others','--ignored','--exclude-standard','-z').stdout.split(b'\0') if v];assert ignored==row['ignored']
  archive=S/(zone+'-ignored.tar.gz');members=[]
  with tarfile.open(archive,'w:gz',dereference=False) as tar:
   for relative in ignored:
    f=p/relative;t=f.lstat();assert not stat.S_ISDIR(t.st_mode),relative
    tar.add(f,arcname=relative,recursive=False)
    members.append({'path':relative,'mode':oct(stat.S_IMODE(t.st_mode)),'inode':t.st_ino,'size':t.st_size,'symlink':os.readlink(f) if f.is_symlink() else None,'sha256':None if f.is_symlink() else sha(f.read_bytes())})
  with tarfile.open(archive,'r:gz') as tar:
   archived=tar.getmembers();assert [x.name for x in archived]==ignored
   for item,m in zip(archived,members):
    if m['symlink'] is not None:assert item.issym() and item.linkname==m['symlink']
    else:assert sha(tar.extractfile(item).read())==m['sha256']
  row['archive']={'path':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':members,'verified':True,'dependencies_not_followed':True}
  row['last_process_check']=process_refs(p);assert not row['last_process_check']['refs'] and not row['last_process_check']['unknown']
  if zone=='linux':
   patch=Path('/workspace/scratch/oct28-bsd-writer-assembly/full.patch');assert sha(patch.read_bytes())=='d16b614218ef14f6d503b994a67b9702b44f2e6ef4fcd1637a3a90dbcb1b2c2b'
   assert sha(git(p,'diff','--cached','--binary','--full-index').stdout)==sha(patch.read_bytes())
   c=git(p,'apply','--reverse','--index','--check',str(patch),check=False);row['inverse_check_exit']=c.returncode;assert c.returncode==0,c.stderr
   a=git(p,'apply','--reverse','--index',str(patch),check=False);row['inverse_exit']=a.returncode;assert a.returncode==0,a.stderr
  assert git(p,'diff','--exit-code',check=False).returncode==0;assert git(p,'diff','--cached','--exit-code',check=False).returncode==0
  assert git(p,'ls-files','--others','--exclude-standard','-z').stdout==b''
  row['last_process_check']=process_refs(p);assert not row['last_process_check']['refs'] and not row['last_process_check']['unknown']
  rm=git(ROOT,'worktree','remove',str(p),check=False);row['normal_remove_exit']=rm.returncode;row['normal_remove_stderr']=rm.stderr.decode(errors='replace');assert rm.returncode==0
  assert not p.exists();assert git(ROOT,'rev-parse',row['branch']).stdout.decode().strip()==row['expected_head']
  row['removed']=True;print(zone,'removed',flush=True)
 except Exception as e:
  row['removed']=False;row['blocked_after_prepare']=str(e);print(zone,'BLOCKED',str(e)[:200],flush=True)
 (S/'receipt-running.json').write_text(json.dumps(r,indent=2)+'\n')
r['after']={'root':snapshot(ROOT),'original':snapshot(ORIG)};r['protected_invariant']=r['before']==r['after'];assert r['protected_invariant']
r['registry']=git(ROOT,'worktree','list','--porcelain').stdout.decode();r['free_after']=os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize
r['removed_allocated_bytes']=sum(x['size_before']['allocated_bytes']for x in r['targets']if x.get('removed'));r['archive_bytes']=sum(x.get('archive',{}).get('bytes',0)for x in r['targets'])+bundle.stat().st_size
r['free_delta_observed']=r['free_after']-r['free_before'];r['free_delta_caveat']='Concurrent validations write to separate retained worktrees and scratch; filesystem free delta is not exact per-target ownership accounting.'
r['scope']='Exactly five authorized unused worktrees. No refs deleted, no protected original/Root/active validator/dependency target mutated. No external TMP/XDG deletion; no signal sent; no reset/stash/clean/force. Ignored archives store links without following them; Git normally removes clean checkout including tracked .gitkeep.'
r['state']='COMPLETE' if all(x.get('removed')for x in r['targets'])else 'PARTIAL_BLOCKED'
r['completed_paris']=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).isoformat()
(S/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'state':r['state'],'removed_allocated_bytes':r['removed_allocated_bytes'],'archive_bytes':r['archive_bytes'],'protected_invariant':r['protected_invariant'],'receipt_sha256':sha((S/'receipt.json').read_bytes())}))
