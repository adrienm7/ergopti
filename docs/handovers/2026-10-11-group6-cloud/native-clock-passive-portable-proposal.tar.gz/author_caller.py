"""Source-only exact optional export over the tested clock156 caller."""
from pathlib import Path
import ast,difflib,json,hashlib
BASE=Path(__file__).resolve().parent
REL='static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
before=(BASE/'preimage'/REL).read_text()
source=before
addition=(BASE/'caller-passive-addition.py').read_text()+'\n\n'
anchor='def receive_native_clock(build, builder):\n'
assert source.count(anchor)==1
source=source.replace(anchor,addition+anchor,1)
call='            cls.build.build()\n'
prepare='            prepare_native_clock_evidence(cls.build)\n'
assert source.count(call)==1
source=source.replace(call,prepare+call,1)
old_command='''    status, raw = build.fixture._command(
        [str(executable), "--fixture-clock-proof"], timeout=15, deadline=before + 15
    )
'''
new_command='''    observer = getattr(build, "passive_command_receiver", None)
    if observer is None:
        status, raw = build.fixture._command(
            [str(executable), "--fixture-clock-proof"], timeout=15, deadline=before + 15
        )
    else:
        status, raw = build.fixture._command(
            [str(executable), "--fixture-clock-proof"], timeout=15, deadline=before + 15,
            passive_receiving=lambda fact: observer("clock", fact),
        )
'''
assert source.count(old_command)==1
source=source.replace(old_command,new_command,1)
return_anchor='    # This observation uses stderr; the worker stdout response ABI is unchanged.\n'
export='    export_native_clock_evidence(build, builder, raw, fact)\n'
assert source.count(return_anchor)==1
source=source.replace(return_anchor,export+return_anchor,1)
inverse=source.replace(export+return_anchor,return_anchor,1).replace(new_command,old_command,1).replace(prepare+call,call,1).replace(addition+anchor,anchor,1)
assert inverse==before
ast.parse(source)
(BASE/'candidate'/REL).write_text(source)
(BASE/'caller-passive-inverse.json').write_text(json.dumps({'addition':addition,'anchor':anchor,'prepare':prepare,'prepare_anchor':call,'original_command':old_command,'receiving_command':new_command,'export':export,'export_anchor':return_anchor},indent=2)+'\n')
(BASE/'caller-passive.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),source.splitlines(keepends=True),fromfile='a/'+REL,tofile='b/'+REL)))
print(json.dumps({'caller':hashlib.sha256(source.encode()).hexdigest(),'whole_clock156_inverse':True,'state':'SOURCE_ONLY_UNRUN'},sort_keys=True))
