<!-- QUALIFICATION-PLAN.md -->

# Exact prepared queue qualification plan

SOURCE STAGING ONLY. No model/native/import/compiler execution has occurred.
Root8587 holds the exclusive package/full-gate slot. Do not run these commands
until root grants the next serialized slot.

## Admitted cohort

The isolated qualification/dependency is the literal static/ergopti_plus archive
of471e80b0b1572d589b67a434c07bbd7e0646cac2, plus ONLY the root-authorized pending
canonical linux_native_runtime.json8a80607d9cc0d50cb710cd9b31a1bacd799961da6dd1b431804fc2ca65996f9f.
The writer saved complete dependency and before/after file hashes and refuses
symlink/special files. Main HEAD/catalog were rechecked after staging. Current
main edits to package tools/workflows are not claimed as captured runtime code.

After uses d8f70 ordinary91 +479b live-only coordinator, cc2f callbacks,3c942
forwarding ports and explicit original auth27 port. Before preserves original
471 runtime producer; it receives only identical new control sources and model
port receipt migrations, never a changed producer. The normal-registration
proposal1a573 adds four new module rows and a driver-relative helper header in
both isolated stages, preserving old manifest rows and all factory/assertion
bytes. Root owns any real manifest changes. Every physical source file is bound
in before-SOURCE-FILES.json/after-SOURCE-FILES.json.

## Model commands and outcomes

Run native executables directly when stdout is redirected to a private capture.
Initialize the established /workspace/ergopti-env.sh and TMPDIR=/tmp. Lua5.4
also needs the actual5.4-only LUA_CPATH, rather than the default5.1-first path:

    LUA_CPATH=/workspace/.tools/native/usr/lib/x86_64-linux-gnu/lua/5.4/?.so;;

1. LuaJIT run_models.lua.source qualification/after after:34 new controls.
2. Actual Lua5.4 same34 controls.
3. LuaJIT then Lua5.4 before before:23 producer causal controls. The old shared
   preparation module does not exist, so its11 new pure API controls are honestly
   UNEXECUTED on the unchanged producer; do not count a module-load error as11
   failed controls or import the new module and call it old implementation.
4. After preserved, both ABIs: original full owner meta suite +auth27 +legacy6
   +exact6 identity forwarding. Record actual counts; three original FFI cases
   run on LuaJIT and are unregistered on Lua5.4, never treated as passes there.
5. Re-run normal original137 and FD88 modules unchanged when runtime/package
   dependencies justify them. Their original independent literal expectations
   remain exact. A normal suite or recorded previous137 receipt does not replace
   the new public/native cases.

Capture exit immediately for every direct command. Stop candidate qualification
at the first unexpected failure and release the slot with private evidence;
expected before-producer failures remain distinct. Preserve source/manifests,
private captured logs and typed counts, not raw secret-bearing transcripts.

## Native preflight25 and bodycleanup14

After source/model receipts, request an EXCLUSIVE native slot. Run before and
corrected fixtures in distinct admitted stages against the SAME after producer
so fixture-port observations are causal rather than runtime source changes.
Keep original before25 absence/additive expectation distinctions explicit:
original preflight is24; corrected25 adds one public no-allocation case.

Use the existing genuine hardware/run_native_subreaper.py for native fixtures
that do not own a subreaper themselves, with structured direct LuaJIT argv and
private file sinks. It retains real adopted-descendant/reaping closure receipts.
There is no external hard kill pretending detached child closure. The Curl
request/group and exact close owners remain those of production. Unknown debt
or timeout is a failed/unretired receipt, not a skip or guessed absence.

Preflight retains all public ports/assertions except the EXACT historical180
late-allocation get_owned scope, which uses the actual native engine while its
valid incumbent/get/isActive ports remain public.168 once-conversion queued
replacement and196 owned-debt refusal remain PUBLIC. The extra25th case proves
strong public preflight no-allocation. No whole fixture retarget is allowed.

Body14 records exact production operation/timer receipts and excludes only its
authentic cleanup monitor while intentional close refusal is active. Every
other closing handle remains counted. Final recovery counts every monitor and
requires actual native close ACK/FD absence. Preserve all14 literal assertions.
The six original descriptor-close errors AFTER real retirement may still reveal
a temporal contract difference between legacy boolean cleanup and stronger
managed owned cleanup. Keep the failure visible; do not silently discard their
fencing/callback assertions or call it external/device-only.

## Separate335/native20 cohorts

335 revision3 inventory3350086d remains immutable and unapplied. After a new
explicit slot, prepare separate before/after fixtures for bodylimit84,
literal-target55 and orphan/digest50. Compare every original preimage byte before
use; do not mix their receipts with queue/Body14. The CLI orphan fixture owns
its own subreaper/private exact descendant captures and MUST run DIRECT, with
no competing subreaper or guessed PID/PGID kill. Its known waitpid receipt is
consumed once and every original final oracle still executes.

Native body-pipe20 and its1ms whole-operation deadline/queued-successor cases
are OUTSIDE this qualification. Preserve them as a separate unresolved native
contract cohort; no raw-engine retarget, assertions weakened or automatic
late child acquisition is implied by this plan.
