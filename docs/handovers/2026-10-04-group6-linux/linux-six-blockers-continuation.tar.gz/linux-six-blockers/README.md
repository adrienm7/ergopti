# Linux managed HTTP: six-blocker continuation

This source/control archive preserves a reviewed scratch candidate. It is not an
integrated producer, an executable installation, or permission to replace the
foreign native core. No live repository source, TODO, workflow, branch or native
owner file was modified to produce it. The older Linux preparation archive
remains unchanged.

The final coordinator is SHA256
`60d38dd979c34660d4d93cf918d8152bd89846db92be125a5f012d05aed297a3`.
`FINAL-SOURCE-MANIFEST.json` pins all nine candidate paths and eight saved
preimages. `six-blockers.patch` changes six of these paths, including the new
deadline ledger; it applies only to the saved scratch preimages, never directly
to the current checkout. `MANIFEST.json` checks every archive member's bytes and
identifies source ownership. Raw logs, transcripts, environment dumps, keys and
credentials are excluded.

## Correction and evidence scope

The six corrections preserve the original public owned-cancellation assertions:
refused termination stays active while suppressing owned completion; both APIs
refuse behind owned cleanup debt; supported proxy-resolution failure cannot
silently become DIRECT; a queued request can expire independently of predecessor
cleanup; proxy timeout publishes the Boolean logical result before physical
retirement; and delayed success is fenced by the original absolute deadline.
Only explicitly acknowledged native capability absence retains ordinary
environment routing. Genuine successful native DIRECT remains usable.

Four additional review controls preserve queued timer debt after expiry or
failed arming, aggregate cancellation refusal while still cancelling the
predecessor, and prevent synchronous listener cancellation from acquiring a new
system child. Queue links detach only after exact timer close ACK; a settled
predecessor adopts an expired/cancelled successor as a retirement-only owner.

There are **105 passing controls in two distinct categories**: 101 model/native
port controls and four actual LuaJIT/luv timer controls. The unchanged saved
producer fails 11 of the same 13 public cases (two pass, exit 1); the corrected
candidate passes all 13. Each additional review control fails its own saved
first-candidate checkpoint before passing the correction. These are not four
additional old-production defects. `VALIDATION.json` and `VALIDATION.md` report
the executed, failed, skipped and unexecuted categories explicitly.

The actual native cases prove timer arming, expiry, logical/physical separation,
reentrant settlement and exact `uv.walk` handle restoration. They create no child
process and establish no final GIO/curl/PAC/CONNECT/privacy/installation result.
`REVIEW.md` records the final source-only peer review, not native clearance.

## Native-owner prerequisite and forbidden stale substitution

The prerequisite is foreign `fix/linux` commit
`ec9673283b6d2eb1dadc7914cbcfba5043f94957`, native core SHA256
`8c5d52f8c1d2e11fea477bab68f764f0315ff1997556faab1a92e8c41c903305`.
Its body-pipe, descriptor retirement, complete-body budget, POST303, globoff and
empty-header changes must survive composition. The candidate's older
`curl_http_client.lua` is retained solely for the original causal model replay;
it must never replace the current native owner's core. No foreign core or body
pipe implementation is included here.

`support/infra/native_timer.lua` is the exact foreign helper, SHA256
`35db96358d9224e70b54d60cb1cadacc043186fa2dbab88d8340b570d6b49c63`.
It is a read-only qualification dependency, not an ours-owned production addition.
The new deadline ledger delegates arming to that helper and owns only its own
timer's close ACK. Final composition must reuse the owner's published helper.

`owner-bridge/PROPOSAL.md` and `owner-bridge/INPUTS-SHA256.json` are preserved
byte-exact source-only proposals. They require the native owner to expose one
core's pure preflight, generic physical dispatch, signal-acceptance receipt,
pre-close terminal observer, private selection config and actual bounded proxy
metrics. The proposal's coordinator design hash predates the final review fixes;
`owner-bridge/CURRENT-DESIGN.json` explicitly supersedes that design reference.
It does not alter the proposal's foreign source preimages or claim implementation.

## Reproduction after obtaining a serialized test slot

Extract outside the checkout. A prepared repository supplies the unchanged
canonical Lua dependencies and test helpers; LuaJIT plus luv are required. Load
its normal environment activation first. Use absolute paths for these variables:

```bash
export ERGOPTI_SIX_ROOT=/absolute/extracted/linux-six-blockers
export ERGOPTI_HTTP_REPOSITORY=/absolute/prepared/ergopti
export ERGOPTI_SIX_STAGE="$ERGOPTI_SIX_ROOT/candidate"
export ERGOPTI_MANAGED_HTTP_CANDIDATE="$ERGOPTI_SIX_STAGE"
export ERGOPTI_PROXY_ADAPTER_CANDIDATE="$ERGOPTI_SIX_STAGE/static/ergopti_plus/linux/adapters/system_proxy.lua"
export TMPDIR=/tmp
ERGOPTI_SIX_PHASE=public luajit "$ERGOPTI_SIX_ROOT/run-focused.lua"
```

Run phases `public`, `preserved`, `deadline`, `queue`, `arming`, `aggregate` and
`reentry` sequentially against `candidate`: expected 13, 74, 10, 1, 1, 1, 1
passes respectively. For the unchanged public causal replay, change all three
stage variables to `preimages`: expected two pass, 11 fail, exit 1. For the
additional causal controls, use `queue-seam-preimage` for phase `queue`, and
`arm-seam-preimage` for phases `arming`, `aggregate`, `reentry`; each must fail
one case, exit 1. The ten new deadline cases have no old ledger equivalent.

With stage variables restored to `candidate`, run the separate actual primitive:

```bash
luajit "$ERGOPTI_SIX_ROOT/controls/native_deadline_receipts.lua"
```

Do not run driver/native controls concurrently with JS artifact drift checks.
Capture every direct exit status. No command in this archive registers a suite,
dispatches CI, changes a native owner file, or installs production routing.

## Outstanding work

Native-owner publication/review and final one-core composition remain blocking.
Full historical/current native-core suites, shared source-of-truth gates, actual
GIO/curl/CONNECT/PAC/privacy controls on final approved sources, native E2E,
packaging and installed relocation are unexecuted for this packet. Per-hop PAC
redirects, updater destination retry leases, owned Ollama traffic, enterprise
CA/auth/WPAD and existing physical-host follow-ups remain TODO62/16/38 scope.
No TODO is removed and no group-completion claim is made.

`generate-archive.py` verifies the payload manifest and recreates a deterministic
tar.gz from these exact source/control bytes. It never reads ambient credentials
or executes tests. Pass an explicit `--output` outside the extracted directory.
