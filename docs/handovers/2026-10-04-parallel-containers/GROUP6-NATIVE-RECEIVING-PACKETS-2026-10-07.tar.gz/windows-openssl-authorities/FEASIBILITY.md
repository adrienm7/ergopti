# Native OpenSSL server feasibility for Windows managed-network acceptance

Status: SOURCE-ONLY; no backend patch, test, native-library load or product execution.

## Conclusion

Replacing only this test fixture's TLS server with actual native OpenSSL3 is feasible without persisting a private key. No current registered JS/AHK source assertion requires SslStream as the server. The two receiving AHK files contain 108 assertion call sites in the inspected source (36 managed-remote, 72 updater); none needs removal or relaxed expectations. Their exact preimages and the runner include are recorded in REPOSITORY-BINDINGS.json.

The production clients remain unmodified: actual System32 curl Schannel and updater .NET clients, strict Windows system trust, revocation, PAC/CONNECT selection, certificate rejection, exact body/hash, deadlines/cancellation, native Job retirement and root removal. An OpenSSL fixture is an independent real TLS oracle for these clients, rather than a manufactured TLS success or receipt.

## Why SslStream cannot retain the existing private-key lifetime

Current dotnet/runtime SslStreamPal.Windows.cs explicitly says Windows does not support ephemeral keys and maps NoCredentials to net_auth_ephemeral. Maintainer comments in dotnet/runtime#23749 explain that the in-memory key cannot be marshaled across Schannel/LSASS; this was closed as an external Windows dependency without an approved delivery timeline. Persisted PFX or switching to PS7 alone is therefore unsuitable. Those source observations are retained in /tmp/group6-windows-tls-source-audit.

## Available runner dependency and authentication boundary

Official actions/runner-images Install-Git.ps1 obtains the Git-for-Windows installer from its release, fetches the release SHA256 and passes ExpectedSHA256Sum to Install-Binary. The current Windows2025 inventory contains Git 2.55.0.windows.5 and OpenSSL 3.6.4, but those inventory versions are not evidence for our specific run.

Git-for-Windows mingw-w64-openssl/PKGBUILD builds native mingw64 shared OpenSSL from an upstream tarball with pinned SHA256 and permitted release-signing fingerprints. Use only the existing native mingw64/bin libssl-3-x64.dll and libcrypto-3-x64.dll pair from the authenticated Git installation; usr/bin MSYS DLLs are not an equivalent native dependency. Resolve the actual Git installation through its known installed identity, without searching arbitrary OpenSSL DLL directories. The repository's canonical Git resolver derives the installation root from git --exec-path and verifies its MSYS userland; do not add a conflicting general-purpose resolver.

The image build's checksum trust chain is source evidence; actual current DLL existence, hashes, AMD64 PE ABI, imports, version, exported entry points, loader confinement and eventual closure MUST be established on the native runner before the feature can be called qualified. A filename, successful version call or local hash alone is not cryptographic provenance. If explicit per-DLL comparison is required beyond the authenticated-image installation, compare the pair against the same Git release's authenticated artifact/package and refuse a mismatch. No unverified download or installed-file replacement is needed merely to attempt the fixture.

Load the exact absolute native DLL paths with LoadLibraryExW LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_SYSTEM32, verify module paths after load and acquire exactly the required exports via GetProcAddress. Keep delegates rooted while workers exist. Release only this fixture's loader references, after all workers and every SSL/context resource retire; do not unload another owner's module or change global DLL search paths.

## In-memory certificate and key import

Preserve the existing RSACng(2048) rootKey and leafKey, both IsEphemeral checks, unique certificate subject, SAN, EKU, validity and signed CRL, as well as exact-thumbprint CurrentUser/Root public certificate admission/removal. CngAlgorithmCore generates its unnamed key with AllowPlaintextExport, and CngKey.Export returns an in-memory blob through NCryptExportKey. Export the leaf key only as PKCS8 private DER in process memory; import it immediately into the native server context and Array.Clear every managed private DER buffer in finally. No PFX, PEM, PKCS8 file, registry key or persisted certificate private key is introduced.

OpenSSL3.5.4 source/documentation proves SSL_CTX_use_certificate_ASN1 accepts in-memory DER; SSL_CTX_use_PrivateKey_ASN1 accepts a typed private key and invokes d2i_PrivateKey_ex. Its decoder detects PKCS8 PrivateKeyInfo and imports DER into an EVP key. Both context uses take references rather than retaining the caller's managed byte pointer. SSL_CTX_check_private_key must acknowledge the actual certificate/key match before ready. TLS minimum and maximum both remain TLS1.2 (0x0303), through SSL_CTX_ctrl commands 123/124. Never disable the client's verification or revocation.

Initialize only the native backend without ambient OpenSSL configuration (OPENSSL_INIT_NO_LOAD_CONFIG) before creating its first context. Native RSA cleanup clears d/p/q/CRT values with BN_clear_free. Free all SSL connections before the one context, then the DLL references, and only then dispose the existing CNG/certificate objects. Constructor failure must release any partial native allocation; native errors remain fixture failure, not a caught success.

## Preserve threads, actual sockets and deadlines through memory BIOs

Use SSL_set_bio with two owned BIO_s_mem handles and a Stream adapter over each original TcpClient.GetStream(). Do not use SSL_set_fd: its int argument is a dangerous Win64 SOCKET ABI boundary. OpenSSL3 documentation explicitly supports stream I/O through memory BIOs; SSL owns both BIOs after SSL_set_bio, so never double-free them.

The adapter calls SSL_do_handshake/SSL_read/SSL_write, obtains SSL_get_error immediately on the same worker thread without another intervening OpenSSL call, drains generated encrypted bytes to the actual NetworkStream, and supplies actual received encrypted bytes to the input BIO on WANT_READ. Preserve all 5000 ms TcpClient receive/send timeouts and the current fixture 90 s, startup 20 s, shutdown/joins and parent process/Job deadlines. No new retry clock or subprocess daemon. Reject impossible partial BIO writes; WANT_WRITE must produce bounded progress, not an unbounded spin. Clear the native thread error queue immediately before each protocol operation so prior certificate-import errors cannot contaminate SSL_get_error.

Handshake protocol/certificate-alert refusal can retain the existing AuthenticationException/IOException FailedTls counting, because it is generated by actual OpenSSL TLS return states. Backend initialization/key mismatch/export/native-call errors stay unexpected fixture failures. Never catch arbitrary Win32 errors or relabel updater connect as tls. Reads, writes, CRL/PAC HTTP server, CONNECT proxy, original payload handlers, counters and thread ledger remain intact. SSL_free and managed stream disposal retire each native connection when the original TcpClient worker completes; service_stopped is published only after all old joins and native context/DLL closure acknowledge success.

Windows uses LLP64: C long/unsigned long are 32-bit even on x64, while pointers/size_t are 64-bit. Marshal SSL_CTX_ctrl/BIO_ctrl return/long arguments as Int32, ERR_get_error as UInt32, and all pointers as IntPtr. Using C# long for C long would make an apparently working DLL binding incorrect. SSL_read/write, BIO_read/write and lengths are signed int32; bounded buffers avoid size overflow.

## Required receiving evidence before commit/integration claims

1. Source audit/inverse proof retains all original AHK assertion calls and every old native trust/destination/body/counter/ownership expectation; BOM/LF check still applies.
2. Actual native DLL authentication/ABI/export/version receipt and a failed-init wrong-library/key mismatch control; not a mock loader.
3. Native TLS handshake with the original client: untrusted rejection, exact root admission, successful static and PAC generation/readiness, native CRL retrieval and post-removal rejection. Preserve the existing eight-transport/four-rejected-handshake counts.
4. Native updater staging: original trusted exact body/digest and redirect route selection, all HTTP/TLS/integrity/file refusals, live partial stage, original cancellation/deadline and exact Job/context/DLL/root/thread retirement.
5. Independent denial controls: malformed DER/mismatched private key, non-native/wrong-architecture DLL, missing required export and actual connection closure. None may return ready.
6. Full affected Windows workflow_dispatch lane including E2E, package and installation when units pass; original selected verification and source assertions remain active. Other OS product clients are unchanged by the fixture-only backend.

No native claim is made in this source packet. The prerequisite DLL/library behavior and complete acceptance remain unexecuted.
