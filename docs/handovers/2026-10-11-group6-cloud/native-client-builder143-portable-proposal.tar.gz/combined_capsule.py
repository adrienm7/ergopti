"""Source-only final capsule; no suite/native role executes here."""
import ast,difflib,hashlib,json,os,stat,subprocess,tarfile,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent
C=P/'canonical143';REPAIR=P.parent/'group6-r2-canonical-order-repair/candidate'
IND=P.parent/'group6-native-http-callee103-independent-proposal'
TEST='tools/test/macos_native_http_receiving_facts_test.py';REG='tools/test/test-managed-ollama-protocol.cjs'
MAC='static/ergopti_plus/macos/tests/support/'
paths=[MAC+'native_http_wire_fixture.py',MAC+'native_http_fixture_builder.py',MAC+'native_http_wire_client_receiving.py',TEST,REG,'tools/test/macos_native_http_fixture_builder_controls.py','tools/test/macos_native_http_client_root_controls.py']
def digest(b):return hashlib.sha256(b).hexdigest()
patch='';inverse='';manifest={};pre=P/'combined-preimage'
for rel in paths:
 source=REPAIR/rel if rel in [TEST,REG] else IND/'preimage'/rel
 before=source.read_bytes() if source.is_file() else b'';after=(C/rel).read_bytes()
 if before:
  dst=pre/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(before)
 patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 inverse+=''.join(difflib.unified_diff(after.decode().splitlines(True),before.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel if before else '/dev/null'))
 manifest[rel]={'preimage_sha256':digest(before) if before else None,'postimage_sha256':digest(after),'bytes':len(after)}
(P/'combined-proposal.patch').write_text(patch);(P/'combined-inverse.patch').write_text(inverse)
with tempfile.TemporaryDirectory(prefix='root-source-inverse-',dir=P) as name:
 root=Path(name)
 for rel in paths:
  if (pre/rel).is_file():
   dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((pre/rel).read_bytes())
 def snapshot():return {str(f.relative_to(root)):digest(f.read_bytes()) for f in root.rglob('*') if f.is_file()}
 before=snapshot()
 for mode,ppath in [('forward',P/'combined-proposal.patch'),('inverse',P/'combined-inverse.patch')]:
  subprocess.run(['git','apply','--check',str(ppath)],cwd=root,check=True,capture_output=True)
  subprocess.run(['git','apply',str(ppath)],cwd=root,check=True,capture_output=True)
  if mode=='forward':assert snapshot()=={rel:f['postimage_sha256'] for rel,f in manifest.items()}
 assert snapshot()==before
(P/'combined-inverse-review.json').write_text(json.dumps({'forward_exact_all7':True,'inverse_exact_all7':True,'new_paths_removed':True,'live_index_refs_untouched':True},indent=2)+'\n')
# The actual physical subject includes each original whole recipe input.
original_graph=json.loads((IND/'build-inputs.json').read_text())
assert original_graph['input_count']==18
source_graph=[]
for item in original_graph['inputs']:
 rel=item['path'];data=(C/rel).read_bytes();current=digest(data)
 assert current==item['candidate_sha256'], (rel,current,item['candidate_sha256'])
 source_graph.append({'path':rel,'bytes':len(data),'sha256':current})
source_graph += [{'path':rel,'bytes':(C/rel).stat().st_size,'sha256':digest((C/rel).read_bytes())} for rel in [MAC+'native_http_wire_client_receiving.py',TEST,'tools/test/macos_native_http_fixture_builder_controls.py','tools/test/macos_native_http_client_root_controls.py','static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/ManagedHTTPWireTests.swift']]
(P/'physical-runtime-source-closure.json').write_text(json.dumps({'recipe_input_count':18,'all18_match_predecessor_recipe_pins':True,'whole_source_inputs':source_graph,'boundaries':'Physical source subject and final post-run snapshot; no native compiler/stdlib/Python binary qualification or claim of original run pre/post byte fence','owning_invocation':'python -I -B canonical143/tools/test/macos_native_http_receiving_facts_test.py; actual default unittest alphabetical discovery'},indent=2)+'\n')
# Native fixture's command/close/trust spans retain R2/guard behavior exactly.
def methods(path):
 source=path.read_text();lines=source.splitlines(True);tree=ast.parse(source)
 node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='WireFixture')
 return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in node.body if isinstance(n,ast.FunctionDef)}
old=methods(IND/'preimage'/ (MAC+'native_http_wire_fixture.py'));new=methods(C/(MAC+'native_http_wire_fixture.py'))
assert all(old[n]==new[n] for n in ['_command','close','trust'])
(P/'native-owner-preservation.json').write_text(json.dumps({'_command_close_trust_body_bytes_exact':True,'preimage_fixture':digest((IND/'preimage'/(MAC+'native_http_wire_fixture.py')).read_bytes()),'postimage_fixture':digest((C/(MAC+'native_http_wire_fixture.py')).read_bytes()),'native_ownership_credit':False},indent=2)+'\n')
review=json.loads((P/'final-source-review.json').read_text());review['status']='PORTABLE_PHYSICAL_CANONICAL143_PASS_NATIVE_UNRUN';(P/'final-source-review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
(P/'qualification.json').write_text(json.dumps({'original_root_counter':{'tests':1,'failures':1,'errors':0,'skips':0},'corrected_root_counter':{'tests':1,'failures':0,'errors':0,'skips':0},'additional_root_controls':{'tests':6,'failures':0,'errors':0,'skips':0},'durable_root7':{'tests':7,'failures':0,'errors':0,'skips':0},'physical_original136':{'tests':136,'passed':135,'failures':1,'errors':0,'skips':0,'seconds':45.876},'physical_corrected143':{'tests':143,'passed':143,'failures':0,'errors':0,'skips':0,'seconds':45.411},'selector_refusals':6,'relocated_assertion_meaningful_mutants':2,'ruff_check_format':'PASS_ACTUAL_FINAL_BYTES','finite7wholefile_inverse':'PASS','native_compile_signing_security_clock_xctest_packaging_installation':'NOT_EXECUTED_NO_NATIVE_CREDIT','historical_receive103_limitation':'Passed object receiving with live source-read root and declaration-order suite; superseded here only by the new physical143 receipt, not relabeled as historical full-source qualification'},indent=2,sort_keys=True)+'\n')
(P/'combined-manifest.json').write_text(json.dumps({'qualification':'PORTABLE_SOURCE_ONLY_NO_NATIVE_CREDIT','apply_paths':manifest,'sha256':{'combined-proposal.patch':digest(patch.encode()),'combined-inverse.patch':digest(inverse.encode())}},indent=2,sort_keys=True)+'\n')
# Selected regular files only. Runtime private temps/caches never enter capsule.
files=[p for p in C.rglob('*') if p.is_file()]+[p for p in pre.rglob('*') if p.is_file()]
files+=[P/name for name in ['README.md','FINAL_REVIEW.md','combined_capsule.py','prepare.py','compose136.py','enroll143.py','relocate_recipe_assertion.py','freeze_sources.py','portable_root_replacement_test.py','portable_root_replacement_candidate_test.py','portable_root_cleanup_controls.py','original-root-replacement.log','original-root-replacement-receiving.json','candidate-root-replacement.log','candidate-root-replacement-receiving.json','additional-root-cleanup.log','additional-root-cleanup-receiving.json','durable-root7.log','durable-root7-receiving.json','canonical136.log','canonical143.log','selector-and-relocation-controls.log','selector-and-relocation-controls.json','combined-proposal.patch','combined-inverse.patch','combined-manifest.json','combined-inverse-review.json','physical-runtime-source-closure.json','native-owner-preservation.json','final-source-review.json','final-relocation-function-review.json','qualification.json']]
inventory=[]
for path in sorted(files):
 assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
 inventory.append({'path':str(path.relative_to(P)),'bytes':path.stat().st_size,'sha256':digest(path.read_bytes())})
archive=P/'qualified143-proposal.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for item in inventory:tf.add(P/item['path'],arcname=item['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert len(tf.getmembers())==len(inventory)
 for member,item in zip(tf.getmembers(),inventory):
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  assert member.name==item['path'] and digest(tf.extractfile(member).read())==item['sha256']
(P/'qualified143-capsule.json').write_text(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes()),'safe_regular_members':len(inventory),'members':inventory},indent=2,sort_keys=True)+'\n')
print(json.dumps({'archive':str(archive),'sha256':digest(archive.read_bytes()),'bytes':archive.stat().st_size,'safe_regular_members':len(inventory),'manifest_sha256':digest((P/'combined-manifest.json').read_bytes())},indent=2))
