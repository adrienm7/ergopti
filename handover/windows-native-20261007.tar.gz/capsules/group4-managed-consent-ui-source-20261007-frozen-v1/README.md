# Managed runtime consent handlers

This source-only slice provides real localized installation and separate selected-model consent callbacks for the existing coordinator. It uses existing keys in all21 locales and starts no browser, installer, network request or model command. Archive fields must match the canonical asset before a modal can open. The shared modal owner excludes nested managed and ordinary local-model offers; exact ownership is restored even on exceptions. Source/selection/pause is checked after the real modal returns. A Yes is intent, never a native readiness receipt or AI preference write.

Six recording controls and three selected causal profiles are unexecuted proposals. Actual GUI remains Root-owned. Canonical initializer/caller wiring, owned models directory, listener authentication and all native receiving remain unfinished. No Group4 readiness is claimed.
