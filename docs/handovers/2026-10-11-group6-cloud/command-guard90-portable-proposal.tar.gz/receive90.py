"""Owning full-suite composition; original72 identities and helpers remain exact."""
from pathlib import Path
import importlib.util
import json
import sys
import unittest

P = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')
source_role = sys.argv[1] if len(sys.argv) > 1 else 'candidate'
REL = 'tools/test/macos_native_http_receiving_facts_test.py'
namespace = {'__name__': 'isolated_guard_enrolled90', '__file__': str(ROOT / REL)}
exec(compile((P / 'candidate' / REL).read_bytes(), str(ROOT / REL), 'exec'), namespace)
source = P / source_role / 'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
spec = importlib.util.spec_from_file_location('isolated_guard90_wire', source)
wire = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wire)
namespace['WIRE'] = wire
if source_role == 'preimage':
    names = [
        'test_unsettled_actual_child_retains_root_and_refuses_new_capture',
        'test_postinstall_query_retains_actual_child_root_and_original_primary',
        'test_real_sigint_at_success_publication_propagates_before_query',
        'test_real_sigterm_at_success_publication_propagates_before_query',
    ]
    suite = unittest.TestSuite(namespace['NativeCommandGuardTests'](name) for name in names)
else:
    suite = unittest.TestSuite()
    for value in namespace.values():
        if isinstance(value, type) and issubclass(value, unittest.TestCase):
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(value))
result = unittest.TextTestRunner(verbosity=2).run(suite)
facts = {'qualification': 'REAL_POSIX_SOFTWARE_CONTROLS_NATIVE_SECURITY_MODELED_NO_DARWIN_CREDIT',
         'source_role': source_role, 'tests': result.testsRun, 'failures': len(result.failures),
         'errors': len(result.errors), 'skips': len(result.skipped), 'cleanup': namespace['NATIVE_GUARD_CLEANUP']}
print(json.dumps(facts, sort_keys=True))
assert result.testsRun == (4 if source_role == 'preimage' else 90)
assert len(facts['cleanup']) == (4 if source_role == 'preimage' else 18)
assert all(fact['all_exact_outer_children_reaped'] for fact in facts['cleanup'])
sys.exit(0 if result.wasSuccessful() else 1)
