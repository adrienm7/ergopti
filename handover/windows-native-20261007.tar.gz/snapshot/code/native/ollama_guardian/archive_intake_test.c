#include "archive_intake.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Recording-only Win32/guardian ports. No child, job, file, event, module or
   process is created by this executable; actual receiving is a separate gate. */
static uint32_t channel_records,channel_paths;
static unsigned created_channels;
static unsigned remote_duplicates,remote_wrong_target,remote_inherited;
static int remote_fail_at;
static int command_closed,command_written,command_flushed,command_close_fail;
static unsigned early_publications;
static DWORD test_error;
static int source_terminal,download_terminal,source_exit,download_exit;
static int fail_query,fail_close,fail_job,guardian_ready,guardian_retired;
static uint32_t model_download_members,composite_members;
static unsigned source_release,termination,close_attempts,attach_attempts;
static GB_Phase guardian_phase;
static HANDLE h(unsigned value) { return (HANDLE)(uintptr_t)value; }
static DWORD WINAPI TGetError(void) { return test_error; }
static void WINAPI TSetError(DWORD value) { test_error=value; }
static HANDLE WINAPI TCurrent(void) { return h(1u); }
static BOOL WINAPI TDuplicate(HANDLE source_process,HANDLE value,HANDLE target_process,
    LPHANDLE output,DWORD access,BOOL inherit,DWORD options) {
    (void)source_process;(void)access;(void)options;
    if(target_process!=h(1u)){
        ++remote_duplicates;if(target_process!=h(2u))++remote_wrong_target;
        if(inherit)++remote_inherited;
        if(remote_fail_at>0 && remote_duplicates==(unsigned)remote_fail_at){test_error=ERROR_ACCESS_DENIED;return FALSE;}
    }
    if(value==NULL){test_error=ERROR_INVALID_HANDLE;return FALSE;}*output=value;return TRUE;
}
static DWORD WINAPI TPid(HANDLE process) { return (DWORD)(uintptr_t)process+100u; }
static BOOL WINAPI TTimes(HANDLE process,LPFILETIME creation,LPFILETIME exit,LPFILETIME kernel,LPFILETIME user) {
    memset(creation,0,sizeof(*creation));creation->dwLowDateTime=TPid(process)*10u;
    memset(exit,0,sizeof(*exit));memset(kernel,0,sizeof(*kernel));memset(user,0,sizeof(*user));return TRUE;
}
static DWORD WINAPI TWait(HANDLE process,DWORD delay) {
    (void)delay;return (process==h(2u)?source_terminal:download_terminal)?WAIT_OBJECT_0:WAIT_TIMEOUT;
}
static BOOL WINAPI TExit(HANDLE process,LPDWORD code) {
    *code=(DWORD)(process==h(2u)?source_exit:download_exit);return TRUE;
}
static BOOL WINAPI TAssign(HANDLE job,HANDLE process) {
    (void)process;if(job!=h(500u)){test_error=ERROR_INVALID_HANDLE;return FALSE;}
    ++attach_attempts;return TRUE;
}
static BOOL WINAPI TMember(HANDLE process,HANDLE job,PBOOL member) {
    (void)process;*member=(job==h(500u) || job==h(201u) || job==h(202u));return TRUE;
}
static BOOL WINAPI TClose(HANDLE value) {
    ++close_attempts;
    if(value==h(700u)){if(command_close_fail){test_error=ERROR_ACCESS_DENIED;return FALSE;}command_closed=1;}
    if(fail_close && value==h(3u)){test_error=ERROR_ACCESS_DENIED;return FALSE;}return TRUE;
}
static HANDLE WINAPI TJob(LPSECURITY_ATTRIBUTES attributes,LPCWSTR name) {
    (void)attributes;(void)name;if(fail_job){test_error=ERROR_NOT_ENOUGH_MEMORY;return NULL;}return h(500u);
}
static BOOL WINAPI TSetJob(HANDLE job,JOBOBJECTINFOCLASS kind,LPVOID input,DWORD bytes) {
    const JOBOBJECT_EXTENDED_LIMIT_INFORMATION *limits=input;
    (void)job;(void)kind;(void)bytes;
    return limits->BasicLimitInformation.LimitFlags==JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
}
static BOOL WINAPI TQuery(HANDLE job,JOBOBJECTINFOCLASS kind,LPVOID output,DWORD bytes,LPDWORD returned) {
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION *info=output;
    (void)kind;(void)bytes;(void)returned;
    if(fail_query && job==h(500u)){test_error=ERROR_ACCESS_DENIED;return FALSE;}
    memset(info,0,sizeof(*info));info->ActiveProcesses=job==h(500u)?composite_members:model_download_members;return TRUE;
}
static BOOL WINAPI TTerminate(HANDLE job,UINT code) { (void)job;(void)code;++termination;return TRUE; }
static int TCreateIntake(uint32_t records,uint32_t paths,const uint8_t manifest[32],const uint8_t guardian[32],uint64_t *id) {
    channel_records=records;channel_paths=paths;++created_channels;(void)manifest;(void)guardian;*id=99u;guardian_phase=GB_SOURCE;return 1;
}
static int TInherited(uint64_t id,HANDLE *map,HANDLE *ready,HANDLE *release,HANDLE *parent) {
    (void)id;*map=h(10u);*ready=h(11u);*release=h(12u);*parent=h(13u);return 1;
}
static int TAcquire(uint64_t id,uint64_t *token) { (void)id;*token=7u;return 1; }
static int TRelease(uint64_t id,uint64_t token) { (void)id;return token==7u; }
static int TBind(uint64_t id,HANDLE process) { (void)id;(void)process;guardian_phase=GB_OFFERED;return 1; }
static int TBegin(uint64_t id,HANDLE job,HANDLE daemon,HANDLE source) {
    (void)id;(void)daemon;(void)source;if(job!=h(500u))return 0;guardian_phase=GB_HOST;return 1;
}
static int TPoll(uint64_t id,GB_Status *status) {
    memset(status,0,sizeof(*status));status->id=id;
    status->phase=(uint32_t)(guardian_retired?GB_RETIRED:guardian_ready?GB_READY:guardian_phase);return 1;
}
static int TClaim(uint64_t id) { (void)id;return guardian_ready; }
static int TSeal(uint64_t id) { (void)id;++source_release;return 1; }
static int TStop(uint64_t id) { (void)id;guardian_phase=GB_STOPPING;return 1; }
static int TContainment(uint64_t id) { (void)id;return guardian_phase==GB_HOST || guardian_ready; }

#define GetLastError TGetError
#define SetLastError TSetError
#define GetCurrentProcess TCurrent
#define DuplicateHandle TDuplicate
#define GetProcessId TPid
#define GetProcessTimes TTimes
#define WaitForSingleObject TWait
#define GetExitCodeProcess TExit
#define AssignProcessToJobObject TAssign
#define IsProcessInJob TMember
#define CloseHandle TClose
#define CreateJobObjectW TJob
#define SetInformationJobObject TSetJob
#define QueryInformationJobObject TQuery
#define TerminateJobObject TTerminate
#define GB_CreateIntake TCreateIntake
#define GB_Inherited TInherited
#define GB_AcquireInheritance TAcquire
#define GB_ReleaseInheritance TRelease
#define GB_Bind TBind
#define GB_IntakeBindTransferredSource TBind
#define GB_BeginGuardian TBegin
#define GB_Poll TPoll
#define GB_ClaimActivation TClaim
#define GB_IntakeReleaseSource TSeal
#define GB_Stop TStop
#define GB_IntakeHasContainment TContainment

static int validation_fail,header_mismatch,publication_fail;
static unsigned native_validations,published_commands;
static char command_bytes[512];

static int TMatch(uint64_t id,const GI_Expected *items,size_t count) {(void)id;(void)items;(void)count;return !header_mismatch;}
static int TConfirm(uint64_t id,const GI_Expected *items,size_t count,size_t root,size_t intake) {
    (void)id;(void)items;(void)count;(void)root;(void)intake;return guardian_ready && !validation_fail;
}
static int TContext(GI_Win32Context *c,HANDLE process,const FILETIME *time,const GI_Expected *items,size_t count) {
    memset(c,0,sizeof(*c));c->source=process;c->source_creation=*time;c->held_candidates=items;c->held_count=count;return 1;
}
static void *TAllocate(void *context,size_t size) {(void)context;return calloc(1u,size);}
static void TFree(void *context,void *value) {(void)context;free(value);}
static int TCopySource(void *context,uintptr_t value,uintptr_t *copy) {(void)context;(void)value;*copy=900u;return 1;}
static int TCopyContent(void *context,uintptr_t from,const GI_Expected *item,uintptr_t *copy) {
    GI_Win32Context *c=context;size_t i;int exact=0;(void)from;
    for(i=0u;i<c->held_count;++i)if(item==&c->held_candidates[i])exact=1;
    if(!exact)return 0;*copy=1000u+item->index;return 1;
}
static int TValidate(void *context,uintptr_t handle,const GI_Expected *item) {
    (void)context;++native_validations;return !validation_fail && handle==1000u+item->index && item->volume==1u;
}
static int TCopyClose(void *context,uintptr_t handle) {(void)context;return TClose((HANDLE)handle);}
static GI_Port TImport(GI_Win32Context *c) {GI_Port p={c,TAllocate,TFree,TCopySource,TCopyContent,TValidate,TCopyClose};return p;}
static HANDLE WINAPI TFile(LPCWSTR file,DWORD access,DWORD share,LPSECURITY_ATTRIBUTES security,DWORD create,DWORD flags,HANDLE template_file) {
    (void)file;(void)access;(void)share;(void)security;(void)create;(void)flags;(void)template_file;command_closed=0;command_written=0;command_flushed=0;return h(700u);
}
static BOOL WINAPI TWrite(HANDLE file,LPCVOID data,DWORD bytes,LPDWORD written,LPOVERLAPPED overlap) {
    (void)file;(void)overlap;if(bytes>=sizeof(command_bytes))return FALSE;memcpy(command_bytes,data,bytes);command_bytes[bytes]=0;command_written=1;*written=bytes;return TRUE;
}
static BOOL WINAPI TFlush(HANDLE file) {(void)file;command_flushed=1;return TRUE;}
static BOOL WINAPI TMove(LPCWSTR before,LPCWSTR after) {(void)before;(void)after;if(!command_closed || !command_written || !command_flushed)++early_publications;if(publication_fail){test_error=ERROR_ACCESS_DENIED;return FALSE;}++published_commands;return TRUE;}
#define GB_IntakeMatchInventory TMatch
#define GB_IntakeConfirmInventory TConfirm
#define GI_Win32ContextInitIntake TContext
#define GI_Win32ImportPort TImport
#define CreateFileW TFile
#define WriteFile TWrite
#define FlushFileBuffers TFlush
#define MoveFileW TMove

#include "guardian_import.c"
#include "archive_intake.c"

#define CHECK(expression) do { if(!(expression)){fprintf(stderr,"FAIL %s:%d\n",#expression,__LINE__);return 0;} } while(0)
static void reset(void) {
    test_error=0u;source_terminal=0;download_terminal=0;source_exit=0;download_exit=0;
    fail_query=0;fail_close=0;fail_job=0;guardian_ready=0;guardian_retired=0;
    model_download_members=1u;composite_members=2u;source_release=0u;termination=0u;close_attempts=0u;attach_attempts=0u;
}
static uint64_t create(void) { uint8_t digest[32]={1u};uint64_t id=0u;return GAI_Create(8u,2048u,digest,digest,&id)?id:0u; }
static int source(uint64_t id) {
    GAI_Status status;
    return GAI_AttachSource(id,h(2u)) && GAI_BindSource(id,h(2u),h(201u)) &&
        GAI_Poll(id,&status) && status.phase==GAI_NAMESPACE_READY;
}
static int download(uint64_t id) {
    return source(id) && GAI_AttachDownload(id,h(3u)) && GAI_BindDownload(id,h(3u),h(202u)) && GAI_BeginGuardian(id);
}
static int reserved_before_failure(void) {
    GAI_Status status;uint64_t id;reset();fail_job=1;id=create();
    CHECK(id!=0u && GAI_Poll(id,&status));CHECK(status.phase==GAI_DEBT && status.first_error==ERROR_NOT_ENOUGH_MEMORY);return 1;
}
static int source_exact_once(void) {
    uint64_t id;reset();id=create();CHECK(id!=0u && source(id));CHECK(attach_attempts==1u);
    CHECK(!GAI_AttachSource(id,h(2u)));CHECK(attach_attempts==1u);return 1;
}
static int foreign_process_refused(void) {
    GAI_Status status;uint64_t id;reset();id=create();CHECK(GAI_AttachSource(id,h(2u)));
    CHECK(!GAI_BindSource(id,h(4u),h(201u)));CHECK(GAI_Poll(id,&status));CHECK(status.first_error==ERROR_INVALID_DATA);
    CHECK(GAI_Find(id)->source.process==h(2u));return 1;
}
static int no_download_before_namespace(void) {
    uint64_t id;reset();id=create();CHECK(!GAI_AttachDownload(id,h(3u)));CHECK(attach_attempts==0u);return 1;
}
static int native_ready_claim_once(void) {
    uint64_t id;reset();id=create();CHECK(download(id));CHECK(!GAI_ClaimDownload(id));
    guardian_ready=1;CHECK(GAI_ClaimDownload(id));CHECK(!GAI_ClaimDownload(id));CHECK(source_release==0u);return 1;
}
static int seal_private_job_zero_composite_live(void) {
    GAI_Status status;uint64_t id;reset();id=create();CHECK(download(id));guardian_ready=1;CHECK(GAI_ClaimDownload(id));
    download_terminal=1;CHECK(!GAI_RequestSeal(id));CHECK(source_release==0u);
    model_download_members=0u;CHECK(GAI_RequestSeal(id));CHECK(GAI_Poll(id,&status));
    CHECK(status.phase==GAI_SEAL_GRANTED && status.composite_members==2u && !status.source_terminal && source_release==1u);
    CHECK(!GAI_RequestSeal(id) && source_release==1u);return 1;
}
static int unsuccessful_download_never_seals(void) {
    GAI_Status status;uint64_t id;reset();id=create();CHECK(download(id));guardian_ready=1;CHECK(GAI_ClaimDownload(id));
    download_terminal=1;download_exit=23;model_download_members=0u;CHECK(!GAI_RequestSeal(id));CHECK(source_release==0u);
    CHECK(GAI_Poll(id,&status) && status.first_error==ERROR_PROCESS_ABORTED);return 1;
}
static int unknown_process_close_retained(void) {
    GAI_Status status;uint64_t id;unsigned attempts;reset();id=create();CHECK(download(id));guardian_ready=1;CHECK(GAI_ClaimDownload(id));
    download_terminal=1;fail_close=1;model_download_members=0u;CHECK(!GAI_RequestSeal(id));
    CHECK(GAI_Stop(id));source_terminal=1;guardian_retired=1;composite_members=0u;CHECK(GAI_Poll(id,&status));
    CHECK(status.phase!=GAI_RETIRED && GAI_Find(id)->download.process==h(3u));attempts=close_attempts;
    CHECK(GAI_Poll(id,&status));CHECK(close_attempts==attempts && source_release==0u);return 1;
}
static int failed_job_query_not_zero(void) {
    GAI_Status status;uint64_t id;reset();id=create();CHECK(download(id));CHECK(GAI_Stop(id));
    source_terminal=1;download_terminal=1;guardian_retired=1;composite_members=0u;fail_query=1;
    CHECK(GAI_Poll(id,&status));CHECK(status.phase!=GAI_RETIRED && status.composite_members==UINT32_MAX);return 1;
}
static int stop_before_factory_once(void) {
    GAI_Status status;uint64_t id;reset();id=create();CHECK(source(id));CHECK(GAI_Stop(id));CHECK(termination==1u);
    CHECK(!GAI_Stop(id) && termination==1u);source_terminal=1;guardian_retired=1;composite_members=0u;
    CHECK(GAI_Poll(id,&status) && status.phase==GAI_RETIRED);return 1;
}

static uint64_t reserve(void) {
    uint8_t digest[32]={1u};uint64_t id=0u;
    reset();remote_duplicates=0u;remote_wrong_target=0u;remote_inherited=0u;remote_fail_at=0;
    command_close_fail=0;command_closed=0;command_written=0;command_flushed=0;early_publications=0u;
    validation_fail=0;header_mismatch=0;publication_fail=0;native_validations=0u;created_channels=0u;published_commands=0u;
    return GAI_Reserve(L"0123456789abcdef0123456789abcdef",digest,digest,&id)?id:0u;
}
static GI_Expected inventory[3];
static void candidates(void) {
    static const wchar_t *names[]={L"C:\\Users\\synthetic\\Local\\ergopti_plus_ollama",
        L"C:\\Users\\synthetic\\Local\\ergopti_plus_ollama\\.intake-0123456789abcdef0123456789abcdef",L"C:\\code\\guardian.exe"};
    size_t i;memset(inventory,0,sizeof(inventory));
    for(i=0u;i<3u;++i){inventory[i].source_handle=100u+i;inventory[i].kind=i==2u?0u:1u;
        inventory[i].volume=1u;inventory[i].index=100u+i;inventory[i].native_path=(const uint16_t *)names[i];
        inventory[i].path_units=wcslen(names[i]);inventory[i].sha256[0]=1u;}
}
static int late_source(uint64_t id) {return GAI_AttachSource(id,h(2u)) && GAI_BindSource(id,h(2u),h(201u)) && GAI_ClaimSource(id);}
static int inventory_validation_precedes_capacity(void) {
    uint64_t id=reserve();candidates();CHECK(late_source(id));CHECK(created_channels==0u);
    validation_fail=1;CHECK(!GAI_BindInventory(id,inventory,3u,1u,100u));
    CHECK(native_validations>0u && created_channels==0u && GAI_Find(id)->shadow.acquired>0u);return 1;
}
static int held_projection_exact_capacity(void) {
    uint64_t id=reserve();size_t units;candidates();CHECK(late_source(id));
    units=inventory[0].path_units+inventory[1].path_units+inventory[2].path_units+3u;
    CHECK(GAI_BindInventory(id,inventory,3u,1u,100u));CHECK(native_validations>=5u);
    CHECK(channel_records==3u && channel_paths==(uint32_t)units && created_channels==1u);return 1;
}
static int multiple_intake_candidates_refused(void) {
    uint64_t id=reserve();candidates();CHECK(late_source(id));
    inventory[2].kind=1u;inventory[2].native_path=inventory[1].native_path;inventory[2].path_units=inventory[1].path_units;
    CHECK(!GAI_BindInventory(id,inventory,3u,1u,100u));CHECK(created_channels==0u);return 1;
}
static int stale_ticket_refused(void) {
    uint64_t id=reserve();candidates();CHECK(late_source(id));
    inventory[1].native_path=(const uint16_t *)L"C:\\Users\\synthetic\\Local\\ergopti_plus_ollama\\.intake-ffffffffffffffffffffffffffffffff";
    inventory[1].path_units=wcslen((const wchar_t *)inventory[1].native_path);
    CHECK(!GAI_BindInventory(id,inventory,3u,1u,100u));CHECK(created_channels==0u);return 1;
}
static int original_source_transfer_once(void) {
    uint64_t id=reserve(),handles[5];candidates();CHECK(late_source(id));CHECK(GAI_BindInventory(id,inventory,3u,1u,100u));
    CHECK(GAI_TransferChannel(id,handles));CHECK(handles[0]==99u && GAI_Find(id)->remote_count==4u);
    CHECK(remote_duplicates==4u && remote_wrong_target==0u && remote_inherited==0u);
    CHECK(!GAI_TransferChannel(id,handles));return 1;
}
static int publication_is_closed_once(void) {
    uint64_t id=reserve(),handles[5];candidates();CHECK(late_source(id));CHECK(GAI_BindInventory(id,inventory,3u,1u,100u));
    CHECK(GAI_TransferChannel(id,handles));CHECK(GAI_WriteChannelCommand(id));
    CHECK(GAI_Find(id)->command_stage==NULL && published_commands==1u && strstr(command_bytes,"source_creation")!=NULL);
    CHECK(!GAI_WriteChannelCommand(id) && published_commands==1u && early_publications==0u);return 1;
}
static int changed_second_offer_refused(void) {
    uint64_t id=reserve(),handles[5];GAI_Status status;candidates();CHECK(late_source(id));CHECK(GAI_BindInventory(id,inventory,3u,1u,100u));
    CHECK(GAI_TransferChannel(id,handles));
    CHECK(GAI_Poll(id,&status) && status.phase==GAI_NAMESPACE_READY);
    CHECK(GAI_AttachDownload(id,h(3u)) && GAI_BindDownload(id,h(3u),h(202u)));
    header_mismatch=1;CHECK(!GAI_BeginGuardian(id));return 1;
}
static int ready_directory_revalidation_before_activation(void) {
    uint64_t id=reserve(),handles[5];GAI_Status status;wchar_t output[256];candidates();CHECK(late_source(id));CHECK(GAI_BindInventory(id,inventory,3u,1u,100u));
    CHECK(GAI_TransferChannel(id,handles));
    CHECK(GAI_Poll(id,&status) && GAI_AttachDownload(id,h(3u)) && GAI_BindDownload(id,h(3u),h(202u)) && GAI_BeginGuardian(id));
    guardian_ready=1;CHECK(GAI_OutputIntent(id,output,256u));CHECK(!GAI_ClaimDownload(id));
    validation_fail=1;CHECK(!GAI_ConfirmOutput(id,output));CHECK(!GAI_ClaimDownload(id));return 1;
}
static int no_inventory_before_source_claim(void) {
    uint64_t id=reserve();candidates();
    CHECK(GAI_AttachSource(id,h(2u)) && GAI_BindSource(id,h(2u),h(201u)));
    CHECK(!GAI_BindInventory(id,inventory,3u,1u,100u));
    CHECK(GAI_Find(id)->inventory_attempted==0u && native_validations==0u && created_channels==0u);return 1;
}
static int partial_remote_transfer_retains_exact_prefix(void) {
    uint64_t id=reserve(),handles[5];unsigned attempts;candidates();CHECK(late_source(id));
    CHECK(GAI_BindInventory(id,inventory,3u,1u,100u));remote_fail_at=3;
    CHECK(!GAI_TransferChannel(id,handles));
    CHECK(GAI_Find(id)->remote_count==2u && GAI_Find(id)->remote[0]==h(10u) && GAI_Find(id)->remote[1]==h(11u));
    CHECK(GAI_Find(id)->first_error==ERROR_ACCESS_DENIED && remote_inherited==0u && remote_wrong_target==0u);
    attempts=remote_duplicates;CHECK(!GAI_TransferChannel(id,handles) && remote_duplicates==attempts);
    CHECK(!GAI_WriteChannelCommand(id) && published_commands==0u);return 1;
}
static int command_unknown_close_never_publishes(void) {
    uint64_t id=reserve(),handles[5];unsigned attempts;candidates();CHECK(late_source(id));
    CHECK(GAI_BindInventory(id,inventory,3u,1u,100u) && GAI_TransferChannel(id,handles));
    command_close_fail=1;CHECK(!GAI_WriteChannelCommand(id));
    CHECK(GAI_Find(id)->command_stage==h(700u) && GAI_Find(id)->command_close_attempted==1u);
    CHECK(GAI_Find(id)->first_error==ERROR_ACCESS_DENIED && published_commands==0u);
    attempts=close_attempts;CHECK(!GAI_WriteChannelCommand(id) && close_attempts==attempts);return 1;
}
int main(void) {
    int (*cases[])(void)={reserved_before_failure,source_exact_once,foreign_process_refused,no_download_before_namespace,
        native_ready_claim_once,seal_private_job_zero_composite_live,unsuccessful_download_never_seals,
        unknown_process_close_retained,failed_job_query_not_zero,stop_before_factory_once,inventory_validation_precedes_capacity,held_projection_exact_capacity,
        multiple_intake_candidates_refused,stale_ticket_refused,original_source_transfer_once,publication_is_closed_once,changed_second_offer_refused,ready_directory_revalidation_before_activation,no_inventory_before_source_claim,partial_remote_transfer_retains_exact_prefix,command_unknown_close_never_publishes};
    const char *names[]={"reserved-before-acquisition","exact-source-once","foreign-process","namespace-before-download",
        "kernel-ready-once","seal-private-zero-composite-live","download-failure","uncertain-close","query-not-zero","stop-before-factory","validation-before-capacity","exact-capacity","ambiguous-directory","stale-ticket","transfer-once","closed-command","second-offer","ready-directory","source-claim-before-inventory","partial-transfer","command-close-debt"};
    size_t i;puts("1..21");
    for(i=0u;i<sizeof(cases)/sizeof(cases[0]);++i){if(!cases[i]()){printf("not ok %zu - %s\n",i+1u,names[i]);return 1;}printf("ok %zu - %s\n",i+1u,names[i]);}
    return 0;
}
