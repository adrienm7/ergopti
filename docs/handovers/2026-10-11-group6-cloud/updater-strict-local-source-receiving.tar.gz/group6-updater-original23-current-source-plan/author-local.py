from pathlib import Path
r=Path(__file__).resolve().parent
p=r/'proposal-candidate/tools/ci/windows-updater-original-source.cjs'
s=p.read_text();a="module.exports = { readSourceFile, candidateSourceReceipt };"
f='''function localInvocation(args) {
	demand(
		Array.isArray(args) && args.length === 4 && args[0] === '--local' &&
			args.slice(1).every((value) => typeof value === 'string' && value.trim() !== '' && !value.startsWith('--')),
		'Local invocation requires --local <ahk> <file-version> <absolute-evidence-root>.'
	);
	demand(!Object.keys(process.env).some((name) => name.startsWith('GITHUB_')), 'Local receiving refuses every GitHub context key.');
	demand(path.isAbsolute(args[1]) && path.isAbsolute(args[3]), 'Local executable and evidence root must be absolute.');
	demand(process.arch === 'x64', 'Original Windows SDK architecture refused.');
	const candidate = execFileSync('git', ['rev-parse', 'HEAD'], {
		cwd: root,
		env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' },
		encoding: 'utf8'
	}).trim();
	demand(/^[0-9a-f]{40}$/.test(candidate), 'Actual local Git HEAD unavailable.');
	return {
		local: true,
		arguments: args.slice(1, 3),
		evidence_root: args[3],
		context: { candidate, run_id: null, run_attempt: null, architecture: process.arch, role: 'local', context_bound: false }
	};
}

module.exports = { readSourceFile, candidateSourceReceipt, localInvocation };'''
assert s.count(a)==1;p.write_text(s.replace(a,f))
p=r/'proposal-candidate/tools/ci/run-windows-updater-original-diagnostic-cohort.cjs';s=p.read_text();s=s.replace("const { readSourceFile, candidateSourceReceipt } = require('./windows-updater-original-source.cjs');","const { readSourceFile, candidateSourceReceipt, localInvocation } = require('./windows-updater-original-source.cjs');",1)
marker='\nconst budgetMs ='
f='''
function invocation() {
	const args = process.argv.slice(2);
	if (args[0] === '--local') return localInvocation(args);
	demand(args.length === 2 && args.every((value) => typeof value === 'string' && !value.startsWith('--')), 'Unknown or mixed original updater invocation mode.');
	return { local: false, arguments: args, context: admittedContext() };
}
'''
assert s.count(marker)==1;s=s.replace(marker,'\n'+f+marker,1)
old='''		receipt.context = admittedContext();
		demand(path.isAbsolute(process.env.RUNNER_TEMP || ''), 'RUNNER_TEMP must be absolute.');
		const suffix = `${receipt.context.candidate}-${receipt.context.run_id}-${receipt.context.run_attempt}`;
		const destination = path.join(
			process.env.RUNNER_TEMP,
			`windows-updater-original-diagnostic-candidate-${suffix}`
		);
		demand(!fs.existsSync(destination), 'Refusing to reuse prior cohort evidence.');
		fs.mkdirSync(destination);
		directory = destination;'''
new='''		const selected = invocation();
		receipt.context = selected.context;
		let destination;
		if (selected.local) {
			receipt.role = 'local';
			receipt.context_bound = false;
			receipt.official_qualified = false;
			receipt.file_version_source = 'caller_provided_local_argument';
			const owner = fs.lstatSync(selected.evidence_root, { bigint: true });
			demand(owner.isDirectory() && !owner.isSymbolicLink(), 'Local evidence requires an existing unaliased directory.');
			destination = fs.mkdtempSync(path.join(selected.evidence_root, `windows-updater-original-diagnostic-local-${receipt.context.candidate}-`));
			receipt.evidence_root = { path: selected.evidence_root, device: String(owner.dev), inode: String(owner.ino) };
		} else {
			demand(path.isAbsolute(process.env.RUNNER_TEMP || ''), 'RUNNER_TEMP must be absolute.');
			const suffix = `${receipt.context.candidate}-${receipt.context.run_id}-${receipt.context.run_attempt}`;
			destination = path.join(
				process.env.RUNNER_TEMP,
				`windows-updater-original-diagnostic-candidate-${suffix}`
			);
			demand(!fs.existsSync(destination), 'Refusing to reuse prior cohort evidence.');
			fs.mkdirSync(destination);
		}
		directory = destination;'''
assert s.count(old)==1;s=s.replace(old,new,1)
s=s.replace("demand(process.argv.length === 4, 'SDK path and FileVersion are required.');","demand(selected.arguments.length === 2, 'SDK path and FileVersion are required.');",1)
s=s.replace("const ahk = path.resolve(process.argv[2]);","const ahk = path.resolve(selected.arguments[0]);",1)
s=s.replace("process.argv[3].trim()", "selected.arguments[1].trim()",1).replace("file_version: process.argv[3],","file_version: selected.arguments[1],",1)
s=s.replace("receipt.source_commit === process.env.GITHUB_SHA,","receipt.source_commit === (selected.local ? receipt.context.candidate : process.env.GITHUB_SHA),",1)
s=s.replace("if (require.main === module) {", "module.exports = { admittedContext, invocation };\n\nif (require.main === module) {",1)
p.write_text(s)
