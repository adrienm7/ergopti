# native/ollama_guardian/tests/test_existing_runtime_native.ps1
# A fresh native process/Root per mode preserves every failed acquisition owner.
[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$FilesHelper,
	[Parameter(Mandatory = $true)][string]$PublicationHelper,
	[Parameter(Mandatory = $true)][string]$FixtureRoot,
	[Parameter(Mandatory = $true)][string]$OwnedRoot,
	[Parameter(Mandatory = $true)][string]$SourceRoot,
	[Parameter(Mandatory = $true)][string]$Guardian,
	[Parameter(Mandatory = $true)][string]$Launcher,
	[ValidateSet('missing', 'published', 'catalogue', 'descriptor', 'oversize', 'collection', 'manifest')][string]$Mode)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Assert-ExistingNative([bool]$Condition, [string]$Reason) {
	if (-not $Condition) { throw $Reason }
}
try {
	if ($PSVersionTable.PSVersion.Major -ne 5 -or [IntPtr]::Size -ne 8) { throw 'Native receiving requires Windows PowerShell 5.1 x64.' }
	$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
	. $FilesHelper
	. $PublicationHelper
	Initialize-OllamaManagedNative
	Initialize-OllamaPublicationOwner
	Assert-ExistingNative ([Ergopti.Ollama.ManagedNative]::PathIsAbsent($OwnedRoot)) 'Receiving requires an exclusive absent direct LocalAppData child.'
	Assert-ExistingNative ([Ergopti.Ollama.ManagedNative]::PathIsAbsent($SourceRoot)) 'Receiving source namespace must be exclusive.'
	[void][IO.Directory]::CreateDirectory($SourceRoot)
	$root = Open-OllamaManagedRoot $OwnedRoot $true
	$fixtures = [IO.File]::ReadAllText([IO.Path]::Combine($FixtureRoot, 'receipts.json')) | ConvertFrom-Json
	$pin = $fixtures.portable
	$cataloguePath = [IO.Path]::Combine($SourceRoot, 'catalogue.json')
	$catalogue = [ordered]@{ schema_version = 1; version = '0.24.0'; assets = [ordered]@{
		'windows-amd64' = [ordered]@{ filename = 'ollama-windows-amd64.zip'; bytes = $pin.bytes; sha256 = $pin.sha256 } } }
	Write-OllamaOwnedJson $cataloguePath $catalogue
	$stream = Open-OllamaReadFile $cataloguePath
	try { $hash = Get-OllamaStreamHash $stream } finally { $stream.Dispose() }
	$descriptorPath = ''
	if ($Mode -ne 'missing') {
		$archive = Read-OllamaPinnedArchive $cataloguePath $hash 'windows-amd64' ([IO.Path]::Combine($FixtureRoot, 'portable.zip'))
		try { $prepared = Prepare-OllamaManagedStage $root $archive ([Guid]::NewGuid().ToString('N')) }
		finally { Close-OllamaPinnedArchive $archive }
		$id = New-OllamaPublicationOwner $root $prepared.ticket $prepared.stage_identity $prepared.manifest_sha256
		$view = Publish-OllamaVersionDescriptor $id
		$descriptorPath = $view.descriptor_path
		Assert-ExistingNative (Close-OllamaPublicationOwner $id) 'Setup publication did not release its exact file-only leases.'
		if ($Mode -eq 'descriptor' -or $Mode -eq 'collection') {
			$image = [IO.File]::ReadAllText($descriptorPath) | ConvertFrom-Json
			if ($Mode -eq 'descriptor') { $image.asset = 'windows-arm64' }
			else { $image.ticket = ,([object[]]@()) }
			[IO.File]::WriteAllBytes($descriptorPath, [Text.UTF8Encoding]::new($false, $true).GetBytes(($image | ConvertTo-Json -Depth 8 -Compress) + "`n"))
		} elseif ($Mode -eq 'manifest') {
			$manifest = [IO.Path]::Combine($view.container_path, 'prepared.json')
			[IO.File]::WriteAllBytes($manifest, [Text.Encoding]::ASCII.GetBytes('{}'))
		}
	}
	Close-OllamaManagedRoot $root
	# Reuse must acquire a fresh real Root owner; no previous scalar owner is adopted.
	$root = Open-OllamaManagedRoot $OwnedRoot $false
	$beforeCatalogue = [IO.File]::ReadAllBytes($cataloguePath)
	$beforeDescriptor = if ($descriptorPath -ne '') { [IO.File]::ReadAllBytes($descriptorPath) } else { $null }
	$capturedHash = if ($Mode -eq 'catalogue') { '0' * 64 } else { $hash }
	$bound = if ($Mode -eq 'oversize') { 1 } else { 8388608 }
	$acquisition = [ordered]@{ root_handles = $null; stage_handle = [IntPtr]::Zero;
		streams = $null; directory_handles = $null; phase = 'acquiring'; first_error = '' }
	$refused = $false
	try {
		$result = Get-OllamaExistingRuntimeExpectation $root $cataloguePath $capturedHash 'windows-amd64' $Guardian $Launcher $bound $acquisition
	} catch { $refused = $true }
	if ($Mode -eq 'missing') {
		Assert-ExistingNative (-not $refused -and $result.phase -ceq 'missing' -and $result.asset -ceq 'windows-amd64' -and
			$result.catalogue_sha256 -ceq $hash) 'Exact absence did not return its source-bound read-only result.'
	} elseif ($Mode -eq 'published') {
		Assert-ExistingNative (-not $refused -and $result.phase -ceq 'published' -and $result.Ticket -ceq $prepared.ticket -and
			$result.StageIdentity -ceq $prepared.stage_identity -and $result.ManifestHash -ceq $prepared.manifest_sha256 -and
			$result.CatalogueHash -ceq $hash -and $result.ArchiveHash -ceq $pin.sha256) 'Existing installation was not revalidated against the original real preparation.'
	} else {
		Assert-ExistingNative $refused 'A mutated or unbounded inspection source was admitted.'
		Assert-ExistingNative ($root.inspection.phase -ceq 'retained-inspection' -and
			$root.inspection.first_error -ne '') 'Refusal lost its exact acquisition owner or first diagnostic.'
	}
	Assert-ExistingNative ([Convert]::ToBase64String([IO.File]::ReadAllBytes($cataloguePath)) -ceq
		[Convert]::ToBase64String($beforeCatalogue)) 'Inspection changed the original canonical catalogue bytes.'
	if ($null -ne $beforeDescriptor) {
		Assert-ExistingNative ([Convert]::ToBase64String([IO.File]::ReadAllBytes($descriptorPath)) -ceq
			[Convert]::ToBase64String($beforeDescriptor)) 'Inspection changed an existing descriptor, including a refused foreign one.'
	}
	if (-not $refused) {
		Assert-ExistingNative ($null -eq $root.inspection.descriptor -and $null -eq $root.inspection.source_stream -and
			$root.inspection.publication -ceq '' -and $root.inspection.close_debt.Count -eq 0) 'Healthy inspection returned before actual reader/publication handback.'
		Close-OllamaManagedRoot $root
	}
	# Refused raw capabilities remain strongly recorded until this exact process's
	# natural exit. Parent cleanup requires actual process/job retirement first.
	[Console]::Out.WriteLine('PASS existing-runtime-native-' + $Mode)
	exit 0
} catch {
	[Console]::Error.WriteLine($_.Exception.Message)
	exit 1
}
