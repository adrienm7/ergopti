# Native publication ports for local-server orchestration

This is a scratch design, not an integrated implementation or passing validation receipt.
No transaction source paths have been changed. Group 1 must own or explicitly serialize the corresponding transaction change.

## `capture_source()` / `source_current(receipt)`

Mint an opaque privately owned receipt only after classified exact snapshots of both `config.toml` and `api_entries.json` succeed. Absence is distinct from unreadable; malformed or future unsupported API records refuse ownership. Existing supported DPAPI decoding must succeed, and the complete ordered six-field entries must match native RAM before granting authority. Capturing a fresh disk hash beside stale RAM is not sufficient.

Keep private exact old presence/hash of both files, detached six-field API entry values, native menu owner identity, active API ID and backend. Recheck these after any snapshot/hash/decryption call. Do not put plaintext tokens or source bytes in shared discovery/cache/menu row data, diagnostics, or receipts passed through external observers.

`source_current` must check the exact privately held receipt, both original file hashes, relevant native authority and complete ordered API values. A normal repeated `_LLM_Menu_LoadApiEntries()` which produces identical values must not invalidate a sweep merely because it allocates a new Array. A committed native configuration replacement should invalidate prior receipts through its owner identity/revision.

## `entry(id)`

Resolve the actual active matching local provider first if applicable, then an existing matching provider entry in native API ordering. Return an immutable detached native validated entry (`Id`, `Provider`, `BaseUrl`, `Token`, `Model`); ambiguity or unsupported authority must refuse. Return false only for honest absence. The owner must not treat read failure as absence.

## `apply(id, fields, source, admission, select_model)`

Use the existing `LLM_Menu_CommitApiEntriesMutation` and crash-recoverable joint writer. Do not add an independent API writer or mutate global RAM first.

The proposed extension must accept the opaque expected source receipt and admission callback, validate them before detached candidate construction and after every yielding build/serialization step, and carry original config/API presence/hash into both `ConfigTransitionPresentTarget` specs. Existing callers without retained-view sources retain their current behavior. Do not repurpose `PauseFn`, whose meaning is a WAL test/recovery boundary.

New or updated entry fields preserve provider/catalogue identity and exact configured key/address. Choosing a model sets API backend, selected entry ID and entry model in the same acknowledged transaction. Address/key changes without an existing entry remain session-private pending values, since the private source format requires a nonempty model.

After `committed_new`, use existing RAM publication and backend lifecycle. The port returns `{saved: true, ...}` only for acknowledged success. Preserve the writer's honest failure/retained recovery barrier when durable files exist but application or cleanup fails; do not turn persistence into a claim of server reachability.

## Validation once root source freeze ends

The shared rows need deterministic tests against the independent existing Lua menu contract: order, duplicate models, empty model hint, status/key rows, configured authority, selected API model, current backend, no discovered rows, searching status, rescan and other-address rows, and paused rows without enabled actions. No new translation or corpus generation is needed.

The native composition needs actual `LocalServerModelsOwner` with injected native CurlAsyncRequest factory, not a fake owner class. Cover old HTTP close/artifact debt delaying newest same-provider probe; creator callback reentrancy; a newest rescan arriving while `capture_source`/`entry` is interrupted; superseded `Settle`; paused waiting queue preserving cache; logical pause cancellation retaining refused exact debt; timer start/stop refusals and explicit retry; duplicate/native late responses; aggregate cache publication and ordered models.

Retained view tests must show source acquisition cannot stamp an old source/model cache with new generations; an old retained model action cannot select after source/config/model/view change; duplicates stay ordered; address/key edits only become pending without a model; no secret enters shared verdict; unsupported/malformed/unreadable sources remain byte-for-byte untouched; writer refusal never mutates RAM selection or reports saved; old receipt cannot write after supported external replacement; DPAPI native write/restart; actual loopback HTTP discovery and chat.

Packaging/installation and physical Windows validation remain required. Substitute child/HANDLE tests only prove lifetime ownership, not network E2E or native private publication.

## Corrected discovery ownership proposal

The native composition records the source and all private target snapshots for each originating sweep. A private exact-generation registry admits provenance before any provider mutation and covers shared automatic failure settlements as well as normal native responses; it accepts a native cache only after the originating source, all targets, generation and exact published result map survive independent rechecks. Menu results, detection and view model capture use that privately accepted provenance, never a fresh source grafted onto raw old shared cache. A retained address/key view may exist without an accepted models cache, but it cannot select a model.

Every active native logical job also retains its own observation timer. The frozen models owner can detach stale observers while preserving/retiring native debt; observing that lifecycle prevents the composition from leaving the shared sweep active forever. Source-stale searches invalidate their logical sweep and preserve the previous accepted cache instead of synthesizing a mixed or false-failure publication. Exact old native debt remains owned by the frozen HTTP owner until its own settlement acknowledgment.

The current-at-check source/target predicate does not claim an atomic external filesystem CAS. Shared settle owns its atomic logical generation claim; private publication must independently enforce both original expected file images through final transition preparation and commit. That transaction integration is still unresolved, tracked by the parent coordination issue.

`test_local_servers.ahk` currently prepares sixteen composed regression cases using the frozen actual controller/models/curl seams. They have not been executed. Their controlled private source and persistence ports do not establish disk, DPAPI, installation or network correctness.


Rescan creator admission is serialized in the native owner: a newer intent queues while any prior source capture/shared Sweep/native creator is still on the stack, and the latest intent is replayed after that setup unwinds. Stale producer callbacks independently validate their real shared ticket, native intent/configuration and unchanged shared generation before touching Job or Models state. Every native cancellation captures the actual Models record during its logical claim and calls the frozen owner's existing exact `_CancelRecord` capability outside Critical; provider IDs never stand in for old native resource ownership.


Every accepted native cache gets a new private cache identity, including an unchanged models refresh. Production `on_publish` must refresh/recapture local-server rows on every accepted publication, not only `Changed=true`, or retained model actions intentionally fail their provenance check. Deferred rebuild must keep action currentness honest while native UI is visible.

## Separate durable-candidate admission

The composition binds publication to an exact active `WriteClaim` with original retained view, source, target, ordered model snapshot/cache, native configuration/model/view generations, controller/rescan generation and session pending owner/values.

`admission()` performs ordinary full view/source/entry validation before durability. Ordinary source receipts remain strict old-image authority and return false after candidate images become durable.

`admission("committed", capability)` performs retained native provenance checks only: no ordinary source, entry or native admission ports. The distinct candidate token is a nominal type check, not source authority. The private writer must independently verify exact original Apply receipt, own bundle, candidate-new images and original native RAM/catalogue, bracketing this callback with `CandidateCurrent`. A successful retained check stores proof only for that exact candidate.

`admission("claim", capability)` requires the publisher's inherited active Critical region and the exact successful candidate proof. It performs only bounded native identity/scalar checks, does not scan models or pending data, invokes no ports and preserves Critical exactly. The private publisher must invoke it after all file I/O, full native data checks and auxiliary work, immediately before the RAM swap. Legitimate native cache/pending changes replace their owner snapshots or advance their generations.

`test_local_server_write_admission.ahk` prepares nineteen controls using the real discovery/models/curl fixture and actual private token classes. Its controlled persistence port always refuses save, and a nominal forged candidate is rejected by the actual private validator. These controls prove predicate separation and final generation refusal; they do not establish WAL durability, source ownership, DPAPI or installation. Load only after actual private source definitions and the existing composition fixture. No execution has occurred.


Native accepted results detach every verdict and ordered model Array from shared controller results. `Result()` and `on_publish` each return further detached verdict/model snapshots. An external observer cannot mutate a same-identity private cache through these data ports between full committed checks and the final bounded claim. Direct implementation-state property mutation is not a supported production port. Three additional prepared causal controls mutate returned verdicts, publication snapshots and shared controller results after committed proof; native accepted model data must survive.
