#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle');w=out.parent/'verification-worker'
r=json.loads((w/'receipts/455-lifecycle-state-enum-commit-exit.json').read_text());assert r['exit_code']==0,r
assert not subprocess.check_output(['git','status','--porcelain'])
p=root/'static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk';(out/'control-request-key-domain-pre-test.ahk').write_bytes(p.read_bytes());p.write_bytes(p.read_bytes()+(out/'control-request-key-domain-regression.ahk').read_bytes())
prod=root/'static/ergopti_plus/windows/infra/driver_control.ahk';(out/'control-request-key-domain-old-production.ahk').write_bytes(prod.read_bytes())
(out/'control-request-key-domain-old-hashes.json').write_text(json.dumps({str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [p,prod]},indent=2)+'\n')
CHECK
exec env WINEPREFIX=/workspace/toolchain/wine-r3-metrics-owned WINEPATH='Z:\workspace\toolchain\node-v22.22.2-win-x64' timeout --kill-after=5s 300s xvfb-run -a bash tools/test/run-ahk-under-wine.sh --ahk /workspace/toolchain/ahk/AutoHotkey64.exe --runner run_all.ahk --results /workspace/scratch/windows-audit-round6/verification-worker/456-lifecycle-request-key-domain-old-red18.tap -- --only driver-control-request-key-domain
