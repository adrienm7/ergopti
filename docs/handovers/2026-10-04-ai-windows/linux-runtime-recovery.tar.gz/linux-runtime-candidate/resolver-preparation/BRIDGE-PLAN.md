<!-- linux-runtime-candidate/resolver-preparation/BRIDGE-PLAN.md -->

# Canonical Linux install resolver and native runtime bridge

This is an unconnected scratch preparation. Its twenty controlled resolver cases
passed under both LuaJIT and Lua 5.4 (40 controlled passes). Two actual read-only
namespace-refusal probes passed in default tool mode; one earlier escalated-mode
namespace expectation failed and is preserved. See `RESOLVER-QUALIFICATION.md`
for exact commands, receipts and limits. The independently reviewed frozen
installer remains unchanged at its 108 product / 20 causal red / 2 teardown
receipts. No checkout file or shared canonical registry has been edited here.

## Prepared source boundaries

`shared/llm/ollama_install_policy.lua` is pure shared policy. It snapshots the
selected canonical `ollama_release.json` asset, selects a supported architecture,
validates literal POSIX paths and derives an immutable release identity. It has
no pinned versions, bytes or hashes of its own. Application ownership comes from
generated `app_dirs.folder_name`, whose source is
`_shared/modules/paths/app_dirs.toml`.

`linux/modules/llm/ollama_install_resolver.lua` supplies native UID, uname,
root-to-parent lstat receipts, access checks and explicit-consent mkdir admission.
Its default loader asks `infra.paths.shared` for the packaged canonical release
JSON and decodes it with shared `json.decode_lossless`. It creates no directory
at require/construction/menu time, executes no command and cannot launch or
download anything. Callers receive fresh plan snapshots, not writable references
to the captured paths or asset.

The managed target is:

```text
${XDG_DATA_HOME:-validated-HOME/.local/share}/
  ${AppDirs.folder_name}/runtimes/ollama/
  <version>-<canonical-asset-key>-<full-sha256>/ollama/
    bin/ollama
    lib/ollama/
```

The full immutable name permits coexistence with a running older release without
replacing its libraries. There is no `current` symlink, automatic upgrade,
garbage collector or differential update. The final `/ollama` directory preserves
the frozen file-owner ABI. Both resolver and installer consume one captured
target. Missing/private parent creation happens only inside explicit current
download consent; empty created app-data parents are durable user state, while
the file owner removes only its own unpublished archive/staging.

## Native trust contract and namespace limitation

The strict path candidate rejects `.`/`..`, NUL and ambiguous repeated separators;
every existing ancestor must be a real directory. Each ancestor captures exact
native device, inode, UID, mode and type. Group/other writable ancestors and
nonroot foreign owners are refused. The existing data root and managed descendants
must be owned by the actual native UID, with a real writable/executable anchor.
Before each creation and final preparation it rechecks captured identities and
current originating consent. Native UID changes, same-named replacements and
new third-party prefixes cannot borrow earlier absence receipts.

Default tool mode reports native UID 1000 and root inode UID 65534. Both Lua
ABIs therefore refuse root ancestry as foreign, with no attempted writes. The
strict candidate never claims overflow UID 65534 means root. The authorized
escalated tool mode instead reports actual native UID 1000 and root inode UID 0;
it returned a read-only plan with no attempted writes. The original probe
required root UID 65534 and correctly failed in that mode. This physical mode
difference is preserved in raw logs, not hidden by changing expected values.
Positive controlled prepare receipts remain seams. Native parent creation,
installation and production activation have not run; escalated mode may support
those prerequisites after the common worker bridge is approved. No positive
native installation qualification is claimed.

Path rechecks reject observed substitutions but cannot prove atomic exclusion
of a hostile same-UID process between lstat and pathname use. A stronger native
port can bind directory FDs to the kernel process root and actual UID-owned app
objects, then use no-follow `openat`/`openat2`, `mkdirat` and `renameat2`. This
trusts exact retained kernel objects, not an invented UID mapping. Inherited
archive/stage FDs would pin curl/SHA/tar inputs and outputs even after ancestor
renaming. Exact parent-FD retirement and helper inheritance must be owned;
current qualified file/HTTP ports do not supply that plumbing. It is a separate
reviewed native-capability slice, not an approved fallback or another process
state machine.

## Existing Linux production owners

| Owner | Current API/evidence | Runtime bridge consequence |
| --- | --- | --- |
| `infra.config_paths` | `home()` can fall back to TMPDIR; `data()` uses legacy `ergopti`. | Keep existing data unchanged; managed runtime requires valid XDG/HOME plus generated application owner. |
| `infra.paths` | `shared("modules/llm/ollama_release.json")` follows registered installed layouts. | Use it for canonical catalogue loading; no component counting or duplicated pins. |
| `infra.llm_bridge` | Canonical loopback host, configured/default port and valid port bounds; `ollama_endpoint` for chat/tags/pull. | Consume these values; never invent a host/port or launch local `serve` for a remote/HTTPS origin. |
| `modules.llm.enable_admission` | Fresh version policy and source-aware preference writer; current native wrapper uses `Http.get`/`Http.cancel` booleans. | Preserve writer/snapshot/UI ownership, add retained owned version/runtime capabilities without borrowing signal acceptance. |
| `prediction_engine.enable` | Captures backend/model/origin/generation/source; modal continuation and exact preference commit. | Attach runtime repair to this exact originating owner; do not write `llm.enabled` elsewhere. |
| `ui.llm_enable_refusal` | Explicit retry/cached replacement choices after modal keyboard restoration. | Add truthful runtime choices under this owner, with a returned retained native operation. |
| `local_model_probe` | Boolean GET tags verification. | Runtime/model stage needs an exact physically owned listing receipt before publishing readiness. |
| `model_download` | Boolean POST stream/cancel, progress window, terminal success frame. | Keep progress UX; extend retained physical transport ownership before including model completion in a repair promise. |
| `local_model_offer` | Manual model consent; automatic typing only notifies. | Reuse accurate model labels; read-only activation cannot silently download. |

There is currently no Linux Ollama binary resolver, owned `serve` API or runtime
dependency checker. An already running configured Ollama must remain usable via
a fresh version receipt even if a managed install directory is unavailable. A
read-only existing-binary resolver should independently inspect managed and fixed
absolute/PATH candidates, canonicalize legitimate symlinks only for reads and
return a retained regular/executable identity. It must not use `which`, version
commands, menu-time processes or caches. Its identity is rechecked before spawn.
Write-target paths retain the stricter no-symlink contract.

## Desired Group3 common worker port

The current remote `origin/feat/actions` at
`d7c8e13514bef49e0a544b1c275cad1ec39d19d9` still has no published
`_shared/lua/native_worker_owner.lua`. Do not adopt the scratch process stack
alongside it. The required adapter-facing shape is:

```lua
operation = Process.start(executable, argv, {
  owner = nonempty_named_string,
  authorized = function() return literal_true_only end,
  timeout_ms = positive_integer_or_nil_for_daemon,
  max_output_bytes = positive_integer,
  capture_tail = false_or_true,
  on_output = function(stream, chunk) end_or_nil,
  env = validated_inherited_name_value_array_or_nil,
  cwd = absolute_directory_or_nil,
}, on_complete)
-- operation.started, operation.error, operation.cleanup_error
-- operation.result = { ok, exit_code, signal, stdout, stderr, error }
operation:cancel()
operation:is_settled()
operation:on_settled(listener)
```

- Refusal returns an operation, retaining any acquired cleanup debt. It cannot
  throw away native acquisition or report a malformed/missing receipt as empty.
- Output/completion are fenced by the exact source; cancellation suppresses them
  immediately. Settlement delivery remains independent of source admission.
- Physical settlement requires actual leader exit, native descendant-group
  absence and every pipe/timer/process close ACK. SIGTERM/SIGKILL acceptance is
  insufficient; an unreaped group zombie remains debt.
- Helper output overflow is a real refusal. Daemon `capture_tail=true` retains
  bounded latest diagnostics while streaming all accepted output to the central
  logger; total historic logs must not kill a healthy daemon.
- Native group/session creation can use a retained referenced detached handle;
  never unref, background a shell, broadly pkill or control a foreign service.
- A future inherited-FD extension must admit only retained exact native file
  capabilities and include their actual retirement, not arbitrary raw numbers.

The frozen archive installer already consumes this start/settlement shape with
named string ownership. A thin Linux binding should translate Group3's common
policy, while Linux implements native spawn/group/pipe/close receipts. Shared
transaction policy owns consent, immutable scalar snapshots, queue/currentness,
deadline and handoff rules; OS ports own concrete helper commands and file APIs.
Move the pure orchestration out of its current scratch Linux-shaped location at
adoption, with GNU preflight steps supplied by the Linux archive port rather than
hardcoded as cross-platform policy.

## Startup, model and publication sequence

1. Capture the exact disabled backend/model/origin/generation/source through the
   existing enable owner. Probe the configured version with `get_owned`, no
   redirects and canonical probe timing. Wait for exit/close settlement.
2. If already reachable, use ordinary current writer admission. Do not require
   or install a local binary for an already working configured server.
3. Otherwise validate a native local loopback origin and inspect installed binary
   receipts. Start only one exact absolute binary with `serve`, preserving proxy
   and trust environment while binding canonical `OLLAMA_HOST`. Remote/HTTPS
   origins get an honest unavailable start reason.
4. If binary absent, require explicit accurately labelled consent before the
   resolver writes parents or the archive transaction downloads. Existing
   `ollama.offer_download` promises binary-only; `llm.unreachable.install`
   promises runtime and model. Never claim the latter from binary-only success.
5. Use the canonical 1,800,000ms dependency bootstrap ceiling for the whole repair,
   with an owned deadline and remaining budgets. Canonical per-probe timeout is
   1,500ms and daemon readiness poll interval is 3,000ms. Per-helper limits alone
   do not implement the overall ceiling. Timer stop/close debt remains owned.
6. Poll with retained owned version operations while the referenced daemon lives.
   PID existence/open port/generic ping is insufficient. Complete version receipt
   remains provisional while parent preference/native publication is pending.
7. A promised model scope needs retained tags and stream-pull operations, exact
   current model/source consent, actual complete success plus physical retirement
   and a fresh listing. No model preference selection or enable write may outrun
   the existing writer owner.
8. Only acknowledged native publication transfers the process capability from
   startup to a stable application-lifecycle owner. Refused writer/publication
   retires unpublished startup. The published predicate must stop consulting the
   original disabled ticket before its successful controlled transition would
   invalidate it. Preserve the existing macOS boundary: published daemon survives
   global pause; unpublished startup is cancelled on pause/source change.
9. After handoff, retain the exact long-lived operation without the bootstrap
   timeout. App shutdown or deliberate owned stop drains actual process/group/
   close receipts. Unexpected exit publishes its real failure and keeps enable
   admission honest. No automatic install/relaunch follows from exit.

Parent admission must attach the runtime operation to the exact originating
enable request. Releasing the old version request and merely invoking a repair
from a detached modal callback would allow duplicate intent or cancellation of
the wrong successor. Native handoff requires a concrete exact owner receipt; it
cannot treat a still-running process as physically exited.

## Remaining qualification

The new resolver needs independent read-only review, both-ABI controlled cases,
causal mutants and real filesystem receipts in a supported native ancestry
environment. All new tests remain unrun while root owns its verification slot.
The existing qualified installer remains an unconnected prerequisite. Shared
worker adaptation, owned HTTP/model streaming, exact enable/publication handoff,
real official archive/serve/model behavior, hosted packaging/installation and
original TODO16/38 requirements remain outstanding.
