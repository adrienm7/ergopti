// Literal independent corpus frozen before the receiver; no native execution.
'use strict';
const assert = require('node:assert/strict');
const { evaluate } = require('../diagnostics/lease_xctest_evidence.cjs');
const corpus = require('./fixtures/lease-native-xctest-corpus.json');
let positives = 0,
	rejections = 0;
for (const vector of corpus) {
	const result = evaluate(vector.transcript, vector.swift_status, vector.tee_status);
	assert.equal(result.complete, vector.expected_complete, vector.name);
	assert.equal(result.scope, 'lease-native-only');
	assert.equal(result.full_package_qualified, false);
	if (vector.expected_complete) {
		assert.equal(result.completed, 146);
		positives++;
	} else rejections++;
}
assert.equal(positives, 2);
assert.equal(rejections, 42);
console.log(`LEASE_XCTEST_RECEIVING_CONTROLS=2 PASS/42 REJECT; native UNEXECUTED`);

// Additive bounded physical capture controls; original corpus bodies remain whole.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { main } = require('../diagnostics/lease_xctest_evidence.cjs');
let boundedCaptures = 0;
for (const grow of [false, true]) {
	const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'lease-capture-control-'));
	const transcript = path.join(directory, 'xctest.log');
	const verdict = path.join(directory, 'verdict.json');
	fs.writeFileSync(transcript, corpus[0].transcript, { mode: 0o600 });
	const identity = fs.statSync(transcript);
	const admitted = identity.size;
	const ownsCapture = (fd) => {
		const stat = fs.fstatSync(fd);
		return stat.dev === identity.dev && stat.ino === identity.ino;
	};
	const originalRead = fs.readSync,
		originalReadFile = fs.readFileSync;
	const originalLog = console.log,
		originalError = console.error;
	const lengths = [];
	let cut = false;
	const beforeRead = () => {
		if (!cut) {
			cut = true;
			if (grow) fs.appendFileSync(transcript, Buffer.alloc(1048576, 120));
		}
	};
	try {
		fs.readSync = (fd, buffer, offset, length, position) => {
			if (ownsCapture(fd)) {
				beforeRead();
				lengths.push(buffer.byteLength, length);
			}
			return originalRead(fd, buffer, offset, length, position);
		};
		fs.readFileSync = (file, ...args) => {
			if (typeof file === 'number' && ownsCapture(file)) {
				beforeRead();
				const bytes = originalReadFile(file, ...args);
				lengths.push(bytes.byteLength);
				return bytes;
			}
			return originalReadFile(file, ...args);
		};
		console.log = () => {};
		console.error = () => {};
		const result = main([transcript, '0', '0', verdict]);
		assert.equal(result, grow ? 1 : 0);
		assert.ok(cut);
		assert.ok(lengths.length > 0 && lengths.every((length) => length <= admitted));
		if (grow) assert.ok(!fs.existsSync(verdict));
		else assert.equal(JSON.parse(originalReadFile(verdict, 'utf8')).completed, 146);
		boundedCaptures++;
	} finally {
		fs.readSync = originalRead;
		fs.readFileSync = originalReadFile;
		console.log = originalLog;
		console.error = originalError;
		fs.rmSync(directory, { recursive: true, force: true });
	}
}
assert.equal(boundedCaptures, 2);
console.log('LEASE_XCTEST_BOUNDED_REAL_CAPTURE_CONTROLS=2; native UNEXECUTED');
for (const frame of [
	' Test Case foreign started.',
	' Test Suite Foreign started.',
	'\tTest Case foreign passed.'
]) {
	assert.equal(evaluate(frame + '\n' + corpus[0].transcript, 0, 0).complete, false);
}
console.log('LEASE_XCTEST_LEADING_FRAME_REFUSALS=3');

// These exact vectors were independently frozen and observed RED before correction.
const crypto = require('node:crypto');

{
	const transcript = corpus[0].transcript.replaceAll(
		'in 0.146 (0.147) seconds',
		'in NOT_A_DURATION'
	);
	assert.equal(
		crypto.createHash('sha256').update(transcript).digest('hex'),
		'017b4e7fc5a0ca4c03fed70a7789531779abafec0b0f01178954e9ca8e7c5eb3'
	);
	assert.equal(evaluate(transcript, 0, 0).complete, false, 'non-duration-summary');
}

{
	const transcript = corpus[0].transcript.replaceAll(
		'in 0.146 (0.147) seconds',
		'in 0.146 (0.147) seconds; 1 test skipped'
	);
	assert.equal(
		crypto.createHash('sha256').update(transcript).digest('hex'),
		'981c17de0bc4262308d75adacabb518e7c13c7e159f126d4a74e0a7979fa7334'
	);
	assert.equal(evaluate(transcript, 0, 0).complete, false, 'contradictory-skip-suffix');
}
console.log('LEASE_XCTEST_FROZEN_SUMMARY_REFUSALS=2');
