# Retained tar feeder final publication fence

Source only. Revision3 e1f5c374 is preserved unchanged. Archive reviewer found
a final external lineage/clock callback could revoke the captured completion
while outer drain retained stale local success. Revision4 refences exact
completion identity/seen/refused, feed state, terminal/delivery/dispatch and
reader settlement after that callback. Revoked completion fields are omitted.
Physical supervisor/reader/timer joins, native8/IO12 control regions and5/10/40
second bounds remain unchanged. One literal duplicate-during-final-current
control is authored; all revised controls/native scopes UNRUN pending root slot.
Prior first native failure and original unresolved debt remain preserved.
