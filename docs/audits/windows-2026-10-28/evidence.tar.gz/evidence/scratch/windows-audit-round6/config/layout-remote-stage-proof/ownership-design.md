# Request-owned layout transfer proposal

The frozen OLD478 cohort is genuine 4 PASS / 4 FAIL; production remains unchanged.
The foreign file is removed before the layout request factory gets control.

## Exact participants

- `layout_catalogue.ahk:621`: public `LayoutCatalogue_Install` → `_LayoutCatalogueOnInstallIndex`; fixed `<id>.keylayout.download`. `_LayoutCatalogueOnLayout` reads/verifies it and deletes it on success or failure.
- `layout_catalogue_refresh.ahk:115`: refresh uses `index.json.download.<script HWND>_<refresh sequence>`; `_LayoutCatalogueOnIndex` deletes stale/current outputs and directly promotes the response file to the cache. Its sequence isolates ordinary reentrancy but does not grant native creation authority.
- `layout_extension.ahk:126`: `_LayoutExtensionNext` uses fixed `<id>.extension.download`; `_LayoutExtensionDownloaded` reads/deletes it, while finished/position guards reject stale business callbacks.
- All three call `LayoutRegistry_Request` (`layout_registry.ahk:331`). `_LayoutRegistrySend:356` unconditionally deletes the provided name before invoking the request factory. `_LayoutRegistryRetire:388` already fences an exact request until Abort returns integer1. `_LayoutRegistryPoll:414` and `_LayoutRegistrySettle:347` provide the existing single terminal callback.
- Default transport is `CurlAsyncRequest`; `http_client.ahk:593` says SetOutputFile's caller owns that path. `_SendManaged:373` forwards it unchanged as response_path. `ergopti_winhttp_transport.ps1:502` writes with FileMode.Create / FileAccess.Write / FileShare.Read; route attempts also clear it via WriteAllBytes at702. A new download owner must be compatible with these existing writes; no HTTP API change is proposed.

## Existing primitives and limits

- FSWriteCreateDurable: native CREATE_NEW + flush, collision preserving, but returns a Boolean and closes the creation handle. Its return alone is not a reusable transfer capability.
- FSCreateDirectoryExclusiveStrict: atomic directory acquisition, but no retained directory handle/identity capability is returned.
- FSHandleSnapshot: real volume/file-index identity from an existing native handle.
- FSDeleteVerified: reads a stable candidate, invokes a genuine ownership verifier, reacquires exclusive DELETE access, compares native identities/metadata, then deletes through SetFileInformationByHandle. This is the existing safe unlink mechanism to reuse after native transfer retirement.
- _SR_AcquireCaptureDirectory: real exclusive mkdir for process/HTTP capture. It returns a name and always allocates in A_Temp. Reusing it for downloaded index publication could cross volumes and is not a transfer capability as-is.
- FSAtomicMoveCreate preserves destination collisions; FSAtomicMoveReplace is an atomic replacement primitive, without created-source capability admission.

## Preferred bounded design for review

1. Keep all changes within the layout registry's three callers, its request owner, a narrow Windows-only filesystem transfer capability, and regression tests. Do not change broad HTTP adapters, shared ports, updater staging or PublishCopy.
2. A request-private owner acquires its stage before proxy resolution, request construction or SetOutputFile. Allocate beside the intended target (same volume) with native CREATE_NEW, never delete an existing name and never infer ownership from FileExist, a response status or callback success.
3. The capability must retain the actual creation handle/identity in private closures, and be passed as the required domain completion capability, replacing caller-bound bare stage paths. An acquisition refusal has no cleanup capability and reports one visible download failure. No compatibility branch accepts an old path/Boolean as authority.
4. A candidate native pin is a create-new read/attribute handle that allows the worker's writes but denies deletion/replacement while I/O is live. The real FileMode.Create/FileShare.Read compatibility and cancellation/refused-Abort behavior must be demonstrated natively before choosing access/share flags. This is a proposal, not a proved Windows API implementation.
5. Reads operate on the created object and remain bounded. Cleanup reuses FSHandleSnapshot/FSDeleteVerified with the captured creation identity after exact request retirement. A changed/rebound name is retained and refused, never removed. An unretired request retains its owner; disposal errors retain explicit debt instead of fabricating release.
6. Index publication needs the same capability boundary because current code directly renames the response. Prefer a narrow handle/identity-admitted publish operation which preserves exact downloaded bytes. Do not replace it casually with a decoded-text rewrite: that can change BOM/raw bytes. Validate/reacquire exclusive authority by native file ID before a handle-based rename; any release/reacquire gap must refuse a changed object. This native boundary requires a separate genuine positive/collision/rebind probe, not a pathname check.
7. The stage owner proves file custody only. Keep refresh-current, install lease, and extension finished/position checks as separate business-generation admission; do not grant publication because a stage exists. Preserve exact request Abort/late-callback retirement fences and single completion.

## Required follow-up proof after scope review

Retain OLD478 and its four successful/refused cold controls unchanged. Add actual creation-collision and sharing compatibility controls before implementation, then test pre-dispatch failure, resolver throw, Abort refusal/retry, late callback, callback throw, reentrant extension-next/refresh, identity substitution, exact binary bytes and cleanup handle/debt retirement. No test will claim native Windows WinHTTP worker execution under the known unsupported local Wine PowerShell runtime; actual Windows CI remains mandatory for that transport boundary.
