from pathlib import Path
import subprocess,json,hashlib
root=Path('/workspace/ergopti-windows-r6-tests');packet=Path(__file__).parent
paths=json.loads((packet/'owned-paths.json').read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')=='e4565ae0e6162d8da099ca6222f709652cc00b8e'
assert not git('diff','--cached','--name-only')
assert set(git('diff','--name-only').splitlines())==set(paths)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
subprocess.run(['sh','.husky/pre-commit'],cwd=root,check=True)
(packet/'candidate-hashes.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths},indent=2)+'\n')
