"""Serial actual private bytecode origin receiving; never live writes or native proof."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,tempfile,time
live=Path('/workspace/ergopti');previous=Path('/workspace/ergopti-cloud/group6-native-clock-passive-evidence-proposal/runtime-source');base=Path('/workspace/ergopti-cloud/clock-passive-bytecode-receiving');base.mkdir(exist_ok=True)
work=Path(tempfile.mkdtemp(prefix='actual-',dir=base));pins={}
paths={p.relative_to(previous).as_posix() for p in previous.rglob('*') if p.is_file()}
paths.add('tools/test/managed_ollama_runtime_policy_test.py')
for branch in ('static/ergopti_plus/_shared/python','static/ergopti_plus/_shared/modules/llm','static/ergopti_plus/macos/platform','static/ergopti_plus/macos/modules/llm','static/ergopti_plus/macos/adapters'):
 for p in (live/branch).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.json','.lua'):paths.add(p.relative_to(live).as_posix())
for relative in paths:
 source=live/relative
 if not source.is_file():source=previous/relative
 pins[relative]={'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'bytes':source.stat().st_size,'source':str(source)}
(work/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
records=[]
def namespace(role):
 root=work/role/'source';root.mkdir(parents=True)
 for relative,pin in pins.items():
  target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);raw=Path(pin['source']).read_bytes();assert hashlib.sha256(raw).hexdigest()==pin['sha256'];target.write_bytes(raw)
 private=root.parent/'tmp';private.mkdir(mode=0o700)
 return root,private

def receive(role,args,expected=None):
 root,private=namespace(role);environment=os.environ.copy();environment.pop('PYTHONDONTWRITEBYTECODE',None);environment.pop('PYTHONPYCACHEPREFIX',None);environment['TMPDIR']=str(private)
 out=root.parent/'stdout';err=root.parent/'stderr';started=time.monotonic()
 with out.open('wb') as stdout,err.open('wb') as stderr:result=subprocess.run([sys.executable,*args],cwd=root,env=environment,stdout=stdout,stderr=stderr,timeout=120)
 pycs={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*.pyc')}
 platform=[name for name in pycs if name.startswith('static/ergopti_plus/macos/platform/')]
 record={'role':role,'exit':result.returncode,'seconds':round(time.monotonic()-started,3),'argv_prefix':args[:2],'platform_cache_names':platform,'all_created_pycs':pycs,'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest(),'qualification':'ACTUAL_PRIVATE_PYTHON_CACHE_EFFECTS_ONLY_NO_NATIVE'}
 records.append(record);(work/'receipts.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==0,(role,str(root.parent))
 if expected:
  text=err.read_text();assert re.search(r'Ran '+str(expected)+r' tests in',text) and '\nOK\n' in text;record.update({'tests':expected,'failures':0,'errors':0,'skips':0})
 print(json.dumps(record),flush=True)
 return record
baseline='4dd97e10cb88e85ff5379becbef0376289b8bd68'
for name in ('macos_source_alias_owner_test','macos_ollama_bootstrap_owner_test','macos_suspended_image_owner_test','macos_ollama_daemon_authority_test','macos_ollama_hint_metadata_test'):
    rel='tools/diagnostics/'+name+'.py'
    committed=subprocess.run(['git','show',baseline+':'+rel],cwd=live,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    assert committed==(live/rel).read_bytes(),rel
for name in ('source_alias_owner','ollama_bootstrap_owner','suspended_image_owner','ollama_daemon_authority','ollama_hint_metadata'):
    rel='static/ergopti_plus/macos/platform/'+name+'.py'
    committed=subprocess.run(['git','show',baseline+':'+rel],cwd=live,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    assert committed==(live/rel).read_bytes(),rel
for name,expected in (('macos_source_alias_owner_test',19),('macos_ollama_bootstrap_owner_test',22),('macos_suspended_image_owner_test',39),('macos_ollama_daemon_authority_test',14),('macos_ollama_hint_metadata_test',19)):
    receive('legacy_default_'+name,['tools/diagnostics/'+name+'.py'],expected)
    receive('legacy_no_bytecode_'+name,['-B','tools/diagnostics/'+name+'.py'],expected)
(work/'receipts.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'terminal':True,'receipts':str(work),'actual_committed_legacy_baseline':baseline,'native_credit':False}))
