"""Freeze exact outside-checkout root/corpus deltas and finite inverse."""
import ast,difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
C=P/'canonical143'
REPAIR=P.parent/'group6-r2-canonical-order-repair/candidate'
IND=P.parent/'group6-native-http-callee103-independent-proposal/candidate'
FROZEN=P.parent/'group6-native-http-builder136-enrollment-proposal/candidate'
TEST='tools/test/macos_native_http_receiving_facts_test.py';REG='tools/test/test-managed-ollama-protocol.cjs'
CLIENT='static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
BHELPER='tools/test/macos_native_http_fixture_builder_controls.py';RHELPER='tools/test/macos_native_http_client_root_controls.py'
paths=[CLIENT,TEST,REG,BHELPER,RHELPER]
def digest(data):return hashlib.sha256(data).hexdigest()
def functions(data):
 s=data.decode();lines=s.splitlines(True)
 return [(n.name,''.join(lines[n.lineno-1:n.end_lineno])) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.FunctionDef)]
oldfunctions=functions((REPAIR/TEST).read_bytes());newfunctions=functions((C/TEST).read_bytes())
assert [n for n,b in oldfunctions]==[n for n,b in newfunctions]
changes=[name for (name,old),(unused,new) in zip(oldfunctions,newfunctions) if old!=new]
assert changes==['test10FixtureFlagCannotChangeReleaseOperationsOrMoveCausalBoundaries']
assert (C/BHELPER).read_bytes()==(FROZEN/BHELPER).read_bytes()
clientold=functions((IND/CLIENT).read_bytes());clientnew=functions((C/CLIENT).read_bytes())
newnames=[name for name,body in clientnew]
changed=[]
for name,body in clientold:
 other=next(b for n,b in clientnew if n==name)
 if body!=other:changed.append(name)
assert changed==['setUpClass','tearDownClass']
pre=P/'final-preimage';patch='';inverse='';manifest={}
for rel in paths:
 source=IND/rel if rel==CLIENT else REPAIR/rel
 before=source.read_bytes() if source.is_file() else b''
 after=(C/rel).read_bytes()
 if before:
  target=pre/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(before)
 # Finite whole-file diffs preserve all unrelated bytes.
 patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 inverse+=''.join(difflib.unified_diff(after.decode().splitlines(True),before.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel if before else '/dev/null'))
 manifest[rel]={'preimage_sha256':digest(before) if before else None,'postimage_sha256':digest(after),'new_path':not bool(before),'bytes':len(after)}
(P/'final-proposal.patch').write_text(patch);(P/'final-inverse.patch').write_text(inverse)
(P/'final-source-review.json').write_text(json.dumps({'status':'RUNTIME_FULL143_PENDING','apply_paths':manifest,'owning_original_test_body_exception':changes,'every_other103_function_span_exact':True,'existing33_provider_whole_file_exact':True,'client_changed_original_functions':changed,'client_all_other_function_spans_exact':True,'new_root_control_total':7,'strict_registry_total':143,'native_credit':False,'source_prerequisites':['Independent three-path central builder proposal coherently applied','Repaired canonical R2 owning103 source exact3f9d0468; registry8e557928']},indent=2,sort_keys=True)+'\n')
# Updated relocation old/new function pins reflect final formatted bytes.
name=changes[0]
oldbody=next(b for n,b in oldfunctions if n==name);newbody=next(b for n,b in newfunctions if n==name)
assert oldbody[:oldbody.index('        compiler =')]==newbody[:newbody.index('        import ast')]
(P/'final-relocation-function-review.json').write_text(json.dumps({'name':name,'preimage_sha256':digest(oldbody.encode()),'postimage_sha256':digest(newbody.encode()),'all_original_causal_stage_assertion_prefix_byte_exact':True,'only_old_inline_compiler_source_assertion_relocated_to_actual_callee_and_caller_AST':True},indent=2)+'\n')
print(json.dumps(manifest,indent=2))
