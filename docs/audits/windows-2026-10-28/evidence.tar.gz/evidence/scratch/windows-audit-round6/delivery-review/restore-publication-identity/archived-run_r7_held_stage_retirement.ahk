﻿; static/ergopti_plus/windows/tests/run_all.ahk

; ==============================================================================
; MODULE: Test Runner Entry Point
; DESCRIPTION:
; Single ``AutoHotkey.exe`` entry point for the ErgoptiPlus AHK test suite.
; Loads the framework, the stubs, every production lib and every per-module
; test file in dependency order, then calls ``RunTests`` to execute all
; registered ``Test`` cases. Exits with code 0 on full pass, 1 on any failure
; — the contract the GitHub Actions workflow relies on to fail the CI build.
;
; FEATURES & RATIONALE:
; 1. The runner #Includes the production ``infra/`` files directly. This means
;    a refactor in a lib file is immediately exercised by the corresponding
;    test_*.ahk file with no per-test glue to maintain.
; 2. ``modules/`` files are deliberately NOT included — they register hotkeys
;    at top level and would prevent the runner from exiting cleanly. The
;    behaviour exposed by modules (layer / shortcuts / hotstrings) is tested
;    through the infra/ helpers it shares with production.
; 3. AHK v2 directives at the top mirror those in ErgoptiPlus.ahk so that
;    parser quirks (#Warn VarUnset, encoding) are identical between test
;    runs and production startup.
; ==============================================================================

#Requires Autohotkey v2.0+
#SingleInstance Force
SetWorkingDir(A_ScriptDir)
#Warn All, StdOut
#Warn VarUnset, Off
; Same policy as ErgoptiPlus.ahk: #Warn covers the whole compilation unit and
; the vendored UIA.ahk shadows globals on purpose. Every other warning class
; stays on and fails the CI compiler-warning gate.
#Warn LocalSameAsGlobal, Off
; Parse runner flags:
;   --dry-run        parse/load gate only — register every test, skip execution.
;   --interactive    explicitly allow tests that activate windows or inject keys.
;   --only <substr>  run only tests whose name contains <substr> (case-insensitive),
;                    e.g. AutoHotkey64.exe run_all.ahk --only "(my-slug)" to replay
;                    a single failing test without the whole suite.
;   --module=<group> run only one module group (TEST_MODULE_GROUPS in
;                    test_framework.ahk); the CI runs one group per runner.
;   --list=<file>    run only the tests named in <file>, one per line, in order.
;   --dump-plan=<f>  append "group<TAB>file<TAB>name" for each selected test.
;   --reverse        run the selected tests backwards to expose tests that rely
;                    on state an earlier test left behind.
; Reject malformed options before includes can initialize tests or input hooks.
_RejectRunnerArguments(Message) {
	FileAppend("Invalid test runner arguments: " . Message . "`n", "**")
	ExitApp(2)
}

global _AHK_DRY_RUN := false
global _AHK_ONLY_FILTER := ""
global _AHK_INTERACTIVE := false
global _AHK_QUALIFICATION_PROFILE := ""
global _AHK_MODULE := ""
global _AHK_LIST_FILE := ""
global _AHK_DUMP_PLAN := ""
global _AHK_REVERSE := false
_riArgIndex := 1
while (_riArgIndex <= A_Args.Length) {
	_riArg := A_Args[_riArgIndex]
	if (_riArg == "--dry-run")
		_AHK_DRY_RUN := true
	else if (_riArg == "--interactive")
		_AHK_INTERACTIVE := true
	else if (_riArg == "--reverse")
		_AHK_REVERSE := true
	else if (SubStr(_riArg, 1, 24) == "--qualification-profile=") {
		if _AHK_QUALIFICATION_PROFILE != ""
			_RejectRunnerArguments("--qualification-profile may be supplied only once")
		_AHK_QUALIFICATION_PROFILE := SubStr(_riArg, 25)
		if _AHK_QUALIFICATION_PROFILE == ""
			_RejectRunnerArguments("--qualification-profile requires a non-empty id")
	}
	else if (SubStr(_riArg, 1, 9) == "--module=") {
		if _AHK_MODULE != ""
			_RejectRunnerArguments("--module may be supplied only once")
		_AHK_MODULE := SubStr(_riArg, 10)
		if !RegExMatch(_AHK_MODULE, "^[a-z][a-z0-9-]*$")
			_RejectRunnerArguments("--module requires a group name")
	}
	else if (SubStr(_riArg, 1, 7) == "--list=") {
		if _AHK_LIST_FILE != ""
			_RejectRunnerArguments("--list may be supplied only once")
		_AHK_LIST_FILE := SubStr(_riArg, 8)
		if !FileExist(_AHK_LIST_FILE)
			_RejectRunnerArguments("--list requires an existing file")
	}
	else if (SubStr(_riArg, 1, 12) == "--dump-plan=") {
		if _AHK_DUMP_PLAN != ""
			_RejectRunnerArguments("--dump-plan may be supplied only once")
		_AHK_DUMP_PLAN := SubStr(_riArg, 13)
		if _AHK_DUMP_PLAN == ""
			_RejectRunnerArguments("--dump-plan requires a path")
	}
	else if (_riArg == "--only" || SubStr(_riArg, 1, 7) == "--only=") {
		if StrLen(_AHK_ONLY_FILTER) > 0
			_RejectRunnerArguments("--only may be supplied only once")
		if (_riArg == "--only") {
			if (_riArgIndex >= A_Args.Length)
				_RejectRunnerArguments("--only requires a non-empty filter")
			_riArgIndex += 1
			_AHK_ONLY_FILTER := A_Args[_riArgIndex]
			if (SubStr(_AHK_ONLY_FILTER, 1, 2) == "--")
				_RejectRunnerArguments("a filter starting with -- requires the --only= form")
		} else
			_AHK_ONLY_FILTER := SubStr(_riArg, 8)
		if (Trim(_AHK_ONLY_FILTER, " `t`r`n") == "")
			_RejectRunnerArguments("--only requires a non-empty filter")
	} else
		_RejectRunnerArguments("unknown option or unexpected positional argument")
	_riArgIndex += 1
}

; Test framework first — Assert / Test / RunTests must exist before any
; subsequent file registers its cases or invokes assertions inside lambdas.
#Include test_framework.ahk
#Include support/native_cli_diagnostics.ahk
; Acquire the selected receipt before any bootstrap observation or test include.
_TestResultsBeginRun()

; AppState — must come before test_stubs.ahk because the stubs reference
; AppState fields directly, and before any infra/ file that reads AppState.
#Include ../infra/app_state.ahk

; Stubs second — they define ScriptInformation, Features, SendNewResult,
; WrapTextIfSelected, DeadKey, ToggleCapsLock, etc., which infra/ files
; reference at definition (Bind) time or at call time during tests.
#Include test_stubs.ahk
#Include ../modules/keystats/keystats_health.ahk

; Install a very early error handler for top-level / #Include phase errors.
; When a newly added production module (LLM, gestures, keystats, prompt builder,
; menu_llm persist, etc.) or test_*.ahk has a top-level statement that throws
; (unset global, t() before i18n is ready, missing stub for a static initializer,
; bad include order, etc.) the default AHK behaviour is to show a modal error
; MsgBox. In the headless CI runner that dialog is never dismissed → the exe
; never exits → the step times out even if the previous green run was ~10 s.
; This handler writes a clear "not ok 0" line to the exact file the CI tailer
; watches and forces a clean ExitApp so the failure is visible and fast.
_FatalErrorHandler(e, mode) {
    msg := "not ok 0 - FATAL STARTUP ERROR: " . e.Message
    try 	msg .= "`r`nSTACK TRACE:`r`n" . e.Stack
	msg .= "`r`nLikely cause: top-level code or missing stub in a newly added module."
	global TEST_RESULTS_FILE
	try _TestResultsWrite(TEST_RESULTS_FILE, msg . "`r`n")
	try FileAppend(msg . "`r`n", "**")
	try FileAppend(msg . "`r`n", "*")
    ExitApp(1)
    return 1
}
OnError(_FatalErrorHandler)

; ── Production lib files in dependency order ──
#Include ../infra/tick_count.ahk
#Include ../vendor/Promise.ahk
#Include ../infra/webview_utils.ahk
#Include ../ui/console_window.ahk
#Include ../infra/wall_clock.ahk
; Compiled-mode bundle bootstrapper — included this early (matching its real
; position right after app_state.ahk in ErgoptiPlus.ahk) so its functions are
; actually exercised by meta/infra/lifecycle/test_bundle_resolve_dir_local_appdata.ahk instead
; of only being scanned as raw text. Bundle_Init() itself is never called here
; (A_IsCompiled is false in the test runner, and it would ExitApp on failure
; anyway) — only its pure helpers (_Bundle_ResolveDir, ResolveLocalAppDataDir)
; are invoked directly by the regression test.
#Include ../infra/bundle.ahk
#Include ../infra/tray_bootstrap.ahk
#Include ../adapters/tray_startup_click.ahk
#Include ../adapters/tray_startup_commands.ahk
#Include ../infra/single_instance_gate.ahk
#Include ../ui/menu/menu_llm/menu_build_coordinator.ahk
#Include ../_generated/window_titles.ahk
#Include ../infra/native_dialogs.ahk
#Include ../infra/ui_style.ahk
#Include ../_generated/logger_sub_files.ahk
#Include ../_generated/app_dirs.ahk
#Include ../infra/logger.ahk
; The logs folder every logger test writes to: a private temp folder, never the
; user's real %LOCALAPPDATA%\ergopti_plus\logs\ (boot.ahk sets it in the driver).
global _LogsDir := A_Temp . "\ergopti_test_logs\ergopti_plus\"
global _DefaultLogsDir := _LogsDir
; Boot stage profiler and the cross-driver diagnostic snapshot: definitions and
; two counters only, exercised by unit/ui/healthcheck/test_diagnostic_logging.ahk.
#Include ../infra/boot_profiler.ahk
#Include ../infra/startup_smoke.ahk
#Include ../infra/diagnostic_snapshot.ahk
#Include ../infra/issue_link.ahk
#Include ../infra/redact.ahk
#Include ../infra/issue_report.ahk
#Include ../infra/error_policy.ahk
#Include ../infra/error_report.ahk
#Include ../infra/toml/toml_helpers.ahk
; Shared timing registry reader (TimingsLoadShared / TimingsGet) — needs
; ParseTomlFile above; exercised by test_timings_config.ahk.
#Include ../infra/timings/timings_config.ahk

#Include ../infra/window_utils.ahk
#Include ../infra/external_url_policy.ahk
#Include ../ui/tooltip/position_receipt.ahk
#Include ../infra/text_utils.ahk
#Include ../infra/text_case.ahk
#Include ../infra/wrap_pair.ahk
#Include ../infra/open_target.ahk
#Include ../infra/send_input_parameter.ahk
#Include ../infra/tap_keys.ahk
#Include ../infra/key_combinations.ahk
#Include ../infra/nav_layer_helpers.ahk
#Include ../infra/hotstrings/hotstring_engine.ahk
#Include ../infra/altgr_family.ahk
#Include ../infra/hotstrings/hotstring_engine_main.ahk
#Include ../infra/hotstrings/hotstring_buffer_effects.ahk
#Include ../infra/hotstrings/hotstring_live_toggle.ahk
#Include ../infra/hotstrings/hotstring_count_policy.ahk
#Include ../infra/hotstrings/hotstring_prefix_watcher.ahk
#Include ../infra/master_gates.ahk
; Generated terminator catalogue (shared single source) — exercised by
; test_terminators.ahk and consumed by the tray / config-window delimiter menus.
#Include ../_generated/terminators.ahk
#Include ../infra/toml/toml_loader.ahk
#Include ../infra/hotstrings/extension_packs.ahk
#Include ../infra/hotstrings/hotstrings_cache.ahk
#Include ../infra/toml/toml_config_loader.ahk
#Include ../infra/config_migrate.ahk
#Include ../../_shared/modules/config/outdated.ahk
#Include ../platform/remap/tap_hold_loader.ahk
#Include ../platform/remap/tap_hold_writer.ahk
; The layer-file loader reads _shared/keymap and the physical-key registry at run
; time; meta/corpus/test_corpus_keymap_layers.ahk replays the cross-driver corpus through it.
#Include ../platform/remap/layers_loader.ahk
; The navigation layer's hotkey table, built from layer files; registration is
; injectable, so unit/platform/remap/layers/test_nav_layer_table.ahk drives it without a live hook.
#Include ../platform/remap/nav_layer_table.ahk
; The layer editor host: validation, the atomic save and the page's messages,
; driven by unit/modules/keymap/test_layer_editor_host.ahk without a WebView.
#Include ../ui/layer_editor/init.ahk
#Include ../ui/menu/menu_taphold.ahk
; The hotstring gate and « all sections » rows, built over the live Features.
#Include ../ui/menu/menu_hotstring_switches.ahk
; The whole tree's path collector and tick, which the bulk hotstring writer in
; infra/config_io.ahk calls. Definitions only; the category tables they read are
; declared by ui/tray_menu.ahk, which is not loaded, so a test supplies them.
#Include ../ui/menu/menu_submenus.ahk
#Include ../_generated/features_manifest.ahk
#Include ../infra/manifest_reader.ahk
; Native manifest-built menu rows use the same pure label owner as tray boot.
#Include ../infra/manifest_descriptions.ahk
; The dynamic-hotstring module, for its pure helpers (SpacedPrefix, the three
; date formatters). Definitions only — _DynHS_RegisterAll() is not called here,
; so no registration happens at harness load.
#Include ../modules/dynamic_hotstrings/dynamic_hotstrings.ahk
#Include ../modules/dynamic_hotstrings/user_code.ahk
#Include ../infra/feature_io.ahk
; EnsurePersonalHotstringFeature is exercised directly by the F4 regression
; test (test_feature_io_locator.ahk) — RegisterPersonalFeature in the same file
; is never called here, so its own unseeded global (_PersonalShortcutsRegistry)
; is harmless (#Warn VarUnset is off).
#Include ../infra/personal_features.ahk
#Include ../infra/hotstrings/hotstrings_config.ahk
#Include ../infra/suspend_handoff.ahk
#Include ../infra/reload_terminal_handoff.ahk
#Include ../infra/reload_successor.ahk
#Include ../infra/reload_deferral.ahk
#Include ../infra/suppressive_inputhook_ownership.ahk
#Include ../infra/lifecycle_transition.ahk
#Include ../infra/config_transition.ahk
#Include ../infra/config_transition_runtime.ahk
; _CollectFeatureUpdates is exercised directly by the section-resolution
; regression tests (test_config_io_feature_section_resolution.ahk).
; SaveFullConfig itself is never invoked here (it depends on numerous
; boot-only globals), so including this file is safe — only function
; definitions at top level.
#Include ../infra/config_io.ahk
#Include ../infra/config_scope.ahk
#Include ../../_shared/modules/hotstrings/scope_overrides.ahk
#Include ../infra/hotstrings/hotstrings_scope.ahk
#Include ../infra/config_global_scope.ahk
#Include ../ui/personal_toml_editor.ahk
#Include ../ui/personal_toml_editor_webview.ahk
; Pure helpers (no boot-time side effects) — CountDynamicSection is exercised
; by the dynamic-hotstrings corpus parity test.
#Include ../infra/menu_helpers.ahk
; Definitions-only live rebuild coordinator/menu helpers. No tray mutation is
; performed until a test explicitly invokes an injected rebuild body.
#Include ../ui/menu/menu_rebuild.ahk
; Wrap-symbols persistence: globals and function definitions only, no top-level
; side effects, so it loads headlessly. Included so the load/save data-loss
; guard (test_wrap_symbols_unreadable_blocks_save.ahk) can drive the real
; functions instead of scanning their source.
#Include ../infra/wrap_symbols_config.ahk
#Include ../modules/keymap/layout/layout_altgr.ahk
#Include ../modules/keymap/layout/layout_ergopti.ahk
#Include ../modules/keymap/layout/accented_shortcuts.ahk
#Include ../../_shared/modules/features/number_row_policy.ahk
#Include ../../_shared/modules/features/layout_rows_policy.ahk
#Include ../../_shared/modules/features/caps_word_auto_off_policy.ahk
#Include ../../_shared/modules/features/pause_switch_policy.ahk
#Include ../modules/keymap/layout/layout_shift_caps.ahk
#Include ../modules/keymap/layout/number_row_send.ahk
; Registry layout emulation: definitions only (the hotkeys are registered by
; KeylayoutEmulation_Register, which the tests call with injected registrars).
#Include ../modules/keymap/keylayout/keylayout_parser.ahk
#Include ../modules/keymap/keylayout/keylayout_tables.ahk
#Include ../modules/keymap/keylayout/keylayout_emulation.ahk
#Include ../modules/keymap/keylayout/layout_registry.ahk
#Include ../modules/keymap/keylayout/layout_catalogue.ahk
#Include ../modules/keymap/keylayout/layout_extension.ahk
; Pure layout-poll quiescence decision (no OS deps, no top-level hotkeys) —
; exercised by meta/modules/keymap/test_layout_quiescence.ahk and consumed by ErgoptiPlus.ahk.
#Include ../modules/keymap/layout_poll_helper.ahk
#Include ../modules/keymap/pause_layout_switch.ahk
#Include ../ui/tooltip/init.ahk
#Include ../adapters/tooltip_renderer.ahk
#Include ../modules/updater.ahk
#Include ../infra/uninstall.ahk
#Include ../infra/start_at_login.ahk
; json.ahk must precede locale.ahk — _I18nLoadLocaleMap delegates to JsonParse.
#Include ../infra/registry.ahk
#Include ../infra/json.ahk
; Keep the standalone assertion library independent of production JSON symbols.
TestQualificationRegisterParser(JsonParse)
#Include ../infra/program_parameter.ahk
#Include ../adapters/program_providers.ahk
#Include ../ui/action_picker_webview.ahk
#Include ../infra/program_actions.ahk
#Include ../../_shared/modules/network/failure.ahk
#Include ../adapters/network_failure_host.ahk
#Include ../ui/download_window/session.ahk
#Include ../ui/download_window/init.ahk
; locale.ahk (string loading + t()) is included here because gestures.ahk calls
; t() at the top level when building GESTURE_SLOT_LABELS; without it the process
; blocks on an AHK runtime-error MsgBox and the CI job times out. i18n.ahk (locale
; management) follows it and calls into the loaders/state it declares.
#Include ../infra/locale.ahk
#Include ../_generated/gesture_emit_actions.ahk
#Include ../_generated/action_catalogue.ahk
#Include ../_generated/locale_table.ahk
#Include ../infra/i18n.ahk
_LogBootProgress("i18n included (t() available)")

; Install the hotstring hooks for the entire test process so neither real
; ``Hotstring()`` registrations nor real ``SendEvent`` keystrokes ever escape
; into the CI environment. Stubs that need raw send semantics still observe
; UpdateLastSentCharacter (the hook only intercepts the lower-level emission).
InstallHotstringHooks()

; ── Adapter contract: include all port adapters so contract vector tests can call them ──
#Include ../adapters/notifier.ahk
#Include ../adapters/timer_scheduler.ahk
#Include ../adapters/file_system.ahk
#Include ../adapters/window_info.ahk
#Include ../adapters/uia_worker.ahk
#Include ../adapters/tray_menu.ahk
#Include ../adapters/text_sender.ahk
#Include ../adapters/http_client.ahk
#Include ../adapters/secure_field_detector.ahk
#Include ../adapters/clipboard.ahk
#Include ../infra/input_probe.ahk
#Include ../adapters/storage.ahk
#Include ../adapters/process_lifecycle.ahk
#Include ../adapters/key_state.ahk
#Include ../adapters/keyboard_layout_switch.ahk
#Include ../adapters/app_launcher.ahk
#Include ../adapters/crypto.ahk
#Include ../adapters/network_info.ahk
#Include ../adapters/window_manager.ahk
#Include ../adapters/system_control.ahk
#Include ../adapters/mouse_control.ahk
#Include ../adapters/graphics_renderer.ahk
#Include ../ui/spotlight/ownership.ahk
#Include ../adapters/shell_runner.ahk
#Include ../../_shared/modules/actions/brightness.ahk
#Include ../adapters/screen_brightness.ahk
#Include ../adapters/crash_report_worker.ahk
#Include ../modules/diagnostics/crash_reporter.ahk
#Include ../infra/error_net.ahk
#Include ../modules/keymap/uia_selection_worker.ahk
; Contract tests must not launch a provider against the user's foreground app.
; Worker behavior is covered separately with explicit owned-process fixtures.
SFD_ConfigureUiaWorker(
	(Context, Terminal) => false, () => false, UIASW_ContextMatches)
; Unified input-hook dispatcher + keyboard_hook adapter. hook_dispatcher.ahk
; defines only classes at top level (no hotkeys), so it is safe in the headless
; runner; keyboard_hook.ahk registers/unregisters its subscribers through it.
; Exercised by test_hook_dispatcher.ahk (BoundFunc identity + bind-once contract).
#Include ../infra/hook_dispatcher.ahk
; CapsWord auto-off listeners: definitions only (capsword.ahk, with its
; hotkeys, stays out of the runner; the stubs stand in for DisableCapsWord).
#Include ../modules/shortcuts/capsword_auto_off.ahk
#Include ../infra/capsword_state.ahk
#Include ../adapters/keyboard_hook.ahk
#Include ../ui/editors.ahk

; Lock _AHK_SendText / _AHK_SendInput to no-ops AFTER the adapter has been
; included (the adapter sets them to real lambdas; InstallSendNoOps overwrites
; them so no keystroke can escape into the OS during test execution).
InstallSendNoOps()

; ── Per-module test files (each registers Test() cases) ──
#Include unit/adapters/test_adapter_compliance.ahk
#Include unit/infra/config/persistence/test_feature_io_locator.ahk
#Include meta/infra/config/persistence/test_feature_io_impl_no_global.ahk
#Include meta/suite/test_isset_no_property_arg.ahk
#Include unit/adapters/test_adapter_contract_vectors.ahk
#Include unit/adapters/test_adapter_contract_vectors_system.ahk
#Include unit/adapters/input/test_clipboard_paste_transaction_ownership.ahk
#Include unit/adapters/input/test_suppressive_inputhook_ownership.ahk
; Runs startup/siho_boot_window_smoke.ahk as a child process. That harness is
; deliberately NOT included here: it must observe the state before the module's
; own include executes, which is unreachable inside this runner, and its
; top-level ExitApp would end the suite.
#Include unit/infra/lifecycle/test_siho_boot_window.ahk
#Include unit/ui/windows/test_window_manager_force_foreground.ahk
#Include unit/ui/windows/test_window_manager_present_window.ahk
#Include unit/ui/windows/test_native_dialog_titles.ahk
#Include unit/ui/windows/test_native_file_filter_behavior.ahk
#Include unit/ui/windows/test_native_folder_orchestration.ahk
#Include unit/ui/windows/test_native_file_filter_diagnostics.ahk
#Include unit/adapters/test_console_window.ahk
#Include unit/adapters/test_keyboard_layout_switch.ahk
#Include unit/adapters/test_app_launcher_native_targets.ahk
#Include unit/ui/windows/test_spotlight_ownership.ahk
#Include unit/modules/gestures/test_take_note_async_job.ahk
#Include unit/adapters/input/test_text_sender_modifiers.ahk
#Include unit/infra/dispatch/test_timer_scheduler.ahk
#Include unit/ui/menu/test_tray_pause_greys_features.ahk
#Include unit/infra/dispatch/test_hook_dispatcher.ahk
#Include unit/adapters/input/test_own_injection_is_not_activity.ahk
#Include unit/infra/logger/test_logger.ahk
#Include unit/infra/logger/test_logger_shutdown_sinks.ahk
#Include unit/infra/dispatch/test_wall_clock_snapshot.ahk
#Include unit/platform/network/test_promise_timeout_budget.ahk
#Include unit/infra/logger/test_logger_format_failure_is_visible.ahk
#Include unit/infra/logger/test_logger_contract.ahk
#Include unit/ui/healthcheck/test_diagnostic_logging.ahk
#Include unit/infra/lifecycle/test_build_commit.ahk
#Include unit/modules/updater/test_version_display_strips_build_metadata.ahk
#Include unit/infra/logger/test_logger_daily_rotation.ahk
; The logs-folder resolver and the Debug menu log openers built on it
; (logs-dir-resolver). log_openers.ahk is definitions only.
#Include ../ui/log_openers.ahk
#Include unit/infra/logger/test_logs_dir_resolver.ahk
#Include meta/infra/logger/test_logs_dir_single_resolver.ahk
; The folders editor host: definitions only until a window is opened; its
; initData builder and logs-folder save are exercised headlessly.
#Include ../ui/paths_editor/init.ahk
#Include unit/ui/windows/test_paths_editor_logs_dir.ahk
#Include unit/ui/healthcheck/test_healthcheck_core.ahk
#Include unit/ui/healthcheck/test_healthcheck_configuration.ahk
#Include unit/ui/healthcheck/test_diagnostics_collection.ahk
#Include unit/ui/healthcheck/test_diagnostics_window_control.ahk
#Include unit/ui/healthcheck/test_healthcheck_owner_snapshots.ahk
#Include unit/infra/input_probe/test_input_probe.ahk
#Include unit/ui/tooltip/test_tooltip_tint_contract.ahk
#Include unit/ui/tooltip/test_tooltip_border_alpha.ahk
#Include unit/ui/tooltip/test_tooltip_border_pool.ahk
#Include unit/ui/tooltip/test_tooltip_border_zorder.ahk
#Include unit/ui/tooltip/test_tooltip_border_ring_region.ahk
#Include unit/ui/tooltip/test_tooltip_latency_diagnostics.ahk
#Include unit/ui/tooltip/test_tooltip_border_gdi_ownership.ahk
#Include unit/ui/tooltip/test_tooltip_measure_gdi_ownership.ahk
#Include unit/ui/tooltip/test_tooltip_dequeue_regression.ahk
#Include unit/ui/tooltip/test_tooltip_dequeue_contract.ahk
#Include unit/ui/tooltip/test_tooltip_position_cache_receipt.ahk
#Include unit/ui/tooltip/test_tooltip_position_refinement.ahk
#Include unit/modules/llm/tooltip/test_llm_tooltip_grace.ahk
#Include unit/modules/llm/tooltip/test_llm_tooltip_render.ahk
#Include unit/modules/llm/tooltip/test_llm_tooltip_layout.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_engine.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_engine_main.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_engine_match.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_engine_expansion.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_engine_input_generations.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_buffer_boundaries.ahk
#Include unit/adapters/input/test_suppress_refcount.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_live_toggle.ahk
#Include unit/modules/hotstrings/catalogue/test_live_rebuild_serialization.ahk
#Include unit/ui/menu/test_tray_root_coordinator.ahk
#Include unit/modules/hotstrings/engine/test_terminal_hotstring_pacing.ahk
#Include unit/modules/hotstrings/engine/test_terminal_hotstring_transaction_owner.ahk
#Include unit/modules/hotstrings/engine/test_output_host_resolver_independent_of_metrics.ahk
#Include unit/modules/gestures/test_gesture_modifier_release_ownership.ahk
#Include unit/modules/gestures/test_gesture_unhook_ownership.ahk
#Include unit/ui/menu/test_tray_root_lifecycle_retained.ahk
#Include unit/ui/menu/test_tray_bootstrap_publication_transaction.ahk
#Include unit/infra/lifecycle/test_boot_menu_wait_clock.ahk
#Include unit/modules/llm/menu/test_llm_menu_build_coordinator.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstring_count_policy.ahk
#Include unit/modules/hotstrings/prefix/test_prefix_watcher_index.ahk
#Include unit/modules/hotstrings/prefix/test_prefix_visible_suggestion_epoch.ahk
#Include unit/modules/hotstrings/preview/test_preview_index_covers_every_registration.ahk
#Include unit/modules/hotstrings/preview/test_preview_defers_to_engine.ahk
#Include unit/modules/hotstrings/preview/test_no_repeat_preview.ahk
#Include unit/modules/hotstrings/preview/test_hotstring_preview_shows.ahk
#Include unit/modules/hotstrings/prefix/test_prefix_index_cache_equiv.ahk
#Include unit/modules/hotstrings/personal/test_personal_info_mask_vectors.ahk
#Include unit/modules/hotstrings/personal/test_personal_info_tags_single_source.ahk
#Include unit/modules/hotstrings/preview/test_preview_provider_at_triggers.ahk
; The fire-time @-combo resolver that replaced the hand-written list of
; thirty-one registrations. It lives in hotstring_engine_main.ahk (loaded above)
; and reads only globals, so the tests drive the REAL function against fixture
; personal-info maps rather than asserting on its source.
#Include unit/modules/hotstrings/personal/test_personal_info_combo_resolver.ahk
#Include unit/infra/config/persistence/test_master_gates.ahk
#Include unit/modules/hotstrings/engine/test_domain_registry.ahk
#Include unit/modules/hotstrings/engine/test_domain_expander.ahk
#Include unit/infra/toml/test_toml_loader.ahk
#Include unit/infra/toml/test_toml_helpers_roundtrip.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstrings_cache.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstring_language_packs.ahk
#Include unit/ui/menu/test_menu_languages_and_global_separator.ahk
#Include unit/ui/menu/test_caps_word_auto_off_submenu.ahk
#Include unit/modules/dynamic_hotstrings/test_dynamic_hotstrings_module.ahk
#Include unit/modules/hotstrings/personal/test_user_hotstrings.ahk
#Include unit/modules/hotstrings/personal/test_user_hotstrings_native.ahk
#Include unit/modules/hotstrings/personal/test_user_hotstrings_pid_publication.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstrings_config.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstrings_config_delimiters.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstring_delimiter_global_transaction.ahk
#Include unit/modules/hotstrings/catalogue/test_word_expander_commands.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstring_override_global_transaction.ahk
#Include unit/modules/hotstrings/catalogue/test_terminators.ahk
#Include unit/modules/hotstrings/catalogue/test_terminator_records.ahk
#Include unit/modules/hotstrings/catalogue/test_terminator_builtin_state.ahk
#Include unit/modules/hotstrings/catalogue/test_terminator_admission.ahk
#Include unit/modules/hotstrings/personal/test_personal_toml_editor.ahk
#Include unit/ui/menu/test_menu_helpers.ahk
#Include unit/ui/menu/test_manifest_menu_resolve_disabled_when_failclosed.ahk
#Include unit/ui/menu/test_manifest_menu_declarations_are_read.ahk
#Include unit/ui/menu/test_manifest_menu_declared_groups.ahk
#Include unit/ui/menu/test_manifest_menu_captions.ahk
#Include unit/ui/menu/test_manifest_menu_parent_groups.ahk
#Include unit/infra/i18n/test_language_deferred_declared_parent.ahk
#Include unit/ui/menu/test_manifest_menu_checked_when.ahk
#Include unit/modules/keymap/test_layout_tables.ahk
#Include unit/modules/shortcuts/test_uia_selection_worker_deadline.ahk
#Include unit/adapters/uia/test_uia_worker_cleanup_debt.ahk
#Include unit/adapters/uia/test_uia_worker_exit_reentry.ahk
#Include unit/adapters/uia/test_secure_field_worker_context.ahk

#Include unit/infra/config/persistence/test_config.ahk
#Include unit/infra/config/persistence/test_feature_state_boot.ahk
#Include unit/ui/wpm/test_wpm_config_types.ahk
#Include ../ui/wpm/wpm_gdiplus_ownership.ahk
#Include ../ui/wpm/wpm_widget.ahk
#Include unit/ui/wpm/test_wpm_gdiplus_ownership.ahk
#Include unit/ui/wpm/test_wpm_drag_admission.ahk
#Include unit/ui/wpm/test_wpm_canon.ahk
#Include unit/infra/config/persistence/test_features_manifest.ahk
#Include unit/infra/config/persistence/test_apply_config_toml.ahk
#Include unit/infra/config/persistence/test_config_semantic_snapshot.ahk
#Include unit/infra/config/persistence/test_config_snapshot_inline_records.ahk
#Include unit/infra/config/persistence/test_config_snapshot_obsolete_parent.ahk
#Include unit/infra/config/persistence/test_neutral_config_manifest.ahk
#Include unit/test_config_scope_manifest.ahk
#Include unit/infra/config/scope/test_config_scope_menus.ahk
#Include unit/infra/config/scope/test_config_scope_shortcuts.ahk
#Include unit/modules/shortcuts/test_shortcuts_restore_row.ahk
#Include unit/ui/menu/test_script_control_submenu.ahk
#Include unit/modules/hotstrings/personal/test_personal_shortcut_neutral_seed.ahk
#Include unit/infra/config/scope/test_hotstrings_scope.ahk
#Include unit/modules/hotstrings/personal/test_personal_file_controls.ahk
#Include unit/infra/config/scope/test_hotstring_delimiter_scope_preservation.ahk
#Include unit/infra/config/scope/test_hotstring_category_scope.ahk
#Include unit/infra/config/scope/test_hotstring_dynamic_menu_scope.ahk
#Include unit/infra/config/scope/test_personal_editor_menu_scope.ahk
#Include unit/infra/config/scope/test_personal_frame_native.ahk
#Include unit/infra/config/scope/test_personal_file_captions.ahk
#Include unit/infra/config/scope/test_global_config_scope.ahk
#Include unit/modules/gestures/test_gesture_clear_boot_marker.ahk
#Include unit/infra/config/scope/test_tap_hold_scope.ahk
#Include unit/infra/config/scope/test_restore_recommended_no_confirm.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_hand_sections.ahk
#Include unit/infra/config/persistence/test_config_io_feature_section_resolution.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstrings_full.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstring_handler.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstrings_end_to_end.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_loader.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_overlay_and_modifiers.ahk
#Include unit/infra/i18n/test_i18n.ahk
#Include unit/infra/i18n/test_locale_probe_is_silent.ahk
#Include unit/adapters/test_window_utils.ahk
#Include unit/infra/test_external_url_policy.ahk
#Include unit/infra/test_text_utils.ahk
#Include unit/adapters/test_registry.ahk
#Include unit/modules/hotstrings/personal/test_personal_toml_io.ahk
#Include unit/modules/hotstrings/personal/test_personal_info_persistence_transaction.ahk
#Include unit/platform/remap/layers/test_nav_layer_helpers.ahk
#Include unit/platform/remap/layers/test_nav_layer_table.ahk
#Include unit/modules/keymap/test_layer_editor_host.ahk
#Include unit/modules/hotstrings/engine/test_synthetic_buffer_effects.ahk
#Include unit/modules/hotstrings/prefix/test_prefix_finalizer_generation.ahk
#Include unit/modules/hotstrings/engine/test_synthetic_sends_declare_buffer_effect.ahk
#Include unit/platform/remap/keys/test_capsword_taphold_unlatch.ahk
#Include unit/modules/shortcuts/test_caps_word_auto_off_policy.ahk
#Include unit/modules/shortcuts/test_capsword_auto_off.ahk
#Include unit/modules/shortcuts/test_capsword_state.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_suspend_boundary.ahk
#Include unit/test_updater.ahk
#Include unit/modules/updater/test_updater_release_fetch.ahk
#Include unit/modules/updater/test_updater_request_pause.ahk
#Include unit/modules/updater/test_updater_transport_ownership.ahk
#Include unit/modules/updater/test_updater_tray_root.ahk
#Include unit/modules/updater/test_updater_install_deadlines.ahk
#Include unit/modules/updater/test_updater_channel_bundle.ahk
#Include unit/modules/updater/test_asset_signature.ahk
#Include unit/modules/updater/test_updater_managed_failure.ahk
#Include unit/modules/updater/test_release_install.ahk
#Include unit/infra/lifecycle/test_uninstall.ahk
#Include unit/infra/lifecycle/test_uninstall_source_run.ahk
#Include unit/infra/lifecycle/test_start_at_login.ahk
#Include unit/infra/lifecycle/test_start_at_login_other_source.ahk
#Include meta/infra/lifecycle/test_uninstall_shutdown_gate.ahk
#Include unit/modules/updater/test_updater_channel_registry.ahk
#Include unit/modules/updater/test_updater_schedule_vectors.ahk
#Include unit/modules/updater/test_version_label_vectors.ahk
#Include unit/modules/updater/test_updater_check_interval_snap.ahk
#Include unit/modules/updater/test_updater_check_schedule.ahk
#Include unit/modules/updater/test_updater_balloon_click_ownership.ahk
#Include unit/modules/updater/test_updater_channel_selection.ahk
#Include unit/modules/updater/test_updater_release_list_budget.ahk
; The About row actions; menu_init.ahk is included with the tray root below.
#Include ../ui/menu/menu_actions.ahk
#Include unit/modules/updater/test_about_menu_channel_rows.ahk
#Include unit/modules/updater/test_about_menu_version_row.ahk
#Include unit/modules/updater/test_changelog_subscribe_channel.ahk
#Include unit/modules/updater/test_updater_release_notes.ahk
#Include unit/modules/updater/test_updater_staging_transport.ahk
#Include unit/modules/updater/test_updater_swap_transaction.ahk
#Include unit/modules/updater/test_updater_swap_cancellation.ahk
#Include unit/modules/updater/test_updater_swap_shutdown.ahk
#Include unit/modules/updater/test_updater_swap_recovery.ahk
#Include unit/modules/updater/test_updater_swap_cleanup.ahk
#Include unit/modules/gestures/test_gesture_emit_actions.ahk
#Include unit/modules/updater/test_updater_constants_single_source.ahk
#Include unit/infra/lifecycle/test_runtime_contract_version.ahk
#Include meta/modules/updater/test_updater_load_interval_guard.ahk

; Shortcuts modules — dispatcher logic is testable without real hotkeys firing;
; the module files are #Include'd from within test_shortcuts.ahk itself so the
; include paths are resolved relative to the tests/ directory.
#Include unit/modules/shortcuts/test_shortcuts.ahk
#Include unit/modules/shortcuts/test_open_target_vectors.ahk
#Include unit/modules/shortcuts/test_keepawake_visible_cancellation.ahk
#Include unit/suite/test_runner_shard.ahk

; Metrics boolean preferences retain their existing transaction owner; ordinary
; chord syntax tests use the shared parser and registrar without binding hotkeys.
#Include ../infra/app_picker.ahk
#Include ../infra/config_shortcuts.ahk
#Include ../infra/metrics/metrics_filters.ahk
#Include ../infra/metrics/metrics_shortcuts.ahk
#Include ../ui/menu/menu_metrics.ahk
#Include ../ui/menu/menu_metrics_actions.ahk
#Include unit/modules/keystats/metrics/test_metrics_shortcut_named_key.ahk
#Include unit/infra/config/persistence/test_config_shortcuts_types.ahk
#Include unit/modules/keystats/metrics/test_metrics_preferences_global_barrier.ahk

; LLM modules — pure-logic subset (profiles, models, api_common, api_ollama,
; api_remote, prediction_engine) included here to test JSON parsing, profile
; lookup, payload building, response parsing, cancel helpers, and engine
; debounce / cache logic without any real network calls.
; models.ahk defines LLM_GetSharedPath which profiles.ahk depends on.
_LogBootProgress("loading LLM modules")
#Include ../modules/llm/models.ahk
#Include ../infra/llm_defaults.ahk
; llm_profiles_data.ahk (generated) defines LLM_LEGACY_IDS + LLM_GetBasicPrompt()
; which profiles.ahk depends on — see the LLM legacy/basic-prompt single-source tests.
#Include ../_generated/llm_profiles_data.ahk
#Include ../modules/llm/profiles.ahk
#Include unit/modules/llm/profiles/test_llm_profiles.ahk
#Include ../modules/llm/api_common.ahk
#Include ../modules/llm/api_token_crypto.ahk
#Include unit/modules/llm/api/test_llm_api_common.ahk
#Include ../modules/llm/ollama_install_files_port.ahk
#Include ../modules/llm/ollama_runtime_owner.ahk
#Include ../modules/llm/ollama_deps_checker.ahk
; Preserve the prior ready test baseline while receiving the real state getter.
_LLM_Deps_State := "ready"
#Include ../modules/llm/api_ollama.ahk
#Include ../modules/llm/remote_formats.ahk
#Include ..\..\_shared\modules\llm\local_server_auth.ahk
#Include ..\..\_shared\modules\llm\local_server_discovery.ahk
#Include ../../_shared/modules/llm/local_server_menu.ahk
#Include ../modules/llm/api_remote.ahk
#Include ../modules/llm/local_server_models.ahk
#Include ../modules/llm/local_servers.ahk
#Include unit/modules/llm/api/test_llm_api_ollama.ahk
#Include unit/modules/llm/api/test_llm_api_ollama_streaming.ahk
#Include unit/modules/llm/api/test_llm_api_ollama_curl_personal_config.ahk
#Include unit/modules/llm/api/test_llm_provider_error_prefix.ahk
#Include unit/modules/llm/api/test_llm_api_ollama_local_presence.ahk
#Include unit/modules/llm/api/test_llm_api_ollama_warmup.ahk
#Include unit/modules/llm/prediction/test_llm_engine_read_guarded_in_timer.ahk
#Include unit/modules/llm/api/test_llm_api_remote.ahk
#Include unit/modules/llm/api/test_llm_api_remote_async_registry.ahk
#Include unit/modules/llm/api/test_llm_api_remote_requests.ahk
#Include unit/platform/network/test_managed_curl_owner.ahk
#Include unit/platform/network/test_managed_curl_empty_header.ahk
#Include unit/platform/network/test_http_post_replacement_validation.ahk
#Include unit/platform/network/test_managed_curl_callers.ahk
#Include unit/modules/llm/servers/test_local_server_auth.ahk
#Include unit/modules/llm/servers/test_local_server_discovery_policy.ahk
#Include unit/modules/llm/servers/test_local_server_models.ahk
#Include unit/modules/llm/servers/test_local_server_models_timer.ahk
#Include unit/modules/llm/servers/test_local_server_menu.ahk
#Include unit/modules/llm/servers/test_local_servers.ahk
#Include unit/modules/llm/servers/test_local_server_queue_timer.ahk
#Include unit/modules/llm/servers/test_llm_crash_orphan_cleanup.ahk
#Include unit/modules/llm/servers/test_llm_temp_artifact_terminal_ownership.ahk
#Include unit/adapters/test_filesystem_native_write.ahk
#Include unit/adapters/test_filesystem_nul_paths.ahk
#Include unit/adapters/test_process_lifecycle_app_events.ahk
#Include unit/infra/logger/test_logger_native_write.ahk
#Include unit/modules/keystats/test_keystats_sql_native_write.ahk
#Include unit/modules/keystats/test_keystats_sql_write_compensation.ahk
#Include unit/modules/keystats/test_keystats_journal_flush_retry.ahk
#Include unit/modules/keystats/test_keystats_journal_owner.ahk
#Include unit/modules/keystats/test_keystats_journal_owner_validation.ahk
#Include unit/modules/keystats/test_keystats_journal_scope.ahk
#Include unit/modules/keystats/test_keystats_journal_native_write.ahk
#Include unit/modules/keystats/test_keystats_journal_encoding.ahk
#Include unit/modules/keystats/test_keystats_journal_tail.ahk
#Include unit/modules/keystats/test_keystats_journal_short_write.ahk
#Include meta/modules/keystats/test_keystats_journal_lifecycle_owner.ahk
#Include unit/modules/keystats/test_keystats_journal_repair_debt.ahk
#Include unit/modules/llm/api/test_llm_aux_request_ownership.ahk
#Include unit/modules/llm/api/test_llm_api_test_entry.ahk
#Include unit/modules/llm/api/test_llm_api_entry_names.ahk
#Include unit/modules/llm/menu/test_llm_menu_backend_model_labels.ahk
#Include unit/modules/llm/menu/test_llm_menu_model_hardware.ahk
#Include unit/modules/llm/menu/test_llm_menu_backend_child.ahk
#Include unit/modules/llm/menu/test_llm_menu_model_parent.ahk
#Include unit/modules/llm/menu/test_llm_menu_build_submenu.ahk
#Include unit/modules/llm/menu/test_llm_menu_prediction_count.ahk
#Include unit/modules/llm/servers/test_llm_curl_terminal_classification.ahk
#Include unit/modules/llm/servers/test_llm_curl_literal_paths.ahk
#Include unit/modules/llm/servers/test_ollama_http_terminal_classification.ahk
#Include unit/modules/llm/servers/test_remote_curl_terminal_classification.ahk
; Remote catalogue load must fall back gracefully when api_providers.json is missing/malformed.
#Include meta/modules/llm/servers/test_remote_catalog_load_graceful.ahk
#Include ../modules/llm/option_validation.ahk
#Include ../modules/llm/rewrite.ahk
#Include ../modules/llm/prompt_action.ahk
#Include ../modules/llm/tone.ahk
#Include ../modules/llm/tone_action.ahk
#Include ../modules/llm/vision.ahk
#Include ../modules/llm/vision_action.ahk
#Include ../modules/llm/translate.ahk
#Include ../modules/llm/translate_action.ahk
#Include ../modules/llm/agent.ahk
#Include ../modules/llm/agent_connectors.ahk
#Include ../modules/llm/agent_action.ahk
#Include ../modules/llm/prediction_engine.ahk
#Include unit/modules/llm/prediction/test_llm_prediction_engine.ahk
#Include unit/modules/llm/prediction/test_llm_prediction_engine_state.ahk
#Include unit/modules/llm/prediction/test_llm_prediction_engine_pointer_dismiss.ahk
#Include unit/modules/llm/api/test_llm_semantic_config_identity.ahk
#Include unit/modules/llm/api/test_llm_semantic_config_budget.ahk
#Include unit/modules/llm/api/test_llm_defaults.ahk
; llm_bridge.ahk is needed by the canonical HSE -> LLM effect behaviour tests.
#Include ../modules/keymap/llm_bridge.ahk
#Include unit/modules/llm/prediction/test_llm_bridge_apply_expansion.ahk
#Include unit/modules/hotstrings/prefix/test_prefix_char_admission.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_idle_click_reset.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_event_word_reset.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_backspace_word_start.ahk
#Include unit/modules/llm/prediction/test_llm_bridge_buffer_cap.ahk
#Include unit/modules/llm/navigation/test_llm_pointer_watch_transaction.ahk
#Include unit/modules/llm/navigation/test_llm_tab_accept_policy.ahk
#Include unit/modules/llm/navigation/test_llm_accept_injects_exact_text.ahk
#Include unit/modules/shortcuts/test_accented_shortcuts.ahk
#Include unit/modules/keymap/test_keylayout_emulation.ahk
#Include unit/modules/keymap/test_keylayout_altgr_characterization.ahk
#Include unit/modules/keymap/test_keylayout_canonical_source.ahk
#Include unit/modules/hotstrings/magic_key/test_magic_key_source_menu.ahk
#Include unit/modules/hotstrings/magic_key/test_magic_key_source_hotkeys.ahk
#Include unit/modules/keymap/test_layout_catalogue.ahk
#Include unit/modules/keymap/test_layout_installed_record_corpora.ahk
#Include unit/modules/keymap/test_layout_extension_runtime.ahk
#Include unit/modules/keymap/test_layout_extension_menu.ahk
#Include unit/modules/keymap/test_layout_extension_refresh.ahk
#Include unit/modules/hotstrings/catalogue/test_ergopti_extension_hotstrings.ahk
#Include ../ui/layout_manager/init.ahk
#Include ../ui/layout_manager/composer.ahk
#Include ../ui/layout_manager/composer_check.ahk
#Include ../ui/field_check/network_check.ahk
#Include ../ui/menu/menu_layout.ahk
#Include unit/modules/keymap/test_layout_manager_host.ahk
#Include unit/modules/keymap/test_layout_composer_host.ahk
#Include unit/modules/keymap/test_layout_composer_check.ahk
#Include unit/ui/field_check/test_network_check.ahk
#Include unit/modules/keymap/test_ergopti_keylayout_tables.ahk
#Include unit/modules/keymap/test_layout_supersession.ahk
; parser.ahk (the AHK semantic-diff parser) was previously exercised by no suite,
; which let a crash in its Levenshtein helper survive — include it + its tests.
#Include ../modules/llm/parser.ahk
#Include unit/modules/llm/prediction/test_llm_parser.ahk
#Include meta/modules/llm/prediction/test_llm_batch_dedup_stats.ahk
; Non-blocking installed-tags cache contract + behaviour (menu-build-sync-api-tags-freeze).
; Behavioural cases call the real models.ahk cache funcs included just above.
#Include meta/modules/llm/api/test_llm_installed_tags_async.ahk
; Any input (type/click/move) cancels in-progress generation (llm-spinner-lingers-through-input).
#Include meta/modules/llm/navigation/test_llm_input_cancels_generation.ahk
; Ollama reachability probe is non-blocking curl, not WinHTTP (ollama-reachability-winhttp-connect-blocks).
#Include meta/modules/llm/servers/test_ollama_reachability_async_nonblocking.ahk
; Orphan temp-file sweep is bounded + off the Critical dispatch path (llm-orphan-sweep-temp-recursion).
#Include meta/modules/llm/prediction/test_llm_orphan_sweep_nonblocking.ahk
; The coordinator serializes detached LLM menu builds and retains re-entrant work.
#Include meta/modules/llm/tooltip/test_llm_markchain_no_rerender.ahk
#Include meta/modules/llm/menu/test_llm_menu_build_critical.ahk
#Include meta/modules/llm/menu/test_llm_menu_build_coordinator.ahk
#Include meta/modules/llm/menu/test_llm_menu_caller_child_full_root.ahk
_LogBootProgress("LLM modules + tests included")

; LLM tray menu -> config.toml persistence (contract-driven round-trips).
global _LLM_Menu := Map(
	"enabled", true, "backend", "ollama", "model", "Qwen3.5-0.8B",
	"profile_id", "basic", "n_predictions", 3, "auto_profile_for_model", true,
	"min_words", 3, "max_words", 15, "language", "fr", "debounce_ms", 500,
	"ctx_chars", 500, "temperature", "0.10", "instant_on_word_end", true,
	"after_hotstring", true, "reset_on_nav", true, "disable_url_bars", true,
	"disable_password_fields", true, "disabled_apps", [], "show_info_bar", true,
	"streaming", true, "show_all_at_once", true, "pred_indent", 0,
	"auto_raise_temp", true, "nav_modifiers", "", "val_modifiers", "alt",
	"inline_autotype", false,
	"ollama_port", 11434
)
global _LLM_Menu_Loaded := false
; Definitions-only chord translation and hotkey identities; registers no hotkey.
#Include ../ui/menu/menu_llm/hotkey_identity.ahk
#Include ../adapters/llm_nav_event_owner.ahk
#Include ../adapters/terminal_output_preview.ahk
#Include ../adapters/terminal_output_custody.ahk
#Include ../adapters/llm_automation.ahk
#Include ../ui/menu/menu_llm/tab_accept.ahk
; Definitions-only boot restore helper. LLM_Menu_Init is never invoked by the
; harness; the regression suite calls only its one-shot saved-options seam.
#Include ../ui/menu/menu_llm/init.ahk
_LogBootProgress("loading menu_llm/persist")
#Include ../ui/menu/menu_llm/menu_models.ahk
#Include ../ui/menu/menu_llm/menu_profiles.ahk
#Include ../ui/menu/menu_llm/persist.ahk
#Include ../ui/menu/menu_llm/transactions.ahk
#Include ../ui/menu/menu_llm/backend_lifecycle.ahk
#Include ../ui/menu/menu_llm/aux_ownership.ahk
#Include ../ui/menu/menu_llm/menu_api_entries.ahk
#Include ../ui/menu/menu_llm/local_server_panel.ahk
#Include ../ui/menu/menu_llm/menu_main.ahk
#Include ../ui/menu/menu_llm/enable_admission.ahk
#Include ../ui/menu/menu_llm/actions.ahk
#Include ../ui/menu/menu_gestures.ahk
#Include ../infra/menu_dispatcher.ahk
#Include ../ui/menu/menu_llm/menu_settings.ahk
#Include ../ui/menu/menu_llm/menu_agent.ahk
#Include unit/modules/llm/api/test_llm_backend_lifecycle_dispatch.ahk
#Include unit/modules/llm/prediction/test_llm_generate_prediction_feedback.ahk
#Include unit/modules/llm/menu/test_llm_menu_persistence.ahk
#Include unit/modules/llm/api/test_llm_temperature_boundary.ahk
#Include unit/modules/llm/menu/test_llm_numeric_option_ranges.ahk
#Include unit/modules/llm/api/test_llm_sync_target.ahk
#Include unit/modules/llm/menu/test_llm_menu_transactions.ahk
#Include unit/modules/llm/menu/test_llm_api_entries_transactions.ahk
#Include unit/modules/llm/menu/test_llm_menu_display.ahk
#Include unit/modules/llm/menu/test_llm_menu_generation.ahk
#Include unit/modules/llm/menu/test_llm_menu_indentation.ahk
#Include unit/modules/llm/menu/test_llm_menu_privacy.ahk
#Include unit/modules/llm/menu/test_llm_menu_profiles.ahk
#Include unit/modules/llm/servers/test_local_server_private_publication.ahk
#Include unit/modules/llm/servers/test_local_server_publication_rollback.ahk
#Include unit/modules/llm/servers/test_local_server_receipt_entry.ahk
#Include unit/modules/llm/servers/test_local_server_source_operations.ahk
#Include unit/modules/llm/api/test_llm_api_add_production.ahk
#Include unit/modules/llm/servers/test_local_server_write_admission.ahk
#Include unit/modules/llm/servers/test_local_server_join.ahk
#Include unit/modules/llm/servers/test_local_server_scope_cohort.ahk
#Include unit/modules/llm/servers/test_local_server_panel.ahk
#Include unit/modules/llm/servers/test_local_server_panel_discovery.ahk
#Include unit/modules/llm/servers/test_local_server_panel_view_preparation.ahk
#Include unit/modules/llm/api/test_llm_enable_admission.ahk
#Include unit/modules/llm/menu/test_llm_menu_fixture_isolation.ahk
#Include unit/modules/llm/api/test_llm_fixture_setup.ahk
#Include unit/ui/windows/test_app_picker_generation.ahk
#Include meta/ui/windows/test_app_picker_generation_wiring.ahk
#Include unit/modules/llm/menu/test_llm_menu_locale_bridge.ahk
#Include meta/modules/llm/menu/test_llm_menu_locale_source.ahk
#Include unit/modules/llm/servers/test_llm_ollama_port_boundary.ahk
#Include meta/modules/llm/servers/test_llm_ollama_port_owner.ahk
#Include unit/modules/llm/menu/test_llm_menu_regressions.ahk
; The prompt-editor host is definitions-only until TryOpen is called. Load it so
; its deferred context fence can be exercised without creating a Gui/WebView.
#Include ../ui/prompt_editor/init.ahk
#Include unit/modules/llm/profiles/test_prompt_editor_context_epoch.ahk
; Changelog host is likewise definitions-only until Changelog_Open is called.
; Load it so the request/window epoch can be exercised with deterministic fakes.
#Include ../ui/changelog/init.ahk
_LogBootProgress("menu_llm persist + tests included")

; Gestures module — included here because its pure logic (assignments, action
; registry, dispatch) is testable. The hotkeys it registers are harmless since
; RunTests() calls ExitApp immediately after completion.
_LogBootProgress("loading gestures modules")
#Include ../modules/take_note.ahk
#Include ../_generated/touchpad_registry.ahk
#Include ../modules/gestures/touchpad_registry.ahk
#Include ../modules/gestures/init.ahk
#Include ../modules/gestures/click.ahk
#Include ../modules/gestures/screenshots.ahk
#Include ../modules/gestures/window_cycle.ahk
#Include ../modules/gestures/virtual_desktops.ahk
#Include ../modules/gestures/config.ahk
; Genuine gestures factory/registry and generated rows are already loaded.
; These source-image cases do not invoke actions or native output.
#Include ../../_shared/ahk/tap_hold/buffered_data_snapshot_owner.ahk
#Include unit/infra/test_buffered_data_snapshot_owner.ahk
; Load the definitions-only onboarding worker owner so its elevated-launch
; reservation can be exercised without constructing the wizard UI.
#Include ../ui/onboarding/gesture_registration.ahk
; The answers contract, the commit and the WebView host are definitions-only
; until _Onboarding_TryWeb is called. Include them so the finish payload is
; followed to the candidate config.toml without the persistence/reload boundary.
#Include ../ui/onboarding/translate.ahk
#Include ../ui/onboarding/answers.ahk
#Include ../ui/onboarding/finish.ahk
#Include ../ui/onboarding/webview.ahk
#Include unit/adapters/crash_report/test_screenshot_worker_ownership.ahk
#Include unit/ui/onboarding/test_onboarding_finish_payload.ahk
#Include unit/ui/onboarding/test_onboarding_answers.ahk
#Include unit/ui/onboarding/test_onboarding_metrics_path.ahk
#Include unit/modules/gestures/test_gestures.ahk
#Include unit/modules/gestures/test_gesture_binding_identity.ahk
#Include unit/modules/gestures/test_gesture_menu_status.ahk
#Include unit/infra/config/persistence/test_config_keyboard_binding_identity.ahk
#Include unit/modules/gestures/test_virtual_desktops.ahk
#Include unit/modules/shortcuts/test_text_case_vectors.ahk
#Include unit/modules/shortcuts/test_wrap_selection_action.ahk
#Include unit/modules/gestures/test_system_actions.ahk
#Include unit/modules/gestures/test_system_actions_confirmed_targets.ahk
#Include unit/modules/gestures/test_system_actions_query_pause.ahk
#Include unit/modules/gestures/test_system_actions_process_lease.ahk
#Include unit/adapters/test_screen_brightness.ahk
#Include unit/modules/llm/actions/test_llm_rewrite.ahk
#Include unit/modules/llm/actions/test_llm_prompt_action.ahk
#Include unit/modules/llm/prediction/test_llm_prompt_prediction.ahk
#Include unit/modules/llm/tooltip/test_llm_line_style.ahk
#Include unit/modules/llm/actions/test_llm_tone.ahk
#Include unit/modules/llm/actions/test_llm_vision.ahk
#Include unit/modules/llm/actions/test_llm_translate.ahk
#Include unit/modules/llm/actions/test_llm_agent.ahk
#Include unit/modules/llm/actions/test_llm_agent_connectors.ahk
#Include unit/modules/llm/actions/test_llm_agent_ai_off.ahk
#Include unit/modules/llm/actions/test_llm_agent_system_menu.ahk
#Include unit/modules/llm/actions/test_llm_agent_requester.ahk
#Include unit/modules/llm/api/test_llm_remote_formats.ahk
#Include unit/modules/llm/prediction/test_llm_live_mode.ahk
#Include unit/modules/shortcuts/test_send_input_actions.ahk
#Include unit/platform/remap/keys/test_tap_keys.ahk
#Include unit/platform/remap/key_combinations/test_key_combinations.ahk
#Include unit/modules/gestures/test_gesture_cycle_candidates.ahk
#Include unit/modules/gestures/test_gesture_recommended_actions.ahk
#Include unit/infra/config/persistence/test_config_persistence_transactions.ahk
#Include unit/infra/config/persistence/test_config_suspend_marker_handoff.ahk
#Include unit/infra/lifecycle/test_reload_terminal_pending.ahk
#Include unit/infra/lifecycle/test_reload_successor_quiescence.ahk
#Include unit/infra/lifecycle/test_reload_worker_identity.ahk
#Include unit/infra/lifecycle/test_reload_deferral.ahk
#Include unit/ui/menu/test_tray_menu_separator_popup.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_hold_picker_options.ahk
#Include unit/ui/menu/test_menu_command_deferral.ahk
#Include unit/ui/menu/test_menu_reload_replay.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_roll.ahk
#Include unit/infra/config/persistence/test_config_recovery_transactions.ahk
#Include unit/infra/config/persistence/test_config_commit_gateway.ahk
#Include unit/infra/config/persistence/test_config_typed_updates.ahk
#Include unit/infra/config/persistence/test_config_typed_transactions.ahk
#Include unit/infra/config/persistence/test_config_unused_keys.ahk
#Include unit/infra/config/persistence/test_config_cleanup_retired_entries.ahk
#Include unit/infra/config/persistence/test_config_cleanup_retired_root.ahk
#Include unit/infra/config/persistence/test_config_cleanup_retired_bindings.ahk
#Include unit/infra/config/migration/test_config_migrate.ahk
#Include unit/infra/config/migration/test_config_migrate_variant_metadata.ahk
#Include unit/infra/config/migration/test_config_journal_boot.ahk
#Include unit/infra/config/migration/test_config_journal_ai_admission.ahk
#Include unit/infra/config/migration/test_config_journal_settlement.ahk
#Include unit/infra/config/migration/test_config_journal_nul_suffix.ahk
#Include unit/infra/config/persistence/test_config_partial_load_persistence.ahk
#Include unit/infra/config/persistence/test_config_partial_load_llm.ahk
#Include unit/infra/toml/test_toml_numeric_strings.ahk
#Include unit/infra/toml/test_toml_array_element_types.ahk
#Include unit/infra/toml/test_toml_inline_tables.ahk
#Include unit/infra/toml/test_toml_nested_arrays.ahk
#Include unit/infra/toml/test_toml_float_roundtrip.ahk
#Include unit/infra/toml/test_toml_incomplete_write.ahk
#Include unit/infra/toml/test_toml_stage_cleanup.ahk
#Include unit/infra/config/persistence/test_config_typed_producers.ahk
#Include unit/modules/keystats/metrics/test_metrics_delivery_owner.ahk
#Include unit/modules/keystats/metrics/test_metrics_cached_ready.ahk
#Include unit/modules/keystats/metrics/test_metrics_warm_sidecar.ahk
#Include unit/modules/keystats/metrics/test_metrics_edge_sidecar.ahk
#Include unit/modules/keystats/metrics/test_metrics_store_isolation.ahk
#Include unit/modules/keystats/metrics/test_metrics_store_publication.ahk
#Include unit/modules/keystats/metrics/test_metrics_store_edge.ahk
#Include unit/modules/keystats/metrics/test_metrics_store_projection.ahk
#Include unit/ui/webview/test_webview_script_outcomes.ahk
#Include unit/ui/webview/test_webview_range_outcomes.ahk
#Include unit/ui/webview/test_webview_range_stage_owner.ahk
#Include unit/ui/webview/test_webview_range_cleanup_reentry.ahk
#Include unit/ui/webview/test_webview_range_mount.ahk
#Include unit/ui/webview/test_webview_profile_ownership.ahk
#Include unit/modules/keystats/metrics/test_metrics_file_urls.ahk
#Include unit/infra/toml/test_uridecode_literal_unicode.ahk
#Include meta/ui/webview/test_webview_script_observer.ahk
#Include unit/modules/keystats/metrics/test_metrics_retry_outcomes.ahk
#Include meta/infra/config/persistence/test_config_typed_foreign_producers.ahk
#Include unit/infra/config/transition/test_config_transition_core.ahk
#Include unit/infra/config/transition/test_config_transition_quarantine.ahk
#Include unit/infra/config/transition/test_config_transition_runtime.ahk
#Include unit/infra/config/transition/test_config_transition_windows_port.ahk
#Include unit/infra/config/transition/test_config_transition_temporal_custody.ahk
#Include unit/infra/toml/test_toml_build_updated_content.ahk
#Include unit/infra/toml/test_toml_writer_admission.ahk
#Include unit/infra/toml/test_toml_table_array_writer.ahk
#Include unit/infra/config/persistence/test_config_full_save_generation.ahk
#Include unit/infra/config/persistence/test_config_full_save_terminal.ahk
#Include unit/infra/config/persistence/test_config_full_save_startup_intent.ahk
#Include unit/infra/config/persistence/test_config_full_save_durable_debt.ahk
#Include unit/infra/config/persistence/test_config_write_terminal_barrier.ahk
#Include unit/infra/config/persistence/test_feature_io_global_barrier.ahk
#Include unit/infra/config/persistence/test_editor_global_barrier_behavior.ahk
#Include unit/infra/lifecycle/test_runtime_decision_generation.ahk
#Include meta/ui/wpm/test_wpm_global_barrier_behavior.ahk
#Include unit/modules/gestures/test_gesture_restart_result_zero_is_success.ahk
#Include unit/modules/gestures/test_touchpad_registry.ahk
_LogBootProgress("gestures + test included")

; Keystats sub-modules — pure-logic subsets included here to test category
; lookup, character classification, and burst helpers without OS hooks or I/O.
; sqlite3.ahk needs _VendorDir (set by ErgoptiPlus.ahk at runtime); stub it
; here so the class static initialiser does not crash the test runner.
_LogBootProgress("loading keystats modules")
global _VendorDir := A_ScriptDir . "\..\vendor"
; keystats_prefetch.ahk normally receives this from infra/boot.ahk.  The
; headless runner loads only the pure worker protocol, so provide its explicit
; config-root dependency without executing the full driver boot sequence.
global _ConfigDir := A_Temp . "\ergopti_test_config\"
global _AhkSubDir := ""
#Include ../infra/sqlite3.ahk
#Include ../modules/keystats/keystats_walker.ahk
#Include ../modules/keystats/keystats_app_categories.ahk
#Include ../modules/keystats/keystats_reader.ahk
; ROI pruning is isolated from the hook-owning module so the exact production
; survivor and generation transactions can be exercised headlessly.
#Include ../modules/keystats/keystats_roi_prune.ahk
; Password-field classification is definitions-only. Load the real async cache
; writer so its fail-closed behaviour can be exercised with a fake UIA object.
#Include ../modules/keystats/keystats_password.ahk
; Atomic completion journaling is definitions-only. Load the production module
; against the Keystats/Metrics stubs so privacy-epoch and RAM-commit ordering
; are verified without arming the full keystats lifecycle.
#Include ../modules/keystats/keystats_llm_journal.ahk
; The prefetch worker contains no top-level I/O. Including it here enables a
; headless generation-fence test with a fake ShellRunner spawn handle.
#Include ../modules/keystats/keystats_prefetch.ahk
; Wi-Fi transition reduction is pure; the live timers are armed only by
; KL_Net_Start(), which the test runner never calls.
#Include ../modules/keystats/keystats_network.ahk
; Capture-state reduction is also definition-only. The process snapshot is
; invoked only by KL_AV_Start/KL_AV_ScanCapture, so tests can replace its seam
; without touching Win32 process enumeration.
#Include ../modules/keystats/keystats_av_state.ahk
; keystats_webview.ahk is likewise definitions-only at top level. Loading the
; real module lets terminal/retry tests drive the production state machines;
; no Gui, COM object, timer, or WebView is created until an explicit function
; call, and those tests replace the push/timer boundaries with local seams.
#Include ../modules/keystats/keystats_webview.ahk
; keystats_clipboard.ahk defines _KL_Clip_CharCountFromBuffer + KLClipConst,
; both exercised functionally by meta/adapters/input/test_clipboard_ram_leak.ahk. It contains
; only class + function definitions at top level (the Hotkey()/OnClipboardChange
; calls live inside KL_Clip_Start), so it is headless-safe. Without this include
; the test's direct call to _KL_Clip_CharCountFromByteSize is a load-time
; "nonexistent function" error that hangs the headless runner with no output.
#Include ../modules/keystats/keystats_clipboard.ahk
#Include unit/modules/keystats/test_keystats_clipboard_provenance.ahk
; keystats_json.ahk (KL_JsonEncode) and keystats_sql.ahk (KL_BuildInserts +
; the per-type KL_BuildInsertXxx builders) are pure definitions with no
; top-level hotkeys/OS hooks, so — like the walker sub-modules above — they
; are safe to load directly for unit coverage of the INSERT-statement
; builders (F19/F21: llm_*/av/network/clipboard/roi event types must not
; silently fall through KL_BuildInserts's switch).
#Include ../modules/keystats/keystats_json.ahk
#Include unit/modules/keystats/test_keystats_json_roundtrip.ahk
#Include ../modules/keystats/keystats_journal.ahk
#Include ../modules/keystats/keystats_shutdown.ahk
#Include unit/modules/keystats/test_keystats_shutdown_timers.ahk
; Event-ID recovery is a pure module extracted from keystats.ahk so its real
; tail parser can be exercised without loading the OS-hooking entry module.
#Include ../modules/keystats/keystats_event_id.ahk
#Include unit/modules/keystats/test_keystats_event_id.ahk
#Include unit/modules/keystats/test_keystats_device_uuid.ahk
#Include unit/modules/keystats/test_keystats_full_id_recovery.ahk
; keystats_text_cipher.ahk (KL_Enc_* at-rest encryption) is pure definitions
; with no top-level hotkeys, and keystats_sql.ahk now calls it, so it must load
; before the SQL builders.
#Include ../modules/keystats/keystats_text_cipher.ahk
; keystats_text_migration.ahk (the data.sql rewrite that converts rows stored
; before the setting changed) is likewise pure definitions: its only side effect
; is armed by a timer from KL_Init, which the runner never calls.
#Include ../modules/keystats/keystats_text_migration.ahk
#Include ../modules/keystats/keystats_sql.ahk
#Include unit/modules/keystats/test_keystats_ingest_encryption_retry.ahk
#Include unit/modules/keystats/test_keystats_rollover_recovery.ahk
; keystats_hotstring_log.ahk holds KL_LogHotstring — the one persisted row that
; can carry the user's personal data. It was split out of keystats.ahk (which
; installs OS hooks at load and can never be included here) precisely so this
; runner can drive the REAL function against the recording KL_AppendLog /
; KL_Roi_OnHotstring / WPMWidget_Push stubs in test_stubs.ahk. Asserting on a
; test-built copy of the row would have passed against the leaking code.
#Include ../modules/keystats/keystats_hotstring_log.ahk
; keystats_watchers.ahk is definition-only. Include it so WTS subscription
; verdict/retry ownership is exercised through the real production functions.
#Include ../modules/keystats/keystats_watchers.ahk
#Include unit/modules/keystats/test_keystats_wts_registration.ahk
; keystats_hook.ahk holds the OTHER sink that can carry the user's personal
; data: the per-keystroke typing buffer. The InputHook observes the driver's own
; auto-typed expansions, so an @iban★ fire reaches KL_Hook_OnChar character by
; character ~90 ms before the redacted hotstring row is written. The file is
; class + function definitions only (the InputHook is created inside
; KL_Hook_Start, which the runner never calls), so the real callbacks can be
; driven headless and the buffer they fill read straight back — the previous
; test asserted only on KL_LogHotstring's row and missed this one entirely.
#Include ../modules/keystats/keystats_hook.ahk
#Include ../modules/keystats/keystats_mouse.ahk
#Include ../modules/keystats/keystats_window_topology.ahk
#Include unit/ui/windows/test_bounded_focus_snapshot.ahk
#Include unit/ui/windows/test_focus_handle_release_reentry.ahk
#Include unit/modules/keystats/test_keystats_mouse_coordinates.ahk
#Include unit/modules/keystats/test_keystats_window_topology.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_fire_log_privacy.ahk
#Include unit/modules/keystats/ergonomics/test_synthetic_typing_row_privacy.ahk
; The near-miss row — the third persisted sink, and the one that had no privacy
; concept at all. _CheckNearMiss lives in hotstring_inputhook.ahk, which the
; prefix-watcher shim above already loads, so these drive the REAL function
; against the recording KL_AppendLog stub rather than a copy of its row.
#Include unit/modules/keystats/ergonomics/test_near_miss_row_privacy.ahk
#Include unit/modules/keystats/test_keystats_walker.ahk
#Include unit/modules/keystats/ergonomics/test_walker_json_flush_merge.ahk
#Include unit/modules/keystats/ergonomics/test_walker_histogram_partitions.ahk
#Include unit/modules/keystats/test_keystats_sql.ahk
#Include unit/modules/keystats/test_keystats_sql_literal_controls.ahk
#Include unit/modules/keystats/test_keystats_text_cipher.ahk
#Include unit/modules/keystats/test_keystats_text_migration.ahk
#Include unit/infra/config/migration/test_migration_native_write.ahk
#Include unit/infra/config/migration/test_migration_open_refusal.ahk
#Include unit/infra/config/migration/test_keystats_migration_read_refusal.ahk
#Include unit/modules/hotstrings/engine/test_build_inserts_covers_emitted_types.ahk
#Include unit/modules/keystats/metrics/test_metrics_and_locale_honesty.ahk
#Include unit/modules/keystats/test_keystats_app_categories.ahk
#Include unit/modules/keystats/reader/test_keystats_reader.ahk
#Include unit/modules/keystats/reader/test_keystats_reader_manifest_contract.ahk
#Include unit/modules/keystats/reader/test_keystats_query_catalogue.ahk
#Include unit/modules/keystats/reader/test_klr_manifest_switches_to.ahk
#Include unit/modules/keystats/test_keystats_llm_accepted_metrics.ahk
#Include unit/modules/keystats/metrics/test_metrics_sqlite_fixture_cleanup.ahk
#Include unit/modules/keystats/test_keystats_shortcut_projection.ahk
#Include unit/modules/keystats/reader/test_keystats_reader_ngram_sources.ahk
#Include unit/modules/keystats/ergonomics/test_roi_prune_bounded.ahk
#Include unit/modules/keystats/reader/test_keystats_reader_sql_fail_loud.ahk
#Include unit/modules/keystats/reader/test_klr_ledger_read_refusal.ahk
#Include unit/modules/keystats/test_keystats_journal_read_progress.ahk
#Include unit/modules/keystats/reader/test_klr_sql_operational_retry.ahk
#Include unit/adapters/sqlite/test_sqlite_read_dispatch.ahk
#Include unit/adapters/sqlite/test_sqlite_exec_progress_cleanup.ahk
#Include unit/adapters/sqlite/test_sqlite_module_owner.ahk
#Include unit/modules/keystats/reader/test_klr_ledger_chunk_boundary.ahk
#Include unit/modules/keystats/reader/test_klr_cache_fixture.ahk
#Include unit/modules/keystats/reader/test_klr_durable_cache.ahk
#Include unit/modules/keystats/reader/test_klr_multi_ledger_retry.ahk
#Include unit/modules/keystats/reader/test_klr_candidate_live_retry.ahk
#Include unit/modules/keystats/metrics/test_metrics_cancel_retry.ahk
#Include unit/modules/keystats/metrics/test_metrics_native_start_cancel.ahk
#Include unit/modules/keystats/metrics/test_metrics_native_worker_exit.ahk
#Include unit/modules/llm/servers/test_orphan_cleanup_pid.ahk
#Include unit/platform/network/test_http_orphan_liveness.ahk
#Include unit/modules/keystats/reader/test_klr_cache_admission.ahk
#Include unit/modules/keystats/reader/test_klr_cache_offsets.ahk
#Include unit/modules/hotstrings/catalogue/test_hotstring_count_units.ahk
#Include unit/modules/keystats/context/test_system_missing_durations.ahk
#Include unit/modules/keystats/context/test_system_duration_accounting.ahk
#Include unit/modules/keystats/metrics/test_metrics_system_manifest.ahk
#Include unit/modules/keystats/context/test_system_intervals.ahk
#Include unit/modules/keystats/context/test_system_event_owner.ahk
#Include unit/modules/keystats/context/test_system_watcher_intervals.ahk
#Include unit/modules/keystats/reader/test_klr_cold_projection_failure.ahk
#Include unit/modules/keystats/reader/test_klr_cache_date_scope.ahk
#Include unit/modules/keystats/reader/test_klr_projection_paging.ahk
#Include unit/modules/keystats/reader/test_klr_worker_memory_bound.ahk
#Include unit/modules/keystats/reader/test_klr_projection_cursor_int64.ahk
#Include unit/modules/keystats/reader/test_klr_projection_page_work.ahk
#Include unit/modules/keystats/reader/test_klr_projection_sql_failure.ahk
#Include unit/modules/keystats/reader/test_klr_projection_late_page_failure.ahk
#Include unit/modules/keystats/reader/test_klr_cache_publication_order.ahk
#Include unit/modules/keystats/reader/test_klr_cache_save_cadence.ahk
#Include unit/adapters/sqlite/test_sqlite_readonly_clone.ahk
#Include unit/adapters/sqlite/test_sqlite_clone_page_size.ahk
#Include unit/modules/keystats/reader/test_klr_resident_refresh.ahk
#Include unit/modules/keystats/reader/test_klr_cache_encryption.ahk
#Include unit/modules/keystats/reader/test_klr_newest_first_rebuild.ahk
#Include unit/modules/keystats/metrics/test_metrics_rebuild_snapshots.ahk
#Include unit/modules/keystats/reader/test_klr_cache_stages.ahk
#Include unit/modules/keystats/reader/test_klr_cache_open_failure.ahk
#Include unit/modules/keystats/reader/test_klr_cache_rejection_identity.ahk
#Include unit/modules/keystats/reader/test_klr_rebuild_publication.ahk
#Include unit/modules/keystats/reader/test_klr_ledger_listing_failure.ahk
#Include unit/modules/keystats/reader/test_klr_cache_copy_failure.ahk
#Include unit/modules/keystats/reader/test_klr_cache_sql_read_failure.ahk
#Include unit/modules/keystats/reader/test_klr_cache_timings.ahk
#Include unit/modules/keystats/reader/test_klr_append_compensation.ahk
#Include unit/modules/keystats/reader/test_klr_stream_writer_interleaving.ahk
#Include unit/modules/keystats/metrics/test_metrics_full_retry_cadence.ahk
#Include meta/modules/keystats/metrics/test_metrics_committed_ingest_signal.ahk
#Include unit/modules/keystats/reader/test_klr_consumed_ledger_identity.ahk
#Include unit/modules/keystats/reader/test_klr_clear_failure.ahk
#Include unit/modules/keystats/reader/test_klr_live_drain_failure.ahk
#Include unit/modules/keystats/metrics/test_metrics_prefetch_history_presence.ahk
#Include unit/modules/keystats/metrics/test_metrics_historical_json.ahk
#Include unit/modules/keystats/metrics/test_metrics_history_seed.ahk
#Include unit/modules/keystats/metrics/test_metrics_terminal_exception_cleanup.ahk
#Include unit/modules/keystats/metrics/test_metrics_range_date_types.ahk
#Include unit/modules/keystats/metrics/test_metrics_range_json_equivalence.ahk
#Include unit/modules/keystats/metrics/test_metrics_range_json_failure.ahk
#Include unit/modules/keystats/metrics/test_metrics_seed_header.ahk
#Include unit/modules/keystats/metrics/test_metrics_manifest_json.ahk
#Include unit/modules/keystats/metrics/test_metrics_delta_lifecycle.ahk
#Include unit/modules/keystats/metrics/test_metrics_delivery_sequence.ahk
#Include unit/modules/keystats/metrics/test_metrics_delivery_midnight.ahk
#Include unit/modules/keystats/metrics/test_metrics_prefetch_orphans.ahk
#Include unit/modules/keystats/reader/test_klr_cache_failed_refresh.ahk
#Include unit/modules/keystats/reader/test_klr_category_order.ahk
#Include unit/adapters/sqlite/test_sqlite_query_failure.ahk
#Include unit/modules/keystats/reader/test_keystats_reader_encrypted_rebuild.ahk
#Include unit/modules/keystats/test_keystats_app_category_projection.ahk
#Include unit/modules/keystats/test_keystats_password_fail_closed.ahk
#Include unit/adapters/test_single_instance_gate.ahk
#Include unit/adapters/test_worker_tray_icon_hidden.ahk
#Include unit/modules/keystats/test_keystats_network_transitions.ahk
#Include ../infra/menu_command_origin.ahk
#Include unit/ui/menu/test_menu_command_origin.ahk
; KLW_GetMap and KLW_GetAppCtx must handle missing context keys without throwing.
#Include unit/modules/keystats/ergonomics/test_walker_ctx_missing_key.ahk
; Shared timings (A3): tap_holds/constants.ahk defines the tap-hold timing
; globals + TapHoldsLoadTimings() and has NO top-level hotkeys, so it is safe to
; include here (unlike most modules/). test_timings_config exercises the shared
; registry reader plus the keystats-walker and tap-hold reassign-at-boot loaders.
#Include ../platform/remap/constants.ahk
#Include ../platform/remap/tap_hold_roll.ahk
#Include ../platform/remap/altgr_criteria.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_activity_cancel.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_owned_press.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_prior_key.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_tap_keeps_held_modifiers.ahk
#Include unit/platform/remap/keys/test_timings_config.ahk
_LogBootProgress("keystats modules + tests included")

; ── Meta tests (codebase hygiene, no production includes needed) ──
#Include meta/suite/test_ahk_brace_balance.ahk
#Include meta/suite/test_run_all_include_integrity.ahk
#Include meta/suite/test_runner_only_filter.ahk
#Include meta/suite/test_runner_failure_ergonomics.ahk
#Include unit/suite/test_qualification_parser_owner.ahk
#Include meta/suite/test_ahk_os_purity_ratchet.ahk
#Include meta/suite/test_ahk_os_purity_inputs.ahk
#Include meta/infra/logger/test_logger_pairing.ahk
#Include meta/modules/llm/servers/test_remote_generate_curl_dispatch.ahk
#Include unit/platform/network/test_network_dispatch_nonblocking.ahk
#Include unit/platform/network/test_managed_network_failure.ahk
#Include unit/platform/network/test_managed_network_windows_actions.ahk
#Include unit/platform/network/test_managed_terminal_failure.ahk
#Include unit/platform/network/test_system_proxy_retirement.ahk
#Include unit/platform/network/test_network_pac_source_contract.ahk
#Include unit/platform/network/test_managed_routes_native.ahk
#Include unit/platform/network/test_managed_remote_transport.ahk
#Include unit/platform/network/test_managed_remote_cleanup_diagnostics.ahk
#Include unit/platform/network/test_managed_remote_fixture_scope.ahk
#Include unit/platform/network/test_managed_remote_readiness_diagnostics.ahk
#Include unit/modules/updater/test_updater_managed_transport.ahk
#Include unit/modules/updater/test_updater_managed_transport_diagnostics.ahk
#Include unit/modules/updater/test_updater_curl_artifact.ahk
#Include unit/modules/updater/test_updater_curl_capture.ahk
#Include unit/modules/updater/test_updater_curl_capture_namespace.ahk
#Include unit/modules/updater/test_updater_curl_capture_move_graph.ahk
#Include unit/platform/network/test_managed_remote_sspi.ahk
#Include unit/platform/network/test_winhttp_transport.ahk
#Include unit/modules/updater/test_updater_artifact_winhttp.ahk
#Include unit/platform/network/test_managed_winhttp_proxy.ahk
#Include meta/modules/llm/servers/test_remote_connect_timeout_bounded.ahk
#Include meta/modules/keystats/test_keystats_json_64bit_decode.ahk
#Include meta/adapters/crash_report/test_crash_build_offthread.ahk
#Include meta/suite/test_assertions_are_case_sensitive.ahk
#Include meta/modules/hotstrings/personal/test_personal_hotstring_node_shape.ahk
#Include meta/modules/hotstrings/personal/test_personal_hotstring_seed.ahk
#Include meta/modules/hotstrings/personal/test_personal_hotstring_new_section_seed.ahk
#Include meta/modules/hotstrings/personal/test_personal_hotstring_cache_invalidation.ahk
#Include meta/modules/hotstrings/personal/test_personal_toml_write_failure_logged.ahk
#Include meta/modules/hotstrings/catalogue/test_hotstring_override_atomic_publish.ahk
#Include meta/modules/hotstrings/personal/test_personal_section_label_disambiguation_wired.ahk
#Include meta/suite/test_no_duplicate_defaults.ahk
#Include meta/suite/test_require_state_pattern.ahk
#Include meta/modules/keystats/test_keystats_pause_guard.ahk
#Include meta/modules/updater/test_changelog_http_timeout.ahk
#Include meta/adapters/test_dpapi_decrypt_safe.ahk
#Include meta/ui/menu/test_menu_dispatcher_critical.ahk
#Include meta/ui/menu/test_menu_dispatch_epoch.ahk
#Include meta/modules/llm/api/test_llm_setbackend_propagates_to_engine.ahk
#Include meta/modules/llm/menu/test_llm_menu_persistence_transactions.ahk
#Include meta/modules/llm/api/test_warmup_retry_suspend_guard.ahk
#Include meta/modules/keystats/ergonomics/test_halflife_tick_suspend_guard.ahk
#Include meta/modules/keymap/test_layout_poll_suspend_guard.ahk
#Include meta/modules/keymap/test_layout_poll_native_arming.ahk
#Include meta/platform/remap/keys/test_lalt_rctrl_accept_suspend_guard.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_fire_action_suspend_guard.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_native_dispatch_guard.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_taps_use_held_modifier_emitter.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_hotkeys_admit_held_modifiers.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_owned_repeat_identities.ahk
#Include meta/platform/remap/layers/test_nav_layer_admits_held_modifiers.ahk
#Include meta/platform/remap/keys/test_lshift_lctrl_rshift_bounded_keywait.ahk
#Include meta/modules/keymap/test_layout_poll_blacklist_guard.ahk
#Include meta/modules/keymap/test_layout_quiescence.ahk
#Include meta/platform/remap/keys/test_layer_key_under_another_holder.ahk
#Include unit/modules/keymap/test_foreground_keyboard_layout.ahk
#Include meta/modules/hotstrings/engine/test_hse_register_atomic.ahk
#Include meta/modules/hotstrings/engine/test_hse_rebuild_guard.ahk
#Include meta/modules/hotstrings/engine/test_hse_rebuild_prefix_buffer_reset.ahk
#Include meta/modules/gestures/test_gesture_shared_lbutton.ahk
#Include meta/modules/gestures/test_gesture_left_hold_tap_release.ahk
#Include meta/modules/gestures/test_gesture_takenote_winwait.ahk
#Include meta/modules/gestures/test_takenote_hotpath_nonblocking.ahk
#Include meta/modules/gestures/test_gesture_takenote_winmaximize_guard.ahk
#Include meta/modules/gestures/test_gesture_get_cyclable_windows_catch.ahk
#Include meta/modules/gestures/test_open_downloads_nonblocking.ahk
#Include meta/modules/gestures/test_searchpath_regjump_catch.ahk
#Include meta/modules/gestures/test_getpath_clipboard_receipt.ahk
#Include meta/ui/windows/test_path_dialog_button_race.ahk
#Include meta/modules/gestures/test_gesture_exit_button_release.ahk
#Include meta/infra/lifecycle/test_onexit_terminal_order.ahk
#Include meta/adapters/input/test_textsend_clipall.ahk
#Include meta/adapters/input/test_text_sender_clipboard_restore.ahk
#Include meta/modules/llm/navigation/test_llm_autotype_hse_suppress.ahk
#Include meta/modules/keystats/test_ingest_tick_guards.ahk
#Include meta/modules/keystats/test_ingest_failure_requeues.ahk
#Include meta/modules/gestures/test_gesture_keywatcher_suspend.ahk
#Include meta/modules/gestures/test_activitysim_collision.ahk
#Include meta/modules/keystats/metrics/test_metrics_focus_cache_atomic.ahk
#Include meta/modules/keystats/metrics/test_metrics_focus_ttl_leak.ahk
#Include meta/modules/keystats/metrics/test_metrics_focus_off_thread.ahk
#Include meta/adapters/input/test_clipboard_ram_leak.ahk
#Include meta/platform/remap/keys/test_space_tap_dispatch.ahk
#Include meta/infra/dispatch/test_dispatch_verdict_consumed.ahk
#Include meta/modules/hotstrings/engine/test_fire_log_never_synchronous.ahk
#Include meta/modules/hotstrings/engine/test_deferred_hotstring_lifecycle_guards.ahk
#Include meta/modules/keystats/ergonomics/test_roi_map_mutation_race.ahk
#Include meta/modules/hotstrings/catalogue/test_deferred_registration_live_rebuild_race.ahk
#Include meta/ui/windows/test_spotlight_non_blocking.ahk
#Include meta/ui/windows/test_spotlight_gdiplus_leak.ahk
#Include meta/infra/toml/test_toml_batchwrite_atomic.ahk
#Include unit/infra/toml/test_toml_batchwrite_exact_subtree.ahk
#Include meta/ui/webview/test_webview2_temp_leak.ahk
#Include meta/modules/keystats/test_keystats_webview_fallback.ahk
#Include meta/ui/windows/test_graphics_renderer_createwindow_catch.ahk
#Include meta/modules/llm/servers/test_ollama_webview_executescript_deferred.ahk
#Include meta/modules/llm/servers/test_ollama_webview_callback_epoch.ahk
#Include meta/modules/keystats/test_keystats_webview_executescript_deferred.ahk
#Include meta/ui/webview/test_webview_low_ram_native_fallback.ahk
#Include meta/infra/dispatch/test_hookdispatcher_swallow.ahk
#Include meta/modules/llm/api/test_llm_json_parser_silent_fail.ahk
#Include meta/infra/toml/test_json_unicode_escape.ahk
#Include meta/ui/healthcheck/test_healthcheck_recordwarn_called.ahk
#Include meta/modules/shortcuts/test_wrap_symbol_disabled_state.ahk
#Include meta/modules/gestures/test_screenshot_region_clipwait_clobber.ahk
#Include meta/modules/keystats/context/test_av_mute_heuristic.ahk
#Include meta/modules/keystats/ergonomics/test_ergo_roi_count_synth.ahk
#Include meta/modules/llm/profiles/test_profile_delete_path.ahk
#Include meta/modules/llm/navigation/test_nav_val_modifiers_wired.ahk
#Include meta/modules/updater/test_updater_sync_winhttp_blocks.ahk
#Include meta/adapters/sqlite/test_sqlite_progress_yield.ahk
#Include meta/modules/keystats/ergonomics/test_agg_app_day_llm_suggested.ahk
#Include meta/modules/keystats/reader/test_reader_preserves_walker_aggregates.ahk
#Include meta/modules/hotstrings/catalogue/test_hotstring_check_constraint_widened.ahk
#Include meta/infra/logger/test_logger_sync_warning.ahk
#Include meta/modules/keystats/test_keystats_deferred_write.ahk
#Include meta/platform/remap/layers/test_deadkey_timeout.ahk
#Include meta/modules/shortcuts/test_sendinstant_deferred_clipboard.ahk
#Include meta/modules/shortcuts/test_keepawake_pause_gate.ahk
#Include meta/modules/shortcuts/test_keepawake_stop_notify_gate.ahk
#Include meta/modules/gestures/test_mouse_park_gate.ahk
#Include meta/modules/gestures/test_mouse_hotkey_clobber.ahk
#Include meta/modules/gestures/test_mouse_suspend_guard.ahk
#Include meta/modules/keystats/test_scroll_flush_fn_cleared_on_stop.ahk
#Include meta/infra/dispatch/test_timer_scheduler_pause_guard.ahk
#Include meta/modules/keystats/test_keystats_watchers_pause_guard.ahk
#Include unit/modules/keystats/test_keystats_session_privacy_transaction.ahk
#Include unit/modules/keystats/test_keystats_session_close_retry.ahk
#Include unit/modules/keystats/test_keystats_native64_clock.ahk
#Include unit/modules/keystats/test_keystats_arrival_fifo.ahk
#Include unit/modules/keystats/test_keystats_mouse_privacy_transaction.ahk
#Include meta/modules/shortcuts/test_uia_selection_background_poll.ahk
#Include meta/modules/shortcuts/test_uia_selection_snapshot.ahk
#Include meta/ui/tooltip/test_tooltip_render_epoch.ahk
#Include meta/ui/tooltip/test_tooltip_position_cache_receipt_wiring.ahk
#Include meta/modules/llm/tooltip/test_tooltip_llm_render_epoch.ahk
#Include meta/modules/llm/profiles/test_llm_presented_record_single_source.ahk
#Include meta/modules/llm/servers/test_remote_poll_deadline.ahk
#Include meta/modules/updater/test_download_integrity_guard.ahk
#Include meta/suite/test_no_coauthor_in_commits.ahk
#Include meta/infra/lifecycle/test_bundle_exclusions.ahk
#Include meta/modules/llm/menu/test_llm_menu_init_order.ahk
#Include meta/modules/llm/api/test_llm_ensure_model_ready_guard.ahk
#Include meta/infra/lifecycle/test_boot_deferred_tasks.ahk
#Include meta/infra/lifecycle/test_boot_error_fatal_before_ready.ahk
#Include meta/infra/lifecycle/test_hotif_globals_boot_safe.ahk
#Include meta/suite/test_hotif_directive_lexical_boundaries.ahk
#Include meta/infra/logger/test_error_net_prelogger_safe.ahk
#Include meta/infra/lifecycle/test_boot_paths_fail_soft.ahk
#Include meta/ui/wpm/test_wpm_widget_native_render.ahk
#Include meta/ui/wpm/test_wpm_widget_hidden_until_typed.ahk
#Include meta/modules/hotstrings/catalogue/test_text_expansion_critical_path.ahk
#Include meta/adapters/input/test_text_sender_clipboard_failure.ahk
#Include meta/adapters/input/test_text_sender_clipboard_sequence_ownership.ahk
#Include meta/ui/windows/test_download_window_i18n_fallback.ahk
#Include meta/ui/menu/test_tray_build_critical_restore.ahk
#Include meta/ui/menu/test_tray_root_terminal_forwarding.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_watcher_deferred.ahk
#Include meta/modules/hotstrings/catalogue/test_hotstrings_ready_contract.ahk
#Include meta/infra/config/migration/test_native_hotstrings_migrated.ahk
#Include meta/modules/hotstrings/engine/test_hse_send_transaction_guard.ahk
#Include meta/infra/i18n/test_i18n_fallback_deferred.ahk
#Include unit/modules/hotstrings/engine/test_hse_conform_double_fire.ahk
#Include meta/modules/llm/menu/test_llm_menu_deferred_build.ahk
#Include meta/infra/logger/test_logger_format_placeholders.ahk
#Include meta/infra/logger/test_logger_sub_files_routing.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_render_deferred.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_visible_suggestion_epoch.ahk
#Include meta/adapters/input/test_input_serialization.ahk
#Include meta/modules/hotstrings/engine/test_fire_log_defer_after_suppress.ahk
#Include meta/modules/hotstrings/engine/test_hse_suppress_release_bounded.ahk
#Include meta/modules/hotstrings/engine/test_hse_physical_suppression_provenance.ahk
#Include meta/modules/hotstrings/engine/test_hse_endchar_index_bound.ahk
#Include meta/modules/hotstrings/engine/test_hse_physical_input_provenance.ahk
#Include meta/adapters/uia/test_uia_wrap_suppress_latch.ahk
#Include meta/modules/keystats/ergonomics/test_near_miss_scan_bounded.ahk
#Include meta/modules/gestures/test_gesture_cycle_winevent_fence.ahk
#Include meta/modules/gestures/test_gesture_cycling_flag_critical.ahk
#Include meta/modules/llm/api/test_llm_app_filter_enforced.ahk
#Include meta/modules/llm/navigation/test_llm_instant_word_end_trigger.ahk
#Include meta/modules/llm/tooltip/test_llm_tooltip_chunk_type_guard.ahk
#Include meta/platform/remap/keys/test_space_hold_suspend_guard.ahk
#Include meta/modules/llm/api/test_av_warmup_cancellable.ahk
#Include meta/modules/llm/servers/test_remote_poll_com_exception_bails.ahk
#Include meta/modules/hotstrings/catalogue/test_cle_emoji_gated.ahk
#Include meta/modules/hotstrings/engine/test_hse_consumed_endchar_ring.ahk
#Include meta/modules/hotstrings/engine/test_expansion_burst_atomic.ahk
#Include meta/infra/toml/test_parsetomlfile_unterminated_array_recovers.ahk
#Include meta/infra/dispatch/test_dispatcher_register_duplicate_label.ahk
#Include meta/modules/updater/test_updater_cancel_fires_on_json.ahk
#Include meta/modules/updater/test_updater_download_receive_timeout.ahk
#Include meta/modules/updater/test_updater_download_reentrancy_guard.ahk
#Include meta/modules/updater/test_updater_download_requires_consent.ahk
#Include meta/modules/updater/test_updater_prompt_uses_shared_notes.ahk
#Include meta/modules/hotstrings/personal/test_personal_load_once.ahk
#Include meta/modules/llm/menu/test_menu_llm_actions_include.ahk
#Include meta/modules/llm/menu/test_llm_menu_suspend_bootstrap.ahk
#Include meta/modules/llm/api/test_llm_backend_lifecycle_ownership.ahk
#Include meta/modules/llm/menu/test_llm_menu_disabled_greyed.ahk
#Include meta/modules/keymap/test_language_menu_deferred_publication.ahk
#Include meta/modules/llm/menu/test_llm_menu_layout_shared.ahk
; MenuManifest_LoadTopLevel/LoadGlobalActions/LoadDebugMenu — needed so the
; top-level drift gate stages the root from the real shared manifest.
#Include ../infra/menu_manifest.ahk
; The generic manifest walker. Pure function definitions — no top-level
; statements, no includes — so pulling it in is side-effect free, and it lets
; disabled_when tests exercise the real resolver instead of scanning its source.
#Include ../infra/manifest_menu.ahk
#Include unit/ui/menu/test_menu_population.ahk
#Include unit/ui/menu/test_menu_startup_commands.ahk
#Include unit/infra/config/persistence/test_config_registry_cache.ahk
#Include unit/modules/llm/api/test_llm_runtime_activation.ahk
; The tray root builder: its top-level dispatcher and the id → builder table.
; Function definitions only, and the table names only its own _MI_ builders,
; so pulling it in stages nothing and resolves no menu dependency at load.
#Include ../ui/menu/menu_init.ahk
; Drift gate: the staged tray root follows the manifest's top level, separators included.
#Include meta/ui/menu/test_menu_top_level_drift_gate.ahk
; Regression: no separator doubles up in any manifest menu.
#Include unit/ui/menu/test_manifest_menu_no_double_separator.ahk
; Regression: every category switch is a first-row checkbox with one label.
#Include unit/modules/hotstrings/catalogue/test_category_toggle_checkbox.ahk
#Include unit/ui/menu/test_menu_choice_row.ahk
; Regression: each hotstring « tout activer » / « tout désactiver » pair is one checkbox.
#Include unit/modules/hotstrings/catalogue/test_hotstring_bulk_checkboxes.ahk
; Regression: Shortcuts submenu block separator and screenshot key label.
#Include unit/modules/shortcuts/test_shortcuts_menu_blocks.ahk
#Include unit/modules/shortcuts/test_shortcuts_personal_data_frame.ahk
#Include unit/modules/shortcuts/test_shortcuts_personal_data_native_port.ahk
#Include unit/modules/shortcuts/test_shortcuts_extension_results.ahk
#Include unit/modules/shortcuts/test_shortcuts_menu_groups_unique.ahk
#Include unit/modules/shortcuts/test_keyboard_slot_group_scope.ahk
; Contract gate: metrics_menu disabled_when predicate == AHK handler resolver calls (MG-1/MG-2).
#Include meta/ui/menu/test_list_providers_touch_no_menu.ahk
#Include meta/modules/keystats/metrics/test_menu_metrics_disabled_when.ahk
#Include unit/modules/keystats/metrics/test_metrics_widget_menu_parity.ahk
#Include meta/adapters/test_port_adapter_coverage.ahk
#Include meta/suite/test_no_class_global_conflict.ahk
#Include meta/infra/i18n/test_locale_json_valid.ahk
#Include meta/modules/shortcuts/test_wrap_symbols_gate.ahk
#Include meta/modules/shortcuts/test_wrap_symbols_catalogue.ahk
#Include unit/modules/shortcuts/test_wrap_symbols_global_transaction.ahk
; ── Cross-driver corpus consumers ──
#Include meta/corpus/test_corpus_hotstrings.ahk
#Include meta/modules/hotstrings/preview/test_preview_matches_engine.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_buffer_tracks_engine.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_buffer_atomic_transitions.ahk
#Include meta/modules/hotstrings/engine/test_nav_cluster_resets_both_buffers.ahk
#Include meta/modules/hotstrings/preview/test_preview_never_wiped_alone.ahk
#Include meta/modules/hotstrings/preview/test_preview_engine_single_owner.ahk
#Include meta/corpus/test_corpus_dynamic_hotstrings_prefix.ahk
#Include meta/corpus/test_corpus_hotstrings_config_resolve.ahk
#Include meta/corpus/test_corpus_tap_hold.ahk
#Include meta/corpus/test_corpus_keymap_layers.ahk
#Include meta/corpus/test_corpus_hotstring_matcher.ahk
; LLM parser corpus -- tests LLM_ParseOllamaResponse and _LLMRemoteParseResponse
; against the shared cross-driver vectors (already included above via api_ollama/api_remote).
#Include meta/corpus/test_corpus_llm_parser.ahk
; Security / keystats privacy corpus -- tests ES_PASSWORD detection and
; Win32 known-class lookup logic in isolation (OS-level paths are headless-safe stubs).
#Include meta/corpus/test_corpus_security_keystats.ahk
; PromptBuilder corpus -- tests the generated PromptBuilder class against the
; shared cross-driver vectors.
#Include ../_generated/prompt_builder.ahk
#Include meta/corpus/test_corpus_prompt_builder.ahk
; Chord notation corpus -- runs the shared _shared/lua/chord/vectors.json against
; the AutoHotkey twin, plus the native-translation half that is supposed to differ.
#Include ../infra/chord.ahk
#Include ../adapters/hotkey_registrar.ahk
#Include ../../_shared/modules/shortcuts/magic_editor.ahk
#Include ../infra/magic_editor.ahk
#Include meta/platform/remap/key_combinations/test_chord_notation.ahk
#Include unit/adapters/input/test_hotkey_registrar_transactions.ahk
#Include unit/adapters/input/test_hotkey_registrar_aliases.ahk
#Include unit/adapters/input/test_hotkey_registrar_modifier_keys.ahk
#Include unit/modules/hotstrings/magic_key/test_magic_editor.ahk
#Include unit/platform/remap/key_combinations/test_keyboard_slot_win_space.ahk
#Include unit/modules/llm/actions/test_llm_trigger_shortcut_retired.ahk
#Include unit/modules/llm/navigation/test_llm_hotkey_identity.ahk
#Include unit/modules/llm/navigation/test_llm_nav_event_owner.ahk
; Reuses the navigation owner's deterministic native port and fixtures above.
#Include unit/modules/llm/navigation/test_llm_tab_accepts_visible_prediction.ahk
#Include unit/modules/llm/tooltip/test_llm_tooltip_nav_consumed.ahk
; Reuses the chord helpers of test_llm_tooltip_nav_consumed above.
#Include unit/modules/llm/navigation/test_llm_nav_cycle_windows.ahk
#Include unit/modules/llm/navigation/test_llm_nav_hotkey_transaction.ahk
#Include unit/modules/llm/navigation/test_llm_nav_hotkey_native_transaction.ahk
#Include unit/modules/llm/navigation/test_llm_profile_hotkey_transaction.ahk
#Include unit/modules/llm/navigation/test_llm_hotkeys_deferred_by_pause.ahk
#Include unit/modules/llm/navigation/test_llm_hotkey_cross_owner_collision.ahk
#Include unit/modules/llm/navigation/test_llm_hotkey_contextual_routes.ahk
#Include meta/modules/llm/navigation/test_llm_hotkey_cross_owner_policy.ahk
#Include meta/infra/config/transition/test_config_transition_integration.ahk
; Logger behaviour corpus -- severity filtering and the ring buffer, from the
; same shared file the macOS and Linux suites replay.
#Include meta/corpus/test_corpus_logger_behaviour.ahk
; TOML fuzz corpus -- exercises ParseTomlFile() against 50 adversarial inputs.
; Asserts the loader never crashes on any input (valid or invalid TOML).
#Include meta/corpus/test_corpus_toml_fuzz.ahk
#Include meta/infra/toml/test_toml_inline_comment_stripping.ahk
#Include meta/infra/toml/test_toml_read_failure_is_loud.ahk
#Include meta/infra/config/persistence/test_config_boot_read_failure_blocks_persist.ahk
#Include meta/infra/config/persistence/test_persist_result_not_discarded.ahk
#Include meta/infra/config/persistence/test_config_persistence_callers.ahk
#Include meta/infra/config/persistence/test_config_recovery_gateway.ahk
; Keystats aggregation corpus -- tests KLW_WalkTypingEntry / KLW_WalkAppSwitch /
; KLW_WalkWindowSwitch / KLW_WalkSystemEvent against shared cross-driver vectors.
#Include meta/corpus/test_corpus_keystats_aggregation.ahk
; Healthcheck snapshot corpus -- tests _HealthCheck_FormatUptime and validates
; the golden vectors for the shared snapshot logic (format_uptime, issues, schema).
#Include meta/corpus/test_corpus_healthcheck_snapshot.ahk
; Updater release parser corpus -- tests Updater_ParseTagName / Updater_ParseBody /
; _Updater_ParsePrerelease / _Updater_SplitReleasesArray against shared cross-driver vectors.
#Include meta/corpus/test_corpus_updater_release_parser.ahk
; Locale resolution corpus -- tests t() cascade (active→en→fr→raw key) and ★
; substitution against shared cross-driver vectors.
#Include meta/corpus/test_corpus_locale_resolution.ahk
; Tooltip layout corpus -- validates _TooltipClampToScreen against shared
; cross-driver vectors.
#Include meta/corpus/test_corpus_tooltip_layout.ahk
; TOML coercion corpus
#Include meta/corpus/test_corpus_toml_coercion.ahk

; -- Audit finding regression tests (batch-wired) --
#Include meta/modules/hotstrings/catalogue/test_activate_hotstrings_sleep_gate.ahk
#Include meta/ui/windows/test_app_picker_t_variable_shadows_i18n.ahk
#Include meta/infra/lifecycle/test_appstate_orphaned_parallel_state.ahk
#Include meta/modules/keystats/context/test_av_no_blocking_registry_walk.ahk
#Include meta/ui/tooltip/test_border_gdi_cleanup_broken_nesting.ahk
#Include meta/ui/tooltip/test_tooltip_measure_gdi_ownership.ahk
#Include meta/platform/remap/keys/test_capslock_led_single_owner.ahk
#Include meta/infra/config/persistence/test_config_shortcuts_array_escape.ahk
#Include meta/infra/config/persistence/test_config_window_delay_write_per_keystroke.ahk
#Include meta/infra/config/persistence/test_config_window_republishes_baked_fields.ahk
#Include meta/infra/config/persistence/test_config_window_no_delimiter_ui.ahk
#Include meta/platform/network/test_curl_payload_pii_temp_leak.ahk
#Include meta/platform/remap/layers/test_deadkey_suspend_guard.ahk
#Include meta/ui/menu/test_deferred_menu_critical_file_io.ahk
#Include meta/infra/dispatch/test_dequeue_poll_no_suspend_guard.ahk
#Include meta/infra/dispatch/test_dispatcher_map_never_cleared_stale_misfire.ahk
#Include meta/infra/dispatch/test_dispatcher_start_guarded.ahk
#Include meta/infra/dispatch/test_dispatcher_start_ungated.ahk
#Include meta/infra/dispatch/test_dispatcher_stop_wired.ahk
#Include meta/suite/test_driver_source_helpers_fail_loudly.ahk
#Include meta/suite/test_driver_source_partial_reads.ahk
#Include meta/suite/test_driver_body_cache.ahk
#Include meta/suite/test_driver_block_comment_extraction.ahk
#Include meta/suite/test_driver_symbol_case.ahk
#Include meta/suite/test_driver_quoted_definitions.ahk
#Include meta/adapters/crash_report/test_error_handler_heavy_diagnostics.ahk
#Include meta/modules/hotstrings/catalogue/test_ext_builder_fn_dynamic_call_swallow.ahk
#Include meta/modules/gestures/test_gesturepickcolor_clipboard_clobber.ahk
#Include meta/modules/shortcuts/test_getselection_blocks_and_eats_keys.ahk
#Include meta/adapters/crash_report/test_global_error_handler_sendevent_storm.ahk
#Include meta/modules/hotstrings/engine/test_output_host_resolver_single_owner.ahk
#Include meta/modules/gestures/test_gesture_modifier_release_class.ahk
#Include meta/ui/healthcheck/test_health_probe_timer_suspend_guard.ahk
#Include meta/ui/healthcheck/test_healthcheck_init_dead_reference.ahk
#Include meta/ui/healthcheck/test_healthcheck_webview_handler.ahk
#Include meta/modules/hotstrings/engine/test_hse_disable_group_atomic.ahk
#Include meta/ui/menu/test_insert_id_discovery_label_collision.ahk
#Include meta/infra/config/persistence/test_isrepeat_section_name_mismatch_latent_divergence.ahk
#Include meta/modules/hotstrings/catalogue/test_text_expansion_auto_toml_backed.ahk
#Include meta/platform/remap/keys/test_kh_intercept_dead_flag.ahk
#Include meta/modules/keystats/test_kl_refresh_context_blocks_on_keystroke.ahk
#Include meta/modules/keystats/test_kl_stop_dead_no_exit_flush.ahk
#Include meta/modules/keystats/test_kl_switch_privacy_filter_outgoing.ahk
#Include meta/modules/keystats/test_kl_window_switch_pre_flush.ahk
#Include meta/modules/keystats/test_klpf_writeatomic_delete_window.ahk
#Include meta/modules/keystats/reader/test_klr_builddatabase_debug_fileappend_hot.ahk
#Include meta/modules/keystats/reader/test_klr_builddatabase_failure_logged.ahk
#Include meta/modules/keystats/ergonomics/test_klw_ctx_unbounded_hist_growth.ahk
#Include meta/platform/remap/keys/test_lalt_capslock_tap_min_duration.ahk
#Include meta/modules/llm/navigation/test_llm_accept_cleanup_in_finally.ahk
#Include meta/modules/llm/prediction/test_llm_failure_callback_arity.ahk
#Include meta/modules/llm/navigation/test_llm_inline_autotype_suspend_guard.ahk
#Include meta/modules/llm/navigation/test_llm_pointer_watch_not_stopped_on_suspend.ahk
#Include meta/infra/toml/test_loader_toml_injection_readfile_hotpath.ahk
#Include meta/modules/gestures/test_lock_workstation_named_helper.ahk
#Include meta/modules/keystats/test_lost_tick_after_filtered_keystroke.ahk
#Include meta/ui/menu/test_menu_dispatch_callbacks_unbounded_growth.ahk
; Deep-liveness: the prune's tray walk reaches items at any depth (F07 deep-liveness).
#Include meta/ui/menu/test_menu_dispatch_deep_liveness.ahk
; Prune collects live IDs once, not per tracked ID — O(tray+tracked) (menu-prune-quadratic-tray-walk).
#Include meta/ui/menu/test_menu_prune_quadratic_tray_walk.ahk
#Include meta/modules/keystats/context/test_ni_isvpnactive_missing_return.ahk
#Include meta/modules/keystats/test_no_onexit_keystats_flush.ahk
#Include meta/ui/onboarding/test_onboarding_no_appstate.ahk
#Include meta/ui/onboarding/test_onboarding_toml_bool_reads.ahk
#Include meta/ui/onboarding/test_onboarding_effective_config_dir.ahk
#Include meta/ui/windows/test_numeric_prompt_throws_on_nonnumeric.ahk
#Include meta/platform/remap/keys/test_oneshotshift_lalt_lshift_stuck.ahk
#Include meta/platform/remap/keys/test_oneshotshift_suspend_guard.ahk
#Include meta/platform/remap/keys/test_hold_modifier_release_bounded.ahk
#Include meta/platform/remap/altgr/test_altgr_rolls_precedence.ahk
#Include meta/modules/keystats/test_keystats_session_watcher_synth.ahk
#Include meta/modules/keystats/test_kl_stop_flush_survives_suspend.ahk
#Include meta/modules/llm/prediction/test_onkeydown_dead_llm_branch.ahk
#Include meta/infra/toml/test_parser_ord_empty_token_crash.ahk
#Include meta/modules/keystats/context/test_password_cache_torn_write.ahk
#Include meta/modules/gestures/test_paste_plain_nontext_clip_guard.ahk
#Include meta/infra/toml/test_pathstoml_read_missing_utf8_encoding.ahk
#Include meta/modules/hotstrings/personal/test_personal_ext_scan_unbounded_recursion.ahk
#Include meta/infra/dispatch/test_pointer_watch_timer_bypasses_suspend.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_index_rebuild_no_suspend_guard.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_onkeydown_tab_llm_feed_gap.ahk
#Include meta/adapters/test_reg_keyexists_value_only.ahk
#Include meta/adapters/test_registry_oserror_number_not_extra.ahk
#Include meta/platform/remap/layers/test_remap_emit_critical_uneven.ahk
#Include meta/modules/llm/servers/test_remote_api_validate_async.ahk
#Include meta/modules/keystats/ergonomics/test_roi_current_word_unbounded_growth.ahk
#Include meta/modules/keystats/ergonomics/test_roi_full_map_prune_scan_on_hot_path.ahk
#Include meta/modules/shortcuts/test_sendinstant_reentrancy_guard.ahk
#Include meta/modules/keystats/context/test_sensors_cpu_state_stale_across_reload.ahk
#Include meta/platform/remap/tap_hold/test_space_altgr_double_raalt_down.ahk
#Include meta/modules/keystats/context/test_ssid_utf8_misdecode_and_signal_offset.ahk
#Include meta/modules/llm/api/test_stream_final_flush_sleep_blocks_thread.ahk
#Include meta/infra/toml/test_strict_canon_does_not_drop_stale_keys.ahk
#Include meta/infra/lifecycle/test_suspend_watchdog_no_prefix_keywait.ahk
#Include meta/adapters/input/test_owned_inputhooks_suspend.ahk
#Include meta/adapters/input/test_blocking_inputhook_suspend_ownership.ahk
#Include meta/infra/dispatch/test_timer_scheduler_registration_transaction.ahk
#Include meta/modules/updater/test_updater_finalize_nonblocking.ahk
#Include meta/infra/lifecycle/test_bundle_upgrade_transaction.ahk
#Include meta/modules/llm/navigation/test_tab_accept_cancels_timer.ahk
#Include meta/adapters/input/test_textsend_clipboard_thread.ahk
#Include meta/suite/test_tint_test_stale_constants_comment.ahk
#Include meta/ui/tooltip/test_tooltip_hide_non_blocking.ahk
#Include meta/ui/tooltip/test_tooltip_teardown_on_keyboard_thread.ahk
#Include meta/modules/llm/prediction/test_llm_bridge_deferred_hides.ahk
#Include meta/modules/keystats/context/test_topo_checkvirtualdesktop_stale_prev_hwnd.ahk
#Include meta/ui/menu/test_traymenu_separator_addstandard.ahk
#Include meta/ui/menu/test_traymenu_setmenu_raw_add.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_menu_register_dispatch.ahk
#Include meta/ui/menu/test_menu_dispatch_error_propagation.ahk
#Include meta/ui/windows/test_ui_launch_error_msgbox_on_timer_thread.ahk
#Include meta/adapters/uia/test_uia_error_logged.ahk
#Include meta/modules/updater/test_updater_focus_poll_suspend_guard.ahk
#Include meta/modules/updater/test_updater_setchannel_cancels_async.ahk
#Include meta/modules/updater/test_updater_setchannel_blocks_during_download.ahk
#Include meta/modules/updater/test_updater_setcheckinterval_coerces.ahk
#Include meta/modules/updater/test_updater_scheduler_off_typing_path.ahk
#Include meta/ui/webview/test_webview_temp_dir_and_com_leak_on_reload.ahk
#Include meta/modules/hotstrings/engine/test_win_l_lock_resets_context.ahk
#Include meta/platform/network/test_winhttp_no_abort_on_poll_timeout.ahk
#Include meta/modules/gestures/test_winorder_unbounded_and_cross_thread.ahk
#Include meta/ui/wpm/test_wpm_push_unguarded_debug_arg_build.ahk
#Include meta/ui/wpm/test_wpm_config_position_pair_validation.ahk
#Include meta/ui/wpm/test_wpm_persistence_transaction.ahk
#Include meta/infra/config/persistence/test_config_full_save_generation_guard.ahk
#Include meta/ui/wpm/test_wpm_ring_buffer_cross_thread_race.ahk
#Include unit/adapters/shell_runner/test_coalesced_job_callbacks_dropped.ahk
#Include unit/modules/hotstrings/personal/test_count_regex_vs_entry_pattern_divergence.ahk
#Include unit/infra/toml/test_counttoml_overcounts_personal_meta_sections.ahk
#Include unit/modules/hotstrings/personal/test_delay_edit_non_integer_personal_truncation.ahk
#Include unit/infra/config/persistence/test_freshness_same_second_edit_window.ahk
#Include unit/adapters/input/test_inline_autotype_not_synthetic.ahk
#Include unit/infra/toml/test_loadexttoml_skips_meta_sections.ahk
#Include unit/infra/toml/test_json_number_misleading_error.ahk
#Include unit/infra/toml/test_json_string_fast_path.ahk
#Include unit/infra/toml/test_json_object_key_nul.ahk
#Include unit/infra/toml/test_json_native_string_scan.ahk
#Include unit/modules/llm/servers/test_ollama_curl_temp_pii_plaintext.ahk
#Include unit/infra/toml/test_parsetomlgroupconfig_missing_file_cache_key.ahk
#Include unit/infra/toml/test_parsetomlgroupconfig_missing_file_cache_key_mismatch.ahk
#Include unit/modules/hotstrings/personal/test_per_entry_priority_divergence_cache_vs_toml.ahk
#Include unit/adapters/shell_runner/test_plc_closure_callable.ahk
#Include unit/modules/llm/servers/test_remote_parse_first_content_match.ahk
#Include unit/modules/hotstrings/engine/test_stale_cache_survives_reset_and_pause.ahk
#Include unit/modules/hotstrings/engine/test_time_activation_fails_open_on_missing_prev_char.ahk
#Include unit/infra/toml/test_uridecode_multibyte_utf8_corruption.ahk

; -- Audit finding regression tests (batch-wired) --
#Include meta/suite/test_generated_substr_minus_one.ahk
#Include meta/infra/toml/test_toml_multiline_array_depth.ahk
#Include meta/infra/toml/test_toml_unescape_ordering.ahk
#Include meta/adapters/input/test_clipboard_sentinel.ahk
#Include meta/adapters/input/test_clipboard_saveall_sentinel.ahk
#Include meta/adapters/input/test_textsend_callback_wired.ahk
#Include meta/infra/config/persistence/test_is_category_all_enabled_loop.ahk
#Include meta/adapters/test_regread_no_type_arg.ahk
#Include meta/infra/logger/test_logger_dedup_tick.ahk
#Include meta/modules/hotstrings/engine/test_hse_endchar_consumed_delimiters.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_watcher_magic_suffix.ahk
#Include meta/modules/hotstrings/magic_key/test_deadkey_uses_dynamic_magic_key.ahk
#Include meta/infra/toml/test_parse_overrides_seen_sections.ahk
#Include meta/modules/llm/api/test_llm_getactiveprofile_arg.ahk
#Include meta/infra/dispatch/test_tickcount_wrap_safe.ahk
#Include meta/infra/dispatch/test_tickcount_lib_wrap.ahk
#Include meta/modules/llm/api/test_llm_token_budget_min5.ahk
#Include meta/modules/llm/prediction/test_llm_parser_nul_strip.ahk
#Include meta/modules/keystats/ergonomics/test_ergo_pinky_modifier_skip.ahk
#Include meta/modules/keystats/context/test_watchers_idle_end_ordering.ahk
#Include meta/infra/dispatch/test_timer_scheduler_ms_guard.ahk
#Include meta/platform/network/test_http_cancel_aborts.ahk
#Include meta/adapters/input/test_keyboard_hook_vk_format.ahk
#Include meta/adapters/shell_runner/test_plc_stop_clears_callbacks.ahk
#Include meta/infra/toml/test_toml_coerce_quoted_commas.ahk
#Include meta/infra/i18n/test_i18n_setlocale_resets_fallback.ahk
#Include meta/modules/shortcuts/test_ws_save_atomic.ahk
#Include meta/platform/remap/tap_hold/test_tapholdwriter_int_before_bool.ahk
#Include meta/modules/llm/menu/test_llm_menu_toggle_reentrancy.ahk
#Include meta/modules/llm/menu/test_llm_menu_tab_source_hwnd.ahk
#Include meta/modules/llm/menu/test_modelbrowser_sort_callback.ahk
#Include meta/platform/remap/keys/test_space_taphold_configurable.ahk
#Include meta/modules/hotstrings/catalogue/test_terminators_requires_directive.ahk
#Include meta/modules/keymap/test_layout_poll_pending_hkl.ahk
#Include meta/modules/llm/api/test_llmbridge_stop_order.ahk
#Include meta/modules/llm/tooltip/test_llm_render_clears_dequeue.ahk
#Include meta/modules/gestures/test_search_shortcut_run_path_existence_guard.ahk
#Include meta/modules/updater/test_updater_swap_exit_guard.ahk
#Include meta/adapters/input/test_keyboard_hook_dispatch_error_logged.ahk
#Include meta/ui/menu/test_tray_menu_cleared_before_onboarding.ahk
#Include meta/ui/menu/test_tray_bootstrap_publication_transaction.ahk
#Include meta/infra/config/persistence/test_config_shortcuts_unescape_ordering.ahk
#Include meta/modules/gestures/test_gesture_selfactivated_bounded.ahk
#Include meta/modules/llm/api/test_llm_api_no_entry_logged.ahk
#Include meta/modules/llm/prediction/test_llm_cancel_not_under_critical.ahk
#Include meta/modules/llm/prediction/test_llm_dispatch_not_under_critical.ahk
#Include meta/modules/llm/servers/test_deps_fail_restores_priority.ahk
#Include meta/modules/llm/navigation/test_tab_accept_invalidates_inflight.ahk
#Include meta/modules/llm/navigation/test_llm_accept_suppress_balance.ahk
#Include meta/platform/remap/altgr/test_altgr_latch_dispatch_aborts.ahk
#Include meta/modules/gestures/test_gesture_click_hold_released_on_suspend.ahk
#Include meta/modules/gestures/test_gesture_click_hold_transaction.ahk
#Include meta/modules/keystats/ergonomics/test_walker_batch_drained_on_rollover_and_stop.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_none_sentinel.ahk
#Include meta/modules/llm/servers/test_deps_check_epoch_guard.ahk
#Include meta/modules/updater/test_updater_rebuild_resets_dispatcher.ahk
#Include meta/platform/remap/keys/test_capsword_reset_on_suspend.ahk
#Include meta/modules/shortcuts/test_capsword_auto_off_single_source.ahk
#Include meta/platform/remap/keys/test_capsword_space_release_timeout.ahk
#Include meta/modules/gestures/test_gesture_toggle_ui_errors_logged.ahk
#Include meta/ui/wpm/test_wpm_mousewatch_suspend_guard.ahk
#Include meta/ui/tooltip/test_tooltip_resolve_pos_profiled.ahk
#Include meta/infra/logger/test_error_net_guarded_send.ahk
#Include meta/infra/logger/test_error_net_dedup_throttle.ahk
#Include unit/infra/logger/test_error_report_dedup_ownership.ahk
#Include meta/infra/logger/test_error_net_uia_orphan_suppress.ahk
#Include meta/adapters/crash_report/test_deferred_crash_report_catch.ahk
#Include meta/modules/keystats/test_keystats_webview_bridge_and_i18n.ahk
#Include meta/modules/keystats/test_keystats_webview_range_bridge.ahk
#Include meta/modules/keystats/test_keystats_flush_atomic.ahk
#Include meta/modules/keystats/test_keystats_tick_overflow.ahk
#Include meta/modules/llm/api/test_llm_streaming_fixes.ahk
#Include meta/platform/remap/layers/test_layout_deadkey_endkey.ahk
#Include meta/platform/remap/keys/test_oneshotshift_endkeys.ahk
#Include meta/modules/hotstrings/magic_key/test_magic_key_capture.ahk
#Include meta/modules/gestures/test_gesture_restart_nonblocking.ahk
#Include meta/modules/gestures/test_gesture_open_url_run_guard.ahk
#Include meta/modules/shortcuts/test_addshortcut_registration_guard.ahk
#Include meta/modules/llm/navigation/test_gpt_hotkey_run_guard.ahk
#Include meta/ui/menu/test_menu_manifest_lifecycle_pair.ahk
#Include meta/infra/config/persistence/test_editor_persist_before_publish.ahk
#Include meta/modules/keystats/test_keystats_webview_epoch.ahk
#Include meta/modules/keystats/test_keystats_webview_callback_fail_safe.ahk
#Include meta/modules/keystats/test_keystats_clipboard_registration_transaction.ahk
#Include meta/modules/keystats/test_keystats_prefetch_worker.ahk
#Include meta/modules/keystats/test_keystats_prefetch_recovery.ahk
#Include meta/modules/shortcuts/test_sendinstant_clip_contention_guard.ahk
#Include meta/modules/shortcuts/test_sendinstant_clipboard_sequence_ownership.ahk
#Include meta/modules/gestures/test_plain_paste_clipboard_sequence_ownership.ahk
#Include meta/ui/onboarding/test_onboarding_gesture_registration_async.ahk
#Include unit/adapters/input/test_text_sender_completion_status.ahk
#Include unit/ui/windows/test_native_editor_completion.ahk
#Include unit/adapters/input/test_text_sender_sendinput_failure.ahk
#Include meta/platform/remap/layers/test_deadkey_unmapped_base_char.ahk
#Include meta/infra/config/persistence/test_savefullconfig_no_delete.ahk
#Include meta/modules/keystats/test_keystats_scan_max_id_tail.ahk
#Include meta/modules/gestures/test_gesture_screenshot_no_tempfile.ahk
#Include meta/adapters/test_wmexists_is_not_a_handle.ahk
#Include meta/platform/remap/tap_hold/test_taphold_scancodes_are_the_real_keys.ahk
#Include unit/adapters/test_crypto_sha256_is_real.ahk
#Include meta/platform/remap/keys/test_capslock_led_does_not_latch.ahk
#Include meta/modules/hotstrings/engine/test_hotstrings_deadkey_uppercase_cleanup.ahk
#Include meta/infra/toml/test_parser_splitblocks_cap.ahk
#Include meta/modules/llm/servers/test_ollama_trim_registry_min_id.ahk
#Include meta/adapters/input/test_clipwait_binary.ahk
#Include meta/infra/dispatch/test_timer_scheduler_oneshot_suspend.ahk
#Include meta/modules/hotstrings/catalogue/test_hotstrings_cache_atomic_write.ahk
#Include meta/modules/keystats/test_keystats_hook_global_try.ahk
#Include meta/modules/keystats/test_keystats_idle_defer_preserves_pending.ahk
#Include meta/modules/keystats/test_keystats_rollover_force_ingest.ahk
#Include meta/modules/keystats/test_keystats_rollover_transaction.ahk
#Include meta/modules/keystats/test_klnet_starter_deref.ahk
#Include meta/platform/remap/layers/test_nav_layer_hotkey_interval.ahk
#Include unit/modules/hotstrings/engine/test_hotstrings_escape_braces.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_send_failure_containment.ahk
#Include unit/modules/hotstrings/engine/test_title_timeout_does_not_eat_expansion.ahk
#Include unit/modules/hotstrings/engine/test_hse_send_failure_transaction.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_output_is_final.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_chaining.ahk
#Include unit/modules/hotstrings/engine/test_hotstring_cascade.ahk
#Include meta/modules/hotstrings/catalogue/test_hotstrings_combo_auto_escaping.ahk
#Include meta/modules/keystats/ergonomics/test_ergo_flow_gap_end.ahk
#Include meta/infra/config/persistence/test_config_window_patch_toml_meta_error.ahk
#Include meta/platform/remap/keys/test_capsword_mouse_clobber.ahk
#Include unit/infra/dispatch/test_timer_scheduler_suspend.ahk
#Include meta/modules/hotstrings/magic_key/test_magic_key_probe_deadkey_safe.ahk
#Include meta/ui/menu/test_script_shortcut_labels_locale.ahk
#Include meta/platform/remap/altgr/test_altgr_chord_debounce_per_slot.ahk
#Include meta/modules/keystats/ergonomics/test_roi_halflife_threshold_reachable.ahk
#Include meta/modules/hotstrings/engine/test_hse_notepad_consumed_delimiter.ahk
#Include meta/modules/hotstrings/engine/test_notepad_hotstring_atomic_burst.ahk
#Include unit/modules/llm/prediction/test_llm_parser_dedup_stats.ahk
#Include meta/modules/shortcuts/test_paste_without_formatting_restore.ahk
#Include meta/platform/remap/keys/test_hold_layer_release_bounded.ahk
#Include meta/platform/remap/keys/test_hold_layer_survives_long_press.ahk
#Include meta/infra/toml/test_toml_batchwrite_cache_coherence.ahk
#Include meta/modules/keystats/context/test_topology_debounce_settled_geometry.ahk
#Include meta/modules/keystats/context/test_topology_single_append.ahk
#Include meta/adapters/crash_report/test_crash_report_unique_filename.ahk
#Include meta/modules/gestures/test_gesture_paste_plain_busy_guard.ahk
#Include unit/modules/llm/api/test_llm_deadline_wrap.ahk
#Include meta/ui/windows/test_gr_drawbitmap_type_guard.ahk
#Include unit/ui/windows/test_gr_drawbitmap_closure.ahk
#Include meta/modules/gestures/test_gestures_action_catalog_deferred.ahk
#Include meta/modules/hotstrings/engine/test_hse_altgr_kana_sendinput.ahk
#Include meta/adapters/input/test_text_sender_clipboard_generation_recheck.ahk
#Include meta/adapters/input/test_text_sender_clipboard_suspend_guard.ahk
#Include meta/modules/llm/prediction/test_llm_output_physical_generation.ahk
#Include meta/adapters/input/test_text_sender_callback_on_bailout.ahk
#Include meta/adapters/shell_runner/test_shell_runner_poll_suspend_guard.ahk
#Include meta/adapters/shell_runner/test_shell_runner_legacy_claims.ahk
#Include meta/modules/gestures/test_screenshot_tree_owned_default.ahk
#Include meta/adapters/shell_runner/test_shell_runner_isolated_logger.ahk
#Include meta/adapters/uia/test_disable_password_fields_gate.ahk
#Include meta/modules/dynamic_hotstrings/test_menu_dynamic_hotstrings_category_gate.ahk
#Include meta/ui/menu/test_menu_master_category_cache.ahk
#Include unit/adapters/test_storage_st_delete_contract.ahk
#Include meta/infra/lifecycle/test_boot_dircreate_guarded.ahk
#Include meta/infra/toml/test_toml_render_bool_sentinel.ahk
#Include meta/modules/llm/menu/test_llm_menu_loaded_gate.ahk
#Include meta/platform/remap/altgr/test_altgr_dispatch_suspend_guard.ahk
#Include meta/modules/llm/prediction/test_llm_inject_complete_callback.ahk
#Include meta/modules/llm/prediction/test_ngram_esrc_json_accumulate.ahk
#Include meta/modules/llm/prediction/test_ngram_tables_not_cleared_on_refresh.ahk
#Include meta/platform/remap/keys/test_shift_digit_passthrough_not_shadowed.ahk
#Include meta/modules/llm/servers/test_deps_installer_pid_captured.ahk
#Include meta/modules/llm/api/test_llm_parse_billions_null_guard.ahk
#Include meta/platform/remap/keys/test_toggle_capslock_calls_disable_capsword.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_writer_inherit_defaults.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_persist_before_publish.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_picker_catalog_path.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_global_transaction.ahk
#Include meta/modules/llm/navigation/test_llm_nav_loop_ten.ahk
#Include meta/modules/llm/api/test_api_entries_persist_error_logged.ahk
#Include meta/modules/updater/test_updater_callback_suspend_guard.ahk
#Include meta/platform/remap/altgr/test_altgr_dispatch_resume_aware.ahk
#Include meta/modules/updater/test_updater_self_update_bak_rollback.ahk
#Include meta/modules/updater/test_updater_swap_failure_receipt.ahk
#Include meta/infra/lifecycle/test_bundle_resolve_dir_local_appdata.ahk
#Include meta/modules/hotstrings/personal/test_personal_shortcuts_compiled_include_path.ahk
#Include meta/modules/hotstrings/personal/test_personal_shortcuts_generator_encoding.ahk
#Include meta/modules/hotstrings/personal/test_personal_shortcuts_reload_handoff.ahk
#Include meta/modules/hotstrings/personal/test_personal_shortcuts_atomic_bootstrap.ahk
#Include meta/platform/remap/altgr/test_altgr_detect_hkl_fallback.ahk
#Include unit/platform/remap/altgr/test_altgr_detection.ahk
#Include unit/platform/remap/altgr/test_altgr_family_follows_layout.ahk
#Include unit/platform/remap/altgr/test_altgr_probe_real_layouts.ahk
#Include unit/modules/keymap/test_layout_digit_row_probe.ahk
#Include unit/modules/keymap/test_number_row_symbols.ahk
#Include unit/modules/keymap/test_layout_rows_policy.ahk
#Include unit/modules/keymap/test_pause_switch_policy.ahk
#Include unit/modules/keymap/test_pause_layout_switch.ahk
#Include unit/modules/keymap/test_number_row_native_hkl.ahk
#Include meta/platform/remap/altgr/test_altgr_kana_taphold_entry.ahk
#Include meta/platform/remap/altgr/test_altgr_prefix_arms_on_press.ahk
#Include unit/platform/remap/altgr/test_altgr_owner_matrix.ahk
#Include unit/platform/remap/altgr/test_altgr_combos_stand_down.ahk
#Include unit/platform/remap/key_combinations/test_script_chords_follow_their_slot.ahk
#Include unit/platform/remap/altgr/test_altgr_layer_shift_from_hold.ahk
#Include unit/platform/remap/key_combinations/test_ctrl_alt_numpad_gate.ahk
#Include unit/platform/remap/keys/test_user_lctrl_held.ahk
#Include unit/platform/remap/altgr/test_altgr_takes_its_lctrl.ahk
#Include unit/platform/remap/altgr/test_altgr_lctrl_not_typed.ahk
#Include meta/platform/remap/keys/test_prior_key_guards_use_helper.ahk
#Include meta/platform/remap/keys/test_modifier_hotkeys_single_identity.ahk
#Include meta/platform/remap/key_combinations/test_scan_code_shadows_key_name.ahk
#Include meta/ui/windows/test_spotlight_gdiplus_free_library.ahk
#Include meta/modules/shortcuts/test_case_transform_synthetic_mark.ahk
#Include meta/modules/gestures/test_color_dropdown_recompute_index.ahk
#Include meta/modules/gestures/test_color_picker_hotkey_nonblocking.ahk
#Include meta/modules/hotstrings/magic_key/test_magic_key_no_regex_inject.ahk
#Include meta/infra/logger/test_logger_fanout_batched.ahk
#Include meta/adapters/crash_report/test_crash_reporter_slash_precedence.ahk
#Include meta/infra/logger/test_logger_flush_on_error.ahk
#Include meta/adapters/test_atomic_write_unique_scratch.ahk
#Include unit/adapters/test_atomic_temp_owner.ahk
#Include meta/suite/test_byref_call_sites.ahk
#Include meta/adapters/uia/test_uia_probe_bounded.ahk
#Include meta/ui/healthcheck/test_healthcheck_collectors_guarded.ahk
#Include meta/modules/hotstrings/personal/test_personal_editor_section_guard.ahk
#Include meta/modules/gestures/test_gestures_init_lifecycle_pair.ahk
#Include meta/infra/config/persistence/test_paths_file_single_writer.ahk
#Include meta/modules/updater/test_changelog_fetch_status_logged.ahk
#Include meta/adapters/test_mutex_yield_is_recorded.ahk
#Include meta/infra/lifecycle/test_suspend_deferral_bounded.ahk
#Include meta/infra/lifecycle/test_shutdown_veto_bounded.ahk
#Include meta/infra/lifecycle/test_suspend_lifecycle_logged.ahk
#Include unit/infra/lifecycle/test_lifecycle_transition.ahk
#Include meta/suite/test_dead_state_and_single_source.ahk
#Include meta/infra/config/persistence/test_discarded_config_is_reported.ahk
#Include meta/modules/keystats/test_sql_replay_is_idempotent.ahk
#Include meta/platform/remap/key_combinations/test_keyboard_shortcut_slots_roundtrip.ahk
#Include meta/infra/config/persistence/test_config_failures_are_surfaced.ahk
#Include meta/adapters/crash_report/test_crash_report_not_suppressed.ahk
#Include meta/ui/menu/test_submenu_survives_publish.ahk
#Include meta/platform/remap/layers/test_keymap_hotpath_guards.ahk
#Include meta/platform/remap/layers/test_keymap_deadkey_emit_serialized.ahk
#Include meta/platform/remap/layers/test_deadkey_ring_push.ahk
#Include meta/platform/remap/altgr/test_altgr_callbacks_serialized.ahk
#Include meta/infra/dispatch/test_hook_dispatcher_critical_save_restore.ahk
#Include meta/infra/dispatch/test_hook_dispatcher_err_cache_cap.ahk
#Include meta/modules/keystats/ergonomics/test_walker_batch_critical.ahk
#Include meta/modules/keystats/ergonomics/test_walker_pure_fns_match_shared_core.ahk
#Include meta/modules/keystats/test_keystats_critical_restore.ahk
#Include meta/modules/keystats/context/test_async_password_detect_suspend_guard.ahk
#Include meta/modules/keystats/context/test_sensors_warmup_distinct_callback.ahk
#Include meta/modules/keystats/context/test_kltopo_seen_hwnds_cap.ahk
#Include meta/platform/remap/layers/test_remapped_list_unconditional.ahk
#Include meta/ui/wpm/test_wpm_widget_color_cache.ahk
#Include meta/modules/gestures/test_screenshot_async_run.ahk
#Include meta/platform/remap/keys/test_space_hold_empty_guard.ahk
#Include meta/modules/llm/navigation/test_profile_hotkey_stable_pred.ahk
#Include meta/modules/updater/test_updater_download_timeout.ahk
#Include meta/modules/gestures/test_mouse_control_physical_cursor.ahk
#Include meta/adapters/crash_report/test_crash_prompt_blocking_msgbox.ahk
#Include meta/platform/remap/key_combinations/test_keyboard_shortcut_groups_register_dispatch.ahk
#Include meta/modules/updater/test_changelog_fetch_async.ahk
#Include meta/platform/network/test_curl_response_size_bound.ahk
#Include meta/platform/network/test_curl_personal_config_disabled.ahk
#Include meta/modules/updater/test_curl_staging_failure_cleanup.ahk
#Include meta/modules/updater/test_changelog_webview_bridge.ahk
#Include meta/modules/llm/menu/test_model_browser_webview_bridge.ahk
#Include meta/modules/hotstrings/catalogue/test_deferred_ext_scan_critical_file_io.ahk
#Include meta/ui/wpm/test_wpm_compact_color_validation.ahk
#Include meta/platform/remap/keys/test_backspace_repeat_suspend_guard.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_render_flush_suspend_guard.ahk
#Include meta/modules/gestures/test_gesture_dispatch_logs_failure.ahk
#Include meta/modules/llm/servers/test_ollama_installer_sync_winhttp_blocks.ahk
#Include meta/modules/llm/servers/test_ollama_delete_model_async.ahk
#Include meta/modules/updater/test_updater_download_resilience.ahk
#Include meta/adapters/input/test_key_state_dllcall_guards.ahk
#Include meta/modules/updater/test_updater_loadchannel_try_wrap.ahk
#Include meta/adapters/crash_report/test_crash_report_sysinfo_dedup.ahk
#Include meta/infra/logger/test_logger_dedup_exit_flush.ahk
#Include meta/infra/logger/test_logger_repeat_collapsing.ahk
#Include meta/adapters/shell_runner/test_shell_runner_boot_crash_and_quoting.ahk
#Include meta/infra/dispatch/test_hotpath_priority_starvation.ahk
#Include meta/suite/test_priority_baseline_single_source.ahk

; -- Previously-orphaned regression tests (on disk but never wired into the
;    runner; re-wired so they actually execute). All were silently skipped; the
;    four that "failed" turned out to be test bugs (wrong A_ScriptDir-relative
;    path, first-call-vs-definition match, elapsed- vs deadline-form poll, a
;    comment tripping a substring guard), not real code regressions — fixed. --
#Include meta/infra/dispatch/test_bypass_dispatch_arity.ahk
#Include meta/modules/hotstrings/catalogue/test_hcw_reset_all_teardown.ahk
#Include meta/ui/healthcheck/test_healthcheck_sysinfo_git_nonblocking.ahk
#Include meta/modules/keystats/test_keystats_pause_metrics.ahk
#Include meta/adapters/test_processentry32w_size.ahk
#Include meta/platform/remap/altgr/test_script_altgr_hotkeys.ahk
#Include meta/platform/remap/keys/test_space_hold_exception_guard.ahk
#Include meta/modules/llm/api/test_stream_handle_type.ahk
#Include meta/modules/llm/api/test_warmup_backoff_preserved.ahk
; These three were orphaned with their own (duplicate or pure-scan) includes;
; the duplicate test_framework.ahk includes were stripped so they integrate.
#Include meta/adapters/test_dpapi_blob_size.ahk
; The diagnostics window's sources are headless-safe: function definitions and
; their globals only, no top-level side effects.
#Include ../ui/healthcheck/core.ahk
; The local reload control rides the Diagnostics endpoint owner above.
#Include ../infra/driver_control.ahk
#Include unit/infra/control/test_driver_control.ahk
#Include unit/infra/control/test_driver_control_cli.ahk
#Include ../ui/healthcheck/collection.ahk
#Include unit/ui/webview/test_ui_warm_hosts.ahk
#Include ../ui/healthcheck/helpers.ahk
#Include ../ui/healthcheck/probes.ahk
#Include ../ui/healthcheck/report.ahk
#Include ../ui/healthcheck/actions.ahk
#Include ../ui/healthcheck/configuration.ahk
#Include unit/platform/remap/altgr/test_kana_altgr_readers.ahk
#Include unit/platform/remap/altgr/test_kana_altgr_lift_respects_owner.ahk
#Include unit/platform/remap/altgr/test_kana_altgr_ctrl_chords.ahk
#Include ../ui/error_dialog/init.ahk
#Include unit/ui/windows/test_error_dialog.ahk
#Include unit/ui/windows/test_window_title_captions.ahk
#Include ../ui/update_check/init.ahk
#Include unit/modules/updater/test_updater_result_dialog_states.ahk
#Include meta/modules/updater/test_updater_manual_check_uses_dialog.ahk
#Include unit/ui/healthcheck/test_healthcheck_os_name_windows11.ahk
#Include unit/ui/healthcheck/test_healthcheck_issues_from_errors_file.ahk
#Include unit/ui/healthcheck/test_healthcheck_report_issue.ahk
#Include meta/corpus/test_corpus_diagnostics.ahk

; Guards the _HsEdWeb_Reset() idempotency fix for the live-log access-violation
; crash (double-unsubscribe against an already torn-down WebView2 controller).
#Include meta/modules/hotstrings/catalogue/test_hsedweb_reset_idempotent.ahk

; Same idempotency-guard shape, verified in the 6 sibling WebView2 hosts that
; got the identical F7 fix applied.
#Include meta/ui/webview/test_webview_reset_idempotent_siblings.ahk
#Include meta/modules/updater/test_updater_onjson_callback_catch.ahk
#Include meta/ui/webview/test_webview_bridge_suspend_guard.ahk
#Include meta/modules/updater/test_changelog_close_order.ahk
#Include meta/modules/updater/test_updater_changelog_install_closegui.ahk
; MCSetPos/MCGetPos bare-try-no-catch fix (F32).
#Include meta/modules/gestures/test_mouse_control_error_logging.ahk
; TooltipRHide bare-try-no-catch + TooltipRShow OutputDebug-instead-of-Logger fix (F50).
#Include meta/ui/tooltip/test_tooltip_renderer_error_logging.ahk
; WMGetList/WIGetAll bare-try-no-catch fix (F33) — sibling of the
; GestureGetCyclableWindows TOCTOU guard (commit 7b701020d).
#Include meta/adapters/test_window_adapters_catch.ahk
#Include meta/ui/onboarding/test_onbweb_singleton_guard.ahk
#Include meta/infra/config/persistence/test_reset_config_writes_meta_placeholder.ahk
#Include meta/ui/webview/test_webview_shared_env_reentrancy_guard.ahk
#Include meta/ui/webview/test_webview_host_callback_epoch.ahk
; AltTabMonitor bare-try-no-catch fix (F37) — sibling of the
; GestureGetCyclableWindows TOCTOU guard (commit 7b701020d).
#Include meta/modules/gestures/test_alt_tab_monitor_catch.ahk
#Include meta/modules/keystats/metrics/test_metrics_shortcut_persist_guard.ahk
#Include meta/modules/keystats/metrics/test_metrics_shortcut_transaction.ahk
#Include meta/modules/keystats/metrics/test_metrics_app_time_accuracy.ahk
#Include meta/infra/config/persistence/test_toggle_category_all_features_atomic.ahk
#Include meta/adapters/test_crypto_djb2_fallback_logged.ahk
#Include meta/adapters/test_adapter_callback_swallow_logged.ahk
#Include meta/modules/llm/prediction/test_llm_callbacks_never_swallowed.ahk
#Include meta/modules/llm/prediction/test_llm_inflight_hygiene.ahk
#Include meta/modules/llm/api/test_llm_semantic_config_class.ahk
#Include meta/ui/wpm/test_wpm_widget_consistency.ahk
#Include meta/modules/keystats/ergonomics/test_marker_and_heatmap_completeness.ahk
#Include meta/adapters/input/test_text_send_direct_mode_guarded.ahk
#Include meta/platform/network/test_http_post_reentrancy_guard.ahk
#Include meta/modules/hotstrings/personal/test_personal_editor_autoexpand_i18n.ahk
#Include meta/infra/toml/test_jsstr_cr_escaped.ahk
#Include meta/infra/toml/test_json_string_literal_single_source.ahk
#Include meta/infra/toml/test_json_string_decoder_single_source.ahk
#Include meta/infra/toml/test_toml_string_codec_single_source.ahk
#Include meta/modules/hotstrings/magic_key/test_magic_key_editor_reopen_presents.ahk
#Include meta/modules/updater/test_update_check_window_presented.ahk
#Include meta/modules/hotstrings/catalogue/test_hs_delimiter_dialog_reachable.ahk
#Include meta/ui/windows/test_ui_style_llm_tray_i18n.ahk
#Include meta/modules/llm/servers/test_ollama_webview_msgsub_retained.ahk
#Include meta/modules/gestures/test_open_downloads_catch.ahk
#Include meta/modules/gestures/test_takenote_winmaximize_guard.ahk
#Include meta/modules/hotstrings/personal/test_personal_info_combo_generation.ahk
#Include meta/modules/hotstrings/personal/test_personal_combo_letters_guard.ahk
#Include meta/suite/test_driver_pid_single_source.ahk
#Include meta/platform/remap/tap_hold/test_taphold_timings_load_order.ahk
#Include meta/modules/hotstrings/engine/test_suspend_resets_hse_context.ahk
#Include meta/platform/remap/keys/test_capsword_parse_time_callback.ahk
#Include meta/infra/config/persistence/test_config_shortcuts_inline_comment.ahk
#Include meta/infra/config/persistence/test_savefullconfig_llm_loaded_gate.ahk
#Include meta/adapters/test_single_instance_mutex_first.ahk
#Include meta/infra/config/persistence/test_master_gate_drifted_subgate_skip.ahk
#Include meta/platform/remap/keys/test_rctrl_lalt_hotif_gated.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_keydown_ctrl_backspace_reset.ahk
#Include meta/modules/hotstrings/prefix/test_prefix_index_rebuild_suspend_replay.ahk
#Include meta/infra/lifecycle/test_suspend_transition_serialized.ahk
#Include meta/modules/shortcuts/test_wrap_selection_clip_fallback.ahk
#Include meta/modules/shortcuts/test_uia_selection_poll_boot_gated.ahk
#Include meta/platform/remap/tap_hold/test_tap_hold_synthetic_up_suspend_guard.ahk
#Include meta/modules/hotstrings/catalogue/test_menu_delay_prompt_rebuild.ahk
#Include meta/modules/gestures/test_gesture_edit_shortcuts_no_reload.ahk
#Include meta/modules/gestures/test_gesture_screenshot_instant_completion.ahk
#Include meta/modules/hotstrings/catalogue/test_live_rebuild_no_critical_io.ahk
#Include meta/modules/keystats/metrics/test_metrics_focus_refresh_suspend_guard.ahk
#Include meta/modules/llm/tooltip/test_llm_loading_tooltip_no_safety_deadline.ahk
#Include meta/ui/onboarding/test_onboarding_gesture_result_token.ahk
#Include meta/infra/lifecycle/test_suspend_prefix_drain_covers_all_combos.ahk
#Include meta/modules/hotstrings/catalogue/test_hotstring_case_sensitivity_mapping.ahk
#Include meta/modules/llm/profiles/test_prompt_editor_singleton_context.ahk
#Include meta/ui/webview/test_webview_deferred_host_actions.ahk
#Include meta/modules/shortcuts/test_wrap_symbols_load_flush.ahk
#Include unit/modules/shortcuts/test_wrap_symbols_unreadable_blocks_save.ahk
#Include unit/infra/config/persistence/test_unreadable_config_never_persisted.ahk
#Include meta/ui/windows/test_app_picker_sort_safe_selection.ahk
#Include meta/modules/updater/test_changelog_ready_not_stranded.ahk
#Include meta/modules/hotstrings/catalogue/test_hcw_bulk_writers_republish.ahk
#Include meta/modules/hotstrings/catalogue/test_hcw_patch_toml_meta_refuses_unread_file.ahk
#Include meta/ui/healthcheck/test_healthcheck_singleton_destroys_window.ahk
#Include meta/modules/keystats/test_ingest_offset_respects_batch_limit.ahk
#Include meta/modules/keystats/test_kl_payload_privacy_filter.ahk
#Include meta/modules/keystats/test_kl_stop_shutdown_ingest_forced.ahk
#Include meta/modules/keystats/test_keystats_shutdown_timer_durability.ahk
#Include meta/modules/llm/prediction/test_llm_finalize_guard_before_yield.ahk
#Include meta/modules/llm/prediction/test_llm_indexed_callbacks_never_swallowed.ahk
#Include meta/modules/llm/menu/test_llm_model_menu_no_model_row_actionable.ahk
#Include meta/modules/llm/profiles/test_llm_profile_menu_unique_labels.ahk
#Include meta/infra/i18n/test_locale_tsv_atomic_write.ahk
#Include meta/ui/menu/test_menu_manifest_single_decode.ahk
#Include meta/ui/menu/test_menu_prune_keeps_detached_registrations.ahk
#Include meta/modules/keystats/metrics/test_metrics_filter_secure_field_fails_closed.ahk
#Include meta/modules/keystats/context/test_network_info_single_wlan_roundtrip.ahk
#Include meta/ui/onboarding/test_onboarding_unbraced_if_scope.ahk
#Include meta/modules/hotstrings/personal/test_personal_info_save_surfaces_failure.ahk
#Include meta/modules/llm/servers/test_remote_curl_forwards_usage_meta.ahk
#Include meta/modules/llm/servers/test_remote_token_not_on_argv.ahk
#Include meta/adapters/uia/test_secure_field_native_detect_conclusive_order.ahk
#Include meta/adapters/uia/test_secure_field_probes_focused_element.ahk
#Include meta/adapters/uia/test_secure_field_stale_verdict_fails_closed.ahk
#Include meta/adapters/uia/test_secure_field_uia_probe_guards.ahk
#Include meta/modules/keystats/ergonomics/test_today_bucket_slots_all_fed.ahk
#Include meta/ui/tooltip/test_tooltip_expiry_anchored_at_request.ahk
#Include meta/ui/tooltip/test_tooltip_expiry_timers_keep_preview.ahk
#Include meta/ui/tooltip/test_tooltip_uia_gate_reachable.ahk
#Include meta/modules/hotstrings/engine/test_uia_wrap_resets_both_buffers.ahk
#Include meta/modules/updater/test_updater_releases_list_cancellable.ahk
#Include meta/modules/updater/test_updater_worker_terminated_on_exit.ahk
#Include meta/ui/webview/test_webview_reset_guard_class.ahk
#Include meta/ui/wpm/test_wpm_graph_mode_draggable.ahk
#Include meta/ui/wpm/test_wpm_rebuilt_surface_is_sized.ahk
#Include unit/modules/hotstrings/catalogue/test_activate_hotstrings_commits_synchronously.ahk
#Include unit/infra/toml/test_cache_builder_strips_header_comment.ahk
#Include unit/infra/lifecycle/test_bundle_skip_validation.ahk
#Include unit/infra/lifecycle/test_startup_smoke_receipt.ahk
#Include unit/modules/shortcuts/test_clipboard_history_paste.ahk
#Include unit/modules/updater/test_changelog_request_epoch.ahk
#Include unit/modules/updater/test_changelog_network_resilience.ahk
#Include unit/infra/config/persistence/test_config_toml_single_writer.ahk
#Include unit/infra/toml/test_derived_toml_caches_not_memoised_on_failed_read.ahk
#Include unit/modules/hotstrings/engine/test_fire_log_callable_replacement.ahk
#Include unit/modules/hotstrings/engine/test_fire_log_suspend_boundary.ahk
#Include unit/infra/config/persistence/test_group_config_cache_alias_invalidation.ahk
#Include unit/infra/dispatch/test_hotpath_profiler_exclusive.ahk
#Include unit/infra/dispatch/test_hotpath_latency_statistics.ahk
#Include unit/infra/dispatch/test_hotpath_breakdown_reentry.ahk
#Include unit/infra/dispatch/test_hook_timing_input_privacy.ahk
#Include unit/infra/dispatch/test_hotpath_per_segment_threshold.ahk
#Include unit/modules/keystats/test_keystats_today_fh_flush.ahk
#Include unit/modules/llm/prediction/test_llm_cache_hit_logs_suggested.ahk
#Include unit/modules/llm/api/test_llm_keep_alive_from_shared_defaults.ahk
#Include unit/modules/llm/prediction/test_llm_parser_refuses_uninjectable_deletes.ahk
#Include unit/infra/logger/test_logger_preinit_level.ahk
#Include unit/infra/logger/test_logger_set_level_transaction.ahk
#Include unit/infra/logger/test_logger_sub_files_multiline_arrays.ahk
#Include unit/modules/hotstrings/engine/test_marker_substituted_in_replacement.ahk
#Include unit/infra/config/persistence/test_master_gates_not_persisted.ahk
#Include unit/infra/toml/test_parse_toml_file_sticky_unreadable.ahk
#Include unit/modules/hotstrings/personal/test_personal_info_unreadable_never_persisted.ahk
#Include unit/modules/hotstrings/personal/test_personal_read_clears_unreadable_latch.ahk
#Include unit/modules/hotstrings/personal/test_personal_reload_bakes_resolved_delay.ahk
#Include unit/modules/keystats/test_prefetch_apps_list_deduped.ahk
#Include unit/modules/keystats/test_prefetch_dbg_write_level_gated.ahk
#Include unit/adapters/shell_runner/test_worker_spawn_args_are_strings.ahk
#Include unit/modules/keystats/test_keystats_prefetch_worker_failure.ahk
#Include unit/modules/hotstrings/preview/test_preview_picks_engine_winner.ahk
#Include unit/modules/hotstrings/personal/test_priority_missing_defaults_to_common.ahk
#Include unit/modules/hotstrings/preview/test_preview_uses_by_trigger_index.ahk
#Include unit/modules/hotstrings/engine/test_repeat_key_honours_rebuild_fence.ahk
#Include unit/adapters/shell_runner/test_shell_runner_legacy_state_machine.ahk
#Include unit/adapters/shell_runner/test_shell_runner_multiline_arg.ahk
#Include unit/adapters/shell_runner/test_shell_runner_tree_owned.ahk
#Include unit/modules/llm/servers/test_ollama_install_files_port.ahk
#Include unit/modules/llm/servers/test_ollama_runtime_owner.ahk
#Include unit/modules/llm/servers/test_ollama_managed_bootstrap.ahk
#Include unit/modules/llm/servers/test_ollama_managed_origin.ahk
#Include unit/modules/llm/servers/test_ollama_managed_model_offer.ahk
#Include unit/modules/shortcuts/test_run_program_actions.ahk
#Include unit/modules/shortcuts/test_run_program_actions_custody.ahk
#Include unit/modules/shortcuts/test_program_providers.ahk
#Include unit/adapters/shell_runner/test_shell_runner_launch_cleanup.ahk
#Include unit/adapters/shell_runner/test_shell_runner_native_argv.ahk
#Include unit/adapters/shell_runner/test_shell_runner_nul_arguments.ahk
#Include unit/adapters/shell_runner/test_shell_runner_native_exit_code.ahk
#Include unit/adapters/shell_runner/test_shell_runner_exit_query_failure.ahk
#Include unit/adapters/shell_runner/test_shell_runner_native_ownership.ahk
#Include unit/adapters/shell_runner/test_shell_runner_native_teardown.ahk
#Include unit/adapters/shell_runner/test_shell_runner_tree_native_refusal.ahk
#Include unit/adapters/shell_runner/test_shell_runner_tree_close_recovery.ahk
#Include unit/adapters/shell_runner/test_shell_runner_capture_debt.ahk
#Include unit/adapters/shell_runner/test_shell_runner_capture_lock.ahk
#Include unit/adapters/shell_runner/test_shell_runner_creator_debt.ahk
#Include unit/adapters/shell_runner/test_shell_runner_completion_pause.ahk
#Include unit/adapters/shell_runner/test_shell_runner_deferred_completion.ahk
#Include unit/adapters/shell_runner/test_shell_runner_tree_deferred_completion.ahk
#Include unit/adapters/crash_report/test_crash_report_worker_transport.ahk
#Include unit/adapters/crash_report/test_crash_mapping_drain_reentry.ahk
#Include unit/adapters/crash_report/test_crash_mapping_payload_bounds.ahk
#Include unit/adapters/crash_report/test_crash_worker_git_exit.ahk
#Include unit/adapters/crash_report/test_crash_worker_fixture_cleanup.ahk
#Include unit/adapters/crash_report/test_crash_worker_attempt_ownership.ahk
#Include unit/adapters/crash_report/test_crash_worker_deadline.ahk
#Include unit/platform/remap/tap_hold/test_taphold_inherit_defaults_roundtrip.ahk
#Include unit/platform/remap/tap_hold/test_taphold_synthetic_refcount_combo.ahk
#Include unit/platform/remap/tap_hold/test_taphold_synthetic_user_held.ahk
#Include unit/platform/remap/tap_hold/test_taphold_unreadable_blocks_rewrite.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_global_transaction.ahk
#Include unit/platform/remap/tap_hold/test_tap_hold_duration_transaction.ahk
#Include unit/ui/tooltip/test_tooltip_row_band_elision.ahk
#Include meta/infra/lifecycle/test_boot_profile_retroactive_stamps.ahk
#Include meta/modules/shortcuts/test_clipboard_history_paste_wiring.ahk
#Include meta/suite/test_fast_timer_inventory.ahk
#Include meta/modules/gestures/test_gestures_bulk_actions_ahk_reachable.ahk
#Include meta/modules/gestures/test_gesture_constants_available_to_onboarding.ahk
#Include meta/infra/dispatch/test_hotpath_segment_coverage.ahk
#Include meta/modules/llm/api/test_llm_health_probe_constants.ahk
#Include meta/ui/menu/test_menu_manifest_one_decoder.ahk
#Include meta/ui/menu/test_menu_reload_preserves_suspend.ahk
#Include meta/infra/lifecycle/test_reload_pending_contract.ahk
#Include meta/ui/menu/test_menu_shortcut_groups_spliced_once.ahk
#Include meta/modules/keystats/metrics/test_metrics_private_title_memo.ahk
#Include meta/modules/llm/servers/test_ollama_async_registry_is_curl_only.ahk
#Include meta/modules/hotstrings/personal/test_personal_save_rebuilds_preview_index.ahk
#Include meta/platform/remap/tap_hold/test_taphold_hold_gate_arms_without_tap.ahk
#Include meta/ui/tooltip/test_tooltip_debounce_is_load_bearing.ahk
#Include meta/ui/tooltip/test_tooltip_present_subsegmented.ahk
#Include meta/ui/tooltip/test_tooltip_reveal_zorder.ahk
#Include meta/ui/tooltip/test_tooltip_border_ring_region.ahk
#Include meta/ui/tooltip/test_tooltip_render_accounting.ahk
#Include meta/ui/menu/test_tray_suspend_checkmark_survives_rebuild.ahk
#Include meta/adapters/uia/test_uia_clamp_every_probe_site.ahk
#Include meta/adapters/uia/test_uia_poll_segment_bounded.ahk
#Include meta/modules/hotstrings/catalogue/test_hcw_reset_all_republishes.ahk
#Include meta/modules/llm/navigation/test_llm_inline_autotype_staleness.ahk
#Include meta/modules/keystats/ergonomics/test_walker_batch_has_an_inprocess_drain.ahk
#Include unit/modules/keystats/ergonomics/test_walker_title_cap_enforced.ahk
#Include meta/suite/test_suite_watchdog_manifest.ahk
#Include meta/suite/test_suite_unique_includes.ahk

#Include unit/adapters/test_file_read_activity.ahk

#Include fixtures/r7_held_stage_retirement.ahk

; Watchdog: kill the process if RunTests() never returns (e.g. a corpus
; consumer blocks on a synchronous HTTP call, an InputHook with no timeout,
; or a blocking dialog in a headless CI context). The current corpus normally
; now includes measured full-cohort file authority work. The finite 120-minute
; cap reserves five minutes below CI's process bound for partial TAP validation.
global _SUITE_STARTUP_BUDGET_MS := 120000
global _SUITE_PER_TEST_BUDGET_MS := 650
global _SUITE_MAX_TIMEOUT_MS := 7200000
global _SUITE_TIMEOUT_MS := _SuiteTimeoutForCount(TEST_REGISTRY.Length)

; Saturation deliberately reserves time for CI to publish partial results.
_SuiteTimeoutForCount(PlannedCount) {
	global _SUITE_MAX_TIMEOUT_MS, _SUITE_STARTUP_BUDGET_MS, _SUITE_PER_TEST_BUDGET_MS
	return Min(_SUITE_MAX_TIMEOUT_MS,
		_SUITE_STARTUP_BUDGET_MS + PlannedCount * _SUITE_PER_TEST_BUDGET_MS)
}

_WatchdogFire() {
	; Preserve the exact partial execution list before force-exiting. The CI
	; validator rejects any missing RUNNING/result pair.
	try _CopyTestResultsForCi()
	try FileAppend("`n[WATCHDOG] Test suite timed out after " . _SUITE_TIMEOUT_MS . " ms - force-exiting.`n", "*")
	ExitApp(2)
}
SetTimer(_WatchdogFire, -_SUITE_TIMEOUT_MS)

; Drive everything. RunTests prints a TAP-style report to stdout and exits
; with the appropriate code — control never returns from this call.

RunTests()
