# Qualified portable central builder and caller root cleanup

This packet composes the independent-only central builder proposal with the
repaired canonical R2 owning103 corpus, unchanged durable33 builder/admission
controls, and seven durable caller root cleanup controls. It remains outside the
checkout. No source, index, reference, workflow or API mutation occurred.

The actual frozen bootstrap counter failed one assertion, with no helper errors
or skips: after the owned root was renamed and a genuine foreign directory
created at the same name, the original real `setUpClass` deleted its marker.
The original builder environment check raised its exact `BuildRefused`, and the
original fixture close ran once. The same counter passed against the corrected
caller; its foreign root survived and the exact initial exception propagated.
The outer private directory owner safely retired both genuine names afterward.
Swift/compiler/signing/Security and the native process owner were modeled; the
file operations were actual POSIX operations. This is not a historical Darwin
Automation failure attribution.

The caller now refuses known root identity divergence before bootstrap cleanup
and teardown receipt reads. Original fixture cleanup is still attempted. Root
removal requires the existing physical capture/child/trust/keychain debts and
closed/active state to be settled. Cleanup failures remain recorded as exact
objects and cannot replace the initial bootstrap exception. No new child owner,
settle invocation or clock was introduced. The identity admission is bounded:
this packet does not claim atomic deletion against a concurrent replacement
after the pathname check.

The seven permanent controls cover the actual bootstrap replacement path,
ordinary bootstrap cleanup, genuine open capture-FD debt, exact primary
precedence on a modeled physical close failure, ordinary teardown with original
receipt/image assertions, a copied same-name foreign teardown root, and genuine
teardown capture-FD debt. All outer exact descriptors and private names were
retired. Each strict provider accepts only its exact reviewed classes/methods;
six extra/missing/foreign-module mutations were refused.

The first physical default alphabetical136 run completed135 tests successfully
and failed one assertion, with zero errors/skips. The failing old test expected
the inline compiler argv in the client after the actual recipe moved to the
builder. Its authorized correction parses the real builder's compiler call and
requires the original xcrun/swiftc/parse-as-library/diagnostics prefix. It also
parses the actual caller's fixed file loader, module execution, owned fixture
construction and single build invocation. A real private-file compiler macro
mutation and a wrong caller loader-path mutation each fail an assertion with
zero helper errors. No comment/literal spoof was added. Every original causal
stage assertion before this relocated check is byte exact. This is the sole
changed original owning103 function; all other103 functions remain byte exact.

The final physical CLI run uses the candidate's own `__file__`, fixed provider
loaders, and actual default unittest alphabetical discovery: **143 passed,
0 failed, 0 errors, 0 skipped**, in45.411seconds. The33 provider remains whole-file
exact. The original root counter red, corrected green, six supplementary greens,
durable7 green, physical136 red, and physical143 green logs/receipts remain
distinct. The earlier independent receive103 replay used candidate objects but
live source-read paths and declaration-order discovery. Its historical success
is bounded accordingly; it is not relabeled as complete candidate qualification.

Apply exactly seven paths from `combined-proposal.patch`, whose preimages bind
the corrected R2 owningtest3f9d0468, true registry8e557928, R2 native fixture54fc39d4,
and original independent client191ac290. New paths are the central builder and
two fixed test providers. No shared Swift factory, native entrypoint, production
Main/Package, sourcePAC10, workflow or unrelated registry census changes occur.
Both original native client test methods and script body remain byte exact.
The caller `setUpClass` and `tearDownClass` change; the old assertion that thirteen
other direct functions remained exact therefore no longer applies. All other
caller function spans remain exact. The native fixture `_command`, `close` and
`trust` retain the original corrected R2/guard spans exactly.

The physical subject contains all18 whole recipe inputs and additional actual
caller, helper, owning suite and Swift source-observation files. Their final
hashes are recorded. The18 recipe pins match the frozen predecessor graph.
This final snapshot does not invent an original before/after byte fence.
Source hashes do not qualify Swift/Python native binaries or pay ownership debt.

Ruff check/format and private whole-file forward/inverse application passed for
the final bytes. New imports are standard library only, including local `ast`
for the relocation predicate and `importlib.abc` for the modeled compiler loader.
Each provider loads fixed repository paths; there is no ambient executable,
feature selector, new dependency package or timeout increase. Constructor-startup
control22 is excluded because that seam is absent from the independent proposal.

Native compilation/signing/Security, genuine Darwin clock joining, XCTest,
packaging and installation remain **not executed** for this packet. The shared
Swift factory role remains unactivated. The parent owns canonical selected gates
and all subsequent source adoption, ownership coordination and hosted receiving.
