from pathlib import Path
root=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/unit/adapters')
for name,expected in [('test_adapter_contract_vectors.ahk',17),('test_adapter_contract_vectors_system.ahk',23)]:
 p=root/name;s=p.read_text(encoding='utf-8-sig')
 assert s.count('Err := E.Message')==s.count('Assert(Err = "",')==s.count('Err := ""')==expected
 s=s.replace('Err := ""','Err := "", ContractThrew := false')
 s=s.replace('Err := E.Message','ContractThrew := true\n\t\t\tErr := E.Message')
 s=s.replace('Assert(Err = "",','Assert(!ContractThrew,')
 assert s.count('ContractThrew := true')==expected and s.count('Assert(!ContractThrew,')==expected
 p.write_text(s,encoding='utf-8-sig',newline='\n')
