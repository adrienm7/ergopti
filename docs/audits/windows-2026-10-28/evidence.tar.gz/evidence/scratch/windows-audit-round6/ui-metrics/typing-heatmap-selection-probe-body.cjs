
const page=loadMetricsTypingPage('windows');freezePageClock(page,'2026-01-05T12:00:00Z');
publishTypingPage(page,'windows',{'2026-01-05':{Editor:{chars:7,time:7000,hourly:{'09':{c:7}}},Browser:{chars:11,time:11000,hourly:{'09':{c:11}}}}});
const before=page.elements.get('hour_weekday_heatmap_container').innerHTML;
page.context.deselect_all_apps();page.context.close_app_modal();
const after=page.elements.get('hour_weekday_heatmap_container').innerHTML;
const tooltip=Array.from(after.matchAll(/<title>([^<]+)<\/title>/g),m=>m[1]).find(x=>x.includes('09h')&&!x.includes(page.context._t('ui_typing.heatmap_hour_no_keystrokes')));
console.log(JSON.stringify({mode:vm.runInContext('app_state.app_selection_mode',page.context),rawIsZero:page.elements.get('global_details').innerHTML.includes('>0</strong>'),heatmapUnchanged:after===before,stillPopulatedTooltip:tooltip,errors:page.diagnostics.filter(x=>x.level==='error')}));
assert.ok(after.includes(`<title>${page.context._t('ui_typing.heatmap_day_mon')} 09h — ${page.context._t('ui_typing.heatmap_hour_no_keystrokes')}</title>`),'deselecting all apps must empty the selected-scope heatmap');
