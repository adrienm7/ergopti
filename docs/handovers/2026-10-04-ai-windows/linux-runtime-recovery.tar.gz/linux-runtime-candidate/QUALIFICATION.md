<!-- linux-runtime-candidate/QUALIFICATION.md -->

# Scratch owned-process qualification

The candidate is outside the repository and has not been adopted or registered.
It implements no Ollama installer, daemon controller, menu action or preference
write. The native fixtures execute real Python processes through real libuv;
they do not qualify an actual Ollama installation or model.

## Final corrected results

All commands ran serially after the parent explicitly released the focused
native slot, using `/workspace/ergopti-env.sh` and
`/workspace/ergopti-native-env.sh`.

| Runtime | Independent native seams | Actual process cases | Causal mutants |
| --- | ---: | ---: | ---: |
| `/workspace/.native/bin/luajit` | 17 passed, 0 failed | 10 passed, 0 failed | 6 rejected, 0 escaped |
| `/workspace/.native/bin/lua5.4` | 17 passed, 0 failed | 10 passed, 0 failed | 6 rejected, 0 escaped |

The independent wrapper failure/timeout teardown probe passed 2 cases, with
actual leader and descendant identities absent afterward. Each successful native
process probe physically reaped two adopted descendants. Every native case
required `uv.loop_alive()` to become false. Final result: 54 product cases pass,
12 causal mutant rejection receipts, 2 wrapper teardown cases pass.

The first corrected wrapper attempt reported 10 native cases passed, then failed
because this kernel does not expose the optional
`/proc/<pid>/task/<pid>/children` file. The harness now derives actual parent-child
ownership from standard binary `/proc/<pid>/stat` PPID receipts. Both affected
native probes and the independent failure teardown cases passed after that
specific correction. Assertions were preserved.

## Review corrections

- An originating-source predicate could synchronously dispatch a same-owner
  operation before reservation. The caller now rechecks ownership after the
  predicate; the independent inner operation retains its exact slot.
- Cleanup timer start refusal no longer prevents a later exact rearm. Attempted
  native activity still retains stop/close debt separately from monitoring state.
- Three result assertions moved outside the product's protected callbacks.
  A mutant that reports failed processes as successful now fails the independent
  descendant-result assertion.
- The real stubborn-process deadline case observes the child's readiness line
  after its SIGTERM-ignore handler is installed.
- Wrapper timeout/failure teardown now always kills and actually reaps its own
  children, preserves primary errors and tolerates native ESRCH races.
- Explicit bounded rolling-tail capture permits long-lived service output;
  ordinary helper output overflow remains a terminal failure.

## Reproduction

Pass repository and candidate roots to each standalone Lua probe. The native
probe must run through `tests/run_native_subreaper.py`, which independently
reaps orphaned descendants until real group absence can be admitted.

```bash
source /workspace/ergopti-env.sh
source /workspace/ergopti-native-env.sh

luajit tests/test_owned_process_seams.lua /workspace/ergopti "$candidate_root"
python3 tests/run_native_subreaper.py /workspace/.native/bin/luajit \
  tests/run_owned_process_native.lua /workspace/ergopti "$candidate_root"
python3 tests/run_owned_process_mutants.py /workspace/.native/bin/luajit \
  /workspace/ergopti

lua5.4 tests/test_owned_process_seams.lua /workspace/ergopti "$candidate_root"
python3 tests/run_native_subreaper.py /workspace/.native/bin/lua5.4 \
  tests/run_owned_process_native.lua /workspace/ergopti "$candidate_root"
python3 tests/run_owned_process_mutants.py /workspace/.native/bin/lua5.4 \
  /workspace/ergopti

python3 tests/run_native_subreaper_teardown.py
```

Set `candidate_root` to
`/workspace/ergopti-validation/linux-runtime-candidate` and invoke these commands
from that directory. The project launcher was used for the actual human-read
command outputs. Repository registration, selected verification and hosted CI
remain pending; see `RUNTIME-PLAN.md`.
