local result = assert(loadfile(arg[2]))(arg[1])
local failed = 0
local function check(name, value)
    if value then print("PASS " .. name) else failed = failed + 1; print("FAIL " .. name) end
end
check("macos-opener-exit23-refuses-action", result.open_path.success_after_terminal == false)
check("macos-opener-subscribes-native-completion", result.open_path.callback_type == "function")
local opened_early = false
for _, event in ipairs(result.reveal_order.events_before_reveal_terminal) do
    if event == "browser" then opened_early = true end
end
check("macos-report-waits-for-reveal-terminal-before-browser", not opened_early)
print("Expected behavior: " .. (3 - failed) .. " passed, " .. failed .. " failed")
os.exit(failed == 0 and 0 or 1)
