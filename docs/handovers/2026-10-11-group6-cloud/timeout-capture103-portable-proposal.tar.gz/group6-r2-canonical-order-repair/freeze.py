"""Freeze bounded corrective packet and exact guarded90 composition."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')
OLD = BASE.parent / 'group6-timeout-capture-on90-proposal'
RELS = ('static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py', 'tools/test/macos_native_http_receiving_facts_test.py', 'tools/test/test-managed-ollama-protocol.cjs')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)

manifest = json.loads((BASE / 'manifest.json').read_text())
composed = []
files = {}
for rel in RELS:
    source = BASE / 'candidate' / rel
    if not source.exists():
        copy(OLD / 'candidate' / rel, source)
    copy(OLD / 'preimage' / rel, BASE / 'guard90-preimage' / rel)
    before = (OLD / 'preimage' / rel).read_text()
    after = source.read_text()
    historical = (OLD / 'candidate' / rel).read_text()
    if rel == RELS[1]:
        inv = json.loads((BASE / 'exact-inverse.json').read_text())
        assert after.replace(inv['after_setup'], inv['before_setup'], 1) == historical
    else:
        assert after == historical
    files[rel] = {'guard90': sha(OLD / 'preimage' / rel), 'candidate': sha(source)}
    composed.append(''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile='a/' + rel, tofile='b/' + rel)))
(BASE / 'guard90-composed.patch').write_text(''.join(composed))
copy(OLD / 'exact-inverse.json', BASE / 'guard90-r2-insertion-inverse.json')
copy(OLD / 'function-preservation.json', BASE / 'guard90-original-function-preservation.json')
copy(OLD / 'capsule-inventory.json', BASE / 'historical47-inventory.json')
old_capsule = BASE.parent / 'group6-timeout-capture-on90-portable-proposal.tar.gz'
copy(old_capsule, BASE / 'historical47-portable-proposal.tar.gz')
with tarfile.open(old_capsule, 'r:gz') as archive:
    original_members = [item for item in archive.getmembers() if item.isfile()]
assert len(original_members) == 47
for name in ('group6-r2-canonical-order-original.stdout', 'group6-r2-canonical-order-original.stderr', 'r2-first-canonical-gate-red.json', 'verify-r2-canonical-final.log'):
    copy(BASE.parent / name, BASE / 'receipts' / name)
assert sha(BASE / 'receipts/verify-r2-canonical-final.log') == json.loads((BASE / 'receipts/r2-first-canonical-gate-red.json').read_text())['raw_log_sha256']
closure = [RELS[0], 'static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py', 'static/ergopti_plus/macos/tests/support/native_http_fixture_main.swift', 'static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/ManagedHTTPWorker.swift', 'static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/ManagedHTTPWireTests.swift', 'tools/diagnostics/macos_owned_process.py']
for rel in closure:
    source = BASE / 'candidate' / rel if rel == RELS[0] else ROOT / rel
    copy(source, BASE / 'runtime-source' / rel)
closure_hashes = {rel: sha(BASE / 'runtime-source' / rel) for rel in closure}
assert closure_hashes[RELS[0]] == files[RELS[0]]['candidate']
# Frozen receiver originally qualified against live canonical preimages; do not
# overwrite it or its receipts. Supply a separate bounded reconstruction.
receive = (BASE / 'receive.py').read_text().replace("ROOT = Path('/workspace/ergopti')", "ROOT = BASE / 'runtime-source'")
(BASE / 'receive_frozen.py').write_text(receive)
copy(BASE / 'candidate' / RELS[1], BASE / 'runtime-source' / RELS[1])
facts = json.loads((BASE / 'candidate103.stdout').read_text())
assert facts['tests'] == 103 and not any(facts[key] for key in ('failures', 'errors', 'skips'))
assert all(facts[key] for key in ('original_type_restored', 'original_type_dictionary_keys_exact', 'original_allocator_identity_exact', 'all_guard_outer_children_reaped'))
summary = {'qualification': 'PORTABLE_CANONICAL_DEFAULT_DISCOVERY_PASS_NO_ADOPTION_NO_NATIVE_CREDIT', 'canonical_original': {'exit': 1, 'tests': 103, 'errors': 6, 'failures': 0, 'skips': 0, 'seconds': 37.291, 'method': 'unmodified physical canonical python -I -B owning script'}, 'corrected': facts | {'exit': 0, 'seconds': 41.051}, 'files': files, 'whole_guard90_composed_inverse': True, 'changed_original_R2_helper_only': 'r2_guard_constructor_literal_setup', 'historical_capsule': {'members': len(original_members), 'sha256': sha(old_capsule), 'private_order_qualification': 'declaration order; does not prove canonical alphabetical discovery'}, 'runtime_source_hashes': closure_hashes, 'unexecuted': ['corrected physical live owning command', 'full canonical format/JS/hotstring gate after correction', 'Darwin native clocks', 'Security trust', 'SDK49', 'PAC14 ARM/AMD', 'E2E', 'packaging', 'installation', 'Actions']}
(BASE / 'qualification.json').write_text(json.dumps(summary, indent=2) + '\n')
manifest['state'] = 'PORTABLE_CANONICAL_DEFAULT_DISCOVERY_PASS_NO_ADOPTION_NO_NATIVE_CREDIT'
manifest['composed_files'] = files
(BASE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': files, 'correction_patch_sha256': sha(BASE / 'proposal.patch'), 'composed_patch_sha256': sha(BASE / 'guard90-composed.patch'), 'qualification_sha256': sha(BASE / 'qualification.json')}, sort_keys=True))
