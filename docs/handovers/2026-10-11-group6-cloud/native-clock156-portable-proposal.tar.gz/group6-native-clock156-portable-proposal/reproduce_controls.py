"""Future serial baseline13 and controlled omission receipts, frozen vectors."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

BASE=Path(__file__).resolve().parent
REL='static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
manifest=json.loads((BASE/'mutant-manifest.json').read_text())['variants']
work=Path(tempfile.mkdtemp(prefix='clock-parser-controls-',dir=BASE))
results=[]
for label in ['candidate']+list(manifest):
    root=work/label
    shutil.copytree(BASE/'runtime-source',root)
    if label!='candidate':
        source=BASE/'mutants'/label/REL
        assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest[label]['mutant_sha256']
        shutil.copyfile(source,root/REL)
    with (work/(label+'.stdout')).open('wb') as out,(work/(label+'.stderr')).open('wb') as err:
        actual=subprocess.run([sys.executable,'-I','-B',str(BASE/'receive_controls.py'),str(root)],stdout=out,stderr=err)
    fact=json.loads((work/(label+'.stdout')).read_text())
    fact.update(label=label,exit=actual.returncode)
    results.append(fact)
    assert fact['tests']==13 and fact['errors']==0 and fact['skips']==0
    if label=='candidate':assert actual.returncode==0 and fact['failures']==0
    else:assert actual.returncode==1 and fact['failures']>0
(work/'receipt.json').write_text(json.dumps({'qualification':'PORTABLE_NEW13_ONLY_NATIVE_UNEXECUTED','facts':results},indent=2)+'\n')
print(json.dumps({'logs':str(work),'facts':results},sort_keys=True))
