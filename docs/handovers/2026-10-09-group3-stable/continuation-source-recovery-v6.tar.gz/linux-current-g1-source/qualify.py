# group3-linux93-g1-published-union/qualify.py
"""Serial focused original G1/G3 controls; no full suites or canonical writes."""
from pathlib import Path
import subprocess,json,shutil
b=Path(__file__).resolve().parent
cwd='/workspace/ergopti/static/ergopti_plus/linux'
rows=[]
def record(row,out):
 rows.append(row);(b/'evidence'/f"{row['case']}.log").write_bytes(out)
 (b/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
# Original G1 builder is the exact one-hunk peel; keep its original logical filename.
rel='static/ergopti_plus/linux/ui/menu/menu_builder.lua'
p=b/'variants/builder-g3-peeled/ui/menu/menu_builder.lua';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((b/'preimages'/rel).read_bytes())
for abi in ['luajit','lua5.4']:
 exe='/workspace/.ergopti-cloud/bin/'+abi
 for label,module in [('g3-manager','tests.unit.meta.test_tap_hold_manager'),('g3-runtime','tests.unit.modules.test_key_combinations'),('g3-local','tests.unit.infra.test_key_combinations_scope'),('g3-global','tests.unit.infra.test_global_shortcuts_pair_scope'),('g3-menu-locales','tests.unit.ui.test_key_combinations_menu'),('g1-ai-parents','tests.unit.ui.test_ai_outer_parents'),('g1-hotstrings','tests.unit.ui.test_hotstrings_language_scope_frame')]:
  r=subprocess.run([exe,str(b/'run.lua'),str(b),module],cwd=cwd,capture_output=True)
  out=r.stdout+r.stderr;summary=[s for s in out.decode(errors='replace').splitlines() if s.startswith('PUBLISHED_G1_UNION_CONTROLLED')]
  record({'case':abi+'-'+label,'exit':r.returncode,'summary':summary[-1:]},out);assert r.returncode==0
 for label,extra,expected in [('builder-delay',[],0),('builder-delay-g3-peeled',[str(b/'variants/builder-g3-peeled')],1)]:
  r=subprocess.run([exe,str(b/'builder-delay-probe.lua'),str(b),*(['tests.helpers']+extra if extra else [])],cwd=cwd,capture_output=True)
  record({'case':abi+'-'+label,'exit':r.returncode},r.stdout+r.stderr);assert r.returncode==expected
for label,target,override,expected in [
 ('g1-category-order','test-hotstring-category-submenu-order.cjs',{},0),
 ('g1-menu-unavailable','test-menu-unavailable-rows.cjs',{},0),
 ('g1-menu-category','test-menu-category-coverage.cjs',{},0),
 ('g3-catalogue','test-tap-hold-key-catalog-single-source.cjs',{},0),
 ('g3-menu-first','test-menu-first-group.cjs',{},0),
 ('g3-restrictions','test-platform-restrictions-explained.cjs',{},0),
 ('g3-evidence','test-linux-feature-parity.cjs',{},0),
 ('manifest-g3-peeled','test-tap-hold-key-catalog-single-source.cjs',{'static/ergopti_plus/_shared/modules/features/manifest.toml':str(b/'preimages/static/ergopti_plus/_shared/modules/features/manifest.toml')},0),
]:
 p=b/'overrides'/f'{label}.json';p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(override,indent=2)+'\n')
 r=subprocess.run([shutil.which('node'),str(b/'run_guard.cjs'),'tools/test/'+target,str(p)],capture_output=True)
 record({'case':'js-'+label,'exit':r.returncode},r.stdout+r.stderr);assert r.returncode==expected
 deps=b/('guard-dependencies-'+target+'.json')
 shutil.copyfile(deps,b/'overrides'/('dependency-pins-'+label+'.json'))
