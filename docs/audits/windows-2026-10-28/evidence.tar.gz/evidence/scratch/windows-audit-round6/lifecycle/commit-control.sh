#!/usr/bin/env bash
set -euo pipefail

: "${1:?Pass the owned checkout path}"
cd -- "$1"
python3 '/workspace/scratch/windows-audit-round6/lifecycle/validate-qualified.py' "$PWD"
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
npm run lint:conventions:strict
if test -n "$(git diff --cached --name-only)"; then
  printf "%s\n" "Refusing to mix an existing index with the lifecycle fix" >&2
  exit 1
fi
git add -- 'static/ergopti_plus/windows/infra/driver_control.ahk' 'static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk'
git commit -F '/workspace/scratch/windows-audit-round6/lifecycle/control-commit-message.txt'
python3 '/workspace/scratch/windows-audit-round6/lifecycle/validate-qualified.py' "$PWD"
