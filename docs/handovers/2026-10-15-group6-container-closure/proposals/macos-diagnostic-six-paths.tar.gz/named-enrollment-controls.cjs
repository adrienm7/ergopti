// named-enrollment-controls.cjs
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(
	path.join(__dirname, 'candidate/tools/test/test-managed-ollama-protocol.cjs'), 'utf8'
);
const start = source.indexOf('// The original 172 receivers remain mandatory');
const end = source.indexOf('const cases = [', start);
assert.ok(start > 0 && end > start);
const fragment = source.slice(start, end);
const load = (text) => vm.runInNewContext(text, {
	assert,
	process: { stdout: { write(value) { assert.equal(value, 'KEYCHAIN_ENROLLMENT controls=7 native=false\n'); } } }
}, { timeout: 1000 });
new vm.Script(source);
load(fragment);
const begin = fragment.indexOf('function assertKeychainReceivingCases(stderr) {');
const finish = fragment.indexOf('/** Keep aggregate success unchanged', begin);
assert.ok(begin > 0 && finish > begin);
const withdrawal = fragment.slice(0, begin) +
	'function assertKeychainReceivingCases(stderr) { assert.match(stderr, /Ran 176 tests in/); }\n\n' +
	fragment.slice(finish);
new vm.Script(withdrawal);
assert.throws(() => load(withdrawal), error => error.code === 'ERR_ASSERTION' && /Missing expected exception/.test(error.message));
load(fragment);
console.log(JSON.stringify({ pure_controls: 7, aggregate_only_withdrawal: 'CAUSAL_ASSERTION_FAILURE', restored: 'PASS7', complete_candidate_syntax: 'PASS', actual_process_or_module_import: false, native: 'UNRUN' }, null, 2));
