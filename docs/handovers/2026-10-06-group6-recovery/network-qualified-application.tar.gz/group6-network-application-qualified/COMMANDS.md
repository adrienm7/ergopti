<!-- COMMANDS.md -->

# Qualification and application commands

No command below was executed while creating this source-only supplement.
Root must reserve the sole local test slot, admit exact source sets, then run
sequentially. Preserve the underlying direct-child exit and private captures.
Only root applies checkout paths or registers/generates artifacts.

Existing immutable qualification runner:

```bash
source /workspace/ergopti-env.sh
export TMPDIR=/tmp
cd /workspace/scratch/group6-linux-public-prepared-queue62/body-retirement-corrected-qualification/after/static/ergopti_plus/linux
/workspace/.tools/native/usr/bin/luajit /workspace/scratch/group6-linux-public-prepared-queue62/body-retirement-corrected-qualification/run_models.lua.source /workspace/scratch/group6-linux-public-prepared-queue62/body-retirement-corrected-qualification/after preserved
```

Run fixed modes `preserved`, `descriptor`, then `after` sequentially. Under actual
Lua5.4, set its own native ABI search before each command:

```bash
export LUA_CPATH='/workspace/.tools/native/usr/lib/x86_64-linux-gnu/lua/5.4/?.so;;'
/workspace/.tools/native/usr/bin/lua5.4 /workspace/scratch/group6-linux-public-prepared-queue62/body-retirement-corrected-qualification/run_models.lua.source /workspace/scratch/group6-linux-public-prepared-queue62/body-retirement-corrected-qualification/after preserved
```

Native25/14 uses the unchanged launch pair in `evidence/native-launch` and the
maintained `tests/hardware/run_native_subreaper.py` from the admitted stage:

```bash
python3 -B /ABSOLUTE/SUPPLEMENT/evidence/native-launch/run.py.source --stage /ABSOLUTE/ADMITTED/STAGE --fixture run_http_preflight_receipts.lua --expected-checks 25 --capture /ABSOLUTE/PRIVATE/NEW-CAPTURE-25 --luajit /workspace/.tools/native/usr/bin/luajit
python3 -B /ABSOLUTE/SUPPLEMENT/evidence/native-launch/run.py.source --stage /ABSOLUTE/ADMITTED/STAGE --fixture run_http_body_cleanup_receipts.lua --expected-checks 14 --capture /ABSOLUTE/PRIVATE/NEW-CAPTURE-14 --luajit /workspace/.tools/native/usr/bin/luajit
```

The companion `entry.lua.source` must remain alongside the exact admitted launcher.
Each private capture directory must be absent before launch. Require exact
fixture/guardian/launcher hashes, actual guardian and Lua PID-birth receipts,
physical direct-child reap and adopted/pending/rescue0/0/0. Stop at the first
unexpected candidate failure. Source sets must be rehashed after each phase.
The controlled genuine before14 models and both causal body14 comparisons have
expected nonzero exits; keep their counts distinct and never mask them.

Root application: verify currentHEAD and every literal preimage/absence in
APPLICATION.json before applying `application.patch`; verify separate manifest
preimage before `registration.patch`. Rebase additive rows if root advances.
Run canonical `tools/test/verify-change.cjs --plan`, then the selected gates,
without parallel native/JS suites. Do not regenerate independent expectations.
The shared header source also needs shared cross-driver source-of-truth gates.
Complete native normal models and25/14 against that final root source snapshot;
the old immutable receipts do not substitute for them. Qualify pending output
variant separately, and schedule native335/bodypipe20 only under their approved
ownership controls and unchanged independent assertions. Root owns CI selection,
SHA confirmation, cancellation of automatic workflows and integration lock.
