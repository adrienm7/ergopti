"""Prepare a reviewed-cancellation successor without altering retained R1."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent
build = ROOT / "build.py"
source = build.read_text()
parsed = ast.parse(source)
node = next(item for item in parsed.body if isinstance(item, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "spans" for target in item.targets))
spans = ast.literal_eval(node.value)
old, _ = spans[1]
spans[1] = (old, '''            if trust_operation == "add":
                # A timeout still owns its captures until exact native settlement.
                # Inspect that existing stderr once before its original close.
                try:
                    if owned is not None and getattr(owned, "reaped", False) is True:
                        trust_install_stream = self._trust_install_stream(errors)
                except BaseException as observation_failure:
                    # Preserve the original primary. A fresh control interruption
                    # on success still flows through original file closure below.
                    if failure is None and (
                        not isinstance(observation_failure, Exception)
                        or isinstance(observation_failure, FixtureFailure)
                    ):
                        failure = observation_failure
            for stream in streams:
''')
old, previous = spans[2]
previous = previous.replace('        if trust_operation == "add" and self.groups:\n            try:\n', '        if trust_operation == "add":\n            try:\n                if self.groups:\n', 1)
lines = previous.splitlines(keepends=True)
start = next(index for index, line in enumerate(lines) if line == '                if self.groups:\n')
end = next(index for index, line in enumerate(lines[start + 1:], start + 1) if line == '            except BaseException:\n')
for index in range(start + 1, end):
    lines[index] = "    " + lines[index]
previous = "".join(lines).replace('            except BaseException:\n                pass  # Diagnostic acquisition/publication is never admission.\n', '''            except BaseException as observation_failure:
                # Technical observations cannot replace command results; genuine
                # control interruptions preserve cancellation on prior success.
                if failure is None and (
                    not isinstance(observation_failure, Exception)
                    or isinstance(observation_failure, FixtureFailure)
                ):
                    failure = observation_failure
''', 1)
spans[2] = (old, previous)
lines = source.splitlines(keepends=True)
lines[node.lineno - 1:node.end_lineno] = ["spans = " + repr(spans) + "\n"]
build.write_text("".join(lines))
extra = ROOT / "additional_tests.py"
extra.write_text(extra.read_text().rstrip() + "\n\n\n" + (ROOT / "cancellation_tests.py").read_text())
