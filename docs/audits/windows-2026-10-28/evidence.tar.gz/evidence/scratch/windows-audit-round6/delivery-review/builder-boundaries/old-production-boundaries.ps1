param([Parameter(Mandatory)][string]$Repo,[Parameter(Mandatory)][string]$Receipt)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$results = [Collections.Generic.List[object]]::new()
$root = Join-Path ([IO.Path]::GetTempPath()) ('ergopti-builder-boundary-' + [Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
function Read-ActualAst([string]$Path) {
 $tokens = $null; $errors = $null
 $ast = [Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tokens,[ref]$errors)
 if ($errors.Count -ne 0) { throw "Actual source parse failed: $Path" }
 return $ast
}
try {
 foreach ($name in @('build_windows_nav_owner.ps1','build_windows_network_pac.ps1')) {
  $path = Join-Path $Repo ('tools/build/' + $name)
  $ast = Read-ActualAst $path
  $commands = @($ast.FindAll({param($node) $node -is [Management.Automation.Language.CommandAst] -and $node.GetCommandName() -ceq 'Push-Location'},$true))
  if ($commands.Count -ne 1) { throw 'The actual build working-directory boundary is not unique.' }
  foreach ($leaf in @('plain','space directory',"O'Brien é",'literal[1]','literal[abc]','unmatched[dir')) {
   $working = Join-Path $root ($name + '/' + $leaf)
   [void][IO.Directory]::CreateDirectory($working)
   if ($leaf -eq 'literal[1]') { [void][IO.Directory]::CreateDirectory((Join-Path (Split-Path $working) 'literal1')) }
   if ($leaf -eq 'literal[abc]') { [void][IO.Directory]::CreateDirectory((Join-Path (Split-Path $working) 'literala')) }
   $before = (Get-Location).Path
   $stackBefore = @(Get-Location -Stack).Count
   $BuildRoot = $working; $buildDir = $working
   $actual = ''; $errorText = ''; $accepted = $false
   try { . ([ScriptBlock]::Create($commands[0].Extent.Text)); $actual=(Get-Location).Path; $accepted=$actual -ceq $working }
   catch { $errorText=$_.Exception.Message }
   finally {
    while (@(Get-Location -Stack).Count -gt $stackBefore) { Pop-Location }
    Set-Location -LiteralPath $before
   }
   $results.Add([ordered]@{kind='builder-working-directory';owner=$name;case=$leaf;passed=$accepted;expected=$working;actual=$actual;error=$errorText;actual_source=$commands[0].Extent.Text})
   Write-Output ($(if ($accepted) {'PASS'} else {'FAIL'}) + ': ' + $name + ' path=' + $leaf)
  }
 }
 $builder=Join-Path $Repo 'tools/build/build_windows_nav_owner.ps1'
 $ast=Read-ActualAst $builder
 foreach ($name in @('Assert-StringArrayContract','Assert-TrackedManifest')) {
  $defs=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $name},$true))
  if ($defs.Count -ne 1) { throw 'The actual provenance owner definition is not unique.' }
  . ([ScriptBlock]::Create($defs[0].Extent.Text))
 }
 $canonicalPath=Join-Path $Repo 'static/ergopti_plus/windows/vendor/ergopti_nav_owner.manifest.json'
 $canonicalText=[IO.File]::ReadAllText($canonicalPath,[Text.UTF8Encoding]::new($false,$true))
 $canonical=$canonicalText | ConvertFrom-Json
 $dll=Join-Path $root "actual-vendor[1]'é.dll"
 [IO.File]::Copy((Join-Path $Repo $canonical.artifact_path),$dll,$false)
 $manifest=Join-Path $root "manifest[1]'é.json"
 $schemaPattern='"schema_version"\s*:\s*1(?=,)'
 if ([regex]::Matches($canonicalText,$schemaPattern).Count -ne 1) { throw 'The immutable canonical manifest must contain one numeric schema field.' }
 $cases=@(
  @{token='1';allow=$true},@{token='1.0';allow=$true},@{token='1e0';allow=$true},
  @{token='true';allow=$false},@{token='"1"';allow=$false},@{token='[1]';allow=$false},@{token='[]';allow=$false},@{token='[0,1]';allow=$false},
  @{token='false';allow=$false},@{token='0';allow=$false},@{token='2';allow=$false},@{token='null';allow=$false},@{token='{}';allow=$false})
 foreach ($case in $cases) {
  $changed=[regex]::Replace($canonicalText,$schemaPattern,('"schema_version":' + $case.token))
  [IO.File]::WriteAllText($manifest,$changed,[Text.UTF8Encoding]::new($false))
  $accepted=$false; $errorText=''
  try {
   Assert-TrackedManifest -Path $manifest -SchemaVersion $canonical.schema_version -DllPath $dll -ArtifactPath $canonical.artifact_path -ExpectedSourceFingerprint $canonical.source_fingerprint_sha256 -ExpectedFingerprintFiles $canonical.fingerprint_files -ExpectedRecipeExecutable $canonical.build_recipe.executable -ExpectedRecipeArguments $canonical.build_recipe.arguments
   $accepted=$true
  } catch { $errorText=$_.Exception.Message }
  $passed=$accepted -eq $case.allow
  $results.Add([ordered]@{kind='tracked-manifest-schema';case=$case.token;passed=$passed;expected_admission=$case.allow;actual_admission=$accepted;error=$errorText})
  Write-Output ($(if ($passed) {'PASS'} else {'FAIL'}) + ': provenance schema=' + $case.token + ' admitted=' + $accepted)
 }
} finally {
 [IO.File]::WriteAllText($Receipt,([ordered]@{qualification='Actual production PS AST and private native host filesystem; no MSVC build, Windows COM or native driver qualification.';powershell=$PSVersionTable.PSVersion.ToString();controls=@($results);passed=@($results|Where-Object passed).Count;failed=@($results|Where-Object {-not $_.passed}).Count}|ConvertTo-Json -Depth 8)+"`n",[Text.UTF8Encoding]::new($false))
 Remove-Item -LiteralPath $root -Recurse -Force
}
if (@($results|Where-Object {-not $_.passed}).Count -gt 0) {exit 1}
