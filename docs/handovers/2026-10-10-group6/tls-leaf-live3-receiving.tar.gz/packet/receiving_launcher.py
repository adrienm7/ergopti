"""Execute the three unchanged original live-peer controls, no fixture wrapping."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

source,output=map(Path,sys.argv[1:])
spec=importlib.util.spec_from_file_location('private_live_peers',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(module.RealPeerControls)
selected=[test.id().split('.',1)[1] for test in suite]
if len(selected)!=3 or len(set(selected))!=3:raise RuntimeError('Original three-case census refused')
result=unittest.TextTestRunner(verbosity=2).run(suite)
summary={'total':result.testsRun,'pass':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
 'fail':len(result.failures),'errors':len(result.errors),'skip':len(result.skipped),'selected':selected,
 'fail_names':[test.id().split('.',1)[1] for test,_ in result.failures],
 'error_names':[test.id().split('.',1)[1] for test,_ in result.errors],
 'native_macos_signature_algorithm_or_certificate_cause_credit':False}
with output.open('x') as stream:stream.write(json.dumps(summary,indent=2,sort_keys=True)+'\n')
output.chmod(0o600)
raise SystemExit(0 if result.wasSuccessful() and result.testsRun==3 and not result.skipped else 1)
