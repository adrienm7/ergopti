# Prepared native fixture backend isolation

SOURCE ONLY. No Lua import, model execution, native command, suite, formatter, repository write or Git action performed.

Manifest ca674e282603e61707a06f76591aa40ed605ededbeade26d1426726ec8faa49f; patch 7a5c4d3c4a37701b4617acd1b0945e0ffa6e00958dbafdeb850005f8fa75b652.

The fresh Curl loader previously restored only luv and the direct target. Cold adapters.shell_runner captures luv and infra.monotonic; the latter also captures luv. Importing these under the fixture therefore leaked a cold fake backend to later native modules. The sibling local fresh_digest lacked protected restoration on import failure.

One shared loader now snapshots luv, direct target, ShellRunner and Monotonic before mutation and restores their exact nil/false/table values after protected require, then rethrows the original error object with level0. Both local loaders delegate; public support exports remain unchanged. The entire original 7825-byte fake_luv prefix and every existing assertion/control source remain unchanged.

Seven additive normal receiving controls preserve exact identity on success and failure for nil/false/table snapshots through require interception. The seventh imports actual Curl and Monotonic source modules and uses a fixed hrtime witness to prove cold cache rebinding, without claiming kernel/native clock or transport delivery. Each control protects and restores original global require and cache ports. A single manifest row registers the new module; root owns final manifest composition and current preimage checks.

Qualification planned, not executed: run all seven unchanged controls against candidate then exact old helper preimage under LuaJIT/Lua5.4 sequentially; run original HTTP deadline and user-hotstrings native scenarios through the normal runner with their original assertions. Root owns serialized slots. Do not infer that models alone prove the original two native failures fixed.
