-- UNEXECUTED actual native tar/reader/pipe qualification. No mock success.
-- Explicit source/helper inputs are isolated controls, not installed fallbacks.
local driver, candidate, helper, session = assert(arg[1]), assert(arg[2]), assert(arg[3]), assert(arg[4])
for _, value in ipairs({ driver, candidate, helper, session }) do assert(value:sub(1, 1) == "/") end
package.path = driver .. "/?.lua;" .. driver .. "/../_shared/lua/?.lua;" .. package.path
local uv, ffi = require("luv"), require("ffi")
package.loaded["adapters.owned_process"] = assert(loadfile(candidate .. "/owned_process.lua"))()
local Owner = require("adapters.owned_process")
ffi.cdef([[
struct ergopti_archive_publication;
unsigned int ergopti_archive_publication_abi_version(void);
int ergopti_archive_publication_create_directory(const char *, double, struct ergopti_archive_publication **);
int ergopti_archive_publication_allocate_output(struct ergopti_archive_publication *, double, int *);
int ergopti_archive_publication_allocate_reader(struct ergopti_archive_publication *, double, int *);
int ergopti_archive_publication_stage(struct ergopti_archive_publication *, int, int64_t, const char *, double);
int ergopti_archive_publication_commit(struct ergopti_archive_publication *);
int ergopti_archive_publication_copy_display_path(const struct ergopti_archive_publication *, char *, size_t);
int ergopti_archive_publication_cleanup(struct ergopti_archive_publication *);
int ergopti_archive_publication_descriptors_closed(const struct ergopti_archive_publication *);
int ergopti_archive_publication_named_remaining(const struct ergopti_archive_publication *);
int ergopti_archive_publication_dispose_unpublished(struct ergopti_archive_publication *);
int geteuid(void);
int getpid(void);
int getppid(void);
]])
assert(ffi.os == "Linux" and ffi.C.geteuid() ~= 0, "actual unprivileged backend required")
local C = ffi.load(helper); assert(C.ergopti_archive_publication_abi_version() == 1)
local diagnostic
local function now() return uv.hrtime() / 1e6 end
local function await(predicate)
	local stop = now() + 10000
	repeat uv.run("nowait"); if predicate() then return true end; uv.sleep(1) until now() >= stop
	if diagnostic then pcall(diagnostic.checkpoint, diagnostic, "await-deadline") end
	return false
end
local function idle() assert(await(function() return not uv.loop_alive() end), "native handles remain") end
local function mkdir(path) assert(uv.fs_mkdir(path, 448)) end
local ledger = { operations = {}, files = {}, debts = {}, pointer = nil, c_state = "absent" }
local passed = 0
local function capture_fd(fd)
	local owner = { fd = fd, state = "open" }; ledger.files[#ledger.files + 1] = owner; return owner
end
local function close_fd(owner)
	if owner.state == "closed" then return true end
	if owner.state ~= "open" then return false end
	owner.state = "closing" -- Reserve before the destructive native call.
	local called, ack = pcall(uv.fs_close, owner.fd)
	owner.state = called and (ack == true or ack == 0) and "closed" or "uncertain-close"
	return owner.state == "closed"
end
local function file_work(path, flags, action)
	local owner = capture_fd(assert(uv.fs_open(path, flags, 384)))
	local called, result = pcall(action, owner.fd)
	local closed = close_fd(owner)
	if not called then error(result, 0) end -- Preserve first assertion/read failure.
	assert(closed, "owned fixture descriptor close unavailable")
	return result
end
local function write(path, bytes)
	return file_work(path, "wx", function(fd) assert(uv.fs_write(fd, bytes, 0) == #bytes) end)
end
local function read(path)
	return file_work(path, "r", function(fd)
		local info = assert(uv.fs_fstat(fd)); return assert(uv.fs_read(fd, info.size, 0))
	end)
end
local function capture_operation(operation)
	local record = { operation = operation }; ledger.operations[#ledger.operations + 1] = record
	assert(type(operation) == "table", "native operation unavailable")
	record.cancel, record.is_settled = rawget(operation, "cancel"), rawget(operation, "is_settled")
	assert(type(record.cancel) == "function" and type(record.is_settled) == "function")
	assert(diagnostic and diagnostic:available(), "actual spawn receipt unavailable; owner retained")
	return operation
end
local function close_publication()
	if ledger.c_state == "absent" or ledger.c_state == "disposed" then return end
	assert(ledger.c_state == "owned", "ambiguous native publication debt")
	assert(C.ergopti_archive_publication_cleanup(ledger.pointer) == 0)
	assert(C.ergopti_archive_publication_descriptors_closed(ledger.pointer) == 1)
	assert(C.ergopti_archive_publication_named_remaining(ledger.pointer) == 0)
	ledger.c_state = "disposing"
	local status = C.ergopti_archive_publication_dispose_unpublished(ledger.pointer)
	if status == 0 then ledger.pointer, ledger.c_state = nil, "disposed" else ledger.c_state = "uncertain-dispose" end
	assert(status == 0)
end
local function cleanup()
	if diagnostic then pcall(diagnostic.checkpoint, diagnostic, "cleanup") end
	local function attempt(label, action)
		local called, ack = pcall(action)
		if not called or ack ~= true then ledger.debts[#ledger.debts + 1] = label end
	end
	for _, record in ipairs(ledger.operations) do
		if type(record.cancel) == "function" then pcall(record.cancel, record.operation) end
	end
	local ops_closed = true
	for _, record in ipairs(ledger.operations) do
		local closed = false
		attempt("operation-retirement", function()
			if type(record.is_settled) ~= "function" then return false end
			closed = await(function()
				local called, ack = pcall(record.is_settled, record.operation)
				return called and ack == true
			end)
			return closed
		end)
		ops_closed = ops_closed and closed
	end
	local fds_closed = true
	for _, owner in ipairs(ledger.files) do
		local closed = close_fd(owner); fds_closed = fds_closed and closed
		if not closed then ledger.debts[#ledger.debts + 1] = "file-descriptor" end
	end
	if ops_closed and fds_closed then attempt("publication-cleanup", function() close_publication(); return true end)
	else ledger.debts[#ledger.debts + 1] = "publication-retained-for-consumers" end
	attempt("native-loop", function() return await(function() return not uv.loop_alive() end) end)
	if diagnostic and not diagnostic:available() then ledger.debts[#ledger.debts + 1] = "diagnostic-capture" end
end
local function run()
-- Parent must provide a newly owned0700, empty, ordinary session root.
local info = assert(uv.fs_lstat(session)); assert(info.type == "directory" and info.uid == ffi.C.geteuid())
assert(info.mode % 512 == 448)
local guardian = tonumber(os.getenv("ERGOPTI_RETAINED_TAR_GUARDIAN_PID"))
assert(guardian and guardian > 0 and guardian % 1 == 0 and ffi.C.getppid() == guardian,
	"existing native subreaper launcher required")
local evidence = session .. "/tar-evidence"
local evidence_info = assert(uv.fs_lstat(evidence))
assert(evidence_info.type == "directory" and evidence_info.uid == ffi.C.geteuid() and evidence_info.mode % 512 == 448)
local constructor = assert(loadfile(candidate .. "/private_tar_diagnostics.lua"))()
diagnostic = constructor(uv, ffi, evidence, guardian)
assert(diagnostic:initialize()) -- Exact owner captured before native acquisition.
diagnostic:begin("producer")
local source = session .. "/source"; mkdir(source)
for _, name in ipairs({ "linux", "_shared", "bin" }) do mkdir(source .. "/" .. name) end
write(source .. "/linux/payload", "literal-original-linux\n")
write(source .. "/_shared/payload", "literal-original-shared\n")
write(source .. "/bin/payload", "literal-original-bin\n")
write(source .. "/install.sh", "literal-original-install\n")
local archive = session .. "/fixture.tar.gz"
local generated
local producer = capture_operation(Owner.start("tar", { "-czf", archive, "-C", source, "linux", "_shared", "bin", "install.sh" },
	{ owner = "literal-native-fixture", timeout_ms = 5000 }, function(result) generated = result end))
assert(producer.started and await(function() return producer:is_settled() end))
assert(generated and generated.ok); idle()
local bytes = read(archive)
local owner = ffi.new("struct ergopti_archive_publication *[1]")
local create_status = C.ergopti_archive_publication_create_directory(session, now() + 5000, owner)
ledger.pointer = owner[0] ~= nil and owner[0] or nil
ledger.c_state = ledger.pointer ~= nil and "owned" or "absent"
assert(create_status == 0)
local output = ffi.new("int[1]", -1)
assert(C.ergopti_archive_publication_allocate_output(owner[0], now() + 5000, output) == 0)
local original_output = capture_fd(tonumber(output[0]))
assert(uv.fs_write(tonumber(output[0]), bytes, 0) == #bytes)
assert(C.ergopti_archive_publication_stage(owner[0], output[0], #bytes, "archive.tar.gz", now() + 5000) == 0)
assert(close_fd(original_output))
assert(C.ergopti_archive_publication_commit(owner[0]) == 0)
local record = { pointer = owner[0], committed = true }
local part = read(candidate .. "/native_tar_feeder.part.lua")
local constructor = assert(loadstring(part .. "\nreturn new_private_tar_feeder\n"))()
local allocations = 0
local feeder = constructor({ ffi = ffi, symbols = { allocate_reader = function(...)
	allocations = allocations + 1
	return C.ergopti_archive_publication_allocate_reader(...)
end } })
passed = 0
local function execute(mode, work, length, current, deadline)
	local result, callbacks = nil, 0
	local captured = diagnostic:begin(mode)
	local original_current = current or function() return true end
	current = function() return diagnostic:available() and original_current() == true end
	local operation = capture_operation(assert(feeder(record, mode, work, length, current or function() return true end,
		deadline or now() + 5000, function(value)
			captured.callback_count = captured.callback_count + 1
			callbacks, result = callbacks + 1, value
		end)))
	assert(not operation:is_settled() and result == nil)
	assert(await(function() return operation:is_settled() end), "actual feeder did not settle")
	assert(callbacks == 1 and result ~= nil); idle()
	return result
end
local expected = "linux/\nlinux/payload\n_shared/\n_shared/payload\nbin/\nbin/payload\ninstall.sh\n"
local names = execute("names", nil, #bytes)
assert(names.ok and names.stdout == expected); passed = passed + 1
local verbose = execute("verbose", nil, #bytes)
assert(verbose.ok)
local lines = 0
for line in verbose.stdout:gmatch("[^\n]+") do
	assert(line:sub(1, 1) == "-" or line:sub(1, 1) == "d"); lines = lines + 1
end
assert(lines == 7); passed = passed + 1
local extraction = session .. "/extracted"; mkdir(extraction)
local extracted = execute("extract", extraction, #bytes)
assert(extracted.ok and read(extraction .. "/linux/payload") == "literal-original-linux\n")
assert(read(extraction .. "/_shared/payload") == "literal-original-shared\n")
assert(read(extraction .. "/bin/payload") == "literal-original-bin\n")
assert(read(extraction .. "/install.sh") == "literal-original-install\n"); passed = passed + 1

-- A pathname rebind cannot redirect reading. Control restores its exact owned
-- entry before native cleanup; the production feeder never receives the path.
local display = ffi.new("char[4352]")
assert(C.ergopti_archive_publication_copy_display_path(owner[0], display, 4352) == 0)
local path = ffi.string(display); assert(uv.fs_rename(path, path .. ".held"))
write(path, "foreign-archive-bytes")
local retained = execute("names", nil, #bytes)
assert(retained.ok and retained.stdout == expected)
assert(read(path) == "foreign-archive-bytes")
assert(uv.fs_unlink(path) and uv.fs_rename(path .. ".held", path)); passed = passed + 1

local early_eof = execute("names", nil, #bytes + 1)
assert(not early_eof.ok); passed = passed + 1
local overflow = execute("names", nil, #bytes - 1)
assert(not overflow.ok); passed = passed + 1

-- Request is actually submitted but its callback cannot yet have run without
-- a loop iteration. Logical cancellation must await that specific native ACK.
local cancelled_result
local operation = capture_operation(assert(feeder(record, "names", nil, #bytes, function() return true end,
	now() + 5000, function(value) cancelled_result = value end)))
assert(operation:cancel() == true and not operation:is_settled() and cancelled_result == nil)
assert(await(function() return operation:is_settled() end))
assert(cancelled_result and not cancelled_result.ok); idle(); passed = passed + 1

local before = allocations
local refused = feeder(record, "names", nil, #bytes, function() return true end, now() - 1, function()
	error("expired preallocation cannot publish success")
end)
assert(refused == nil and allocations == before); idle(); passed = passed + 1

end
local called, primary = xpcall(run, function(error) return error end)
cleanup() -- Every acquired exact owner is attempted, independently of primary.
if not called then
	io.stderr:write(tostring(primary), "\n")
	if #ledger.debts > 0 then io.stderr:write("retained owned cleanup debt:", table.concat(ledger.debts, ","), "\n") end
	os.exit(1)
end
assert(#ledger.debts == 0, "owned fixture cleanup debt; inputs retained")
print(string.format("Actual retained tar scopes: %d completed,0 skipped; fixture inputs retained", passed))
