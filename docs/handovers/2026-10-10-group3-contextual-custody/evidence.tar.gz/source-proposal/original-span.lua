	local generation = _dispatch_generation
	if opts.defer(function()
		if _configuration_owner ~= nil or generation ~= _dispatch_generation then return end
		if hit.physical then
			if not physical_admitted(opts, hit) then return end
			local source = physical_source_generation()
			if source ~= hit.source_generation or not physical_current(hit) then return end
		end
		if hit.decision then
			local admission = opts.admission()
			local current = M.magic_editor_decision(admission)
			if not MagicEditor.can_deliver(hit.decision, { source_generation = current.source_generation,
				configuration_generation = _dispatch_generation, action = current.action,
				master = admission.master, paused = admission.paused, inhibited = admission.inhibited }) then return end
		end
		if _configuration_owner ~= nil or generation ~= _dispatch_generation then return end
		fire(hit, hit.physical and function() return physical_current(hit) end or nil)
	end) ~= true then
