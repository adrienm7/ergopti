# Source-only original23 / interpreted-startup binding proposal

Actual d02912f9 inert API and the seven-member Root handoff6183251915 are received
and their literal hash index verified. No member is imported, run or replayed.
The new CommonJS module is an INACTIVE pure data binding step, not an executable
provider/authority.20 source-only declaration controls PASS; no native test.
Run the test file with the repository-pinned Node22.22.2; it reads only the new
module, never the handed-off Python/PowerShell/Node inert subjects.

It binds original three filters/argv, dry-run mode, intended AHK runtime/source,
externally DECLARED caller, source manifest, candidate, nonce, separate capture
declarations and explicit environment. Startup retains its separate argv and
isolated LOCALAPPDATA/nonce. Original23's300000ms shared collector deadline and
startup's120000ms fixture deadline are descriptive; no clock or fresh budget is
created. Inert role list and provider/source qualification remain unchanged.
Data declarations and their matching do not authenticate a current caller, lease
an actual source/runtime or grant production/native execution.

Exact remaining incompatibilities with supplied source:
- prehost_native_inert.py175-176 permits node-inert/powershell-inert only.
-177-178 bounds the inert lifetime at30000ms; it cannot silently replace either
 original consumer budget.
-381-386 owns fresh stdout.bin/stderr.bin; collector owns exclusive descriptors.
-409-410 fixes Node script argv or PowerShell-File; retained acquired-byte
 EncodedCommand and actual interpreted-AHK argv need distinct reviewed roles.
-466-480 is one4096-byte length-prefixed echo, not original newline lifecycle/
 cancel framing. Native113 explicitly grants no trusted-caller admission.
- start/resume/retire/custody are genuine retained native seams, not substitutes
 for externally chosen caller admission, complete runtime/include dependency
 leases, exact capture transfer and original terminal/cleanup barriers.

The current public collector still uses ordinary spawn and no first-host
replacement is enrolled by this proposal. The original23 labels/oracle and
prepared Root01ee/TLS source controls remain unchanged. Required next input is
a Root-reviewed finite production role/caller/channel/capture contract; never
relabel production as inert, widen packet roles or flip qualification booleans.
Root owns independent current Windows receiving and final integration.
