#pragma once

#include "console_user_server_peer.hpp"
#include "constants.hpp"
#include "core_service/daemon/core_service_daemon_state_manager.hpp"
#include "device_grabber_details/device_key_code_manipulator_manager.hpp"
#include "device_grabber_details/entry.hpp"
#include "device_grabber_details/fn_function_keys_manipulator_manager.hpp"
#include "device_grabber_details/simple_modifications_manipulator_manager.hpp"
#include "event_tap_utility.hpp"
#include "filesystem_utility.hpp"
#include "hid_keyboard_caps_lock_led_state_manager.hpp"
#include "iokit_utility.hpp"
#include "json_writer.hpp"
#include "keyboard_suppression.hpp"
#include "krbn_notification_center.hpp"
#include "logger.hpp"
#include "manipulator/condition_factory.hpp"
#include "manipulator/manipulator_factory.hpp"
#include "manipulator/manipulator_managers_connector.hpp"
#include "manipulator/manipulators/post_event_to_virtual_devices/post_event_to_virtual_devices.hpp"
#include "monitor/configuration_monitor.hpp"
#include "monitor/event_tap_monitor.hpp"
#include "notification_message_manager.hpp"
#include "process_lifecycle_manager.hpp"
#include "types.hpp"
#include <array>
#include <dlfcn.h>
#include <fstream>
#include <nlohmann/json.hpp>
#include <nod/nod.hpp>
#include <pqrs/gsl.hpp>
#include <pqrs/karabiner/driverkit/virtual_hid_device_driver.hpp>
#include <pqrs/osx/hitoolbox/secure_event_input_monitor.hpp>
#include <pqrs/osx/iokit_hid_manager.hpp>
#include <pqrs/osx/system_preferences.hpp>
#include <pqrs/spdlog.hpp>
#include <ranges>
#include <string_view>
#include <thread>
#include <time.h>
#include <unistd.h>
#include <unordered_map>
#include <unordered_set>

namespace krbn::core_service::daemon {
class device_grabber final : public pqrs::dispatcher::extra::dispatcher_client {
public:
  // Signals (invoked from the shared dispatcher thread)

  nod::signal<void()> connected_devices_changed;
  nod::signal<void(const std::string&)> notification_message_changed;

  device_grabber(const device_grabber&) = delete;

  device_grabber(std::weak_ptr<console_user_server_peer> weak_console_user_server_peer,
                 std::weak_ptr<core_service_daemon_state_manager> weak_core_service_daemon_state_manager)
      : dispatcher_client(),
        weak_console_user_server_peer_(weak_console_user_server_peer),
        weak_core_service_daemon_state_manager_(weak_core_service_daemon_state_manager),
        core_configuration_(std::make_shared<core_configuration::core_configuration>()),
        logger_unique_filter_(logger::get_logger()) {
    notification_message_manager_ = std::make_shared<notification_message_manager>();

    notification_message_manager_->notification_message_changed.connect(
        [this](const auto& notification_message) {
          notification_message_changed(notification_message);
        });

    // Apply per-device key-code swaps through basic manipulators rather than
    // rewriting events when they are added to the queue. A basic manipulator
    // retains the mapping selected at key_down until the corresponding key_up,
    // even if the configuration is updated while the key is held.
    device_key_code_manipulator_manager_ = std::make_shared<device_grabber_details::device_key_code_manipulator_manager>();
    simple_modifications_manipulator_manager_ = std::make_shared<device_grabber_details::simple_modifications_manipulator_manager>();
    complex_modifications_manipulator_manager_ = std::make_shared<manipulator::manipulator_manager>();
    fn_function_keys_manipulator_manager_ = std::make_shared<device_grabber_details::fn_function_keys_manipulator_manager>();
    post_event_to_virtual_devices_manipulator_manager_ = std::make_shared<manipulator::manipulator_manager>();

    merged_input_event_queue_ = std::make_shared<event_queue::queue>();
    device_key_code_manipulated_event_queue_ = std::make_shared<event_queue::queue>();
    simple_modifications_applied_event_queue_ = std::make_shared<event_queue::queue>();
    complex_modifications_applied_event_queue_ = std::make_shared<event_queue::queue>();
    fn_function_keys_applied_event_queue_ = std::make_shared<event_queue::queue>();
    posted_event_queue_ = std::make_shared<event_queue::queue>();

    //
    // virtual_hid_device_service_client_
    //

    virtual_hid_device_service_client_ = std::make_shared<pqrs::karabiner::driverkit::virtual_hid_device_service::client>();

    virtual_hid_device_service_client_->connected.connect([this, weak_core_service_daemon_state_manager] {
      logger::get_logger()->debug("virtual_hid_device_service_client_ connected");

      if (auto m = weak_core_service_daemon_state_manager.lock()) {
        m->set_virtual_hid_device_service_client_connected(true);
      }

      update_virtual_hid_keyboard();
      update_virtual_hid_pointing();

      update_devices_disabled();
      async_grab_devices();
    });

    virtual_hid_device_service_client_->connect_failed.connect([weak_core_service_daemon_state_manager](auto&& error_code) {
      logger::get_logger()->debug("virtual_hid_device_service_client_ connect_failed: {0}", error_code.message());

      if (auto m = weak_core_service_daemon_state_manager.lock()) {
        m->set_virtual_hid_device_service_client_connected(false);
      }
    });

    virtual_hid_device_service_client_->closed.connect([weak_core_service_daemon_state_manager] {
      logger::get_logger()->debug("virtual_hid_device_service_client_ closed");

      if (auto m = weak_core_service_daemon_state_manager.lock()) {
        m->set_virtual_hid_device_service_client_connected(false);
      }

      // Wait automatic reconnection.
      //
      // Note:
      // The following callback will be signaled by virtual_hid_device_service::client.
      // - `virtual_hid_keyboard_ready_response(false)`
      // - `virtual_hid_pointing_ready_response(false)`
    });

    virtual_hid_device_service_client_->error_occurred.connect([](auto&& error_code) {
      logger::get_logger()->debug("virtual_hid_device_service_client_ error_occurred: {0}", error_code.message());
    });

    virtual_hid_device_service_client_->driver_activated.connect([weak_core_service_daemon_state_manager](auto&& driver_activated) {
      if (auto m = weak_core_service_daemon_state_manager.lock()) {
        m->set_driver_activated(driver_activated);
      }
    });

    virtual_hid_device_service_client_->driver_connected.connect([weak_core_service_daemon_state_manager](auto&& driver_connected) {
      if (auto m = weak_core_service_daemon_state_manager.lock()) {
        m->set_driver_connected(driver_connected);
      }
    });

    virtual_hid_device_service_client_->driver_version_mismatched.connect([weak_core_service_daemon_state_manager](auto&& driver_version_mismatched) {
      if (auto m = weak_core_service_daemon_state_manager.lock()) {
        m->set_driver_version_mismatched(driver_version_mismatched);
      }
    });

    virtual_hid_device_service_client_->virtual_hid_keyboard_ready.connect([this, weak_core_service_daemon_state_manager](auto&& ready) {
      if (virtual_hid_devices_state_.get_virtual_hid_keyboard_ready() != ready) {
        logger::get_logger()->info("virtual_hid_device_service_client_ virtual_hid_keyboard_ready_response: {0}", ready);

        virtual_hid_devices_state_.set_virtual_hid_keyboard_ready(ready);
        async_post_virtual_hid_devices_state_changed_event();

        if (auto m = weak_core_service_daemon_state_manager.lock()) {
          m->set_virtual_hid_keyboard_ready(ready);
        }

        // The virtual_hid_keyboard might have been terminated or become unavailable.
        // We try to reinitialize the device.
        if (!ready) {
          if (post_event_to_virtual_devices_manipulator_) {
            post_event_to_virtual_devices_manipulator_->clear_virtual_hid_keyboard_pressed_keys();
          }
          virtual_hid_device_service_client_->async_virtual_hid_keyboard_terminate();
          update_virtual_hid_keyboard();
        }

        update_devices_disabled();
        async_grab_devices();
      }
    });

    virtual_hid_device_service_client_->virtual_hid_pointing_ready.connect([this](auto&& ready) {
      if (virtual_hid_devices_state_.get_virtual_hid_pointing_ready() != ready) {
        logger::get_logger()->info("virtual_hid_device_service_client_ virtual_hid_pointing_ready_response: {0}", ready);

        virtual_hid_devices_state_.set_virtual_hid_pointing_ready(ready);
        async_post_virtual_hid_devices_state_changed_event();

        // The virtual_hid_pointing might have been terminated or become unavailable.
        // We try to reinitialize the device.
        if (!ready) {
          virtual_hid_device_service_client_->async_virtual_hid_pointing_terminate();
          update_virtual_hid_pointing();
        }

        update_devices_disabled();
        async_grab_devices();
      }
    });

    post_event_to_virtual_devices_manipulator_ =
        std::make_shared<manipulator::manipulators::post_event_to_virtual_devices::post_event_to_virtual_devices>(
            weak_console_user_server_peer_,
            notification_message_manager_);
    post_event_to_virtual_devices_manipulator_->set_cgeventtap_fallback_enabled(cgeventtap_fallback_enabled_);
    post_event_to_virtual_devices_manipulator_->set_sleep_shortcut_delay(
        std::chrono::milliseconds(core_configuration_->get_global_configuration().get_delay_milliseconds_before_sleep_shortcut()));
    post_event_to_virtual_devices_manipulator_manager_->push_back_manipulator(std::shared_ptr<manipulator::manipulators::base>(post_event_to_virtual_devices_manipulator_));

    // Connect manipulator_managers

    manipulator_managers_connector_.emplace_back_connection(pqrs::make_weak(device_key_code_manipulator_manager_->get_manipulator_manager()),
                                                            merged_input_event_queue_,
                                                            device_key_code_manipulated_event_queue_);
    manipulator_managers_connector_.emplace_back_connection(pqrs::make_weak(simple_modifications_manipulator_manager_->get_manipulator_manager()),
                                                            simple_modifications_applied_event_queue_);
    manipulator_managers_connector_.emplace_back_connection(complex_modifications_manipulator_manager_,
                                                            complex_modifications_applied_event_queue_);
    manipulator_managers_connector_.emplace_back_connection(pqrs::make_weak(fn_function_keys_manipulator_manager_->get_manipulator_manager()),
                                                            fn_function_keys_applied_event_queue_);
    manipulator_managers_connector_.emplace_back_connection(post_event_to_virtual_devices_manipulator_manager_,
                                                            posted_event_queue_);

    external_signal_connections_.emplace_back(
        krbn_notification_center::get_instance().input_event_arrived.connect([this] {
          manipulate(pqrs::osx::chrono::mach_absolute_time_point());
        }));

    // hid_manager_

    std::vector<pqrs::cf::cf_ptr<CFDictionaryRef>> matching_dictionaries{
        pqrs::osx::iokit_hid_manager::make_matching_dictionary(
            pqrs::hid::usage_page::generic_desktop,
            pqrs::hid::usage::generic_desktop::keyboard),

        pqrs::osx::iokit_hid_manager::make_matching_dictionary(
            pqrs::hid::usage_page::generic_desktop,
            pqrs::hid::usage::generic_desktop::mouse),

        pqrs::osx::iokit_hid_manager::make_matching_dictionary(
            pqrs::hid::usage_page::generic_desktop,
            pqrs::hid::usage::generic_desktop::pointer),

        pqrs::osx::iokit_hid_manager::make_matching_dictionary(
            pqrs::hid::usage_page::generic_desktop,
            pqrs::hid::usage::generic_desktop::joystick),

        pqrs::osx::iokit_hid_manager::make_matching_dictionary(
            pqrs::hid::usage_page::generic_desktop,
            pqrs::hid::usage::generic_desktop::game_pad),

        // Headset
        pqrs::osx::iokit_hid_manager::make_matching_dictionary(
            pqrs::hid::usage_page::consumer,
            pqrs::hid::usage::consumer::consumer_control),

        // Special devices (e.g., VEC USB Footpedal INFINITY USB-3)
        pqrs::osx::iokit_hid_manager::make_matching_dictionary(
            pqrs::hid::usage_page::consumer,
            pqrs::hid::usage::consumer::programmable_buttons),
    };

    hid_manager_ = std::make_unique<pqrs::osx::iokit_hid_manager>(weak_dispatcher_,
                                                                  pqrs::cf::run_loop_thread::extra::get_shared_run_loop_thread(),
                                                                  matching_dictionaries,
                                                                  std::chrono::milliseconds(1000));

    hid_manager_->device_matched.connect([this](auto&& registry_entry_id, auto&& device_ptr) {
      if (device_ptr) {
        auto device_id = make_device_id(registry_entry_id);

        //
        // entries_
        //

        pqrs::not_null_shared_ptr_t<device_grabber_details::entry> entry =
            std::make_shared<device_grabber_details::entry>(device_id,
                                                            *device_ptr,
                                                            core_configuration_);
        entries_.insert_or_assign(device_id,
                                  entry);

        connected_devices_changed();

        entry->set_temporarily_ignore(
            temporarily_ignored_device_ids_.contains(device_id));

        entry->hid_values_arrived.connect([this](auto&& entry,
                                                 auto&& event_queue_entries) {
          hid_values_arrived(entry,
                             event_queue_entries);
        });

        entry->get_hid_device_events_monitor()->started.connect([this, device_id] {
          if (auto it = entries_.find(device_id);
              it != entries_.end()) {
            logger::get_logger()->info("{0} hid device events monitor is started ({1}).",
                                       it->second->get_device_name(),
                                       it->second->seized() ? "grabbed" : "observed");
            logger_unique_filter_.reset();

            post_device_grabbed_event(it->second->get_device_properties());

            update_caps_lock_led();

            update_virtual_hid_pointing();
          }
        });

        entry->get_hid_device_events_monitor()->stopped.connect([this, device_id] {
          if (auto it = entries_.find(device_id);
              it != entries_.end()) {
            logger::get_logger()->info("{0} hid device events monitor is stopped.",
                                       it->second->get_device_name());
            logger_unique_filter_.reset();

            physical_pressed_momentary_switch_events_.erase(device_id);
            post_device_ungrabbed_event(device_id);

            update_virtual_hid_pointing();
          }
        });

        entry->get_hid_device_events_monitor()->error_occurred.connect([](auto&& message, auto&& kr) {
          if (kr.not_permitted()) {
            logger::get_logger()->warn("hid_device_events_monitor not_permitted error");
            process_lifecycle_manager::async_request_termination();
          }
        });

        // ----------------------------------------

        update_virtual_hid_pointing();

        // ----------------------------------------

        update_devices_disabled();
        async_grab_devices();
      }
    });

    hid_manager_->device_terminated.connect([this](auto&& registry_entry_id) {
      auto device_id = make_device_id(registry_entry_id);

      // entries_

      {
        if (auto it = entries_.find(device_id);
            it != entries_.end()) {
          logger::get_logger()->info("{0} is terminated.",
                                     it->second->get_device_name());
          logger_unique_filter_.reset();

          entries_.erase(it);
          connected_devices_changed();
        }
      }

      //
      // Unregister device
      //

      physical_pressed_momentary_switch_events_.erase(device_id);
      hat_switch_converter::get_global_hat_switch_converter()->erase_device(device_id);

      // ----------------------------------------

      post_device_ungrabbed_event(device_id);

      update_virtual_hid_pointing();

      // ----------------------------------------
      update_devices_disabled();
      async_grab_devices();
    });

    hid_manager_->error_occurred.connect([this](auto&& message, auto&& kern_return) {
      logger::get_logger()->error("{0}: {1}", message, kern_return.to_string());
      logger_unique_filter_.reset();
    });

    //
    // secure_event_input_monitor_
    //

    secure_event_input_monitor_ = std::make_unique<pqrs::osx::hitoolbox::secure_event_input_monitor>(weak_dispatcher_,
                                                                                                     std::chrono::milliseconds(50));
    secure_event_input_monitor_->secure_event_input_enabled_changed.connect([this](auto&& enabled) {
      // For devices opened via IOHIDDeviceOpen, we can still receive events even when secure event input is enabled
      // (for example, when sudo or System Settings is prompting for a password).
      //
      // With CGEventTap, however, we cannot receive events while secure event input is active.
      // As a result, for keys that were pressed before entering secure event input, we cannot receive key_up,
      // and key repeat can continue unexpectedly.
      //
      // Therefore, when using CGEventTap, we must release all keys pressed on the virtual device
      // when secure event input becomes enabled.

      if (!cgeventtap_fallback_enabled_) {
        return;
      }

      if (enabled) {
        logger::get_logger()->info("secure event input is enabled: release all pressed keys");
        post_device_keys_and_pointing_buttons_are_released_event();
        physical_pressed_momentary_switch_events_.clear();

        if (post_event_to_virtual_devices_manipulator_) {
          post_event_to_virtual_devices_manipulator_->get_key_event_dispatcher().clear_pressed_modifier_flags();

          post_event_to_virtual_devices_manipulator_->async_release_virtual_hid_keyboard_pressed_keys(
              virtual_hid_device_service_client_);
        }
      }
    });
  }

  ~device_grabber() override {
    detach_from_dispatcher([this] {
      // Invalidate callbacks from an event_tap_monitor that is still stopping.
      event_tap_monitor_lifetime_ = nullptr;
      pending_event_tap_monitor_configuration_ = std::nullopt;

      stop();

      hid_manager_ = nullptr;

      external_signal_connections_.clear();

      post_event_to_virtual_devices_manipulator_ = nullptr;

      device_key_code_manipulator_manager_ = nullptr;
      simple_modifications_manipulator_manager_ = nullptr;
      complex_modifications_manipulator_manager_ = nullptr;
      fn_function_keys_manipulator_manager_ = nullptr;
      post_event_to_virtual_devices_manipulator_manager_ = nullptr;
      virtual_hid_device_service_client_ = nullptr;
      secure_event_input_monitor_ = nullptr;

      notification_message_manager_ = nullptr;

      hat_switch_converter::get_global_hat_switch_converter()->clear();
    });
  }

  void async_start(const std::optional<std::string>& user_core_configuration_file_path,
                   std::optional<uid_t> expected_user_core_configuration_file_owner) {
    enqueue_to_dispatcher([this,
                           user_core_configuration_file_path,
                           expected_user_core_configuration_file_owner] {
      // We should call CGEventTapCreate after user is logged in.
      // So, we create event_tap_monitor here.
      setup_event_tap_monitor(false);

      configuration_monitor_ = std::make_unique<configuration_monitor>(user_core_configuration_file_path,
                                                                       expected_user_core_configuration_file_owner.value_or(uid_t(0)),
                                                                       krbn::core_configuration::error_handling::loose);

      configuration_monitor_->parse_error_message_changed.connect([this](auto&& parse_error_message) {
        if (auto m = weak_core_service_daemon_state_manager_.lock()) {
          m->set_karabiner_json_parse_error_message(parse_error_message);
        }
      });

      configuration_monitor_->load_state_changed.connect([this](auto load_state) {
        if (auto m = weak_core_service_daemon_state_manager_.lock()) {
          m->set_karabiner_json_permission_error(
              load_state == core_configuration::core_configuration::load_state::permission_error);
        }
      });

      configuration_monitor_->core_configuration_updated.connect([this](auto&& weak_core_configuration) {
        if (auto core_configuration = weak_core_configuration.lock()) {
          core_configuration_ = core_configuration;

          auto using_system_core_configuration =
              core_configuration_->get_source() == core_configuration::core_configuration::source::system_file;

          // If an old core_configuration is stored in system_file,
          // Settings is opened to show an alert when the user logs in.
          // However, the configuration is then loaded from user_file in the new format, and the alert disappears.
          // From the user's perspective, Settings opens unnecessarily after login in this case,
          // so configuration errors in system_file should not be reflected in settings_window_guidance or trigger opening Settings.
          if (auto m = weak_core_service_daemon_state_manager_.lock()) {
            m->set_virtual_hid_keyboard_type_not_set(
                !using_system_core_configuration &&
                core_configuration_->get_selected_profile().get_virtual_hid_keyboard()->get_keyboard_type_v2().empty());
          }

          for (auto&& entry : entries_ | std::views::values) {
            entry->set_core_configuration(core_configuration);
          }

          manipulator_managers_connector_.set_manipulator_environment_core_configuration(core_configuration);

          logger_unique_filter_.reset();

          if (auto console_user_server_peer = weak_console_user_server_peer_.lock()) {
            //
            // Check for updates
            //

            console_user_server_peer->async_check_for_updates(
                core_configuration_->get_global_configuration().get_check_for_updates());
          }

          //
          // Reflect profile changes
          //

          auto& profile = core_configuration_->get_selected_profile();

          set_cgeventtap_fallback_enabled(core_configuration_->get_global_configuration().get_enable_cgeventtap_fallback());

          if (post_event_to_virtual_devices_manipulator_) {
            post_event_to_virtual_devices_manipulator_->set_sleep_shortcut_delay(
                std::chrono::milliseconds(core_configuration_->get_global_configuration().get_delay_milliseconds_before_sleep_shortcut()));
          }

          if (hid_manager_) {
            hid_manager_->async_set_device_matched_delay(
                profile.get_parameters()->get_delay_milliseconds_before_open_device());
            hid_manager_->async_start();
          }

          device_key_code_manipulator_manager_->update(profile);
          simple_modifications_manipulator_manager_->update(profile);
          fn_function_keys_manipulator_manager_->update(profile,
                                                        system_preferences_properties_);
          update_complex_modifications_manipulators();

          update_virtual_hid_keyboard();
          update_virtual_hid_pointing();

          update_devices_disabled();
          async_grab_devices();
          async_post_system_preferences_properties_changed_event();
        }
      });

      configuration_monitor_->async_start();

      virtual_hid_device_service_client_->async_start();

      secure_event_input_monitor_->async_start();
    });
  }

  void async_grab_devices() {
    enqueue_to_dispatcher([this] {
      for (auto&& entry : entries_ | std::views::values) {
        grab_device(*entry);
      }
    });
  }

  void async_set_temporarily_ignored_device_ids(const std::unordered_set<device_id>& device_ids) {
    enqueue_to_dispatcher([this, device_ids] {
      temporarily_ignored_device_ids_ = device_ids;

      for (const auto& [device_id, entry] : entries_) {
        entry->set_temporarily_ignore(device_ids.contains(device_id));
      }

      async_grab_devices();
    });
  }

  void async_set_system_preferences_properties(const pqrs::osx::system_preferences::properties& value) {
    enqueue_to_dispatcher([this, value] {
      system_preferences_properties_ = value;

      fn_function_keys_manipulator_manager_->update(core_configuration_->get_selected_profile(),
                                                    system_preferences_properties_);
      async_post_system_preferences_properties_changed_event();
    });
  }

  void async_post_set_variable_event(const manipulator_environment_variable_set_variable& value) {
    enqueue_to_dispatcher([this, value] {
      auto event = event_queue::event::make_set_variable_event(value);

      for (const auto& t : {event_type::key_down, event_type::key_up}) {
        event_queue::entry entry(device_id(0),
                                 event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                                 event,
                                 t,
                                 std::nullopt,
                                 event,
                                 event_queue::state::virtual_event);
        merged_input_event_queue_->push_back_entry(entry);
      }

      krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
    });
  }

  void async_post_frontmost_application_changed_event(const application& application) {
    enqueue_to_dispatcher([this, application] {
      auto event = event_queue::event::make_frontmost_application_changed_event(application);
      event_queue::entry entry(device_id(0),
                               event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                               event,
                               event_type::single,
                               std::nullopt,
                               event,
                               event_queue::state::virtual_event);

      merged_input_event_queue_->push_back_entry(entry);

      krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
    });
  }

  void async_post_input_source_changed_event(const pqrs::osx::input_source::properties& properties) {
    enqueue_to_dispatcher([this, properties] {
      auto event = event_queue::event::make_input_source_changed_event(properties);
      event_queue::entry entry(device_id(0),
                               event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                               event,
                               event_type::single,
                               std::nullopt,
                               event,
                               event_queue::state::virtual_event);

      merged_input_event_queue_->push_back_entry(entry);

      krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
    });
  }

  void async_post_system_preferences_properties_changed_event() {
    enqueue_to_dispatcher([this] {
      auto event = event_queue::event::make_system_preferences_properties_changed_event(
          system_preferences_properties_);
      event_queue::entry entry(device_id(0),
                               event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                               event,
                               event_type::single,
                               std::nullopt,
                               event,
                               event_queue::state::virtual_event);

      merged_input_event_queue_->push_back_entry(entry);

      krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
    });
  }

  void async_post_virtual_hid_devices_state_changed_event() {
    enqueue_to_dispatcher([this] {
      auto event = event_queue::event::make_virtual_hid_devices_state_changed_event(virtual_hid_devices_state_);
      event_queue::entry entry(device_id(0),
                               event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                               event,
                               event_type::single,
                               std::nullopt,
                               event,
                               event_queue::state::virtual_event);

      merged_input_event_queue_->push_back_entry(entry);

      krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
    });
  }

  void async_invoke_with_manipulator_environment(std::function<void(const manipulator::manipulator_environment&)> function) const {
    enqueue_to_dispatcher([this, function] {
      function(complex_modifications_applied_event_queue_->get_manipulator_environment());
    });
  }

  void async_invoke_with_connected_devices(std::function<void(const nlohmann::json&)> function) const {
    enqueue_to_dispatcher([this, function] {
      connected_devices connected_devices;
      for (const auto& entry : entries_ | std::views::values) {
        connected_devices.push_back_device(entry->get_device_properties());
      }

      function(nlohmann::json(connected_devices));
    });
  }

  void async_invoke_with_notification_message(std::function<void(const std::string&)> function) const {
    enqueue_to_dispatcher([this, function] {
      function(notification_message_manager_->get_full_message());
    });
  }

private:
  void stop() {
    configuration_monitor_ = nullptr;

    enqueue_to_dispatcher([this] {
      for (auto&& entry : entries_ | std::views::values) {
        entry->get_hid_device_events_monitor()->async_stop();
      }

      logger::get_logger()->info("Connected devices are ungrabbed");
    });

    async_stop_event_tap_monitor();

    virtual_hid_device_service_client_->async_stop();

    secure_event_input_monitor_->async_stop();
  }

  // This method is executed in the shared dispatcher thread.
  void manipulate(absolute_time_point now) {
    manipulator_managers_connector_.manipulate(now,
                                               core_configuration_);

    posted_event_queue_->clear_events();
    post_event_to_virtual_devices_manipulator_->async_post_events(virtual_hid_device_service_client_);

    if (auto min = manipulator_managers_connector_.min_input_event_time_stamp()) {
      auto when = when_now();
      if (now < *min) {
        when += pqrs::osx::chrono::make_milliseconds(*min - now);
      }

      enqueue_to_dispatcher(
          [this, min] {
            manipulate(*min);
          },
          when);
    }
  }

  // This method is executed in the shared dispatcher thread.
  void hid_values_arrived(device_grabber_details::entry& entry,
                          event_queue::not_null_entries_ptr_t event_queue_entries) {
    if (entry.get_device_properties()->get_device_identifiers().get_is_virtual_device()) {
      // Handle caps_lock_state_changed event only if the hid is Karabiner-DriverKit-VirtualHIDDevice.
      for (const auto& e : *event_queue_entries) {
        if (e->get_event().get_type() == event_queue::event::type::caps_lock_state_changed) {
          if (auto state = e->get_event().get_integer_value()) {
            last_caps_lock_state_ = *state;
            post_caps_lock_state_changed_event(*state);
            update_caps_lock_led();
          }
        }
      }
    } else {
      // Manipulate events

      bool notify = false;

      for (const auto& e : *event_queue_entries) {
        if (!entry.get_disabled() && entry.seized()) {
          if (unbalanced_momentary_switch_event(e->get_device_id(),
                                                e->get_event(),
                                                e->get_event_type())) {
            continue;
          }

          event_queue::entry qe(e->get_device_id(),
                                e->get_event_time_stamp(),
                                e->get_event(),
                                e->get_event_type(),
                                e->get_event_integer_value(),
                                e->get_original_event(),
                                e->get_state());

          merged_input_event_queue_->push_back_entry(qe);

          notify = true;
        }
      }

      if (core_configuration_->get_global_configuration().get_reorder_same_timestamp_input_events_to_prioritize_modifiers()) {
        merged_input_event_queue_->sort_events();
      }

      if (notify) {
        krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
      }
    }
  }

  void event_tap_keyboard_event_arrived(event_type event_type, const event_queue::event& event) {
    if (unbalanced_momentary_switch_event(device_id(0),
                                          event,
                                          event_type)) {
      return;
    }

    event_queue::entry entry(device_id(0),
                             event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                             event,
                             event_type,
                             std::nullopt,
                             event,
                             event_queue::state::original);

    merged_input_event_queue_->push_back_entry(entry);

    krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
  }

  void post_device_grabbed_event(pqrs::not_null_shared_ptr_t<device_properties> device_properties) {
    auto event = event_queue::event::make_device_grabbed_event(device_properties);
    event_queue::entry entry(device_properties->get_device_id(),
                             event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                             event,
                             event_type::single,
                             std::nullopt,
                             event,
                             event_queue::state::virtual_event);

    merged_input_event_queue_->push_back_entry(entry);

    krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
  }

  void post_device_ungrabbed_event(device_id device_id) {
    auto event = event_queue::event::make_device_ungrabbed_event();
    event_queue::entry entry(device_id,
                             event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                             event,
                             event_type::single,
                             std::nullopt,
                             event,
                             event_queue::state::virtual_event);

    merged_input_event_queue_->push_back_entry(entry);

    krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
  }

  void post_device_keys_and_pointing_buttons_are_released_event() {
    auto event = event_queue::event::make_device_keys_and_pointing_buttons_are_released_event();
    event_queue::entry entry(device_id(0),
                             event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                             event,
                             event_type::single,
                             std::nullopt,
                             event,
                             event_queue::state::virtual_event);

    merged_input_event_queue_->push_back_entry(entry);

    krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
  }

  void post_caps_lock_state_changed_event(bool caps_lock_state) {
    auto event = event_queue::event::make_caps_lock_state_changed_event(caps_lock_state);
    event_queue::entry entry(device_id(0),
                             event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                             event,
                             event_type::single,
                             std::nullopt,
                             event,
                             event_queue::state::virtual_event);

    merged_input_event_queue_->push_back_entry(entry);

    krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
  }

  // This method is executed in the shared dispatcher thread.
  void grab_device(device_grabber_details::entry& entry) const {
    auto state = make_grabbable_state(entry);
    switch (state) {
      case grabbable_state::state::grabbable:
        entry.async_start_hid_device_events_monitor(state);
        break;

      case grabbable_state::state::ungrabbable:
      case grabbable_state::state::none:
      case grabbable_state::state::end_:
        entry.async_stop_hid_device_events_monitor();
        break;
    }
  }

  // This method is executed in the shared dispatcher thread.
  void grab_device(device_id device_id) const {
    if (auto it = entries_.find(device_id);
        it != entries_.end()) {
      grab_device(*(it->second));
    }
  }

  // This method is executed in the shared dispatcher thread.
  grabbable_state::state make_grabbable_state(const device_grabber_details::entry& entry) const {
    //
    // The device is always grabbable if it is observed device.
    // Because Karabiner-Core-Service never takes exclusive control of a device,
    // It doesn't cause side effects such as interfering with key input processing in hidd.
    //

    if (entry.needs_to_observe_device()) {
      return grabbable_state::state::grabbable;
    }

    //
    // From here, we determine whether it's safe to take exclusive control of the device.
    // If we take control before the virtual device is ready,
    // input events will have nowhere to go and be dropped,
    // so we must not grab the device until we're ready to send input events.
    //

    if (!entry.needs_to_seize_device()) {
      return grabbable_state::state::ungrabbable;
    }

    //
    // Ungrabbable while virtual_hid_device_service_client_ is not ready.
    //

    if (!virtual_hid_devices_state_.get_virtual_hid_keyboard_ready()) {
      std::string message = "virtual_hid_keyboard is not ready. Please wait for a while.";
      logger_unique_filter_.debug(message);
      return grabbable_state::state::ungrabbable;
    }

    if (needs_prepare_virtual_hid_pointing_device()) {
      if (!virtual_hid_devices_state_.get_virtual_hid_pointing_ready()) {
        std::string message = "virtual_hid_pointing is not ready. Please wait for a while.";
        logger_unique_filter_.debug(message);
        return grabbable_state::state::ungrabbable;
      }
    }

    //
    // It's okay to take exclusive control of the device.
    //

    return grabbable_state::state::grabbable;
  }

  void update_caps_lock_led() {
    std::optional<led_state> state;
    if (last_caps_lock_state_) {
      state = *last_caps_lock_state_ ? led_state::on : led_state::off;
    }

    for (auto&& entry : entries_ | std::views::values) {
      entry->set_caps_lock_led_state(state);
    }
  }

  [[nodiscard]] bool needs_prepare_virtual_hid_pointing_device() const {
    //
    // Check if there is a pointing device to grab
    // (The game pad also sends mouse events, so a virtual pointing device should be prepared as well.)
    //

    for (const auto& entry : entries_ | std::views::values) {
      if (entry->needs_to_seize_device()) {
        auto device_properties = entry->get_device_properties();
        if (device_properties->get_device_identifiers().get_is_pointing_device() ||
            device_properties->get_device_identifiers().get_is_game_pad()) {
          return true;
        }
      }
    }

    //
    // Check if a setting exists that would fire pointing device events
    //

    if (manipulator_managers_connector_.needs_virtual_hid_pointing()) {
      return true;
    }

    return false;
  }

  void update_virtual_hid_keyboard() {
    pqrs::karabiner::driverkit::virtual_hid_device_service::virtual_hid_keyboard_parameters parameters;

    auto t = core_configuration_->get_selected_profile().get_virtual_hid_keyboard()->get_iokit_keyboard_type();
    if (t == pqrs::osx::iokit_keyboard_type::ansi) {
      // Apple Aluminum USB Keyboard (A1243) (ANSI)
      parameters.set_vendor_id(pqrs::hid::vendor_id::value_t(0x05ac));
      parameters.set_product_id(pqrs::hid::product_id::value_t(0x024f));
    } else if (t == pqrs::osx::iokit_keyboard_type::iso) {
      // Apple Aluminum USB Keyboard (A1243) (ISO)
      parameters.set_vendor_id(pqrs::hid::vendor_id::value_t(0x05ac));
      parameters.set_product_id(pqrs::hid::product_id::value_t(0x0250));
    } else if (t == pqrs::osx::iokit_keyboard_type::jis) {
      // Apple Aluminum USB Keyboard (A1243) (JIS)
      parameters.set_vendor_id(pqrs::hid::vendor_id::value_t(0x05ac));
      parameters.set_product_id(pqrs::hid::product_id::value_t(0x0251));
    } else {
      logger::get_logger()->warn("unknown virtual_hid_keyboard keyboard_type: {0}", type_safe::get(t));
    }

    virtual_hid_device_service_client_->async_virtual_hid_keyboard_initialize(parameters);
  }

  void update_virtual_hid_pointing() {
    if (needs_prepare_virtual_hid_pointing_device()) {
      virtual_hid_device_service_client_->async_virtual_hid_pointing_initialize();
      return;
    }

    virtual_hid_device_service_client_->async_virtual_hid_pointing_terminate();
  }

  [[nodiscard]] bool need_to_disable_built_in_keyboard() const {
    for (const auto& entry : entries_ | std::views::values) {
      if (entry->is_disable_built_in_keyboard_if_exists()) {
        return true;
      }
    }
    return false;
  }

  void update_devices_disabled() {
    for (const auto& entry : entries_ | std::views::values) {
      if (entry->determine_is_built_in_keyboard() &&
          need_to_disable_built_in_keyboard()) {
        entry->set_disabled(true);
      } else {
        entry->set_disabled(false);
      }
    }
  }

  void update_complex_modifications_manipulators() {
    complex_modifications_manipulator_manager_->invalidate_manipulators();

    for (const auto& rule : core_configuration_->get_selected_profile().get_complex_modifications()->get_rules()) {
      if (!rule->get_enabled()) {
        continue;
      }

      for (const auto& manipulator : rule->get_manipulators()) {
        try {
          auto m = manipulator::manipulator_factory::make_manipulator(manipulator->to_json(),
                                                                      manipulator->get_parameters());
          for (const auto& c : manipulator->get_conditions()) {
            m->push_back_condition(manipulator::condition_factory::make_condition(c.get_json()));
          }
          complex_modifications_manipulator_manager_->push_back_manipulator(m);

        } catch (const pqrs::json::unmarshal_error& e) {
          logger::get_logger()->error(fmt::format("karabiner.json error: {0}", e.what()));

        } catch (const std::exception& e) {
          logger::get_logger()->error(e.what());
        }
      }
    }
  }

  void set_cgeventtap_fallback_enabled(bool value) {
    if (cgeventtap_fallback_enabled_ == value) {
      logger::get_logger()->debug("enable_cgeventtap_fallback unchanged: effective={0}",
                                  cgeventtap_fallback_enabled_);
      return;
    }

    cgeventtap_fallback_enabled_ = value;

    logger::get_logger()->debug("enable_cgeventtap_fallback changed: effective={0}",
                                cgeventtap_fallback_enabled_);

    if (post_event_to_virtual_devices_manipulator_) {
      post_event_to_virtual_devices_manipulator_->set_cgeventtap_fallback_enabled(cgeventtap_fallback_enabled_);
    }

    setup_event_tap_monitor(cgeventtap_fallback_enabled_);

    async_grab_devices();
  }

  void setup_event_tap_monitor(bool cgeventtap_fallback_enabled) {
    logger::get_logger()->debug("setup_event_tap_monitor (enable_cgeventtap_fallback={0})",
                                cgeventtap_fallback_enabled);

    // Keep only the latest requested configuration while the previous monitor
    // is stopping. This prevents old and new EventTaps from being active at the
    // same time when configuration changes arrive in quick succession.
    pending_event_tap_monitor_configuration_ = cgeventtap_fallback_enabled;

    if (event_tap_monitor_stopping_) {
      return;
    }

    if (event_tap_monitor_) {
      event_tap_monitor_stopping_ = true;

      std::weak_ptr<bool> weak_lifetime(event_tap_monitor_lifetime_);
      async_stop_event_tap_monitor([this, weak_lifetime] {
        // Both invalidation and this completion run on the shared dispatcher,
        // so a valid token guarantees that device_grabber is still alive here.
        if (!weak_lifetime.lock()) {
          return;
        }

        event_tap_monitor_stopping_ = false;
        create_pending_event_tap_monitor();
      });

      return;
    }

    create_pending_event_tap_monitor();
  }

  void create_pending_event_tap_monitor() {
    if (!pending_event_tap_monitor_configuration_) {
      return;
    }

    auto cgeventtap_fallback_enabled = *pending_event_tap_monitor_configuration_;
    pending_event_tap_monitor_configuration_ = std::nullopt;

    event_tap_monitor_ = std::make_unique<event_tap_monitor>(
        cgeventtap_fallback_enabled,
        post_event_to_virtual_devices_manipulator_->get_virtual_hid_keyboard_pressed_keys_manager(),
        post_event_to_virtual_devices_manipulator_->get_keyboard_suppression());

    event_tap_monitor_->pointing_device_event_arrived.connect([this](auto&& event_type, auto&& event) {
      auto e = event_queue::event::make_pointing_device_event_from_event_tap_event();
      event_queue::entry entry(device_id(0),
                               event_queue::event_time_stamp(pqrs::osx::chrono::mach_absolute_time_point()),
                               e,
                               event_type,
                               std::nullopt,
                               event,
                               event_queue::state::virtual_event);

      merged_input_event_queue_->push_back_entry(entry);

      krbn_notification_center::get_instance().enqueue_input_event_arrived(*this);
    });

    event_tap_monitor_->keyboard_event_arrived.connect([this](auto&& event_type, auto&& event) {
      event_tap_keyboard_event_arrived(event_type, event);
    });

    event_tap_monitor_->async_start();
  }

  void async_stop_event_tap_monitor(std::function<void()> completion = nullptr) {
    if (!event_tap_monitor_) {
      if (completion) {
        completion();
      }
      return;
    }

    // Remove the monitor from device_grabber immediately so shutdown or a new
    // setup can continue without waiting for its run-loop thread. Keep it alive
    // through the completion until EventTap cleanup has finished on that thread.
    std::shared_ptr<event_tap_monitor> event_tap_monitor(std::move(event_tap_monitor_));
    event_tap_monitor->async_stop([event_tap_monitor, completion] {
      // Keep event_tap_monitor alive until its run loop has stopped, then
      // continue a pending replacement if the owner is still alive.
      if (completion) {
        completion();
      }
    });
  }

  // Some input paths (for example around secure event input transitions or CGEventTap fallback re-entry)
  // can deliver a key_up without a corresponding key_down, or repeated key_down while the same key is
  // still treated as pressed. If we push such unbalanced events into merged_input_event_queue_,
  // downstream state can become inconsistent and cause stuck keys or re-entry loops.
  // Therefore we have to drop unbalanced momentary switch events before queue insertion.
  bool unbalanced_momentary_switch_event(device_id device_id,
                                         const event_queue::event& event,
                                         event_type event_type) {
    auto& pressed_momentary_switch_events = physical_pressed_momentary_switch_events_[device_id];

    if (auto mse = event.template get_if<momentary_switch_event>()) {
      if (!mse->valid()) {
        return false;
      }

      switch (event_type) {
        case event_type::key_down:
          if (pressed_momentary_switch_events.contains(*mse)) {
            logger::get_logger()->warn("drop duplicated momentary switch key_down before merged_input_event_queue insertion");
            return true;
          }
          pressed_momentary_switch_events.insert(*mse);
          break;

        case event_type::key_up:
          if (!pressed_momentary_switch_events.contains(*mse)) {
            logger::get_logger()->warn("drop unmatched momentary switch key_up before merged_input_event_queue insertion");
            return true;
          }
          pressed_momentary_switch_events.erase(*mse);
          break;

        case event_type::single:
          break;
      }
    }

    return false;
  }

  std::weak_ptr<console_user_server_peer> weak_console_user_server_peer_;
  std::weak_ptr<core_service_daemon_state_manager> weak_core_service_daemon_state_manager_;

  std::shared_ptr<pqrs::karabiner::driverkit::virtual_hid_device_service::client> virtual_hid_device_service_client_;

  virtual_hid_devices_state virtual_hid_devices_state_;

  // Connections to signals owned by objects that may outlive device_grabber.
  // Keep them here to ensure that callbacks referencing this are disconnected
  // before device_grabber is destroyed.
  std::vector<nod::scoped_connection> external_signal_connections_;

  std::unique_ptr<configuration_monitor> configuration_monitor_;
  pqrs::not_null_shared_ptr_t<const core_configuration::core_configuration> core_configuration_;

  std::unique_ptr<event_tap_monitor> event_tap_monitor_;
  std::shared_ptr<bool> event_tap_monitor_lifetime_ = std::make_shared<bool>();
  std::optional<bool> pending_event_tap_monitor_configuration_;
  bool event_tap_monitor_stopping_ = false;
  std::optional<bool> last_caps_lock_state_;
  std::unique_ptr<pqrs::osx::iokit_hid_manager> hid_manager_;
  std::unordered_map<device_id, pqrs::not_null_shared_ptr_t<device_grabber_details::entry>> entries_;
  std::unordered_set<device_id> temporarily_ignored_device_ids_;

  std::unique_ptr<pqrs::osx::hitoolbox::secure_event_input_monitor> secure_event_input_monitor_;

  pqrs::osx::system_preferences::properties system_preferences_properties_;

  manipulator::manipulator_managers_connector manipulator_managers_connector_;

  std::shared_ptr<notification_message_manager> notification_message_manager_;

  std::shared_ptr<event_queue::queue> merged_input_event_queue_;

  std::shared_ptr<device_grabber_details::device_key_code_manipulator_manager> device_key_code_manipulator_manager_;
  std::shared_ptr<event_queue::queue> device_key_code_manipulated_event_queue_;

  std::shared_ptr<device_grabber_details::simple_modifications_manipulator_manager> simple_modifications_manipulator_manager_;
  std::shared_ptr<event_queue::queue> simple_modifications_applied_event_queue_;

  std::shared_ptr<manipulator::manipulator_manager> complex_modifications_manipulator_manager_;
  std::shared_ptr<event_queue::queue> complex_modifications_applied_event_queue_;

  std::shared_ptr<device_grabber_details::fn_function_keys_manipulator_manager> fn_function_keys_manipulator_manager_;
  std::shared_ptr<event_queue::queue> fn_function_keys_applied_event_queue_;

  std::shared_ptr<manipulator::manipulators::post_event_to_virtual_devices::post_event_to_virtual_devices> post_event_to_virtual_devices_manipulator_;
  std::shared_ptr<manipulator::manipulator_manager> post_event_to_virtual_devices_manipulator_manager_;
  std::shared_ptr<event_queue::queue> posted_event_queue_;
  std::unordered_map<device_id, std::unordered_set<momentary_switch_event>> physical_pressed_momentary_switch_events_;

  bool cgeventtap_fallback_enabled_ = false;

  mutable pqrs::spdlog::unique_filter logger_unique_filter_;
};
} // namespace krbn::core_service::daemon
