"""Replay only immutable finite Source controls; no canonical or native execution."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, tempfile
parser = argparse.ArgumentParser()
parser.add_argument('--immutable-inputs', type=Path, required=True)
parser.add_argument('--predecessor-packet', type=Path, required=True)
parser.add_argument('--node', type=Path, required=True)
parser.add_argument('--work-root', type=Path, required=True)
args = parser.parse_args()
packet = Path(__file__).resolve().parent
inventory = json.loads((packet/'immutable-inputs37.inventory.json').read_text())['entries']
args.work_root.mkdir(parents=True, exist_ok=True)
work = Path(tempfile.mkdtemp(prefix='updater-arm-source-', dir=args.work_root))
physical = work/'physical-source'
for item in inventory:
    src=args.immutable_inputs/item['path']
    data=src.read_bytes()
    assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'], item['path']
    dest=physical/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
relative='tools/test/test-windows-updater-original-source.cjs'
destination=physical/relative;destination.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(packet/'candidate.cjs',destination)
for name in ['model-arm-test.cjs','receive-arm-omission.cjs']:
    shutil.copyfile(packet/name,work/name)
source=(packet/'receive-counterfactuals.cjs').read_text()
start=source.index('const task=');end=source.index(';',start)
source=source[:start]+'const task='+json.dumps(str(args.predecessor_packet.resolve()))+source[end:]
(work/'receive-counterfactuals.cjs').write_text(source)
private_tmp=work/'tmp';private_tmp.mkdir()
env={**os.environ,'TMPDIR':str(private_tmp)}
rounds=[('final22',[str(destination)],0),('modeled-arm22',[str(work/'model-arm-test.cjs')],0),('counter-arm-omission',[str(work/'receive-arm-omission.cjs')],1)]
rounds.extend((name,[str(work/'receive-counterfactuals.cjs'),mode],1) for name,mode in [('counter-scope','scope-before-wrapper'),('counter-proxy','proxy-before-snapshot'),('counter-local-argc','local-before-argc'),('counter-import','import-before-guard')])
records=[]
for name,arguments,expected in rounds:
    with (work/(name+'.stdout')).open('wb') as out, (work/(name+'.stderr')).open('wb') as err:
        result=subprocess.run([str(args.node),*arguments],env=env,stdout=out,stderr=err,timeout=60)
    stderr=(work/(name+'.stderr')).read_text()
    assert result.returncode==expected,(name,result.returncode)
    if expected:assert 'AssertionError [ERR_ASSERTION]' in stderr,(name,stderr)
    else:assert 'WINDOWS_UPDATER_SOURCE controls=22 native=false official=false' in (work/(name+'.stdout')).read_text()
    records.append({'name':name,'exit':result.returncode,'expected':expected})
(work/'reproduction.receipt.json').write_text(json.dumps({'records':records,'native':False,'official':False},indent=2)+'\n')
print(work)
