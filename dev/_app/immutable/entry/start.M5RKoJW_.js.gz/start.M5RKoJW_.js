import{l as o,a as r}from"../chunks/CMACC6zg.js";export{o as load_css,r as start};
