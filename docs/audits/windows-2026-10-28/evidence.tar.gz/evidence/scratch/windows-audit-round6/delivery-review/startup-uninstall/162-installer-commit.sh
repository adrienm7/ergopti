set -euo pipefail
cd /workspace/ergopti-windows-r7-installer
pwd
if test -n "$(git diff --cached --name-only)"; then
    printf '%s\n' 'Refusing to mix an existing index with the installer fix' >&2
    exit 1
fi
git diff --check
git add -- static/ergopti_plus/windows/vendor/ergopti_uninstall.ps1 tools/test/test-windows-uninstall.cjs
git commit -F /workspace/scratch/windows-audit-round6/delivery-review/startup-uninstall/commit-message.txt
git status --short
git log -1 --format=fuller
