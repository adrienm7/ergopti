# Group 1 — remaining software and device receiving

Checkpoint: 2026-10-11, before Root's final title delivery. The corrected title gate is ACTIVE; no terminal result is inferred. This external Source-only handover changes no canonical file, index or ref. Final commit/Dev/native/CI fields below await actual Root results. Items5/7/33/42/54/81 remain partial; transversal16/38 stay mandatory; withdrawn differential-updates22 must not return.

## Delivered versus pending

- Dev already received ordinary no-squash merges c4180d8d8d368e7e41a71c542b1edabdc0b36ee0 and c15a16cc9eee103b4132bcaf811ed890834f894c. Preserve the13 owned commits in DECLARED-CATALOGUES-DEV-INTEGRATION-20261011.json and other groups' history; do not redo integrated catalogue/config/menu work.
- Mac wizard timeout refusal is published on feat/config-menus as c19927d7edcedeb0dbfc2f92300461bc5f285ae8; Dev integration is not asserted here. Genuine owning replay18/0, predecessor15/3 and inverse18/0 passed; selected410 JS,18,441 Mac units and101 Mac E2E plus one old host skip passed. Manual38112231515 was dispatched on same-tree CI54c8e0d4; Root must supply its final result.
- The new title/shared-presentation tranche remains unpublished at this checkpoint. Current genuine scanner census19 Windows/2 Mac/1 Linux is source work plus native acceptance, not a declaration that all remaining work is device-only. Prior failing gates stay preserved. The old assembled title V2 patch is not a ready continuation patch.

## Remaining Group 1 scope

| Item | Software/ownership versus acceptance |
| --- | --- |
|5 | Current recommended/clear/global/journal owners are implemented. Qualify constructor-owned source, neutral defaults, effective inherited delays, Script participant, backup/rollback, native ACK/conflict/retry and installed scopes. Retired autocorrection.caps is preserved obsolete data until explicit cleanup, not a recommendation target. |
|7 | Installed fresh/existing/moved-folder wizard, genuine Browse, all seven Yes/No pages,21-language text, kept/customized key locking, runtime restart and retry. Linux21locale/recommended native extensions are prepared but UNRUN; Mac timeout code is implemented, installed acceptance remains. |
|33 | Actual Windows keyboard catalogue publication needs G3/G7 input-owner cooperation; Mac aggregate Hotstrings category/section/order authority belongs to G2; Linux dynamic models belong to G4. Lua logical/physical keyboard, gestures and combination catalogues already have constructor-issued currentness; do not duplicate them. Invalid/newer schema refuses migration/writes; retired source remains until explicit cleanup. Remaining current owner audits/native startup remain. |
|42 | Complete Windows WAL/scope/journal/native receiving and authentic subject1306 foreign-source race; finish full suites/E2E/package/install. Retired-Script and final installed publication acceptance remain separate. Never grant authority to copied/replaced native owners or erase obsolete scalar/array parents during ordinary saves. |
|54/81 | Genuine remaining producer ownership below, full joined native CI and installed menus; existing typed frames must not be cosmetically reimplemented. |

## Actual remaining Source sites

Windows19 is assigned to the maintainer; baseline `tools/test/native-menu-rows-baseline.json` owns the census. Driver-relative sites:

| File | Lines/count | Actual source boundary |
| --- | --- | --- |
|infra/tray_bootstrap.ahk |63/1 | Native temporary disabled root; preserve critical/native retirement. |
|ui/menu/menu_hotstrings.ahk |945,1106,1283,1297/4 |945/1297 already receive shared frames;1106 retains late file stem/count/submenu,1283 folder caption/submenu. Coordinate G2 providers; preserve active-count effects/cleanup. |
|ui/menu/menu_llm/menu_main.ahk |416,453,465,492,499,503,507,511/8 | AppendRows/AppendGroup of real shared frames/groups; audit actual DATA/native custody before any change. G4 owns business callbacks. |
|ui/menu/menu_llm/menu_models.ahk |259,291,297,338/4 | Header/catalogue/tail/installed tag receiving, some already declared; dynamic models and fallback remain G4-owned. |
|ui/menu/menu_shortcuts.ahk |191,196/2 | Existing declared extension error/empty frames; preserve G3 builder and callbacks. |

Mac2: models_manager_mlx_hf.lua:830 HF token-prompt title and profiles_manager.lua:1068 shortcut-dialog title. Linux1: menu_builder.lua:2376 debounce numeric PAGE title, distinct from its native window. All require explicit G4 producer handoff and actual receiving; shared primitives alone transfer no business custody.

## Windows maintainer steps

1. After Root supplies integrated SHA, fetch current Dev and preserve existing worktree/index. Use an isolated test profile, exact pinned AHK/runtime and compiled identities. Read AGENTS/verify-change/configuration memory; no reapplication of integrated source.
2. Use existing collector `node tools/test/test-ahk-suite-manifest.cjs --ahk <AutoHotkey64.exe>` and genuine `windows/tests/run_all.ahk`. Replay syntax: `<AutoHotkey64.exe> /ErrorStdOut <run_all.ahk> --only <substring>`. Replay `config-scope:`, `config migrate:`, `terminator-records:` and `onboarding`; collect actual TAP/result files after exit. Filtered receiving does not replace the full suite.
3. Item5: recommended/clear/global on real constructor-stamped source; typed false/default inheritance, unknown/foreign bytes, backups, runtime refusal/repair/retry, Script participation and restart/rerun. Item33: full private keyboard inventory independent of active/pause state; withdrawal/replacement unjudged without foreign observation and exact repair; strict schema refusal and explicit obsolete cleanup through real read/set/report owners.
4. Item42: first apply the separately reviewed genuine boot prerequisite only if its exact preimage still matches and G2 custody is clear. It fixes the fixture's positive boot source, not subject1306. That subject replaces the canonical Port.hash and correctly revokes native admission before intended capture. Find an authentic deterministic independent write after capture/before conditional commit, preserving all assertions/guards/cleanup; custom ports, hash own-Call replacement, fake WAL or polling without acknowledged ordering cannot prove the original conflict.
5. Preserve watchdog/full-suite contracts. Exact run38107369273/source1e5c1faf planned11,121 and completed1,988:1,987 PASS/1 FAIL1306,9,133 UNRUN at unchanged1,320,000ms watchdog. E2E/package/install skipped. This is incomplete coverage, not proof of a single-test hang. Unsafe exact-owner optimization stays HOLD. Measure genuine12/34-target cost/guards; do not raise budgets/remove tests for green.
6. Installed wizard/menus: cancel fresh with no files; Finish all seven No pages; restart/rerun and verify sparse/default-on false. Real Browse to moved folder, select only recommended left Alt, preserve kept/customized locked keys and backups; verify actual nav/backspace and restart. Exercise switch/recommend/clear/global-clear, captions/order/enabled states and refusal/retry. Physical keyboard acceptance is separate from synthetic/unit input.
7. Run verify-change/full native suites and manual ci.yml with affected OS lanes, all three for shared drivers, no release. After every push cancel automatic runs for exact SHA; let manual runs finish. Report units/E2E/package/install PASS/FAIL/SKIP/UNRUN separately. Only final Dev integration uses its coordinated lock.

## Mac and Linux acceptance limits

The user can test Windows and a work Mac, without exporting Mac logs. On an available permitted installation/private test profile, record local yes/no observations for seven-page wizard, moved folder/cancel/Finish/retry, kept keys, recommend/clear/global actions, actual native/page captions, restart/rerun and physical TapHold/nav. A blocked case stays UNRUN with its actual missing prerequisite; no logs are needed to report these observations.

Historical Linux V4 uses genuine Gtk3/WebKit4.1/Xvfb/DBus/HostBridge/Manager and real private XDG/config files: cancel8/8, all-No Finish42/42, persisted-folder/English rerun47/47; independent file34/34. Sessions/Xvfb retired and654 runtime pins reconciled; receipt4a799953… is historical.17 later Source changes plus presentation7956→43f631 require fresh receiving.

Prepared V7 keeps the original body and adds21locale DOM/GTK/page text and chosen-folder left_alt/backspace/nav/0.20 real writer/nav-preset checks. All five-scenario runtime counts remain UNRUN here. Receiving proves real writers without engine reload, not physical/live remapping or installed restart. Reviewed Root fence V2 requires strict final selected PASS and current published Source; monitors complete tracked membership plus every explicit selected path, bytes/kinds, rawindex and HEAD before/finally.

Browse is a real synchronous zenity/kdialog invocation via ui.modal→shell.exec_line. Choosers and xdotool are absent; genuine separately owned X11 chooser/automation is required, never a fake selection. /dev/input and /dev/uinput are absent; physical input, Wayland and installed startup/restart remain unqualified. Keep16/38 open.

## Durable pending subset

`pending/` contains only the finite original Windows boot patch and G4 HF/profile/numeric handoffs, original captions and Source receipts;111KB, no checkout/source snapshots or old assembled title patch. `PENDING-PACKETS.json` pins every copied file, extraction origin and exact pre/post/current Source hashes. Saved Source PASS is not native acceptance or G4 grant.

- Windows boot: exact current pre2a3a18c0→post8c745fa2, patch9bc5cea3, finite boot Source PASS/race HOLD. Native parser/positive baseline/race/full CI UNRUN; all original race assertions and native hash-revocation protection remain.
- G4 HF V2: actual current producer84c2a38c and fixture842c5b0f match saved preimages; source-only review covers genuine cohort/cleanup, but owner grant and runtime remain UNRUN. Require full original module plus three authentic added subjects and genuine cleanup records, not physical Cocoa claims.
- G4 profile: two original unchanged file-diff chunks are extracted from the reviewed finite packet, with original source/range hashes. Producerd376dfa8/fixturec5f253e1 currently match. Review covers those original bytes; no new qualification from extraction. Revalidate current shared factory/order/cleanup and obtain G4 custody before actual receiving; other shared/Linux old hunks are not included.
- G4 numeric V1: renderer399983dc and owningfixture29060ed6 match CURRENT Source. ONLY menu_builder67ee49ef preimage has drifted. Preserve original32 prospective subjects/21 independent captions and G4 bounds/save callbacks; recompose just the numeric PAGE receiving hunk against fresh builder, review then execute. Do not apply the whole stale three-path patch directly.

## Root final receiving fields

Final title feature SHA / Dev no-ff merge: PENDING. Corrected selected gate verdict/counts/Source-index-HEAD fence: PENDING. Actual V7 five native modes/counts/cleanup: UNRUN. Final manual CI IDs/testedSHA/OS lanes/unit/E2E/package/install/release-skip: PENDING. Feature deletion after proved integration/required validation: PENDING. Root should receive only this concise handover/subset and append only Group1 TODO status, preserving other groups and16/38/22.
