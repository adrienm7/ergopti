class NativeClockRefused(RuntimeError):
    pass


def native_clock_frame(raw, before, after):
    # Compare every actual sample; never infer a shared epoch from the endpoints.
    def finite_number(value):
        if type(value) not in (int, float):
            return False
        try:
            return math.isfinite(value)
        except OverflowError:
            return False

    if (
        type(raw) is not bytes
        or not 1 <= len(raw) <= 4096
        or not raw.endswith(b"\n")
        or raw.count(b"\n") != 1
        or not finite_number(before)
        or not finite_number(after)
        or not 0 < before <= after
        or after - before > 15
    ):
        raise NativeClockRefused("Native clock frame refused")

    def unique(pairs):
        if len({key for key, _ in pairs}) != len(pairs):
            raise NativeClockRefused("Native clock duplicate field refused")
        return dict(pairs)

    def nonfinite(value):
        raise NativeClockRefused("Native clock nonfinite field refused")

    try:
        fields = json.loads(raw.decode("ascii"), object_pairs_hook=unique, parse_constant=nonfinite)
    except (ValueError, UnicodeError) as refused:
        raise NativeClockRefused("Native clock JSON refused") from refused
    if (
        type(fields) is not dict
        or set(fields) != {"version", "system_uptime"}
        or type(fields["version"]) is not int
        or fields["version"] != 1
        or type(fields["system_uptime"]) is not list
        or len(fields["system_uptime"]) != 16
    ):
        raise NativeClockRefused("Native clock grammar refused")
    samples = fields["system_uptime"]
    for index, sample in enumerate(samples):
        if (
            not finite_number(sample)
            or not before <= sample <= after
            or (index > 0 and sample < samples[index - 1])
        ):
            raise NativeClockRefused("Native clock epoch/order refused")
    return samples


def native_clock_epoch(environment, architecture):
    if architecture not in ("arm64", "amd64"):
        raise NativeClockRefused("Native clock architecture context refused")
    names = ("GITHUB_SHA", "GITHUB_RUN_ID", "GITHUB_RUN_ATTEMPT")
    values = [environment.get(name) for name in names]
    # A local native run can receive numeric samples without claiming CI context.
    if all(value is None for value in values):
        return None
    if (
        any(type(value) is not str for value in values)
        or re.fullmatch(r"[0-9a-f]{40}", values[0]) is None
        or re.fullmatch(r"[1-9][0-9]{0,19}", values[1]) is None
        or re.fullmatch(r"[1-9][0-9]{0,5}", values[2]) is None
    ):
        raise NativeClockRefused("Native clock run context refused")
    return {"candidate": values[0], "run_id": values[1], "run_attempt": values[2],
            "architecture": architecture, "provenance": "github_environment"}


def receive_native_clock(build, builder):
    if sys.platform != "darwin" or not build.fixture.native or build.fixture.groups is None:
        raise NativeClockRefused("Native clock requires the actual Darwin child owner")
    executable = build.verify()
    image, identity = builder.regular_bytes(executable)
    architecture = {"arm64": "arm64", "x86_64": "amd64"}.get(os.uname().machine)
    cpu = {"arm64": 0x0100000C, "amd64": 0x01000007}.get(architecture)
    if (
        len(image) < 32
        or image[:4] != b"\xcf\xfa\xed\xfe"
        or int.from_bytes(image[4:8], "little") != cpu
    ):
        raise NativeClockRefused("Native clock signed image architecture refused")
    epoch = native_clock_epoch(os.environ, architecture)
    receiver, _ = builder.regular_bytes(Path(__file__))
    receiver_digest = hashlib.sha256(receiver).hexdigest()
    before = time.monotonic()
    status, raw = build.fixture._command(
        [str(executable), "--fixture-clock-proof"], timeout=15, deadline=before + 15
    )
    after = time.monotonic()
    if type(status) is not int or status != 0:
        raise NativeClockRefused("Native clock child refused")
    samples = native_clock_frame(raw, before, after)
    build.verify()
    if hashlib.sha256(builder.regular_bytes(Path(__file__))[0]).hexdigest() != receiver_digest:
        raise NativeClockRefused("Native clock receiver source changed")
    if native_clock_epoch(os.environ, architecture) != epoch:
        raise NativeClockRefused("Native clock run context changed")
    fact = {
        "version": 1,
        "state": "observed",
        "native_acceptance": "UNQUALIFIED_GIT_HEAD_CLEANLINESS_NOT_RECEIVED",
        "git_head": None,
        "tracked_clean_sources": None,
        "epoch": epoch,
        "context_bound": epoch is not None,
        "python_before": before,
        "python_after": after,
        "system_uptime": samples,
        "source_receipt_sha256": build.receipt_digest,
        "source_hashes": dict(build.source_hashes),
        "staged_hashes": dict(build.staged_hashes),
        "receiver_sha256": receiver_digest,
        "binary_sha256": build.image_digest,
        "device": identity.st_dev,
        "inode": identity.st_ino,
        "architecture": architecture,
        "signature": "existing_build_codesign_strict_verified_same_image",
    }
    encoded = json.dumps(fact, sort_keys=True)
    if len(encoded.encode("ascii")) > 16_384:
        raise NativeClockRefused("Native clock receipt bound refused")
    # This observation uses stderr; the worker stdout response ABI is unchanged.
    # Technical publication refusal is optional, genuine cancellation propagates.
    try:
        print("# native_http_clock_proof " + encoded,
              file=sys.stderr, flush=True)
    except BaseException as refused:
        if not isinstance(refused, Exception) or (
            type(refused) is wire.FixtureFailure
            and refused.args == ("Native fixture cancelled",)
        ):
            raise
    return fact
