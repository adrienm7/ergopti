'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {spawnSync} = require('node:child_process');
const root = __dirname;
const source = path.join(root,'candidate-physical-source');
const inventory = JSON.parse(fs.readFileSync(path.join(root,'source-inventory.json'),'utf8'));
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
function fence() {
 for (const entry of inventory.source_files) {
  for (const directory of [source, '/workspace/ergopti']) {
   const expected = directory === source && entry.path === 'tools/ci/native_http_clock_evidence.cjs' ? '83743c317166cf908bf0f4a5efee09bfb6e49db016163ea195c8825836f53e96' : entry.sha256;
   if (hash(fs.readFileSync(path.join(directory,entry.path))) !== expected)
    throw new Error('Source fence refused: '+directory+'/'+entry.path);
  }
 }
}
const mode = process.argv[2];
if (!['candidate','candidate-profiled'].includes(mode)) throw new Error('Fixed receiving mode missing');
fence();
const temporary = path.join(root,'tmp-'+mode);fs.mkdirSync(temporary,{mode:0o700});
const args = mode === 'candidate-profiled' ? ['-r',path.join(root,'observe.cjs')] : [];
args.push(path.join(source,'tools/test/test-native-http-clock-evidence.cjs'));
const env = {...process.env, TMPDIR:temporary, NODE_PATH:'/workspace/ergopti/node_modules', CLOCK32_OBSERVATION:path.join(root,'candidate-profiled-observation.jsonl')};
const before = process.hrtime.bigint();
const result = spawnSync(process.execPath,args,{cwd:source,encoding:'utf8',timeout:60000,env});
const milliseconds = Number(process.hrtime.bigint()-before)/1e6;
fs.writeFileSync(path.join(root,mode+'.stdout'),result.stdout??'');
fs.writeFileSync(path.join(root,mode+'.stderr'),result.stderr??'');
let reaped = null;
if (result.pid) { try { process.kill(result.pid,0);reaped=false; } catch(e) {reaped=e.code==='ESRCH';} }
const receipt = {mode,node:process.version,argv:args,timeout:60000,milliseconds,pid:result.pid??null,child_reaped:reaped,status:result.status,signal:result.signal,error:result.error?.code??null,passed:(result.stdout?.match(/^PASS /gm)??[]).length,footer:/^CLOCK_RECEIVER controls=32 native=false official=false$/m.test(result.stdout??''),stdout_sha256:hash(result.stdout??''),stderr_sha256:hash(result.stderr??''),native:false,live_adoption:false};
fence();receipt.before_after_source_fence=true;
fs.writeFileSync(path.join(root,mode+'.receipt.json'),JSON.stringify(receipt,null,2)+'\n');
process.stdout.write(JSON.stringify(receipt)+'\n');
process.exitCode = result.status===0&&receipt.passed===32&&receipt.footer&&reaped===true?0:1;
