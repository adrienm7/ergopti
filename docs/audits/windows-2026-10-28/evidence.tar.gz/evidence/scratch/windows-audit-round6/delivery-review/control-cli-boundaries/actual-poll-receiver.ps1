param([string]$Folder,[string]$SpecPath,[string]$RequestId,[int]$DriverPid=4000,[int]$TimeoutMs=1000)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$folder=$Folder
$spec=Get-Content -Raw -Encoding UTF8 -LiteralPath $SpecPath|ConvertFrom-Json
$requestId=$RequestId
$driverPid=$DriverPid
function Write-Outcome($outcome) {
	$outcome | ConvertTo-Json -Compress
}
$resultPath = Join-Path $folder $spec.files.result
$deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
$last = $null
while ([DateTime]::UtcNow -lt $deadline) {
	if (Test-Path -LiteralPath $resultPath -PathType Leaf) {
		$result = $null
		try { $result = Get-Content -Raw -Encoding UTF8 -LiteralPath $resultPath | ConvertFrom-Json } catch { $result = $null }
		if ($null -ne $result -and $result.request_id -eq $requestId) {
			$last = $result
			if ($result.state -eq 'completed') { Write-Outcome $result; exit 0 }
			if ($result.state -eq 'refused') { Write-Outcome $result; exit 1 }
			if ($result.state -eq 'timeout') { Write-Outcome $result; exit 2 }
			# A restart that cannot name its successor leaves a pending record with a
			# deadline: past it, the answer is a timeout and never a completion.
			if ($result.state -eq 'requested' -and $null -eq $result.successor_pid -and $null -ne $result.deadline -and
				[DateTimeOffset]::UtcNow.ToUnixTimeSeconds() -gt [int64]$result.deadline) {
				Write-Outcome ([ordered]@{ request_id = $requestId; state = 'timeout'; reason = $spec.timeout_reason; driver_pid = $driverPid })
				exit 2
			}
		}
	}
	Start-Sleep -Milliseconds 200
}
if ($null -ne $last) { Write-Outcome $last } else {
	Write-Outcome ([ordered]@{ request_id = $requestId; state = 'unknown'; driver_pid = $driverPid })
}
exit 2
