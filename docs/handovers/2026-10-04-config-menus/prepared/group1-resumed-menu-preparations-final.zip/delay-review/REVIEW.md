# Independent prepared delay review and resumption boundary

Verdict: **BLOCKED / UNAPPROVED for integration in its current scope**.
Reviewed 15-path packet `tap-hold-delay-current.patch`, SHA256 `f8f32ad75ce2ed3d45d565b882bd38ddb702537b60b406217eb5621325717865`,
against exact independently accepted head + Metrics V3 preimages. Every packet
preimage/postimage and BOM/LF contract was verified; old native test byte prefixes
and earlier three independent corpora were retained.

Independent focused existing native-provider checks pass Linux27/0 on Lua5.4,
Linux27/0 on LuaJIT and macOS23/0 on Lua5.4 with portable native dependencies.
These checks do not execute Windows or prove physical UI behavior.

Windows already implements per-key `time_activation_seconds` through
`TapHoldDuration` and preserves these values in its writer. The missing delay
picker is a feasible unported UI, not an OS/runtime limitation. The packet hides
that Windows control and its older README claims an unsupported feature/global
control without an established owner. Root asked the author to implement the
actual Windows port; the latest immediate partial-integration steering stopped
that expansion before new Windows implementation code was written. The packet
therefore remains explicitly blocked/unapproved, with concrete resumption notes
at `/tmp/ergopti-delay-resume-packet/RESUMPTION.md`.

Windows resumption must reuse `_TH_CommitTapHoldMutation`, strict integer1 writer
and reload receipts, existing bounded loader duration constants and native
`Ui_InputBox` result contract. Preserve neighbors, actual write admission and
source/runtime refusal; cancellation/invalid input publishes and reloads zero
times. Respect printf `%s`/`%d` captions rather than AHK brace formatting.
Deleting a duration field may restore a shipped per-key default through loader
field-by-field inheritance, not a global200ms value. Loaded field presence does
not distinguish a stored override from inherited state. A minimal custom-only
port can match existing Linux behavior while retaining Mac-only global reset.

The forthcoming Linux delay caption needs separately handwritten expected
fixture state (empty keys currently yield0ms) in full menu certification; unknown
getters must remain strict. Update any now-obsolete Windows whole-child count
predicates only for the explicit new UI contract, retaining all head row/order,
Win32 rendering and callback assertions. Keep the old independent head corpus
unchanged; author new delay expectations from intended behavior, not output.

No root edits, index, refs or CI were performed by this reviewer. Disposable
copied source subtrees were removed only after preserving these receipts to
relieve the exhausted /tmp quota; author immutable packet/postimages and cached
bounded preimages still reconstruct the inspected source.
