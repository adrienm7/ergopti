"""Outside-only passive result timing; original unittest.main order and assertions."""
import json,os,runpy,sys,time,unittest,threading
from pathlib import Path
ROOT=Path(sys.argv[1]);OUTPUT=Path(sys.argv[2]);script=ROOT/'tools/test/macos_native_http_receiving_facts_test.py'
fd=os.open(OUTPUT,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
starts={};clock=time.monotonic();original_start=unittest.TextTestResult.startTest;original_stop=unittest.TextTestResult.stopTest

def record(value):
 os.write(fd,(json.dumps(value,sort_keys=True)+'\n').encode())

def children():
 try:return [int(v) for v in Path('/proc/self/task/'+str(os.getpid())+'/children').read_text().split()]
 except (OSError,ValueError):return None

def start(result,test):
 starts[test.id()]=time.monotonic();record({'event':'start','test':test.id(),'elapsed':starts[test.id()]-clock,'direct_children':children()});return original_start(result,test)

def stop(result,test):
 details={}
 fixture=getattr(test,'fixture',None)
 if fixture is not None:
  details['fixture_closed']=getattr(fixture,'closed',None)
  for field in ('command_group_debt','command_file_debt','connections'):
   value=getattr(fixture,field,None)
   if value is not None:details[field+'_count']=len(value)
  details['server_threads_alive']=sum(t.is_alive() for _,t in getattr(fixture,'server_threads',[]))
 model=getattr(test,'model',None)
 if model is not None:details['model_children']=[{'pid':o.process.pid,'returncode':o.process.returncode,'settle_calls':o.settle_calls,'stdin_closed':o.process.stdin.closed,'output_closed':o.process.output_capture.closed,'error_closed':o.process.error_capture.closed} for o in getattr(model,'children',[])]
 original_stop(result,test);now=time.monotonic();record({'event':'stop','test':test.id(),'duration':now-starts.pop(test.id()),'elapsed':now-clock,'direct_children':children(),'threads_alive':sum(t.is_alive() for t in threading.enumerate()),'passive_fixture_facts':details,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)})

unittest.TextTestResult.startTest=start;unittest.TextTestResult.stopTest=stop
sys.argv=[str(script),'-v']
try:runpy.run_path(str(script),run_name='__main__')
finally:record({'event':'terminal','elapsed':time.monotonic()-clock,'direct_children':children(),'threads_alive':sum(t.is_alive() for t in threading.enumerate())});os.close(fd)
