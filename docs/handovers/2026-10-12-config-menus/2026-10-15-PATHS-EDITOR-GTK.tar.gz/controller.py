import pathlib, os, sys, json, time, select, importlib.util, hashlib, subprocess, tarfile, io
B=pathlib.Path('/workspace/.ergopti-cloud'); P=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('native',B/'gtk-current-v9/run-private-wizard.py');N=importlib.util.module_from_spec(spec);spec.loader.exec_module(N)
sha=subprocess.check_output(['git','-C','/workspace/ergopti','rev-parse','0ba71fa72'],text=True).strip()
overlay=B/'resume-paths-editor-proposal/formatted-v2/candidate'
paths={'static/ergopti_plus/_shared/ui/paths_editor/script.js':'cd1c1213d2c830951bf9791b20191c0c24ffc169c8b30de6018d33fca2e75a27','static/ergopti_plus/_shared/ui/paths_editor/index.html':'a518efdea1f8d1c2ed59a4ddb9aca4e6df9a81bed1c54b2ccf39b9fcc4b2f66c'}
for p,h in paths.items():assert N.digest(overlay/p)==h
archive=subprocess.check_output(['git','-C','/workspace/ergopti','archive',sha,'static/ergopti_plus/_shared','static/ergopti_plus/linux'])
(P/'literal-source.tar').write_bytes(archive)
run=P/sys.argv[1];run.mkdir(exist_ok=False)
report={'status':'RUNNING','phase':sys.argv[1],'literal_commit':sha,'literal_tree':subprocess.check_output(['git','-C','/workspace/ergopti','rev-parse',sha+'^{tree}'],text=True).strip(),'source_archive_sha256':hashlib.sha256(archive).hexdigest(),'overlay':paths if sys.argv[1]!='literal' else {},'cases':[],'cleanup_errors':[],'limitations':['genuine Linux GTK/WebKit source sessions','no physical hooks','no installed GUI','no Windows/Cocoa','running logger sink not installed','no native Browse picker'],'controller_sha256':N.digest(pathlib.Path(__file__)),'worker_sha256':N.digest(P/'worker.lua')}
source=run/'source';source.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(source,filter='data')
if report['overlay']:
 for p in paths:(source/p).write_bytes((overlay/p).read_bytes())
files={str(p.relative_to(source)):N.digest(p) for p in source.rglob('*') if p.is_file()}
report['source_files']=files;report['source_count']=len(files)
for p in files:(source/p).chmod(0o444)
def drift():return [p for p,h in files.items() if N.digest(source/p)!=h]
try:
 assert not drift()
 for case in ['type-config','type-logs','clear-config','clear-logs','reset','untouched']:
  profile=run/case;profile.mkdir(mode=0o700);env=N.controlled_environment(profile);env.update(GSETTINGS_BACKEND='memory',MESA_SHADER_CACHE_DISABLE='true',NO_AT_BRIDGE='1')
  target=profile/'owned-folders';target.mkdir()
  for f in ['custom-B','logs-B/ergopti_plus','typed folder D','typed logs D/ergopti_plus']:(target/f).mkdir(parents=True,exist_ok=True)
  (profile/'config/ergopti').mkdir()
  e={'case':case,'stages':[]};report['cases'].append(e);server=worker=None;reader=writer=None
  try:
   reader,writer=os.pipe()
   with (profile/'xvfb.log').open('wb') as log:server=N.OwnedSession(['Xvfb','-displayfd',str(writer),'-screen','0','1024x768x24','-nolisten','tcp','-noreset'],profile/'xvfb-status.json',log,log,env,(writer,),cwd=source/'static/ergopti_plus/linux')
   os.close(writer);writer=None
   assert select.select([reader],[],[],5)[0],'Xvfb readiness deadline';display=os.read(reader,32).decode().strip();assert display.isdecimal();env['DISPLAY']=':'+display
   for stage in ['receive','reopen']:
    receipt=profile/(stage+'-native.json');item={'stage':stage};e['stages'].append(item)
    with (profile/(stage+'-native.stdout')).open('wb') as stdout,(profile/(stage+'-native.stderr')).open('wb') as stderr:
     worker=N.OwnedSession(['dbus-run-session','--','luajit',str(P/'worker.lua'),case,str(target),str(receipt),stage],profile/(stage+'-status.json'),stdout,stderr,env,cwd=source/'static/ergopti_plus/linux')
    deadline=time.monotonic()+70
    while worker.status() is None and time.monotonic()<deadline:time.sleep(.05)
    item['command_status']=worker.status()
    if receipt.exists():item['receipt']=json.loads(receipt.read_text());item['receipt_sha256']=N.digest(receipt)
    if not item['command_status'] or item['command_status']['exit_code']!=0 or item.get('receipt',{}).get('status')!='PASS':
     e['status']='FAIL';break
    worker.dispose();worker=None
   else:e['status']='PASS'
   storage=profile/'config/ergopti_plus/storage.json'
   if storage.exists():e['storage']=json.loads(storage.read_text());e['storage_sha256']=N.digest(storage)
  except BaseException as exc:e['status']='FAIL';e['error']=str(exc)
  finally:
   for obj in [worker,server]:
    if obj:
     try:obj.dispose()
     except BaseException as exc:report['cleanup_errors'].append(str(exc))
   for fd in [reader,writer]:
    if fd is not None:os.close(fd)
  N.write_json(run/'ACTUAL-RESULTS.json',report)
 report['status']='PASS' if all(e['status']=='PASS' for e in report['cases']) else 'FAIL'
except BaseException as exc:report['status']='FAIL';report['primary_error']=str(exc)
finally:
 report['source_drift']=drift()
 if report['source_drift'] or report['cleanup_errors']:report['status']='FAIL'
 N.write_json(run/'ACTUAL-RESULTS.json',report)
 print(json.dumps({'status':report['status'],'receipt':str(run/'ACTUAL-RESULTS.json'),'cases':[(e['case'],e.get('status')) for e in report['cases']],'source_count':len(files),'cleanup_errors':report['cleanup_errors']}),flush=True)
 sys.exit(0 if report['status']=='PASS' else 1)
