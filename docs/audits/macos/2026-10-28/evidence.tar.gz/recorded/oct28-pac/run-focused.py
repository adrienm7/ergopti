import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-verify-batch18-hs');d=Path('/workspace/scratch/oct28-pac/focused');d.mkdir(exist_ok=True)
e=dict(os.environ);e.update(USER='agent',LOGNAME='agent',HUSKY='1');e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';rows=[]
for name,command in [('hooks-install',['npx','husky','install']),('false-green',['node','tools/test/find-false-greens.cjs']),('python',['python3','-B','tools/test/native_pac_source_fixture_test.py','-v']),('python-optimized',['python3','-O','-B','tools/test/native_pac_source_fixture_test.py','-v']),('node-contract',['node','tools/test/test-native-pac-source-contract.cjs']),('verify-plan',['node','./tools/test/verify-change.cjs','--plan']),('normal-hook',['sh','.husky/pre-commit']),('source-encoding',['npm','run','-s','test:source-encoding']),('strict',['npm','run','-s','lint:conventions:strict'])]:
 start=time.monotonic();log=d/(name+'.log')
 with log.open('w') as output:run=subprocess.run(command,cwd=w,env=e,stdout=output,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'actual_exit':run.returncode,'seconds':time.monotonic()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};rows.append(row);(d/'receipt.json').write_text(json.dumps({'updated_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'gates':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
 if run.returncode:break
