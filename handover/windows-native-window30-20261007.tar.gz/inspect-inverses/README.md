# Closed inspection inverses

Five profiles from manifest62eca125 were applied independently to the exact Root
private graph, with byte-exact reversals and restoration after each original
created child exit plus stream-close event. Root's exact run/units/psargs bodies
were reused; backslash PS5 transport and headless recording ports remain intact.
No already completed seven-mode/full corpus was repeated.

All five profiles exit1 at their expected first control. The phase/debt AHK
profile fails exactly cases2+3, the foreign-missing profile exactly case3. Both
TAPs are complete4; the canonical completeness validator correctly returns0
for complete red runs. The first wrapper omitted sync in its VM context, then
assumed one failure instead of the observed two. Both harness refusals are
retained; the closed earlier AHK run was validated without replaying it or
changing any test assertion.

Restored shape6/6, AHK4/4 and real PS5 oversize each exit0. All nine feature
images and all earlier Root graph pins are unchanged at final verification.
Native LocalAppData and SourceRoot namespaces were exclusive at admission and
remain retained after original natural process terminal/close. No directory
cleanup, hardkill, PID adoption, daemon, GUI or input was performed.
No native job/daemon receiving success is claimed.

Local authorization closes at16:24:17UTC; this receipt closed at2026-10-07T16:10:38.825Z.
All created processes are terminal and streams closed; no further local work
is scheduled. Cloud may consume source profiles and closed proofs independently.
