# Existing runtime session route

A freshly inspected expectation can enter the genuine session without preparing, publishing or downloading another archive. Independent scalar copies, current source, exact release/model target and separate consent precede the normal runtime owner. Post-dispatch refusal cancels the source and retains physical retirement debt. The coordinator retains the same startup deadline, HTTP version/tags validation, model consent and readiness callback; READY still never enables AI.

The legacy local/official routes and all existing methods remain exact outside five coordinator seams and the appended session route. The caller and localized existing-start offer are not implemented in this packet. Runtime/guardian/source/kernel receiving is mandatory and unqualified here.
