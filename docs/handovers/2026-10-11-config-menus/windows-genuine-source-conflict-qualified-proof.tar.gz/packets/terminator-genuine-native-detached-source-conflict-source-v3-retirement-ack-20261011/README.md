# Genuine native detached source conflict proposal

SOURCE ONLY; native, parser, formatting and suites are UNRUN. One test function changes; the registered subject and every byte outside it remain exact.

The current original subject changes the canonical issued native hash callback and overwrites its booted current-schema image with an unstamped legacy body. Authentic run38124170676 refuses the revoked port before candidate capture. The proposal uses the existing current-source constructor before boot, captures the exact file and original terminator plan inside a genuine lifecycle bundle, hashes through the unchanged native owner, then performs a real independent durable source write before calling the existing conditional native commit.

The existing actual journal returns retry/expected_old_conflict before WAL publication. The test checks unchanged foreign bytes, actual absent WAL, no new stage/backup/target files, unchanged native authority and actual lease retirement. A fresh retry then uses the untouched original editor and the same real reload callback; its pending publication and reload refusal must restore the independent image exactly. No prepared WAL, issued clone, product hook, fixture timing race or dummy direct owner is introduced. The old editor refused-status assertion is retained on the genuine retry refusal; the detached stale branch uses the journal's actual typed status instead of inventing an editor receipt. SOURCE-PROPOSAL maps all four original assertion purposes explicitly.

Existing original WAL ACK/refusal tests remain exact and provide editor-route lifetime coverage. Root must receive finite hunks only and qualify the real registered Windows subject plus original neighbouring subjects and full applicable gates. An original-fixture inverse should retain its actual revoked-port failure; no source-only review claims runtime equivalence.

CURRENT-NATIVE-PHASE-ACCOUNTING records the authentic global-deadline observation and transaction timings. It does not establish a hung2056 or an internal performance cause. macOS/Linux source-conflict implementations are unchanged; this is a Windows fixture authority correction.

V2 only corrects native fixture cleanup after an unexpected direct commit: genuine Inspect and RollbackOwned must prove absent WAL before actual owner release/file deletion. Otherwise the original bundle and files remain retained for recovery; independent cleanup errors do not replace a prior primary. The unchanged V1 candidate and reviewer HOLD are ancestry, not a runtime result.

V3 adds exact native retirement acknowledgement and recovered same-owner marker retirement; unresolved or foreign markers remain untouched. Already retired genuine reload callback bundles are accepted only when the original native process barrier is actually inactive. Root must independently review all bounded source changes; runtime remains UNRUN.
