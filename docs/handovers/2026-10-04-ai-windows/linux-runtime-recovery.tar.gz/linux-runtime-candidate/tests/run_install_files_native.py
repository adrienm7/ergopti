"""Build a tiny independent archive; run Lua under the approved child subreaper."""
import argparse
import hashlib
import io
from pathlib import Path
import subprocess
import tarfile
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("repository")
parser.add_argument("candidate")
parser.add_argument("--lua", default="luajit")
args = parser.parse_args()
candidate = Path(args.candidate).resolve()
with tempfile.TemporaryDirectory(prefix="ergopti-archive-native-") as temporary:
    root = Path(temporary)
    plain = root / "independent-fixture.tar"
    with tarfile.open(plain, "w", format=tarfile.GNU_FORMAT) as archive:
        for directory in ("bin", "lib", "lib/ollama"):
            info = tarfile.TarInfo(directory)
            info.type = tarfile.DIRTYPE
            info.mode = 0o700
            info.mtime = 0
            archive.addfile(info)
        content = {
            "bin/ollama": b"#!/bin/sh\nprintf 'independent archive fixture\\n'\n",
            "lib/ollama/native-fixture.txt": b"independent full library tree fixture\n",
        }
        for name, data in content.items():
            info = tarfile.TarInfo(name)
            info.mode = 0o755 if name == "bin/ollama" else 0o600
            info.size = len(data)
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    compressed = root / "independent-fixture.tar.zst"
    subprocess.run(["zstd", "--quiet", "--no-progress", "-o", str(compressed), str(plain)], check=True)
    data = compressed.read_bytes()
    command = [
        "python3", str(candidate / "tests/run_native_subreaper.py"),
        args.lua, str(candidate / "tests/run_install_files_native.lua"),
        str(Path(args.repository).resolve()), str(candidate), str(root), str(compressed),
        str(len(data)), hashlib.sha256(data).hexdigest(),
    ]
    subprocess.run(command, check=True)
