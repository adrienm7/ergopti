"""Assess retained official bytes without executing tests or native targets."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path("/workspace/ergopti-cloud")
REPO = Path("/workspace/ergopti")
SHA = "5f7a8467c9696b26a75de104f6329b39c181b8cb"
RUN = 38129586139
receipt = {"schema": 1, "candidate": SHA, "run_id": RUN, "attempt": 1, "architectures": {}}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for arch, expected_arch, job in [("arm", "arm64", 114441094443), ("amd", "amd64", 114441094369)]:
    artifact = json.loads((ROOT / f"pac-{arch}-artifact-metadata.json").read_text())
    job_metadata = json.loads((ROOT / f"network-{arch}-job-metadata.json").read_text())
    assert job_metadata["id"] == job and job_metadata["run_id"] == RUN
    assert job_metadata["head_sha"] == SHA and job_metadata["run_attempt"] == 1
    assert artifact["workflow_run"]["head_sha"] == SHA
    assert artifact["workflow_run"]["id"] == RUN and not artifact["expired"]
    zip_path = ROOT / f"pac-{arch}-5f7a8467.zip"
    assert "sha256:" + digest(zip_path) == artifact["digest"]
    assert zip_path.stat().st_size == artifact["size_in_bytes"]
    folder = ROOT / f"pac-{arch}-5f7a8467"
    source = json.loads((folder / "native-pac-source-inputs.json").read_text())
    assert source["candidate"] == SHA and source["run_id"] == str(RUN)
    assert source["run_attempt"] == "1" and source["architecture"] == expected_arch
    for relative, expected in source["sources"].items():
        raw = subprocess.run(["git", "show", SHA + ":" + relative], cwd=REPO,
                             capture_output=True, check=True).stdout
        assert hashlib.sha256(raw).hexdigest() == expected
    source_verdict = json.loads((folder / "native-pac-source-verdict.json").read_text())
    assert source_verdict["source"] == source
    assert source_verdict["complete"] and source_verdict["observed"] == 10
    verdict = json.loads((folder / "native-pac-verdict.json").read_text())
    methods = {}
    current = None
    for number, line in enumerate((folder / "native-pac-xctest.log").read_text().splitlines(), 1):
        start = re.fullmatch(r"Test Case '-\[ErgoptiPlusTests\.([^ ]+) ([^]]+)\]' started\.", line)
        if start:
            current = start[1] + "." + start[2]
            assert current not in methods
            methods[current] = {"start_line": number, "observations": []}
        end = re.fullmatch(r"Test Case '-\[ErgoptiPlusTests\.([^ ]+) ([^]]+)\]' (passed|failed) \(([0-9.]+) seconds\)\.", line)
        if end:
            assert current == end[1] + "." + end[2]
            methods[current].update(status=end[3], seconds=float(end[4]), end_line=number)
            current = None
        if current and line.startswith("# native_http_"):
            if line.startswith("# native_http_trust_outcome "):
                methods[current]["observations"].append({"line": number, "kind": "trust_command", "fact": json.loads(line.split(" ", 2)[2])})
            elif re.fullmatch(r"# native_http_(trust_challenge mode=(system|extra)|error_chain node=[0-3] domain=(url|cfnetwork|posix|osstatus|unknown) code=(-?[0-9]+|none) stream_domain=(-?[0-9]+|none) stream_code=(-?[0-9]+|none)|certificate_code domain=NSURLErrorDomain code=-?[0-9]+)", line):
                methods[current]["observations"].append({"line": number, "kind": "closed_native_diagnostic", "fact": line})
    assert len(methods) == 14 and all("status" in item for item in methods.values())
    assert sum(item["status"] == "passed" for item in methods.values()) == 12
    job_log = ROOT / f"native-network-{arch}-5f7a8467.log"
    # Keep fixtures separate; a cleanup lookup cannot establish WPAD visibility.
    http = []
    lines = job_log.read_text().splitlines()
    begin = next(i for i, line in enumerate(lines) if "test01RealHTTPXFullURLPACURLFallbackAndVerifiedPhysicalChildEOF (__main__.RealNativeClientReceiving" in line)
    finish = next(i for i, line in enumerate(lines[begin:], begin) if "FAILED (errors=3)" in line)
    for number in range(begin, finish + 1):
        line = lines[number]
        match = re.search(r"# (native_http_(trust_outcome|admin_trust|admin_trust_after|admin_authorization|fixture_closure)) (\{.*\})$", line)
        if match:
            http.append({"job_line": number + 1, "kind": match[1], "fact": json.loads(match[3])})
    receipt["architectures"][expected_arch] = {
        "job": job, "job_complete": job_metadata["status"], "job_conclusion": job_metadata["conclusion"],
        "job_log": {"file": job_log.name, "bytes": job_log.stat().st_size, "sha256": digest(job_log)},
        "artifact": {"id": artifact["id"], "name": artifact["name"], "bytes": artifact["size_in_bytes"], "api_digest": artifact["digest"], "safe_extraction": True},
        "pac_source": {"observed": 10, "complete": True, "swift_status": 0, "capture_status": 0, "exact_git_tree_source_hashes": len(source["sources"]), "inputs_sha256": digest(folder / "native-pac-source-inputs.json")},
        "pac": {"methods": 14, "passed": 12, "failed": 2, "skipped": 0, "assertion_failures": 14, "unexpected_failures": 2, "swift_status": verdict["swift_status"], "capture_status": verdict["capture_status"], "complete": verdict["complete"], "transcript_sha256": digest(folder / "native-pac-xctest.log"), "method_records": methods},
        "independent_http": {"methods_executed": 2, "errors": 3, "observations": http},
    }
receipt["scope"] = "Official retained component receipts only; no tests executed by this assessment, no adoption or trust-policy correction"
receipt["remaining"] = ["WPAD own exact-CA visibility after successful add unavailable", "Wire and HTTP original add-child deadline cause unknown", "original cleanup/restoration debt remains", "native model operation, packaging/install and enterprise devices not qualified"]
(ROOT / "group6-network-fresh-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print("Both exact native component receipts assessed; all 402 source digests per architecture match the tested Git tree.")
