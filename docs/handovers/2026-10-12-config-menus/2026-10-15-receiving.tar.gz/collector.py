#!/usr/bin/env python3
"""Collect bounded folder-wizard evidence; never execute gates or publish commits."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import tarfile
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zlib

BASELINE = "6818cd94eba5966c26308f8e8dd30d0b8514023e"
CLOUD = Path("/workspace/.ergopti-cloud")
SHARED = "static/ergopti_plus/_shared"
SOURCES = [
    SHARED + "/ui/onboarding/" + name for name in ("index.html", "script.js", "style.css")
] + [
    SHARED + "/ui/host_bridge.js", SHARED + "/ui/_generated/onboarding_catalogue.js",
    SHARED + "/ui/_generated/onboarding_catalogue.json",
    "static/ergopti_plus/macos/ui/onboarding/init.lua",
    "static/ergopti_plus/macos/tests/support/onboarding_delivery_fixture.lua",
    "static/ergopti_plus/macos/tests/unit/ui/test_onboarding_javascript_delivery.lua",
    "static/ergopti_plus/linux/ui/onboarding/bridge.lua",
    "static/ergopti_plus/linux/tests/unit/meta/test_ui_bridge_handlers.lua",
    "static/ergopti_plus/windows/ui/onboarding/webview.ahk",
    "static/ergopti_plus/windows/tests/unit/test_onboarding_finish_payload.ahk",
    "tools/test/test-onboarding-wizard-page.cjs",
]
EXTRA = (
    "folder-intent-gtk-receiving.tar.gz", "install-gtk.sh", "activate-gtk.sh",
    "build-gtk-overlay.py", "run-with-gtk.sh",
    "personal-preimages-6818.json", "folder-target-windows-namespace-review.json",
    "personal-receiving-addendum.md", "wizard-chromium-dom-receiving.cjs",
    "ahk-v2-warn-documentation.htm", "ahk-v2-functions-documentation.htm",
    "resume-root-6818-run.json", "resume-root-6818-jobs.json",
    "resume-root-6818-full-jobs.json", "resume-root-6818-windows-annotations.json",
)
EXTENSIONS = {".log", ".json", ".js", ".lua", ".cjs", ".html", ".patch", ".md"}
API = "https://api.github.com/repos/adrienm7/ergopti"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode()


def stable_bytes(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError("Evidence must be an existing regular file: " + str(path))
    with path.open("rb") as stream:
        before = os.fstat(stream.fileno())
        value = stream.read()
        after = os.fstat(stream.fileno())
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError("Evidence changed during collection: " + str(path))
    return value


def png_valid(data):
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("Screenshot is not PNG")
    cursor, chunks, dimensions = 8, [], None
    while cursor < len(data):
        if len(data) - cursor < 12:
            raise ValueError("Truncated PNG chunk")
        size = struct.unpack(">I", data[cursor:cursor + 4])[0]
        end = cursor + 12 + size
        if end > len(data):
            raise ValueError("Truncated PNG payload")
        kind = data[cursor + 4:cursor + 8]
        payload = data[cursor + 8:cursor + 8 + size]
        crc = struct.unpack(">I", data[cursor + 8 + size:end])[0]
        if zlib.crc32(kind + payload) & 0xffffffff != crc:
            raise ValueError("PNG checksum mismatch")
        if not chunks:
            if kind != b"IHDR" or size != 13:
                raise ValueError("Missing PNG header")
            dimensions = struct.unpack(">II", payload[:8])
            if not all(dimensions):
                raise ValueError("Empty PNG dimensions")
        chunks.append(kind)
        cursor = end
        if kind == b"IEND":
            if size or cursor != len(data) or b"IDAT" not in chunks:
                raise ValueError("Invalid PNG termination")
            return list(dimensions)
    raise ValueError("PNG did not terminate")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


def api_get(suffix):
    url = API + suffix
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "ergopti-folder-receiving"}
    token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = "Bearer " + token
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.build_opener(NoRedirect).open(request, timeout=30) as response:
        body = response.read()
        return json.loads(body), digest(body)


def safe_metadata(value):
    """Refuse credentials/signed-storage links rather than silently redact evidence."""
    raw = json.dumps(value)
    if re.search(r"https?://[^\s\"]*[?&](?:sig|signature|token|x-amz-signature|x-amz-credential)=", raw, re.I):
        raise ValueError("Signed or credential-bearing metadata URL refused")
    return value


def choose(value, fields):
    return safe_metadata({field: value[field] for field in fields if field in value})


def collect(args):
    repository = Path(args.repo).resolve()
    output = Path(args.out).absolute()
    def git(*command):
        return subprocess.check_output(["git", *command], cwd=repository)
    roots = [Path(line[9:]).resolve() for line in git("worktree", "list", "--porcelain").decode().splitlines() if line.startswith("worktree ")]
    if any(output.resolve().is_relative_to(root) for root in roots) or output.exists():
        raise ValueError("Output must be a new file outside every registered checkout")
    for sha in (BASELINE, args.source_commit):
        if not re.fullmatch(r"[a-f0-9]{40}", sha) or git("cat-file", "-t", sha).strip() != b"commit":
            raise ValueError("A complete existing commit SHA is required")
    manifest = {"schema": 1, "collector_command": [str(Path(__file__).resolve()), *os.sys.argv[1:]],
                "source_commit": args.source_commit, "baseline_commit": BASELINE,
                "source_tree": git("rev-parse", args.source_commit + "^{tree}").decode().strip(),
                "baseline_tree": git("rev-parse", BASELINE + "^{tree}").decode().strip(),
                "publication_claim": "NONE; source inspection commits are not publication evidence",
                "excluded": ["credentials", "node_modules", "caches", "Git indexes", "full repositories", "archive backups", "signed-storage downloads"],
                "execution_evidence": [], "chromium": [], "manual_runs": [], "baseline_runs": [], "unavailable": []}
    members = {}
    def add(name, data):
        if name in members or name.startswith("/") or ".." in Path(name).parts or "\n" in name or "\r" in name:
            raise ValueError("Unsafe or duplicate archive member")
        members[name] = data
    add("collector.py", stable_bytes(Path(__file__)))
    locale_paths = git("ls-tree", "-r", "--name-only", args.source_commit, "--", SHARED + "/data/locales").decode().splitlines()
    locales = [name for name in locale_paths if name.endswith(".json")]
    if len(locales) != 21:
        raise ValueError("Expected the actual 21 locale source files")
    for sha in (BASELINE, args.source_commit):
        for name in sorted(set(SOURCES + locales)):
            add("sources/" + sha + "/" + name, git("show", sha + ":" + name))
    selected = [p for p in CLOUD.iterdir() if p.name.startswith(("folder-target-", "folder-intent-", "native-http-", "managed-ollama-")) and p.suffix in EXTENSIONS and p.is_file() and p.name != "folder-intent-final-collection.json"]
    selected += [CLOUD / name for name in EXTRA if (CLOUD / name).exists()]
    manifest["unavailable"].extend({"artifact": name, "status": "NOT_PRESENT"} for name in EXTRA if not (CLOUD / name).exists())
    gtk_path = CLOUD / "folder-intent-gtk-receiving.tar.gz"
    if digest(stable_bytes(gtk_path)) != "14e4bc415c72208386e50b9e27d62da903f94df21d3bf4dc5d9a8cf80ad47c45":
        raise ValueError("Sealed GTK packet changed")
    with tarfile.open(gtk_path, "r:gz") as gtk_archive:
        gtk_names = gtk_archive.getnames()
        if len(gtk_names) != len(set(gtk_names)):
            raise ValueError("Duplicate GTK packet member")
        gtk_sums = gtk_archive.extractfile("folder-intent-gtk-receiving/SHA256SUMS").read().decode().splitlines()
        if len(gtk_sums) != 318:
            raise ValueError("GTK packet inventory mismatch")
        for row in gtk_sums:
            expected, name = row.split("  ", 1)
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError("Unsafe GTK member")
            if digest(gtk_archive.extractfile("folder-intent-gtk-receiving/" + name).read()) != expected:
                raise ValueError("GTK member checksum mismatch")
    manifest["gtk"] = {"artifact": "local/" + gtk_path.name,
        "sha256": digest(stable_bytes(gtk_path)), "verified_member_checksums": 318,
        "scope": "NATIVE_GTK_SOURCE_GUI_X11; NOT_INSTALLED_OR_PHYSICAL"}
    for path in sorted(set(selected)):
        data = stable_bytes(path)
        add("local/" + path.name, data)
        if path.suffix == ".json":
            record = json.loads(data)
            manifest["execution_evidence"].append({"artifact": "local/" + path.name, "reported": record,
                "classification": "REPORTED_STATUS_ONLY; RUNNING is not terminal proof"})
    for name in args.interrupted_log:
        if "local/" + name not in members:
            raise ValueError("Interrupted log must name a collected artifact")
        manifest["execution_evidence"].append({"artifact": "local/" + name, "classification": "EXPLICITLY_INTERRUPTED", "exit_code": None})
    for specification in args.gate_exit:
        name, code = specification.rsplit(":", 1)
        if "local/" + name not in members:
            raise ValueError("Gate exit must name a collected artifact")
        manifest["execution_evidence"].append({"artifact": "local/" + name, "classification": "EXPLICIT_RECORDED_EXIT", "exit_code": int(code)})
    for directory in sorted(CLOUD.glob("wizard-chromium-*")):
        if not directory.is_dir() or directory.is_symlink() or not (directory / "receipt.json").exists():
            continue
        receipt_bytes = stable_bytes(directory / "receipt.json")
        receipt = json.loads(receipt_bytes)
        sha = receipt.get("sourceCommit", "")
        if not re.fullmatch(r"[a-f0-9]{40}", sha):
            raise ValueError("Chromium receipt has no immutable source commit")
        if git("rev-parse", sha + "^{tree}").decode().strip() != receipt.get("sourceTree"):
            raise ValueError("Chromium tree receipt mismatch")
        expected_browser_sources = set(locales + SOURCES[:5])
        if set(receipt.get("sourceIdentities", {})) != expected_browser_sources:
            raise ValueError("Chromium receipt must seal the complete actual page source set")
        for name, expected in receipt.get("sourceIdentities", {}).items():
            if name.startswith("/") or ".." in Path(name).parts or not name.startswith(SHARED + "/"):
                raise ValueError("Unsafe Chromium source identity")
            if digest(git("show", sha + ":" + name)) != expected:
                raise ValueError("Chromium immutable source hash mismatch")
            if digest(stable_bytes(directory / "source" / name)) != expected:
                raise ValueError("Retained Chromium source snapshot drifted")
        if not receipt.get("sourceIdentities"):
            raise ValueError("Chromium receipt has no source fingerprints")
        sealed_archive = stable_bytes(directory / "sealed-source.tar")
        if digest(sealed_archive) != receipt.get("archiveSha256"):
            raise ValueError("Chromium retained source archive hash mismatch")
        prefix = "chromium/" + directory.name
        add(prefix + "/receipt.json", receipt_bytes)
        add(prefix + "/sealed-source.tar", sealed_archive)
        add(prefix + "/chromium.log", stable_bytes(directory / "chromium.log"))
        if (directory / "cdp-resource-events.json").exists():
            events = json.loads(stable_bytes(directory / "cdp-resource-events.json"))
            add(prefix + "/cdp-resource-events.json", encoded(safe_metadata(events)))
        if (directory / "failed-document.png").exists():
            failed_image = stable_bytes(directory / "failed-document.png")
            png_valid(failed_image)
            add(prefix + "/failed-document.png", failed_image)
        ledger = json.loads(stable_bytes(CLOUD / "folder-intent-chromium-runtime-receiving-ledger.json"))
        attempts = [attempt for attempt in ledger["attempts"] if attempt["phase"] == directory.name]
        if len(attempts) != 1:
            raise ValueError("Chromium attempt must have one independent runtime-ledger witness")
        attempt = attempts[0]
        helper = Path(attempt["helper"])
        if helper.parent != CLOUD or digest(stable_bytes(helper)) != attempt["helper_sha256"]:
            raise ValueError("Retained per-attempt Chromium harness hash mismatch")
        if digest(receipt_bytes) != attempt["receipt_sha256"]:
            raise ValueError("Chromium runtime ledger receipt hash mismatch")
        if receipt.get("harnessSha256", attempt["helper_sha256"]) != attempt["helper_sha256"]:
            raise ValueError("Chromium receipt and runtime harness identity disagree")
        status = {"directory": directory.name, "source_commit": sha,
                  "matches_source_commit": sha == args.source_commit, "matches_source_tree": receipt.get("sourceTree") == manifest["source_tree"], "reported_verdict": receipt.get("verdict"),
                  "reported_cleanup": receipt.get("cleanup"), "screenshots": []}
        for case in receipt.get("cases", []):
            if not case.get("screenshot"):
                continue
            path = Path(case["screenshot"])
            if path.parent.resolve() != directory.resolve() or path.name not in {osname + "-empty-target.png" for osname in ("windows", "macos", "linux")}:
                raise ValueError("Screenshot path is outside the exact owned receiving directory")
            image = stable_bytes(path)
            dimensions = png_valid(image)
            add(prefix + "/" + path.name, image)
            status["screenshots"].append({"name": path.name, "sha256": digest(image), "dimensions": dimensions})
        manifest["chromium"].append(status)
    if not manifest["chromium"]:
        manifest["unavailable"].append({"chromium": "NO_VERIFIED_EXISTING_RECEIPT"})
    if len(set(args.run)) != len(args.run) or len(set(args.baseline_run)) != len(args.baseline_run):
        raise ValueError("A run ID must not be repeated within its receiving category")
    for run_id, category in [(run, "manual_runs") for run in args.run] + [(run, "baseline_runs") for run in args.baseline_run]:
        run, raw_sha = api_get("/actions/runs/" + run_id)
        if category == "manual_runs" and run.get("event") != "workflow_dispatch":
            raise ValueError("Only explicitly requested manual workflow runs may be collected")
        run_prefix = "api/" + ("baseline/" if category == "baseline_runs" else "") + run_id
        metadata = choose(run, ("id", "event", "status", "conclusion", "head_sha", "head_branch", "run_attempt", "workflow_id", "html_url", "created_at", "updated_at"))
        add(run_prefix + "/run.json", encoded(metadata))
        head = metadata.get("head_sha", "")
        if not re.fullmatch(r"[a-f0-9]{40}", head):
            raise ValueError("Manual run has no complete source SHA")
        commit_metadata, commit_raw_sha = api_get("/git/commits/" + head)
        head_tree = commit_metadata["tree"]["sha"]
        jobs, page = [], 1
        while True:
            payload, raw = api_get("/actions/runs/" + run_id + "/jobs?filter=all&per_page=100&page=" + str(page))
            rows = payload["jobs"]
            if not isinstance(rows, list):
                raise ValueError("Malformed paginated jobs response")
            add(run_prefix + "/jobs-page-" + str(page) + ".json", encoded({"raw_response_sha256": raw, "total_count": payload["total_count"], "jobs": [choose(job, ("id", "name", "status", "conclusion", "started_at", "completed_at", "head_sha", "run_attempt", "check_run_url", "steps")) for job in rows]}))
            jobs.extend(rows)
            if len(rows) < 100:
                break
            page += 1
        jobs_pages = page
        if len(jobs) != payload["total_count"] or len({job["id"] for job in jobs}) != len(jobs):
            raise ValueError("Jobs changed during pagination or the receiving is incomplete")
        for job in jobs:
            if job.get("head_sha", head) != head:
                raise ValueError("Job source SHA differs from its manual run")
            url = job.get("check_run_url", "")
            match = re.fullmatch(re.escape(API) + r"/check-runs/([0-9]+)", url)
            if not match:
                manifest["unavailable"].append({"run": run_id, "job": job["id"], "annotations": "NO_VALID_REPOSITORY_CHECK_RUN_URL"})
                continue
            page = 1
            while True:
                annotations, raw = api_get("/check-runs/" + match[1] + "/annotations?per_page=100&page=" + str(page))
                if not isinstance(annotations, list):
                    raise ValueError("Malformed annotation page")
                add(run_prefix + "/job-" + str(job["id"]) + "-annotations-" + str(page) + ".json", encoded({"raw_response_sha256": raw, "annotations": [choose(item, ("path", "start_line", "end_line", "start_column", "end_column", "annotation_level", "title", "message")) for item in annotations]}))
                if len(annotations) < 100:
                    break
                page += 1
        manifest[category].append({**metadata, "receiving_category": category, "role": "CANDIDATE_MANUAL_METADATA" if category == "manual_runs" else "HISTORICAL_BASELINE_METADATA", "raw_run_response_sha256": raw_sha, "jobs_collected": len(jobs), "jobs_pages": jobs_pages, "head_tree": head_tree, "git_commit_metadata_sha256": commit_raw_sha, "matches_source_commit": head == args.source_commit, "matches_source_tree": head_tree == manifest["source_tree"], "scope": "PAGINATED_API_METADATA_ONLY; NO_NATIVE_FULL_LOG_OR_SAS_DOWNLOAD"})
    manifest["members"] = {name: {"bytes": len(data), "sha256": digest(data)} for name, data in sorted(members.items())}
    add("MANIFEST.json", encoded(manifest))
    add("SHA256SUMS", "".join(digest(data) + "  " + name + "\n" for name, data in sorted(members.items())).encode())
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=".folder-receiving-", suffix=".partial", dir=output.parent)
    try:
        with os.fdopen(descriptor, "wb") as sink, gzip.GzipFile(filename="", mode="wb", fileobj=sink, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
                for name, data in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mtime, info.mode = len(data), 0, 0o644
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(data))
        verify_archive(Path(temporary), members)
        os.link(temporary, output)
        print(json.dumps({"archive": str(output), "sha256": digest(stable_bytes(output)), "members": len(members), "member_hashes_verified": True}))
    finally:
        Path(temporary).unlink(missing_ok=True)


def verify_archive(path, expected):
    with tarfile.open(path, "r:gz") as archive:
        names = archive.getnames()
        if names != sorted(expected) or len(set(names)) != len(names):
            raise ValueError("Archive member inventory mismatch")
        retained = {}
        for info in archive.getmembers():
            if not info.isfile() or info.uid or info.gid or info.mtime or info.mode != 0o644:
                raise ValueError("Archive contains nondeterministic metadata or a non-file")
            data = archive.extractfile(info).read()
            if data != expected[info.name]:
                raise ValueError("Archive bytes do not match the collected evidence")
            retained[info.name] = data
        sums = retained["SHA256SUMS"].decode().splitlines()
        if len(sums) != len(retained) - 1:
            raise ValueError("Checksum inventory mismatch")
        for row in sums:
            checksum, name = row.split("  ", 1)
            if name == "SHA256SUMS" or digest(retained[name]) != checksum:
                raise ValueError("Archive member SHA256 mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default="/workspace/ergopti")
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--run", action="append", default=[], type=lambda value: value if re.fullmatch(r"[1-9][0-9]*", value) else parser.error("--run requires a positive workflow run ID"), help="Repeat for each manual workflow run ID")
    parser.add_argument("--baseline-run", action="append", default=[], type=lambda value: value if re.fullmatch(r"[1-9][0-9]*", value) else parser.error("--baseline-run requires a positive workflow run ID"), help="Repeat for explicit historical baseline runs; preserve their actual event, including push, separately from candidate manual validations")
    parser.add_argument("--interrupted-log", action="append", default=[], help="Collected basename whose gate was explicitly interrupted; no exit is invented")
    parser.add_argument("--gate-exit", action="append", default=[], metavar="LOG:EXIT", help="Explicit independently recorded exit status")
    collect(parser.parse_args())


if __name__ == "__main__":
    main()
