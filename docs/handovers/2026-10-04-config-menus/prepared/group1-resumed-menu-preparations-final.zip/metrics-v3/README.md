# Metrics labels current-source V3

This is a 13-path successor on Tap-Hold head successor `b3ce4124…`; exact source
preimages/postimages are in the manifest. Patch SHA256:
`64282fbfc2268c7c0896b28371ede9f436a53c9c4f3958f926fb7b0aa9382f81`.
The original frozen Metrics patch `a9a2ba6…` was checked. Current Linux wizard
and network owners remain intact; generated artifacts were recreated by their
menu/census generators. Two inherited JS preimages were canonically formatted,
and formatter output of the exact reviewed parents matches the head successor.
The old TODO hunk is omitted for current group-only composition.

Shared inert labels replace only Linux's unavailable/idle migration statuses.
The running progress and cancellation owners are unchanged. Labels are always
inert and Linux-only; they cannot acquire supplied callback/child payloads.
Existing captions remain translated in all21 languages. The native census is
95/152/94, lowering exactly the two Linux fixed status-caption sites.

V1 was rejected by independent review: assigning CaseSense to a populated AHK
Map throws. V2 removes that redundant assignment; V3 also distinguishes a
missing unavailable key from a forbidden explicitly empty policy. Native and
Lua vectors pin strict case-sensitive foreign fields and the empty-policy
refusal. Windows uses Map's default case-sensitive behavior. No original test
assertion is removed; all three original native test byte prefixes remain.
V1/V2 packets are immutable rejected evidence and must not be applied.

Current Linux focused owners pass42/0 on Lua5.4 and LuaJIT. Unchanged macOS
sources/tests retain V1's18/0 supported Lua5.4 result. Independent V1 inverses
prove missing status provider/renderer/compiler support: old provider36/4,
old renderer35/5 Linux and17/1 Mac, actual compiler malformed vectors exit1.
All remaining V3 source/artifact images are exact V1; corrected AHK portable
BOM/LF, syntax and registration checks are rerun and pass. V1 archive full
format and focused manifest/parity/bijection/readers pass; V3 changes only
AHK/Lua formatter-excluded paths and add rejection cases.

Windows native execution and all fullselected, E2E, package/install, hosted
three-OS and physical UI qualification remain unexecuted by this worker.
They remain root/CI work. No TODO item is removed, no shared root/index/ref is
edited, and no release is triggered. Independent review receipts are separate.
