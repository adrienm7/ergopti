// _shared/ui/metrics_typing/modal.js

/**
 * ==============================================================================
 * MODULE: App Filter Modal
 * DESCRIPTION:
 * Manages the application selector modal: rendering the app list with icons,
 * handling search/select/deselect, and syncing the filter button label.
 *
 * FEATURES & RATIONALE:
 * 1. Bug Fix — get_app_color: The original code called get_app_color() which
 *    was never defined, causing a ReferenceError that silently prevented the
 *    modal from opening. This module implements the missing function.
 * 2. Deterministic Colors: App icon fallback colors are seeded from the app
 *    name so the same app always gets the same color across sessions.
 * ==============================================================================
 */

// =============================================
// =============================================
// ======= 1/ App Color & Icon Helpers =======
// =============================================
// =============================================

// Color palette for app icon fallback badges
const APP_BADGE_COLORS = [
	ThemeTokens.color('blue'),
	ThemeTokens.color('green'),
	ThemeTokens.color('red'),
	ThemeTokens.color('orange'),
	ThemeTokens.color('hue-af52de'),
	ThemeTokens.color('hue-ff2d55'),
	ThemeTokens.color('hue-5ac8fa'),
	ThemeTokens.color('yellow'),
	ThemeTokens.color('hue-4cd964'),
	ThemeTokens.color('hue-ff6b00'),
	ThemeTokens.color('hue-30b0c7'),
	ThemeTokens.color('hue-ff6961'),
	ThemeTokens.color('hue-77dd77'),
	ThemeTokens.color('hue-aec6cf'),
	ThemeTokens.color('hue-cb99c9')
];

/**
 * Returns a deterministic badge color for an app based on its name.
 * Same name always returns the same color so the UI stays stable.
 * @param {string} name - The application display name.
 * @returns {string} A hex color string.
 */
function get_app_color(name) {
	let hash = 0;
	for (let i = 0; i < name.length; i++) {
		hash = (hash << 5) - hash + name.charCodeAt(i);
		hash |= 0;
	}
	return APP_BADGE_COLORS[Math.abs(hash) % APP_BADGE_COLORS.length];
}

// ============================================
// ============================================
// ======= 2/ Filter Button Label =======
// ============================================
// ============================================

/**
 * Updates the "Apps" filter button text to reflect the current selection count.
 */
function update_app_btn_text() {
	const btn = document.getElementById('app_filter_btn');
	if (!btn) return;

	const sel = app_state.selected_apps.size;
	const tot = app_state.available_apps.length;

	if (sel === tot && app_state.app_selection_mode !== APP_SELECTION_MODE.NONE) {
		btn.innerText = _t('ui_typing.apps_all');
		btn.classList.add('active');
	} else {
		btn.innerText =
			sel === 0
				? _t('ui_typing.apps_none')
				: _t('ui_typing.apps_some').replace('{n}', sel).replace('{total}', tot);
		btn.classList.remove('active');
	}
}

// Locale application rewrites declared labels before this dynamic caption is restored.
document.addEventListener('i18n:applied', update_app_btn_text);

// ======================================
// ======================================
// ======= 3/ Modal Open / Close =======
// ======================================
// ======================================

/**
 * Opens the app filter modal and renders the current app list.
 */
function open_app_modal() {
	const search_input = document.getElementById('app_search');
	if (search_input) search_input.value = '';
	render_app_list();
	document.getElementById('app_modal').style.display = 'flex';
	if (search_input) search_input.focus();
}

/**
 * Closes the app filter modal and applies the updated selection.
 */
function close_app_modal() {
	document.getElementById('app_modal').style.display = 'none';
	update_app_btn_text();
	apply_date_app_filters();
}

/**
 * Selects all available apps and re-renders the list.
 */
function select_all_apps() {
	app_state.selected_apps.clear();
	app_state.available_apps.forEach((app) => app_state.selected_apps.add(app));
	app_state.app_selection_mode = APP_SELECTION_MODE.ALL;
	render_app_list();
}

/**
 * Deselects all available apps and re-renders the list.
 */
function deselect_all_apps() {
	app_state.selected_apps.clear();
	app_state.app_selection_mode = APP_SELECTION_MODE.NONE;
	render_app_list();
}

/**
 * Toggles a single app's selection state from its checkbox.
 * @param {HTMLInputElement} checkbox - The checkbox element that changed.
 */
function toggle_app_selection(checkbox) {
	if (checkbox.checked) {
		app_state.selected_apps.add(checkbox.value);
	} else {
		app_state.selected_apps.delete(checkbox.value);
	}
	if (app_state.selected_apps.size === 0) {
		app_state.app_selection_mode = APP_SELECTION_MODE.NONE;
	} else if (app_state.selected_apps.size === app_state.available_apps.length) {
		app_state.app_selection_mode = APP_SELECTION_MODE.ALL;
	} else {
		app_state.app_selection_mode = APP_SELECTION_MODE.SUBSET;
	}
}

// =====================================
// =====================================
// ======= 4/ App List Rendering =======
// =====================================
// =====================================

/**
 * Re-renders the scrollable app list inside the modal, filtered by the
 * search input and decorated with icons or colored badge fallbacks.
 */
const appInitialSegmenter =
	typeof Intl.Segmenter === 'function'
		? new Intl.Segmenter(undefined, { granularity: 'grapheme' })
		: null;

function appInitial(name) {
	const normalized = name.normalize('NFC');
	const first = appInitialSegmenter
		? appInitialSegmenter.segment(normalized)[Symbol.iterator]().next().value?.segment
		: Array.from(normalized)[0];
	return (first || '').toUpperCase();
}

function render_app_list() {
	const query = (document.getElementById('app_search')?.value ?? '').toLowerCase().normalize('NFC');
	const container = document.getElementById('app_list');
	if (!container) return;

	let html = '';

	app_state.available_apps.forEach((app) => {
		if (!app.toLowerCase().normalize('NFC').includes(query)) return;

		const checked = app_state.selected_apps.has(app) ? 'checked' : '';
		const icon_src =
			window.app_icons && Object.hasOwn(window.app_icons, app) ? window.app_icons[app] : null;
		const icon_html = icon_src
			? `<img src="${icon_src}" class="app-icon-img" alt="${escape_html(app)}" />`
			: `<div class="app-icon-div" style="background-color:${get_app_color(app)}">${escape_html(appInitial(app))}</div>`;

		html +=
			`<label class="app-item">` +
			`<input type="checkbox" value="${escape_html(app)}" ${checked} onchange="toggle_app_selection(this)">` +
			`<div class="app-icon-wrapper">${icon_html}</div>` +
			`<span class="app-name">${escape_html(app)}</span>` +
			`</label>`;
	});

	container.innerHTML =
		html ||
		`<div style="padding:15px; color:var(--text-muted); text-align:center;">${_t('ui_typing.no_app_found')}</div>`;
}
