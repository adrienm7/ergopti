# Reproduction commands and constraints

These are proposed commands; generation does not execute a test. Inspect current source/header/package dependencies and exact preimages before reconstructing a cohort. Retain all literal assertions and complete private captures. Source review grants no local test slot.

Build this source archive only, with original reviewed folders present:

```sh
python3 GENERATE.py \
  --prepared /workspace/scratch/group6-linux-public-prepared-queue62 \
  --fixtures /workspace/scratch/group6-linux-native-fixture-retirement-correction-revision3 \
  --review /workspace/scratch/group6-prepared-queue-review \
  --output /workspace/scratch/group6-network-recovery-2026-10-06/generated
```

For models after admitted stage reconstruction, execute the captured scripts directly from the isolated driver cwd. LuaJIT uses the maintained environment; actual Lua5.4 additionally requires its own native ABI search path:

```sh
source /workspace/ergopti-env.sh
export TMPDIR=/tmp
export LUA_CPATH='/workspace/.tools/native/usr/lib/x86_64-linux-gnu/lua/5.4/?.so;;'
umask 077
```

qualification/BODY-MODEL-COMMANDS.json fixes descriptor14, original34 and preserved528/525 command plans on both ABIs. It lists genuine producer-before causal commands separately. Their absolute paths require deliberately admitted relocation; do not run a model against the live tree merely because a recorded path is unavailable.

Actual25/14 use groups/native-launch/run.py.source plus its adjacent immutable entry.lua.source and existing admitted run_native_subreaper.py. The native phase owns only one guardian and consumes the exact Popen/pidfd/WNOWAIT birth receipt before one direct-child reap. From the admitted driver's cwd, invoke the source with structured scalar arguments:

```sh
python3 -B run.py.source \
  --stage /ABS/ADMITTED/STAGE \
  --fixture run_http_preflight_receipts.lua \
  --expected-checks 25 \
  --capture /ABS/NEW/PRIVATE/CAPTURE \
  --luajit /ABS/REAL/LUAJIT
```

Use run_http_body_cleanup_receipts.lua and14 for the separate body phase. Candidate25 is followed by candidate14; stop at the first true candidate failure. Every source/stage set, real PIDbirth, complete capture, terminal/reap and zero-debt guardian receipt must be retained. Do not outer-timeout or numerically kill the cleanup guardian, infer closure from exit alone, or introduce a competing reaper. Before24/14 replay is a distinct contract migration; original/follow-up failures never become successes through skipped counts.

Fixture335 requires a later separate granted slot and final-source stage admission. The bodylimit/literal-target probes may use the existing sole guardian; the CLI orphan/digest probe already owns its subreaper and must run directly, preserving its authenticated exact descendant and final reap oracle. Native body-pipe20 is a separate unresolved cohort. No automatic scheduling or CI dispatch is part of this archive.
