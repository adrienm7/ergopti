<!-- shortcuts-invocation-owner-assessment-v1/README.md -->

# Apple Shortcuts invocation: original-owner boundary

Read-only assessment on `a634372ed1ebed8c04719d58eb999d6a37303b2f` plus the parent's frozen no-start query repair. No tests, native processes, guessed selectors, workflow changes or canonical/index/ref writes were performed. The existing eleven diagnostic probe files were not changed.

**There is no justified small invocation-wiring patch with the currently supplied native authority.** The required routing already exists; its refusal is deliberate. This is unfinished software/native receiving, not a hardware-only or user-authorization blocker.

## Actual receiving chain

`modules/gestures/actions.lua` first authenticates the saved scalar, binding/category, canonical source bytes, configuration revision and SHA. Its chosen-program branch routes `/usr/bin/shortcuts run <ID>` to `actions_aux_owner.revalidate_automation` and returns false, so it cannot fall through to the generic user-program runner. The auxiliary owner constructs `apple_shortcuts_native.revalidate_program`, retains its exact task in the same action-parent lifecycle and starts only the read-only query.

The native adapter revalidates the UUID through the signed `ErgoptiAutomationQuery` role. It returns `service_retirement_unqualified` on actual valid packet plus current consumer admission, or `query_refused` otherwise. `create()` qualifies discovery only and supplies an invocation function returning nil. `OwnedAutomationQueryWorker.validRequest/queryRole` accepts discover/revalidate and fixed permission-observation, not an execution operation. Its Q1 retirement proves the owned query child/group; the fixed core/getd permission observation is a read event, not an invocation/cancellation selector or permission grant.

The policy `apple_shortcuts.lua` already requires invocation AND cancellation qualifications and separate `isSettled` plus `automationSettled` before releasing an invocation. `owned_program_runner.lua` exposes only local task/group settlement. Its native V1 RETIRED contract covers the retained original group and exact leader; the documented boundary explicitly excludes processes leaving the group/session. Shortcuts' independently running service is not turned into that owned group by launching the CLI. There is no `automationSettled` producer in this runner. Aliasing it to `isSettled`, accepting CLI exit or sending TERM to the CLI would weaken the actual contract.

## Minimum valid implementation, conditional on an authentic API

A product invocation transport needs a supported, observed chosen-ID start operation with an invocation-specific remote identity, terminal outcome and cancellation/retirement acknowledgement. None of those service ports is supplied by the current source or read-only dictionary/permission observations. This assessment does not establish universal absence from every macOS API; it establishes that no such supported API/identity is available in the inspected implementation. Do not invent a JXA/ScriptingBridge selector or wire mapping.

Once such a native contract is received, the smallest receiving design is: revalidate the original saved ID; retain the exact configuration/consumer/source and sender identity; construct a held local owner plus the actual remote invocation owner; rejoin admission before activation; independently record local physical and remote service terminal receipts; cancel only that invocation; retain cleanup debt until both owners acknowledge. A rejected or ambiguous start must not permit a successor. The existing 20-second query supervision and 65,536-byte query cap stay unchanged; they do not define an invented invocation deadline or guarantee remote cancellation.

Likely receiving edit seams are `apple_shortcuts_native.lua`, `actions_aux_owner.lua`, and the reserved chosen-program branch in `actions.lua`, plus a genuine native service-owner implementation and its existing native dispatch owner after coordination. `apple_shortcuts.lua` is the existing behavioral contract, not a missing replacement state machine. `owned_program_runner.lua` and `OwnedProgramWorker.swift` remain local owners and need not be modified merely to manufacture service qualification. Native signed/helper dispatch and CI regions require their actual Root/G5/G6 owner joins before adoption.

## Independent expectations and real receiving

Preserve all original policy/transport/program-runner/native tests. In particular: `refuses invocation when runtime cancellation is unqualified`; the gesture/keyboard/other chosen-argv cases; `retains cancelled service debt after CLI closure across all consumers`; source/admission invalidation before constructor/activation and after terminal observations; malformed/stale IDs; query receipt missing despite leader completion; and the new actual ShellRunner never-started versus attempted/unsettled distinctions. Existing controlled invocation cases demonstrate these obligations, not real service authority.

Future causal controls must independently require: local exit with live remote invocation remains pending; acknowledged remote cancellation with live local owner remains pending; both exact owners retired releases; stale generation/source/consumer suppresses callback and execution; duplicate/mismatched remote invocation receipts never release debt; every consumer uses the same literal chosen ID; invalid/unknown allocation remains owned. An inverse substituting local isSettled for remote retirement must fail the existing remote-debt expectation. Do not replace those assertions with success-only or CLI-exit tests.

Hosted macOS qualification needs the actual supported service operation on a deliberately owned test shortcut, under the actual signed sender, with pre-existing appropriate permissions rather than a prompt/grant workaround. ARM/Intel native start/outcome/cancel/remote retirement plus action-source invalidation, exact local cleanup, packaged identity and affected existing suites are required. Read-only metadata/preflight, fake automation handles or generic process-tree tests cannot qualify this. No user shortcut is executed by the present assessment.

Next finite prerequisite is to obtain the supported remote invocation/retirement API and exact installed-target semantics, not to add speculative wiring. Until then keep the actual unavailable gate and continue other demonstrated Group3 software work.
