#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd(); out=Path('/workspace/scratch/windows-audit-round6/lifecycle');w=out.parent/'verification-worker'
r=json.loads((w/'receipts/324-lifecycle-schema-control-green-exit.json').read_text());assert r['exit_code']==0
s=(w/'receipts/324-lifecycle-schema-control-green.log').read_text(errors='replace');assert '# 33 passed, 0 failed.' in s
for p,h in json.loads((out/'control-schema-candidate-hashes.json').read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
CHECK
git add -- static/ergopti_plus/windows/infra/driver_control.ahk static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk
git commit -F /workspace/scratch/windows-audit-round6/lifecycle/control-schema-commit-message.txt
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
for p,h in json.loads((out/'control-schema-candidate-hashes.json').read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
print(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
CHECK
