from pathlib import Path
b=Path('/workspace/.ergopti-cloud/resume-personal-watch-topology');p=b/'added-tests.lua';s=p.read_text();(b/'added-tests-v3.lua').write_text(s)
s=s.replace('''		local backend, scan_port = {}, {}
''','''		local actual_shell = require("adapters.shell_runner")
		local backend, scan_port, shell_port = {}, {}, {}
''',1)
s=s.replace('''		for key, value in pairs(actual_posix) do scan_port[key] = value end
''','''		for key, value in pairs(actual_posix) do scan_port[key] = value end
		for key, value in pairs(actual_shell) do shell_port[key] = value end
		function shell_port.exec_checked(command)
			if command:find("ls -1A -- ", 1, true) == 1 and state.command_refusal then
				state.checked_refusals = (state.checked_refusals or 0) + 1
				return actual_shell.exec_checked("printf 'partial.toml\\n'; exit 23")
			end
			if command:find("ls -1A -- ", 1, true) == 1 and state.capture_refusal then
				local original_popen = io.popen
				io.popen = function(...)
					local pipe = assert(original_popen(...))
					return { read = function(_, ...) return pipe:read(...) end, close = function()
						local closed = pipe:close()
						state.actual_child_closed = closed == true or closed == 0
						return nil, "controlled native checked-capture close refusal"
					end }
				end
				local called, complete, output, detail = pcall(actual_shell.exec_checked, command)
				io.popen = original_popen
				if not called then error(complete, 0) end
				state.checked_refusals = (state.checked_refusals or 0) + 1
				return complete, output, detail
			end
			return actual_shell.exec_checked(command)
		end
''',1)
s=s.replace('''			local entries = actual_posix.dir(path)
''','''			local entries = actual_posix.dir(path)
			if state.duplicate == path then
				for _, name in ipairs(entries) do if name ~= "." and name ~= ".." then entries[#entries + 1] = name; break end end
			end
''',1)
s=s.replace('''		function state.file(path)
''','''		function state.file(path, content)
''',1)
s=s.replace('''local wrote, detail = handle:write('[personal.topology]\\ntrigger = "before"\\n')''','''local wrote, detail = handle:write(content or '[personal.topology]\\ntrigger = "before"\\n')''',1)
s=s.replace('''		local previous_posix = package.loaded["posix"]
''','''		local previous_posix, previous_posix_preload = package.loaded["posix"], package.preload["posix"]
		local previous_shell = package.loaded["adapters.shell_runner"]
''',1)
s=s.replace('''				package.loaded["posix"] = scan_port
				watcher = helpers.load_module_with_dependency''','''				package.loaded["posix"] = state.no_posix and nil or scan_port
				if state.no_posix then
					package.loaded["posix"] = nil
					package.preload["posix"] = function() error("explicit supported no-posix watcher backend") end
				end
				package.loaded["adapters.shell_runner"] = shell_port
				watcher = helpers.load_module_with_dependency''',1)
s=s.replace('''				package.loaded["posix"] = previous_posix
''','''				package.loaded["posix"], package.preload["posix"] = previous_posix, previous_posix_preload
				package.loaded["adapters.shell_runner"] = previous_shell
''',1)
s=s.replace('''					if state.fail_callback then error("controlled reload callback refusal") end
''','''					if state.fail_callback then error("controlled reload callback refusal") end
					if state.observe_path then
						local file = assert(io.open(state.observe_path, "r"))
						local content = assert(file:read("*a")); assert(file:close())
						state.observed = state.observed or {}; state.observed[#state.observed + 1] = content
					end
''',1)
s=s.replace('''		package.loaded["infra.file_watchers"], package.loaded["posix"] = previous_watch, previous_posix
''','''		package.loaded["infra.file_watchers"], package.loaded["posix"] = previous_watch, previous_posix
		package.preload["posix"], package.loaded["adapters.shell_runner"] = previous_posix_preload, previous_shell
''',1)
s=s.replace('''s.denied = s.personal; s.file(s.personal .. "/new.toml"); s.settle(0)''','''s.denied = s.personal; s.file(s.personal .. "/new.toml"); s.settle(1)''',1)
s=s.replace('''if backend == "native" then helpers.assert_eq(s.active(s.personal), 1, "ambiguous emptiness cannot retire the original directory owner") end
				s.denied = nil; s.settle(1); s.file(old); s.settle(1)''','''if backend == "native" then
					helpers.assert_eq(s.active(s.personal), 1, "ambiguous emptiness cannot retire the original directory owner")
					helpers.assert_eq(s.active(old), 1, "ambiguous emptiness cannot retire the original file owner")
				end
				s.file(old); s.settle(1)
				s.denied = nil; s.settle(0); s.settle(1); s.file(old); s.settle(1)''',1)
s=s.replace('''s.start_refused = new; s.settle(0)''','''s.start_refused = new; s.settle(1)''',1)
s=s.replace('''s.start_refused = nil; s.settle(1);''','''helpers.assert_eq(s.active(existing), 1, "activation refusal preserves the exact original file owner")
			s.start_refused = nil; s.settle(0); s.settle(1);''',1)
new=r'''
	helpers.it("(linux-watch-topology) native rejects a duplicate native directory result without shadowed handles", function()
		session("native", function(s)
			local old = s.file(s.personal .. "/old.toml"); s.start()
			local sub = s.directory(s.personal .. "/duplicated"); local child = s.file(sub .. "/rules.toml")
			s.duplicate = sub; s.settle(1)
			helpers.assert_eq(s.active(old), 1, "unjudged source cannot replace existing coverage")
			helpers.assert_eq(s.active(child), 0, "duplicate source cannot leave shadowed native bindings")
			s.duplicate = nil; s.settle(0); s.settle(1)
			helpers.assert_eq(s.active(child), 1, "the repaired unique source has exactly one admitted binding")
		end)
	end)
	helpers.it("(linux-watch-topology) native pending Personal refusal preserves accepted main and base bursts", function()
		session("native", function(s)
			s.overlap = true; s.base = s.directory(s.root .. "/base"); s.start(); s.denied = s.personal
			s.file(s.personal .. "/new.toml"); s.settle(1)
			s.file(s.base .. "/changed.lua"); s.settle(1)
			s.file(s.personal .. "/other.toml"); s.settle(1)
		end)
	end)
	helpers.it("(linux-watch-topology) native repaired unobserved coverage refreshes the consumer's latest bytes once", function()
		session("native", function(s)
			s.start(); local sub = s.directory(s.personal .. "/unobserved")
			local path = s.file(sub .. "/rules.toml", "first acknowledged source\n")
			s.observe_path, s.start_refused = path, sub; s.settle(1)
			helpers.assert_eq(s.observed[1], "first acknowledged source\n")
			s.file(path, "new bytes during refused coverage\n"); s.settle(0); s.settle(0)
			helpers.assert_eq(#s.observed, 1, "refused coverage retries cannot repeatedly publish a consumer callback")
			s.start_refused = nil; s.settle(0); s.settle(1)
			helpers.assert_eq(s.observed[2], "new bytes during refused coverage\n", "repair must refresh bytes that changed while unobserved")
			s.idle(); helpers.assert_eq(#s.observed, 2)
			s.file(path, "later observed source\n"); s.settle(1)
			helpers.assert_eq(s.observed[3], "later observed source\n")
		end)
	end)
	for _, fault in ipairs({ "command_refusal", "capture_refusal" }) do
		helpers.it("(linux-watch-topology) native no-posix checked shell refuses " .. fault, function()
			session("native", function(s)
				s.no_posix = true; local old = s.file(s.personal .. "/old.toml"); s.start()
				s[fault] = true; s.file(s.personal .. "/new.toml"); s.settle(1)
				helpers.assert_true((s.checked_refusals or 0) > 0, "the real checked command/capture owner must refuse")
				if fault == "capture_refusal" then helpers.assert_true(s.actual_child_closed, "close the actual captured native child before refusing its receipt") end
				helpers.assert_eq(s.active(old), 1, "partial failed command output cannot erase existing coverage")
				s[fault] = false; s.settle(0); s.settle(1)
				s.file(old); s.settle(1)
			end)
		end)
	end
'''
s=s.replace('\n\tfor _, field in ipairs({ "stop_refused", "close_refused" }) do',new+'\n\tfor _, field in ipairs({ "stop_refused", "close_refused" }) do',1)
p.write_text(s);(b/'source/static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua').write_bytes((b/'literal-tests.lua').read_bytes()+p.read_bytes())
(b/'source/static/ergopti_plus/linux/infra/file_watchers.lua').write_bytes((b/'literal-producer.lua').read_bytes())
