from pathlib import Path
p=Path('/workspace/ergopti-delivery/full-group1-scope/candidate/static/ergopti_plus/_shared/lua/test/config_scope_composition_contract.lua')
old=p.read_text();assert old.endswith('end\n')
extra=r'''
	--- Real files and the actual transaction retain distinct source/runtime owners.
	local function with_cohort_files(run)
		local paths = {}
		local function path()
			local value = os.tmpname()
			os.remove(value)
			paths[#paths + 1] = value
			return value
		end
		local function read(file)
			local stream = io.open(file, "rb")
			if not stream then return nil, "absent" end
			local value = assert(stream:read("*a"))
			assert(stream:close())
			return value, "ok"
		end
		local function write(file, value)
			local stream = assert(io.open(file, "wb"))
			assert(stream:write(value))
			assert(stream:close())
		end
		local files = { read_with_status = read, write = write,
			write_if_unchanged = function(file, value, expected)
				local actual, status = read(file)
				if status ~= expected.status or (status == "ok" and actual ~= expected.content) then return false end
				write(file, value)
				return true
			end,
			delete_if_unchanged = function(file, expected)
				local actual, status = read(file)
				if status ~= expected.status or (status == "ok" and actual ~= expected.content) then return false end
				return os.remove(file) == true
			end,
		}
		local function transaction(file, initial)
			local runtime = { marker = initial, restored = 0 }
			local controls = {}
			local owner = require("config_scope_transaction").new({ path = file, backup_path = path(),
				manifest = Manifest, files = files,
				capture = function() return { marker = runtime.marker } end,
				apply = function(decoded)
					runtime.marker = decoded.gestures.swipe_3_down or "neutral"
					if controls.during_apply then controls.during_apply() end
					return controls.refuse_apply ~= true
				end,
				restore = function(snapshot)
					if controls.refuse_restore then return false end
					runtime.marker, runtime.restored = snapshot.marker, runtime.restored + 1
					return true
				end,
			})
			return owner, runtime, controls
		end
		local ok, detail = pcall(run, path, read, write, transaction)
		for _, file in ipairs(paths) do if io.open(file, "rb") then assert(os.remove(file)) end end
		assert(ok, detail)
	end

	helpers.describe("scope participant retained cohort", function()
		local original = '[gestures]\nenabled = true\nswipe_3_down = "copy"\nfuture = 73\n[foreign]\nkeep = false\n'
		local expected = { gestures = { enabled = true, swipe_3_down = "copy", future = 73 }, foreign = { keep = false } }
		local Codec = require("toml_codec")
		local Participant = require("config_scope_participant")

		helpers.it("reverts the actual committed source and runtime after its provider is replaced", function()
			with_cohort_files(function(path, read, write, transaction)
				local first, second = path(), path()
				write(first, original); write(second, original)
				local a, runtime_a = transaction(first, "runtime-a")
				local b, runtime_b = transaction(second, "runtime-b")
				local latest = a
				local target = Participant.synchronous({ apply = function(mode) return a.apply("gestures", mode) end,
					owner = function() return latest end })
				local later = participant({}, "later", { refuse = true })
				later.apply = function(_, done)
					helpers.assert_eq(b.apply("gestures", "recommended"), true)
					latest = b
					return done(false, "later category refused")
				end
				local successor
				local prior = later.apply
				later.apply = function(mode, done)
					return prior(mode, function(ok, detail) successor = read(second); return done(ok, detail) end)
				end
				local owner = composition({ gestures = target, llm = later })
				local _, ok, report = run(owner, "clear")
				helpers.assert_eq(ok, false)
				helpers.assert_eq(report.reverted, true)
				helpers.assert_eq(Codec.decode(read(first)), expected, "the first owner's complete source model returns")
				helpers.assert_eq(read(second), successor, "a distinct successor is untouched")
				helpers.assert_eq(runtime_a.marker, "runtime-a")
				helpers.assert_eq(runtime_b.restored, 0)
				helpers.assert_eq(b.committed(), true, "the successor retains its own inverse")
			end)
		end)

		helpers.it("preserves a same-path successor and retains the original inverse until exact repair", function()
			with_cohort_files(function(path, read, write, transaction)
				local file = path(); write(file, original)
				local a, runtime_a = transaction(file, "runtime-a")
				local b, runtime_b = transaction(file, "runtime-b")
				local latest, candidate, successor = a, nil, nil
				local target = Participant.synchronous({ apply = function(mode)
					local ok, detail = a.apply("gestures", mode); candidate = read(file); return ok, detail
				end, owner = function() return latest end })
				local later = participant({}, "later", { refuse = true })
				later.apply = function(_, done)
					helpers.assert_eq(b.apply("gestures", "recommended"), true)
					latest, successor = b, read(file)
					return done(false, "later category refused")
				end
				local owner = composition({ gestures = target, llm = later })
				local _, ok, report = run(owner, "clear")
				helpers.assert_eq(ok, false)
				helpers.assert_eq(report.reverted, false, "the foreign publication refuses the original file inverse")
				helpers.assert_eq(read(file), successor)
				helpers.assert_eq(owner.pending(), true)
				helpers.assert_eq(runtime_a.marker, "runtime-a")
				helpers.assert_eq(runtime_b.restored, 0)
				local settled
				owner.retry_restore(function(value) settled = value end)
				helpers.assert_eq(settled, false)
				helpers.assert_eq(read(file), successor)
				write(file, candidate) -- Explicit fixture repair, never a production overwrite.
				owner.retry_restore(function(value) settled = value end)
				helpers.assert_eq(settled, true)
				helpers.assert_eq(Codec.decode(read(file)), expected)
				helpers.assert_eq(runtime_a.restored, 1, "the settled native inverse is not repeated")
				helpers.assert_eq(b.committed(), true)
			end)
		end)

		helpers.it("releases only its committed inverse after a later owner replaced the provider", function()
			with_cohort_files(function(path, _, write, transaction)
				local first, second = path(), path(); write(first, original); write(second, original)
				local a, b = transaction(first, "a"), transaction(second, "b")
				local latest = a
				local target = Participant.synchronous({ apply = function(mode) return a.apply("gestures", mode) end,
					owner = function() return latest end })
				target.apply("clear", function(ok) helpers.assert_eq(ok, true) end)
				helpers.assert_eq(b.apply("gestures", "recommended"), true)
				latest = b
				target.release(); target.release()
				helpers.assert_eq(a.committed(), false)
				helpers.assert_eq(b.committed(), true)
			end)
		end)

		helpers.it("keeps the failed apply owner's runtime debt when the provider advances", function()
			with_cohort_files(function(path, read, write, transaction)
				local file = path(); write(file, original)
				local a, runtime, controls = transaction(file, "original-runtime")
				controls.refuse_apply, controls.refuse_restore = true, true
				local latest = a
				local target = Participant.synchronous({ apply = function(mode) return a.apply("gestures", mode) end,
					owner = function() return latest end })
				target.apply("clear", function(ok) helpers.assert_eq(ok, false) end)
				latest = transaction(path(), "successor")
				helpers.assert_eq(target.pending(), true)
				local settled
				target.retry_restore(function(ok) settled = ok end)
				helpers.assert_eq(settled, false)
				controls.refuse_restore = false
				target.retry_restore(function(ok) settled = ok end)
				helpers.assert_eq(settled, true)
				helpers.assert_eq(runtime.marker, "original-runtime")
				helpers.assert_eq(Codec.decode(read(file)), expected)
			end)
		end)
	end)
'''
p.write_text(old[:-4]+extra+'end\n')
