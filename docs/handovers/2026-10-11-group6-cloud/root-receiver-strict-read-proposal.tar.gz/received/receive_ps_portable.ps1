[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Packet)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$Original = Join-Path $Packet 'received/tools/ci/receive-windows-personal-file-caption-build-source.ps1'
$Library = Join-Path $Packet 'candidate/tools/ci/lib/native-pac-build-source.psm1'
function Assert([bool]$Passed,[string]$Message) { if(-not $Passed){throw $Message} }
function Parse([string]$Text){
 $Tokens=$null;$Errors=$null
 $Ast=[Management.Automation.Language.Parser]::ParseInput($Text,[ref]$Tokens,[ref]$Errors)
 Assert ($Errors.Count -eq 0) 'PowerShell syntax refused.'
 return $Ast
}
function Require-ImportOnly($Ast){
 $Statements=@($Ast.EndBlock.Statements)
 Assert ($Statements.Count -eq 2) 'Module has an unexpected top-level execution statement.'
 Assert ($Statements[0] -is [Management.Automation.Language.FunctionDefinitionAst] -and $Statements[0].Name -ceq 'Invoke-NativePacBuildSourceReceipt') 'Expected sole exported receiver definition.'
 Assert ($Statements[1] -is [Management.Automation.Language.PipelineAst]) 'Expected sole export statement.'
 Assert ($Statements[1].PipelineElements.Count -eq 1) 'Export pipeline changed.'
 $Command=$Statements[1].PipelineElements[0]
 Assert ($Command -is [Management.Automation.Language.CommandAst] -and $Command.GetCommandName() -ceq 'Export-ModuleMember') 'Module executes a non-export command.'
 Assert ($Command.Extent.Text -ceq 'Export-ModuleMember -Function Invoke-NativePacBuildSourceReceipt') 'Module exports arbitrary names.'
}
$OriginalText=[IO.File]::ReadAllText($Original)
$LibraryText=[IO.File]::ReadAllText($Library)
$OriginalAst=Parse $OriginalText
$LibraryAst=Parse $LibraryText
Require-ImportOnly $LibraryAst
Write-Output 'PASS original and extracted library parse with import-only top-level grammar'
$OriginalFunctions=@($OriginalAst.FindAll({param($Node) $Node -is [Management.Automation.Language.FunctionDefinitionAst]},$true))
$NewFunctions=@($LibraryAst.FindAll({param($Node) $Node -is [Management.Automation.Language.FunctionDefinitionAst]},$true))
Assert ($NewFunctions.Count -eq $OriginalFunctions.Count+1) 'Original helper inventory changed.'
foreach($Function in $OriginalFunctions){
 $Actual=@($NewFunctions|Where-Object {$_.Name -ceq $Function.Name})
 Assert ($Actual.Count -eq 1 -and $Actual[0].Extent.Text -ceq $Function.Extent.Text) ('Original function body changed: '+$Function.Name)
}
Write-Output ('PASS all '+$OriginalFunctions.Count+' original native compiler/header/source/receipt helper bodies exact')
foreach($Suffix in @("`nInvoke-NativePacBuildSourceReceipt -Stage prebuild -Root X -InputPath X -SourceCount 3262`n", "`nGet-Content X`n")){
 $Refused=$false
 try {Require-ImportOnly (Parse ($LibraryText+$Suffix))}catch{$Refused=$true}
 Assert $Refused 'Self-starting module mutation was accepted.'
}
Write-Output 'PASS two genuine self-starting/import-I/O mutations refused without running them'
$PreviousLocks=[Environment]::GetEnvironmentVariable('GIT_OPTIONAL_LOCKS')
$BeforeCommands=@(Get-Command Import-MsvcEnvironment -ErrorAction SilentlyContinue)
$Module=Import-Module $Library -Force -PassThru -ErrorAction Stop
Assert ($Module.ExportedFunctions.Count -eq 1 -and $Module.ExportedFunctions.ContainsKey('Invoke-NativePacBuildSourceReceipt')) 'Actual import exports changed.'
Assert (@(Get-Command Import-MsvcEnvironment -ErrorAction SilentlyContinue).Count -eq $BeforeCommands.Count) 'Actual import executes compiler discovery.'
Assert ([Environment]::GetEnvironmentVariable('GIT_OPTIONAL_LOCKS') -ceq $PreviousLocks) 'Actual import changes receipt environment.'
Remove-Module $Module -Force
Write-Output 'PASS actual Linux PowerShell module import exports one receiver without executing compiler discovery or receipt stage'
Write-Output ('{"scope":"LINUX_POWERSHELL_PORTABLE_ONLY","selected":4,"passed":4,"failed":0,"errors":0,"skipped":0,"version":"'+$PSVersionTable.PSVersion.ToString()+'"}')
