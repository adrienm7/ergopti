# Root wizard composed pin forwarding

SOURCE ONLY. The helper is original reviewed Root V2 with exactly two literal
substitutions: V8 packet folder and its new proposal SHA. Full root/qSourceUnion,
index, HEAD, file snapshots, original scenarios/oracles/native assertions/failure
cleanup predicates are unchanged. Default requires current HEAD==qualified HEAD;
--qualified-commit retains original strict sole ordinary child admission.

Use current complete qualification receipt/log/SHA and actual clean published HEAD.
Documentation-only child does not alter654 runtime closure; commit admission must
match genuine q.head relation, never a merely stale green qualification. Root must
first check independent pin-forwarding review and exact helper SHA. No author
runtime. All existing frozen helpers/native payloads and originals preserved.
