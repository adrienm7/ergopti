'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),vm=require('node:vm');
const yaml=require('/workspace/ergopti/node_modules/yaml'),acorn=require('/workspace/ergopti/node_modules/acorn');
const producer='/workspace/ergopti-cloud/group6-clock-status-inline-producer-proposal',meta='/workspace/ergopti-cloud/group6-clock-workflow-owning-enrollment-proposal',published='/workspace/ergopti-cloud/group6-clock-workflow-custody-review';
const root=fs.readFileSync(path.join(producer,'active-physical-root.txt'),'utf8').trim();
const source=fs.readFileSync(path.join(meta,'candidate/tools/test/test-managed-ollama-protocol.cjs'),'utf8');
const declarations=acorn.parse(source,{ecmaVersion:'latest'}).body.filter(n=>n.type==='FunctionDeclaration'&&n.id.name==='assertNativeHTTPClockWorkflow');assert.equal(declarations.length,1);
const predicate=vm.runInNewContext('('+source.slice(declarations[0].start,declarations[0].end)+')',{assert});
const expected=yaml.parse(fs.readFileSync(path.join(producer,'candidate/tools/test/fixtures/native_http_clock_workflow.yml'),'utf8'));
const clone=v=>JSON.parse(JSON.stringify(v));let controls=0,expectedAssertionRefusals=0;
function pass(name,body){body();controls++;console.log('PASS '+name);}
function refusal(name,body){pass(name,()=>{assert.throws(body,e=>e instanceof assert.AssertionError);expectedAssertionRefusals++;});}
const candidates={};for(const ref of ['8d6','4260b74']){
 const old=yaml.parse(fs.readFileSync(path.join(published,ref+'-ci-macos.yml'),'utf8'));
 candidates[ref]=yaml.parse(fs.readFileSync(path.join(producer,ref+'-workflow-own.candidate.yml'),'utf8'));
 refusal(ref+' actual unenrolled source',()=>predicate(old,expected));
 pass(ref+' actual composed own steps and frozen Package',()=>predicate(candidates[ref],expected));
}
const base=candidates['4260b74'];const names=['missing upload','foreign output ID','duplicate output ID','duplicate artifact transport','unconditional deferred upload','missing artifact attempt','renewed five minute budget','source bracket moved before first two commands','lost capture exit','changed Package disposition','omitted source-after-final judge'];
const edits=[
 (w,s,u)=>w.jobs['managed-ollama-native'].steps.splice(w.jobs['managed-ollama-native'].steps.indexOf(u),1),
 (w,s)=>s.id='foreign_clock',
 (w,s)=>w.jobs['managed-ollama-native'].steps.push({name:'Independent duplicate output authority',id:s.id,run:'true'}),
 (w,s,u)=>w.jobs['managed-ollama-native'].steps.push(clone(u)),
 (w,s,u)=>u.if='always()',
 (w,s,u)=>u.with.name=u.with.name.replace('-${{ github.run_attempt }}',''),
 (w,s)=>s['timeout-minutes']=6,
 (w,s)=>{const lines=s.run.split('\n');const b=lines.findIndex(x=>x.includes('native_http_clock_evidence.cjs begin')),f=lines.findIndex(x=>x.includes('macos_owned_process_native_test.py'));assert.ok(b>f);const line=lines.splice(b,1)[0];lines.splice(f,0,line);s.run=lines.join('\n');},
 (w,s)=>{const old='"${owned_status[@]}" "${public_status[@]}" "${client_status[@]}"';assert.ok(s.run.includes(old));s.run=s.run.replace(old,'"${owned_status[0]}" "${public_status[0]}" "${client_status[0]}"');},
 w=>{const p=w.jobs['package-macos'].steps.find(x=>x.name==='Receive actual managed HTTP native clients');p.run=p.run.replace('macos_owned_process_native_test.py','EXPLICIT_omitted_original_package_owned_process.py');},
 (w,s)=>{assert.ok(s.run.includes('node tools/ci/native_http_clock_evidence.cjs judge '));s.run=s.run.replace('node tools/ci/native_http_clock_evidence.cjs judge ','true EXPLICIT_omitted_source_after_final_judge ');}
];
for(let i=0;i<edits.length;i++)refusal(names[i],()=>{const w=clone(base),steps=w.jobs['managed-ollama-native'].steps;const s=steps.find(x=>x.name==='Receive actual independent managed HTTP native clients'),u=steps.find(x=>x.name==='Retain independent native HTTP clock receiving');edits[i](w,s,u);predicate(w,expected);});
const scoped=require(path.join(root,'tools/test/fixtures/ci-scoped-full-branches.cjs'));const protocol=scoped.contract.protocols.find(x=>x.scope==='macos-native-http'&&x.strip===4);
assert.ok(protocol);const oldInput=yaml.parse(fs.readFileSync(path.join(producer,'preimages/tools/test/fixtures/native_http_clock_workflow.yml'),'utf8'));
refusal('original rejected heredoc refuses unchanged full projection strip4',()=>scoped.unwrap(oldInput.jobs['managed-ollama-native'].steps[0].run.trimEnd(),protocol));
pass('corrected inline literal receives unchanged full projection strip4',()=>{const full=scoped.unwrap(expected.jobs['managed-ollama-native'].steps[0].run.trimEnd(),protocol);assert.ok(full.includes('node -e '));assert.ok(full.includes('native_http_clock_evidence.cjs begin '));assert.ok(full.includes('native_http_clock_evidence.cjs judge '));assert.ok(!full.includes('CLOCK_STATUS'));assert.equal(protocol.strip,4);});
console.log(JSON.stringify({controls,expectedAssertionRefusals,node:process.version,native:false,official:false,oldProjectionUnchanged:true}));
