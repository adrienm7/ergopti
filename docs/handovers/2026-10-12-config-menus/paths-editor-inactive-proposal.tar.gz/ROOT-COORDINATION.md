# Group 1: paths-editor initialization proposal for coordinated enrollment

The folders editor can receive both its frontend `ready` message and its native
navigation-completion notification. Its shared `initData` currently replaces both
fields on each delivery, losing a typed folder, a deliberate clear, a native pick
or the Reset selection. The proposal preserves each edited field independently;
untouched fields still follow a fresh payload, and labels, defaults and tags still
refresh. A new document initializes normally.

This is an **inactive source proposal**, with no production or repository-test
integration. The three intended paths are:

- `static/ergopti_plus/_shared/ui/paths_editor/script.js`
- `static/ergopti_plus/_shared/ui/paths_editor/index.html`
- `tools/test/test-paths-editor-page.cjs`

The first changes by 18 added/six removed lines, including an unchanged Save
payload expression reflow. The HTML changes only `script.js` to `script.js?v=1`.
No host policy, locale dictionary, menu proof helper, workflow, native principal
or registration is modified. The base is
`0ba71fa72c09f012c13545c9d9c5236ebf92358c`, tree
`7b85fdd2d8f57ab05e7ae678327eb91bbb77a00a`; recheck exact preimages and concurrent
changes before composition.

Root owns the JS runner and inventory. Please compose these two enrollments with
the test in the **same integration**, retaining every existing entry and alias:

`package.json`, under `scripts`:

```json
"test:paths-editor-page": "node ./tools/test/test-paths-editor-page.cjs"
```

`tools/test/run-js-suite.cjs`, one additional `CHECKS` entry:

```js
{
	name: 'paths editor retains per-field user intent across repeated native initialization',
	cmd: 'node',
	args: ['tools/test/test-paths-editor-page.cjs'],
	repro: 'npm run test:paths-editor-page'
}
```

The current `test-gate-scripts-are-wired.cjs` refuses an orphan test file.
`test-npm-aliases-match-the-suite.cjs` independently requires the mechanical
alias for every direct suite path (`BASELINE_ALIASLESS = 0`). The `repro` field
alone is diagnostic text and does not enroll the test.

The same independent portable test runs the real shared HTML, JavaScript and
host bridge on all three transport shapes, with all 21 real locale dictionaries.
Receiving is **six cases passed/103 failed → 109/0 → six/103 → 109/0** for
literal, candidate, literal and restored candidate. These are **cases**, each
containing multiple assertions; individual assertion calls are not counted.
Each phase retains a matching 25-file pre/post seal. Source assets authenticate
against the base commit. Tests cover raw input, clear, pick and Reset intent,
untouched sibling refresh, fresh documents and edits before delayed first data.
The literal failures comprise 102 intent cases plus the unversioned cache URL.
Pinned repository Prettier configuration/ignore and Node syntax checks pass.

Separate genuine Linux GTK/WebKit source receiving is sealed at:

`/workspace/.ergopti-cloud/resume-paths-gtk-receiving.tar.gz`

SHA-256: `a8cca0a0bd6c9769588d3c635658aa44d930865e4c453fe3d18d524e8f48e108`

It contains 194 members and authenticates the same two-asset production overlay.
The unchanged native worker/controller reports **174 assertions passed/zero
failed → 71 passed/five failed → 174 passed/zero failed**, covering typing,
clearing, Reset and untouched fields through real duplicate-ready routing,
Save and reopening. All 2,361 captured sources remain unchanged in each phase,
with no cleanup errors. The five literal cases fail before later assertions;
their unexecuted tail is not counted as passed. This does not qualify native
Browse, Windows WebView2, Cocoa, installed GUI, physical input or the installed
running logger sink. The GTK archive bytes are intentionally not nested in this
compact source packet.

The proposal is not qualified by a full repository gate or CI on an integrated
SHA. After source/proof review and coordinated enrollment, run `verify-change`
on the actual composition, preserve every original assertion and run affected
OS manual CI with the Release guard intact. Keep remaining native/install/device
requirements in the TODO; this packet closes no item.

Recommended publication: a separate inert documentation packet and a short
handover entry, after the active Linux lot, retaining the feature history. Suggested
repository path:
`docs/handovers/2026-10-12-config-menus/paths-editor-inactive-proposal.tar.gz`.
Use the exact documentation commit URL when sharing the packet. The 14,448-byte
unified patch could fit in an issue comment, but the checked archive also keeps
preimages, source pins, all causal logs and enrollment metadata together.
