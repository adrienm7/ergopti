"""Finite source-only application/qualification supplement; never writes checkout."""
from pathlib import Path
import difflib, hashlib, json, stat, subprocess, tarfile, io, gzip
ROOT=Path(__file__).parent
REPO=Path('/workspace/ergopti')
BASE=Path('/workspace/scratch/group6-linux-public-prepared-queue62')
AFTER=BASE/'body-retirement-corrected-qualification/after'
DRIVER='static/ergopti_plus/linux/'
SHARED='static/ergopti_plus/_shared/lua/network/http_headers.lua'
def digest(value): return hashlib.sha256(value).hexdigest()
def read(path):
    assert stat.S_ISREG(path.lstat().st_mode),str(path)
    data=path.read_bytes();assert b'\r' not in data,str(path)
    return data
def write(path,data):
    target=ROOT/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
def dump(path,value):write(path,(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
assert head=='9f4b8e9c16b2b916c5a5e630f5ac6a1b22c91b13' and status=='', 'Fresh root checkpoint required'
paths=[SHARED]+[DRIVER+x for x in [
'adapters/curl_http_client.lua','adapters/http_client.lua','infra/managed_http.lua',
'tests/hardware/run_http_preflight_receipts.lua','tests/hardware/run_http_body_cleanup_receipts.lua',
'tests/support/prepared_native_ports.lua','tests/unit/infra/test_http_headers.lua',
'tests/unit/adapters/test_managed_prepared_queue.lua','tests/unit/meta/test_native_prepared_headers.lua',
'tests/unit/infra/test_managed_construction_terminal.lua','tests/unit/meta/test_native_descriptor_cancel.lua',
'tests/unit/infra/test_managed_descriptor_cancel.lua','tests/unit/adapters/test_managed_owned_authorization.lua',
'tests/unit/infra/test_curl_identity_forwarding.lua','tests/unit/adapters/test_managed_http_exact_forwarding.lua']]
entries=[];patch=[]
for rel in paths:
    original=read(AFTER/rel)
    data=original
    if rel.endswith('tests/support/prepared_native_ports.lua'):
        data=read(BASE/'normal-registration-proposal/candidate'/rel)
        assert data.split(b'\n',1)[1]==original.split(b'\n',1)[1]
    if rel.endswith('test_native_descriptor_cancel.lua'):
        old=b'--- tests/unit/meta/test_native_descriptor_cancel.lua\n--- Native exact descriptor cancellation receipts; literal refusal ports only.\n'
        assert data.startswith(old)
        data=(b'--- tests/unit/meta/test_native_descriptor_cancel.lua\n\n'
              b'--- ==============================================================================\n'
              b'--- MODULE: Native Descriptor Cancellation Receipt Controls\n'
              b'--- DESCRIPTION:\n'
              b'--- Native exact descriptor cancellation receipts; literal refusal ports only.\n'
              b'--- ==============================================================================\n\n')+data[len(old):]
        write('qualified-control-originals/test_native_descriptor_cancel.lua.source',original)
    if rel.endswith('test_managed_descriptor_cancel.lua'):
        write('qualified-control-originals/test_managed_descriptor_cancel.lua.source',original)
    write('candidate/'+rel,data)
    target=REPO/rel
    assert not target.is_symlink(),rel
    if target.exists():
        before=read(target);write('preimages/'+rel,before)
        disposition={'kind':'regular','sha256':digest(before),'bytes':len(before)}
    else:before=b'';disposition={'kind':'absent'}
    entries.append({'path':rel,'preimage':disposition,'candidate_sha256':digest(data),
                    'qualified_source_sha256':digest(original),'business_and_assertion_tail_unchanged':True})
    if data!=before:
        patch.extend(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),
          fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
write('application.patch',''.join(patch).encode())
manifest_rel=DRIVER+'tests/test_manifest.lua'
before=read(REPO/manifest_rel)
modules=['tests.unit.infra.test_http_headers','tests.unit.meta.test_native_prepared_headers',
 'tests.unit.adapters.test_managed_prepared_queue','tests.unit.infra.test_managed_construction_terminal',
 'tests.unit.meta.test_native_descriptor_cancel','tests.unit.infra.test_managed_descriptor_cancel']
assert all(('"'+x+'"').encode() not in before for x in modules)
assert before.count(b'return {\n')==1
new=before.replace(b'return {\n',b'return {\n'+''.join('\t"'+x+'",\n' for x in modules).encode(),1)
write('registration-preimages/'+manifest_rel,before);write('registration-proposal/'+manifest_rel,new)
write('registration.patch',''.join(difflib.unified_diff(before.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+manifest_rel,tofile='b/'+manifest_rel)).encode())
dump('APPLICATION.json',{'status':'SOURCE_PROPOSAL_NOT_APPLIED','root_head':head,'root_clean':True,'paths':entries,
 'registration':{'preimage_sha256':digest(before),'candidate_sha256':digest(new),'only_additive_rows':modules},
 'normal_cases':{'prepared':34,'descriptor':14,'total_added':48,'existing_auth':27,'existing_forwarding':12},
 'banners_only':{'native_descriptor':'Canonical module header added; every byte following original two-line header exact',
                 'prepared_ports':'Canonical first-line path only; remaining source exact'},
 'final_root_normal_registration_and_gates':'UNEXECUTED'})
# Separate pending output-hop variant. It is not a main-tree application choice.
hop_sources={
 SHARED:BASE/'output-hop-composition/candidate'/SHARED,
 DRIVER+'adapters/http_client.lua':BASE/'output-hop-composition/candidate'/(DRIVER+'adapters/http_client.lua'),
 DRIVER+'adapters/curl_http_client.lua':BASE/'body-retirement-followup/output-hop-composition/candidate'/(DRIVER+'adapters/curl_http_client.lua'),
 DRIVER+'infra/managed_http.lua':BASE/'body-retirement-shadow-correction/output-hop-composition/candidate'/(DRIVER+'infra/managed_http.lua')}
hops=[];hp=[]
for rel,source in hop_sources.items():
    data=read(source);write('pending-output-hop/candidate/'+rel,data)
    oldpath=BASE/'output-hop-composition/preimages'/rel
    old=read(oldpath) if oldpath.exists() else b''
    if old:write('pending-output-hop/preimages/'+rel,old)
    hops.append({'path':rel,'preimage_sha256':digest(old) if old else None,'candidate_sha256':digest(data)})
    hp.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel))
write('pending-output-hop/application.patch',''.join(hp).encode())
dump('pending-output-hop/STATUS.json',{'status':'SOURCE_REVIEWED_RUNTIME_UNEXECUTED','paths':hops,'output_hop_46':'UNEXECUTED',
 'ordinary_qualification_not_inherited':True,'preserved':'All sink/reader/writer/group/source/artifact ownership; output-target eligibility remains isolated',
 'coordinate_owner':'shared_failure62; do not replace its later immutable source packets'})
# Source and typed receipts only: no complete checkout stages or native capture files.
evidence={
 'VALIDATION-CORRECTED.json':BASE/'body-retirement-corrected-qualification/VALIDATION-CORRECTED.json',
 'ADMISSION-CORRECTED.json':BASE/'body-retirement-corrected-qualification/ADMISSION.json',
 'VALIDATION-FIRST-FOLLOWUP.json':BASE/'body-retirement-qualification/VALIDATION-FIRST-FOLLOWUP.json',
 'VALIDATION-NATIVE-FIRST.json':BASE/'native-qualification/VALIDATION-NATIVE.json',
 'VALIDATION-MODELS-FIRST.json':BASE/'qualification/VALIDATION-MODELS.json',
 'run_models.lua.source':BASE/'body-retirement-corrected-qualification/run_models.lua.source',
 'native-launch/run.py.source':BASE/'native-launch-proposal/run.py.source',
 'native-launch/entry.lua.source':BASE/'native-launch-proposal/entry.lua.source',
 'native-launch/SOURCE-INVENTORY.json':BASE/'native-launch-proposal/SOURCE-INVENTORY.json',
 'body830/SOURCE-INVENTORY.json':BASE/'body-retirement-followup/SOURCE-INVENTORY.json',
 'body830/PRESERVATION.json':BASE/'body-retirement-followup/PRESERVATION.json',
 'rename25a/SOURCE-INVENTORY.json':BASE/'body-retirement-shadow-correction/SOURCE-INVENTORY.json',
 'rename25a/PRESERVATION.json':BASE/'body-retirement-shadow-correction/PRESERVATION.json',
 'rename25a/cancel-reason.patch':BASE/'body-retirement-shadow-correction/cancel-reason.patch',
 'prepared/SOURCE-INVENTORY.json':BASE/'SOURCE-INVENTORY.json',
 'live479/SOURCE-INVENTORY.json':BASE/'live-queue-revision/SOURCE-INVENTORY.json',
 'callbackcc2/SOURCE-INVENTORY.json':BASE/'callback-control-revision/SOURCE-INVENTORY.json',
 'source-review-prepared.md':Path('/workspace/scratch/group6-prepared-queue-review/SOURCE-REVIEW.md')}
for rel,source in evidence.items():write('evidence/'+rel,read(source))
# Bound historical fixture bytes; log retained outside this packet.
write('historical-bodypipe20/run_http_body_pipe_receipts.py.source',read(REPO/(DRIVER+'tests/hardware/run_http_body_pipe_receipts.py')))
# Original assertion line order is independently checked, without regenerating any outcomes.
def asserts(data):return [line.strip() for line in data.decode().splitlines() if 'assert(' in line or 'helpers.assert_' in line]
def subsequence(needle,haystack):
    it=iter(haystack);return all(any(x==y for y in it) for x in needle)
preservation=[]
for name in ['run_http_preflight_receipts.lua','run_http_body_cleanup_receipts.lua']:
    rel=DRIVER+'tests/hardware/'+name
    old=read(ROOT/'preimages'/rel);new=read(ROOT/'candidate'/rel)
    a=asserts(old);b=asserts(new)
    assert subsequence(a,b),name
    preservation.append({'path':rel,'original_assertion_lines':len(a),'ordered_literal_lines_sha256':digest(('\n'.join(a)+'\n').encode()),'all_retained_in_order':True})
dump('PRESERVATION.json',{'fixtures':preservation,'independent_expectations_regenerated':False,
 'qualified_control_tails_byte_exact':True,'native_descriptor_header_only_change':True,
 'rename':json.loads(read(BASE/'body-retirement-shadow-correction/PRESERVATION.json'))})
print(json.dumps({'root':str(ROOT),'paths':len(entries),'output_hop_paths':len(hops),'assertions':preservation}))
