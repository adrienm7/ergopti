// tools/ci/run-windows-personal-file-caption-cohort.cjs

// Supplemental personal CI; the mandatory native suite remains byte-preserved.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn, execFileSync } = require('node:child_process');
const { validateAhkSuiteManifest } = require('../test/validate-ahk-suite-manifest.cjs');
const inputs = require('./windows-personal-file-caption-cohort-inputs.json');
const root = path.resolve(__dirname, '../..');
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const source = () =>
	Object.fromEntries(
		Object.keys(inputs.source_sha256).map((rel) => [
			rel,
			sha(fs.readFileSync(path.join(root, rel)))
		])
	);
const demand = (ok, message) => {
	if (!ok) throw new Error(message);
};
const budgetMs = 600000; // Supplemental selection + execution only; below the original 1320000 ms maximum.
let directory, primary, receiptError;
const receipt = {
	scope: 'supplemental-personal-file-caption-twelve',
	status: 'UNRUN',
	full_suite_qualified: false,
	started_at: new Date().toISOString(),
	budget_ms: budgetMs,
	children: [],
	errors: [],
	cleanup_errors: [],
	cohorts: inputs.cohorts.map((cohort) => ({
		id: cohort.id,
		status: 'UNRUN',
		expected_names: cohort.expected_names
	}))
};

async function child(ahk, args, mode, environment, deadline) {
	const tap = path.join(directory, `${mode}.tap.txt`);
	const stdout = path.join(directory, `${mode}.stdout.txt`);
	const stderr = path.join(directory, `${mode}.stderr.txt`);
	const entry = {
		mode,
		command: [ahk, ...args],
		tap,
		stdout,
		stderr,
		attempted: false,
		started: false,
		disposed: false,
		timeout: false,
		native_exit_code: null,
		signal: null
	};
	receipt.children.push(entry);
	let outFd, errFd, proc, pending, alarm, disposalAlarm;
	try {
		outFd = fs.openSync(stdout, 'wx');
		errFd = fs.openSync(stderr, 'wx');
		entry.attempted = true;
		await new Promise((resolve, reject) => {
			proc = spawn(ahk, args, {
				cwd: root,
				env: { ...environment, ERGOPTI_AHK_RESULTS_FILE: tap },
				stdio: ['ignore', outFd, errFd],
				windowsHide: true,
				shell: false
			});
			proc.once('spawn', () => {
				entry.started = true;
				entry.pid = proc.pid;
			});
			proc.once('error', reject);
			proc.once('close', (code, signal) => {
				entry.disposed = true;
				entry.native_exit_code = code;
				entry.signal = signal;
				entry.ended_at = new Date().toISOString();
				resolve();
			});
			alarm = setTimeout(
				() => {
					entry.timeout = true;
					try {
						entry.kill_acknowledged = proc.kill('SIGKILL');
					} catch (error) {
						entry.kill_error = String(error);
					}
					disposalAlarm = setTimeout(
						() => reject(new Error(`${mode}: native exit not acknowledged after timeout`)),
						30000
					);
				},
				Math.max(1, deadline - Date.now())
			);
		});
	} catch (error) {
		pending = error;
	} finally {
		clearTimeout(alarm);
		clearTimeout(disposalAlarm);
		for (const fd of [outFd, errFd])
			if (fd !== undefined) {
				try {
					fs.closeSync(fd);
				} catch (error) {
					receipt.cleanup_errors.push(String(error));
				}
			}
	}
	if (pending) throw pending;
	demand(entry.disposed, `${mode}: missing native exit receipt`);
	// FileAppend owns an exclusive handle. Never read the canonical TAP before exit.
	for (const name of ['tap', 'stdout', 'stderr']) {
		entry[`${name}_present`] = fs.existsSync(entry[name]);
		if (entry[`${name}_present`]) entry[`${name}_sha256`] = sha(fs.readFileSync(entry[name]));
	}
	return entry.tap_present ? fs.readFileSync(tap, 'utf8') : '';
}

function sameImage(actual, expected) {
	return (
		actual &&
		typeof actual === 'object' &&
		!Array.isArray(actual) &&
		JSON.stringify(Object.keys(actual).sort()) === JSON.stringify(Object.keys(expected).sort()) &&
		Object.keys(expected).every((name) => actual[name] === expected[name])
	);
}
function receiveBuildSource() {
	const policy = inputs.build_provenance;
	demand(
		policy.scope === 'personal-file-caption-v7-genuine-native-pac-rebuild',
		'Build receiving scope refused.'
	);
	const expectedPaths = [
		'static/ergopti_plus/windows/vendor/ergopti_network_pac.exe',
		'static/ergopti_plus/windows/vendor/ergopti_network_pac.json'
	];
	demand(
		JSON.stringify(policy.rebuilt_paths) === JSON.stringify(expectedPaths),
		'Build receiving domain refused.'
	);
	demand(
		Object.keys(inputs.source_sha256).length === 3262,
		'Original complete commitment required.'
	);
	demand(
		process.env.PERSONAL_CAPTION_PREBUILD_OUTCOME === 'success' &&
			process.env.PERSONAL_CAPTION_RECEIVE_OUTCOME === 'success',
		'Actual build receiving steps did not succeed.'
	);
	const evidence = path.join(process.env.RUNNER_TEMP, policy.directory_name);
	const evidenceStat = fs.lstatSync(evidence);
	demand(
		evidenceStat.isDirectory() && !evidenceStat.isSymbolicLink(),
		'Build receiving requires the actual evidence directory.'
	);
	const held = {};
	const ordinaryHash = (file) => {
		const stat = fs.lstatSync(file);
		demand(
			stat.isFile() && !stat.isSymbolicLink(),
			`Build receiving requires an ordinary file: ${file}`
		);
		return sha(fs.readFileSync(file));
	};
	const retain = (file) => {
		held[file] = ordinaryHash(file);
		return held[file];
	};
	const receiver = path.join(
		root,
		'tools/ci/receive-windows-personal-file-caption-build-source.ps1'
	);
	demand(retain(receiver) === policy.receiver_sha256, 'Reviewed build receiver changed.');
	const inputPath = path.join(__dirname, 'windows-personal-file-caption-cohort-inputs.json');
	const inputHash = retain(inputPath);
	const ci = {
		sha: process.env.GITHUB_SHA,
		run_id: process.env.GITHUB_RUN_ID,
		run_attempt: process.env.GITHUB_RUN_ATTEMPT,
		job: process.env.GITHUB_JOB
	};
	demand(
		/^[0-9a-f]{40}$/.test(ci.sha || '') &&
			/^[1-9][0-9]*$/.test(ci.run_id || '') &&
			/^[1-9][0-9]*$/.test(ci.run_attempt || '') &&
			typeof ci.job === 'string' &&
			ci.job.length > 0,
		'Actual CI identity missing.'
	);
	const read = (name) => {
		const file = path.join(evidence, name);
		retain(file);
		return JSON.parse(fs.readFileSync(file, 'utf8'));
	};
	const before = read('PREBUILD.json'),
		after = read('POSTBUILD.json');
	for (const [stage, proof] of [
		['prebuild', before],
		['receive', after]
	]) {
		demand(
			proof.scope === policy.scope &&
				proof.stage === stage &&
				proof.status === 'PASS' &&
				proof.inputs_sha256 === inputHash &&
				sameImage(proof.ci, ci),
			'Genuine same-run build proof absent.'
		);
		demand(
			sameImage(proof.producer_source, policy.producer_sha256),
			'Original producer commitment missing.'
		);
	}
	demand(
		sameImage(before.source_before, inputs.source_sha256),
		'Original prebuild commitment incomplete.'
	);
	demand(
		after.prebuild_sha256 === held[path.join(evidence, 'PREBUILD.json')],
		'Prebuild proof linkage changed.'
	);
	demand(
		sameImage(after.original_build, {
			step_id: policy.original_build_step_id,
			command: policy.original_build_command,
			outcome: 'success'
		}),
		'Original successful build linkage absent.'
	);
	for (const [name, hash] of Object.entries(policy.producer_sha256))
		demand(retain(path.join(root, name)) === hash, 'Original producer source changed.');
	demand(
		retain(path.join(root, '.node-version')) === policy.node_version_sha256,
		'Node contract changed.'
	);
	const built = path.join(root, 'static/ergopti_plus/windows/build/native/network_pac');
	const receiptPaths = {
		source_receipt: path.join(built, 'prepared/source_receipt.json'),
		artifact_receipt: path.join(built, 'artifact_receipt.json'),
		msvc_function: path.join(built, 'msvc_function.source.ps1')
	};
	demand(
		sameImage(
			Object.fromEntries(Object.entries(receiptPaths).map(([name, file]) => [name, retain(file)])),
			after.received_files
		),
		'Actual retained producer receipts changed.'
	);
	const runtime = { ...inputs.source_sha256 };
	demand(
		sameImage(
			after.runtime_pair,
			Object.fromEntries(expectedPaths.map((name) => [name, after.runtime_source[name]]))
		),
		'Actual received pair domain changed.'
	);
	for (const name of expectedPaths) {
		demand(
			/^[0-9a-f]{64}$/.test(after.runtime_pair[name] || ''),
			'Received output identity absent.'
		);
		runtime[name] = after.runtime_pair[name];
	}
	demand(
		sameImage(after.runtime_source, runtime),
		'Only two built outputs may replace committed pins.'
	);
	demand(
		after.actual_artifact_manifest.source_fingerprint ===
			policy.expected_current_source_fingerprint &&
			after.actual_artifact_manifest.exe_sha256 === runtime[expectedPaths[0]] &&
			after.received_files.artifact_receipt === runtime[expectedPaths[1]],
		'Artifact/compiled-output linkage refused.'
	);
	return {
		runtime,
		held,
		evidence,
		prebuild_sha256: held[path.join(evidence, 'PREBUILD.json')],
		postbuild_sha256: held[path.join(evidence, 'POSTBUILD.json')]
	};
}
let runtimeSource, buildAdmission;

// Reports are genuine framework TAP comments from each owned native fixture invocation.
// Capture every report before success checks; a primary/secondary refusal cannot be
// hidden by a complete TAP count or an acknowledged child process exit.
function inspectCleanupReports(tap, cohort) {
	const expected = inputs.cleanup_expected_reports[cohort.id];
	const reports = [],
		errors = [];
	let running = null;
	for (const [lineIndex, line] of tap.split(/\r?\n/).entries()) {
		const start = /^RUNNING (\d+)\/(\d+) - (.*)$/.exec(line);
		if (start) running = { index: Number(start[1]), name: start[3] };
		if (line.includes('ERGOPTI_PERSONAL_CAPTION_')) {
			const match =
				/^# (ERGOPTI_PERSONAL_CAPTION_(?:SCALAR_CLEANUP|CLEANUP)) primary_present=([01]) secondary_count=(0|[1-9]\d*)$/.exec(
					line
				);
			const record = {
				line: lineIndex + 1,
				raw: line,
				current: running && { ...running }
			};
			if (match) {
				record.marker = match[1];
				record.primary_present = Number(match[2]);
				record.secondary_count = Number(match[3]);
			} else errors.push(`Malformed cleanup report at line ${lineIndex + 1}.`);
			if (!running)
				errors.push(`Cleanup report outside a running subject at line ${lineIndex + 1}.`);
			if (running && !expected.some((row) => row.subject === running.name))
				errors.push(`Unexpected cleanup subject at line ${lineIndex + 1}.`);
			if (match && (record.primary_present !== 0 || record.secondary_count !== 0))
				errors.push(`Fixture primary or secondary cleanup refusal at line ${lineIndex + 1}.`);
			reports.push(record);
		}
		if (/^(?:not ok|ok) \d+ - /.test(line)) running = null;
	}
	if (reports.length !== expected.length)
		errors.push(`Expected ${expected.length} cleanup reports, received ${reports.length}.`);
	if (
		JSON.stringify(
			reports.map((record) => ({
				subject: record.current && record.current.name,
				marker: record.marker
			}))
		) !== JSON.stringify(expected)
	)
		errors.push('Cleanup report names/order differ from the unchanged native subject oracle.');
	return {
		complete: errors.length === 0,
		expected_reports: expected,
		reports,
		errors
	};
}

async function main() {
	try {
		demand(path.isAbsolute(process.env.RUNNER_TEMP || ''), 'RUNNER_TEMP must be absolute.');
		const destination = path.join(process.env.RUNNER_TEMP, 'windows-personal-file-caption-twelve');
		demand(!fs.existsSync(destination), 'Refusing to reuse prior cohort evidence.');
		fs.mkdirSync(destination);
		directory = destination;
		receipt.output_directory = directory;
		demand(
			inputs.status === 'SEALED_FINAL_COMMITTED_SOURCE',
			'Draft source pins are not executable.'
		);
		demand(process.platform === 'win32', 'This cohort requires the genuine Windows AHK SDK.');
		demand(
			process.argv.length === 4,
			'Usage: node run-windows-personal-file-caption-cohort.cjs <ahk.exe> <file-version>'
		);
		const ahk = path.resolve(process.argv[2]);
		demand(process.argv[3].trim() !== '', 'AHK executable FileVersion is unavailable.');
		receipt.ahk = {
			path: ahk,
			file_version: process.argv[3],
			sha256: sha(fs.readFileSync(ahk))
		};
		const gitEnv = { ...process.env, GIT_OPTIONAL_LOCKS: '0' };
		receipt.source_commit = execFileSync('git', ['rev-parse', 'HEAD'], {
			cwd: root,
			env: gitEnv,
			encoding: 'utf8'
		}).trim();
		demand(
			receipt.source_commit === process.env.GITHUB_SHA,
			'Checkout HEAD differs from the actual CI SHA.'
		);
		buildAdmission = receiveBuildSource();
		runtimeSource = buildAdmission.runtime;
		receipt.build_source_receiving = {
			scope: inputs.build_provenance.scope,
			prebuild_sha256: buildAdmission.prebuild_sha256,
			postbuild_sha256: buildAdmission.postbuild_sha256,
			received_pair: Object.fromEntries(
				inputs.build_provenance.rebuilt_paths.map((name) => [name, runtimeSource[name]])
			),
			toolchain_scope: 'Original before/after discovery only; no retrospective invocation trace.'
		};
		receipt.source_before = source();
		demand(sameImage(receipt.source_before, runtimeSource), 'Original source pins changed.');
		const runner = path.join(root, 'static/ergopti_plus/windows/tests/run_all.ahk');
		const deadline = Date.now() + budgetMs;
		for (const [cohortIndex, cohort] of inputs.cohorts.entries()) {
			const current = receipt.cohorts[cohortIndex];
			current.status = 'ATTEMPTED';
			const childBase = receipt.children.length;
			const common = ['/ErrorStdOut', runner, `--only=${cohort.filter}`];
			try {
				demand(Date.now() < deadline, 'Shared supplemental budget exhausted before selection.');
				const dry = await child(
					ahk,
					[...common, '--dry-run'],
					`${cohort.id}-selection`,
					process.env,
					deadline
				);
				const selection = receipt.children[childBase];
				demand(
					!selection.timeout && selection.native_exit_code === 0 && selection.signal === null,
					'Native dry selection failed.'
				);
				const plans = [...dry.matchAll(/^1\.\.(\d+)\r?$/gm)];
				demand(
					plans.length === 1 && Number(plans[0][1]) === cohort.expected_names.length,
					'Dry selection differs from frozen prospective plan.'
				);
				demand(
					(dry.match(/^# dry-run - skipping execution\.\r?$/gm) || []).length === 1,
					'Missing genuine dry-run marker.'
				);
				demand(
					!/^(RUNNING |ok |not ok |# duration_ms |# \d+ passed)/m.test(dry),
					'Dry selection unexpectedly executed tests.'
				);
				demand(
					!dry.includes('ERGOPTI_PERSONAL_CAPTION_'),
					'Dry selection unexpectedly emitted fixture cleanup reports.'
				);
				demand(Date.now() < deadline, 'Shared supplemental budget exhausted before execution.');
				const actual = await child(ahk, common, `${cohort.id}-actual`, process.env, deadline);
				const manifest = validateAhkSuiteManifest(actual);
				fs.writeFileSync(
					path.join(directory, `${cohort.id}-execution-manifest.json`),
					`${JSON.stringify(manifest, null, 2)}\n`,
					{ flag: 'wx' }
				);
				current.manifest = manifest;
				current.cleanup_receipt = inspectCleanupReports(actual, cohort);
				fs.writeFileSync(
					path.join(directory, `${cohort.id}-cleanup-receipt.json`),
					`${JSON.stringify(current.cleanup_receipt, null, 2)}\n`,
					{ flag: 'wx' }
				);
				const execution = receipt.children[childBase + 1];
				demand(
					!execution.timeout && execution.native_exit_code === 0 && execution.signal === null,
					'Native cohort refused; partial manifest retained.'
				);
				demand(
					manifest.complete &&
						manifest.planned === cohort.expected_names.length &&
						manifest.executed_count === cohort.expected_names.length &&
						manifest.timed_count === cohort.expected_names.length,
					'Incomplete supplemental execution manifest.'
				);
				demand(
					manifest.passed === cohort.expected_names.length &&
						manifest.failed === 0 &&
						manifest.errors.length === 0,
					'Supplemental native assertions failed.'
				);
				demand(
					JSON.stringify(manifest.executed.map((row) => row.name)) ===
						JSON.stringify(cohort.expected_names),
					'Original labels/order differ from frozen source oracle.'
				);
				demand(
					manifest.executed.every(
						(row, i) =>
							row.index === i + 1 && row.status === 'ok' && Number.isFinite(row.duration_ms)
					),
					'Missing native terminal/timing receipts.'
				);
				demand(
					current.cleanup_receipt.complete,
					'Fixture cleanup reports refused; original raw and independent cleanup receipts retained.'
				);
				current.status = 'PASS';
			} catch (error) {
				current.status = 'FAIL';
				current.error = String(error);
				demand(
					receipt.children.every((entry) => !entry.started || entry.disposed),
					'Native retirement unacknowledged; refusing subsequent cohort overlap.'
				);
			}
		}
		demand(
			receipt.cohorts.every((cohort) => cohort.status === 'PASS'),
			'One or more supplemental cohorts failed; original raw evidence retained.'
		);
		receipt.status = 'PASS';
	} catch (error) {
		primary = error;
		receipt.status = 'FAIL';
		receipt.errors.push(String(error));
	} finally {
		try {
			if (buildAdmission) {
				const finalAdmission = receiveBuildSource();
				demand(
					sameImage(finalAdmission.runtime, runtimeSource) &&
						sameImage(finalAdmission.held, buildAdmission.held),
					'Build provenance changed during native receiving.'
				);
			}
			receipt.source_after = source();
			demand(
				sameImage(receipt.source_after, runtimeSource || inputs.source_sha256),
				'Final source pins changed.'
			);
		} catch (error) {
			receipt.cleanup_errors.push(String(error));
		}
		if (receipt.cleanup_errors.length) receipt.status = 'FAIL';
		receipt.native_children_retired = receipt.children.every(
			(entry) => entry.started === false || entry.disposed === true
		);
		if (!receipt.native_children_retired) receipt.status = 'FAIL';
		receipt.ended_at = new Date().toISOString();
		if (directory)
			try {
				fs.writeFileSync(
					path.join(directory, 'RESULT.json'),
					`${JSON.stringify(receipt, null, 2)}\n`,
					{ flag: 'wx' }
				);
			} catch (error) {
				receiptError = error;
			}
	}
	if (primary) {
		console.error(primary);
		if (receiptError) console.error('Receipt failure:', receiptError);
	} else if (receiptError) console.error(receiptError);
	console.log(JSON.stringify(receipt));
	// A failed supplemental probe has its own late workflow verdict. All evidence
	// remains; no process/source/data paths are recursively removed by this helper.
	process.exit(receipt.status === 'PASS' && !receiptError ? 0 : 1);
}
main().catch((error) => {
	console.error(error);
	process.exit(1);
});
