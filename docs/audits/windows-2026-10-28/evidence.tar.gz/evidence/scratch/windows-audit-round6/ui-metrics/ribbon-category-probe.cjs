const fs = require('node:fs');
const {loadMetricsAppsPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const page=loadMetricsAppsPage('windows');
for(const id of ['ribbon_container','ribbon_legend']) page.elements.set(id,page.context.document.createElement('div'));
const category='Label </title><rect data-category-marker="1"/><title>';
const blob={metrics_manifest:{'2026-10-27':{Editor:{app_time_ms:60000,chars:10,time:1000,hourly:{'09':{c:10,time_ms:60000}}}}},user_categories:{Editor:{type:category,score:0}},app_icons:{}};
page.messageListeners.find(entry=>entry.name==='message').callback({data:{type:'prefetch',blob}});
console.log(JSON.stringify({category,svg:page.elements.get('ribbon_container').innerHTML,legend:page.elements.get('ribbon_legend').innerHTML,diagnostics:page.diagnostics}));
