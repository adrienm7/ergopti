"""One bounded read-only API poll; no native logs, redirects or mutations."""
import datetime
import json
import os
from pathlib import Path
import re
import time
import urllib.error
import urllib.request

ROOT = Path('/workspace/.ergopti-cloud')
RUN = '38663542439'
SHA = 'ae6245f0a158290c600a3589d0e32db2273c971f'
TREE = 'c2a6cc23f72006ff823882ea15338985d2c0d9dd'
API = 'https://api.github.com/repos/adrienm7/ergopti'
PREFIX = 'folder-intent-windows-followup-' + RUN + '-'
DEADLINE = time.monotonic() + 40
HEADERS = {'Accept': 'application/vnd.github+json', 'User-Agent': 'ergopti-config-menus-readonly-monitor'}
if os.getenv('GH_TOKEN'):
    HEADERS['Authorization'] = 'Bearer ' + os.getenv('GH_TOKEN')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None

OPENER = urllib.request.build_opener(NoRedirect)
def request(suffix):
    remaining = DEADLINE - time.monotonic()
    if remaining < 1:
        raise TimeoutError('Read-only poll budget reached')
    with OPENER.open(urllib.request.Request(API + suffix, headers=HEADERS), timeout=min(10, remaining)) as response:
        return json.load(response)

def save(name, value):
    file = ROOT / (PREFIX + name + '.json')
    temporary = file.with_suffix('.json.pending')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(file)

def read(name, default):
    file = ROOT / (PREFIX + name + '.json')
    return json.loads(file.read_text()) if file.exists() else default

try:
    run = request('/actions/runs/' + RUN)
    assert run['head_sha'] == SHA and run['event'] == 'workflow_dispatch', 'Actual manual source changed'
    save('run', run)
    source = read('source', {})
    if source.get('sha') != SHA:
        commit = request('/git/commits/' + SHA)
        source = {'sha': commit['sha'], 'tree': commit['tree']['sha']}
        save('source', source)
    assert source['tree'] == TREE, 'Actual source tree changed'
    jobs, page = [], 1
    while True:
        payload = request('/actions/runs/' + RUN + '/jobs?filter=all&per_page=100&page=' + str(page))
        save('jobs-page-' + str(page), payload)
        jobs.extend(payload['jobs'])
        if len(payload['jobs']) < 100:
            break
        page += 1
    assert len(jobs) == payload['total_count'], 'Incomplete jobs pagination'
    save('jobs', {'total_count': len(jobs), 'jobs': jobs})
    cache = read('annotation-cache', {})
    annotation_pending = []
    for job in jobs:
        if job['status'] != 'completed':
            continue
        match = re.fullmatch(re.escape(API) + r'/check-runs/([0-9]+)', job.get('check_run_url', ''))
        if not match:
            annotation_pending.append({'job': job['id'], 'reason': 'No exact repository check-run URL'})
            continue
        identity = str(job['id']) + '|' + str(job.get('completed_at')) + '|' + str(job.get('conclusion'))
        if identity in cache:
            continue
        rows, page = [], 1
        try:
            while True:
                batch = request('/check-runs/' + match[1] + '/annotations?per_page=100&page=' + str(page))
                save('annotations-job-' + str(job['id']) + '-page-' + str(page), batch)
                rows.extend(batch)
                if len(batch) < 100:
                    break
                page += 1
            cache[identity] = {'job_id': job['id'], 'job_name': job['name'], 'annotations': rows}
        except (TimeoutError, urllib.error.URLError) as error:
            annotation_pending.append({'job': job['id'], 'reason': type(error).__name__})
    save('annotation-cache', cache)
    annotations = [{'job_id': item['job_id'], 'job_name': item['job_name'], 'annotation': row}
                   for item in cache.values() for row in item['annotations']]
    save('annotations', annotations)
    status = {'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'run_id': int(RUN),
              'status': run['status'], 'conclusion': run['conclusion'], 'head_sha': SHA, 'tree': TREE,
              'event': run['event'], 'counts': {}, 'annotation_pending': annotation_pending,
              'release_jobs': [{'name': job['name'], 'status': job['status'], 'conclusion': job['conclusion']}
                               for job in jobs if 'release' in job['name'].lower()],
              'jobs': [{'id': job['id'], 'name': job['name'], 'status': job['status'], 'conclusion': job['conclusion'],
                        'failed_steps': [step['name'] for step in job.get('steps', []) if step.get('conclusion') == 'failure']}
                       for job in jobs],
              'limits': 'API metadata only; complete stdout/native logs and SDK pins not received; no dev delivery claim'}
    for job in jobs:
        key = job['conclusion'] or job['status']
        status['counts'][key] = status['counts'].get(key, 0) + 1
    save('status', status)
    history = read('history', [])
    if not history or history[-1].get('jobs') != status['jobs'] or history[-1]['status'] != status['status']:
        history.append(status)
        save('history', history)
    print(json.dumps({'observed_at': status['observed_at'], 'status': run['status'], 'conclusion': run['conclusion'],
                      'counts': status['counts'], 'release': status['release_jobs'], 'annotation_pending': annotation_pending,
                      'failed': [job for job in status['jobs'] if job['conclusion'] in ['failure', 'timed_out', 'cancelled']],
                      'annotations': annotations}, indent=2))
except Exception as error:
    errors = read('observer-errors', [])
    errors.append({'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'kind': type(error).__name__,
                   'http_status': getattr(error, 'code', None), 'scope': 'MONITOR_ERROR_ONLY; no native verdict inferred'})
    save('observer-errors', errors)
    print(json.dumps(errors[-1]))
    raise SystemExit(1)
