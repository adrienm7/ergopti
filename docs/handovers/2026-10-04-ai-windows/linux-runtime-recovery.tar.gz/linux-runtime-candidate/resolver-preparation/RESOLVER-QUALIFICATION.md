# Scratch resolver qualification

Sources remain unconnected and unadopted. No checkout edits, downloads, runtime
installation, generated source changes or assertion changes occurred in this
qualification. The frozen installer remains independently qualified at its
prior 108 product passes, 20 causal rejections and 2 teardown passes.

## Captured executions

All runs activated `/workspace/ergopti-env.sh`. Exact argument vectors, exit
statuses, stdout/stderr paths and their SHA-256 values are recorded in
`results/resolver-seams-and-namespace-20261004/summary.json`. Raw logs were
captured from actual subprocess executions, not reconstructed from prior output.

| Execution | Mode | Exit | Receipt |
| --- | --- | --- | --- |
| 20 independent resolver seams, LuaJIT | require_escalated | 0 | 20 passed, 0 failed |
| 20 independent resolver seams, Lua 5.4 | require_escalated | 0 | 20 passed, 0 failed |
| Original actual namespace-refusal probe, LuaJIT | require_escalated | 1 | Expected root UID 65534; actual root UID 0, native UID 1000, zero writes, read-only plan returned |
| Unchanged actual namespace-refusal probe, LuaJIT | use_default | 0 | Native UID 1000, root UID 65534, `install_ancestor_foreign_owner`, zero writes, loop inactive |
| Unchanged actual namespace-refusal probe, Lua 5.4 | use_default | 0 | Native UID 1000, root UID 65534, `install_ancestor_foreign_owner`, zero writes, loop inactive |

The first actual namespace expectation failure is retained, including its raw
assertion traceback. The same frozen fixture passed in default mode; its
expected identities were not weakened or regenerated. Escalated Lua 5.4
namespace execution was not run after the original LuaJIT failure. Nothing was
skipped by a test harness.

Totals: **40 controlled seam passes**, **2 actual read-only refusal passes**,
**1 preserved namespace-mode expectation failure**. These are separate from
installer, native process, download and positive installation qualifications.
Actual default-mode refusal establishes honest environment admission, not a
functional installation. Escalated-mode read-only planning may support future
native preparation as UID 1000 with UID 0 root ancestry; no preparation or
installation was attempted in that mode.

## Frozen source evidence

The three source hashes before and after all executions were identical:

| Path | SHA-256 |
| --- | --- |
| `shared/llm/ollama_install_policy.lua` | `e50bb92a2afdf1377d7befb782e33a80c5f95b65cd136e342901532546b616a5` |
| `linux/modules/llm/ollama_install_resolver.lua` | `a004f3e967f146e0ff75d925705fc79b77f942cf59f69202710e09e505c5f701` |
| `tests/test_install_resolver_seams.lua` | `8135fdbfbcdf4d2c7000fd046bbd001ecdaa3dac0e0513cb1c0ad40dfe494bd2` |

Frozen namespace fixture SHA-256:
`edbc0a4e30f724c50e9cc7dd79bbe5d5d67e14e65bda75a4fb174676f07673ef`.

## Unexecuted scope

No real parent creation, archive HTTP transfer, authoritative Ollama archive
extraction, installed binary execution, daemon readiness, model transfer,
preference commit, native UI repair flow or packaging/install qualification ran.
The shared process-owner candidate remains unavailable for review/adoption.
Strict repeated pathname checks reject observed substitutions but do not prove
atomic exclusion of a hostile same-UID pathname race. The retained-directory-FD
capability proposed in `BRIDGE-PLAN.md` is not implemented or approved.
