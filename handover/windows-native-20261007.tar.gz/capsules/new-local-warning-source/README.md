# Eight new local-shadow warnings only

Reference 4738 and completed dependency graph 4746 warning rows were compared
as ASCII warning headers/variable/function tuples from exact raw capture bytes.
Non-warning output remains raw; no whole-log encoding normalization is used.
There are exactly eight additions and no lost reference instances. Source-proof
records actual file/line/name and each scoped identifier change.

The three payloads only rename eight locals and their code references, leaving
quoted map keys, comments, calls, decisions, callbacks and signatures unchanged.
All files preserve BOM/LF; each whole UTF8 file reverses byte-exactly. No READY
image, fake getter, test assertion, frozen packet or candidate graph was edited.

Root coverage recipe: compose these three exact baselines into a fresh receiving
copy of the qualified graph. Run canonical READY10, old37 and Direct14; require
the same complete manifests and all tests passing. Count warning tuples: fixed
must retain every old4738 tuple and omit the eight source-proof additions. Run
each of the eight one-variable profiles with READY10: tests still pass but exact
named warning appears and count4739 fails the warning ratchet. Restore all three
images and require4738 again. Keep #Warn settings unchanged. No native execution
of this proposal has been performed, and the earlier completed corpus remains
recording evidence rather than TCP/guardian/config transaction qualification.
