﻿; Interpreted native desktop cohorts reuse the canonical shared runner owners.
; Complete ordinary unit qualification remains mandatory in run_all.ahk.

#Include runner_prelude.ahk

#Include ../infra/tick_count.ahk
#Include ../ui/console_window.ahk
#Include ../infra/logger.ahk
#Include runner_log_directories.ahk
#Include ../infra/toml/toml_helpers.ahk
#Include ../infra/key_combinations.ahk
#Include ../infra/toml/toml_loader.ahk
#Include ../platform/remap/tap_hold_loader.ahk
#Include ../platform/remap/tap_hold_writer.ahk
#Include ../infra/json.ahk
TestQualificationRegisterParser(JsonParse)
#Include ../adapters/text_sender.ahk
#Include ../adapters/key_state.ahk
#Include ../adapters/shell_runner.ahk
InstallSendNoOps()
#Include unit/test_console_window.ahk
#Include unit/test_key_combinations.ahk
#Include ../platform/remap/constants.ahk
#Include ../platform/remap/altgr_criteria.ahk

#Include runner_completion.ahk
