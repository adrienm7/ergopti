﻿; tests/unit/test_ollama_official_archive_provider.ahk

; ==============================================================================
; MODULE: Official Archive Provider Recording Controls
; DESCRIPTION:
; Exercises the actual admission and retirement methods with explicit transport
; and metadata specimens. These controls do not establish HTTPS or kernel proof.
; ==============================================================================

class _OAP_Request extends CurlAsyncRequest {
	__New() {
		this.Method := "GET"
		this.Url := "https://release-assets.githubusercontent.com/owned-release"
		this.Headers := Map("Range", "bytes=0-0")
		this.ResponseHeaders := Map("content-range", "bytes 0-0/2069313829")
		this.Completed := true
		this.Aborted := false
		this.Status := 206
		this.Handle := 0
		this.CleanupPending := false
		this.ResponseText := "P"
		this.CleanupCalls := 0
	}
	_Cleanup() {
		this.CleanupCalls += 1
	}
}

class _OAP_Intake extends OllamaArchiveIntake {
	__New() {
		this.Owned := false
	}
	HasOwner() {
		return this.Owned
	}
}

class _OAP_Provider extends OllamaOfficialArchiveProvider {
	__New() {
		this.Intake := _OAP_Intake()
		this.Generation := 1
		this.FirstError := ""
		this.CurrentFn := (*) => true
		this.IntakeCurrentFn := (*) => true
		this.Record := Map("generation", 1, "request", Map(), "target", Map(), "asset", OllamaReleaseWindowsAsset("windows-amd64"),
			"deadline", A_TickCount + 10000, "cancelled", false, "phase", "probing", "url", "",
			"intake_record", 0, "prepared", false,
			"seen", Map(), "url_bytes", 0, "proxy_tasks", [], "proxy_runs", [], "proxy_pending", false,
			"proxy", 0, "requests", [], "download", 0, "download_url", "", "probe", 0)
	}
}

_OAP_OfficialHostsAreExact() {
	local asset := OllamaReleaseWindowsAsset("windows-amd64")
	AssertTrue(OllamaArchiveOfficialUrl(asset["url"], asset))
	AssertTrue(OllamaArchiveOfficialUrl("https://release-assets.githubusercontent.com/file?token=owned", asset))
	AssertTrue(OllamaArchiveOfficialUrl("https://objects.githubusercontent.com/file", asset))
	for url in ["http://release-assets.githubusercontent.com/file", "https://github.com/foreign/release.zip",
		"https://github.com.evil.invalid/file", "https://release-assets.githubusercontent.com@evil.invalid/file",
		"https://evil.invalid/file", "https://release-assets.githubusercontent.com:443/file",
		"https://RELEASE-ASSETS.githubusercontent.com/file", "https://objects.githubusercontent.com/file#fragment",
		"https://objects.githubusercontent.com/", "relative/path", "https://objects.githubusercontent.com/file" . Chr(10)]
		AssertFalse(OllamaArchiveOfficialUrl(url, asset))
}

_OAP_ExactRangeReceipt() {
	local asset := OllamaReleaseWindowsAsset("windows-amd64"), request := _OAP_Request()
	AssertTrue(OllamaArchiveProbeComplete(request, asset))
	for status in [200, 302, 404, 0, "206"] {
		request.Status := status
		AssertFalse(OllamaArchiveProbeComplete(request, asset))
	}
	request.Status := 206
	for body in ["", "PK", "p"] {
		request.ResponseText := body
		AssertFalse(OllamaArchiveProbeComplete(request, asset))
	}
	request.ResponseText := "P"
	for header in ["bytes 0-0/1", "bytes 1-1/2069313829", "bytes 0-1/2069313829", ""] {
		request.ResponseHeaders["content-range"] := header
		AssertFalse(OllamaArchiveProbeComplete(request, asset))
	}
}

_OAP_RangeRequiresPhysicalAndCleanupReceipt() {
	local asset := OllamaReleaseWindowsAsset("windows-amd64"), request := _OAP_Request()
	request.Handle := {}
	AssertFalse(OllamaArchiveProbeComplete(request, asset))
	request.Handle := 0
	request.CleanupPending := true
	AssertFalse(OllamaArchiveProbeComplete(request, asset))
	request.CleanupPending := false
	request.Aborted := true
	AssertFalse(OllamaArchiveProbeComplete(request, asset))
}

_OAP_RedirectCycleBeforeResolver() {
	local provider := _OAP_Provider(), record := provider.Record, url := record["asset"]["url"]
	record["seen"][url] := true
	AssertThrows(() => provider._Resolve(record, url))
	AssertFalse(record["proxy_pending"])
	AssertEqual(record["proxy_tasks"].Length, 0)
	AssertEqual(record["url_bytes"], 0)
}

_OAP_ForeignRedirectBeforeResolver() {
	local provider := _OAP_Provider(), record := provider.Record
	AssertThrows(() => provider._Resolve(record, "https://foreign.invalid/archive.zip"))
	AssertFalse(record["proxy_pending"])
	AssertEqual(record["proxy_runs"].Length, 0)
}

_OAP_TotalMetadataBudgetBeforeResolver() {
	global HTTP_CURL_MAX_HEADER_BYTES
	local provider := _OAP_Provider(), record := provider.Record
	record["url_bytes"] := HTTP_CURL_MAX_HEADER_BYTES
	AssertThrows(() => provider._Resolve(record, record["asset"]["url"]))
	AssertEqual(record["seen"].Count, 0)
	AssertFalse(record["proxy_pending"])
}

_OAP_MetadataCallbackIsSeparate() {
	local provider := _OAP_Provider(), row := Map("task", {}, "probe", (*) => true, "delivery", (*) => true, "done", false)
	provider.Record["proxy_tasks"].Push(row)
	AssertFalse(provider._MetadataRetired(provider.Record))
	row["done"] := true
	AssertTrue(provider._MetadataRetired(provider.Record))
	row["done"] := false
	row["delivery"] := (*) => false
	AssertTrue(provider._MetadataRetired(provider.Record), "Suppressed failed-start notification is a different receipt.")
	row["probe"] := (*) => false
	AssertFalse(provider._MetadataRetired(provider.Record))
}

_OAP_ActualProxyOwnerCleanupIsRetained() {
	local provider := _OAP_Provider(), owner := {Done: false, Capture: Map("owned", true)}
	provider._ProxyOwner(provider.Record, owner)
	AssertFalse(provider._MetadataRetired(provider.Record))
	owner.Done := true
	AssertFalse(provider._MetadataRetired(provider.Record))
	owner.Capture := 0
	AssertTrue(provider._MetadataRetired(provider.Record))
}

_OAP_PendingProxyWaiterIsNotRetirement() {
	local provider := _OAP_Provider()
	provider.Record["proxy_pending"] := true
	AssertFalse(provider._NoWorkOwned(provider.Record))
	provider.Record["proxy_pending"] := false
	AssertTrue(provider._NoWorkOwned(provider.Record))
}

_OAP_ProxyCallbackChecksFinalGeneration() {
	local provider := _OAP_Provider(), record := provider.Record
	record["url"] := record["asset"]["url"]
	provider.CurrentFn := (*) => (++provider.Generation, true)
	provider._ProxyResolved(record, record["url"], Map("ok", true, "inherit", false, "proxy", ""))
	AssertEqual(record["proxy"], 0)
	AssertTrue(record["cancelled"])
	AssertEqual(provider.FirstError, "archive_proxy_source_changed")
}

_OAP_ProxyScalarsStayTyped() {
	for selection in [Map("ok", "1", "inherit", false, "proxy", ""), Map("ok", true, "inherit", "0", "proxy", ""),
		Map("ok", true, "inherit", 2, "proxy", ""), Map("ok", true, "inherit", false, "proxy", 0)] {
		local provider := _OAP_Provider(), record := provider.Record
		record["url"] := record["asset"]["url"]
		provider._ProxyResolved(record, record["url"], selection)
		AssertEqual(record["proxy"], 0)
		AssertTrue(record["cancelled"])
		AssertEqual(provider.FirstError, "archive_proxy_refused")
	}
}

_OAP_FinalDownloadSourceIsPinned() {
	local provider := _OAP_Provider(), request := _OAP_Request(), record := provider.Record
	record["download"] := request
	record["download_url"] := request.Url
	AssertTrue(provider._IntakeCurrent(Map(), Map()))
	request.Url := "https://foreign.invalid/archive.zip"
	AssertFalse(provider._IntakeCurrent(Map(), Map()))
	request.Url := record["download_url"]
	request.Method := "POST"
	AssertFalse(provider._IntakeCurrent(Map(), Map()))
}

_OAP_RequestSourceTypeCannotChange() {
	local provider := _OAP_Provider(), record := provider.Record
	record["request"]["MaxEntries"] := 10
	AssertTrue(provider._SourceMatches(record, Map("MaxEntries", 10), Map()))
	AssertFalse(provider._SourceMatches(record, Map("MaxEntries", "10"), Map()))
}

Test("official-archive-exact-hosts", _OAP_OfficialHostsAreExact)
Test("official-archive-exact-range-receipt", _OAP_ExactRangeReceipt)
Test("official-archive-range-physical-cleanup", _OAP_RangeRequiresPhysicalAndCleanupReceipt)
Test("official-archive-redirect-cycle", _OAP_RedirectCycleBeforeResolver)
Test("official-archive-foreign-redirect", _OAP_ForeignRedirectBeforeResolver)
Test("official-archive-total-metadata-budget", _OAP_TotalMetadataBudgetBeforeResolver)
Test("official-archive-metadata-callback-retirement", _OAP_MetadataCallbackIsSeparate)
Test("official-archive-proxy-input-retirement", _OAP_ActualProxyOwnerCleanupIsRetained)
Test("official-archive-pending-proxy-retirement", _OAP_PendingProxyWaiterIsNotRetirement)
Test("official-archive-proxy-final-generation", _OAP_ProxyCallbackChecksFinalGeneration)
Test("official-archive-proxy-typed-receipt", _OAP_ProxyScalarsStayTyped)
Test("official-archive-final-download-source", _OAP_FinalDownloadSourceIsPinned)
Test("official-archive-request-source-type", _OAP_RequestSourceTypeCannotChange)

_OAP_UnexpectedSpawn(*) {
	throw Error("A recording proxy control cannot start a native process.")
}

_OAP_QueuedProxyPublishesActualOwner() {
	global _SYSTEM_PROXY_PAC_PENDING, _SYSTEM_PROXY_PAC_CACHE, _SYSTEM_PROXY_PAC_CONFIG
	local saved_pending := _SYSTEM_PROXY_PAC_PENDING, saved_cache := _SYSTEM_PROXY_PAC_CACHE, saved_config := _SYSTEM_PROXY_PAC_CONFIG
	AssertFalse(IsObject(saved_pending), "Recording may not replace a foreign live PAC owner.")
	local owner := {Waiters: [], Done: false, Capture: Map("owned", true)}, observed := [], answers := []
	local reader := (*) => Map("auto_detect", true, "pac_url", "", "proxy", "", "bypass", "")
	try {
		_SYSTEM_PROXY_PAC_PENDING := owner
		AssertTrue(SystemProxy_ResolveCurlAsync("https://github.com/ollama/ollama/releases/download/v0.24.0/ollama-windows-amd64.zip",
			(Value) => answers.Push(Value), reader, _OAP_UnexpectedSpawn, (*) => "", (Value) => observed.Push(Value)))
		AssertEqual(observed.Length, 1)
		AssertTrue(observed[1] == owner)
		AssertEqual(owner.Waiters.Length, 1)
		AssertTrue(owner.Waiters[1].Owner is Func)
		AssertEqual(answers.Length, 0)
	} finally {
		if _SYSTEM_PROXY_PAC_PENDING == owner
			_SYSTEM_PROXY_PAC_PENDING := saved_pending
		_SYSTEM_PROXY_PAC_CACHE := saved_cache
		_SYSTEM_PROXY_PAC_CONFIG := saved_config
	}
}

_OAP_ObserverRefusalPrecedesNativeAcquisition() {
	global _SYSTEM_PROXY_PAC_PENDING, _SYSTEM_PROXY_PAC_CACHE, _SYSTEM_PROXY_PAC_CONFIG
	local saved_pending := _SYSTEM_PROXY_PAC_PENDING, saved_cache := _SYSTEM_PROXY_PAC_CACHE, saved_config := _SYSTEM_PROXY_PAC_CONFIG
	AssertFalse(IsObject(saved_pending), "Recording requires no foreign PAC owner.")
	local observed := [], answers := [], expected := Error("Recorded ownership observer refused."), caught := 0
	local reader := (*) => Map("auto_detect", true, "pac_url", "", "proxy", "", "bypass", "")
	RefuseOwner(Value) {
		observed.Push(Value)
		throw expected
	}
	try {
		try SystemProxy_ResolveCurlAsync("https://github.com/ollama/ollama/releases/download/v0.24.0/ollama-windows-amd64.zip",
			(Value) => answers.Push(Value), reader, _OAP_UnexpectedSpawn, (*) => "", RefuseOwner)
		catch Any as Err {
			caught := Err
		}
		AssertTrue(caught == expected)
		AssertEqual(observed.Length, 1)
		AssertTrue(observed[1].Done)
		AssertEqual(observed[1].Capture, 0)
		AssertEqual(observed[1].Handle, 0)
		AssertTrue(observed[1].OwnerObservationFailure == expected)
		AssertEqual(answers.Length, 1)
		AssertFalse(answers[1]["ok"])
		AssertFalse(IsObject(_SYSTEM_PROXY_PAC_PENDING))
	} finally {
		if IsObject(_SYSTEM_PROXY_PAC_PENDING) && observed.Length && _SYSTEM_PROXY_PAC_PENDING == observed[1]
			_SYSTEM_PROXY_PAC_PENDING := saved_pending
		_SYSTEM_PROXY_PAC_CACHE := saved_cache
		_SYSTEM_PROXY_PAC_CONFIG := saved_config
	}
}

_OAP_InvalidOwnerPortBeforeConfiguration() {
	local observed := Map("reads", 0, "callbacks", 0), reader := (*) => (++observed["reads"], Map())
	AssertThrows(() => SystemProxy_ResolveCurlAsync("https://github.com/ollama/ollama/releases/download/v0.24.0/ollama-windows-amd64.zip",
		(*) => ++observed["callbacks"], reader, _OAP_UnexpectedSpawn, (*) => "", 1))
	AssertEqual(observed["reads"], 0)
	AssertEqual(observed["callbacks"], 0)
}

Test("official-archive-queued-proxy-owner", _OAP_QueuedProxyPublishesActualOwner)
Test("official-archive-owner-refusal-before-acquisition", _OAP_ObserverRefusalPrecedesNativeAcquisition)
Test("official-archive-invalid-owner-port-before-configuration", _OAP_InvalidOwnerPortBeforeConfiguration)

_OAP_ProxyObserverCanFinishBeforeEffects(Queued) {
	global _SYSTEM_PROXY_PAC_PENDING, _SYSTEM_PROXY_PAC_CACHE, _SYSTEM_PROXY_PAC_CONFIG
	local saved_pending := _SYSTEM_PROXY_PAC_PENDING, saved_cache := _SYSTEM_PROXY_PAC_CACHE, saved_config := _SYSTEM_PROXY_PAC_CONFIG
	AssertFalse(IsObject(saved_pending), "Recording may not replace a live PAC owner.")
	local observed := [], answers := [], url := "https://github.com/ollama/ollama/releases/download/v0.24.0/ollama-windows-amd64.zip"
	local config := Map("auto_detect", true, "pac_url", "", "proxy", "", "bypass", "")
	local model := {Waiters: [], Urls: [url], Done: false, Capture: 0, Handle: 0, Strict: true,
		ConfigIdentity: "", Config: config}
	FinishObserved(Value) {
		observed.Push(Value)
		_SystemProxy_FinishPac(Value, -1, "", "")
	}
	try {
		model.ConfigIdentity := _SystemProxy_RefreshCache(config)
		if Queued
			_SYSTEM_PROXY_PAC_PENDING := model
		AssertTrue(SystemProxy_ResolveCurlAsync(url, (Value) => answers.Push(Value), (*) => config,
			_OAP_UnexpectedSpawn, (*) => "", FinishObserved))
		AssertEqual(observed.Length, 1)
		AssertTrue(observed[1].Done)
		AssertEqual(observed[1].Handle, 0)
		AssertEqual(observed[1].Capture, 0)
		AssertFalse(IsObject(_SYSTEM_PROXY_PAC_PENDING))
		AssertEqual(answers.Length, 1)
		AssertFalse(answers[1]["ok"])
		AssertEqual(observed[1].Waiters.Length, Queued ? 0 : 1)
	} finally {
		if IsObject(_SYSTEM_PROXY_PAC_PENDING) && observed.Length && _SYSTEM_PROXY_PAC_PENDING == observed[1]
			_SYSTEM_PROXY_PAC_PENDING := saved_pending
		_SYSTEM_PROXY_PAC_CACHE := saved_cache
		_SYSTEM_PROXY_PAC_CONFIG := saved_config
	}
}

class _OAP_StartIntake extends _OAP_Intake {
	__New() {
		super.__New()
		this.Options := Map("archive_bytes", OllamaReleaseWindowsAsset("windows-amd64")["bytes"])
		this.Record := 0
		this.Starts := 0
	}
	Start(Prepare, Target, Deadline) {
		this.Starts += 1
		this.Owned := true
		this.Record := Map("cancelled", false, "request", Prepare.Clone(), "target", Target.Clone(), "deadline", Deadline)
		return true
	}
}

class _OAP_StartProvider extends _OAP_Provider {
	__New() {
		super.__New()
		this.Intake := _OAP_StartIntake()
		this.Record := 0
		this.Schedules := 0
	}
	_Schedule() {
		this.Schedules += 1
	}
}

_OAP_PostAcquisitionRefusalRetainsAndRevokes() {
	local provider := _OAP_StartProvider(), calls := Map("count", 0), asset := OllamaReleaseWindowsAsset("windows-amd64")
	provider.CurrentFn := (*) => (++calls["count"], calls["count"] == 1)
	AssertFalse(provider.Start(Map("AssetId", "windows-amd64"), Map(), asset, A_TickCount + 10000))
	AssertEqual(provider.Intake.Starts, 1)
	AssertTrue(provider.Intake.HasOwner())
	AssertTrue(provider.Record is Map && provider.Record["cancelled"])
	AssertEqual(provider.Record["phase"], "retiring")
	AssertEqual(provider.FirstError, "archive_acquisition_refused")
	AssertFalse(provider._NoWorkOwned(provider.Record))
	provider.CurrentFn := (*) => true
	AssertFalse(provider._Current(provider.Record), "A later current read cannot undo the refusal.")
	provider.Intake.Owned := false
	AssertTrue(provider._NoWorkOwned(provider.Record), "Only the recorded handback removes this modeled native debt.")
}

Test("official-archive-new-owner-reentrant-finish", _OAP_ProxyObserverCanFinishBeforeEffects.Bind(false))
Test("official-archive-queued-owner-reentrant-finish", _OAP_ProxyObserverCanFinishBeforeEffects.Bind(true))
Test("official-archive-post-acquisition-refusal", _OAP_PostAcquisitionRefusalRetainsAndRevokes)
