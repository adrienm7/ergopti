# AST-only Linux parser evidence

The parent reserved one exclusive local slot for AST-only parsing and provided
checksum-verified official PowerShell 7.4.13 at
`/workspace/.native/powershell/7.4.13/pwsh`. Its archive receipt is
`/workspace/.native/powershell/receipt.json`.

First command:

```bash
/workspace/.native/powershell/7.4.13/pwsh -NoLogo -NoProfile -NonInteractive -File /workspace/ergopti-validation/windows-ollama-runtime-candidate/parse-v2.ps1 > /workspace/ergopti-validation/windows-ollama-runtime-candidate/versions/file-port-v2/parser-v2.json
```

Exit 134 before any parsing. PowerShell startup attempted to create
`/home/agent/.cache/powershell` on a read-only filesystem. No candidate code ran.

Corrected command, reusing the existing onboarding environment activation:

```bash
source /workspace/ergopti-env.sh
/workspace/.native/powershell/7.4.13/pwsh -NoLogo -NoProfile -NonInteractive -File /workspace/ergopti-validation/windows-ollama-runtime-candidate/parse-v2.ps1 > /workspace/ergopti-validation/windows-ollama-runtime-candidate/versions/file-port-v2/parser-v2.json
```

Exit 0, PowerShell Core 7.4.13 on Unix. `Parser.ParseFile` returned all three ASTs
with zero diagnostics. Source hashes before/after agree for each file; the
complete diagnostic and hash receipt is in `parser-v2.json`. The parser harness
only hashes sources and asks the parser for ASTs. It never executes the AST,
dot-sources a candidate or invokes Add-Type. The slot was released immediately.
Windows PowerShell 5.1 and every native implementation/test remain unexecuted.

After bounded inventory validation replaced recursive traversal, the parent
granted a second exclusive slot. The corrected command above ran again, exited
0 and produced the final `parser-v2.json`: three ASTs, zero diagnostics and
unchanged hashes, including helper
`ee0a64aa40c17e15bd863e7b651043e3bd607848dd0f49bfb90b5150ea017d1f`.
The first successful parse is preserved as `parser-v2-pre-inventory.json`.
