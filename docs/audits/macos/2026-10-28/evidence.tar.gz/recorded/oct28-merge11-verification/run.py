from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/workspace/ergopti-macos-integration');s=Path('/workspace/scratch/oct28-merge11-verification')
e=os.environ.copy();e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';e['USER']='agent';e['LOGNAME']='agent'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')=='37ad319e514c3ade085dee292c35fca4e05d6cef'
assert git('rev-parse','MERGE_HEAD')=='42acb5cdcf2c027925a672b94b30bcbc79bccc34'
paths=git('diff','--name-only','6d67374daeb70f3699a2266fd8118e77ca9658f3','MERGE_HEAD').splitlines();assert len(paths)==9
own=['static/ergopti_plus/macos/infra/field_run.lua','static/ergopti_plus/macos/tests/unit/infra/field_run/test_field_run.lua']
rows=[]
def run(name,cmd):
 t=time.monotonic()
 with(s/(name+'.log')).open('wb')as f:rc=subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append({'name':name,'command':cmd,'actual_exit':rc,'seconds':round(time.monotonic()-t,3)});(s/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,rc,flush=True);assert rc==0
run('generate',['npm','run','-s','gen'])
for row in json.loads(Path('/workspace/scratch/oct28-merge10-verification/receipts.json').read_text()):run(row['name'],row['command'])
for name,script in [('locale-catalogue','test:locale-catalogue-complete'),('windows-literals','test:config-key-literals'),('constant-owner','test:duplicate-constant-names')]:run(name,['npm','run','-s',script])
for path in paths:assert git('rev-parse',':'+path)==git('rev-parse','MERGE_HEAD:'+path),path
for path in own:assert git('rev-parse',':'+path)==git('rev-parse','HEAD:'+path),path
assert not git('diff','--name-only')
(s/'source.json').write_text(json.dumps({'base':git('rev-parse','HEAD'),'incoming':git('rev-parse','MERGE_HEAD'),'staged_tree':git('write-tree'),'incoming_paths_exact_dev':paths,'owned_field_paths_unchanged':own,'all_actual_zero':True,'own_edits_to_protected_files':False},indent=2)+'\n')
