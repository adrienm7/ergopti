<!-- group6-updater-recovery-2026-10-06/README.md -->

# Reviewed group6 updater source preservation

This finite archive preserves exact reviewed updater3/installer5/registry6 source
packets, preimages, patches, both bounded reviews, all96 independent controls,
normal-registration/application proposals and unexecuted qualification commands.
It is not an integrated or qualified runtime feature. Original manifests retain
their historical statuses; EVIDENCE-SUMMARY.json separates later independently
qualified prerequisites from the unexecuted composite.

Source snapshots use an inert .source suffix without changing their bytes.
PORTABLE-MAPPING.json maps every original absolute locator to its archived path
and SHA256. Restore scratch files only into a new private preparation location;
never overwrite the repository from this archive. To restore original scratch
filenames, remove only the recorded inert suffix according to the mapping.
Keep manifests/reviews byte-exact; revise execution metadata explicitly when the
workspace location differs. Root-owned repository evidence is an assertion
snapshot, not permission to apply it over current upstream sources.

Before launching anything, compare all archive hashes and source preimages,
review current origin/dev and confirm the exclusive qualification slot with its
owner. Read qualification-plan/COMMANDS.md and restore its .py/.lua source names
in scratch. Its exact96 launch was authored but never executed. Each module uses
a fresh genuine-framework process and both ABIs sequentially; first candidate
failure stops the sequence. Preserve predecessor failures, absent-contract
negatives and original assertions separately. Follow the root application plan
for current protected producers, canonical generation and package ownership.

No compiled binary, secret, environment value, raw private runtime log, native
child identity ledger or thousands-of-files source snapshot is included. Native
C26/clock256 and feeder30+8 are independently scoped facts, not complete updater
acceptance. The old failed feeder is represented by preserved source preimages
and an honest status summary; no cause is inferred from its later pass. Actual
registry/installer/HTTP composition and installed package checks remain required.

The separate adjacent .tar.gz is deterministic source storage. Its adjacent
ARCHIVE-RECEIPT.json records checksum, member count and size; SOURCE-SHA256SUMS.tsv
inside records every source/metadata member except itself. No root files, tests,
Git refs, CI, generator or TODO were changed to create it.
