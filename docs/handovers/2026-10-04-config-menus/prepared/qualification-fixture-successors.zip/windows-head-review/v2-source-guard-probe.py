from pathlib import Path
import json,re
root=Path('/workspace/ergopti-delivery/windows-head-regression-v2-archive')
provider=(root/'static/ergopti_plus/windows/ui/menu/menu_taphold.ahk').read_text(encoding='utf-8-sig');renderer=(root/'static/ergopti_plus/windows/infra/manifest_menu.ahk').read_text(encoding='utf-8-sig');meta=(root/'static/ergopti_plus/windows/tests/meta/test_tap_hold_menu_register_dispatch.ahk').read_text(encoding='utf-8-sig');manifest=json.loads((root/'static/ergopti_plus/_shared/modules/menu/menu_manifest.json').read_text())
def body(source,name):
 start=re.search(r'(?m)^'+re.escape(name)+r'\([^\n]*\)\s*\{',source);assert start,name
 pos=start.end();depth=1;quoted=None;escaped=False;comment=False
 while depth:
  c=source[pos];pos+=1
  if comment:
   if c=='\n':comment=False
   continue
  if escaped:escaped=False;continue
  if c=='`':escaped=True;continue
  if quoted:
   if c==quoted:quoted=None
   continue
  if c in "\"'":quoted=c
  elif c==';':comment=True
  elif c=='{':depth+=1
  elif c=='}':depth-=1
 return '\n'.join(line for line in source[start.start():pos].splitlines() if not line.lstrip().startswith(';'))
menu_patterns=re.findall(r'RegExMatch\(Body, "([^"\n]+Menu[^"\n]+)"\)',meta)
assert len(menu_patterns)==3 and len(set(menu_patterns))==1,menu_patterns
menu_pattern=menu_patterns[0]
binding_suffix=re.search(r'Chr\(34\) \. "([^"\n]+)" \. Fn',meta).group(1)
action_suffix=re.search(r'Chr\(34\) \. "action" \. Chr\(34\) \. "([^"\n]+)"',meta).group(1)
assert "\x08" not in menu_pattern

def checks(p,r,m):
 b=body(p,'_TH_KeyRows'); t=body(r,'_MR_TemplateRows'); cp=body(r,'MenuRenderer_CommandRow'); d=body(r,'_MR_DeclaredProviderRow'); data=body(r,'_MR_CommandRowData'); render=body(r,'_MR_RenderRows')
 commands={'tap_hold_key_native':'_TH_MakeDisableFn','tap_hold_key_tap':'_TH_MakeTapPickerFn'};sections={'tap_hold_key_native_commands':'tap_hold_key_native','tap_hold_key_head':'tap_hold_key_tap'}
 return {
 'raw_menu_refused':not re.search(menu_pattern,b),'raw_registration_refused':'RegisterMenuItem(' not in b,
 'actual_shared_head':'MenuRenderer_TemplateRows("tap_hold_key_head"' in b,
 'native_bindings':all(re.search('"'+key+'"'+binding_suffix+fn,b) for key,fn in commands.items()),
 'include_reachable':m['tap_hold_key_head'][0]['type']=='include' and m['tap_hold_key_head'][0]['section']=='tap_hold_key_native_commands',
 'declared_commands':all(any(row.get('id')==key and row.get('type')=='command' and ('platforms' not in row or 'ahk' in row['platforms']) for row in m[section]) for section,key in sections.items()),
 'template_materializes':'MenuRenderer_CommandRow(' in t,'command_owner':'_MR_DeclaredProviderRow(' in cp,'row_data_owner':'_MR_CommandRowData(' in d,
 'action_data':bool(re.search('"action"'+action_suffix,data)),
 'actual_dispatch_registration':'RegisterMenuItem(TargetMenu, Label, Row["action"])' in render}
normal=checks(provider,renderer,manifest);assert all(normal.values()),normal
mutants={
 'missing_native_binding':(provider.replace('"tap_hold_key_native", _TH_MakeDisableFn','"wrong_identity", _TH_MakeDisableFn'),renderer,manifest),
 'missing_shared_head':(provider.replace('MenuRenderer_TemplateRows("tap_hold_key_head"','MenuRenderer_TemplateRows("wrong_head"'),renderer,manifest),
 'raw_menu_construction':(provider.replace('_TH_KeyRows(Hand) {','_TH_KeyRows(Hand) {\n Menu()'),renderer,manifest),
 'raw_provider_registration':(provider.replace('_TH_KeyRows(Hand) {','_TH_KeyRows(Hand) {\n RegisterMenuItem('),renderer,manifest),
 'missing_canonical_action':(provider,renderer.replace('"action", Commands[CmdId]','"wrong_action", Commands[CmdId]'),manifest),
 'untracked_native_dispatch':(provider,renderer.replace('RegisterMenuItem(TargetMenu, Label, Row["action"])','TargetMenu.Add(Label, Row["action"])'),manifest)}
results={name:checks(*values) for name,values in mutants.items()};assert all(not all(result.values()) for result in results.values())
# Reproduce the exact old AHK source predicate: AHK does not consume backslashes.
b=body(provider,'_TH_KeyRows');preimage_meta=Path('/workspace/ergopti-delivery/windows-head-regression-packet/preimages/static/ergopti_plus/windows/tests/meta/test_tap_hold_menu_register_dispatch.ahk').read_text(encoding='utf-8-sig')
old_suffix=re.search(r'Chr\(34\) \. "action" \. Chr\(34\) \. "([^"\n]+)" \. Fn',preimage_meta).group(1)
old={fn:bool(re.search('"action"'+old_suffix+fn,b)) for fn in ['_TH_MakeDisableFn','_TH_MakeTapPickerFn']};assert not any(old.values())
preimage_menu_patterns=re.findall(r'RegExMatch\(Body, "([^"\n]+Menu[^"\n]+)"\)',preimage_meta)
assert all(pattern.startswith("\x08") for pattern in preimage_menu_patterns)
assert all(not re.search(pattern,body(mutants['raw_menu_construction'][0],'_TH_KeyRows')) for pattern in preimage_menu_patterns)
Path(__file__).with_name('source-guard-proof.json').write_text(json.dumps({'kind':'portable evaluation of actual AHK source guard predicates; not native AHK execution','actual_frozen_patterns':{'menu':menu_patterns,'binding_suffix':binding_suffix,'action_suffix':action_suffix,'old_action_suffix':old_suffix,'old_menu':preimage_menu_patterns},'normal':normal,'original_predicates_reproduced':old,'mutants':results},indent=2)+'\n')
print('Actual source chain:11 predicates pass. Six causal source mutants rejected. Original two literal action predicates reproduced red.')
