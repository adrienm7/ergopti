# Configuration native receiving, 2026-10-15

This packet records four published native Group 1 atoms and their exact feature checkpoint, followed by the final diagnostics receiving supplied at sealing. `source/SOURCE-PINS.json` identifies every immutable commit, parent, tree, path, Git blob and SHA256; atomic patches and one final source copy per changed path permit review without duplicate checkouts. The initial four-atom checkpoint is `4b08766a2660c631dd670e37fe9ec321867412ae`. A feature checkpoint is not a Dev delivery.

## Four native atoms

| Fix | Published commit | Targeted causal result | Relevant local terminal gate |
| --- | --- | --- | --- |
| macOS native folder-picker refusal | `5bc47ca57fa858f596a91f69154c2d613013ebb6` | Literal 6 passed/2 failed; corrected 8/0, preserving the original prefix | Portable macOS 19,830/0 in 1,604 modules; E2E 101/0 plus one explicit skip |
| Linux native chooser exit receipt | `b6f0cbd86281ec0bed7fc38456806668d898f6fa` | Actual private zenity/kdialog children exit 1 or 7 while emitting an absolute path: literal 22/4; corrected 26/0 on LuaJIT/Lua5.4 | Selected Linux 13,810/0 in 521 modules; E2E 193/0 |
| Linux filesystem-root preservation | `ab2ca83d2b245ecc44fe4d0f62df05750f486456` | Four literal root vectors fail; composed owning modules 55/0 on both engines; two original bridge controls 1/0 each | Selected Linux 13,814/0 in 521 modules; E2E 193/0 |
| Linux watcher fixture placement | `3011ea7ef2ac582374410eb2f721ba405c390d5b` | Two original fixture cases each 0/1 under /tmp and 1/0 under /var/tmp; corrected cases 1/0 under /tmp with POSIX unavailable | Complete registered Git-view Linux 13,802/0 in 521 modules; E2E not rerun for this test-only atom |

These gates ran on their explicitly bracketed source compositions, not a single invented combined SHA. Local status files preserve before/after sources and actual commands. The final-source hosted CI remains a separate qualification. The macOS validated proof remains one exact nested archive rather than duplicated expansions.

The Linux watcher producer intentionally excludes paths beginning `/tmp/` and `/dev/` from Lua-source reloads. Only the two base-owner fixture sessions now choose uniquely owned `/var/tmp` roots; source policy, names, callbacks and every assertion remain unchanged. Under global POSIX absence, the complete watcher module executes 82 cases with zero failures, including all 34 topology cases. One unchanged original installed-POSIX integration subject is unavailable; it is not counted as an 83rd global-no-POSIX success. Ordinary real-POSIX receiving executes 83. The previous partial Linux/shared capture did not contain the full suite's sibling extensions and macOS action catalogue and was explicitly retired as unqualified; only the complete registered Git worktree gate supplies the 13,802 result.

Native child exit/status and real watcher/file resources are exercised where declared. Native GUI rendering, Cocoa/OSA execution, installed daemon, keyboard-grab/device interaction and physical root writes remain unqualified unless a specific receipt states otherwise. Root persistence uses owned bootstrap fixtures and never writes configuration files at `/`.

## Historical failed CI D7

`historical-ci-d7/` preserves API receipt, job census and unit annotations for run 38717729588, source `d7b8d23bb1f1c80b4b70ce6cf599ba66c31bd01a`, tree equal to source 7523. The whole run is FAILED: 12 jobs, 4 successful, 3 failed, 5 skipped; Release is skipped. The Unit annotation gives 13,799 passed/2 failed, naming the two base-owner watcher cases. Raw job logs and the failure artifact were not received. No exact hosted assertion text or exclusive cause is invented from these annotations; local /tmp reproduction remains separately identified. Private storage-proxy 403 responses, empty error ZIPs and storage-signed URLs are excluded.

## Publication and unqualified attempts

`automatic/CENSUSES.json` binds each of the four native commit SHAs and the Dev-merge feature SHA to its four recorded automatic-workflow polls. All recorded results are empty; no manual validation was cancelled. Empty polls establish observed state at those checkpoints, not an assurance about later workflow creation.

`unqualified-attempts/` retains small explicit status records for the earlier failed Linux exit composition, the interrupted root prerequisite gate and the interrupted incomplete-capture suite. These are not passing gates or replacements for their original results. Their raw logs remain preserved externally; successful final local logs/statuses are included separately. The failed hosted D7 run is not rewritten by any later local pass.

## Diagnostics and packet integrity

Candidate diagnostics commit `280174ee225a5d28869efec6061e43dd20bfe015` and its exact receiving state are recorded in `FINAL-RECEIVING.json` and `source/DIAGNOSTICS-SOURCE-PINS.json`. Targeted controls, strict conventions and closed JS 426/426 pass; macOS E2E 101/101 plus one explicit skip is parent-received. Complete portable macOS units and Linux gates remain PENDING, and future manual CI remains PENDING. Dev integration is blocked until remaining checks actually finish. This dated archive is not terminal whole-source qualification. `diagnostics-pending/` retains the earlier stable targeted 9/0 source records under its original preparation label; stable proof members are explicitly listed in FINAL-RECEIVING; changing partial native logs are excluded. Sealing ran no test and changed no product source. The native atoms retain their earlier individual gate contexts.

All logs are copied as bytes. Some native byte-probe logs are not valid UTF8; decode only for display and verify hashes against the original bytes. SHA256SUMS inventories every other regular member; the external archive receipt additionally hashes every regular member including SHA256SUMS and records the archive hash. The finished archive is reopened and every member byte-compared. Retired worktrees are already separately recoverable; no full checkout, node_modules, private download error or redundant worktree bundle belongs in this packet.

All six Group 1 items and transversal 16/38 remain partial. These component results do not close native acceptance or turn an inactive proposal into an integrated feature.
