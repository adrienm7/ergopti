from pathlib import Path
import json,hashlib,difflib,subprocess,tempfile
P=Path(__file__).resolve().parent;M=Path('/workspace/ergopti-cloud/group6-clock-workflow-owning-enrollment-proposal');R=Path('/workspace/ergopti-cloud/group6-clock-workflow-custody-review');paths=[];patch=[];inverse=[];items=[]
for owner in [M,P]:
 for file in sorted((owner/'candidate').rglob('*')):
  if not file.is_file():continue
  rel=file.relative_to(owner/'candidate').as_posix();old=(owner/'preimages'/rel).read_bytes();new=file.read_bytes()
  patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));inverse.extend(difflib.unified_diff(new.decode().splitlines(True),old.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
  items.append({'path':rel,'owner_packet':owner.name,'preimage_sha256':hashlib.sha256(old).hexdigest(),'candidate_sha256':hashlib.sha256(new).hexdigest(),'candidate_bytes':len(new)})
  paths.append((rel,old,new))
(P/'formatted-six-source.patch').write_text(''.join(patch));(P/'formatted-six-source.inverse.patch').write_text(''.join(inverse))
work=Path(tempfile.mkdtemp(prefix='whole-inverse-',dir=P));root=work/'source';root.mkdir()
for rel,old,new in paths:
 t=root/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(old)
def apply(file):subprocess.run(['git','apply','--no-index',str(file)],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
apply(P/'formatted-six-source.patch')
for rel,old,new in paths:assert (root/rel).read_bytes()==new
apply(P/'formatted-six-source.inverse.patch')
for rel,old,new in paths:assert (root/rel).read_bytes()==old
workflow_receipts=[]
for prefix in ['8d6','4260b74']:
 t=root/'.github/workflows/ci-macos.yml';t.parent.mkdir(parents=True,exist_ok=True);old=(R/(prefix+'-ci-macos.yml')).read_bytes();new=(P/(prefix+'-workflow-own.candidate.yml')).read_bytes();t.write_bytes(old)
 apply(P/(prefix+'-workflow-own.diff'));assert t.read_bytes()==new
 apply(P/(prefix+'-workflow-own.inverse.diff'));assert t.read_bytes()==old
 workflow_receipts.append({'base':prefix,'forward_inverse_byte_exact':True})
(P/'formatted-source-manifest.json').write_text(json.dumps({'qualification':'PORTABLE_RECEIVED_NATIVE_UNRUN','paths':items,'six_path_whole_forward_inverse':True,'workflow_forward_inverses':workflow_receipts,'retained_census':[156,21,32],'full_default_controls':222,'pipeline_conditional_steps':128,'source_workflow_actual_control_count':17,'expected_assertion_refusals':14},indent=2)+'\n')
print(json.dumps({'six_source_forward_inverse':True,'two_workflow_forward_inverses':True,'source_paths':len(items)}))
