'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const vm = require('node:vm');
const crypto = require('node:crypto');
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const original = fs.readFileSync(path.join(__dirname, 'preimage/tools/ci/lib/native-pac-build-source.cjs'), 'utf8');
const candidate = fs.readFileSync(path.join(__dirname, 'preimage/tools/ci/lib/native-pac-build-source.cjs'), 'utf8');
const fixtureSource = fs.readFileSync(path.join(__dirname, 'received/receive_pure.cjs'), 'utf8');
const fixtureBody = fixtureSource.slice(fixtureSource.indexOf('function fixture() {'), fixtureSource.indexOf('function loadCandidate('));
const reader = fs.readFileSync(path.join(__dirname, 'actual-g6-read-source-file.cjs'), 'utf8');
const cases = [];
function check(name, fn) { cases.push([name, fn]); }
function model(run) {
	const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'g6-strict-seam-'));
	const root = path.join(temporary, 'source');
	const runner = path.join(temporary, 'runner');
	const evidence = path.join(runner, 'windows-personal-file-caption-build-source');
	const pair = ['static/ergopti_plus/windows/vendor/ergopti_network_pac.exe', 'static/ergopti_plus/windows/vendor/ergopti_network_pac.json'];
	const context = {
		root, evidence, pair, Buffer, sha,
		license: 'static/ergopti_plus/windows/vendor/ergopti_network_pac.LICENSE.txt',
		receiverPath: path.join(root, 'tools/ci/receive-windows-personal-file-caption-build-source.ps1'),
		inputPath: path.join(root, 'tools/ci/windows-personal-file-caption-cohort-inputs.json'),
		sourceReceipt: path.join(root, 'static/ergopti_plus/windows/build/native/network_pac/prepared/source_receipt.json'),
		artifactReceipt: path.join(root, 'static/ergopti_plus/windows/build/native/network_pac/artifact_receipt.json'),
		msvcReceipt: path.join(root, 'static/ergopti_plus/windows/build/native/network_pac/msvc_function.source.ps1'),
		environment: { RUNNER_TEMP: runner, GITHUB_SHA: '0123456789abcdef0123456789abcdef01234567', GITHUB_RUN_ID: '38173146839', GITHUB_RUN_ATTEMPT: '1', GITHUB_JOB: 'test-ahk' }
	};
	vm.runInNewContext(fixtureBody, context);
	const m = context.fixture();
	for (const [file, bytes] of m.files) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, bytes); }
	const strictContext = { fs, Buffer, sha, demand(ok, message) { if (!ok) throw new Error(message); } };
	vm.runInNewContext(reader, strictContext);
	const args = { root, inputs: m.inputs, inputPath: context.inputPath, receiverPath: context.receiverPath, expectedScope: 'personal-file-caption-v7-genuine-native-pac-rebuild', sourceCount: 3262, prebuildOutcome: 'success', receiveOutcome: 'success' };
	const load = (source, fileSystem = fs) => {
		const module = { exports: {} };
		vm.runInNewContext(source, { module, Buffer, process: { env: m.env }, require(name) { if (name === 'node:fs') return fileSystem; return require(name); } });
		return module.exports;
	};
	try { run({ ...context, m, args, load, strictRead: strictContext.readSourceFile }); }
	finally { fs.rmSync(temporary, { recursive: true }); assert.equal(fs.existsSync(temporary), false); }
}
check('real ordinary files preserve original default and strict output', () => model(({ args, load, strictRead }) => {
	const a = load(original).receiveBuildSource(args);
	const b = load(candidate).receiveBuildSource(args);
	const c = load(candidate).receiveBuildSource({ ...args, readSourceFile: strictRead });
	assert.equal(JSON.stringify(a), JSON.stringify(b));
	assert.equal(JSON.stringify(a), JSON.stringify(c));
}));
check('actual hardlink admitted by ordinary reader is refused by unchanged G6 reader', () => model(({ args, load, strictRead, evidence }) => {
	fs.linkSync(path.join(evidence, 'POSTBUILD.json'), path.join(evidence, 'alias.json'));
	assert.ok(load(original).receiveBuildSource(args));
	assert.throws(() => load(candidate).receiveBuildSource({ ...args, readSourceFile: strictRead }), /Regular unaliased/);
}));
check('actual different second JSON read is not consumed after strict byte/hash acquisition', () => model(({ args, load, strictRead, evidence }) => {
	const target = path.join(evidence, 'POSTBUILD.json');
	let reads = 0;
	const replacedRead = Object.create(fs);
	replacedRead.readFileSync = (file, encoding) => {
		if (file === target && ++reads === 2) return '{}';
		return fs.readFileSync(file, encoding);
	};
	assert.throws(() => load(original, replacedRead).receiveBuildSource(args), /same-run/);
	reads = 0;
	assert.doesNotThrow(() => load(candidate, replacedRead).receiveBuildSource({ ...args, readSourceFile: strictRead }));
	assert.equal(reads, 0, 'strict JSON comes from the acquired bytes, never the ordinary second read');
}));
check('real after-acquisition alias is refused by unchanged final-held check', () => model(({ args, load, strictRead, evidence }) => {
	const target = path.join(evidence, 'POSTBUILD.json');
	const realRead = fs.readSync;
	let linked = false;
	fs.readSync = (...values) => {
		const count = realRead(...values);
		if (!linked && fs.fstatSync(values[0]).ino === fs.statSync(target).ino) { fs.linkSync(target, path.join(evidence, 'after-acquisition-alias')); linked = true; }
		return count;
	};
	try { assert.throws(() => load(candidate).receiveBuildSource({ ...args, readSourceFile: strictRead }), /changed during receiving/); assert.equal(linked, true); }
	finally { fs.readSync = realRead; }
}));
check('malformed callback bytes/hash never become proof authority', () => model(({ args, load }) => {
	assert.throws(() => load(candidate).receiveBuildSource({ ...args, readSourceFile: () => ({ bytes: Buffer.from('actual'), sha256: 'a'.repeat(64) }) }), /bytes\/hash linkage/);
}));
let failed = 0;
for (const [name, fn] of cases) { try { fn(); console.log('PASS ' + name); } catch (e) { failed++; console.error('FAIL ' + name); console.error(e.stack); } }
console.log(JSON.stringify({ selected: cases.length, passed: cases.length - failed, failed, errors: 0, skipped: 0, native: false, fixture: 'MODELED3262 protocol on actual regular POSIX files; no compiler/source native authenticity' }));
process.exitCode = failed ? 1 : 0;
