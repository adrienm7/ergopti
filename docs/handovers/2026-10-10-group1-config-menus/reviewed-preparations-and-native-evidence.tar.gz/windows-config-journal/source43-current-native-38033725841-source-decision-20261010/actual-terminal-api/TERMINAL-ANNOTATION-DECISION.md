# Terminal annotations: failure remains incomplete

Manual38033725841 / Windows job114159896889 finished **failure** at07:39:39, tested SHA `de96b36e8cb51bdd30aec54d7f556e1e21b307a6`. All17 terminal annotations are retained exactly. The API explicitly reports `AHK execution manifest incomplete (1954/10962)` and `expected one terminal footer, found0`. The notice `windows-ahk:0 passed,0 failed` cannot qualify anything. Actual raw logs/manifest are still unavailable to this agent; current passed totals, individual successes, guard32/34-store timing and the reason for termination remain **UNOBSERVED**. Do not infer a watchdog solely from elapsed time.

Two named native failures are observed:

- `tray pause: every feature row of the root is staged as a feature row (tray-pause-greys-features)` — gestures staging assertion, `test_tray_pause_greys_features.ahk:121`.
- `declared language parent: retained raw owner refusal TrayMenuSubmenuHandle` — expected1376531, actual1, `test_language_deferred_declared_parent.ahk:209`.

Minimal SOURCE receiving tasks, with no production guess:

1. Menu staging owner verifies the actual declared-feature helper's delegation to `TrayMenuStage_AddFeature`, then follows that source chain in the source-contract subject if the current direct-string assertion is obsolete. Keep all actual pause policy/native state checks.
2. Deferred-language test owner fixes a concrete self-observation: after `Publish.Call` refuses with observer Hits0, the current test queries `TrayMenuSubmenuHandle` while that exact function's `.Call` observer remains installed. The assertion itself returns1. Move existing exact descriptor restoration before the physical old-child query, keeping its expected handle and the same captured Publish repair-success assertion. No renderer production relaxation is implied. Ownership must be assigned before authoring.
3. Root acquires the actual raw/manifest via its separate whole-run transport attempt. Only then extract complete counts, guard32 and original34-store phases, and the exact termination. No repeated blob request, filter/sharding/full-suite substitution, increased22-minute budget or blocked Count/prototype change is justified here.

Native desktop cohorts, isolatedLLM, compiler warnings, full startup and fresh-clone startup were **skipped**. Missing desktop artifacts add a publication failure; they do not create a native success receipt. Pre-suite step conclusions show PAC/navigation checks, manifest parity and AHK encoding completed successfully, but do not establish whole Windows qualification. Later merged Rootf319 has a different run_all source; this prior source tree cannot qualify that complete later tree.

Previous run38019750684's10908planned/1905executed/1894passed/11failed/9003UNRUN and266-second capacity remain historical. They are not this run's totals. The9 genuine acquired-read controls and complete full-suite/native E2E/startup/package/install results remain unqualified until actual receipts establish them.
