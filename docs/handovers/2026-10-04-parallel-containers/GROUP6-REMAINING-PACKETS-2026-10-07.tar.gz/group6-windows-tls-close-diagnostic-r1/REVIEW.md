# SOURCE-only Windows TLS and shutdown audit

No main checkout, index or ref mutation; no test or product execution.

The native HRESULT is E_FAIL and does not disclose Win32Exception.NativeErrorCode. The new bounded primitive field measures that exact separate native code, without classifying or suppressing any failure. All original RSACng, IsEphemeral, CopyWithPrivateKey, AuthenticateAsServer, counters, catches, joins, assertions, clocks, capture limits and cleanup ownership remain unchanged.

Current upstream System.Net.Security/SslStreamPal.Windows.cs explicitly rejects ephemeral keys on NoCredentials (lines 299–304). dotnet/runtime#23749 maintainer comment on 2019-04-23 states the Schannel/LSASS cross-process architecture cannot marshal the ephemeral key; on 2019-08-08 the issue was closed because the Windows dependency was external, without a promised fix. PS7 alone is therefore not an evidence-based repair. Persisted PFX or a CAPI provider name would change the required ephemeral-key lifetime. A CAPI private-key context must be genuinely native-qualified before replacing the original CNG construction; no supported alternative has been established.

The updater cleanup failure is a false GracefulReceiptVerified flag, not a zero failure exit code and not an assertion inversion. Existing Close returned true and independent root removal passed. The bounded shutdown projection reports the exact already-recorded original completion and the already-read original state, and runs only when the original graceful receipt fails. It adds no native call, read, timer or control-flow success path. Existing Publish-State can overwrite a cleanup diagnostic with the first TLS failure; this projection retains state/cleanup boolean shape independently and never raw child output.

Root validation still required: authentic PowerShell/C# compilation helper, original registered AHK controls (8 native-status and 14 shutdown-shape assertions), repository encoding gate, selected verify-change and genuine workflow_dispatch Windows CI. This packet contains no claim of functional repair or qualified native acceptance.
