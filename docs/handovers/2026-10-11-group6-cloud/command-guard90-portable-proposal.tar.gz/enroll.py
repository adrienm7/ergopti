"""Compose additive controls without replacing any original helper/test body."""
from pathlib import Path
import ast
import hashlib

P = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')
REL = 'tools/test/macos_native_http_receiving_facts_test.py'
source = (ROOT / REL).read_bytes()
assert hashlib.sha256(source).hexdigest() == '6a6f93dbd7ce8a2aea3d2a9d5632e17668f98ecb30f34647780e026a7832203b'
for role in ('preimage', 'candidate'):
    dest = P / role / REL
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(source)
control = (P / 'portable_guard_tests.py').read_text()
start = control.index('class ProtocolModel:')
end = control.index('\n\nif __name__', start)
block = control[start:end]
for before, after in [('ProtocolModel', 'NativeCommandGuardProtocolModel'),
                      ('actual_main_handlers', 'native_guard_actual_main_handlers'),
                      ('GuardControls', 'NativeCommandGuardTests'),
                      ('W.', 'WIRE.'), ('QUERY', 'NATIVE_GUARD_QUERY'),
                      ('FACT', 'NATIVE_GUARD_FACT'), ('CLEANUP', 'NATIVE_GUARD_CLEANUP')]:
    block = block.replace(before, after)
block = block.replace('mock.patch.object(W,', 'mock.patch.object(WIRE,')
block = block.replace('self.fixture.command_group_debt, []', 'getattr(self.fixture, "command_group_debt", []), []')
block = block.replace('        lines = SOURCE.read_text().splitlines()',
                      '        source = Path(WIRE.__file__).resolve()\n        lines = source.read_text().splitlines()')
block = block.replace('frame.f_code.co_filename == str(SOURCE)', 'frame.f_code.co_filename == str(source)')
# Receiving must observe actual root/child facts before any outer cleanup.
block = block.replace('        try:\n            if not self.close_called', '''        before_outer = {
            "fixture_closed_before_outer_cleanup": self.fixture.closed,
            "root_exists_before_outer_cleanup": self.root.exists(),
            "child_live_before_outer_cleanup": [] if self.model is None else [
                owner.process.poll() is None for owner in self.model.children
            ],
            "retained_owner_count_before_outer_cleanup": len(
                getattr(self.fixture, "command_group_debt", ())
            ),
        }
        try:
            if not self.close_called''', 1)
block = block.replace('                    "test": self.id(),', '                    "test": self.id(),\n                    **before_outer,', 1)
# Root counterexample is received before the independent admission assertion.
a = block.index('    def test_unsettled_actual_child_retains_root_and_refuses_new_capture(self):')
b = block.index('    def test_postinstall_query_retains_actual_child_root_and_original_primary(self):', a)
case = block[a:b]
case = case.replace('        self.assert_owner_debt(owner)\n', '', 1)
case = case.replace('        with mock.patch.object(\n            WIRE.tempfile,', '        self.close_refuses()\n        self.assertIsNone(owner.process.poll())\n        self.assert_owner_debt(owner)\n        with mock.patch.object(\n            WIRE.tempfile,', 1)
case = case.replace('        self.close_refuses()\n        self.assertIsNone(owner.process.poll())\n        self.assert_owner_debt(owner)\n\n', '\n', 1)
# The replacement above targets the trailing occurrence only (the first is followed by with).
assert case.count('self.close_refuses()') == 1
block = block[:a] + case + block[b:]
a = block.index('    def test_postinstall_query_retains_actual_child_root_and_original_primary(self):')
b = block.index('    def test_partial_registration_failure_retains_exact_owner_and_primary(self):', a)
case = block[a:b].replace('        self.assert_owner_debt(owner)\n', '', 1)
block = block[:a] + case + block[b:]
header = '''# Actual POSIX child ownership and actual existing main-handler signals.
# Native settlement acknowledgements and Security command bodies are explicitly
# modeled; these controls do not qualify Darwin or change system trust.
NATIVE_GUARD_QUERY = "EXPLICIT-PORTABLE-QUERY-IMAGE-NOT-NATIVE"
NATIVE_GUARD_FACT = {"version": 1, "export_status": 0, "entry_count": 1,
                     "owned_status": 0, "owned_present": 1}
NATIVE_GUARD_CLEANUP = []


'''
text = source.decode()
text = text.replace('import hashlib\n', 'import hashlib\nimport builtins\nimport shutil\nimport signal\n', 1)
text = text.replace('\n\nif __name__ == "__main__":', '\n\n' + header + block + '\n\nif __name__ == "__main__":', 1)
(P / 'candidate' / REL).write_text(text)
# The existing strict registry admits the enlarged owning suite, with no other edit.
for rel in ('tools/test/test-managed-ollama-protocol.cjs',):
    before = (ROOT / rel).read_bytes()
    for role in ('preimage', 'candidate'):
        dest = P / role / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(before)
    old = "cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 72]);"
    new = "cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 90]);"
    assert before.decode().count(old) == 1
    (P / 'candidate' / rel).write_text(before.decode().replace(old, new, 1))
print(P)
