﻿; Private actual native printable/Unicode encoding observation; no production edits.
_R6Encoding_Native(Scalars, Id) {
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	Db := 0
	try {
		OutputDir := EnvGet("ERGOPTI_R6_ENCODING_DIR")
		AssertTrue(OutputDir != "" && DirExist(OutputDir))
		KLW.ctx := Map()
		KLW_ResetBatch()
		Events := []
		for Scalar in Scalars
			Events.Push([Scalar, 100, Map("st", "none")])
		KLW_WalkTypingEntry(Map("timestamp", "2026-10-26 12:00:00.000",
			"app", "encoding-probe.exe", "events", Events))
		App := KLW.batch["app_day"]["2026-10-26" . Chr(1) . "encoding-probe.exe"]
		AssertEqual(Scalars.Length, App["chars"], "the native input contains this many independent events")
		Manifest := Map("2026-10-26", Map("encoding-probe.exe", Map("chars", App["chars"], "time", App["time_ms"])))
		Db := _KLRShortcut_OpenFixture()
		AssertTrue(SQLite_Exec(Db, KLW_BuildBatchSql(SQLite_Q("unicode-encoding"), false)))
		Historical := KLR_BuildNgramsJson(Db, "2026-10-26", "2026-10-26", ["encoding-probe.exe"])
		Decoded := JsonParse(Historical)
		AssertEqual(Scalars.Length, Decoded["c"].Count)
		for Scalar in Scalars {
			AssertTrue(Decoded["c"].Has(Scalar), "the native reader must retain every original Unicode scalar")
			AssertEqual(1, Decoded["c"][Scalar]["c"])
		}
		AssertEqual(Max(0, Scalars.Length - 1), Decoded["bg"].Count)
		if Scalars.Length >= 2 {
			Pair := Scalars[1] . Scalars[2]
			AssertTrue(Decoded["bg"].Has(Pair), "native printable events retain their exact encoded pair")
			AssertEqual(1, Decoded["bg"][Pair]["c"])
		}
		AssertEqual(Max(0, Scalars.Length - 2), Decoded["tg"].Count)
		if Scalars.Length == 3 {
			Triple := Scalars[1] . Scalars[2] . Scalars[3]
			AssertTrue(Decoded["tg"].Has(Triple))
			AssertEqual(1, Decoded["tg"][Triple]["c"])
		}
		FileAppend('{"id":' . JsonStringLiteral(Id) . ',"events":' . KL_JsonEncode(Scalars)
			. ',"manifest":' . KL_JsonEncode(Manifest) . ',"range":{"historical":'
			. Historical . ',"today":{}}}', OutputDir . "\" . Id . ".json", "UTF-8-RAW")
		FileAppend("NATIVE_LITERAL_UNICODE " . Id . " chars=" . App["chars"]
			. " native_bg=" . Decoded["bg"].Count . " native_tg=" . Decoded["tg"].Count . "`n", "*")
	} finally {
		if Db
			SQLite_Close(Db)
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
	}
}
for Spec in [
	Map("id", "nbsp-only", "scalars", [Chr(0xA0)]),
	Map("id", "nnbsp-only", "scalars", [Chr(0x202F)]),
	Map("id", "ordinary-nbsp", "scalars", ["a", Chr(0xA0), "b"]),
	Map("id", "literal-capital-a-nbsp", "scalars", ["Â", Chr(0xA0)]),
	Map("id", "literal-c1-sequence", "scalars", ["â", Chr(0x80), "¯"])
]
	Test("audit: native Unicode encoding " . Spec["id"] . " (r6-native-literal-unicode)",
		_R6Encoding_Native.Bind(Spec["scalars"], Spec["id"]))
