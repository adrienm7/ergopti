from pathlib import Path
import importlib.util,os,tempfile,json
root=Path('/workspace/ergopti-macos-native-validation');p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('cases',root/'tools/diagnostics/keystats_startup_replay_test.py');cases=importlib.util.module_from_spec(spec);spec.loader.exec_module(cases)
test=cases.StartupReplayTests();receipts={}
for mode in ['read','sql','schedule','publication','id_publication','durability']:
 with tempfile.TemporaryDirectory(prefix='ergopti-f896-proof-') as temporary:
  test.seed(temporary)
  os.environ.update(HOME=temporary,ERGOPTI_STARTUP_REPLAY_MODE='fault_'+mode,ERGOPTI_PHYSICAL_SOURCE_ROOT=str(root))
  receipt=cases.BRIDGE.run_fixture('/workspace/toolchain/bin/lua',temporary,p/'upstream-public-init.lua')
  receipts[mode]=receipt
(p/'upstream-f896-findings.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2))
