"""Real POSIX children/signals; native settlement and Security are explicitly modeled."""

import argparse
import builtins
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import unittest
from unittest import mock

P = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--source", choices=("candidate", "preimage", "frozen"), default="candidate")
options, selected = parser.parse_known_args()
REL = "static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py"
SOURCE = P / ("frozen_guard.py" if options.source == "frozen" else options.source + "/" + REL)
spec = importlib.util.spec_from_file_location("isolated_command_guard", SOURCE)
W = importlib.util.module_from_spec(spec)
spec.loader.exec_module(W)
QUERY = "EXPLICIT-PORTABLE-QUERY-IMAGE-NOT-NATIVE"
FACT = {"version": 1, "export_status": 0, "entry_count": 1, "owned_status": 0, "owned_present": 1}
CLEANUP = []


class ProtocolModel:
    """No native executable runs; exact Popen handles retire every actual child."""

    def __init__(
        self,
        ack=True,
        primary=None,
        partial=False,
        refuse=False,
        postinstall=False,
        add_status=0,
        uncertain_capture=False,
    ):
        self.ack = ack
        self.primary = primary
        self.partial = partial
        self.refuse = refuse
        self.postinstall = postinstall
        self.add_status = add_status
        self.uncertain_capture = uncertain_capture
        self.children = []
        self.arguments = []
        self.queries = 0

    def acquire_owned(self, arguments, native, register, **options):
        self.arguments.append(arguments)
        if self.refuse:
            raise self.primary
        query = arguments == [QUERY, "--fixture-admin-trust-query"]
        if query:
            self.queries += 1
        unsettled = self.ack is False or self.postinstall and query and self.queries == 1
        body = "import time; time.sleep(60)" if unsettled else "import sys; sys.stdin.buffer.read()"
        if query and not unsettled:
            body += "; import json; sys.stdout.write(json.dumps(" + repr(FACT) + "))"
        if arguments[:3] == ["/usr/bin/sudo", "-n", "/usr/bin/security"]:
            assert arguments[3] in ("add-trusted-cert", "remove-trusted-cert")
            if arguments[3] == "add-trusted-cert":
                body += "; sys.exit(" + str(self.add_status) + ")"
        process = subprocess.Popen(
            [sys.executable, "-I", "-B", "-c", body], start_new_session=True, **options
        )
        process.output_capture = options["stdout"]
        process.error_capture = options["stderr"]
        if self.uncertain_capture:
            stream = process.stdin

            class UncertainClose:
                def __getattr__(self, name):
                    return getattr(stream, name)

                def close(self):
                    stream.close()
                    raise OSError("EXPLICIT physical descriptor closed but ACK refused")

            process.stdin = UncertainClose()
        model = self

        class Owner:
            reaped = False

            def __init__(self):
                self.process = process
                self.settle_calls = 0

            def wait_for_exit(self, timeout):
                if unsettled:
                    if model.primary is None:
                        model.primary = subprocess.TimeoutExpired(
                            "EXPLICIT modeled owned wait", timeout
                        )
                    raise model.primary
                process.wait(timeout=timeout)

            def settle(self):
                self.settle_calls += 1
                ack = False if unsettled else model.ack
                if isinstance(ack, BaseException):
                    raise ack
                if ack is True:
                    if process.poll() is None:
                        process.terminate()
                    process.wait(timeout=5)
                    self.reaped = True
                return ack

        owner = Owner()
        self.children.append(owner)
        register(owner)
        if self.partial:
            raise self.primary
        return owner


def actual_main_handlers():
    previous = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM)}
    captured = {}

    class Stop(Exception):
        pass

    def stop(*args, **kwargs):
        captured.update({sig: signal.getsignal(sig) for sig in previous})
        raise Stop()

    try:
        with (
            mock.patch.object(W, "WireFixture", side_effect=stop),
            contextlib.redirect_stdout(io.StringIO()),
        ):
            try:
                W.main()
            except Stop:
                pass
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    assert len(captured) == 2 and all(callable(value) for value in captured.values())
    return captured


class GuardControls(unittest.TestCase):
    def setUp(self):
        self.out, self.err = io.StringIO(), io.StringIO()
        self.stdout = contextlib.redirect_stdout(self.out)
        self.stderr = contextlib.redirect_stderr(self.err)
        self.stdout.__enter__()
        self.stderr.__enter__()
        self.fixture = W.WireFixture(native=False)
        self.root = self.fixture.root
        self.model = None
        self.close_called = False

    def activate(self, **options):
        self.model = ProtocolModel(**options)
        self.fixture.native = True
        self.fixture.groups = self.model
        self.fixture.native_groups = object()
        self.fixture.trust_query_executable = QUERY
        return self.model

    def close_refuses(self):
        self.close_called = True
        with self.assertRaisesRegex(W.FixtureFailure, "^Owned native fixture restoration refused$"):
            self.fixture.close()
        self.assertFalse(self.fixture.closed)
        self.assertTrue(self.root.is_dir())

    def assert_owner_debt(self, owner):
        self.assertEqual(len(self.fixture.command_group_debt), 1)
        self.assertIs(self.fixture.command_group_debt[0], owner)
        self.assertEqual(owner.settle_calls, 1)

    def tearDown(self):
        try:
            if not self.close_called and not self.fixture.closed:
                try:
                    self.fixture.close()
                except W.FixtureFailure:
                    pass
            children = [] if self.model is None else self.model.children
            for owner in children:
                process = owner.process
                if process.poll() is None:
                    process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
                if process.stdin is not None and not process.stdin.closed:
                    process.stdin.close()
                for capture in (process.output_capture, process.error_capture):
                    if not capture.closed:
                        capture.close()
            assert all(owner.process.returncode is not None for owner in children)
            # Outer private test owner removes only after exact real child reaps.
            # This does not pay the modeled native ACK debt or clear its record.
            if self.root.exists():
                self.fixture._retire_servers()
                if hasattr(self.fixture, "refused"):
                    self.fixture.refused.close()
                shutil.rmtree(self.root)
            CLEANUP.append(
                {
                    "test": self.id(),
                    "actual_children": len(children),
                    "all_exact_outer_children_reaped": True,
                    "settle_calls": [owner.settle_calls for owner in children],
                }
            )
        finally:
            self.stderr.__exit__(None, None, None)
            self.stdout.__exit__(None, None, None)

    def test_unsettled_actual_child_retains_root_and_refuses_new_capture(self):
        model = self.activate(ack=False)
        with self.assertRaises(subprocess.TimeoutExpired) as caught:
            self.fixture._command(["EXPLICIT-MODELED-COMMAND"])
        self.assertIs(caught.exception, model.primary)
        owner = model.children[0]
        self.assert_owner_debt(owner)
        self.assertIsNone(owner.process.poll())
        self.assertEqual(self.fixture.command_file_debt, [])
        with mock.patch.object(
            W.tempfile, "TemporaryFile", side_effect=AssertionError("capture must not be acquired")
        ):
            with self.assertRaisesRegex(
                W.FixtureFailure, "^Native fixture child closure debt remains$"
            ):
                self.fixture._command(["SECOND-MUST-NOT-ACQUIRE"])
        self.assertEqual(len(model.arguments), 1)
        self.close_refuses()
        self.assertIsNone(owner.process.poll())
        self.assert_owner_debt(owner)

    def test_postinstall_query_retains_actual_child_root_and_original_primary(self):
        model = self.activate(postinstall=True)
        with self.assertRaises(subprocess.TimeoutExpired) as caught:
            self.fixture.trust(True)
        self.assertIs(caught.exception, model.primary)
        self.assertEqual(model.queries, 1)
        self.assertTrue(self.fixture.trust_attempted)
        owner = model.children[-1]
        self.assert_owner_debt(owner)
        self.assertIsNone(owner.process.poll())
        self.fixture.keychain_created = True
        self.fixture.foreign_keychains = []
        with (
            mock.patch.object(self.fixture, "_command", wraps=self.fixture._command) as attempts,
            mock.patch.object(self.fixture, "trust", wraps=self.fixture.trust) as trust_cleanup,
        ):
            self.close_refuses()
        trust_cleanup.assert_called_once_with(False)
        arguments = [call.args[0] for call in attempts.call_args_list]
        self.assertIn([QUERY, "--fixture-admin-trust-query"], arguments)
        self.assertTrue(any("delete-keychain" in argument for argument in arguments))
        self.assertEqual(model.queries, 1)
        self.assertEqual(len(model.arguments), 2)
        self.assertTrue(self.fixture.trust_attempted)
        self.assertTrue(self.fixture.keychain_created)
        self.assertIsNone(owner.process.poll())
        self.assert_owner_debt(owner)

    def test_partial_registration_failure_retains_exact_owner_and_primary(self):
        primary = RuntimeError("EXACT partial registration primary")
        model = self.activate(ack=False, partial=True, primary=primary)
        with self.assertRaises(RuntimeError) as caught:
            self.fixture._command(["EXPLICIT-PARTIAL-REGISTRATION"])
        self.assertIs(caught.exception, primary)
        self.assert_owner_debt(model.children[0])
        self.close_refuses()

    def test_refusal_before_registration_fabricates_no_owner_debt(self):
        primary = RuntimeError("EXACT acquisition refusal")
        model = self.activate(refuse=True, primary=primary)
        with self.assertRaises(RuntimeError) as caught:
            self.fixture._command(["EXPLICIT-ACQUISITION-REFUSAL"])
        self.assertIs(caught.exception, primary)
        self.assertEqual(model.children, [])
        self.assertEqual(self.fixture.command_group_debt, [])
        self.fixture.close()
        self.assertTrue(self.fixture.closed)
        self.assertFalse(self.root.exists())

    def test_none_ack_refuses(self):
        model = self.activate(ack=None)
        with self.assertRaisesRegex(W.FixtureFailure, "^Native fixture child closure refused$"):
            self.fixture._command(["EXPLICIT-UNKNOWN-NONE-ACK"])
        self.assert_owner_debt(model.children[0])
        self.close_refuses()

    def test_truthy_string_ack_refuses(self):
        model = self.activate(ack="unknown")
        with self.assertRaisesRegex(W.FixtureFailure, "^Native fixture child closure refused$"):
            self.fixture._command(["EXPLICIT-UNKNOWN-STRING-ACK"])
        self.assert_owner_debt(model.children[0])
        self.close_refuses()

    def test_truthy_integer_ack_refuses(self):
        model = self.activate(ack=1)
        with self.assertRaisesRegex(W.FixtureFailure, "^Native fixture child closure refused$"):
            self.fixture._command(["EXPLICIT-UNKNOWN-INTEGER-ACK"])
        self.assert_owner_debt(model.children[0])
        self.close_refuses()

    def test_settle_exception_preserves_original_wait_primary_and_owner(self):
        primary = RuntimeError("EXACT original wait primary")
        model = self.activate(ack=False, primary=primary)

        def refuse():
            owner.settle_calls += 1
            raise OSError("EXACT settlement refusal")

        original_acquire = model.acquire_owned

        def acquire(*args, **kwargs):
            nonlocal owner
            value = original_acquire(*args, **kwargs)
            owner = value
            owner.settle = refuse
            return value

        owner = None
        model.acquire_owned = acquire
        with self.assertRaises(RuntimeError) as caught:
            self.fixture._command(["EXPLICIT-WAIT-AND-SETTLE-REFUSAL"])
        self.assertIs(caught.exception, primary)
        self.assert_owner_debt(owner)
        self.close_refuses()

    def test_ordinary_success_strong_ack_leaves_no_group_debt(self):
        model = self.activate()
        self.assertEqual(
            self.fixture._command(["EXPLICIT-SUCCESS"], input_bytes=b"owned input"), (0, b"")
        )
        self.assertEqual(self.fixture.command_group_debt, [])
        self.assertEqual(self.fixture.command_file_debt, [])
        self.assertEqual(model.children[0].settle_calls, 1)
        self.assertIsNotNone(model.children[0].process.returncode)
        self.fixture.close()
        self.assertTrue(self.fixture.closed)
        self.assertFalse(self.root.exists())

    def test_strong_child_ack_does_not_pay_distinct_capture_debt(self):
        model = self.activate(uncertain_capture=True)
        with self.assertRaisesRegex(OSError, "physical descriptor closed"):
            self.fixture._command(["EXPLICIT-CAPTURE-DEBT"])
        self.assertEqual(self.fixture.command_group_debt, [])
        self.assertEqual(len(self.fixture.command_file_debt), 1)
        self.assertTrue(self.fixture.command_file_debt[0]["uncertain"])
        self.assertTrue(self.fixture.command_file_debt[0]["stream"].closed)
        self.assertEqual(model.children[0].settle_calls, 1)
        self.close_refuses()
        self.assertEqual(len(self.fixture.command_file_debt), 1)

    def registration_signal(self, sig):
        model = self.activate(ack=False)
        handlers = actual_main_handlers()
        previous = signal.signal(sig, handlers[sig])
        fired = []
        lines = SOURCE.read_text().splitlines()

        def trace(frame, event, arg):
            if (
                event == "line"
                and frame.f_code.co_filename == str(SOURCE)
                and frame.f_code.co_name == "register"
                and lines[frame.f_lineno - 1].strip() == "self.command_group_debt.append(value)"
                and not fired
            ):
                fired.append(True)
                os.kill(os.getpid(), sig)
            return trace

        previous_trace = sys.gettrace()
        try:
            sys.settrace(trace)
            with self.assertRaisesRegex(W.FixtureFailure, "^Native fixture cancelled$"):
                self.fixture._command(["EXPLICIT-REGISTRATION-SIGNAL"])
        finally:
            sys.settrace(previous_trace)
            signal.signal(sig, previous)
        self.assertEqual(fired, [True])
        self.assert_owner_debt(model.children[0])
        self.close_refuses()
        self.assertIsNone(model.children[0].process.poll())

    def test_real_sigint_before_registration_persistence_retains_owner(self):
        self.registration_signal(signal.SIGINT)

    def test_real_sigterm_before_registration_persistence_retains_owner(self):
        self.registration_signal(signal.SIGTERM)

    def publication(self, primary, kind):
        model = self.activate(add_status=7 if primary else 0)
        handlers = actual_main_handlers()
        previous = None if kind == "technical" else signal.signal(kind, handlers[kind])
        real_print = print
        events = []

        def publish(*args, **kwargs):
            if (
                len(args) == 1
                and isinstance(args[0], str)
                and args[0].startswith("# native_http_trust_outcome ")
            ):
                fact = json.loads(args[0].removeprefix("# native_http_trust_outcome "))
                if fact["operation"] == "add":
                    child = model.children[-1].process
                    self.assertEqual(child.returncode, 7 if primary else 0)
                    self.assertTrue(
                        child.stdin.closed
                        and child.output_capture.closed
                        and child.error_capture.closed
                    )
                    self.assertEqual(self.fixture.command_group_debt, [])
                    events.append("exact original child and captures closed before sink")
                    if kind == "technical":
                        raise RuntimeError("EXPLICIT optional technical publication refusal")
                    os.kill(os.getpid(), kind)
            return real_print(*args, **kwargs)

        caught = None
        try:
            with mock.patch.object(builtins, "print", side_effect=publish):
                try:
                    self.fixture.trust(True)
                except BaseException as failure:
                    caught = failure
        finally:
            if previous is not None:
                signal.signal(kind, previous)
        self.assertEqual(events, ["exact original child and captures closed before sink"])
        if primary:
            self.assertIs(type(caught), W.FixtureFailure)
            self.assertEqual(caught.args, ("Native fixture command refused",))
            self.assertEqual(model.queries, 0)
        elif kind == "technical":
            self.assertIsNone(caught)
            self.assertEqual(model.queries, 1)
        else:
            self.assertIs(type(caught), W.FixtureFailure)
            self.assertEqual(caught.args, ("Native fixture cancelled",))
            self.assertEqual(model.queries, 0)

    def test_real_sigint_at_success_publication_propagates_before_query(self):
        self.publication(False, signal.SIGINT)

    def test_real_sigterm_at_success_publication_propagates_before_query(self):
        self.publication(False, signal.SIGTERM)

    def test_original_primary_dominates_sigint_at_publication(self):
        self.publication(True, signal.SIGINT)

    def test_original_primary_dominates_sigterm_at_publication(self):
        self.publication(True, signal.SIGTERM)

    def test_success_technical_publication_refusal_remains_optional(self):
        self.publication(False, "technical")

    def test_original_primary_dominates_technical_publication_refusal(self):
        self.publication(True, "technical")


if __name__ == "__main__":
    suite = (
        unittest.defaultTestLoader.loadTestsFromNames(selected, module=sys.modules[__name__])
        if selected
        else unittest.defaultTestLoader.loadTestsFromTestCase(GuardControls)
    )
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print(
        json.dumps(
            {
                "qualification": "REAL_POSIX_CHILDREN_AND_REAL_MAIN_SIGNALS_MODELED_NATIVE_SECURITY_ONLY",
                "source_role": options.source,
                "tests": result.testsRun,
                "failures": len(result.failures),
                "errors": len(result.errors),
                "skips": len(result.skipped),
                "cleanup": CLEANUP,
            },
            sort_keys=True,
        )
    )
    sys.exit(0 if result.wasSuccessful() else 1)
