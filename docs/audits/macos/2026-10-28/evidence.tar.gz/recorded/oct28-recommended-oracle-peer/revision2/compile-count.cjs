const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const realThrows=assert.throws,calls=[];
assert.throws=(...args)=>{calls.push(args[2]);return realThrows(...args);};
try{const m=new Module(process.argv[2]);m.filename=process.argv[2];m.paths=Module._nodeModulePaths(path.dirname(m.filename));m._compile(fs.readFileSync(process.argv[3],'utf8'),m.filename);assert.equal(calls.length,22);}finally{assert.throws=realThrows;console.log(JSON.stringify({negative_calls:calls}));}
