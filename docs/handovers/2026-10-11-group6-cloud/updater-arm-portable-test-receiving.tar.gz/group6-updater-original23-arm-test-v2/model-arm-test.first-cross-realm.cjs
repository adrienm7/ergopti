'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createRequire } = require('node:module');
const file = path.join(__dirname, 'physical-source/tools/test/test-windows-updater-original-source.cjs');
const context = {
 require: createRequire(file), __dirname: path.dirname(file),
 process: {...process, arch: 'arm64'}, Error, Buffer, console, setTimeout, clearTimeout
};
vm.runInNewContext(fs.readFileSync(file, 'utf8'), context, {filename:file});
process.on('beforeExit', () => { process.exitCode = context.process.exitCode || 0; });
