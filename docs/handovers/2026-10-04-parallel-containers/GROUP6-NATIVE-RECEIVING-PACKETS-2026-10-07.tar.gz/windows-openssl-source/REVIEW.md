# Native in-memory OpenSSL fixture server candidate

Status: SOURCE-ONLY_UNEXECUTED. No main checkout/index/ref mutation, no native library load, no C# compilation and no test/product execution by this agent.

## Scope

Only the fixture SERVER changes. Production curl Schannel and updater .NET clients, Windows CurrentUser public-root admission/removal, exact root identity, CRL, PAC/CONNECT listeners, TLS1.2, payload handlers, counters, original clocks, 5000 ms socket timeouts, thread ledger/3000 ms joins, owned ShellRunner Jobs and all 108 original receiving assertion call sites remain intact. SOURCE-PRESERVATION.json records complete byte-exact original AHK assertion calls and inverse reconstruction. The updater file remains byte-exact unchanged. Eleven additional managed-remote assertion call sites establish provider/key/closure receipt invariants.

The broken ephemeral Schannel server boundary is replaced by actual OpenSSL3 with input/output memory BIOs over the original actual TcpClient NetworkStream. RootKey and leafKey remain the original RSACng(2048), with both original IsEphemeral assertions and CopyWithPrivateKey/certificate generation unchanged. The leaf key is exported only through Framework-compatible CngKey.Export(CngKeyBlobFormat.Pkcs8PrivateBlob), pinned for DER import and cleared/observed zero in finally. There are no PFX/PEM/PKCS8 files, persisted private keys, new native production application dependencies, mocked TLS methods or success receipts from failed native calls.

## Native provider ownership

Only the verified hosted-image Git-for-Windows native mingw64 pair is admitted at ProgramFiles/Git/mingw64/bin. Missing/custom installations refuse this fixture prerequisite rather than switching to another provider. Official image installation checks the Git installer release SHA256; supporting source proof is /tmp/group6-windows-openssl-feasibility-r1/FEASIBILITY.md and its bound source archive. Do not treat filenames, individual hashes, pure metadata controls or compilation as actual native qualification.

ImageFence holds readonly FileStreams with FileShare.Read (no write/delete) before each native load. PE headers must identify AMD64 PE32+ DLLs; imports are recursively fenced from the same trusted native Git directory, or constrained to Windows System32/API sets. MSYS imports and unsafe import names refuse admission. Image SHA256, exact loaded module paths and dependencies are checked, with source hashes checked again after context initialization and immediately before/after owned module-reference retirement. Only absolute LoadLibraryEx DLL_LOAD_DIR | SYSTEM32 is used; no global DLL-search-path mutation, wildcard provider or PATH DLL search.

Both explicit loader references are retained independently of any prior matching module references; only the fixture's own references are released. Every returned module/dependency path must match the fenced provider/System32 identity. The actual OpenSSL version major and version number must be 3.x, and all required exports must bind. SSL_CTX/BIO control long arguments and returns use Windows LLP64 Int32; native pointers use IntPtr. OPENSSL_init_ssl(NO_LOAD_CONFIG) avoids ambient OpenSSL configuration before context creation.

## TLS and retirement correctness

SSL_CTX_use_certificate_ASN1 imports original leaf DER; SSL_CTX_use_PrivateKey_ASN1 imports original CNG PKCS8 through OpenSSL3's DER decoder. SSL_CTX_check_private_key and both TLS1.2 min/max controls must acknowledge before ready. Certificate/server-policy errors, invalid provider/ABI/export or unexpected native TLS errors stay failed fixture service outcomes.

SSL_get_error is taken on the same worker immediately after each failing SSL operation, before any other OpenSSL call. The thread error queue is cleared immediately before the operation. Actual peer certificate alerts 1042/1044/1045/1046/1048 from SSL library 20 are accepted only in the original untrusted phases; a trusted-phase alert remains an unexpected native service error. WANT_WRITE requires actual encrypted-output progress, and every protocol retry loop is count-bounded without changing any deadline. Network EOF/IOException retain the original expected physical peer-close path. No arbitrary Win32 catch or updater connect-to-tls relabel is introduced.

SSL_set_bio transfers both BIO references to SSL exactly once. The constructor has an explicit transferred-ownership flag, so failure after that point frees only SSL. Each Stream disposal frees SSL and its BIOs, disposes its original NetworkStream and acknowledges its connection ledger even when socket disposal throws. An authenticated connection sends close_notify once and never waits for a peer at retirement; unexpected native shutdown errors remain visible, and resources still free in finally. All old worker joins precede context destruction. Active connections or changed provider sources refuse owner disposal and preserve their owner until the original process/Job physically closes.

Native context closure precedes the two exact loader-reference releases, source-fence closure and original certificate/CNG-key disposal. Native receipt fields record the two hashes, actual version, actual ephemeral key, observed DER clearing, source-fence identity and actual owned module/stream/fence counts. Existing graceful receipt qualification gains closing assertions. Its flag is temporarily false while those assertions run, so the enclosing original catch cannot hide a failed new closure assertion by leaving the flag true.

## Root validation plan

- Compile the entire actual candidate Add-Type block using genuine PowerShell; no native Windows backend execution credit on Linux.
- PORTABLE-CONTROLS.ps1 invokes actual compiled pure helpers for 29 independently specified expectations: five certificate-alert constants in both trust phases, four non-certificate errors, DER clearing including absent/oversized refusal, literal PE metadata, and nine wrong-ABI/MSYS/path/header/import mutants. It explicitly prints native_tls_acceptance=UNRUN. These controls are authored and UNEXECUTED.
- Verify original full C# fixture source outside the listed substitutions remains byte-exact by TARGETS.json inverse; verify all original assertions, clocks and artifact/certificate ownership. Keep original failure evidence.
- Run the repository BOM/LF gate and selected verify-change sequentially with native suites, then workflow_dispatch Windows CI at the exact candidate SHA. Original native unit assertions must prove real trust admission/removal, generation/readiness and CRL/PAC/CONNECT behavior, full updater staging/integrity/refusals/live partial stage/cancellation/deadline, and exact graceful/independent cleanup.
- Native CI must observe the actual provider pair hashes/PE/import/export/version and closure receipts. Units alone do not replace E2E/package/installation. No native-success claim until those real outcomes are available.

Source-supported feasibility is stronger than a diagnostic-only packet, but this candidate is not yet compiled or natively qualified. Any provider, TLS alert or loader dependency incompatibility must fail the existing native acceptance and be corrected without changing expectations.
