const fs=require('node:fs');
const original=fs.readFileSync;
const source='/workspace/ergopti-macos-receipt-writer/static/ergopti_plus/macos/apps/App Cloner.app/Contents/Resources/reserve_bundle.sh';
fs.readFileSync=function(file, options){
 const value=original.call(this,file,options);
 if(file!==source)return value;
 const text=Buffer.isBuffer(value)?value.toString('utf8'):value;
 const mutated=text.replace('/bin/cat <<ERGOPTI_BUNDLE_RECEIPT','/bin/cat <<ERGOPTI_BUNDLE_RECEIPT || :');
 if(mutated===text)throw new Error('The status-masking mutation must apply');
 return Buffer.isBuffer(value)?Buffer.from(mutated):mutated;
};
