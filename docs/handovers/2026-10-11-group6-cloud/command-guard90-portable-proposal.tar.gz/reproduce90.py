from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time

P = Path(__file__).resolve().parent
TMP = Path(tempfile.mkdtemp(prefix='g6-command-guard90-tmp-', dir='/tmp'))
TMP.chmod(0o700)
facts = []
for name, role, expected in [('canonical72-red4', 'preimage', 1), ('owning90', 'candidate', 0)]:
    before = time.monotonic()
    result = subprocess.run([sys.executable, '-I', '-B', str(P / 'receive90.py'), role],
                            cwd=P, env={**os.environ, 'TMPDIR': str(TMP)}, capture_output=True, timeout=90)
    (P / (name + '.stdout')).write_bytes(result.stdout)
    (P / (name + '.stderr')).write_bytes(result.stderr)
    fact = {'cohort': name, 'returncode': result.returncode, 'expected_returncode': expected,
            'elapsed_seconds': round(time.monotonic() - before, 3),
            'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
            'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    facts.append(fact)
    print(json.dumps(fact), flush=True)
    if result.returncode != expected:
        break
(P / 'owning90-receiving.json').write_text(json.dumps({'qualification': 'REAL_POSIX_ONLY_NATIVE_SECURITY_MODELED_NO_ADOPTION', 'private_tmp': str(TMP), 'cohorts': facts}, indent=2) + '\n')
assert len(facts) == 2
assert all(fact['returncode'] == fact['expected_returncode'] for fact in facts)
