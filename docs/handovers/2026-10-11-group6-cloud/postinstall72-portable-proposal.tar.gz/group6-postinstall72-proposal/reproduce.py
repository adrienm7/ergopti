"""Replay bounded corrected postinstall72 without changing the checkout."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,sys
parser=argparse.ArgumentParser()
parser.add_argument('repository',type=Path)
parser.add_argument('--ruff',default='ruff')
options=parser.parse_args()
root=options.repository.resolve()
packet=Path(__file__).resolve().parent
manifest=json.loads((packet/'manifest.json').read_text())
for name,binding in manifest['files'].items():
 for role in ('preimage','frozen','candidate'):
  assert hashlib.sha256((packet/role/name).read_bytes()).hexdigest()==binding[role]
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==binding['preimage'],('Live source changed; rebase/review exact preimages',name)
registry=json.loads((packet/'registry-activation/manifest.json').read_text())
for role in ('preimage','candidate'):
 assert hashlib.sha256((packet/'registry-activation'/role/registry['path']).read_bytes()).hexdigest()==registry[role+'_sha256']
assert hashlib.sha256((root/registry['path']).read_bytes()).hexdigest()==registry['preimage_sha256']
assert subprocess.run([options.ruff,'--version'],check=True,capture_output=True,text=True).stdout.strip()=='ruff 0.15.8'
files=[str(packet/'candidate'/name) for name in manifest['files']]
subprocess.run([options.ruff,'format','--check','--config',str(root/'pyproject.toml'),*files],check=True)
subprocess.run([options.ruff,'check','--config',str(root/'pyproject.toml'),*files],check=True)
for subject,cohort,status,counts in [('frozen','interaction',1,(2,4,0,0)),('candidate','all',0,(72,0,0,0))]:
 result=subprocess.run([sys.executable,'-I','-B',str(packet/'receive.py'),subject,'--cohort',cohort,'--repository',str(root)],capture_output=True,text=True)
 sys.stdout.write(result.stdout)
 sys.stderr.write(result.stderr)
 assert result.returncode==status,(subject,result.returncode)
 summaries=re.findall(r'receiving subject=\w+ cohort=\w+ total=(\d+) failures=(\d+) errors=(\d+) skips=(\d+)',result.stdout)
 assert len(summaries)==1 and tuple(map(int,summaries[0]))==counts,(subject,summaries)
