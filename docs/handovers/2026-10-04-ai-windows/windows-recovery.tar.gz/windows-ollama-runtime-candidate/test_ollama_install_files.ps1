# Native Windows acceptance candidate. All ZIP payloads are inert fixture text.
# Not registered or executed in the Linux cloud container.
[CmdletBinding()]
param([string]$CandidateRoot = $PSScriptRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. ([IO.Path]::Combine($CandidateRoot, 'ollama_managed_files.ps1'))
Initialize-OllamaManagedNative
$fixtures = [IO.Path]::Combine($CandidateRoot, 'fixtures')
$receipts = [IO.File]::ReadAllText([IO.Path]::Combine($fixtures, 'receipts.json')) | ConvertFrom-Json
$payloads = [IO.File]::ReadAllText([IO.Path]::Combine($fixtures, 'payloads.json')) | ConvertFrom-Json
$token = [Guid]::NewGuid().ToString('N')
$rootPath = [IO.Path]::Combine([Environment]::GetFolderPath('LocalApplicationData'), 'ergopti-ollama-test-' + $token)
$sourcePath = [IO.Path]::Combine([IO.Path]::GetTempPath(), 'ergopti-ollama-source-' + $token)
[void][IO.Directory]::CreateDirectory($sourcePath)
$script:passed = 0
$script:failed = 0
$script:source_index = 0
function Assert-Receipt([bool]$Condition, [string]$Message) {
	if (-not $Condition) { throw ('ASSERTION: ' + $Message) }
}
function Case([string]$Name, [scriptblock]$Body) {
	try { & $Body; $script:passed++; Write-Output ('PASS ' + $Name) }
	catch { $script:failed++; Write-Output ('FAIL ' + $Name + ': ' + $_.Exception.Message) }
}
function Must-Refuse([scriptblock]$Body) {
	$refused = $false
	try { & $Body | Out-Null } catch { $refused = $true }
	Assert-Receipt $refused 'The actual native owner must refuse this operation.'
}
function Open-Fixture([string]$Name, [long]$Budget = 0, [int]$Count = 0) {
	$receipt = $receipts.PSObject.Properties[$Name].Value
	# This independent fixture catalogue admits only inert test payloads. It is
	# never copied over the authoritative production catalogue.
	$catalogue = [ordered]@{ schema_version = 1; version = '0.24.0'; assets = [ordered]@{
		'windows-amd64' = [ordered]@{ filename = 'ollama-windows-amd64.zip'; bytes = $receipt.bytes; sha256 = $receipt.sha256 }
	} }
	$path = [IO.Path]::Combine($sourcePath, $Name + '-' + (++$script:source_index) + '.json')
	Write-OllamaOwnedJson $path $catalogue
	$read = Open-OllamaReadFile $path
	try { $hash = Get-OllamaStreamHash $read } finally { $read.Dispose() }
	return Read-OllamaPinnedArchive $path $hash 'windows-amd64' ([IO.Path]::Combine($fixtures, $Name + '.zip')) $Budget $Count
}
$root = $null
$archive = $null
$prepared = $null
try {
	Case 'native protected current-user root and exclusive ownership receipt' {
		$script:root = Open-OllamaManagedRoot $rootPath
		Assert-OllamaPrivateSecurity $rootPath
		Assert-Receipt ([IO.File]::Exists([IO.Path]::Combine($rootPath, 'root-owner.json'))) 'Root ownership marker exists.'
	}
	foreach ($name in @('traversal', 'ads', 'rooted', 'device', 'collision', 'trailing-dot', 'receipt-collision', 'directory-cli', 'symlink')) {
		# Bind each fixture name through an independent function scope.
		function Refuse-Fixture([string]$FixtureName) { Case ('reject ' + $FixtureName) { Must-Refuse { Open-Fixture $FixtureName } } }
		Refuse-Fixture $name
	}
	Case 'full portable extraction retains every inert library and prerequisite payload' {
		$script:archive = Open-Fixture 'portable'
		$script:prepared = Prepare-OllamaManagedStage $root $archive $token
		Assert-Receipt ($prepared.ok -and $prepared.files -eq 4) 'All four independently declared files extracted.'
		foreach ($property in $payloads.PSObject.Properties) {
			$actual = [IO.File]::ReadAllBytes([IO.Path]::Combine($prepared.stage, $property.Name.Replace('/', '\')))
			Assert-Receipt (([BitConverter]::ToString($actual).Replace('-', '').ToLowerInvariant()) -eq $property.Value.hex) ('Exact independent payload: ' + $property.Name)
		}
	}
	Case 'archive reader lock excludes concurrent byte replacement' {
		Must-Refuse { $write = [IO.File]::Open($archive.archive_stream.Name, 'Open', 'Write', 'ReadWrite'); $write.Dispose() }
	}
	Case 'admitted expanded byte budget rejects portable extraction before stage creation' {
		Must-Refuse { Open-Fixture 'portable' 1 }
	}
	Case 'admitted entry budget rejects portable extraction before stage creation' {
		Must-Refuse { Open-Fixture 'portable' 0 1 }
	}
	Case 'foreign stage content blocks exact prepared publication' {
		$foreign = [IO.Path]::Combine($prepared.stage, 'foreign.txt')
		Write-OllamaOwnedJson $foreign @{ foreign = $true }
		Must-Refuse { Open-OllamaPreparedStage $root $token $prepared.stage_identity $prepared.manifest_sha256 }
		# This case owns the exact deliberately introduced test file only.
		$read = Open-OllamaReadFile $foreign $true
		Remove-OllamaExactFile $read
	}
	Case 'physical exact stage receipt rejects borrowed identity' {
		Must-Refuse { Open-OllamaPreparedStage $root $token '00000000:0000000000000000' $prepared.manifest_sha256 }
	}
	Case 'prepared receipt hash rejects changed source before publication' {
		Must-Refuse { Open-OllamaPreparedStage $root $token $prepared.stage_identity ('0' * 64) }
	}
	Case 'immutable no-replace native version publication' {
		$stage = Open-OllamaPreparedStage $root $token $prepared.stage_identity $prepared.manifest_sha256
		try {
			$published = Publish-OllamaPreparedStage $root $stage
			Assert-Receipt ($published.version_identity -eq $prepared.stage_identity) 'Physical directory identity survives publication.'
			Assert-Receipt ([IO.File]::Exists($published.executable)) 'Published CLI path exists.'
			$script:published = $published
		} finally { Close-OllamaPreparedStage $stage }
	}
	Case 'cleanup acknowledges exact source path absence after publication without deleting version' {
		$retired = Remove-OllamaPreparedStage $root $token $prepared.stage_identity $prepared.manifest_sha256
		Assert-Receipt $retired.ok 'Old private stage retired.'
		Assert-Receipt ([IO.File]::Exists($published.executable)) 'Immutable published version remains.'
	}
	Case 'existing version refuses replacement and exact unpublished duplicate can retire' {
		$otherTicket = [Guid]::NewGuid().ToString('N')
		$other = Prepare-OllamaManagedStage $root $archive $otherTicket
		$stage = Open-OllamaPreparedStage $root $otherTicket $other.stage_identity $other.manifest_sha256
		try { Must-Refuse { Publish-OllamaPreparedStage $root $stage } }
		finally { Close-OllamaPreparedStage $stage }
		$retired = Remove-OllamaPreparedStage $root $otherTicket $other.stage_identity $other.manifest_sha256
		Assert-Receipt $retired.ok 'Exact duplicate stage retired.'
		Assert-Receipt ([IO.File]::Exists($published.executable)) 'Original published version survived duplicate refusal and cleanup.'
	}
} finally {
	if ($null -ne $archive) { Close-OllamaPinnedArchive $archive }
	if ($null -ne $root) { Close-OllamaManagedRoot $root }
	# Preserve native evidence and the immutable published fixture version. No
	# wildcard recursive removal or replacement of production/user directories.
	Write-Output ('Evidence root: ' + $rootPath)
	Write-Output ('Independent source receipts: ' + $sourcePath)
	Write-Output ('RESULT passed=' + $script:passed + ' failed=' + $script:failed + ' skipped=0')
}
if ($script:failed -ne 0) { exit 1 }
