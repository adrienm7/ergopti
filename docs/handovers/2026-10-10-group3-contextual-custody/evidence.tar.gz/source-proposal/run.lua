local root, source, tests, filter = assert(arg[1]), assert(arg[2]), assert(arg[3]), arg[4]
local linux, shared = root .. "/static/ergopti_plus/linux", root .. "/static/ergopti_plus/_shared/lua"
package.path = linux .. "/?.lua;" .. linux .. "/?/init.lua;" .. shared .. "/?.lua;" .. shared .. "/?/init.lua;" .. package.path
require("compat.utf8").install()
package.preload["modules.shortcuts.keyboard_shortcuts"] = assert(loadfile(source))
local helpers = require("tests.helpers")
helpers.set_only_filter(filter or "contextual-late-custody")
dofile(tests)
local results = helpers.get_results()
print(string.format("RESULT %d passed, %d failed; actual module paths and original enrolled fixture; selected filter=%s",
	results.passed, results.failed, filter or "contextual-late-custody"))
os.exit(results.failed == 0 and 0 or 1)
