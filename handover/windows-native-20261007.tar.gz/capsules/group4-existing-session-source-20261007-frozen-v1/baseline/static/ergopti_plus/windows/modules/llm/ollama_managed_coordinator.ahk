﻿; modules/llm/ollama_managed_coordinator.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Captured Managed Ollama Session Coordination
; DESCRIPTION:
; Coordinates existing native session, exact HTTP receipts and a separate model
; command under one source/selection/deadline. It never changes enabled state.
; ==============================================================================

OllamaManagedSnapshot() {
	local snapshot := _LLM_Menu_EnableSnapshot()
	snapshot["source"] := _LLM_Menu_EnableReadSource()
	return snapshot
}

OllamaManagedCopySnapshot(Snapshot) {
	if !(Snapshot is Map) || !(Snapshot.Get("source", 0) is Map)
			|| !(Snapshot["source"].Get("bytes", 0) is Buffer)
		throw TypeError("Managed selection requires a captured configuration byte source.")
	local result := Snapshot.Clone(), source := Snapshot["source"].Clone(), bytes := source["bytes"]
	local copy := Buffer(bytes.Size, 0)
	loop bytes.Size
		NumPut("UChar", NumGet(bytes, A_Index - 1, "UChar"), copy, A_Index - 1)
	source["bytes"] := copy
	result["source"] := source
	return result
}

OllamaManagedSelectionCurrent(Captured, Live) {
	if !(Captured is Map) || !(Live is Map)
		return false
	for name in ["backend", "model", "origin"]
		if !(Captured.Get(name, 0) is String) || !(Live.Get(name, 0) is String)
				|| StrCompare(Captured[name], Live[name], true) != 0
			return false
	for name in ["generation", "enabled"]
		if !(Captured.Get(name, "") is Integer) || !(Live.Get(name, "") is Integer)
				|| Captured[name] != Live[name]
			return false
	return Live["backend"] == "ollama" && Live.Get("paused", true) is Integer && Live["paused"] == false
		&& Live.Get("blocked", true) is Integer && Live["blocked"] == false
		&& _LLM_Menu_EnableSourceMatches(Captured.Get("source", 0), Live.Get("source", 0))
}

/** Fresh pin copies: files keep all nine roles, native runtime drops only installer. */
OllamaManagedPinProjection(Pins) {
	local names := ["NativeModule", "Guardian", "ManagedBridge", "FilesHelper", "PublicationHelper",
		"ProducerHelper", "SourceWorker", "Launcher", "InstallWorker"]
	if !(Pins is Map) || Pins.Count != names.Length
		throw TypeError("Managed initialization requires all nine generated image pins.")
	local files := Map(), native := Map()
	for name in names {
		if !(Pins.Get(name, 0) is Map)
			throw TypeError("A required generated image pin is missing.")
		files[name] := Pins[name].Clone()
		if name != "InstallWorker"
			native[name] := Pins[name].Clone()
	}
	return Map("files", files, "native", native)
}

class OllamaManagedCoordinator extends _LocalServerModelsTimerNativeAdapter {
	__New(Files, RuntimeOptions, Options) {
		if !(Files is OllamaManagedFilesDefault) || !(RuntimeOptions is Map) || !(Options is Map)
				|| !(Options.Get("workflow_ms", 0) is Integer) || Options["workflow_ms"] <= 0
				|| Options["workflow_ms"] > 0x7fffffff || !(Options.Get("poll_ms", 0) is Integer)
				|| Options["poll_ms"] <= 0 || !HasMethod(Options.Get("consent", 0), "Call")
				|| !HasMethod(Options.Get("model_consent", 0), "Call") || !HasMethod(Options.Get("on_ready", 0), "Call")
			throw TypeError("Managed coordination requires captured budgets and distinct explicit consent owners.")
		for name in ["snapshot", "release", "timer", "clock", "session_factory", "model_factory", "on_failed", "archive_factory"]
			if Options.Has(name) && !HasMethod(Options[name], "Call")
				throw TypeError("Managed coordinator ports must be callable.")
		this.Options := Options.Clone()
		this.RuntimeOptions := RuntimeOptions.Clone()
		local projected := OllamaManagedPinProjection(Files.Pins)
		if !(RuntimeOptions.Get("native_pins", 0) is Map)
			throw TypeError("Managed runtime requires its explicit generated native pins.")
		for name, pin in RuntimeOptions["native_pins"] {
			if !projected["files"].Has(name) || !(pin is Map)
				throw TypeError("Runtime pin projection cannot admit an unknown image role.")
			for field in ["path", "bytes", "sha256"]
				if pin.Get(field, 0) != projected["files"][name].Get(field, 0)
					throw ValueError("Runtime image pins are foreign to the managed file owner.")
		}
		if RuntimeOptions["native_pins"].Count < 8 || RuntimeOptions["native_pins"].Count > 9
			throw TypeError("The runtime pin projection must preserve every native image role.")
		for name in projected["native"]
			if !RuntimeOptions["native_pins"].Has(name)
				throw TypeError("A native runtime pin is missing from the captured projection.")
		if RuntimeOptions.Get("launcher", "") != Files.Pins["Launcher"]["path"]
			throw ValueError("The runtime launcher differs from the captured file-owner image.")
		this.RuntimeOptions["native_pins"] := projected["native"]
		this.Files := Files
		this.Record := 0
		this.Generation := 0
		this.FirstError := ""
		this.SessionTimers := Map()
		this.Http := OllamaManagedHttp(Map("poll_ms", Options["poll_ms"],
			"timer", ObjBindMethod(this, "_Timer"), "clock", ObjBindMethod(this, "_Clock")))
		local factory := Options.Get("session_factory", OllamaUserLocalSession)
		this.Session := factory.Call(Files, this.RuntimeOptions, ObjBindMethod(this, "_SessionCurrent"),
			ObjBindMethod(this, "_SessionConsent"), ObjBindMethod(this, "_Dispatched"),
			Options["poll_ms"], ObjBindMethod(this, "_SessionTimer"))
		if !(this.Session is OllamaUserLocalSession)
			throw TypeError("Managed coordination requires its genuine session owner.")
	}

	/** Plan is produced by the separately owned verified archive provider. */
	Start(Plan) {
		if !(Plan is Map) || !(Plan.Get("prepare", 0) is Map) || !(Plan.Get("target", 0) is Map)
			throw TypeError("Managed start requires an owned archive plan.")
		local previous := Critical("On")
		try {
			if this.Record is Map || this.HasNativeOwner() || this.Files.HasFileDebt()
				return false
			if this.Generation == 0x7fffffffffffffff
				throw Error("Managed coordination generation identities are exhausted.")
			local copied := Map("prepare", Plan["prepare"].Clone(), "target", Plan["target"].Clone(), "version", Plan.Get("version", ""), "archive_mode", Plan.Get("archive_mode", "local"))
			local record := Map("generation", ++this.Generation, "plan", copied, "captured", 0,
				"deadline", 0, "phase", "consent",
				"consented", false, "cancelled", false, "building", true, "busy", false,
				"model", 0, "model_attempted", false, "model_done", false, "model_exit", -1,
				"publication", 0, "target", 0, "delivered", false, "failure_notified", false,
				"timer_owned", false, "timer_revision", 0, "first_error", "")
			record["timer"] := ObjBindMethod(this, "_PollRecord", record)
			this.Record := record
		} finally Critical(previous)
		local accepted := false
		try {
			; The reservation precedes optional clocks and every external callback.
			record["deadline"] := this._Clock() + this.Options["workflow_ms"]
			record["plan"]["deadline"] := record["deadline"]
			if !(record["plan"]["archive_mode"] == "local" || record["plan"]["archive_mode"] == "official")
				throw ValueError("Managed archive intent is unsupported.")
			if !this._Owns(record) || record["cancelled"]
				return false
			local snapshot := this.Options.Get("snapshot", OllamaManagedSnapshot)
			record["captured"] := OllamaManagedCopySnapshot(snapshot.Call())
			local selected := record["captured"], captured_target := record["plan"]["target"], origin := 0
			if selected["model"] == "" || !RegExMatch(selected["origin"], "\Ahttp://(?:localhost|127\.0\.0\.1):([0-9]+)\z", &origin)
					|| StrLen(origin[1]) > 5
					|| !(captured_target.Get("port", 0) is Integer) || captured_target["port"] < 1
					|| captured_target["port"] > 65535 || Integer(origin[1]) != captured_target["port"]
					|| captured_target.Get("origin", "") != ("http://127.0.0.1:" . captured_target["port"])
				throw Error("The captured server origin/model cannot authorize this native target.")
			local release := this.Options.Get("release", OllamaWindowsRelease), asset := release.Call()
			if !(asset is Map) || record["plan"]["version"] != asset["version"]
					|| record["plan"]["prepare"].Get("AssetId", "") != asset["asset_id"]
				throw Error("The archive plan is foreign to the current native release selection.")
			record["asset"] := asset.Clone()
			if !this._Current(record)
				return false
			local consent := this.Options["consent"].Call(OllamaManagedCopySnapshot(record["captured"]), asset.Clone())
			if !(consent is Integer) || consent != true || !this._Current(record)
				return false
			record["consented"] := true
			record["phase"] := "preparing"
			if record["plan"]["archive_mode"] == "official"
				accepted := this.Session.Start(record["plan"], this.Options.Get("archive_factory", OllamaOfficialSessionArchive)) == true && this._Current(record)
			else
				accepted := this.Session.Start(record["plan"]) == true && this._Current(record)
			return accepted
		} catch Any as Err {
			this._Fault(record, "managed_start_refused")
			return false
		} finally {
			record["building"] := false
			if !accepted
				this._Fault(record, "managed_consent_or_start_refused")
			this._PollRecord(record)
		}
	}

	_Owns(Record) {
		return this.Record is Map && this.Record == Record && this.Generation == Record["generation"]
	}

	_Current(Record) {
		if !this._Owns(Record) || Record["cancelled"] || A_IsSuspended
				|| (Record["phase"] != "ready" && this._Clock() >= Record["deadline"])
			return false
		local observed_tick := this._Clock()
		local snapshot := this.Options.Get("snapshot", OllamaManagedSnapshot)
		local current := OllamaManagedSelectionCurrent(Record["captured"], snapshot.Call())
		return current && this._Owns(Record) && !Record["cancelled"] && !A_IsSuspended
			&& (Record["phase"] == "ready" || observed_tick < Record["deadline"])
	}

	_SessionCurrent(Prepare, Target) {
		local record := this.Record
		if !(record is Map) || !this._Current(record)
			return false
		local captured := record["plan"]["prepare"]
		for name in ["ManagedRoot", "CataloguePath", "CatalogueSha256", "AssetId", "ArchivePath", "TicketId",
			"MaxExpandedBytes", "MaxEntries"]
			if Prepare.Get(name, 0) != captured.Get(name, 0)
				return false
		local expected := record["target"] is Map ? record["target"] : record["plan"]["target"]
		for name in ["models_dir", "origin", "port"]
			if Target.Get(name, 0) != expected.Get(name, 0)
				return false
		if expected.Has("executable") && Target.Get("executable", "") != expected["executable"]
			return false
		return this._Current(record)
	}

	_SessionConsent(Prepare, Target) {
		return this.Record is Map && this.Record["consented"] && this._SessionCurrent(Prepare, Target)
	}

	_Dispatched(Target, Publication) {
		local record := this.Record
		if !(record is Map) || !this._Current(record)
			return
		local expected := record["plan"]["target"]
		for name in ["models_dir", "origin", "port"]
			if Target.Get(name, 0) != expected.Get(name, 0)
				return this._Fault(record, "runtime_target_refused")
		local source := OllamaRuntimeSourceSpec(Publication)
		if Publication.Get("Version", "") != record["asset"]["version"]
				|| Publication.Get("Asset", "") != record["asset"]["asset_id"]
			return this._Fault(record, "runtime_publication_refused")
		source.ForTarget(Target)
		record["target"] := Target.Clone()
		record["publication"] := Publication.Clone()
		record["phase"] := "awaiting-native-activation"
		this._Schedule(record)
	}

	_RuntimeLive() {
		local owner := this.Session.Runtime.Owner
		if !(owner is OllamaRuntimeOwner) || !(owner.Record is Map)
			return false
		local actor := owner.Record.Get("guardian", 0)
		if !(actor is OllamaGuardianTask) || actor.Cancelled || actor.IsRetired || !actor.ActivationAttempted
			return false
		local status := actor.Native.Poll(actor.Id)
		if !(status is Map) || status.Get("id", 0) != actor.Id || status.Get("phase", -1) != 4
				|| status.Get("error", -1) != 0 || status.Get("activation_claimed", 0) != 1
			return false
		if !this.RuntimeOptions.Get("direct_daemon", false)
			return true
		local listener := _SR_GuardianWithLiveDaemon(actor.Daemon, _OllamaListenerOwned.Bind(this.Record["target"]["port"]))
		return listener is Map && listener.Get("state", "refused") == "owned" && listener.Get("error", -1) == 0
	}

	_Query(Record, Kind) {
		if Record.Get("ready_write", 0) is Map || !this._Current(Record) || !this._RuntimeLive()
			return this._Fault(Record, "runtime_or_source_not_current")
		Record["phase"] := "http-" . Kind
		if !this.Http.Query(Record["captured"]["origin"], Kind, Record["deadline"],
				ObjBindMethod(this, "_HttpCurrent", Record), ObjBindMethod(this, "_Receipt", Record),
				this.RuntimeOptions.Get("direct_daemon", false))
			return this._Fault(Record, "http_query_refused")
		return true
	}

	_HttpCurrent(Record) {
		return this._Current(Record) && this._RuntimeLive()
	}

	_Receipt(Record, Receipt) {
		if !this._HttpCurrent(Record) || !(Receipt is Map)
			return this._Fault(Record, "http_receipt_source_refused")
		local expected := "http-" . Receipt.Get("kind", "")
		if Record["phase"] != expected || StrCompare(Receipt.Get("origin", ""), Record["captured"]["origin"], true) != 0
			return this._Fault(Record, "http_receipt_origin_or_phase_refused")
		if Receipt["kind"] == "version" {
			local version := LLM_EnableReceipt(Receipt)
			if !version["admitted"]
				return this._Fault(Record, "version_receipt_refused")
			local data := JsonParse(Receipt["body"])
			if data["version"] != Record["asset"]["version"]
				return this._Fault(Record, "version_receipt_mismatch")
			Record["version_receipt"] := Receipt.Clone()
			return this._Query(Record, "tags")
		}
		local tags := LLM_LocalModelListReceipt(Receipt)
		if !tags["ok"]
			return this._Fault(Record, "tags_receipt_refused")
		if !tags["names"].Has(LLM_LocalModelNormalize(Record["captured"]["model"]))
			return this._PullModel(Record)
		if !this._HttpCurrent(Record) || this.Http.HasOwner()
			return this._Fault(Record, "http_handback_or_current_refused")
		if !Record["delivered"] {
			Record["delivered"] := true
			Record["phase"] := "ready"
			; Data only: no enabled flag, preference write or inference activation.
			try {
				this.Options["on_ready"].Call(Map("origin", Record["captured"]["origin"],
					"model", Record["captured"]["model"], "version", Record["asset"]["version"], "model_present", true))
			} catch Any as Err {
				this._Fault(Record, "managed_ready_callback_refused")
			}
		}
	}

	_PullModel(Record) {
		if Record["model_attempted"] || !this._HttpCurrent(Record)
			return this._Fault(Record, "model_missing_or_source_refused")
		Record["model_attempted"] := true
		local accepted := this.Options["model_consent"].Call(OllamaManagedCopySnapshot(Record["captured"]))
		if !(accepted is Integer) || accepted != true || !this._HttpCurrent(Record)
			return this._Fault(Record, "model_consent_refused")
		local options := this.RuntimeOptions.Clone(), source := OllamaRuntimeSourceSpec(Record["publication"])
		options["source_spec"] := ObjBindMethod(source, "ForTarget")
		options["startup_ms"] := Record["deadline"] - this._Clock()
		local constructor := this.Options.Get("model_factory", OllamaModelPullOwner)
		Record["model"] := constructor.Call(options, Record["captured"]["model"])
		if !(Record["model"] is OllamaModelPullOwner)
			return this._Fault(Record, "model_owner_type_refused")
		local target := Record["target"].Clone()
		target["model_tag"] := Record["captured"]["model"]
		local authority := ObjBindMethod(this, "_ModelCurrent", Record)
		Record["phase"] := "model-running"
		if !Record["model"].Start(target, Map("authorize", authority, "is_current", authority),
				ObjBindMethod(this, "_ModelTerminal", Record))
			return this._Fault(Record, "model_command_refused")
		return true
	}

	_ModelCurrent(Record, Target) {
		if !this._HttpCurrent(Record) || Target.Get("model_tag", "") != Record["captured"]["model"]
			return false
		for name in ["executable", "models_dir", "origin", "port"]
			if Target.Get(name, 0) != Record["target"].Get(name, 0)
				return false
		return this._HttpCurrent(Record)
	}

	_ModelTerminal(Record, ExitCode, Target) {
		if !this._Owns(Record) || Record["cancelled"]
			return
		if !(ExitCode is Integer) || !this._ModelCurrent(Record, Target)
			return this._Fault(Record, "model_terminal_correlation_refused")
		Record["model_done"] := true
		Record["model_exit"] := ExitCode
		this._Schedule(Record)
	}

	_Fault(Record, Reason) {
		if !this._Owns(Record)
			return false
		if Record["first_error"] == "" {
			Record["first_error"] := Reason
			this.FirstError := Reason
		}
		Record["cancelled"] := true
		Record["phase"] := "retiring"
		return false
	}

	_PollRecord(Record) {
		local previous := Critical("On")
		try {
			if !(Record is Map) || !this._Owns(Record) || Record["building"] || Record["busy"]
					|| (Record.Get("ready_write", 0) is Map && !Record["cancelled"])
				return
			Record["busy"] := true
		} finally Critical(previous)
		local caller := Critical("Off")
		try {
			if !Record["cancelled"] && !this._Current(Record)
				this._Fault(Record, "selection_or_deadline_changed")
			if Record["cancelled"] {
				this.Http.Cancel()
				this.Session.Stop()
				if !this.Files.HasOwner() && !this.Session.Runtime.HasOwner() && !this.Session.Busy && !this.Session.ArchiveOwned
					this._StopSessionTimers()
				if IsObject(Record["model"])
					Record["model"].Stop()
				if !this._WorkOwned() && this._RetireRecordTimer(Record) {
					if !Record["failure_notified"] && HasMethod(this.Options.Get("on_failed", 0), "Call") {
						Record["failure_notified"] := true
						this.Options["on_failed"].Call(Record["first_error"])
					}
					return
				}
			} else if this.Session.Record is Map && this.Session.Record["cancelled"]
				this._Fault(Record, "managed_session_native_refused")
			else if Record["phase"] == "awaiting-native-activation" && this._RuntimeLive()
				this._Query(Record, "version")
			else if Record["phase"] == "model-running" && Record["model_done"] && !Record["model"].HasOwner() {
				if Record["model_exit"] != 0
					this._Fault(Record, "model_native_terminal_refused")
				else
					this._Query(Record, "version")
			} else if InStr(Record["phase"], "http-") == 1 && !this.Http.HasOwner()
				this._Fault(Record, "http_delivery_cancelled")
			else if Record["phase"] == "ready" && !this._RuntimeLive()
				this._Fault(Record, "runtime_no_longer_live")
		} catch Any as Err {
			this._Fault(Record, "managed_observation_refused")
		} finally {
			Record["busy"] := false
			try this._Schedule(Record)
			finally Critical(caller)
		}
	}

	/** Reserves one source-exact ready runtime before a real configuration write. */
	BeginReadyWrite() {
		local record := this.Record
		if !(record is Map) || record["phase"] != "ready" || record["busy"] || record["building"]
				|| record.Get("ready_write", 0) is Map || !this.ReadyForUse()
				|| this.Http.HasOwner() || this.Files.HasOwner() || this.Files.HasFileDebt()
				|| this.Session.Busy || this.Session.ArchiveOwned
				|| (IsObject(record["model"]) && record["model"].HasOwner())
			return false
		local runtime := this.Session.Runtime.Owner
		if !(runtime is OllamaRuntimeOwner) || !(runtime.Record is Map)
			return false
		local actor := runtime.Record.Get("guardian", 0)
		if !(actor is OllamaGuardianTask)
			return false
		local ticket := OllamaManagedReadyWriteTicket(this)
		local previous := Critical("On")
		try {
			if !this._Owns(record) || record["cancelled"] || record["phase"] != "ready"
					|| record["busy"] || record.Get("ready_write", 0) is Map
				return false
			local row := Map("ticket", ticket, "actor", actor, "record", record,
				"captured", OllamaManagedCopySnapshot(record["captured"]), "expected", 0,
				"write_ack", false, "sealed", false)
			record["ready_write"] := row
		} finally Critical(previous)
		local accepted := false
		try {
			if !actor.HoldReadyWrite(ticket) || !this._StopSessionTimers() || !this._HoldReadyTimer(record)
					|| !this._Current(record) || !this._RuntimeLive() || !this._Current(record)
					|| !this._ReadyWriteOwns(row)
				return false
			row["sealed"] := true
			accepted := true
			return ticket
		} finally {
			if !accepted
				this.AbortReadyWrite(ticket)
		}
	}

	_ReadyWriteOwns(Row) {
		local record := Row["record"]
		local runtime := this.Session.Runtime.Owner
		if !(runtime is OllamaRuntimeOwner) || !(runtime.Record is Map)
			return false
		return this._Owns(record) && record.Get("ready_write", 0) == Row
			&& !record["cancelled"] && record["phase"] == "ready"
			&& Row["ticket"] is OllamaManagedReadyWriteTicket && Row["ticket"].Owner == this
			&& runtime.Record.Get("guardian", 0) == Row["actor"]
	}

	_ReadyWriteEntry(Ticket) {
		local record := this.Record
		if !(Ticket is OllamaManagedReadyWriteTicket) || Ticket.Owner != this || !(record is Map)
			return false
		local row := record.Get("ready_write", 0)
		return row is Map && row["ticket"] == Ticket && this._ReadyWriteOwns(row) ? row : false
	}

	_HoldReadyTimer(Record) {
		if Record["timer_revision"] == 0x7fffffffffffffff
			throw Error("Managed coordinator timer revisions are exhausted.")
		local revision := ++Record["timer_revision"]
		if !this._Timer(Record["timer"], 0)
			return false
		local previous := Critical("On")
		try {
			if !this._Owns(Record) || Record["cancelled"] || Record["timer_revision"] != revision
					|| this.SessionTimers.Count != 0
				return false
			Record["timer_owned"] := false
			return true
		} finally Critical(previous)
	}

	/** Seals independently rendered bytes before the actual writer runs. */
	SealReadyWrite(Ticket, ExpectedSource) {
		local row := this._ReadyWriteEntry(Ticket)
		if !(row is Map) || !row["sealed"] || row["expected"] is Map || row["write_ack"]
				|| !(ExpectedSource is Map) || !(ExpectedSource.Get("bytes", 0) is Buffer)
				|| ExpectedSource.Get("path", "") != row["captured"]["source"]["path"]
				|| !this._Current(row["record"]) || !this._RuntimeLive() || !this._Current(row["record"])
				|| !this._ReadyWriteOwns(row)
			return false
		local copied := OllamaManagedCopySnapshot(row["captured"])
		copied["source"] := ExpectedSource
		copied := OllamaManagedCopySnapshot(copied)
		row["expected"] := copied["source"]
		return this._ReadyWriteOwns(row)
	}

	/** Writer success is necessary, but cannot replace exact post-write bytes. */
	AcknowledgeReadyWrite(Ticket, Source) {
		local row := this._ReadyWriteEntry(Ticket)
		if !(row is Map) || !(row["expected"] is Map) || row["write_ack"]
				|| !_LLM_Menu_EnableSourceMatches(row["expected"], Source)
			return false
		row["write_ack"] := true
		return this._ReadyWriteOwns(row)
	}

	/** Consumes only a confirmed fresh snapshot after durable/live publication. */
	FinishReadyWrite(Ticket) {
		local row := this._ReadyWriteEntry(Ticket)
		if !(row is Map)
			return false
		if !row["write_ack"] || !row["sealed"] || !this._RuntimeLive()
			return this.AbortReadyWrite(Ticket)
		local snapshot := this.Options.Get("snapshot", OllamaManagedSnapshot)
		local fresh := OllamaManagedCopySnapshot(snapshot.Call()), captured := row["captured"]
		for field in ["backend", "model", "origin", "generation"]
			if Type(fresh.Get(field, 0)) != Type(captured.Get(field, 0)) || fresh.Get(field, 0) != captured.Get(field, 0)
				return this.AbortReadyWrite(Ticket)
		if !(fresh.Get("enabled", 0) is Integer) || fresh["enabled"] != true
				|| !(fresh.Get("paused", 0) is Integer) || fresh["paused"] != false
				|| !(fresh.Get("blocked", 0) is Integer) || fresh["blocked"] != false
				|| !_LLM_Menu_EnableSourceMatches(row["expected"], fresh["source"])
				|| !this._ReadyWriteOwns(row) || !this._RuntimeLive()
			return this.AbortReadyWrite(Ticket)
		local previous := Critical("On")
		try {
			if !this._ReadyWriteOwns(row)
				return false
			row["record"]["captured"] := fresh
			row["record"]["ready_write"] := 0
		} finally Critical(previous)
		try {
			if !row["actor"].ReleaseReadyWrite(Ticket, true) || !this._Current(row["record"])
					|| !this._RuntimeLive()
				return this._RefuseReadyWriteAfterCommit(row["record"])
			this._SessionTimer(this.Session.Timer, -this.Options["poll_ms"])
			this._Schedule(row["record"])
			if !this._Current(row["record"]) || !this._RuntimeLive()
				return this._RefuseReadyWriteAfterCommit(row["record"])
			return true
		} catch Any as Err {
			return this._RefuseReadyWriteAfterCommit(row["record"])
		}
	}

	_RefuseReadyWriteAfterCommit(Record) {
		this._Fault(Record, "managed_ready_write_resume_refused")
		this._PollRecord(Record)
		return false
	}

	AbortReadyWrite(Ticket) {
		local record := this.Record
		if !(record is Map)
			return false
		local row := record.Get("ready_write", 0)
		if !(row is Map) || row["ticket"] != Ticket
			return false
		this._Fault(record, "managed_ready_write_refused")
		; Revocation permits the real actor's retirement poll even while its
		; ready-observer hold remains retained after a cancellation refusal.
		row["actor"].ReleaseReadyWrite(Ticket, false)
		this._PollRecord(record)
		return false
	}

	ReadyForUse() {
		local record := this.Record
		if !(record is Map) || record["phase"] != "ready" || record.Get("ready_write", 0) is Map
			return false
		if !this._Current(record) || !this._RuntimeLive() || !this._Current(record) {
			this._Fault(record, "managed_ready_source_or_listener_refused")
			this._PollRecord(record)
			return false
		}
		return this._Owns(record) && !record["cancelled"] && !(record.Get("ready_write", 0) is Map)
	}

	Stop() {
		local record := this.Record
		if record is Map {
			this._Fault(record, "managed_lifecycle_revoked")
			this._PollRecord(record)
		} else {
			this.Http.Cancel()
			this.Session.Stop()
			if !this.Files.HasOwner() && !this.Session.Runtime.HasOwner() && !this.Session.Busy && !this.Session.ArchiveOwned
				this._StopSessionTimers()
		}
		return !this.HasNativeOwner()
	}

	HasNativeOwner() {
		return this._WorkOwned() || (this.Record is Map && this.Record["timer_owned"])
	}

	_WorkOwned() {
		return this.Files.HasOwner() || this.Session.Runtime.HasOwner() || this.Http.HasOwner()
			|| this.Session.Busy || this.Session.ArchiveOwned || this.SessionTimers.Count != 0
			|| (this.Record is Map && (this.Record["building"]
				|| IsObject(this.Record["model"]) && this.Record["model"].HasOwner()))
	}

	_Schedule(Record) {
		if Record.Get("ready_write", 0) is Map && !Record["cancelled"]
			return
		if this._Owns(Record) {
			if Record["timer_revision"] == 0x7fffffffffffffff
				throw Error("Managed coordinator timer revisions are exhausted.")
			Record["timer_revision"] += 1
			Record["timer_owned"] := true
			if !this._Timer(Record["timer"], -this.Options["poll_ms"])
				this._Fault(Record, "managed_timer_refused")
		}
	}

	_RetireRecordTimer(Record) {
		if !this._Owns(Record) || Record["timer_revision"] == 0x7fffffffffffffff
			return false
		local revision := ++Record["timer_revision"]
		if !this._Timer(Record["timer"], 0)
			return false
		local previous := Critical("On")
		try {
			; An external stop port can acquire/rearm after the earlier work check.
			if !this._Owns(Record) || this._WorkOwned() || Record["timer_revision"] != revision
				return false
			Record["timer_owned"] := false
			this.Record := 0
			return true
		} finally Critical(previous)
	}

	_Timer(Callback, Period) {
		local timer := this.Options.Get("timer", ObjBindMethod(this, "_NativeTimer"))
		try {
			local accepted := timer.Call(Callback, Period)
			return accepted is Integer && accepted == true
		} catch Any as Err {
			return false
		}
	}

	_SessionTimer(Callback, Period) {
		if !HasMethod(Callback, "Call") || !(Period is Integer) || Period > 0
			throw TypeError("Managed session timers require exact callbacks and one-shot/stop periods.")
		if Period < 0 && this.Record is Map && this.Record.Get("ready_write", 0) is Map && !this.Record["cancelled"]
			return this._Fault(this.Record, "managed_ready_write_unexpected_rearm")
		local key := ObjPtr(Callback), previous := Critical("On")
		try {
			local entry := this.SessionTimers.Get(key, Map("callback", Callback, "revision", 0))
			if entry["revision"] == 0x7fffffffffffffff
				throw Error("Managed session timer revisions are exhausted.")
			local revision := ++entry["revision"]
			this.SessionTimers[key] := entry
		} finally Critical(previous)
		local accepted := this._Timer(Callback, Period)
		previous := Critical("On")
		try {
			if accepted && Period == 0 && this.SessionTimers.Get(key, 0) == entry
					&& entry["revision"] == revision
				this.SessionTimers.Delete(key)
		} finally Critical(previous)
		if !accepted && this.Record is Map
			this._Fault(this.Record, "managed_session_timer_refused")
		return accepted
	}

	_StopSessionTimers() {
		local retained := []
		for key, entry in this.SessionTimers
			retained.Push(entry)
		for entry in retained
			this._SessionTimer(entry["callback"], 0)
		return this.SessionTimers.Count == 0
	}

	_Clock() {
		local clock := this.Options.Get("clock", () => A_TickCount), now := clock.Call()
		if !(now is Integer) || now < 0
			throw TypeError("Managed workflow requires native-domain monotonic ticks.")
		return now
	}
}
