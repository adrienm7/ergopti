
helpers.describe("lease cadence retained READY transaction", function()
	helpers.it("preserves the original READY watchdog origin before delayed recurring construction", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local after, every = scheduler.after, scheduler.every
			local ready_at, ready_timer, calls, successful = nil, nil, 0, 0
			scheduler.after = function(delay, fn)
				local timer, committed = after(delay, fn)
				if delay == 4 then ready_at, ready_timer = ctx.clock, timer end
				return timer, committed
			end
			scheduler.every = function(delay, fn)
				calls = calls + 1;assert(ready_at == 0 and ready_timer and not ready_timer.cancelled)
				ctx.clock = 3.8;ctx.chunk(1, "READY\n")
				assert(successful == 0 and controller.status() == "starting" and not ready_timer.cancelled)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and ready_timer.cancelled and controller.status() == "paused")
		end)
	end)

	helpers.it("does not hide a malformed line after authentic held READY", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, calls, results = scheduler.every, 0, {}
			scheduler.every = function(delay, fn)
				calls = calls + 1;ctx.chunk(1, "READY\nBOGUS\n")
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) results[#results + 1] = ok end) == false)
			assert(calls == 1 and #results == 0 and controller.status() == "fencing")
			assert(#recurring(ctx, true) == 0 and #ctx.spawns == 2)
			ctx.complete(2, 0);assert(#results == 1 and results[1] == false)
		end)
	end)

	helpers.it("admits duplicate authentic held READY only once after commit", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, calls, successful = scheduler.every, 0, 0
			scheduler.every = function(delay, fn)
				calls = calls + 1;ctx.chunk(1, "READY\nREADY\n")
				assert(controller.status() == "starting" and successful == 0)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and #recurring(ctx, true) == 1)
			ctx.chunk(1, "READY\n");assert(successful == 1 and #recurring(ctx, false) == 1)
		end)
	end)

	helpers.it("preserves an inline READY during the original ACK constructor", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local after, every = scheduler.after, scheduler.every
			local ready_timer, calls, successful = nil, 0, 0
			scheduler.after = function(delay, fn)
				local timer, committed = after(delay, fn)
				if delay == 4 then ready_timer = timer;ctx.chunk(1, "READY\n") end
				return timer, committed
			end
			scheduler.every = function(delay, fn)
				calls = calls + 1;assert(successful == 0)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and ready_timer.cancelled)
			assert(controller.status() == "paused" and #recurring(ctx, true) == 1)
		end)
	end)

	helpers.it("keeps a recurring callback inert while authentic READY is held before commit", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, calls, successful = scheduler.every, 0, 0
			scheduler.every = function(delay, fn)
				calls = calls + 1;ctx.chunk(1, "READY\n");fn()
				assert(successful == 0 and controller.status() == "starting" and #ctx.spawns[1].inputs == 0)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and #ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("does not replay an old held READY over a STOP successor", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, first, successful, failed, successor = scheduler.every, true, 0, 0, 0
			scheduler.every = function(delay, fn)
				local timer, committed = every(delay, fn)
				if first then
					first = false;ctx.chunk(1, "READY\n");assert(controller.stop("held-replace"))
					assert(controller.start_paused(function(ok) assert(ok);successor = successor + 1 end))
				end
				return timer, committed
			end
			assert(controller.start_paused(function(ok) if ok then successful = successful + 1 else failed = failed + 1 end end) == false)
			assert(successful == 0 and failed == 1 and successor == 0 and controller.status() == "starting")
			ctx.chunk(2, "READY\n");assert(successor == 1 and controller.status() == "paused")
			ctx.chunk(1, "READY\n");assert(successful == 0 and successor == 1)
			local all = recurring(ctx, false);assert(#all == 2 and all[1].cancelled and not all[2].cancelled)
			local old, new = #ctx.spawns[1].inputs, #ctx.spawns[2].inputs;all[1].fn()
			assert(#ctx.spawns[1].inputs == old and #ctx.spawns[2].inputs == new)
		end)
	end)

	helpers.it("preserves authentic inline STOPPED and reinitialization cleanup debt after held READY", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, retained, stopped, successful, failed = scheduler.every, nil, nil, 0, 0
			scheduler.every = function(delay, fn)
				local timer, committed = every(delay, fn);retained = timer
				ctx.chunk(1, "READY\n");ctx.next_input_chunk = "STOPPED\n"
				assert(controller.stop("held-inline-stop", function(ok) stopped = ok end))
				assert(stopped == true and controller.status() == "idle")
				ctx.cancel_target, ctx.cancel_failures = timer, 1
				assert(controller.init())
				return timer, committed
			end
			assert(controller.start_paused(function(ok) if ok then successful = successful + 1 else failed = failed + 1 end end) == false)
			assert(successful == 0 and failed == 1 and stopped == true and #ctx.spawns == 1)
			assert(retained.cancel_attempts == 1 and not retained.cancelled)
			assert(controller.init());assert(retained.cancel_attempts == 1)
			local inputs = #ctx.spawns[1].inputs;retained.fn();assert(#ctx.spawns[1].inputs == inputs)
			assert(controller.status() == "idle" and retained.cancelled and retained.cancel_attempts == 2)
		end)
	end)
end)
