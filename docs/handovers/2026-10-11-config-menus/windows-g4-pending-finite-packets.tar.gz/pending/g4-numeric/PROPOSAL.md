# Linux trigger prompt receives the real shared group caption

PRIVATE SOURCE ONLY. No parser, VM, test, generator, native receiving or canonical mutation was performed. Conditional G4 ownership of the title-only prompt receiving hunk is required before canonical adoption; Root coordinates that handoff.

## Concrete scope

The original Linux debounce custom-value callback supplies the literal translation key `menu.llm.trigger_menu_title` to `Prompt.ask`. That field is the numeric page request title, not the generic native window title. The existing shared `llm_menu` declaration already has the real `group` identity `llm_trigger` with that translation key in all 21 languages. The candidate receives that actual group caption, preserving its existing context and native bridge.

Three paths only: a separate `group_caption_receiver` in the shared Lua renderer; the real Linux debounce `Prompt.ask` title receiving seam plus its narrowly captured facade; and an additive suffix on the existing prediction-count/numeric-menu fixture. No manifest, schema, generated output, locale, business policy, native bridge, worker or transaction edit is included. No dummy menu row or new window policy is declared.

## Exact predecessor composition

The renderer and menu-builder preimages are the exact reviewed uninstall V3 private postimages (`399983dc…` and `67ee49ef…`). They are NOT the current canonical renderer/menu-builder bytes (`54a993a0…` and `adb26469…`). The numeric fixture preimage is current canonical `29060ed6…`. Root must first adopt the exact uninstall predecessor, or explicitly compose its proven hunk into any newly qualified Source and review receiving pins. `SOURCE.patch` is relative to these exact future preimages. The command-caption receiver, complete uninstall V3 addition and all other renderer/menu-builder bytes are unchanged by the exact inverse recorded in `SOURCE-PRESERVATION.json`.

## Actual shared admission and late read

`group_caption_receiver` uses the existing actual manifest root, unique native-visible item selector, and `reasoned_group_snapshot/current` functions. The captured row must be a simple translated real group. Formatted/native/decorated captions are refused rather than silently interpreted by this receiver. The owning rows and platform lists must be plain dense data. No native row allocation occurs.

The API captures the actual group factory, its own translator `get`, the exact translator metatable identity, owning source records and unique selected row. It compares captured owners and Source both before and after the actual late translation read. Unlike the separate command receiver, the new API admits a captured i18n facade with a stable metatable when `get` is an OWN raw function. This is necessary for the existing owning fixture's actual locale facade; the method invokes only that raw captured getter, never an inherited method. Replacing the metatable or own getter withdraws authority. This is not a change to command receiver admission.

The Linux producer additionally pins the actual `package.loaded` table, manifest facade and i18n facade identities, so a retained old factory cannot admit a replacement export on this concrete route. The real trigger group builder captures its declaration before its existing preset business work. At activation, the existing missing-prompt branch remains exact, the original `Prompt.ask` field is captured before title argument evaluation, and Source/facade admission precedes and follows that translated read. A final pure check precedes `ask(request, ctx.webview)`.

The original numeric bounds, hint, current delay, native bridge, ignored prompt return and complete `on_save` function remain exact. Refusal returns `false` before ask with no configuration write, redraw or native allocation. On admitted delivery, existing nil action return and writer/redraw behavior remain as before. This tranche grants no new authorization to a saved `on_save` callback after a later Source change; all its original behavior is retained and remains owned by G4.

## Existing owning tests and causal controls

The complete original fixture is an exact byte prefix (59 existing assertion-opening lines). The existing independent numeric-tail corpus is unchanged. The new suffix has 43 assertion-opening lines and a Source-derived floor of 32 new subjects: original 21 captions with unchanged request fields; actual fresh group declaration key authority; five held-field withdrawals and repairs; owning-section withdrawal and repair; actual late translated value; genuine captured-get locale-table read reentry; and two captured-owner replacements with zero foreign observation and exact repair.

The existing fixture creates real manifest/renderer instances and actual temporary config/writer/settings/trigger modules. Its prompt recorder is an explicit presentation port double; it is NOT native window evidence. The reentry control keeps the captured translator function unchanged and uses the real function's locale-table lookup to withdraw the actual group declaration during translation, then repairs that exact field and locale table before reusing the same callback. Local field/metatable restoration runs through protected exercise and rethrows its original assertion value; the entire existing cache/file cleanup owner remains unchanged.

`ORIGINAL-21-CAPTIONS-BEFORE-IMPLEMENTATION.json` contains handwritten exact group caption literals checked and pinned against the old physical locale files before the API/producer Source was authored. The same independent literals are in the additive fixture. No implementation generated or regenerated expectations.

A genuine predecessor control must pair the NEW fixture with the original group-less renderer and original debounce title producer (preserving the qualified uninstall predecessor where applicable). In particular, fresh actual declaration-key authority, held changed-group refusal, owner replacement refusal and actual translation-read Source reentry must fail for concrete old behavior. No uniform failure count or green caption-only floor is predicted. The exact old assertions must still pass. Root must inspect actual failures and repair inverse under serial Source custody.

## Required receiving and limitations

After custody, adoption, ordinary formatting and Source pin recapture, run the genuine Linux launcher with `--only=trigger-declared-page-caption` to verify the actual 32-subject registration/floor; the existing runner uses one plain substring filter. Full selected Linux verifies all original numeric writer/refusal/cancellation/bounds tests and the appended cases. Root uses `verify-change` for format, complete JS parity/conventions, shared Lua macOS and Linux coverage, and the applicable E2E gates. No generator is needed for these Source edits; the owning native-menu baseline must be regenerated by its normal owner if this receiving seam changes the genuine source census.

The shared Lua API is available to macOS without changing its business producer. AHK has no corresponding Source edit in this packet. Do not claim Windows or macOS physical/native behavior or equivalence from the Linux recorder. Installation/native-window acceptance and TODO 16/38/54/81 remain separate. This candidate has no executed software/native proof yet, no claimed census reduction and no claim that the residual menu migration is complete.
