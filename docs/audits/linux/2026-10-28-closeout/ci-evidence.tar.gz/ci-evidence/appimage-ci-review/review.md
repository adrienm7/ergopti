# AppImage installed-layout receiver: proposed reserved CI exception

The actual workflow run 40766890057 on source55 failed in the installed-layout
receiver because it invoked the image's LuaJIT with LUA_PATH alone. The same
image had already passed its normal tray startup and the glibc distribution
sweep. Its canonical AppRun sources network-runtime-env.sh before invoking LuaJIT;
that owner exports LUA_CPATH and the native library/GIO/schema environment.
The installed-layout receiver bypasses it, so infra.native_directory cannot
load the genuine bundled luv binding. The package carries that binding.

The unapplied one-line patch replaces the receiver's manual LUA_PATH export
with the exact canonical native environment owner already used by AppRun.
It retains the bundled interpreter, expected shared root, all file and locale
assertions, step name, role, matrix and failure behavior. No test is skipped,
relaxed or made conditional. RPM is a separate real packaging dependency bug
and is being corrected independently in an owned worktree.

This changes .github/workflows/ci-linux.yml, which the user's instruction
explicitly reserves. No workflow source has been edited; the patch is pending
an explicit exception. After approval, run the protected workflow's existing
contract checks unmodified, formatting/conventions/generation and one complete
CI batch for the corrected source. Do not raise a baseline or edit tools/ci.

Patch: canonical-native-env-unapplied.patch
Proof: the preserved actual decoded job123113887327 log and terminal.json,
under ../ci-preparation/55a50835be9e027ec9cbe43ac5d1c693c6ff711f/.
Canonical owner: tools/build/templates/linux-portable-runtime-env.sh;
actual caller: tools/build/build-linux-appimage.sh AppRun stanza.
