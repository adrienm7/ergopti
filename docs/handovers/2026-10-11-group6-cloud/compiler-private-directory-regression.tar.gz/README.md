# Private compiler directory regression receiving

The unchanged independent ten-case Swift dependency test refuses baseline mode
0755 under022 and0777 under000, while077 passes. The actual CI old image under
its unmeasured umask reports0755. The same ten cases pass after the explicit
private include directory creation under all three controlled umasks.

The patch creates only the existing owned CPOSIXCompatibility directory with
0700 then chmod0700 before the original header loop. Removing exactly three
added lines restores the whole original builder. All independent assertions,
recipes, commands, clocks and source/image receipts remain unchanged. Compiler
and native Security calls are modeled in this portable test; no native credit.
