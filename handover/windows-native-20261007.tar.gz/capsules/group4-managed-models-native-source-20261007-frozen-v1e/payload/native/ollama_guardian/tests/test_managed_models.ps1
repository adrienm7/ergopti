# native/ollama_guardian/tests/test_managed_models.ps1
# Receiving controls use actual private directory/file capabilities; no daemon.
[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$FilesHelper,
	[Parameter(Mandatory = $true)][string]$FilesHash,
	[Parameter(Mandatory = $true)][string]$OwnedRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$held = [Collections.Generic.List[object]]::new()
$receipts = [Collections.Generic.List[object]]::new()
function Assert-ModelsTest([bool]$Condition, [string]$Reason) {
	if (-not $Condition) { throw $Reason }
}
function Refuse-ModelsTest([scriptblock]$Action, [string]$Reason) {
	$refused = $false
	try { & $Action | Out-Null } catch { $refused = $true }
	Assert-ModelsTest $refused $Reason
}
function New-ModelsTestRoot {
	$root = Open-OllamaManagedRoot $OwnedRoot $true
	$held.Add($root)
	return $root
}
try {
	if ($PSVersionTable.PSVersion.Major -ne 5 -or [IntPtr]::Size -ne 8) { throw 'These receiving controls require Windows PowerShell 5.1 x64.' }
	$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
	$code = [IO.FileStream]::new($FilesHelper, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
	$hasher = [Security.Cryptography.SHA256]::Create()
	try {
		$actual = [BitConverter]::ToString($hasher.ComputeHash($code)).Replace('-', '').ToLowerInvariant()
		Assert-ModelsTest ($actual -ceq $FilesHash) 'The models receiving helper pin differs.'
	} finally { $hasher.Dispose(); $code.Position = 0 }
	# The source pin stays continuously held through every native receiving control.
	. $FilesHelper
	Initialize-OllamaManagedNative
	Assert-ModelsTest ([Ergopti.Ollama.ManagedNative]::PathIsAbsent($OwnedRoot)) 'The models test requires a fresh exclusive selected Root.'
	$root = New-ModelsTestRoot
	$ticket = [Guid]::NewGuid().ToString('N')
	$archive = @{ version = 'models-fixture'; asset = 'synthetic';
		pin = @{ sha256 = ('0' * 64) }; catalogue_sha256 = ('1' * 64) }
	$wal = Begin-OllamaCreationWal $root $archive $ticket
	$modelsPath = [IO.Path]::Combine($OwnedRoot, 'model-data')
	$models = Open-OllamaManagedModels $root $modelsPath 'model-data' $true $wal
	Assert-ModelsTest ($models.phase -ceq 'held') 'The real models acquisition did not reach held.'
	Assert-ModelsTest ($root.handles.Contains($models.handle)) 'The directory capability escaped its raw Root ledger.'
	Assert-ModelsTest ($models.identity -ceq [Ergopti.Ollama.ManagedNative]::DirectoryIdentity($models.handle)) 'The acquired models identity differs.'
	Assert-ModelsTest ([StringComparer]::OrdinalIgnoreCase.Equals($models.path,
		[IO.Path]::Combine([Ergopti.Ollama.ManagedNative]::FinalPath($root.root_handle), 'model-data'))) 'The native models parent/leaf differs.'
	$receipts.Add(@{ control = 'models-created-owned'; admitted = $true })
	Refuse-ModelsTest { [IO.Directory]::Move($models.path, $models.path + '-renamed') } 'The retained models directory accepted replacement/rename.'
	$receipts.Add(@{ control = 'models-retained-rename-refused'; admitted = $true })
	# Model contents stay mutable; the lease protects the directory identity only.
	$data = [IO.Path]::Combine($models.path, 'mutable-model.fixture')
	[IO.File]::WriteAllBytes($data, [byte[]]@(1, 2, 3))
	[IO.File]::WriteAllBytes($data, [byte[]]@(4, 5))
	Assert-ModelsTest ([Convert]::ToBase64String([IO.File]::ReadAllBytes($data)) -ceq 'BAU=') 'A directory lease accidentally claimed immutable model contents.'
	$receipts.Add(@{ control = 'models-data-remains-mutable'; admitted = $true })
	Refuse-ModelsTest { Open-OllamaManagedModels $root $modelsPath 'model-data' $false $null } 'Duplicate acquisition replaced the original models owner.'
	Assert-ModelsTest ([object]::ReferenceEquals($root.models, $models)) 'Duplicate refusal replaced the exact original owner.'
	$receipts.Add(@{ control = 'models-duplicate-owner-refused'; admitted = $true })
	Close-OllamaManagedRoot $root
	$reopened = New-ModelsTestRoot
	$verified = Open-OllamaManagedModels $reopened $modelsPath 'model-data' $false $null
	Assert-ModelsTest ($verified.identity -ceq $models.identity) 'Existing models provenance admitted another FileID.'
	$receipts.Add(@{ control = 'models-existing-provenance'; admitted = $true })
	Close-OllamaManagedRoot $reopened
	$markerRoot = New-ModelsTestRoot
	$markerPath = [IO.Path]::Combine([Ergopti.Ollama.ManagedNative]::FinalPath($markerRoot.root_handle), '.models-owner-model-data.json')
	$originalMarker = [IO.File]::ReadAllBytes($markerPath)
	Close-OllamaManagedRoot $markerRoot
	foreach ($field in @('kind', 'owner_sid', 'root_identity', 'identity', 'leaf')) {
		foreach ($singleton in @($false, $true)) {
			$candidate = [Text.UTF8Encoding]::new($false, $true).GetString($originalMarker) | ConvertFrom-Json
			$expected = $candidate.$field
			$candidate.$field = if ($singleton) { ,([object[]]@($expected)) } else { ,([object[]]@()) }
			[IO.File]::WriteAllBytes($markerPath, [Text.UTF8Encoding]::new($false, $true).GetBytes(($candidate | ConvertTo-Json -Compress) + "`n"))
			$typedRoot = New-ModelsTestRoot
			try {
				Refuse-ModelsTest { Open-OllamaManagedModels $typedRoot $modelsPath 'model-data' $false $null } 'A collection-shaped ownership field was admitted as a scalar.'
				Assert-ModelsTest ($typedRoot.models.phase -ceq 'retained-debt') 'Typed marker refusal lost its real acquisition owner.'
			} finally {
				Close-OllamaManagedRoot $typedRoot
				[IO.File]::WriteAllBytes($markerPath, $originalMarker)
			}
		}
	}
	$receipts.Add(@{ control = 'models-receipt-field-types-refused'; admitted = $true })
	# A real existing directory without the typed receipt must never be adopted
	# or re-ACL'd. A fresh Root row owns partial raw acquisitions on refusal.
	$untrusted = [IO.Path]::Combine($OwnedRoot, 'missing-receipt')
	[Ergopti.Ollama.ManagedNative]::CreateProtectedDirectory($untrusted, (New-OllamaPrivateSecurity).GetSecurityDescriptorBinaryForm())
	$before = [IO.Directory]::GetAccessControl($untrusted).GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::All)
	$refusalRoot = New-ModelsTestRoot
	Refuse-ModelsTest { Open-OllamaManagedModels $refusalRoot $untrusted 'missing-receipt' $false $null } 'An unreceipted models directory was adopted.'
	Assert-ModelsTest ($refusalRoot.models.phase -ceq 'retained-debt' -and $refusalRoot.models.first_error -ne '') 'Partial acquisition refusal lost its owner/diagnostic.'
	Assert-ModelsTest ($refusalRoot.handles.Count -gt 0) 'Partial raw capabilities were discarded.'
	Assert-ModelsTest ($before -ceq [IO.Directory]::GetAccessControl($untrusted).GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::All)) 'Refusal silently changed an existing directory ACL.'
	$receipts.Add(@{ control = 'models-unreceipted-refused'; admitted = $true })
	Close-OllamaManagedRoot $refusalRoot
	$foreignRoot = New-ModelsTestRoot
	$foreign = [IO.Path]::Combine([IO.Path]::GetDirectoryName($OwnedRoot), 'foreign-models-' + $ticket)
	Refuse-ModelsTest { Open-OllamaManagedModels $foreignRoot $foreign ([IO.Path]::GetFileName($foreign)) $true $wal } 'An outside Root models target was admitted.'
	Assert-ModelsTest (-not [IO.Directory]::Exists($foreign)) 'Foreign namespace effects occurred before Root admission.'
	Assert-ModelsTest ($foreignRoot.models.phase -ceq 'retained-debt') 'Foreign parent refusal lost the acquisition owner.'
	$receipts.Add(@{ control = 'models-foreign-parent-refused'; admitted = $true })
	Close-OllamaManagedRoot $foreignRoot
	$policyRoot = New-ModelsTestRoot
	Refuse-ModelsTest { Open-OllamaManagedModels $policyRoot ([IO.Path]::Combine($OwnedRoot, 'versions')) 'versions' $true $wal } 'The immutable versions subtree became mutable model data.'
	Assert-ModelsTest (-not $policyRoot.ContainsKey('models')) 'Invalid leaf acquisition crossed the native-effect boundary.'
	$receipts.Add(@{ control = 'models-reserved-policy-refused'; admitted = $true })
	foreach ($row in $receipts) { [Console]::Out.WriteLine(($row | ConvertTo-Json -Compress)) }
	$wal.stream.Dispose()
	foreach ($owned in $held) { Close-OllamaManagedRoot $owned }
	$code.Dispose()
	exit 0
} catch {
	# Any failed native close/acquisition remains in the exact live process until
	# its natural terminal; no path cleanup/reopen/foreign directory deletion.
	[Console]::Error.WriteLine('Models native receiving refused: ' + $_.Exception.Message)
	exit 1
}