for (const [script, expected] of cases) {
	const result = spawnSync(pythonExecutable(), [script], {
		cwd: path.resolve(__dirname, '../..'),
		encoding: 'utf8',
		timeout: 60000
	});
	// Preserve child output before the original spawn assertions reject it.
	// Optional diagnostics cannot replace the original failure or extend its budget.
	if (result.error || result.signal !== null || result.status !== 0) {
		try {
			process.stderr.write(
				`PORTABLE_RECEIVER_FAILURE ${JSON.stringify({
					script,
					status: result.status,
					signal: result.signal,
					error_code: result.error?.code || null,
					stdout_tail: typeof result.stdout === 'string' ? result.stdout.slice(-8192) : '',
					stderr_tail: typeof result.stderr === 'string' ? result.stderr.slice(-8192) : '',
					native_qualified: false
				})}\n`
			);
		} catch {
			// A failed diagnostic sink leaves every original assertion authoritative.
		}
	}
	assert.equal(result.error, undefined, 'the portable receiver must start');
	assert.equal(result.signal, null, 'the portable receiver must retire');
	assert.equal(result.status, 0, result.stderr || result.stdout);
	assert.match(
		result.stderr,
		new RegExp(`Ran ${expected} ${expected === 1 ? 'test' : 'tests'} in`)
	);
	assert.match(result.stderr, /\bOK\b/);
	assert.doesNotMatch(result.stderr, /skipped=/);
	process.stdout.write(result.stdout);
	process.stdout.write(result.stderr);
}
