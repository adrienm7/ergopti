﻿; Private bounded producer observation; every GUI and process is owned.
_R6AppId_NativeIdentity(Name) {
	OutputDir := EnvGet("ERGOPTI_R6_APP_ID_DIR")
	AssertTrue(OutputDir != "" && DirExist(OutputDir))
	Image := OutputDir . "\" . Name
	Actor := OutputDir . "\actor.ahk"
	Handle := 0
	ThreadHandle := 0
	Hwnd := 0
	try {
		AssertFalse(FileExist(Image), "the probe image path must be unowned before creation")
		FileCopy(A_AhkPath, Image)
		Command := '"' . Image . '" /ErrorStdOut=UTF-8 "' . Actor . '"'
		CommandBuffer := Buffer((StrLen(Command) + 1) * 2, 0)
		StrPut(Command, CommandBuffer, "UTF-16")
		Startup := Buffer(104, 0)
		NumPut("UInt", Startup.Size, Startup)
		ProcessInfo := Buffer(24, 0)
		AssertTrue(DllCall("Kernel32\CreateProcessW", "WStr", Image, "Ptr", CommandBuffer,
			"Ptr", 0, "Ptr", 0, "Int", false, "UInt", 0, "Ptr", 0,
			"WStr", OutputDir, "Ptr", Startup, "Ptr", ProcessInfo, "Int"),
			"Win32 must launch the exact extensionless owned PE image")
		Handle := NumGet(ProcessInfo, 0, "Ptr")
		ThreadHandle := NumGet(ProcessInfo, 8, "Ptr")
		Pid := NumGet(ProcessInfo, 16, "UInt")
		DllCall("Kernel32\CloseHandle", "Ptr", ThreadHandle)
		ThreadHandle := 0
		Hwnd := WinWait("ahk_pid " . Pid . " ahk_class AutoHotkeyGUI", , 8)
		AssertTrue(Hwnd != 0, "the exact owned process must create its own native GUI")
		WinActivate("ahk_id " . Hwnd)
		AssertTrue(WinWaitActive("ahk_id " . Hwnd, , 5) != 0)
		Info := WIGetFocused()
		Foreground := PLC_GetForegroundApp()
		Bounded := WICaptureBoundedFocusSnapshot()
		AssertTrue(Bounded.ok, "the resident metrics acquisition must admit the owned foreground")
		AssertEqual(Name, Bounded.process_name, "the canonical metrics focus producer preserves extensionless identity")
		AssertEqual(Name, WinGetProcessName("ahk_id " . Hwnd), "native Windows process-name API preserves extensionless identity")
		AssertEqual(Name, Info["appId"], "actual WindowInfo ingress retains the native app ID")
		AssertEqual(Name, Foreground["appId"], "actual lifecycle ingress retains the native app ID")
		FileAppend("NATIVE_EXTENSIONLESS_APP " . Name . " pid=" . Pid
			. " window_info=" . Info["appId"] . " lifecycle=" . Foreground["appId"] . "`n", "*")
		return Bounded.process_name
	} finally {
		AssertTrue(_WIResetFocusProcessCache(), "retire the canonical focus process handle")
		if Hwnd && WinExist("ahk_id " . Hwnd)
			WinClose("ahk_id " . Hwnd)
		if Handle {
			if DllCall("Kernel32\WaitForSingleObject", "Ptr", Handle, "UInt", 3000, "UInt") != 0 {
				AssertTrue(DllCall("Kernel32\TerminateProcess", "Ptr", Handle, "UInt", 0))
				AssertEqual(0, DllCall("Kernel32\WaitForSingleObject", "Ptr", Handle, "UInt", 3000, "UInt"))
			}
			AssertTrue(DllCall("Kernel32\CloseHandle", "Ptr", Handle))
		}
		if ThreadHandle
			DllCall("Kernel32\CloseHandle", "Ptr", ThreadHandle)
		if FileExist(Image)
			FileDelete(Image)
	}
}
_R6Pair_InsertHistory(Db, Names, Day) {
	Walk := [1, 2, 1, 2, 3, 4, 3, 4, 3, 4]
	Typed := Map()
	for Index, Slot in Walk {
		Timestamp := Day . " 12:00:00." . Format("{:03d}", (Index - 1) * 100)
		App := Names[Slot]
		if Index > 1 {
			Entry := Map("type", "app_switch", "timestamp", Timestamp,
				"prev_app", Names[Walk[Index - 1]], "next_app", App, "duration_ms", 100)
			for Sql in KL_BuildInserts(Entry) {
				AssertTrue(Sql != "", "the real raw switch builder must emit a statement")
				AssertTrue(SQLite_Exec(Db, Sql))
			}
		}
		if !Typed.Has(Slot) {
			Entry := Map("type", "typing", "timestamp", Timestamp, "app", App, "text", "x",
				"events", [["x", 100, Map("st", "none")]])
			for Sql in KL_BuildInserts(Entry) {
				AssertTrue(Sql != "", "the real raw typing builder must emit a statement")
				AssertTrue(SQLite_Exec(Db, Sql))
			}
			Typed[Slot] := true
		}
	}
}
_R6Pair_ActualNamesAndStorage() {
	Names := []
	for Name in ["a", "b ↔ c", "a ↔ b", "c"]
		Names.Push(_R6AppId_NativeIdentity(Name))
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	SavedDevice := Keystats.device_id
	SavedLiteral := Keystats._device_id_lit
	SavedId := Keystats.next_event_id
	Db := 0
	try {
		KLW.ctx := Map()
		KLW_ResetBatch()
		Keystats.device_id := "pair-proof"
		Keystats._device_id_lit := SQLite_Q(Keystats.device_id)
		Keystats.next_event_id := 1
		Db := _KLRShortcut_OpenFixture()
		OutputDir := EnvGet("ERGOPTI_R6_APP_ID_DIR")
		for Index, Day in ["2026-10-26", "2026-10-27"] {
			_R6Pair_InsertHistory(Db, Names, Day)
			AssertTrue(KLR_PrepareTypingProjection(Db))
			AssertTrue(KLR_ClearAggregates(Db))
			AssertTrue(KLR_RebuildAggregates(Db))
			AssertEqual(4 * Index, KLR_RebuildWalkerAggregates(Db, true),
				"the logical replay owns typing while SQL rollups own app switches")
			AssertEqual(4 * Index, SQLite_Query(Db, "SELECT COUNT(*) AS n FROM events_typing;")[1]["n"])
			AssertEqual(9 * Index, SQLite_Query(Db, "SELECT COUNT(*) AS n FROM events_app_switch;")[1]["n"])
			Raw := KLR_BuildManifestJson(Db, "2026-10-26", Day)
			Manifest := JsonParse(Raw)
			for ProbeDay, Apps in Manifest {
				AssertEqual(1, Apps[Names[1]]["chars"])
				AssertEqual(2, Apps[Names[1]]["switches_to"][Names[2]])
				AssertEqual(1, Apps[Names[2]]["switches_to"][Names[1]])
				AssertEqual(1, Apps[Names[2]]["switches_to"][Names[3]])
				AssertEqual(3, Apps[Names[3]]["switches_to"][Names[4]])
				AssertEqual(2, Apps[Names[4]]["switches_to"][Names[3]])
			}
			FileAppend('{"names":' . KL_JsonEncode(Names) . ',"days":' . Index
				. ',"expected_top_count":' . (5 * Index) . ',"manifest":' . Raw
				. ',"range":{"historical":' . KLR_BuildNgramsJson(Db, "2026-10-26", Day, Names)
				. ',"today":{}}}', OutputDir . "\history-" . Index . ".json", "UTF-8-RAW")
			FileAppend("NATIVE_STRUCTURED_APP_PAIRS days=" . Index . " pair_ab=" . (3 * Index)
				. " pair_cd=" . (5 * Index) . " bridge_bc=" . Index . "`n", "*")
		}
	} finally {
		if Db
			SQLite_Close(Db)
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
		Keystats.device_id := SavedDevice
		Keystats._device_id_lit := SavedLiteral
		Keystats.next_event_id := SavedId
	}
}
Test("audit: actual native app names preserve separate workflow pairs (r6-native-structured-pairs)",
	_R6Pair_ActualNamesAndStorage)
