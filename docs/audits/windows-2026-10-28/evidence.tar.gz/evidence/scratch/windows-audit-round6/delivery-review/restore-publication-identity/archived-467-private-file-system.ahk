﻿; adapters/file_system.ahk

#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\infra\file_read_activity.ahk

; ==============================================================================
; MODULE: FileSystem Adapter (AutoHotkey)
; DESCRIPTION:
; AHK v2 implementation of the FileSystem port contract defined in
; static/ergopti_plus/_shared/core/ports/FileSystem.spec.js. Wraps AHK v2's
; FileRead, FileOpen, FileExist, and FileDelete built-ins behind the five
; canonical functions (FSRead, FSWrite, FSAppend, FSExists, FSDelete) so
; domain modules perform file I/O without coupling to AHK-specific APIs.
;
; NAMING CONVENTION:
; Port method → AHK name mapping:
;   read(path)           → FSRead(Path)
;   write(path, content) → FSWrite(Path, Content)
;   append(path, content)→ FSAppend(Path, Content)
;   exists(path)         → FSExists(Path)
;   delete(path)         → FSDelete(Path)
;
; ENCODING:
; AHK v2 FileRead and FileOpen default to UTF-8 when the file has a BOM.
; FSRead and FSWrite explicitly pass the "UTF-8" encoding flag to FileOpen
; so all operations are UTF-8 regardless of the system ANSI code page.
; ==============================================================================




; =======================================================
; =======================================================
; ======= 1/ Adapter Methods ============================
; =======================================================
; =======================================================

; Windows path APIs, and the AHK built-ins over them, read a caller String
; only up to its first NUL code unit: "a.txt" NUL "x" names a.txt, so a refused
; delete removed that prefix file and a refused read returned its bytes. Every
; entry below admits a path through this check before any native call.
; @param Path {Any} Caller value.
; @return {Boolean} True only for a non-empty String without a NUL code unit.
FSPathIsAdmissible(Path) {
	return Path is String && Path != "" && !RegExMatch(Path, "\x00")
}

; Strict entries refuse an inadmissible path with an exception, as they do for
; every other native failure; the message never repeats the refused bytes.
_FSRequirePath(Path, Operation) {
	if !FSPathIsAdmissible(Path)
		throw ValueError(Operation . " requires a non-empty path without NUL.")
}

; Reads UTF-8 text using AHK's BOM handling and preserves native read failures.
; @param Path {String} File path.
; @return {String} Text contents; throws when the read fails.
FSReadStrict(Path) {
	_FSRequirePath(Path, "A strict read")
	return FileRead(Path, "UTF-8")
}

; Reads a file's raw bytes and preserves native read failures.
; @param Path {String} File path.
; @return {Buffer} The bytes; throws when the read fails.
FSReadBytesStrict(Path) {
	_FSRequirePath(Path, "A strict byte read")
	return FileRead(Path, "RAW")
}

; Opens an owned native file without changing flags, encoding, or failure behavior.
; @param Path {String} File path.
; @param Flags {String|Integer} Native access, sharing and translation flags.
; @param Encoding {String} Optional encoding; omission retains the native default.
; @return {File|0} Native file result; native exceptions remain visible.
FSOpenStrict(Path, Flags, Encoding := unset) {
	_FSRequirePath(Path, "A strict open")
	if IsSet(Encoding)
		return FileOpen(Path, Flags, Encoding)
	return FileOpen(Path, Flags)
}

; Reads the entire contents of a file as a UTF-8 string.
; @param Path {String} Absolute path to the file.
; @return {String|false} File contents on success, false on any error.
FSRead(Path) {
	if !FSPathIsAdmissible(Path)
		return false
	try {
		local FH := FileOpen(Path, "r", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		local Content := FH.Read()
		FH.Close()
		return Content
	} catch {
		return false
	}
}

; Writes content to a file, overwriting any existing content.
; Creates the file if it does not exist.
; @param Path    {String} Absolute path to the file.
; @param Content {String} UTF-8 content to write.
; @param OpenFn   {Func|0} Optional deterministic open seam for tests.
; @param DeleteFn {Func|0} Optional deterministic cleanup seam for tests.
; @param WriteFn  {Func|0} Optional native write seam for tests.
; @return {Boolean} True on success, false on error.
FSWrite(Path, Content, OpenFn := 0, DeleteFn := 0, WriteFn := 0) {
	ResolvedOpen := HasMethod(OpenFn, "Call") ? OpenFn : FileOpen
	ResolvedDelete := HasMethod(DeleteFn, "Call") ? DeleteFn : FileDelete
	return _FSWriteComplete(Path, Content, ResolvedOpen, ResolvedDelete, WriteFn)
}

; Owns a write from the first successful open through either a complete close or
; deletion of the partial artifact. OpenFn/DeleteFn make the short-write boundary
; deterministic in tests without weakening the public FileSystem port.
_FSWriteComplete(Path, Content, OpenFn, DeleteFn, WriteFn := 0) {
	if !FSPathIsAdmissible(Path)
		return false
	if !(Content is String)
		Content := ""
	FH := 0
	Opened := false
	Succeeded := false
	try {
		FH := OpenFn.Call(Path, "w", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		Opened := true
		if !_FSWriteUtf8Bytes(FH, Content, WriteFn)
			return false
		FH.Close()
		FH := 0
		Succeeded := true
		return true
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
		if Opened && !Succeeded
			try DeleteFn.Call(Path)
	}
}

; Writes a complete control artifact and flushes its handle before returning.
; Atomic protocols still validate the stage and publish it with
; FSAtomicMoveReplace; this helper only makes the stage bytes durable.
FSWriteDurable(Path, Content, OpenFn := 0, DeleteFn := 0, FlushFn := 0, WriteFn := 0) {
	ResolvedOpen := HasMethod(OpenFn, "Call") ? OpenFn : FileOpen
	ResolvedDelete := HasMethod(DeleteFn, "Call") ? DeleteFn : FileDelete
	ResolvedFlush := HasMethod(FlushFn, "Call") ? FlushFn : FSFlushFileBuffers
	return _FSWriteDurableComplete(Path, Content, ResolvedOpen, ResolvedDelete,
		ResolvedFlush, WriteFn)
}

_FSWriteDurableComplete(Path, Content, OpenFn, DeleteFn, FlushFn, WriteFn := 0) {
	if !FSPathIsAdmissible(Path)
		return false
	if !(Content is String)
		Content := ""
	FH := 0
	Opened := false
	Succeeded := false
	try {
		FH := OpenFn.Call(Path, "w", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		Opened := true
		if !_FSWriteUtf8Bytes(FH, Content, WriteFn)
			return false
		if FlushFn.Call(FH) != true
			throw Error("flush failed")
		FH.Close()
		FH := 0
		Succeeded := true
		return true
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
		if Opened && !Succeeded
			try DeleteFn.Call(Path)
	}
}

; Creates a private UTF-8 control artifact without ever replacing an existing
; path, then flushes its bytes before reporting success. ``FileOpen(..., "w")``
; cannot express CREATE_NEW and a probe followed by a write is a TOCTOU race,
; so the transaction journal uses this Windows-only helper outside the portable
; FileSystem port. A failed partial creation is removed only when this call
; actually created it; a collision is byte-preserving.
FSWriteCreateDurable(Path, Content) {
	if !FSPathIsAdmissible(Path) or !(Content is String)
		return 0
	static GENERIC_WRITE := 0x40000000
	static CREATE_NEW := 1
	static FILE_ATTRIBUTE_NORMAL := 0x00000080
	static FILE_FLAG_WRITE_THROUGH := 0x80000000
	Handle := -1
	Created := false
	Succeeded := false
	try {
		Handle := DllCall("kernel32\CreateFileW",
			"Str", Path,
			"UInt", GENERIC_WRITE,
			"UInt", 0,
			"Ptr", 0,
			"UInt", CREATE_NEW,
			"UInt", FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH,
			"Ptr", 0,
			"Ptr")
		if (Handle == -1)
			return 0
		Created := true
		ByteCount := StrPut(Content, "UTF-8") - 1
		Utf8 := Buffer(ByteCount + 1, 0)
		if (ByteCount > 0)
			StrPut(Content, Utf8, ByteCount + 1, "UTF-8")
		Offset := 0
		while (Offset < ByteCount) {
			Written := 0
			if !DllCall("kernel32\WriteFile",
					"Ptr", Handle,
					"Ptr", Utf8.Ptr + Offset,
					"UInt", ByteCount - Offset,
					"UInt*", &Written,
					"Ptr", 0,
					"Int") or Written <= 0
				return 0
			Offset += Written
		}
		if !DllCall("kernel32\FlushFileBuffers", "Ptr", Handle, "Int")
			return 0
		Succeeded := true
		return 1
	} catch {
		return 0
	} finally {
		if (Handle != -1)
			try DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int")
		if Created && !Succeeded
			try DllCall("kernel32\DeleteFileW", "Str", Path, "Int")
	}
}

; Flushes one already-open writable file handle to stable storage. Callers use
; this before an atomic rename when the rename itself is a durable protocol
; boundary. The File object owns and closes the handle; this adapter only asks
; Windows to persist its buffered bytes.
FSFlushFileBuffers(FileObject) {
	if !IsObject(FileObject)
		return false
	try return DllCall("FlushFileBuffers", "Ptr", FileObject.Handle,
		"Int") != 0
	catch
		return false
}

; Appends content to a file, creating it if it does not exist.
; @param Path    {String} Absolute path to the file.
; @param Content {String} UTF-8 content to append.
; @return {Boolean} True on success, false on error.
FSAppend(Path, Content) {
	return _FSAppendComplete(Path, Content, FileOpen)
}

; Completes an append only when Windows accepts every encoded UTF-8 byte.
; Unlike an overwrite stage, a partially appended user file cannot be safely
; deleted or rolled back, so callers must receive failure and retain ownership.
_FSAppendComplete(Path, Content, OpenFn, WriteFn := 0) {
	if !FSPathIsAdmissible(Path)
		return false
	if !(Content is String)
		Content := ""
	FH := 0
	try {
		FH := OpenFn.Call(Path, "a", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		if !_FSWriteUtf8Bytes(FH, Content, WriteFn)
			return false
		FH.Close()
		FH := 0
		return true
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
	}
}

; Only use with a newly opened UTF-8 file, before any buffered text writes.
; Both File.Write and RawWrite buffer small blocks; Close and Handle discard
; buffer-flush failures. WriteFile checks the actual OS receipt instead. Keep
; this primitive logger-free so filesystem failures cannot recurse into logging.
_FSWriteUtf8Bytes(FileObject, Content, WriteFn := 0) {
	if FileObject.Encoding != "UTF-8"
		return false
	ByteCount := StrPut(Content, "UTF-8") - 1
	if ByteCount = 0
		return true
	Utf8 := Buffer(ByteCount + 1, 0)
	StrPut(Content, Utf8, ByteCount + 1, "UTF-8")
	Written := 0
	ResolvedWrite := HasMethod(WriteFn, "Call") ? WriteFn : _FSNativeWrite
	return ResolvedWrite.Call(FileObject.Handle, Utf8, ByteCount, &Written)
		&& Written = ByteCount
}

_FSNativeWrite(Handle, Bytes, ByteCount, &Written) {
	return DllCall("WriteFile", "Ptr", Handle, "Ptr", Bytes,
		"UInt", ByteCount, "UInt*", &Written, "Ptr", 0, "Int") != 0
}

; Returns true if a file or directory exists at the given path, false otherwise.
; @param Path {String} Absolute path to test.
; @return {Boolean} True on success, false on error.
FSExists(Path) {
	if !FSPathIsAdmissible(Path)
		return false
	; FileExist returns a non-empty attribute string on match, "" on miss
	return FileExist(Path) != "" ? true : false
}

; Strict file existence for recovery protocols. Only the two Windows
; not-found statuses mean absence; access, device, or filesystem errors throw
; so recovery never mistakes "could not inspect" for "does not exist".
FSStrictExists(Path) {
	if !FSPathIsAdmissible(Path)
		throw ValueError("A strict existence probe requires a non-empty path without NUL.")
	Attributes := DllCall("kernel32\GetFileAttributesW", "Str", Path, "UInt")
	if (Attributes != 0xFFFFFFFF)
		return 1
	ErrorCode := A_LastError
	if (ErrorCode == 2 || ErrorCode == 3)
		return 0
	throw OSError(ErrorCode, A_ThisFunc,
		"GetFileAttributesW failed for '" . Path . "'.")
}

/**
 * Enumerates one directory without treating access or device failures as absence.
 * @param {String} Path - Directory path; proven optional absence yields no entries.
 * @param {Integer} Directories - True selects directories, false regular entries.
 * @returns {Array} Absolute child paths; dot entries are excluded.
 */
FSListDirectoryStrict(Path, Directories := false) {
	if !FSStrictExists(Path)
		return []
	if !DirExist(Path)
		throw ValueError("Directory enumeration requires a directory.")
	Data := Buffer(592, 0)
	Handle := DllCall("kernel32\FindFirstFileW", "Str", RTrim(Path, "\/") . "\*", "Ptr", Data, "Ptr")
	if Handle == -1 {
		ErrorCode := A_LastError
		if ErrorCode == 2
			return []
		throw OSError(ErrorCode, A_ThisFunc, "Directory enumeration could not start.")
	}
	Entries := []
	try {
		loop {
			Name := StrGet(Data.Ptr + 44, 260, "UTF-16")
			IsDirectory := (NumGet(Data, 0, "UInt") & 0x10) != 0
			if Name != "." && Name != ".." && IsDirectory == !!Directories
				Entries.Push(RTrim(Path, "\/") . "\" . Name)
			if !DllCall("kernel32\FindNextFileW", "Ptr", Handle, "Ptr", Data, "Int") {
				ErrorCode := A_LastError
				if ErrorCode != 18
					throw OSError(ErrorCode, A_ThisFunc, "Directory enumeration did not complete.")
				break
			}
		}
	} finally {
		if !DllCall("kernel32\FindClose", "Ptr", Handle, "Int")
			throw OSError(A_LastError, A_ThisFunc, "Directory enumeration handle did not close.")
	}
	return Entries
}

/**
 * Resolves an existing directory to an absolute long path without recasing it.
 * @param {String} Path - Existing directory without wildcard characters.
 * @returns {String} Absolute long path; volume roots keep their final separator.
 * @throws {Error|OSError} Missing directories or incomplete native resolution.
 */
FSResolveDirectoryPath(Path) {
	if !FSPathIsAdmissible(Path) || InStr(Path, "*") || InStr(Path, "?")
		throw Error("Startup working directory cannot be resolved")
	if !DirExist(Path)
		throw Error("Startup working directory does not exist")
	Size := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", 0, "Ptr", 0, "Ptr", 0, "UInt")
	if !Size
		throw OSError(A_LastError, A_ThisFunc)
	Full := Buffer(Size * 2)
	Written := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", Size,
		"Ptr", Full, "Ptr", 0, "UInt")
	if !Written || Written >= Size
		throw Error("Startup working directory resolution did not complete")
	Size := DllCall("kernel32\GetLongPathNameW", "Ptr", Full, "Ptr", 0, "UInt", 0, "UInt")
	if !Size
		throw OSError(A_LastError, A_ThisFunc)
	Long := Buffer(Size * 2)
	Written := DllCall("kernel32\GetLongPathNameW", "Ptr", Full, "Ptr", Long, "UInt", Size, "UInt")
	if !Written || Written >= Size
		throw Error("Startup working directory long-name resolution did not complete")
	Resolved := StrGet(Long)
	if RegExMatch(Resolved, "i)^[a-z]:\\$")
		return Resolved
	return RTrim(Resolved, "\")
}

; Creates one directory exclusively, without adopting existing paths or parents.
; @param Path {String} Non-empty directory path with an existing parent.
; @return {Boolean} True only after native exclusive creation succeeds.
; @throws {ValueError|OSError} Invalid paths and all native failures are explicit.
FSCreateDirectoryExclusiveStrict(Path) {
	if !FSPathIsAdmissible(Path)
		throw ValueError("Exclusive directory creation requires a non-empty path without NUL.")
	Created := DllCall("kernel32\CreateDirectoryW", "WStr", Path, "Ptr", 0, "Int")
	ErrorCode := A_LastError
	if !Created
		throw OSError(ErrorCode, A_ThisFunc, Path)
	return true
}

; Creates a directory, and its missing parents, when it does not exist.
; @param Path {String} Absolute directory path.
; @return {Boolean} True when it was created, false when it already existed.
; @throws {Error} When it cannot be created.
FSEnsureDirectoryStrict(Path) {
	if !FSPathIsAdmissible(Path)
		throw ValueError("A directory creation requires a non-empty path without NUL.")
	if DirExist(Path)
		return false
	DirCreate(Path)
	return true
}

; Deletes a file. Returns true if deleted or already absent, false on error.
; @param Path {String} Absolute path to the file to delete.
; @return {Boolean} True on success, false on error.
FSDelete(Path) {
	return _FSDeleteWith(Path, _FSDeleteNativeReceipt)
}

_FSDeleteNativeReceipt(Path) {
	; One native call distinguishes successful deletion, proven absence, and every
	; other failure without a FileExist/DeleteFile race or an ambiguous probe.
	Deleted := DllCall("kernel32\DeleteFileW", "Str", Path, "Int")
	ErrorCode := A_LastError
	return Map("deleted", Deleted != 0, "error", ErrorCode)
}

_FSDeleteWith(Path, DeleteFn) {
	if !FSPathIsAdmissible(Path)
		return false
	try {
		Receipt := DeleteFn.Call(Path)
		if !(Receipt is Map)
			return false
		Deleted := Receipt.Get("deleted", false)
		if (Deleted is Integer) && Deleted == true
			return true
		ErrorCode := Receipt.Get("error", 0)
		if !(ErrorCode is Integer)
			return false
		return ErrorCode == 2 || ErrorCode == 3
	} catch {
		return false
	}
}

; Verify a stable read-only file before deleting that same object exclusively.
; The callback must return true only for an artifact owned by its caller.
; Sharing/identity failures retain the file for a later retry.
FSDeleteVerified(Path, VerifyFn) {
	if !FSPathIsAdmissible(Path)
		return false
	Handle := DllCall("kernel32\CreateFileW", "Str", Path, "UInt", 0x80000000,
		"UInt", 1, "Ptr", 0, "UInt", 3, "UInt", 0x00200000, "Ptr", 0, "Ptr")
	if Handle = -1
		return false
	try {
		Info := Buffer(52, 0)
		if !DllCall("kernel32\GetFileInformationByHandle", "Ptr", Handle, "Ptr", Info, "Int")
				|| (NumGet(Info, 0, "UInt") & 0x410)
			return false
		Before := FSHandleSnapshot(Handle)
		if !Before.Get("ok", false) || !VerifyFn.Call(Path)
			return false
	} finally DllCall("kernel32\CloseHandle", "Ptr", Handle)
	; DELETE access and no sharing prevent any new connection or replacement
	; between the identity check and marking this handle for deletion.
	Handle := DllCall("kernel32\CreateFileW", "Str", Path, "UInt", 0x80010000,
		"UInt", 0, "Ptr", 0, "UInt", 3, "UInt", 0x00200000, "Ptr", 0, "Ptr")
	if Handle = -1
		return false
	try {
		After := FSHandleSnapshot(Handle)
		if !After.Get("ok", false)
			return false
		for Key in ["volume", "index_high", "index_low", "size", "write_high", "write_low"] {
			if Before[Key] != After[Key]
				return false
		}
		; FILE_DISPOSITION_INFO contains one BOOLEAN. Closing deletes the
		; verified object, whereas DeleteFileW after closing would race a rename.
		Disposition := Buffer(1, 1)
		return DllCall("kernel32\SetFileInformationByHandle", "Ptr", Handle,
			"Int", 4, "Ptr", Disposition, "UInt", 1, "Int") != 0
	} finally DllCall("kernel32\CloseHandle", "Ptr", Handle)
}

; Acquire a persistent guard file without sharing, truncation, or inheritance.
; Windows-only protocol helper, intentionally outside the portable port map.
; @param Path {String} Guard path in an existing owned directory.
; @returns {Integer} Owned handle, or 0 when unavailable or not an ordinary file.
FSOpenExclusiveGuard(Path) {
	if !FSPathIsAdmissible(Path)
		throw ValueError("An exclusive guard requires a non-empty path without NUL.")
	Handle := DllCall("kernel32\CreateFileW", "Str", Path, "UInt", 0xC0000000,
		"UInt", 0, "Ptr", 0, "UInt", 4, "UInt", 0x00200080, "Ptr", 0, "Ptr")
	if Handle = -1
		return 0
	Info := Buffer(52, 0)
	if !DllCall("kernel32\GetFileInformationByHandle", "Ptr", Handle, "Ptr", Info, "Int")
			|| (NumGet(Info, 0, "UInt") & 0x410) {
		DllCall("kernel32\CloseHandle", "Ptr", Handle)
		return 0
	}
	return Handle
}

; Release exactly the acquired guard. Keep its pathname stable across owners.
; @param Handle {Integer} Owned guard returned by FSOpenExclusiveGuard.
; @returns {Boolean} Whether Windows released the native handle.
FSCloseExclusiveGuard(Handle) {
	return Handle && DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
}

; Idempotent strict deletion for recovery protocols. Unlike FSDelete, this
; does not route through FileExist (whose empty result conflates absence with
; an OS probe failure). Non-absence failures are surfaced to the journal.
FSDeleteStrict(Path) {
	if !FSPathIsAdmissible(Path)
		throw ValueError("A strict delete requires a non-empty path without NUL.")
	Receipt := _FSDeleteNativeReceipt(Path)
	if Receipt["deleted"]
		return 1
	ErrorCode := Receipt["error"]
	if (ErrorCode == 2 || ErrorCode == 3)
		return 1
	throw OSError(ErrorCode, A_ThisFunc,
		"DeleteFileW failed for '" . Path . "'.")
}

; Returns the current byte length, or -1 when the path is absent/unreadable.
; Kept outside the portable port map for transactional file protocols that must
; validate an artifact without exposing AHK FileGetSize to domain modules.
FSSize(Path) {
	if !FSPathIsAdmissible(Path)
		return -1
	try return FileGetSize(Path)
	catch
		return -1
}

; Reads a small control file only when its size is inside the explicit budget.
; This prevents a malformed sidecar from turning an early-boot capability check
; into an unbounded allocation.
FSReadBounded(Path, MaxBytes) {
	if !FSPathIsAdmissible(Path)
		or !IsNumber(MaxBytes) or MaxBytes <= 0
		return false
	FH := 0
	try {
		FH := FileOpen(Path, "r", "UTF-8-RAW")
		if !IsObject(FH) or FH.Length > MaxBytes
			return false
		; Never issue an unbounded Read after the size probe. The same open handle
		; may grow concurrently; one extra character detects overflow while the
		; UTF-8 byte check preserves the contract for multibyte text.
		Content := FH.Read(MaxBytes + 1)
		if (FH.Pos < FH.Length
			or StrPut(Content, "UTF-8") - 1 > MaxBytes)
			return false
		return Content
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
	}
}

; Reads a transition target through Win32 without FileOpen's BOM skip. The WAL
; hashes exact UTF-8 byte images, so a leading EF BB BF must survive as U+FEFF
; and malformed/non-canonical UTF-8 must be refused rather than normalized to
; replacement characters. FILE_SHARE_READ excludes concurrent writers while
; the snapshot handle is open.
FSReadUtf8Exact(Path) {
	return _FSReadUtf8ExactImpl(Path, 0, false)
}

; Byte-faithful verification for staged UTF-8 control/source artifacts. The
; ordinary FSRead/FileRead path consumes a physical EF BB BF prefix, so comparing
; its String to a BOM-bearing expected payload produces a deterministic false
; mismatch even though the bytes on disk are correct.
FSUtf8ExactMatches(Path, Expected) {
	if !(Expected is String)
		return false
	Observed := FSReadUtf8Exact(Path)
	return (Observed is String) and Observed == Expected
}

FSReadUtf8ExactBounded(Path, MaxBytes) {
	if !(MaxBytes is Integer) || MaxBytes <= 0
		return false
	return _FSReadUtf8ExactImpl(Path, MaxBytes, true)
}

_FSReadUtf8ExactImpl(Path, MaxBytes, Bounded) {
	if !FSPathIsAdmissible(Path)
		return false
	static GENERIC_READ := 0x80000000
	static FILE_SHARE_READ := 0x00000001
	static OPEN_EXISTING := 3
	static FILE_ATTRIBUTE_NORMAL := 0x00000080
	Handle := -1
	OpeningReturned := false
	Closed := false
	Content := false
	ReadActivity := FileReadActivityEnter(Path)
	try {
		Handle := DllCall("kernel32\CreateFileW",
			"Str", Path,
			"UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ,
			"Ptr", 0,
			"UInt", OPEN_EXISTING,
			"UInt", FILE_ATTRIBUTE_NORMAL,
			"Ptr", 0,
			"Ptr")
		OpeningReturned := true
		if Handle != -1 {
			FileReadActivityBind(ReadActivity, Handle)
			Content := _FSReadUtf8ExactHandle(Handle, MaxBytes, Bounded)
		}
	} catch {
		Content := false
	} finally {
		if Handle == -1 {
			; A returned failed opening owns no handle; a thrown acquisition stays debt.
			Closed := OpeningReturned
		} else {
			try Closed := DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
			catch {
				Closed := false
			}
		}
		if Closed
			FileReadActivityLeave(ReadActivity)
	}
	return Closed ? Content : false
}

/** Reads and validates the original UTF-8 bytes through one retained handle. */
_FSReadUtf8ExactHandle(Handle, MaxBytes, Bounded) {
	ByteCount := 0
	if !DllCall("kernel32\GetFileSizeEx", "Ptr", Handle,
			"Int64*", &ByteCount, "Int")
		return false
	if ByteCount < 0 || ByteCount > 0x7FFFFFFF
		return false
	if Bounded && ByteCount > MaxBytes
		return false
	Raw := Buffer(ByteCount > 0 ? ByteCount : 1, 0)
	Offset := 0
	while Offset < ByteCount {
		Chunk := Min(ByteCount - Offset, 0x7FFFF000)
		ReadCount := 0
		if !DllCall("kernel32\ReadFile",
				"Ptr", Handle,
				"Ptr", Raw.Ptr + Offset,
				"UInt", Chunk,
				"UInt*", &ReadCount,
				"Ptr", 0,
				"Int") || ReadCount <= 0
			return false
		Offset += ReadCount
	}
	FinalSize := 0
	if !DllCall("kernel32\GetFileSizeEx", "Ptr", Handle,
			"Int64*", &FinalSize, "Int") || FinalSize != ByteCount
		return false
	if ByteCount == 0
		return ""
	Content := StrGet(Raw.Ptr, ByteCount, "UTF-8")
	CanonicalCount := StrPut(Content, "UTF-8") - 1
	if CanonicalCount != ByteCount
		return false
	Canonical := Buffer(CanonicalCount + 1, 0)
	StrPut(Content, Canonical, CanonicalCount + 1, "UTF-8")
	MatchingBytes := DllCall("ntdll\RtlCompareMemory",
		"Ptr", Raw, "Ptr", Canonical, "UPtr", ByteCount, "UPtr")
	return MatchingBytes == ByteCount ? Content : false
}

; Admit only the target's HWND-sequence scratch format after its owner exits.
; A reused HWND conservatively retains debris instead of risking an active write.
; @param FileName {String} Candidate basename from the directory enumeration.
; @param TargetName {String} Exact basename of the writer's destination.
; @returns {Boolean} Whether the recognized producer window no longer exists.
FSAtomicTempOwnerIsGone(FileName, TargetName) {
	if TargetName = "" || StrCompare(SubStr(FileName, 1, StrLen(TargetName)), TargetName, true) != 0
		return false
	Suffix := SubStr(FileName, StrLen(TargetName) + 1)
	if !RegExMatch(Suffix, "^\.([1-9]\d{0,9})-[1-9]\d{0,18}\.tmp$", &Owner)
		return false
	Hwnd := Integer(Owner[1])
	return Hwnd <= 0xFFFFFFFF && !DllCall("User32\IsWindow", "Ptr", Hwnd, "Int")
}

; Publishes a complete same-directory stage with one write-through Win32 rename.
; Failure retains Source and leaves Destination untouched.
; NativeError reports the immediate Win32 error; zero also denotes unavailable
; native information on invalid arguments or a DllCall exception.
FSAtomicMoveReplace(Source, Destination, &NativeError := 0) {
	NativeError := 0
	if !FSPathIsAdmissible(Source)
		or !FSPathIsAdmissible(Destination)
		return false
	static MOVEFILE_REPLACE_EXISTING := 0x00000001
	static MOVEFILE_WRITE_THROUGH := 0x00000008
	try {
		DllCall("kernel32\SetLastError", "UInt", 0)
		Moved := DllCall("MoveFileExW", "Str", Source, "Str", Destination,
			"UInt", MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH, "Int")
		NativeError := A_LastError
		return Moved != 0
	} catch Error {
		; No completed native receipt is available for a DllCall exception.
		NativeError := 0
		return false
	}
}

; Publishes Source only when Destination is still absent. Omitting
; MOVEFILE_REPLACE_EXISTING makes the directory-entry operation atomic and
; collision-preserving; WRITE_THROUGH makes the rename a durable boundary.
FSAtomicMoveCreate(Source, Destination) {
	if !FSPathIsAdmissible(Source)
		or !FSPathIsAdmissible(Destination)
		return 0
	static MOVEFILE_WRITE_THROUGH := 0x00000008
	try return DllCall("kernel32\MoveFileExW", "Str", Source,
		"Str", Destination, "UInt", MOVEFILE_WRITE_THROUGH, "Int") ? 1 : 0
	catch
		return 0
}

; Atomically replaces Destination with Source when both are on the same volume.
; Kept in the adapter so domain modules never call FileMove directly.
FSMove(Source, Destination, Overwrite := false) {
        if !FSPathIsAdmissible(Source) or !FSPathIsAdmissible(Destination)
                return false
        try {
                FileMove(Source, Destination, Overwrite)
                return true
        } catch {
                return false
        }
}

/** Open a BOM-aware UTF-8 reader; native refusal reaches the identity owner. */
FSOpenReadStrict(Path) {
	_FSRequirePath(Path, "A strict reader")
	return FileOpen(Path, "r", "UTF-8")
}

; Opens a file for STREAMED reading and hands the handle back.
; FSRead loads a whole file; the at-rest migration walks data.sql, which can be
; hundreds of megabytes, and would have to hold all of it in memory to rewrite
; two columns of a few statements. The handle is UTF-8-RAW so a byte-exact
; passthrough is possible: the byte-order mark, if any, arrives as content and
; leaves as content instead of being stripped on one side and re-added on the
; other.
; @param Path {String} Absolute path to the file.
; @return {Object|String} An AHK file object, or "" on any error.
FSOpenRead(Path) {
	if !FSPathIsAdmissible(Path)
		return ""
	try {
		local FH := FileOpen(Path, "r", "UTF-8-RAW")
		return IsObject(FH) ? FH : ""
	} catch {
		return ""
	}
}

; Opens a file for STREAMED writing, truncating any existing content.
; Counterpart of FSOpenRead; see its note on UTF-8-RAW.
; @param Path {String} Absolute path to the file.
; @return {Object|String} An AHK file object, or "" on any error.
FSOpenWrite(Path) {
	if !FSPathIsAdmissible(Path)
		return ""
	try {
		local FH := FileOpen(Path, "w", "UTF-8-RAW")
		return IsObject(FH) ? FH : ""
	} catch {
		return ""
	}
}

; Returns stable identity, size and write-time metadata for an already-open file
; handle. This Windows-specific helper deliberately stays outside the canonical
; ADAPTER_FILE_SYSTEM port map; it is an implementation boundary used by the
; metrics reader to distinguish append, in-place repair and file replacement.
FSHandleSnapshot(FileHandle) {
	if !FileHandle
		return Map("ok", false)
	try {
		; BY_HANDLE_FILE_INFORMATION is a fixed 52-byte DWORD structure.
		static INFO_BYTES := 52
		local Info := Buffer(INFO_BYTES, 0)
		if !DllCall("kernel32\GetFileInformationByHandle",
			"Ptr", FileHandle,
			"Ptr", Info.Ptr,
			"Int")
			return Map("ok", false)
		return Map(
			"ok", true,
			"write_low", NumGet(Info, 20, "UInt"),
			"write_high", NumGet(Info, 24, "UInt"),
			"volume", NumGet(Info, 28, "UInt"),
			"size", (NumGet(Info, 32, "UInt") << 32)
				| NumGet(Info, 36, "UInt"),
			"index_high", NumGet(Info, 44, "UInt"),
			"index_low", NumGet(Info, 48, "UInt")
		)
	} catch {
		return Map("ok", false)
	}
}

; Move an exact file-read byte span, including overlapping carry buffers.
; @param Destination {Buffer|Integer} A writable span of at least ByteCount bytes.
; @param Source {Buffer|Integer} A readable span of at least ByteCount bytes.
; @param ByteCount {Integer} The number of bytes to move without text decoding.
FSBufferMove(Destination, Source, ByteCount) {
	DllCall("ntdll\RtlMoveMemory", "Ptr", Destination, "Ptr", Source, "UPtr", ByteCount)
}

; Reads an exact byte range together with the identity of the handle it came
; from, so a caller can prove the bytes belong to the file it expects. NUL bytes
; (an interrupted append's hole) are optionally blanked to spaces: UTF-8
; conversion stops at the first NUL. Windows-specific, outside the port map.
; @param Path {String} Absolute path to the file.
; @param Start {Integer} First byte offset.
; @param Count {Integer} Exact number of bytes to read.
; @param BlankNul {Boolean} Whether to replace every NUL byte with a space.
; @return {Map} ok, buffer, snapshot (FSHandleSnapshot), nul_bytes.
FSReadRange(Path, Start, Count, BlankNul := false) {
	if !FSPathIsAdmissible(Path)
		return Map("ok", false)
	local Buf := Buffer(Max(Count, 1), 0)
	local FH := FileOpen(Path, "r")
	if !IsObject(FH)
		return Map("ok", false)
	try {
		local Snapshot := FSHandleSnapshot(FH.Handle)
		FH.Pos := Start
		if Count > 0 && FH.RawRead(Buf, Count) != Count
			return Map("ok", false, "snapshot", Snapshot)
	} finally FH.Close()
	local Blanked := 0
	if BlankNul {
		local Cursor := Buf.Ptr
		local Stop := Buf.Ptr + Count
		while Cursor < Stop {
			local Hit := DllCall("msvcrt\memchr", "Ptr", Cursor, "Int", 0, "UPtr", Stop - Cursor, "Cdecl Ptr")
			if !Hit
				break
			NumPut("UChar", 0x20, Hit)
			Blanked += 1
			Cursor := Hit + 1
		}
	}
	return Map("ok", true, "buffer", Buf, "snapshot", Snapshot, "nul_bytes", Blanked)
}

; Copies a file byte for byte to a path that must not exist yet, then checks
; the copy reads back as its source. The configuration backup's copies.
; @param Source {String} File to copy.
; @param Destination {String} New path; an existing one is never replaced.
; @return {Boolean} True only for a complete, verified copy. Unverified output
;   is retained: its pathname may already belong to a different file.
FSCopyCreateVerified(Source, Destination) {
	if !FSPathIsAdmissible(Source) || !FSPathIsAdmissible(Destination)
		return false
	; Builtin copy/delete operations interpret patterns; this API owns literal names.
	if !DllCall("kernel32\CopyFileW", "Str", Source, "Str", Destination, "Int", true, "Int")
		return false
	; A mismatch can describe a foreign replacement, not the copy just created.
	return FSSameBytes(Source, Destination)
}

; Whether two files hold exactly the same bytes.
; @param PathA {String}
; @param PathB {String}
; @return {Boolean} False when either cannot be read.
FSSameBytes(PathA, PathB) {
	if !FSPathIsAdmissible(PathA) || !FSPathIsAdmissible(PathB)
		return false
	try {
		A := FileRead(PathA, "RAW")
		B := FileRead(PathB, "RAW")
	} catch {
		return false
	}
	if (A.Size != B.Size)
		return false
	if (A.Size == 0)
		return true
	return DllCall("ntdll\RtlCompareMemory", "Ptr", A, "Ptr", B, "UPtr", A.Size, "UPtr") == A.Size
}

; Publishes verified raw bytes through one exclusively held same-directory stage.
; Pre-publication refusal leaves the destination untouched; post-publication
; flush/close uncertainty returns false with an explicit receipt. Unverified
; stages are retained, and no failure grants cleanup authority over a pathname.
; @param Source {String} Source file; the held pin follows the existing file-link contract.
; @param Destination {String} File explicitly replaced by the authorized restore owner.
; @param Receipt {Map} Phase, native error, publication and close acknowledgments.
; @return {Boolean} True only after publication, flush and every owned native close.
; Review-only replacement for the configuration restore copy boundary.
; The pathname wrapper preserves the existing fixed restore sidecar contract.
FSCopyReplaceAtomic(Source, Destination, &Receipt := 0) {
	Receipt := _FSCopyReceipt()
	if !FSPathIsAdmissible(Source) || !FSPathIsAdmissible(Destination)
		return false
	SourceOwner := _FSCopyOwner("")
	try {
		FullSource := _FSCopyFullPath(Source)
		FullDestination := _FSCopyFullPath(Destination)
		SourceOwner["path"] := FullSource
		Receipt["phase"] := "open_source"
		if !_FSCopyAcquire(SourceOwner, "path", , &NativeError) {
			Receipt["native_error"] := NativeError
			return false
		}
		Receipt := _FSCopyHeldSourceReplaceAtomic(SourceOwner["handle"], FullSource,
			FullDestination, FullDestination . ".ergopti-restore.tmp")
	} catch as Err {
		Receipt["detail"] := Err.Message
	} finally {
		if !_FSCopyClose(SourceOwner, &NativeError) {
			Receipt["close_errors"]["source_path"] := NativeError
			Receipt["close_error_details"]["source_path"] := SourceOwner["close_detail"]
			Receipt["ok"] := false
		}
	}
	return Receipt["ok"]
}

; SourcePath is reader-admission metadata, never a source-opening authority.
; Private config-copy core; no layout generation or cancellation API is granted.
; The caller retains its original held source and owns its eventual disposal.
; StagePath must be a distinct, absent sibling of Destination. Publication keeps
; the existing replace-live-destination policy; this is not destination CAS.
_FSCopyHeldSourceReplaceAtomic(SourceHandle, SourcePath, Destination, StagePath) {
	Receipt := _FSCopyReceipt()
	if !(SourceHandle is Integer) || SourceHandle == 0 || SourceHandle == -1
			|| !FSPathIsAdmissible(SourcePath) || !FSPathIsAdmissible(Destination)
			|| !FSPathIsAdmissible(StagePath)
		return Receipt
	SourceOwner := _FSCopyOwner(SourcePath), StageOwner := _FSCopyOwner("")
	DestinationActivity := 0
	try {
		FullDestination := _FSCopyFullPath(Destination)
		FullStage := _FSCopyFullPath(StagePath)
		SplitPath(FullDestination, , &DestinationDirectory)
		SplitPath(FullStage, , &StageDirectory)
		if StrCompare(FullDestination, FullStage, false) == 0
				|| StrCompare(DestinationDirectory, StageDirectory, false) != 0 {
			Receipt["detail"] := "Publication requires a distinct same-directory stage."
			return Receipt
		}
		StageOwner["path"] := FullStage
		Receipt["phase"] := "pin_source"
		if !_FSCopyAcquire(SourceOwner, "held", SourceHandle, &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Held := FSHandleSnapshot(SourceHandle), Before := FSHandleSnapshot(SourceOwner["handle"])
		if !Held["ok"] || !Before["ok"] || !_FSCopyOrdinary(SourceOwner["handle"])
				|| Before["size"] < 0 {
			Receipt["detail"] := "The held source is not a readable ordinary file."
			return Receipt
		}
		for Key in ["volume", "index_high", "index_low"] {
			if Held[Key] != Before[Key] {
				Receipt["detail"] := "The source pin did not preserve the held file identity."
				return Receipt
			}
		}
		Receipt["source_identity"] := Before
		if !DllCall("kernel32\SetFilePointerEx", "Ptr", SourceOwner["handle"], "Int64", 0, "Ptr", 0, "UInt", 0, "Int") {
			Receipt["native_error"] := A_LastError
			Receipt["detail"] := "The held source cursor could not be reset."
			return Receipt
		}
		Receipt["phase"] := "create_stage"
		if !_FSCopyAcquire(StageOwner, "stage", , &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Created := FSHandleSnapshot(StageOwner["handle"])
		if !Created["ok"] {
			Receipt["detail"] := "The acquired stage has no native identity receipt."
			return Receipt
		}
		Receipt["stage_identity"] := Created
		static COPY_CHUNK_BYTES := 0x10000
		Bytes := Buffer(COPY_CHUNK_BYTES), Readback := Buffer(COPY_CHUNK_BYTES)
		Offset := 0
		while Offset < Before["size"] {
			Count := Min(COPY_CHUNK_BYTES, Before["size"] - Offset)
			Receipt["phase"] := "read_source"
			if !_FSCopyTransfer(SourceOwner["handle"], Bytes, Count, false, &NativeError) {
				Receipt["native_error"] := NativeError
				Receipt["detail"] := "The source read did not complete."
				return Receipt
			}
			Receipt["phase"] := "write_stage"
			if !_FSCopyTransfer(StageOwner["handle"], Bytes, Count, true, &NativeError) {
				Receipt["native_error"] := NativeError
				Receipt["detail"] := "The stage write did not complete."
				return Receipt
			}
			Receipt["phase"] := "verify_stage"
			if !DllCall("kernel32\SetFilePointerEx", "Ptr", StageOwner["handle"],
					"Int64", Offset, "Ptr", 0, "UInt", 0, "Int") {
				Receipt["native_error"] := A_LastError
				return Receipt
			}
			if !_FSCopyTransfer(StageOwner["handle"], Readback, Count, false, &NativeError) {
				Receipt["native_error"] := NativeError
				return Receipt
			}
			if DllCall("ntdll\RtlCompareMemory", "Ptr", Bytes, "Ptr", Readback,
					"UPtr", Count, "UPtr") != Count {
				Receipt["detail"] := "The held stage differs from the source bytes."
				return Receipt
			}
			Offset += Count
			Receipt["bytes"] := Offset
		}
		After := FSHandleSnapshot(SourceOwner["handle"]), Staged := FSHandleSnapshot(StageOwner["handle"])
		if !After["ok"] || !Staged["ok"] || Staged["size"] != Before["size"] {
			Receipt["detail"] := "The source or stage size could not be verified."
			return Receipt
		}
		for Key in ["volume", "index_high", "index_low", "size", "write_high", "write_low"] {
			if Before[Key] != After[Key] {
				Receipt["detail"] := "The held source changed during the copy."
				return Receipt
			}
		}
		Receipt["phase"] := "flush_stage"
		if !_FSCopyFlush(StageOwner["handle"], &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		; This aliases reader admission only. The stage owner alone closes the
		; native handle; both metadata paths remain busy until that close ACK.
		DestinationActivity := FileReadActivityEnter(FullDestination)
		Receipt["phase"] := "publish_stage"
		Receipt["publication"] := "unknown"
		if !_FSCopyPublish(StageOwner["handle"], FullDestination, &NativeError) {
			Receipt["publication"] := "refused"
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Receipt["publication"] := "completed"
		FileReadActivityBind(DestinationActivity, StageOwner["handle"])
		Receipt["phase"] := "flush_published"
		if !_FSCopyFlush(StageOwner["handle"], &NativeError) {
			Receipt["native_error"] := NativeError
			return Receipt
		}
		Receipt["ok"] := true
		Receipt["phase"] := "complete"
	} catch as Err {
		Receipt["detail"] := Err.Message
	} finally {
		StageClosed := _FSCopyClose(StageOwner, &NativeError)
		if !StageClosed {
			Receipt["close_errors"]["stage"] := NativeError
			Receipt["close_error_details"]["stage"] := StageOwner["close_detail"]
			Receipt["ok"] := false
		}
		if IsObject(DestinationActivity) && StageClosed {
			try {
				if !FileReadActivityLeave(DestinationActivity) {
					Receipt["close_errors"]["destination_activity"] := 0
					Receipt["close_error_details"]["destination_activity"] := "Destination reader metadata retirement was refused."
					Receipt["ok"] := false
				}
			} catch as Err {
				Receipt["close_errors"]["destination_activity"] := 0
				Receipt["close_error_details"]["destination_activity"] := Err.Message
				Receipt["ok"] := false
			}
		}
		if !_FSCopyClose(SourceOwner, &NativeError) {
			Receipt["close_errors"]["source_pin"] := NativeError
			Receipt["close_error_details"]["source_pin"] := SourceOwner["close_detail"]
			Receipt["ok"] := false
		}
	}
	return Receipt
}

_FSCopyReceipt() {
	return Map("ok", false, "phase", "admission", "native_error", 0, "detail", "",
		"publication", "not_attempted", "bytes", 0, "close_errors", Map(), "close_error_details", Map())
}

_FSCopyOwner(Path) {
	return Map("path", Path, "handle", -1, "returned", false, "activity", 0, "close_detail", "")
}

_FSCopyAcquire(Owner, Mode, Original := 0, &NativeError := 0) {
	static GENERIC_READ := 0x80000000, GENERIC_WRITE := 0x40000000, DELETE_ACCESS := 0x10000
	static FILE_SHARE_READ := 1, FILE_SHARE_WRITE := 2, CREATE_NEW := 1, OPEN_EXISTING := 3
	static FILE_ATTRIBUTE_NORMAL := 0x80, FILE_FLAG_WRITE_THROUGH := 0x80000000
	NativeError := 0
	if Mode != "held" && Mode != "path" && Mode != "stage"
		throw ValueError("Unknown held-copy acquisition mode.")
	Owner["activity"] := FileReadActivityEnter(Owner["path"])
	if Mode == "held"
		Handle := DllCall("kernel32\ReOpenFile", "Ptr", Original, "UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ, "UInt", 0, "Ptr")
	else if Mode == "path"
		Handle := DllCall("kernel32\CreateFileW", "Str", Owner["path"], "UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ | FILE_SHARE_WRITE, "Ptr", 0, "UInt", OPEN_EXISTING,
			"UInt", FILE_ATTRIBUTE_NORMAL, "Ptr", 0, "Ptr")
	else if Mode == "stage"
		Handle := DllCall("kernel32\CreateFileW", "Str", Owner["path"],
			"UInt", GENERIC_READ | GENERIC_WRITE | DELETE_ACCESS, "UInt", 0, "Ptr", 0,
			"UInt", CREATE_NEW, "UInt", FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, "Ptr", 0, "Ptr")
	else
		throw ValueError("Unknown held-copy acquisition mode.")
	NativeError := Handle == -1 ? A_LastError : 0
	Owner["returned"] := true
	Owner["handle"] := Handle
	if Handle == -1
		return false
	FileReadActivityBind(Owner["activity"], Handle)
	return true
}

_FSCopyClose(Owner, &NativeError := 0) {
	NativeError := 0
	try {
		if !IsObject(Owner["activity"])
			return true
		if Owner["handle"] == -1 {
			if !Owner["returned"] {
				Owner["close_detail"] := "The native acquisition outcome is unknown."
				return false
			}
		} else {
			if !_FSCopyNativeClose(Owner["handle"], &NativeError) {
				Owner["close_detail"] := "Native CloseHandle refused retirement."
				return false
			}
			Owner["handle"] := -1
		}
		if !FileReadActivityLeave(Owner["activity"]) {
			Owner["close_detail"] := "Reader activity retirement was refused."
			return false
		}
		Owner["activity"] := 0
		return true
	} catch as Err {
		Owner["close_detail"] := Err.Message
		return false
	}
}

_FSCopyNativeClose(Handle, &NativeError := 0) {
	Closed := DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
	NativeError := Closed ? 0 : A_LastError
	return Closed
}

_FSCopyOrdinary(Handle) {
	Info := Buffer(52, 0)
	return DllCall("kernel32\GetFileInformationByHandle", "Ptr", Handle, "Ptr", Info, "Int")
		&& !(NumGet(Info, 0, "UInt") & 0x410)
		&& DllCall("kernel32\GetFileType", "Ptr", Handle, "UInt") == 1
}

_FSCopyTransfer(Handle, Bytes, Count, Write, &NativeError := 0) {
	NativeError := 0
	Offset := 0
	while Offset < Count {
		Transferred := 0
		if !_FSCopyNativeIo(Write, Handle, Bytes.Ptr + Offset, Count - Offset, &Transferred, &NativeError)
				|| Transferred <= 0 || Transferred > Count - Offset
			return false
		Offset += Transferred
	}
	return true
}

_FSCopyNativeIo(Write, Handle, Address, Count, &Transferred, &NativeError := 0) {
	Api := Write ? "kernel32\WriteFile" : "kernel32\ReadFile"
	Completed := DllCall(Api, "Ptr", Handle, "Ptr", Address, "UInt", Count,
		"UInt*", &Transferred, "Ptr", 0, "Int") != 0
	NativeError := Completed ? 0 : A_LastError
	return Completed
}

_FSCopyFlush(Handle, &NativeError := 0) {
	Flushed := DllCall("kernel32\FlushFileBuffers", "Ptr", Handle, "Int") != 0
	NativeError := Flushed ? 0 : A_LastError
	return Flushed
}

_FSCopyPublish(Handle, Destination, &NativeError := 0) {
	static FILE_RENAME_INFO_CLASS := 3
	NameBytes := StrLen(Destination) * 2
	NameOffset := A_PtrSize == 8 ? 20 : 12
	Rename := Buffer(NameOffset + NameBytes + 2, 0)
	NumPut("UInt", 1, Rename, 0)
	NumPut("UInt", NameBytes, Rename, A_PtrSize == 8 ? 16 : 8)
	StrPut(Destination, Rename.Ptr + NameOffset, StrLen(Destination) + 1, "UTF-16")
	Published := DllCall("kernel32\SetFileInformationByHandle", "Ptr", Handle,
		"Int", FILE_RENAME_INFO_CLASS, "Ptr", Rename, "UInt", Rename.Size, "Int") != 0
	NativeError := Published ? 0 : A_LastError
	return Published
}

_FSCopyFullPath(Path) {
	Size := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", 0, "Ptr", 0, "Ptr", 0, "UInt")
	if !Size
		throw OSError(A_LastError, A_ThisFunc)
	Full := Buffer(Size * 2)
	Written := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", Size, "Ptr", Full, "Ptr", 0, "UInt")
	if !Written || Written >= Size
		throw Error("Held-copy path resolution did not complete.")
	return StrGet(Full)
}

; Whether a path is a reparse point (a symbolic link or a junction), which a
; folder walk never follows: it can lead back up the tree.
; @param Path {String}
; @return {Boolean}
FSIsReparsePoint(Path) {
	return FSPathIsAdmissible(Path) && InStr(FileExist(Path), "L") > 0
}

; Machine-readable contract map - consumed by the generic adapter compliance test
; (tests/unit/adapters/test_adapter_compliance.ahk) to verify every required method exists
; and is callable without manually listing functions per-adapter.
global ADAPTER_FILE_SYSTEM := Map(
    "read",   FSRead,
    "write",  FSWrite,
    "append", FSAppend,
    "exists", FSExists,
    "delete", FSDelete,
)


/** Configuration-only byte receipt; native opening errors never grant write authority. */
FSConfigReadUtf8Exact(Path, &NativeOpenError := 0) {
	static OriginalRead := FSReadUtf8Exact, HandleRead := _FSReadUtf8ExactHandle
	static Enter := FileReadActivityEnter, Bind := FileReadActivityBind, Leave := FileReadActivityLeave
	NativeOpenError := 0
	if OriginalRead != FSReadUtf8Exact || HandleRead != _FSReadUtf8ExactHandle
			|| Enter != FileReadActivityEnter || Bind != FileReadActivityBind || Leave != FileReadActivityLeave
		return false
	if !FSPathIsAdmissible(Path)
		return false
	static GENERIC_READ := 0x80000000
	static FILE_SHARE_READ := 0x00000001
	static OPEN_EXISTING := 3
	static FILE_ATTRIBUTE_NORMAL := 0x00000080
	Handle := -1
	OpeningReturned := false
	Closed := false
	Content := false
	for Owner in [OriginalRead, HandleRead, Enter, Bind, Leave]
		if Object.Prototype.HasOwnProp.Call(Owner, "Call")
			return false
	ReadActivity := Enter.Call(Path)
	try {
		Handle := DllCall("kernel32\CreateFileW",
			"Str", Path,
			"UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ,
			"Ptr", 0,
			"UInt", OPEN_EXISTING,
			"UInt", FILE_ATTRIBUTE_NORMAL,
			"Ptr", 0,
			"Ptr")
		OpeningReturned := true
		if Handle == -1
			NativeOpenError := A_LastError ; Capture the actual failed CreateFileW before cleanup.
		if Handle != -1 {
			if OriginalRead != FSReadUtf8Exact || HandleRead != _FSReadUtf8ExactHandle
					|| Enter != FileReadActivityEnter || Bind != FileReadActivityBind || Leave != FileReadActivityLeave
				return false
			for Owner in [OriginalRead, HandleRead, Enter, Bind, Leave]
				if Object.Prototype.HasOwnProp.Call(Owner, "Call")
					return false
			Bind.Call(ReadActivity, Handle)
			Content := HandleRead.Call(Handle, 0, false)
		}
	} catch {
		Content := false
	} finally {
		if Handle == -1 {
			; A returned failed opening owns no handle; a thrown acquisition stays debt.
			Closed := OpeningReturned
		} else {
			try Closed := DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
			catch {
				Closed := false
			}
		}
		if Closed
			Leave.Call(ReadActivity)
	}
	return Closed ? Content : false
}

; Pure logical admission is consumed only within a configuration native span.
_FSNativeAdmissionAccepted(AdmissionFn) {
	if (AdmissionFn is Integer) && AdmissionFn == 0
		return true
	if !HasMethod(AdmissionFn, "Call")
		return false
	try {
		Accepted := AdmissionFn.Call()
		return (Accepted is Integer) && Accepted == 1
	} catch {
		return false
	}
}

/** Consumes captured unchanged-source admission within the configuration span. */
FSNativeAcknowledge(AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		Accepted := Accept == _FSNativeAdmissionAccepted && Accept.Call(AdmissionFn)
		return Accepted && Accept == _FSNativeAdmissionAccepted
			&& !Object.Prototype.HasOwnProp.Call(Accept, "Call")
	}
	finally Critical(PreviousCritical)
}

/** Configuration replacement through the retained genuine write-through producer. */
FSConfigAtomicMoveReplace(Source, Destination, &NativeError := 0, AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	static Move := FSAtomicMoveReplace
	NativeError := 0
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		if Move != FSAtomicMoveReplace || Accept != _FSNativeAdmissionAccepted || !Accept.Call(AdmissionFn)
				|| Accept != _FSNativeAdmissionAccepted
				|| Move != FSAtomicMoveReplace {
			; No native operation ran, so no Win32 error receipt is invented.
			return false
		}
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return Move.Call(Source, Destination, &NativeError)
	} finally Critical(PreviousCritical)
}

/** Configuration-only no-replace publication keeps the existing producer receipt. */
FSConfigAtomicMoveCreate(Source, Destination, AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	static Move := FSAtomicMoveCreate
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		if Move != FSAtomicMoveCreate || Accept != _FSNativeAdmissionAccepted || !Accept.Call(AdmissionFn)
				|| Accept != _FSNativeAdmissionAccepted
				|| Move != FSAtomicMoveCreate
			return 0
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return Move.Call(Source, Destination)
	} finally Critical(PreviousCritical)
}

/** Configuration-owned recovery removal retains the original strict delete receipt. */
FSConfigDeleteStrict(Path, AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	static Delete := FSDeleteStrict, Receipt := _FSDeleteNativeReceipt
	static DeleteWith := _FSDeleteWith, Exists := FSStrictExists
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept, Delete, Receipt, DeleteWith, Exists]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		if Delete != FSDeleteStrict || Receipt != _FSDeleteNativeReceipt
				|| DeleteWith != _FSDeleteWith || Exists != FSStrictExists
				|| Accept != _FSNativeAdmissionAccepted || !Accept.Call(AdmissionFn)
				|| Accept != _FSNativeAdmissionAccepted
				|| Delete != FSDeleteStrict || Receipt != _FSDeleteNativeReceipt
				|| DeleteWith != _FSDeleteWith || Exists != FSStrictExists
			return 0
		for Owner in [Accept, Delete, Receipt, DeleteWith, Exists]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return Delete.Call(Path)
	} finally Critical(PreviousCritical)
}


/** Writes a strict UTF-8 stage and retains the original close-before-move order. */
FSWriteUtf8ReplaceStrict(Path, Text) {
	Utf8ReplacementStream := FileOpen(Path . ".tmp", "w", "UTF-8-RAW")
	try Utf8ReplacementStream.Write(Text)
	finally Utf8ReplacementStream.Close()
	FileMove(Path . ".tmp", Path, true)
}

/** Encodes the complete UTF-8 image without its additional terminator byte. */
FSUtf8Bytes(Content) {
	Size := StrPut(Content, "UTF-8") - 1
	Bytes := Buffer(Size, 0)
	Encoded := Buffer(Size + 1, 0)
	StrPut(Content, Encoded, "UTF-8")
	DllCall("RtlMoveMemory", "Ptr", Bytes.Ptr, "Ptr", Encoded.Ptr, "UPtr", Size)
	return Bytes
}
