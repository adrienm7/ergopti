#!/usr/bin/env python3
"""Independent prospective receiving checks; SOURCE ONLY until a slot is granted."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

SOURCE_SHA = 'f73fc5a639589acf86b19260f4919bb776c68e4ac25a1ac2769d321f91eab097'
ABC_SHA = 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--proposal', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--keyring', type=Path, required=True)
    parser.add_argument('--phase', choices=('before', 'after'), required=True)
    parser.add_argument('--admitted-root', type=Path)
    args = parser.parse_args()
    source = args.proposal / 'setup_validation_curl.py'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_SHA
    producer = load(source, 'actual_validation_curl_source')
    pins = json.loads((args.proposal / 'PINS.json').read_text())
    owner_source = args.repo / 'tools/build/stage-linux-network-runtime.py'
    assert hashlib.sha256(owner_source.read_bytes()).hexdigest() == pins['command_owner_sha256']
    owner = load(owner_source, 'actual_qualified_native_command_owner')
    assert not owner.direct_children()
    workspace = Path(tempfile.mkdtemp(prefix='curl-negative-owned-'))
    os.chmod(workspace, 0o700)

    class Receiving(unittest.TestCase):
        def test_independent_nist_abc_positive(self):
            path = workspace / 'positive-abc'; path.write_bytes(b'abc')
            producer.checked(path, ABC_SHA, 3)

        def test_wrong_sha_refuses_before_extraction(self):
            path = workspace / 'corrupt-abc'; path.write_bytes(b'abd')
            with self.assertRaisesRegex(RuntimeError, '^Artifact checksum refused\\.$'):
                producer.checked(path, ABC_SHA, 3)

        def test_wrong_size_refuses_even_matching_digest(self):
            path = workspace / 'wrong-size'; path.write_bytes(b'abc')
            with self.assertRaisesRegex(RuntimeError, '^Artifact admission refused\\.$'):
                producer.checked(path, ABC_SHA, 4)

        def test_symlink_refuses_even_matching_bytes(self):
            target = workspace / 'link-target'; target.write_bytes(b'abc')
            link = workspace / 'artifact-symlink'; link.symlink_to(target)
            with self.assertRaisesRegex(RuntimeError, '^Artifact admission refused\\.$'):
                producer.checked(link, ABC_SHA, 3)

        def test_changed_owner_pin_refuses_actual_setup_before_acquisition(self):
            copied = workspace / 'bad-owner-proposal'; copied.mkdir(mode=0o700)
            shutil.copyfile(source, copied / source.name)
            wrong = json.loads((args.proposal / 'PINS.json').read_text())
            wrong['command_owner_sha256'] = '0' * 64
            (copied / 'PINS.json').write_text(json.dumps(wrong))
            destination = workspace / 'must-not-acquire'
            with self.assertRaisesRegex(owner.RuntimeRefused, '^Native packaging command refused\\.$'):
                owner.run(['python3', '-B', str(copied / source.name), '--repo', str(args.repo),
                           '--destination', str(destination), '--openssl-prefix', '/usr',
                           '--keyring', str(args.keyring)], budget_seconds=30)
            self.assertFalse(destination.exists(), 'wrong-owner admission must acquire no setup root')
            self.assertEqual(owner.direct_children(), [], 'failed child must be physically retired')

    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Receiving)
    if args.phase == 'after':
        assert args.admitted_root is not None
        admitted = args.admitted_root
        receipt = json.loads((admitted / 'TOOLS-ADMISSION.json').read_text())
        assert receipt['state'] == 'tools_admitted' and receipt['native_30_qualification'] == 'UNEXECUTED'
        legacy = pins['legacy']

        class AuthenticatedArtifacts(unittest.TestCase):
            def test_real_signed_release_bit_change_is_refused(self):
                original = admitted / 'InRelease'
                producer.checked(original, legacy['inrelease_sha256'])
                authentic = workspace / 'authentic-payload'
                valid = owner.run(['gpgv', '--keyring', str(args.keyring), '--status-fd', '1',
                                   '--output', str(authentic), str(original)], budget_seconds=30)
                self.assertIn('[GNUPG:] VALIDSIG ' + legacy['required_signer'] + ' ', valid)
                raw = original.read_bytes()
                commitment = legacy['metadata']['sha256'].encode('ascii')
                self.assertEqual(raw.count(commitment), 1)
                changed = workspace / 'changed-signed-release'
                changed.write_bytes(raw.replace(commitment, b'0' + commitment[1:]))
                with self.assertRaisesRegex(owner.RuntimeRefused, '^Native packaging command refused\\.$'):
                    owner.run(['gpgv', '--keyring', str(args.keyring), '--status-fd', '1',
                               '--output', str(workspace / 'refused-payload'), str(changed)], budget_seconds=30)
                self.assertEqual(owner.direct_children(), [])

            def test_real_package_index_truncation_is_refused(self):
                metadata = legacy['metadata']
                original = admitted / 'Packages.xz'
                producer.checked(original, metadata['sha256'], metadata['size'])
                changed = workspace / 'truncated-index'
                changed.write_bytes(original.read_bytes()[:-1])
                with self.assertRaisesRegex(RuntimeError, '^Artifact admission refused\\.$'):
                    producer.checked(changed, metadata['sha256'], metadata['size'])

            def test_real_selected_legacy_library_bit_change_is_refused(self):
                library = legacy['libraries'][0]
                original = admitted / 'legacy-libraries' / library['soname']
                producer.checked(original, library['file_sha256'])
                data = bytearray(original.read_bytes()); data[-1] ^= 1
                changed = workspace / 'changed-libcurl'; changed.write_bytes(data)
                with self.assertRaisesRegex(RuntimeError, '^Artifact checksum refused\\.$'):
                    producer.checked(changed, library['file_sha256'])
                producer.checked(original, library['file_sha256'])

        suite = unittest.defaultTestLoader.loadTestsFromTestCase(AuthenticatedArtifacts)
    # A missing native acknowledgement prevents cleanup of the retained inputs.
    outcome = unittest.TextTestRunner(verbosity=2).run(suite)
    expected = 5 if args.phase == 'before' else 3
    success = outcome.wasSuccessful() and outcome.testsRun == expected and not outcome.skipped
    if owner.direct_children():
        raise RuntimeError('Unexpected native child debt; negative inputs retained.')
    if success:
        shutil.rmtree(workspace)
    else:
        print('Negative-control failure; owned inputs retained at ' + str(workspace))
    raise SystemExit(0 if success else 1)


if __name__ == '__main__':
    main()
