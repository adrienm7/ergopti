"""Prepare a compact, portable supplement without rewriting the original audit."""
from pathlib import Path
from zoneinfo import ZoneInfo
import argparse, copy, datetime, hashlib, json, re, shutil, subprocess, tarfile

OUT = Path('/workspace/scratch/windows-post-ci-portable')
ROOT = Path('/workspace/ergopti-windows-integration')
DOCS = ROOT / 'docs/audits/windows-2026-10-28'
BASE = '3b33225970415794481337525e4cc23cb15f2922'
PROOFS = Path('/workspace/scratch/windows-final-shutdown-proof')
ORIGINAL_ARTIFACTS = {'evidence.tar.gz':'519cc2ac9c2fcde16effda1fb3abd4fe5a2bfbc15fef7c4aa48944a8e7adb0c7','owned-windows.bundle':'04fc656ca60e1387d76a0a3d7e8b2b94ba53c1596a8d9680b7b23bd022e66212'}


def git(*args, binary=False):
    data = subprocess.check_output(['git','-C',str(ROOT),*args])
    return data if binary else data.decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def now():
    return datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def paris(v):
    if isinstance(v,str) and len(v)<40 and v.endswith('Z') and 'T' in v:
        try:return datetime.datetime.fromisoformat(v.replace('Z','+00:00')).astimezone(ZoneInfo('Europe/Paris')).isoformat()
        except ValueError:pass
    if isinstance(v,dict):return {k:paris(x) for k,x in v.items()}
    if isinstance(v,list):return [paris(x) for x in v]
    return v


def extract_rows(value):
    rows=[]
    if isinstance(value,dict):
        if value.get('integrated_sha') and value.get('original_sha'):rows.append(value)
        for x in value.values():rows.extend(extract_rows(x))
    elif isinstance(value,list):
        for x in value:rows.extend(extract_rows(x))
    return rows


def main(receipt_path, expected_fixes):
    assert git('branch','--show-current')=='fix/windows'
    assert not git('status','--porcelain'), 'Source integration must be committed and clean'
    assert git('merge-base','--is-ancestor',BASE,'HEAD')==''
    for name,digest in ORIGINAL_ARTIFACTS.items():assert sha((DOCS/name).read_bytes())==digest
    receipt_path=Path(receipt_path).resolve()
    integration=json.loads(receipt_path.read_text())
    rows=extract_rows(integration)
    proof_map={'5ce0e246954ef3d150d9eb19a720fa9b2b0f4e6d':str(PROOFS/'fixture-proof.json'),'c8e977a8fb138082967a02a2531bf771fcbc6326':str(PROOFS/'compensation-proof.json'),'7348172a5698c0ab5251a1958b9d1e1448676fb4':'/workspace/scratch/windows-final-devcli-proof/proof.json'}
    for row in rows:row['proof']=proof_map[row['original_sha']]
    closed=json.loads((PROOFS/'completed.json').read_text())
    assert closed['ready_for_root_integration'] and closed['clean'] and closed['no_more_native_jobs']
    devcli=json.loads(Path('/workspace/scratch/windows-final-devcli-proof/proof.json').read_text())
    assert re.fullmatch('[0-9a-f]{40}',devcli['commit']) and devcli['hook_exit_code']==0
    assert set(closed['commits'])|{devcli['commit']} <= {r['original_sha'] for r in rows}
    assert len(rows)==expected_fixes and len({r['integrated_sha'] for r in rows})==expected_fixes, 'The exact reviewed bounded fix count is required'
    completed=json.loads((receipt_path.parent/'completed.json').read_text())
    assert completed['head']==git('rev-parse','HEAD'), 'Integration completion is stale'
    head=git('rev-parse','HEAD')
    for row in rows:
        assert git('merge-base','--is-ancestor',row['integrated_sha'],head)==''
        assert re.fullmatch('[0-9a-f]{40}',row['original_sha'])
    payload=OUT/'payload';payload.mkdir(exist_ok=True)
    roots=[PROOFS,Path('/workspace/scratch/windows-final-devcli-proof'),receipt_path.parent,Path('/workspace/scratch/windows-final-full-qualification')]
    roots += [Path(r['proof']).resolve().parent for r in rows]
    roots += [p for p in [Path('/workspace/scratch/windows-final-registry-path-proof'),Path('/workspace/scratch/windows-final-registry-peer')] if p.exists()]
    extensions={'.json','.log','.tap','.ahk','.patch','.md','.py','.txt','.cjs','.ps1','.sh'}
    paths=set()
    for folder in roots:
        paths.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in extensions and not any(n in p.parts for n in ['node_modules','.git','__pycache__']))
    delivery=Path('/workspace/scratch/windows-final-delivery')
    for leaf in ['root-ci-latest.json','ci-latest.json','failed-job-123111092632-annotations.json','failed-job-123111092632.json','failed-job-123111092631-annotations.json','failed-job-123111092631.json','failed-job-123111092749-annotations.json','failed-job-123111092749.json','archive-commit.json','archive-commit.log','dispatch-receipt.json','push-receipt.json','cleanup-receipt.json','full-js-supervisor.log','quick-gates.json']:
        p=delivery/leaf
        if p.is_file():paths.add(p)
    # Follow explicit compact proof references, including worker exit receipts.
    queue=list(paths);visited=set()
    def refs(value, base):
        if isinstance(value,str) and 0<len(value)<240 and '\x00' not in value and '\n' not in value:
            if value.startswith('/workspace/scratch/'):
                p=Path(value).resolve()
            elif not value.startswith(('http:','https:')):
                p=(base/value).resolve()
            else:return
            if str(p).startswith('/workspace/scratch/') and p.is_file() and p.suffix in extensions:queue.append(p)
        elif isinstance(value,dict):
            for x in value.values():refs(x,base)
        elif isinstance(value,list):
            for x in value:refs(x,base)
    while queue:
        p=queue.pop()
        if p in visited:continue
        visited.add(p)
        if p.suffix=='.json':
            try:refs(json.loads(p.read_bytes()),p.parent)
            except (ValueError,UnicodeError):pass
    paths=visited
    paths.update(p for p in Path('/workspace/scratch/windows-final-registry-path-proof/STOP-files').rglob('*') if p.is_file())
    paths.update(delivery.glob('failed-job-*.json'))
    mapping=[]
    for p in sorted(paths):
        data=p.read_bytes();assert len(data)<5*1024*1024,p
        relative=Path('evidence')/p.relative_to('/workspace/scratch')
        dest=payload/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        mapping.append({'original_path':str(p),'portable_path':str(relative),'sha256':sha(data),'bytes':len(data)})
    for source in rows:
        for kind in ['original_sha','integrated_sha']:
            commit=source[kind];folder=payload/'commits'/commit;folder.mkdir(parents=True,exist_ok=True)
            (folder/'message.txt').write_text(git('show','-s','--format=fuller',commit)+'\n')
            (folder/'source.patch').write_bytes(git('show','--format=','--binary',commit,binary=True))
    # Keep the new original branch history without repacking any old audit blobs.
    refs=sorted(set(ref for row in rows for ref in git('for-each-ref','--format=%(refname)','--contains',row['original_sha'],'refs/heads/windows','refs/heads/fix/windows').splitlines()))
    if 'refs/heads/windows/final-registry-path' not in refs:refs.append('refs/heads/windows/final-registry-path')
    branch_heads={ref:git('rev-parse',ref) for ref in refs}
    assert all(any(subprocess.run(['git','-C',str(ROOT),'merge-base','--is-ancestor',r['original_sha'],branch_head],capture_output=True).returncode==0 for branch_head in branch_heads.values()) for r in rows)
    bundle=payload/'post-validation-owned.bundle'
    subprocess.run(['git','-C',str(ROOT),'bundle','create',str(bundle),*refs,'^'+BASE],check=True,capture_output=True)
    verified=subprocess.run(['git','-C',str(ROOT),'bundle','verify',str(bundle)],capture_output=True,text=True)
    assert verified.returncode==0
    (payload/'bundle-verify.log').write_text(verified.stdout+verified.stderr)
    write_json(payload/'path-map.json',mapping)
    write_json(payload/'bundle-receipt.json',{'refs':branch_heads,'excluded_prerequisite':BASE,'sha256':sha(bundle.read_bytes()),'bytes':bundle.stat().st_size,'verify_exit_code':verified.returncode})
    # Retain the exact preparation recipe without adding runtime/cache files.
    shutil.copy2(Path(__file__),payload/'prepare.py')
    shutil.copy2(OUT/'POST_VALIDATION.template.md',payload/'POST_VALIDATION.template.md')
    shutil.copy2(OUT/'validate.py',payload/'validate.py')
    shutil.copy2(OUT/'URGENT_STOP.md',payload/'URGENT_STOP.md')
    manifest=[]
    for p in sorted(payload.rglob('*')):
        if p.is_file() and p!=payload/'SHA256SUMS':manifest.append(sha(p.read_bytes())+'  '+str(p.relative_to(payload)))
    (payload/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
    archive=OUT/'post-validation-evidence.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
        for p in sorted(payload.rglob('*')):
            if p.is_file():tar.add(p,arcname=str(Path('post-validation-evidence')/p.relative_to(payload)),recursive=False)
    previous=json.loads((DOCS/'report.json').read_text());assert len(previous['commits'])==160
    followups=[];appendix=['\n## Post-validation Windows corrections\n']
    for source in rows:
        commit=source['integrated_sha'];paragraphs=git('show','-s','--format=%B',commit).split('\n\n')
        changed=git('diff-tree','--no-commit-id','--name-only','-r',commit).splitlines()
        row={'sha':commit,'original_sha':source['original_sha'],'subject':paragraphs[0],'bug_and_root_cause':paragraphs[1] if len(paragraphs)>1 else '', 'fix_and_regression_details':'\n\n'.join(paragraphs[2:]),'added_or_strengthened_regression_files':[p for p in changed if '/tests/' in p or p.startswith('tools/test/')], 'integration_receipt':str(Path('post-validation-evidence/evidence')/receipt_path.relative_to('/workspace/scratch')),'proof_packets':[str(Path('post-validation-evidence/evidence')/Path(source['proof']).resolve().relative_to('/workspace/scratch'))],'qualification_scope':'Genuine extracted shutdown/reload bodies and ProgramActions_Stop under AutoHotkey/Wine, with faithful navigation/configuration ports; no physical Windows DLL or keyboard-hook qualification. Corrected-head full shared and native Windows CI remain required.'}
        packet=json.loads(Path(source['proof']).read_text())
        assert packet['commit']==source['original_sha']
        row['proof_qualification_fields']={k:packet[k] for k in ['native_scope','scope','qualification_scope','qualification_limit','native_windows_qualified'] if k in packet}
        if source['original_sha'] not in closed['commits']:row['qualification_scope']='The linked proof packet defines the exact runtime/model boundary; corrected-head full shared and native Windows CI remain required.'
        if source['original_sha']==devcli['commit']:
            row['qualification_scope']='Host PowerShell7.5.2 controls21/21 including4actual serialization values and8complete-entry cases; the fixed native PowerShell5.1 bridge remains unqualified until corrected-head Windows CI.'
        followups.append(row)
        appendix.extend([f"\n### {commit[:10]} {row['subject']}\n",f"\nFull SHA: `{commit}`; original: `{row['original_sha']}`.\n",row['bug_and_root_cause']+'\n',row['fix_and_regression_details']+'\n','\nRegression files:\n'])
        appendix.extend('- `'+p+'`\n' for p in row['added_or_strengthened_regression_files'])
        appendix.append('\nIntegration proof: `'+row['integration_receipt']+'` in `post-validation-evidence.tar.gz`.\n')
    previous['post_validation_followup']={'generated_at_paris':now(),'source_head':head,'baseline_hosted_head':BASE,'failed_run_id':40771445154,'failed_job_ids':[123111092749,123111092631,123111092632],'failed_job_urls':['https://github.com/adrienm7/ergopti/actions/runs/40771445154/job/123111092749','https://github.com/adrienm7/ergopti/actions/runs/40771445154/job/123111092631','https://github.com/adrienm7/ergopti/actions/runs/40771445154/job/123111092632'],'historical_commit_count_preserved':160,'fixes':followups,'archive':'post-validation-evidence.tar.gz','extraction_root':'post-validation-evidence/','corrected_shared_js':'not run; explicit urgent user stop before full corrected-batch qualification','corrected_native_windows_ci':'not dispatched; urgent stop and container deletion pending','unfixed_keymap_followup':'POST_VALIDATION.md and archived STOP_HANDOVER notes; no registry production correction claimed','initial_archives_unchanged':ORIGINAL_ARTIFACTS}
    first_ci=json.loads((delivery/'root-ci-latest.json').read_text())
    previous['post_validation_followup']['first_hosted_run_final_observation']={k:first_ci.get(k) for k in ['headSha','status','conclusion','url','updatedAt']}
    write_json(OUT/'report.json',paris(previous))
    introduction=(DOCS/'README.md').read_text()
    title='# Windows audit handover, 28 October 2026\n'
    update='\nPost-validation update: the first hosted run exposed two fixture failures and\nreview of the same shutdown flow proved one production compensation defect.\nSee [POST_VALIDATION.md](POST_VALIDATION.md) for the three saved corrections, the unresolved 21 keymap failures, urgent-stop\nrecovery instructions and exact before/after evidence. The original\n160-commit index and binary archives remain historical and unchanged; the\ncorrected batch remains unqualified: work stopped before new full shared or\nnative Windows CI runs at the explicit urgent stop request.\n'
    assert title in introduction
    (OUT/'README.md').write_text(introduction.replace(title,title+update,1))
    original=(DOCS/'COMMITS.md').read_text()
    note='\nThe original 160-commit index is historical. The post-validation Windows fixes and their integrated source head are documented in the appendix.\n'
    anchor='# Atomic Windows audit commits\n'
    assert anchor in original
    (OUT/'COMMITS.md').write_text(original.replace(anchor,anchor+note,1)+''.join(appendix))
    prose=(OUT/'POST_VALIDATION.template.md').read_text()
    prose=prose.replace('The correction and\nits exact before/after controls are documented below once the integration\nreceipts are complete.', 'False, Error and empty-message Error refusal controls failed on the original\ncode while both healthy controls passed. The corrected focused cohort passed\n5/5, and the complete user-program cohort passed 17/17. The registry gate now\nruns inside both existing compensation scopes, preserving exact configuration\nbundle and navigation ownership. The proof executes genuine shutdown/reload\nbodies and ProgramActions_Stop in AutoHotkey under Wine; surrounding navigation\nand configuration owners are faithful stateful ports, with no physical Windows\nDLL or keyboard-hook qualification claimed.')
    prose += (OUT/'URGENT_STOP.md').read_text()
    prose += '\n## Integrated fixes\n\nSource checkpoint: `'+head+'`.\n\n'
    for row in followups:prose += '- `'+row['sha']+'` '+row['subject']+'\n'
    prose += '\nVerify and extract the supplement in its separate namespace:\n\n```sh\nsha256sum -c POST_VALIDATION_SHA256SUMS\ntar -xzf post-validation-evidence.tar.gz\ncd post-validation-evidence\nsha256sum -c SHA256SUMS\n```\n'
    (OUT/'POST_VALIDATION.md').write_text(prose)
    final=copy.deepcopy(previous['post_validation_followup']);final['archive_sha256']=sha(archive.read_bytes());final['archive_bytes']=archive.stat().st_size;final['proof_files']=len(mapping)
    write_json(OUT/'post-validation-receipt.json',paris(final))
    (OUT/'POST_VALIDATION_SHA256SUMS').write_text(sha(archive.read_bytes())+'  post-validation-evidence.tar.gz\n')
    print(json.dumps({'head':head,'followups':len(followups),'archive_bytes':archive.stat().st_size,'proof_files':len(mapping),'publication':'not performed'}))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--integration-receipt',required=True);parser.add_argument('--expected-fixes',type=int,required=True)
    options=parser.parse_args();main(options.integration_receipt,options.expected_fixes)
