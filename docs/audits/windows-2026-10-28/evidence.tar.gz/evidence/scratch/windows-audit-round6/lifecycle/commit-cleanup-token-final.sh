#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import json,re,hashlib,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle');w=out.parent/'verification-worker'
for job in ['480-lifecycle-cleanup-token-final-native20']:
 receipt=json.loads((w/'receipts'/(job+'-exit.json')).read_text());assert receipt['exit_code']==0,receipt
for name,count in [('480-lifecycle-cleanup-token-final9',9),('480-lifecycle-cleanup-token-start-final2',2),('480-lifecycle-cleanup-token-suspend-final9',9)]:
 t=(w/(name+'.tap')).read_text(encoding='utf-8-sig');assert f'# {count} passed, 0 failed.' in t,(name,t[-1000:]);pairs=re.findall(r'^ok (\d+) - (.+)$',t,re.M);assert len(pairs)==count and {int(p[0]) for p in pairs}==set(range(1,count+1))
for p,h in json.loads((out/'cleanup-token-final-candidate-hashes.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
CHECK
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
git add -- static/ergopti_plus/windows/modules/keystats/keystats_prefetch.ahk static/ergopti_plus/windows/tests/unit/modules/keystats/metrics/test_metrics_cancel_retry.ahk
git commit -F /workspace/scratch/windows-audit-round6/lifecycle/cleanup-token-commit-message.txt
python3 - <<'CHECK'
from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
for p,h in json.loads((out/'cleanup-token-final-candidate-hashes.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
print(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
CHECK
