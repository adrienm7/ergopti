-- Read-only observations of original module loaders and file reads.
local packet=assert(arg[1]);local module=assert(arg[2])
local emit=io.write
local seen={}
local function record(file)
 if type(file)=='string' and file:sub(1,1)=='@' then file=file:sub(2) end
 if type(file)=='string' and file:sub(1,1)=='/' and not seen[file] then
  seen[file]=true;emit('READ_DEPENDENCY '..file..'\n')
 end
end
local loaders=package.searchers or package.loaders
for i,original in ipairs(loaders) do
 loaders[i]=function(name)
  local fn,where=original(name)
  if type(fn)=='function' then record(debug.getinfo(fn,'S').source);record(where) end
  return fn,where
 end
end
local open=io.open
io.open=function(file,mode) if mode==nil or mode:sub(1,1)=='r' then record(file) end;return open(file,mode) end
arg={packet,module};dofile(packet..'/run.lua')
