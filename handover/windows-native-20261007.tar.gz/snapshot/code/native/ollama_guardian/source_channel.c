#include "source_channel.h"
#include "guardian_inheritance.h"
#include <stdlib.h>
#include <string.h>

struct GSC_Owner {
    uint64_t id;
    GSC_Phase phase;
    DWORD first_error;
    GIL_Owner inheritance;
    HANDLE mapping, ready, release, parent, source;
    uint32_t close_attempted;
    uint32_t close_uncertain;
    uint32_t source_close_attempted,source_close_uncertain,source_terminal;
    DWORD source_pid;
    FILETIME source_creation;
    uint32_t record_capacity, path_capacity, bytes;
    uint8_t expected_manifest[32];
    void *view;
    GI_Expected *records;
    uint16_t *paths;
    size_t count;
};

static int GSC_Error(GSC_Owner *owner, DWORD error) {
    if(owner->first_error==ERROR_SUCCESS)
        owner->first_error=error!=ERROR_SUCCESS?error:ERROR_INVALID_DATA;
    owner->phase=GSC_RETAINED_DEBT;
    return 0;
}
static uint64_t GSC_Time(FILETIME value) {
    return ((uint64_t)value.dwHighDateTime<<32)|value.dwLowDateTime;
}
static int GSC_Process(GSC_Owner *owner) {
    FILETIME creation,exit_time,kernel,user;
    DWORD waited;
    if(owner->source==NULL)return GSC_Error(owner,ERROR_PROCESS_ABORTED);
    waited=WaitForSingleObject(owner->source,0u);
    if(waited!=WAIT_TIMEOUT)
        return GSC_Error(owner,waited==WAIT_FAILED?GetLastError():ERROR_PROCESS_ABORTED);
    if(GetProcessId(owner->source)!=owner->source_pid)
        return GSC_Error(owner,ERROR_INVALID_DATA);
    if(!GetProcessTimes(owner->source,&creation,&exit_time,&kernel,&user))
        return GSC_Error(owner,GetLastError());
    if(CompareFileTime(&creation,&owner->source_creation)!=0)
        return GSC_Error(owner,ERROR_INVALID_DATA);
    return 1;
}

GSC_Owner *GSC_Create(uint64_t id,uint32_t record_capacity,uint32_t path_capacity,
                      const uint8_t digest[32]) {
    GSC_Owner *owner;
    size_t bytes;
    HANDLE current;
    if(id==0u || record_capacity==0u || path_capacity==0u || digest==NULL)return NULL;
    bytes=sizeof(GSC_Header);
    if((size_t)record_capacity>(SIZE_MAX-bytes)/sizeof(GSC_Record))return NULL;
    bytes+=(size_t)record_capacity*sizeof(GSC_Record);
    if((size_t)path_capacity>(SIZE_MAX-bytes)/sizeof(uint16_t))return NULL;
    bytes+=(size_t)path_capacity*sizeof(uint16_t);
    if(bytes>UINT32_MAX)return NULL;
    owner=calloc(1u,sizeof(*owner));
    if(owner==NULL)return NULL;
    /* Return this owning object even when a later acquisition fails. No native
       resource is created before the row exists and contains owning slots. */
    owner->id=id;owner->phase=GSC_UNBOUND;
    owner->record_capacity=record_capacity;owner->path_capacity=path_capacity;
    owner->bytes=(uint32_t)bytes;memcpy(owner->expected_manifest,digest,32u);
    owner->mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,
        0u,owner->bytes,NULL);
    if(owner->mapping==NULL){GSC_Error(owner,GetLastError());return owner;}
    owner->view=MapViewOfFile(owner->mapping,FILE_MAP_WRITE,0u,0u,owner->bytes);
    if(owner->view==NULL){GSC_Error(owner,GetLastError());return owner;}
    memset(owner->view,0,owner->bytes);
    owner->ready=CreateEventW(NULL,TRUE,FALSE,NULL);
    if(owner->ready==NULL){GSC_Error(owner,GetLastError());return owner;}
    owner->release=CreateEventW(NULL,TRUE,FALSE,NULL);
    if(owner->release==NULL){GSC_Error(owner,GetLastError());return owner;}
    current=GetCurrentProcess();
    if(!DuplicateHandle(current,current,current,&owner->parent,
        SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,0u)){
        GSC_Error(owner,GetLastError());return owner;
    }
    return owner;
}

int GSC_Inherited(GSC_Owner *owner,HANDLE *mapping,HANDLE *ready,
                   HANDLE *release,HANDLE *parent) {
    if(owner==NULL || owner->phase!=GSC_UNBOUND || mapping==NULL || ready==NULL ||
        release==NULL || parent==NULL || owner->view==NULL || owner->parent==NULL)return 0;
    *mapping=owner->mapping;*ready=owner->ready;*release=owner->release;*parent=owner->parent;
    return 1;
}

static int GSC_GetFlags(void *context,uintptr_t value,uint32_t *flags,uint32_t *error) {
    DWORD actual=0u;(void)context;
    if(!GetHandleInformation((HANDLE)value,&actual)){*error=GetLastError();return 0;}
    *flags=actual;return 1;
}
static int GSC_SetFlags(void *context,uintptr_t value,uint32_t flags,uint32_t *error) {
    (void)context;
    if(!SetHandleInformation((HANDLE)value,HANDLE_FLAG_INHERIT,flags)){*error=GetLastError();return 0;}
    return 1;
}
int GSC_InheritanceUsed(const GSC_Owner *owner) { return owner!=NULL && owner->inheritance.used!=0u; }
int GSC_AcquireInheritance(GSC_Owner *owner,uint64_t token) {
    uintptr_t handles[4];GIL_Ports ports;
    if(owner==NULL || owner->phase!=GSC_UNBOUND || owner->inheritance.used || owner->first_error!=0u)return 0;
    handles[0]=(uintptr_t)owner->mapping;handles[1]=(uintptr_t)owner->ready;
    handles[2]=(uintptr_t)owner->release;handles[3]=(uintptr_t)owner->parent;
    ports.context=owner;ports.get=GSC_GetFlags;ports.set=GSC_SetFlags;
    if(!GIL_Begin(&owner->inheritance,token,handles,&ports))
        return GSC_Error(owner,owner->inheritance.first_error);
    return 1;
}
int GSC_ReleaseInheritance(GSC_Owner *owner,uint64_t token) {
    if(owner==NULL || token==0u || token!=owner->inheritance.token)return 0;
    if(!GIL_Release(&owner->inheritance,token))
        return GSC_Error(owner,owner->inheritance.first_error);
    return 1;
}
uint64_t GSC_InheritanceToken(const GSC_Owner *owner) { return owner!=NULL?owner->inheritance.token:0u; }

static int GSC_BindMode(GSC_Owner *owner,HANDLE source,uint32_t transferred) {
    FILETIME exit_time,kernel,user;
    GSC_Header *header;
    if(owner==NULL || owner->phase!=GSC_UNBOUND || source==NULL ||
        !GIL_CanRetire(&owner->inheritance) || owner->first_error!=0u ||
        (transferred?owner->inheritance.used:!owner->inheritance.used))return 0;
    if(!DuplicateHandle(GetCurrentProcess(),source,GetCurrentProcess(),&owner->source,
        SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_DUP_HANDLE,FALSE,0u))
        return GSC_Error(owner,GetLastError());
    owner->source_pid=GetProcessId(owner->source);
    if(owner->source_pid==0u)return GSC_Error(owner,GetLastError());
    if(!GetProcessTimes(owner->source,&owner->source_creation,&exit_time,&kernel,&user))
        return GSC_Error(owner,GetLastError());
    if(!GSC_Process(owner))return 0;
    header=owner->view;
    header->magic=GSC_WIRE_MAGIC;header->version=GSC_WIRE_VERSION;
    header->channel_id=owner->id;header->source_pid=owner->source_pid;
    header->source_creation=GSC_Time(owner->source_creation);
    memcpy(header->manifest_sha256,owner->expected_manifest,32u);
    header->bytes=owner->bytes;
    header->record_capacity=owner->record_capacity;
    header->path_capacity=owner->path_capacity;
    owner->phase=GSC_BOUND;
    return 1;
}

int GSC_Bind(GSC_Owner *owner,HANDLE source) { return GSC_BindMode(owner,source,0u); }
/* Internal intake service only: these four original channel handles never
   become inheritable. GAI transfers them to the captured original process. */
int GSC_BindTransferred(GSC_Owner *owner,HANDLE source) { return GSC_BindMode(owner,source,1u); }

int GSC_Poll(GSC_Owner *owner) {
    GSC_Header before,after;
    GSC_Record *wire;
    uint16_t *paths;
    size_t i,j;
    DWORD waited;
    if(owner==NULL)return 0;
    if(owner->phase==GSC_DATA_READY)return GSC_Process(owner);
    if(owner->phase!=GSC_BOUND)return 0;
    /* Detect a failed unpublished helper too; otherwise this retained process
       reference would keep SourceTask's job accounting alive indefinitely. */
    if(!GSC_Process(owner))return 0;
    waited=WaitForSingleObject(owner->ready,0u);
    if(waited==WAIT_TIMEOUT)return 0;
    if(waited!=WAIT_OBJECT_0)return GSC_Error(owner,waited==WAIT_FAILED?GetLastError():ERROR_INVALID_DATA);
    if(!GSC_Process(owner))return 0;
    memcpy(&before,owner->view,sizeof(before));
    if(before.magic!=GSC_WIRE_MAGIC || before.version!=GSC_WIRE_VERSION ||
        before.channel_id!=owner->id || before.source_pid!=owner->source_pid ||
        before.source_creation!=GSC_Time(owner->source_creation) ||
        memcmp(before.manifest_sha256,owner->expected_manifest,32u)!=0 ||
        before.bytes!=owner->bytes || before.record_capacity!=owner->record_capacity ||
        before.path_capacity!=owner->path_capacity || before.record_count==0u ||
        before.record_count>owner->record_capacity || before.path_units==0u ||
        before.path_units>owner->path_capacity)return GSC_Error(owner,ERROR_INVALID_DATA);
    owner->records=calloc(before.record_count,sizeof(*owner->records));
    owner->paths=calloc(before.path_units,sizeof(*owner->paths));
    wire=calloc(before.record_count,sizeof(*wire));
    if(owner->records==NULL || owner->paths==NULL || wire==NULL){
        free(wire);return GSC_Error(owner,ERROR_NOT_ENOUGH_MEMORY);
    }
    memcpy(wire,(uint8_t *)owner->view+sizeof(GSC_Header),
        (size_t)before.record_count*sizeof(*wire));
    paths=(uint16_t *)((uint8_t *)owner->view+sizeof(GSC_Header)+
        (size_t)owner->record_capacity*sizeof(GSC_Record));
    memcpy(owner->paths,paths,(size_t)before.path_units*sizeof(*paths));
    memcpy(&after,owner->view,sizeof(after));
    if(memcmp(&before,&after,sizeof(before))!=0 || !GSC_Process(owner)){
        free(wire);return GSC_Error(owner,ERROR_INVALID_DATA);
    }
    for(i=0u;i<before.record_count;++i){
        GSC_Record *item=&wire[i];
        if(item->source_handle==0u || item->source_handle==UINTPTR_MAX || item->kind>1u ||
            item->reserved!=0u || item->path_units==0u || item->path_offset>=before.path_units ||
            item->path_units>=before.path_units-item->path_offset ||
            owner->paths[item->path_offset+item->path_units]!=0u){
            free(wire);return GSC_Error(owner,ERROR_INVALID_DATA);
        }
        for(j=0u;j<item->path_units;++j)if(owner->paths[item->path_offset+j]==0u){
            free(wire);return GSC_Error(owner,ERROR_INVALID_DATA);
        }
        owner->records[i].source_handle=(uintptr_t)item->source_handle;
        owner->records[i].kind=item->kind;owner->records[i].volume=item->volume;
        owner->records[i].index=item->index;
        owner->records[i].native_path=owner->paths+item->path_offset;
        owner->records[i].path_units=item->path_units;
        memcpy(owner->records[i].sha256,item->sha256,32u);
    }
    free(wire);owner->count=before.record_count;owner->phase=GSC_DATA_READY;
    return 1;
}

static int GSC_PublishMode(uint64_t expected_channel,HANDLE mapping,HANDLE ready,HANDLE release,HANDLE parent,
                 const uint8_t digest[32],const GI_Expected *items,size_t count) {
    GSC_Header *view;
    GSC_Header header;
    GSC_Record *records;
    uint16_t *paths;
    FILETIME creation,exit_time,kernel,user;
    HANDLE inherited[4]={mapping,ready,release,parent};
    size_t i,units=0u,bytes;
    if(mapping==NULL || ready==NULL || release==NULL || parent==NULL ||
        digest==NULL || items==NULL || count==0u)return 0;
    for(i=0u;i<4u;++i)if(!SetHandleInformation(inherited[i],HANDLE_FLAG_INHERIT,0u))return 0;
    view=MapViewOfFile(mapping,FILE_MAP_WRITE,0u,0u,sizeof(header));
    if(view==NULL)return 0;
    memcpy(&header,view,sizeof(header));
    if(!UnmapViewOfFile(view))return 0;
    if(header.magic!=GSC_WIRE_MAGIC || header.version!=GSC_WIRE_VERSION ||
        header.channel_id==0u || (expected_channel!=0u && header.channel_id!=expected_channel) || header.source_pid!=GetCurrentProcessId() ||
        header.record_capacity==0u || header.path_capacity==0u ||
        count>header.record_capacity || memcmp(digest,header.manifest_sha256,32u)!=0)return 0;
    if(!GetProcessTimes(GetCurrentProcess(),&creation,&exit_time,&kernel,&user) ||
        GSC_Time(creation)!=header.source_creation)return 0;
    bytes=sizeof(header);
    if((size_t)header.record_capacity>(SIZE_MAX-bytes)/sizeof(GSC_Record))return 0;
    bytes+=(size_t)header.record_capacity*sizeof(GSC_Record);
    if((size_t)header.path_capacity>(SIZE_MAX-bytes)/sizeof(uint16_t))return 0;
    bytes+=(size_t)header.path_capacity*sizeof(uint16_t);
    if(bytes!=header.bytes)return 0;
    for(i=0u;i<count;++i){
        if(items[i].source_handle==0u || items[i].kind>1u || items[i].native_path==NULL ||
            items[i].path_units==0u || items[i].path_units>=header.path_capacity ||
            units>header.path_capacity-items[i].path_units-1u)return 0;
        units+=items[i].path_units+1u;
    }
    view=MapViewOfFile(mapping,FILE_MAP_WRITE,0u,0u,header.bytes);
    if(view==NULL)return 0;
    if(memcmp(view,&header,sizeof(header))!=0){UnmapViewOfFile(view);return 0;}
    records=(GSC_Record *)((uint8_t *)view+sizeof(header));
    paths=(uint16_t *)((uint8_t *)view+sizeof(header)+(size_t)header.record_capacity*sizeof(*records));
    units=0u;
    for(i=0u;i<count;++i){
        records[i].source_handle=items[i].source_handle;
        records[i].volume=items[i].volume;records[i].index=items[i].index;
        records[i].kind=items[i].kind;records[i].path_offset=(uint32_t)units;
        records[i].path_units=(uint32_t)items[i].path_units;records[i].reserved=0u;
        memcpy(records[i].sha256,items[i].sha256,32u);
        memcpy(paths+units,items[i].native_path,items[i].path_units*sizeof(*paths));
        units+=items[i].path_units;paths[units++]=0u;
    }
    view->record_count=(uint32_t)count;view->path_units=(uint32_t)units;
    if(!UnmapViewOfFile(view))return 0;
    return SetEvent(ready)!=0;
}
const GI_Expected *GSC_Records(const GSC_Owner *owner,size_t *count) {
    if(owner==NULL || count==NULL || owner->phase!=GSC_DATA_READY)return NULL;
    *count=owner->count;return owner->records;
}
HANDLE GSC_Source(const GSC_Owner *owner) {
    return owner!=NULL && owner->phase==GSC_DATA_READY?owner->source:NULL;
}
GSC_Phase GSC_State(const GSC_Owner *owner) {
    return owner!=NULL?owner->phase:GSC_RETAINED_DEBT;
}
DWORD GSC_FirstError(const GSC_Owner *owner) {
    return owner!=NULL?owner->first_error:ERROR_INVALID_PARAMETER;
}
int GSC_RequestSourceRelease(GSC_Owner *owner) {
    if(owner==NULL || owner->release==NULL || owner->phase==GSC_RETIRED)return 0;
    if(!SetEvent(owner->release))return GSC_Error(owner,GetLastError());
    return 1;
}
int GSC_DropSourceReference(GSC_Owner *owner) {
    DWORD waited;
    if(owner==NULL)return -1;
    if(owner->source_terminal && owner->source==NULL)return 1;
    if(owner->source==NULL || owner->source_close_attempted)return -1;
    waited=WaitForSingleObject(owner->source,0u);
    if(waited==WAIT_TIMEOUT)return 0;
    if(waited!=WAIT_OBJECT_0){GSC_Error(owner,waited==WAIT_FAILED?GetLastError():ERROR_INVALID_DATA);return -1;}
    owner->source_terminal=1u;
    owner->source_close_attempted=1u;
    if(!CloseHandle(owner->source)){
        owner->source_close_uncertain=1u;GSC_Error(owner,GetLastError());return -1;
    }
    owner->source=NULL;
    return 1;
}
int GSC_TryRetire(GSC_Owner *owner) {
    HANDLE *slots[5];size_t i;DWORD waited;
    if(owner==NULL)return -1;
    if(owner->phase==GSC_RETIRED)return 1;
    /* These slots remain genuine capabilities while any flag reset is unknown. */
    if(!GIL_CanRetire(&owner->inheritance))return 0;
    if(owner->close_attempted!=0u)return -1;
    if(owner->source_close_uncertain)return -1;
    if(owner->source!=NULL){
        waited=WaitForSingleObject(owner->source,0u);
        if(waited==WAIT_TIMEOUT)return 0;
        if(waited!=WAIT_OBJECT_0){GSC_Error(owner,waited==WAIT_FAILED?GetLastError():ERROR_INVALID_DATA);return -1;}
        if(GSC_DropSourceReference(owner)!=1)return -1;
    }
    owner->close_attempted=1u;
    if(owner->view!=NULL){
        if(!UnmapViewOfFile(owner->view)){owner->close_uncertain=1u;GSC_Error(owner,GetLastError());return -1;}
        owner->view=NULL;
    }
    slots[0]=&owner->source;slots[1]=&owner->parent;slots[2]=&owner->mapping;
    slots[3]=&owner->ready;slots[4]=&owner->release;
    for(i=0u;i<5u;++i){
        HANDLE value=*slots[i];
        if(value==NULL)continue;
        if(!CloseHandle(value)){owner->close_uncertain=1u;GSC_Error(owner,GetLastError());return -1;}
        *slots[i]=NULL;
    }
    free(owner->records);free(owner->paths);owner->records=NULL;owner->paths=NULL;
    owner->phase=GSC_RETIRED;
    return 1;
}
int GSC_Retire(GSC_Owner *owner) { return GSC_TryRetire(owner)==1; }

int GSC_Publish(HANDLE mapping,HANDLE ready,HANDLE release,HANDLE parent,const uint8_t digest[32],const GI_Expected *items,size_t count) {
    return GSC_PublishMode(0u,mapping,ready,release,parent,digest,items,count);
}
int GSC_PublishIntake(uint64_t expected,HANDLE mapping,HANDLE ready,HANDLE release,HANDLE parent,const uint8_t digest[32],const GI_Expected *items,size_t count) {
    if(expected==0u)return 0;
    return GSC_PublishMode(expected,mapping,ready,release,parent,digest,items,count);
}
