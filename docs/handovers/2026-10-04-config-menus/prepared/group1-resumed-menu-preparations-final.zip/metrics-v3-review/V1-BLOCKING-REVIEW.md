# Rejected Metrics V1 Windows source

Packet `62cae6410a94bb81405f760fecde608b7c9324ed18617262d2ec35d3515a26af` has a blocking native Windows primitive defect. Its nonempty `Fields := Map(...)` is immediately followed by `Fields.CaseSense := "On"`, which throws under AHK v2 whenever the map contains entries, even when assigning the default value. Official Map documentation states: "Attempting to assign to this property causes an exception to be thrown if the Map is not empty." The native label capability cannot pass its new Windows tests when platform projection permits a label. Remove the redundant default-On assignment or set it before filling an empty map.

The same branch accepts explicitly supplied `unavailable = ""`, while the Lua capability and shared compiler accept only missing or literal "hide". Use field presence to distinguish missing from invalid empty values and add independent native rejection vectors.

Linux focused tests pass 40/0 on Lua 5.4 and LuaJIT; Mac 18/0 on Lua 5.4. These passes do not qualify the rejected Windows source. Actual original provider and renderer inverses reproduce causal failures. The parent and author have been notified; a corrected successor needs its own frozen SHA and review.
