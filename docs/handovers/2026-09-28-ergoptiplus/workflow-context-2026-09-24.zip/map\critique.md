# Completeness critique: 10 scope reports for R1–R35

The reports cover all 35 requests. I spot-checked 13 of their claims against the source: 12 hold and one needs a nuance. I also found one new fact that nobody reported, about the gestures runtime (section 1). The biggest risks are elsewhere: the reports contradict each other on shared key names, on how config migration should work, and on where the navigation layer is stored. Two suggested orders are also unsafe: renaming `global_actions` too early, and fixing default values in the wrong direction.

`SP` means `static/ergopti_plus`.

## 1. Spot-checks against the source

| # | Claim | Verdict | Evidence |
|---|---|---|---|
| 1 | R5/R20: the renderer drops a row's `action` when the row has `items`/`submenu`, and it skips a `toggle` row that has no command, logging only at DEBUG | **Confirmed** | `SP/_shared/lua/menu/renderer.lua:345-362` (`fn` is only set in the `elseif`), `:484-488` |
| 2 | R1: "Enable All" enables each named shortcut before `sync_runtime`, and `sync_runtime` is what resumes bindings | **Confirmed** | `SP/macos/ui/menu/global_actions_transaction.lua:431-442`; `bindings.lua:976-979` refuses when `lifecycle_paused`; `menu_state.lua:525-531` resumes only when `state.shortcuts` is true |
| 3 | R1/R5: the rollback puts every shortcut into `_disabled_set`, and the snapshot records live binding state rather than the user's preference | **Confirmed** | `bindings.lua:1106` (`enabled = hotkeys[name] ~= nil`), `global_actions_transaction.lua:264-269` (snapshot built from it), `:480-486` (inverse calls `disable`), `bindings.lua:1024-1027` (`_disabled_set[name] = true` when not bound) |
| 4 | R5/R33: the macOS gestures default drifts from the manifest, and a code comment about it is wrong | **Confirmed** | `SP/macos/modules/gestures/init.lua:113-117` says the flag "has no manifest path" and sets `gestures=false`; `manifest.toml:1859-1864` declares `enabled` with `default = true` |
| 5 | R8: the native logger declares failure at the 4th send, which is fatal | **Confirmed** | `SP/macos/adapters/log_transport.lua:28-29,814-822`; `SP/macos/init.lua:931` calls `emergency_exit_after_runtime_failure("native_logger")` |
| 6 | R30: the "Open Settings" button in the gesture-conflict dialog crashes because `text_utils` is nil | **Confirmed** | `SP/macos/ui/menu/menu_gestures.lua:295` is the file's only `text_utils` reference; no global is assigned anywhere in non-test `SP/macos` code |
| 7 | R11/R35: on Linux, a 304 response wipes the cached release | **Confirmed** | `SP/linux/modules/updater/manager.lua:441` (`_cached_release = nil`), `:281-284` (304 calls back with a nil body), `:446-453` (nil body means idle and not available) |
| 8 | R12: the changelog renders `<details>` as literal text | **Confirmed** | `.github/workflows/ci.yml:3014-3021` emits the tags; `SP/_shared/ui/markdown.js:13,553` shows raw HTML as literal text and strips only comments |
| 9 | R33: the Linux navigation layer has drifted from Windows | **Confirmed** | `SP/linux/platform/remap/data/kanata.kbd:55-57`: t=`f12`, g=`f2`, a/f=`C-up`/`C-down`, v and caps transparent. Windows `nav_layer.ahk:129,135-140,147`: T=F2, G=F12, `^+Up`/`^+Down`, CapsLock=BackSpace, V=End+Enter |
| 10 | R34: on Windows, Ctrl+Space does nothing because the AI is off and the handler returns silently | **Confirmed** | User config `autohotkey/config.toml:692-698` has `[llm] enabled = false`; `menu_settings.ahk:706-712` returns with no log and no UI |
| 11 | R18/R21: renaming the top-level id `global_actions` empties the macOS menu tail | **Confirmed** | `SP/macos/ui/menu/builder.lua:117-124` returns `{}`, so Reload, Quit and Debug disappear |
| 12 | Official Karabiner is bundled; the fork is CI-only | **Confirmed** | `SP/macos/vendor/karabiner-elements/manifest.json` pins pqrs Karabiner-Elements 16.0.0. The user calls it a "fork", so R3 wording should say "Ergopti's rules and variables", not "Ergopti's Karabiner" |
| 13 | R34: "Number of suggestions" appears twice | **Not at HEAD** | Only the top-level row plus a conditional "↳ Réinitialiser (défaut : N)" row (macOS `menu_llm/init.lua:1108-1124`; Windows `menu_settings.ahk:44-64` is the submenu of that same row). Either the packaged build is older or the user means the reset row. Ask the user |

**New finding (from reading the code, not run).** The gestures runtime runs even when Gestures is disabled:
- Boot starts gestures unconditionally (`SP/macos/init.lua:1043-1050`).
- `M.start` forces `CoreState.enabled = true` (`gestures/init.lua:1283`).
- `M.disable_all` only clears the flag (`:725-744`). It stops neither the touch watchers, nor the primer eventtap, nor the 30 s health-check timer (`:1016-1039`).

Consequences:
- The R7 log spam and the touch-watcher CPU cost continue with Gestures off.
- A "Health-check tick" line in the log **does not** show that gestures were on. The macos-blocking report's hypotheses cannot use it as evidence.
- Fix: `disable_all` (or the category toggle) should tear down the runtime, and `enable_all` should rebuild it.
- Regression test: `macos/tests/unit/modules/gestures/test_disable_stops_health_loop.lua`.

## 2. Requests with thin or missing coverage

- **R10, "last physical keys from Karabiner"**: no report found a data source. The Karabiner CLI is unverified, and EventViewer offers no API. Realistic option: Ergopti's own eventtap/hook keeps a small ring of recent keys, shown on screen only and never exported (the privacy rule from R26).
- **R10, permissions list on macOS**: only Accessibility and Screen Recording are probed today. Input Monitoring, driver-extension approval and guardian/Login Items state are proposed but have no owner. The child-processes and diagnostics reports each propose half of this.
- **R19**: only covered indirectly (master gate + neutral defaults + pause). No report specifies the "everything off, then turn features on one by one" flow on Windows, where `CategoryEnabled` already works as the model.
- **R6 on Windows and Linux**: Linux has no console at all. The optional "Live log" webview is only a suggestion.
- **R16 outside macOS**: effectively nothing to do. Every Ergopti key is already translated; only Sparkle's own UI is English.
- **R34, whether Win+Space can be swallowed**: stated as true from AHK hotkey semantics but not tested live. Decide the default key only after checking that the language flyout does not still appear.
- **R15, "every error"**: the diagnostics report recommends *not* showing a dialog per error (uncaught errors get a dialog, the rest a counter). That departs from the literal request, so it must go to the user as a decision rather than be presented as coverage.

## 3. Contradictions between reports

| Topic | Conflict | Resolution |
|---|---|---|
| R1 root cause | menu: medium confidence, the gestures/shortcuts boundary refuses. macos-blocking: high confidence, ordering bug. | Both can happen. The ordering bug is certain after "Disable All" or with Shortcuts off (checks 2 and 3). Fix the order, report refusals to the user, and fix the snapshot. |
| Locale tooling | menu: never run `check_locales.py --fix` for renames. updater, config and the i18n skill (`SKILL.md:35`) say run `--fix`. | `dump_locale` sorts alphabetically (`tools/locale/check_locales.py:69-81`), and `en.json` is not sorted (`:784-785`), so `--fix` rewrites all 21 files. It also fills missing keys with English placeholders. Use targeted in-place edits, or make one separate re-sort commit first. |
| `.tsv` files | diagnostics lists `locales/*.tsv` among files to change. | They are gitignored (`.gitignore:97`) and a generated cache (`i18n/SKILL.md:28-29`). Never edit them. |
| R25 shared keys | Three different namespaces proposed: `common.restore_recommended` + `common.clear_all_to_system_default` (menu), `menu.common.reset_recommended` + `menu.common.clear_all` (shortcuts), `common.clear_to_system` (config). | Pick one namespace before any R18/R25/R31 work. |
| R24 action ids | actions: unified `desktop_*` ids on all three OSes, with aliases. shortcuts: `space_*_wrap`, macOS only. | Unified ids need the alias and migration machinery. Also, Linux wmctrl already wraps, so a non-wrapping "normal" variant changes Linux behaviour. |
| R34 default chord | actions: Ctrl+Space on Windows/Linux, Ctrl+Opt+Space on macOS, opt-in. shortcuts: Win+Space on Windows, Ctrl+Space on macOS. | R33's "default no" principle points to no default binding, offered by the wizard instead. |
| Navigation-layer storage | config: one `keymap.toml` merging tap_hold, config_karabiner and layers. layouts: a separate `layers.toml`. | One decision needed. The config report's argument is stronger (layers reference hold keys), but the file needs its own `schema_version` either way. |
| Migration mechanism | macos-blocking: `moved_from` fields in the manifest. config: an op registry in `migrations.toml`. | Use one mechanism: the op registry. Hotstring moves become `rename` ops. |
| R27 / R2 details | Icon feature path `layout.menubar_icon` vs `ui.menubar_icon`. Header text "Méthodes de saisie" (user's wording) vs "Sources de saisie" (macOS wording). Input methods (IMEs) listed or not. | Pick one path. The header text depends on whether IMEs are listed: they are filtered out today (`input_sources.lua:381`). |
| R8 folder name | The user asked for an `ergopti_plus` subfolder on all three OSes. logging recommends `ErgoptiPlus` following each OS's convention. | Present both; do not assume either. |
| R18 sequencing | config marks the `configuration` rename as not needing a user decision and does not mention the anchor risk. | It breaks the macOS tail (check 11). Keep the `global_actions` id until head/tail dispatch lands, or ship both together. |
| Direction of default fixes | macos-blocking: make macOS defaults follow the manifest (gestures and metrics become true). config/R33: the manifest `default` becomes neutral (false). | Doing the first then the second flips macOS users on, then off. Decide the neutral-default question first, and fix the drift toward the final values only. |
| Duplicated proposals | Runtime-vs-boot fatal dialog (logging and diagnostics); Debug "Report a bug" rows (menu and diagnostics); errors-file tail (logging's issues ring and diagnostics' hook). | Compatible. Merge each into one owner. |

## 4. Claims that are unverified or shaky

- The Sparkle 1-hour minimum check interval (updater report) needs checking against the vendored Sparkle version. It decides whether macOS can offer the 1m/5m/30m frequencies.
- The macOS "paused" hypothesis for R5 is weak. The user could open the AI submenu, which is impossible while paused on dev.132 and later. The disabled toggle (check 1), the hotstring clean slate (commit `856c4aa60` is real, with no migration) and the all-or-nothing boot sync are the stronger explanations.
- The R30 idea that Force Touch trackpads store a 0 value for the 3-finger tap is speculation. One grep of the user's log settles it.
- The R8 trigger (App Nap / .utility QoS stall vs dropped datagram) is at medium confidence. The fix, a stall budget instead of 4 sends, is valid whichever it is.
- "`system_profiler` USB output is empty on recent macOS" (diagnostics) and "systemd `BindsTo` is skipped during auto-restart" (child-processes) are both unverified.

## 5. What blocks what, and a recommended order

**Phase 0: safe now, no user answer needed**
1. **R5/R20 unblock:** macOS registers `gestures_toggle`, `shortcuts_toggle`, `metrics_toggle` and `hotstrings_toggle` using today's on/off label rows, exactly like Linux. The renderer logs an ERROR when a row has both an action and a subtree. Converting these rows to real checkboxes waits for the R20 answer.
2. **R1/R5:** fix the Enable All order, make `list_shortcuts` report the preference, show a notification on refusal, and make the boot sync isolate failures per feature. These are needed even though R18 later removes the button, because the snapshot bug also hits Disable All, pause and saves.
3. Stop the gestures runtime when the feature is disabled (new finding). Log periodic loops only when something changes (R7).
4. Small, certain fixes: R30 `text_utils` require; R11 Linux 304 cache and Windows balloon-click ownership; R6 console size; R16 `CFBundleLocalizations`; R10 quick wins (wire `record_error` on macOS/Linux, Windows 11 name); R34 log and tooltip on each silent early return; R33 Linux kanata drift and kanata identity (R3).
5. R8: time-based stall budget plus Swift worker QoS/App Nap hardening (the 30 s value can be tuned later). Separate the runtime-failure dialog from the boot one (R15).
6. R12: token-level `<details>`/`<summary>` support in the renderer and the section splitter. Only the display order needs an answer.
7. R22 label; R9 and R17 French values as requested. The English wording for R17 is a question.

**Phase 1: foundations, most of which need answers**

| Foundation | Blocks |
|---|---|
| A. Manifest-driven menu head/tail on macOS and Windows | R21, R18 rename, R13 moving Updates into About |
| B. `schema_version` + migration op registry (R23) | R24 key removal and aliases, R34 trigger→slot migration, R13 Linux `stable`→`main`, R27 icon moving from hs.settings to config, hotstring section migration, R3 Karabiner switch, **every neutral-default change (R33/R19)** |
| C. Generated action catalogue | R4, R24, R32, R34 action, Linux picker |
| D. One logs-dir resolver per driver + shared log file names | R8 relocation, R10 errors-file tail, R14 save-to-file location, R15 crash directory |
| E. Renderer: toggle as checkbox + generic `choice` row type | R20/R29, R31 key-combinations checkbox, R27 icon selector, R13 channel, R35 frequency |
| F. Update channel/frequency registry | R13, R35, R11 dialog |
| G. Physical-key registry keyed by `KeyboardEvent.code` | R33, R28 |

**Phase 2: menu restructure (after A and E)**
- R18: remove Enable/Disable All **only after** the per-category toggles are reachable on every driver; otherwise macOS users have no way left to turn features on.
- Then R21, R2, R27, R31, R25 (after the key namespace is chosen), R17.

**Phase 3: features**
- R4 tiers, R32, R24, R34 (needs C, B and Linux key swallowing).
- R10 overhaul + R26 redaction, R14/R15 (needs D and the shared issue-link builder).
- R11 dialog, R13 sync, R35 scheduler (need F and the Sparkle ownership answer).

**Phase 4: large projects**
- R33 layer editor and neutral defaults with the first-run wizard (need B, G, and the answer on what happens to existing installs).
- R28 layout manager (needs G; Optimot licence answer).

## 6. Questions to consolidate before Phase 1

Ask the user these once, deduplicated across the reports:
1. **Existing installs when defaults become off:** keep each user's current behaviour, or reset everyone? This gates B and R33.
2. **What the first-row checkbox means:** a master gate that leaves children as they are, or "check all children"? (R20)
3. **One namespace for the shared reset/clear keys.** (R25)
4. **Navigation-layer file:** `keymap.toml` or `layers.toml`. (R33)
5. **Action ids for Spaces/desktops:** unified `desktop_*` or per-OS names. (R24)
6. **Default chord for "generate prediction",** or no default binding. (R34)
7. **Logs folder name** on each OS. (R8)
8. **Error UI policy:** a dialog for every error, or dialog plus counter. (R15)
9. **macOS update cadence and channel:** owned by Sparkle or by Ergopti. (R13/R35)
10. **Whether a hotstring-section migration should run** for configs written before the clean slate.