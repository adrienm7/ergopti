"""Materialize pinned portable inputs from explicit source roots; no Git mutation.

The compact capsule deliberately contains no runtime source tree. Pass retained
source roots (for example the immutable clock156 packet's runtime-source and the
actual repository) explicitly. Only bytes matching the inventory are copied.
This is software test input materialization, never native executable receiving.
"""
from pathlib import Path
import argparse
import hashlib
import json
import stat

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', action='append', required=True)
args = parser.parse_args()
roots = [base / 'candidate', base / 'preimage']
roots.extend(Path(item).resolve(strict=True) for item in args.source_root)
pins = json.loads((base / 'runtime-source-inventory.json').read_text())['files']
output = base / 'runtime-source'
output.mkdir(mode=0o700, exist_ok=True)
for relative, pin in pins.items():
    rel = Path(relative)
    if rel.is_absolute() or '..' in rel.parts:
        raise RuntimeError('Unsafe pinned relative input')
    target = output / rel
    if target.exists():
        raw = target.read_bytes()
        if len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256']:
            continue
        raise RuntimeError('Existing materialization differs: ' + relative)
    selected = None
    for root in roots:
        source = root / rel
        if not source.exists() or source.resolve(strict=True) != source:
            continue
        facts = source.lstat()
        if not stat.S_ISREG(facts.st_mode):
            continue
        raw = source.read_bytes()
        if len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256']:
            selected = source
            break
    if selected is None:
        raise RuntimeError('No exact retained source for: ' + relative)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(selected.read_bytes())
    if hashlib.sha256(target.read_bytes()).hexdigest() != pin['sha256']:
        raise RuntimeError('Input changed while materializing: ' + relative)
print(json.dumps({'materialized_inputs': len(pins), 'native_credit': False}))
