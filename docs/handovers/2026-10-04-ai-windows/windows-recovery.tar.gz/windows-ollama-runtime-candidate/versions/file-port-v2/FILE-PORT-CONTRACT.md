# Windows per-user Ollama native file preparation

This scratch implementation is not registered, integrated, source-approved or
qualified on Windows. It implements a file-helper prerequisite, not an Ollama
installer or an enabled AI service. Production files and pins are unchanged.

This is candidate v2. `WAL-CHANGES.md` describes its additional creation journal
and five causal/negative cases. The original root-level candidate and v1 remain
frozen for comparison.

## Native boundaries

`ollama_managed_files.ps1` accepts explicit `prepare`, `publish`, `cleanup`, or
`cleanup_partial`.
The caller passes a captured canonical catalogue path/hash, selected Windows
asset, private ticket, and per-user managed root. Publication and cleanup also
require the originating physical stage identity and final manifest hash.

The managed root is one explicitly selected immediate child of the current
user's actual LocalApplicationData. Native creation supplies its protected DACL
at creation: current user and SYSTEM full control, without inherited grants.
All existing ancestors, managed root, versions and prepared child directories
are held through native no-DELETE-share handles; reparse directories refuse.
Files open using OPEN_REPARSE_POINT and their actual handle attributes. Source
streams remain read-locked while their content is consumed.

Archive inspection starts only after complete bytes and SHA-256 agree with the
captured canonical source. Archive lengths/counts may additionally use caller
budgets; no separate release policy or duplicate pinned constants are added.
The helper checks declared total overflow/free space, each extracted stream's
exact declared length, traversal, rooted names, alternate streams, device names,
native case collisions, ambiguous trailing punctuation, reparse/special entries
and collisions with private receipts. All portable files are extracted,
including GPU/CPU libraries and the bundled prerequisite executable as data.
The helper never executes bundled vc_redist or any extracted executable.

Prepared admission checks the exact physical directory and locked manifest,
declared file sizes/hashes and the complete directory inventory. Publication
uses the exact directory handle with native no-replace rename to a version,
asset and archive-digest leaf. No current pointer, config/API selection, model
download or master-enable state is changed.

Cleanup keeps a durable root journal containing the originating manifest bytes
and identities before removal. Existing files and directories retire through
their exact DELETE-capable handles. Partial deletion can retry with that same
journal; unknown identities/content preserve debt. Only classified physical
path absence acknowledges final directory retirement. Root journal deletion
also uses an exact held file handle.

`ollama_install_files_port.ahk` provides one native helper task owner. Its spawn
port must publish an exact construction task before yielding, must return that
same task, and must not hide debt if construction throws. This contract awaits
the Group 3 ShellRunner receipt API; there is deliberately no invented adapter
overload. Captured output bounds come from its caller. Cancellation uses
`requestTerminate`, preserving physical completion. The physical observer runs
independently of source drift/pause, must adopt private file evidence and must
acknowledge retirement. Logical result callbacks require the original source.

The separately prepared `ollama_runtime_owner.ahk` also has an explicit physical
retirement observer: immutable version lease cleanup is never suppressed by a
stale logical exit callback. `ollama-runtime-launch.ps1` launches only the selected
foreground CLI under the existing job, with child-only configured loopback port
and models directory. Launch acceptance is not HTTP readiness or AI enablement.

## Genuine evidence and limits

Ten tiny independent ZIP fixtures were authored from inert ASCII payloads.
`test_ollama_install_files.ps1` prepares 25 native acceptance cases, all
**unexecuted**. No PowerShell/C# compilation, AHK parse, Windows handle/DACL/
rename/disposition test, native extraction, CLI launch or installation ran.
Fixture preparation and static PE import inspection are not those validations.
No suites ran while the parent owns its serial verification slot.

The parent's full official ARM64 archive receipt proves the complete archive's
24,673,830 bytes/digest and two-entry 49,928,912-byte expanded layout. Read-only
PE import inspection of that verified CLI shows Universal CRT API-set imports,
KERNEL32 and ADVAPI32, with no direct VCRUNTIME/MSVCP or delay imports. This
does not qualify dynamically loaded libraries or successful native startup.
The AMD64 24-entry, 3,661,563,960-byte expanded layout is observed only from a
bounded HTTP central-directory tail; complete AMD64 digest is unverified.
Its GPU/backend prerequisites therefore remain unknown.

## Blockers before adoption

1. The new installation-specific creation journal and exact partial cleanup
   require independent review and Windows qualification. Intent-only objects
   or changed/uncaptured journal images retain honest debt. The config/API
   source WAL cannot lend its authority to these objects. Do not recursively
   delete partial stages.
2. Native Windows must prove directory rename while exact child/file handles
   remain held and prove actual NtSetInformationFile layouts, DACL inheritance,
   classified missing paths and cleanup retry semantics. Source reasoning does
   not establish those API results.
3. The atomic construction receipt must be wired to the adapter owner's actual
   final API. The earlier runtime draft still uses the seven-argument adapter;
   interrupted constructor debt there is not yet closed.
4. A separate native large-download port remains required. Ordinary
   CurlAsyncRequest's 8 MiB limit must stay unchanged. Source-owned TLS/proxy/
   redirects and exact bytes/digest need physical failure and cleanup tests.
5. Published runtime version files need an exact retained immutable-version
   lease across actual CLI/library loading and retirement. No-replace naming
   alone cannot prevent another current-user process from changing content.
6. Shared consent/menu/session composition, initial source-fenced endpoint
   readiness, truthful missing-prerequisite refusal and explicit model-install
   consent remain unimplemented. Native full unit/E2E, packaging, per-user
   installation/restart and actual model/service behavior remain required.
