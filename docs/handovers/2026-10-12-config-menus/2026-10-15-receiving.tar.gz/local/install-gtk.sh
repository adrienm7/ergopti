#!/usr/bin/env bash
set -euo pipefail
cloud_gtk_base=/workspace/.ergopti-cloud
export APT_CONFIG="$cloud_gtk_base/apt/apt.conf"
mkdir -p "$cloud_gtk_base/gtk-root" "$cloud_gtk_base/gtk-downloads"
apt-get update > "$cloud_gtk_base/gtk-apt-update.log" 2>&1
/usr/bin/python3 - <<'PY'
import hashlib,json,pathlib,subprocess,urllib.request,datetime
base=pathlib.Path('/workspace/.ergopti-cloud')
manifest=json.loads((base/'gtk-dependency-feasibility.json').read_text())
rows=[]
for p in manifest['selected']:
    fields={}
    record=subprocess.check_output(['apt-cache','show',p['name']+'='+p['version']],text=True).split('\n\n')[0]
    for line in record.splitlines():
        if ': ' in line and not line.startswith(' '):
            key,value=line.split(': ',1);fields[key]=value
    assert fields['SHA256']==p['sha256'],p['name']
    assert fields['Filename']==p['filename'],p['name']
    assert int(fields['Size'])==p['archive_bytes'],p['name']
    archive=base/'gtk-downloads'/pathlib.Path(p['filename']).name
    if not archive.exists():
        with urllib.request.urlopen('https://deb.debian.org/debian/'+p['filename'],timeout=60) as response:
            archive.write_bytes(response.read())
    data=archive.read_bytes()
    assert len(data)==p['archive_bytes'] and hashlib.sha256(data).hexdigest()==p['sha256'],p['name']
    control=subprocess.check_output(['dpkg-deb','--field',str(archive),'Package','Version'],text=True)
    assert 'Package: '+p['name'] in control and 'Version: '+p['version'] in control,control
    subprocess.run(['dpkg-deb','--extract',str(archive),str(base/'gtk-root')],check=True)
    rows.append({**p,'archive':str(archive),'verified_against_refreshed_signed_index':True,'extracted':True})
    print(p['name'],p['version'],'verified/extracted',flush=True)
receipt={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXTRACTED_NOT_YET_RUNTIME_QUALIFIED','prefix':str(base/'gtk-root'),'system_packages_changed':False,'signature_policy':'APT signed-by Debian archive keyring; no insecure flags','package_count':len(rows),'packages':rows,'apt_update_log_sha256':hashlib.sha256((base/'gtk-apt-update.log').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((base/'gtk-dependency-feasibility.json').read_bytes()).hexdigest()}
(base/'gtk-install-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
PY
if [ -d "$cloud_gtk_base/gtk-root/usr/share/glib-2.0/schemas" ]; then
    glib-compile-schemas "$cloud_gtk_base/gtk-root/usr/share/glib-2.0/schemas"
fi
