#include "guardian_import.h"
#include <string.h>

static void GI_Error(GI_Row *row, uint32_t error) {
    if (row->first_error == 0u) row->first_error = error;
}

int GI_Begin(GI_Row *row, uint64_t id, uintptr_t source,
             const GI_Expected *expected, size_t count, GI_Port port) {
    size_t i, j;
    if (row == NULL || row->initialized != 0u) return 0;
    row->initialized = 1u;
    row->id = id;
    row->phase = GI_ACQUIRING;
    row->port = port;
    /* The server row already exists. A native duplicate writes directly into
       its owning slot, including a partial acquisition followed by refusal. */
    if (id == 0u || source == 0u || expected == NULL || count == 0u ||
        count > SIZE_MAX / sizeof(*row->contents) || port.allocate == NULL ||
        port.release == NULL || port.duplicate_source == NULL ||
        port.duplicate_content == NULL || port.validate_content == NULL ||
        port.close == NULL) {
        GI_Error(row, 1u); row->phase = GI_RESOURCE_DEBT; return 0;
    }
    for (i = 0u; i < count; ++i) {
        if (expected[i].source_handle == 0u || expected[i].kind > 1u ||
            expected[i].native_path == NULL || expected[i].path_units == 0u ||
            expected[i].path_units > (SIZE_MAX / sizeof(uint16_t)) - 1u) {
            GI_Error(row, 2u); row->phase = GI_RESOURCE_DEBT; return 0;
        }
        for (j = 0u; j < i; ++j) {
            if (expected[i].source_handle == expected[j].source_handle ||
                (expected[i].volume == expected[j].volume && expected[i].index == expected[j].index)) {
                GI_Error(row, 2u); row->phase = GI_RESOURCE_DEBT; return 0;
            }
        }
    }
    row->contents = port.allocate(port.context, count * sizeof(*row->contents));
    if (row->contents == NULL) {
        GI_Error(row, 3u); row->phase = GI_RESOURCE_DEBT; return 0;
    }
    memset(row->contents, 0, count * sizeof(*row->contents));
    row->count = count;
    if (port.duplicate_source(port.context, source, &row->source) != 1 || row->source == 0u) {
        GI_Error(row, 4u); row->phase = GI_RESOURCE_DEBT; return 0;
    }
    for (i = 0u; i < count; ++i) {
        if (port.duplicate_content(port.context, row->source, &expected[i], &row->contents[i].handle) != 1 ||
            row->contents[i].handle == 0u) {
            GI_Error(row, 5u); row->phase = GI_RESOURCE_DEBT; return 0;
        }
        row->acquired = i + 1u;
        if (port.validate_content(port.context, row->contents[i].handle, &expected[i]) != 1) {
            GI_Error(row, 6u); row->phase = GI_RESOURCE_DEBT; return 0;
        }
    }
    /* The import has copied all contents. Drop its source process reference
       before any SourceTask job-empty accounting can depend on its terminal. */
    row->source_close_attempted = 1u;
    if (port.close(port.context, row->source) != 1) {
        row->source_close_uncertain = 1u;
        GI_Error(row, 7u); row->phase = GI_RESOURCE_DEBT; return 0;
    }
    row->source = 0u;
    row->phase = GI_PREPARED;
    return 1;
}

int GI_MarkExported(GI_Row *row) {
    if (row == NULL || row->phase != GI_PREPARED || row->source != 0u ||
        row->source_close_uncertain != 0u || row->acquired != row->count) return 0;
    row->phase = GI_EXPORTED;
    return 1;
}

int GI_Abort(GI_Row *row) {
    size_t i;
    uint32_t uncertain = 0u;
    if (row == NULL || row->initialized == 0u || row->phase == GI_EXPORTED) return 0;
    if (row->phase == GI_ABORTED) return 1;
    if (row->port.close == NULL || row->port.release == NULL) return 0;
    for (i = 0u; i < row->count; ++i) {
        GI_Imported *item = &row->contents[i];
        if (item->handle == 0u) continue;
        if (item->attempted != 0u) {
            if (item->uncertain != 0u) uncertain = 1u;
            continue;
        }
        item->attempted = 1u;
        if (row->port.close(row->port.context, item->handle) == 1) item->handle = 0u;
        else {
            item->uncertain = 1u; uncertain = 1u; GI_Error(row, 8u);
        }
    }
    if (row->source != 0u) {
        if (row->source_close_attempted != 0u) {
            if (row->source_close_uncertain != 0u) uncertain = 1u;
        } else {
            row->source_close_attempted = 1u;
            if (row->port.close(row->port.context, row->source) == 1) row->source = 0u;
            else {
                row->source_close_uncertain = 1u; uncertain = 1u; GI_Error(row, 8u);
            }
        }
    }
    if (uncertain != 0u) {
        row->phase = GI_RESOURCE_DEBT; return 0;
    }
    if (row->contents != NULL) row->port.release(row->port.context, row->contents);
    row->contents = NULL; row->count = 0u; row->acquired = 0u;
    row->phase = GI_ABORTED;
    return 1;
}
