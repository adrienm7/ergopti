from pathlib import Path
import subprocess,json,os,datetime
from zoneinfo import ZoneInfo
out=Path('/workspace/scratch/windows-adapter-contract-followup/live-r29/cycle-baseline')
env=dict(os.environ,WINEPREFIX='/workspace/toolchain/wine-r3-metrics-owned')
argv=['timeout','--kill-after=5s','120s','xvfb-run','-a','wine','/workspace/toolchain/ahk/AutoHotkey64.exe','/ErrorStdOut=UTF-8','Z:'+str(out/'cycle.ahk').replace('/',chr(92))]
with (out/'native.log').open('w') as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'exit_code':r.returncode,'ended_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()}
(out/'results.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
