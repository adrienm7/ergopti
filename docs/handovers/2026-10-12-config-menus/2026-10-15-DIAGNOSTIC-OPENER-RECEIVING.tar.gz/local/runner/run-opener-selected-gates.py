import argparse,datetime,hashlib,json,os,subprocess,tempfile,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--lane',choices=['js','native'],required=True);p.add_argument('--tree',required=True);p.add_argument('--owned',required=True);a=p.parse_args()
out=Path('/workspace/.ergopti-cloud');view=Path('/workspace/ergopti') if a.lane=='js' else out/'config-healthcheck-opener-view';base='614970f3c2f8c2c1b6c27e27ff1c513dd6c933d7';prefix='opener-selected-'+a.lane;statuspath=out/(prefix+'-status.json');logpath=out/(prefix+'.log');assert not statuspath.exists(),'Inspect earlier gate status before retry'
owned=json.loads(Path(a.owned).read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=view,text=True).strip()
def snapshot():return {'head':git('rev-parse','HEAD'),'index_tree':git('write-tree'),'unstaged_paths':git('diff','--name-only'),'untracked_paths':git('ls-files','--others','--exclude-standard'),'source_sha256':{p:hashlib.sha256((view/p).read_bytes()).hexdigest() for p in owned}}
before=snapshot();assert before['head']==base and before['index_tree']==a.tree and not before['unstaged_paths'] and not before['untracked_paths']
selected=json.loads(subprocess.check_output(['node','-e',"const v=require('./tools/test/verify-change.cjs'); console.log(JSON.stringify([...v.selectGates(v.changedFiles(null)).keys()]));"],cwd=view,text=True))
expected={'format','js','hs','hs-e2e','linux','linux-e2e','linux-managed-http-native'};assert set(selected)==expected,(selected,expected)
keys=['format','js'] if a.lane=='js' else ['hs','hs-e2e','linux','linux-e2e','linux-managed-http-native'];scripts={'format':'format:check','js':'test:js','hs':'test:hs','hs-e2e':'test:hs:e2e','linux':'test:linux','linux-e2e':'test:linux:e2e','linux-managed-http-native':'test:linux:managed-http-native'}
tmp=tempfile.mkdtemp(prefix='eg-op-',dir='/var/tmp');env=os.environ.copy();env.update(TMPDIR=tmp,TEMP=tmp)
record={'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'physical_view':str(view),'lane':a.lane,'before':before,'planner_selected':selected,'gates_this_view':keys,'temporary_directory':tmp,'commands':[]};statuspath.write_text(json.dumps(record,indent=2)+'\n')
with logpath.open('w') as log:
 subprocess.run(['node','tools/test/verify-change.cjs','--plan'],cwd=view,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 for key in keys:
  command=['npm','run',scripts[key]];command_env=env.copy()
  if key=='linux-managed-http-native':
   activation=out/'native-http-prereqs-5ar36pu4/activate-native-http.sh';assert hashlib.sha256(activation.read_bytes()).hexdigest()=='a5b7d4b56c6427e9354afcd5e1d218060e71088a93520e510d669d5e0e5db294'
   command_env['ERGOPTI_MANAGED_NATIVE_EXPECTED_HEAD']=base
   command=['bash','-c','set -e; . "$1"; exec npm run test:linux:managed-http-native','opener-native-http',str(activation)]
   record['native_http_tool_prerequisites']=json.loads((out/'native-http-prereqs-5ar36pu4/FINAL-PREREQUISITES.json').read_text())
  log.write('\n=== '+key+' ===\n');log.flush();start=time.monotonic();r=subprocess.run(command,cwd=view,env=command_env,stdout=log,stderr=subprocess.STDOUT);entry={'gate':key,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start};record['commands'].append(entry);statuspath.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(entry),flush=True)
record['after']=snapshot();record['inputs_unchanged']=record['after']==before;record['status']='PASSED' if record['inputs_unchanged'] and all(c['exit_code']==0 for c in record['commands']) else 'FAILED';record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['log_sha256']=hashlib.sha256(logpath.read_bytes()).hexdigest();statuspath.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':record['status'],'lane':a.lane,'inputs_unchanged':record['inputs_unchanged'],'log_sha256':record['log_sha256']}),flush=True)
raise SystemExit(0 if record['status']=='PASSED' else 1)
