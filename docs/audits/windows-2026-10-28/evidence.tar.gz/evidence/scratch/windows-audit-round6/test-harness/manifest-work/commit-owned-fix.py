from pathlib import Path
import subprocess,json,sys,hashlib
root=Path('/workspace/ergopti-windows-r6-tests')
packet=Path(__file__).parent
receipts=Path('/workspace/scratch/windows-audit-round6/verification-worker/receipts')
assert json.loads((receipts/'090-manifest-work-preflight-exit.json').read_text())['exit_code']==0
expected={'tools/test/validate-ahk-suite-manifest.cjs','tools/test/test-ahk-suite-manifest.cjs'}
def run(args,capture=False):
 result=subprocess.run(args,cwd=root,text=True,stdout=subprocess.PIPE if capture else None,check=True)
 return result.stdout if capture else None
assert run(['git','rev-parse','HEAD'],True).strip()=='79ccbaaa69b66743c279528c58dac5745affd5de'
assert not run(['git','diff','--cached','--name-only'],True).strip()
assert set(run(['git','diff','--name-only'],True).splitlines())==expected
run(['node',str(packet/'observe-declared-plan-work.cjs')])
before={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected}
run(['git','add','--',*sorted(expected)])
run(['git','commit','-F',str(packet/'commit-message.txt')])
metadata=run(['git','log','-1','--format=%H%n%P%n%an <%ae>%n%cn <%ce>%n%B'],True)
(packet/'commit-metadata.txt').write_text(metadata)
assert 'Co-Authored-By' not in metadata
assert not run(['git','status','--porcelain=v1'],True).strip()
assert set(run(['git','diff','--name-only','HEAD^','HEAD'],True).splitlines())==expected
assert before=={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected}
(packet/'commit-receipt.json').write_text(json.dumps({'commit':metadata.splitlines()[0],'parent':metadata.splitlines()[1],'source_sha256':before,'clean':True,'normal_hooks':True},indent=2)+'\n')
print(metadata,flush=True)
