from pathlib import Path
import subprocess,json,os,signal,time,ctypes,sys,hashlib,datetime,re
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-picker-observer');root=Path('/workspace/scratch/oct28-cloner/race-url-replay');root.mkdir(mode=0o700)
if sys.platform=='linux':
 if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'Owned child observer admission failed')
def retire_group(gid):
 deadline=time.monotonic()+5
 while time.monotonic()<deadline:
  if sys.platform=='linux':
   while True:
    try:p,_=os.waitpid(-gid,os.WNOHANG)
    except ChildProcessError:break
    if not p:break
  try:os.killpg(gid,0)
  except ProcessLookupError:return
  time.sleep(.01)
 raise RuntimeError('Owned process group remains; retain fixture')
def run(argv,env=None):
 p=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:out,err=p.communicate(timeout=15)
 except subprocess.TimeoutExpired:
  if p.returncode is None:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
  p.communicate(timeout=5);retire_group(p.pid);raise
 retire_group(p.pid);return p.returncode,out,err
rows=[]
for version,snapshot in [('old','01-second'),('new','02-third')]:
 for shell in ['/usr/bin/bash','/usr/bin/zsh']:
  case=root/('race-'+version+'-'+Path(shell).name);case.mkdir(mode=0o700)
  helper=Path('/workspace/scratch/oct28-cloner')/snapshot/'resources/reserve_bundle.sh';cmd=[shell,str(w/'tools/test/lib/app-cloner-reservation-race.sh'),str(helper),str(case)]
  status,out,err=run(cmd);(case/'stdout.bin').write_bytes(out);(case/'stderr.log').write_bytes(err)
  assert (case/'owner-retired').exists() and not (case/'Contended.app').exists()
  if version=='new':assert status==0 and out==str(case/'Contended_1.app').encode()+b'\0' and not err and (case/'Contended_1.app').is_dir()
  else:assert status==1 and out==b'\0' and b'cannot reserve bundle directory' in err and not (case/'Contended_1.app').exists()
  rows.append({'kind':'reservation','version':version,'shell':shell,'actual_exit':status,'stdout_hex':out.hex(),'source_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'owned_group_retired':True})
uri_names={'https','http','teams-double','teams-chat','teams-calendar','opaque','custom'}
for version,snapshot in [('old','03-fourth'),('new','04-fifth')]:
 for shell in ['/usr/bin/bash','/usr/bin/zsh']:
  case=root/('url-'+version+'-'+Path(shell).name);case.mkdir(mode=0o700)
  source=Path('/workspace/scratch/oct28-cloner')/snapshot/'resources/clone_app.sh';cmd=[sys.executable,str(w/'tools/test/lib/app-cloner-url-routing-probe.py'),str(source),str(case),shell,str(case)]
  status,out,err=run(cmd);assert status==0 and not err;data=json.loads(out);(case/'receipt.json').write_bytes(out)
  assert len(data['cases'])==len({c['family']+':'+c['name'] for c in data['cases']})==36 and data['ui_validation'] is None
  wrong=[]
  for c in data['cases']:
   assert c['status']==0 and c['stdout']==c['stderr']==''
   args=[] if c['family']=='native' else ['--user-data-dir',c['owned_shell']+'/profile']
   if c['family']=='vscode':args+=['--extensions-dir',c['owned_shell']+'/extensions','--new-window']
   uri=c['name'] in uri_names
   if c['input'] and not uri:args+=[c['input']]
   execution=c['executions'];actual=(len(execution)==1 and len(execution[0])>=2 and execution[0][0] in ['-arm64','-x86_64'] and execution[0][1]=='fixture-executable' and execution[0][2:]==args and c['opens']==([['-a','fixture-application',c['input']]] if uri else []) and c['sleeps']==([['1']] if uri else []))
   if not actual:wrong.append(c['family']+':'+c['name'])
  assert len(wrong)==(0 if version=='new' else 12),wrong
  rows.append({'kind':'url','version':version,'shell':shell,'actual_exit':status,'actual_cases':36,'semantic_failures':wrong,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'owned_group_retired':True,'ui_validation':'actual AppleScript remains DarwinCI-only'})
rel='static/ergopti_plus/macos/apps/App Cloner.app/Contents/Resources/ShortcutBuilder.applescript';current=(w/rel).read_text();old=subprocess.check_output(['git','show','dab40053:'+rel],cwd=w,text=True)
handler_identical={}
for name in ['format_ui','toLower','validateOpenArg']:
 pattern=rf'(?ms)^on {name}\([^\n]*\n.*?^end {name}$';a=re.findall(pattern,current);b=re.findall(pattern,old);assert len(a)==len(b)==1;assert a==b;handler_identical[name]=hashlib.sha256(a[0].encode()).hexdigest()
r={'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'rows':rows,'current_ui_handlers_byte_identical_to_previous_proof':handler_identical,'app_activation':'NOT EXECUTED','native_darwin':'UNRUN; actual Linux kernel operations and actual bash/zsh with strict native command spies'};(root/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
