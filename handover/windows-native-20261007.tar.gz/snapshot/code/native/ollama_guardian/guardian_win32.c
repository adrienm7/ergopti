#include "guardian_win32.h"
#include <wchar.h>
#include <stdlib.h>

static void GG_WinError(GG_Win32Context *c, DWORD error) {
    if (c->first_os_error == ERROR_SUCCESS)
        c->first_os_error = error != ERROR_SUCCESS ? error : ERROR_INVALID_DATA;
}

static int GG_WinProcess(GG_Win32Context *c, HANDLE handle, DWORD expected_pid,
                         const FILETIME *expected_creation) {
    FILETIME creation, exit_time, kernel, user;
    DWORD pid = GetProcessId(handle);
    if (pid == 0u) { GG_WinError(c, GetLastError()); return 0; }
    if (!GetProcessTimes(handle, &creation, &exit_time, &kernel, &user)) {
        GG_WinError(c, GetLastError()); return 0;
    }
    if (pid != expected_pid || creation.dwLowDateTime != expected_creation->dwLowDateTime ||
        creation.dwHighDateTime != expected_creation->dwHighDateTime) {
        GG_WinError(c, ERROR_INVALID_DATA); return 0;
    }
    return 1;
}

static int GG_WinValidate(void *p, uintptr_t process, uintptr_t job) {
    GG_Win32Context *c = p;
    BOOL member = FALSE;
    if ((HANDLE)process != c->setup_process || (HANDLE)job != c->job ||
        c->parent_pid == 0u || c->daemon_pid == 0u || c->parent_pid == c->daemon_pid ||
        !GG_WinProcess(c, c->parent, c->parent_pid, &c->parent_creation) ||
        !GG_WinProcess(c, c->setup_process, c->daemon_pid, &c->daemon_creation)) {
        GG_WinError(c, ERROR_INVALID_DATA); return 0;
    }
    if (!IsProcessInJob(c->setup_process, c->job, &member)) {
        GG_WinError(c, GetLastError()); return 0;
    }
    if (!member) { GG_WinError(c, ERROR_INVALID_DATA); return 0; }
    if (!IsProcessInJob(GetCurrentProcess(), c->job, &member)) {
        GG_WinError(c, GetLastError()); return 0;
    }
    if (member) { GG_WinError(c, ERROR_INVALID_DATA); return 0; }
    if (!IsProcessInJob(c->parent, c->job, &member)) {
        GG_WinError(c, GetLastError()); return 0;
    }
    if (member) { GG_WinError(c, ERROR_INVALID_DATA); return 0; }
    return 1;
}

static int GG_WinWait(GG_Win32Context *c, HANDLE handle) {
    DWORD result = WaitForSingleObject(handle, 0u);
    if (result == WAIT_OBJECT_0) return 1;
    if (result == WAIT_TIMEOUT) return 0;
    GG_WinError(c, result == WAIT_FAILED ? GetLastError() : ERROR_INVALID_DATA);
    return -1;
}

static int GG_WinParent(void *p, uintptr_t handle) {
    GG_Win32Context *c = p;
    if ((HANDLE)handle != c->parent) { GG_WinError(c, ERROR_INVALID_DATA); return -1; }
    return GG_WinWait(c, c->parent);
}

static int GG_WinStop(void *p, uintptr_t handle) {
    GG_Win32Context *c = p;
    if ((HANDLE)handle != c->stop) { GG_WinError(c, ERROR_INVALID_DATA); return -1; }
    return GG_WinWait(c, c->stop);
}

static int GG_WinQuery(void *p, uintptr_t handle, uint32_t *members) {
    GG_Win32Context *c = p;
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION information;
    if ((HANDLE)handle != c->job || members == NULL) {
        GG_WinError(c, ERROR_INVALID_DATA); return 0;
    }
    if (!QueryInformationJobObject(c->job, JobObjectBasicAccountingInformation,
            &information, (DWORD)sizeof(information), NULL)) {
        GG_WinError(c, GetLastError()); return 0;
    }
    *members = information.ActiveProcesses;
    return 1;
}

static int GG_WinTerminate(void *p, uintptr_t handle) {
    GG_Win32Context *c = p;
    if ((HANDLE)handle != c->job) { GG_WinError(c, ERROR_INVALID_DATA); return 0; }
    if (!TerminateJobObject(c->job, c->terminate_code)) {
        GG_WinError(c, GetLastError()); return 0;
    }
    return 1;
}

static int GG_WinClose(void *p, uintptr_t handle) {
    GG_Win32Context *c = p;
    if (!CloseHandle((HANDLE)handle)) { GG_WinError(c, GetLastError()); return 0; }
    return 1;
}

GG_Port GG_Win32Port(GG_Win32Context *context) {
    GG_Port port = { context, GG_WinValidate, GG_WinParent, GG_WinStop,
                     GG_WinQuery, GG_WinTerminate, GG_WinClose };
    return port;
}

int GG_Win32CheckContent(GG_Win32Context *c, HANDLE handle,
                         const GG_Win32Identity *expected) {
    BY_HANDLE_FILE_INFORMATION information;
    wchar_t *path;
    DWORD length;
    DWORD required;
    size_t bytes;
    DWORD type;
    if (expected == NULL || expected->native_path == NULL || expected->is_directory > 1u) {
        GG_WinError(c, ERROR_INVALID_DATA); return 0;
    }
    SetLastError(ERROR_SUCCESS);
    type = GetFileType(handle);
    if (type != FILE_TYPE_DISK) {
        GG_WinError(c, type == FILE_TYPE_UNKNOWN ? GetLastError() : ERROR_INVALID_DATA);
        return 0;
    }
    if (!GetFileInformationByHandle(handle, &information)) {
        GG_WinError(c, GetLastError()); return 0;
    }
    if ((information.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0u ||
        ((information.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0u ? 1u : 0u) != expected->is_directory ||
        information.dwVolumeSerialNumber != expected->volume_serial ||
        information.nFileIndexHigh != expected->file_index_high ||
        information.nFileIndexLow != expected->file_index_low) {
        GG_WinError(c, ERROR_INVALID_DATA); return 0;
    }
    required = GetFinalPathNameByHandleW(handle, NULL, 0u, 0u);
    if (required == 0u) { GG_WinError(c, GetLastError()); return 0; }
    bytes = (size_t)required * sizeof(*path);
    if (bytes / sizeof(*path) != (size_t)required) {
        GG_WinError(c, ERROR_ARITHMETIC_OVERFLOW); return 0;
    }
    path = calloc(1u, bytes);
    if (path == NULL) { GG_WinError(c, ERROR_NOT_ENOUGH_MEMORY); return 0; }
    length = GetFinalPathNameByHandleW(handle, path, required, 0u);
    if (length == 0u) {
        GG_WinError(c, GetLastError()); free(path); return 0;
    }
    if (length >= required ||
        wcsncmp(path, L"\\\\?\\", 4u) != 0 || _wcsicmp(path + 4, expected->native_path) != 0) {
        GG_WinError(c, ERROR_INVALID_DATA); free(path); return 0;
    }
    free(path);
    return 1;
}
