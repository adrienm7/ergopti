Private SOURCE-only CI proposal. Root must obtain bounded custody for the two existing G6 step bodies before adoption. No main/index/ref/CI/test execution by author.

The existing five-minute receiving step retains both original5/8 calls and every original status/count/size/OK/no-skip guard. It appends direct APIwire20 and serve35 Python suites and logs. These run genuine portable process/pipe/EOF/reap fixture owners on both macOS architecture jobs, with modeled native framing/admission. They do not qualify actual accepted listener/socket/native READY or set NATIVE_PRODUCTION_QUALIFIED.

Exact inverse spans in SOURCE-PROOF recover the whole prior workflow. Original topology, conditions, SDK tests/builders and deadlines are byte-exact. Existing normal collector already registers20/35; no shared registry edits. Root must rerun the source-focused workflow guard/format after custody and actual hosted receiving remains pending.
