import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

R=Path('/workspace/ergopti'); P=Path(__file__).resolve().parent
CURRENT='60adb7e83d504b04ca807bfda8657254cccae306'; MAIN='63cf3d005d371edb4e4093a906da276ced487182'; DEV='9ad6fd159568edd11fba3a6baa0578cb2391421c'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def blob(commit,path):return git('show',f'{commit}:{path}')
archive=Path('/workspace/.ergopti-cloud/continuation-2026-10-12/snapshot16-diagnostic-existing-group-CI-v2/run-logs-attempt-2.archive.private.raw').read_bytes()
assert sha(archive)=='403b3dad7ba6e86fdbffed18b1811ad7187f42a471c26b4f6e361711a068e4a0'
with zipfile.ZipFile(__import__('io').BytesIO(archive)) as z:
    raw=z.read('Windows _ Unit tests/21_Run AHK test suite.txt')
assert sha(raw)=='406678a5921a04b9057a849920d64da46862ec369ac19ea2a928b2258e34c609'
line=next(line for line in raw.splitlines(keepends=True) if b'SNAPSHOT16_CAPTURE_REFUSAL ' in line)
receipt=json.loads(line.split(b'SNAPSHOT16_CAPTURE_REFUSAL ',1)[1])
assert len(receipt['launches'])==1;launch=receipt['launches'][0]
assert launch['mode']=='dry' and launch['status']==0 and launch['signal'] is None
facts=launch['capture_observation'];assert facts['first_mismatch_offset']==0 and facts['expected_byte']==35 and facts['observed_byte']==68
assert facts['captures']['stdout']['bytes']==1253792 and facts['captures']['tap']['bytes']==445 and facts['captures']['stderr']['bytes']==0
(P/'refusal.received.json.raw').write_bytes(json.dumps(receipt,indent=2).encode()+b'\n')
(P/'refusal.original-line.raw').write_bytes(line)
words={'Worker','Name','Callback','Count','Source','Owner','Command','Index'}
pattern=re.compile(r'(?m)^for\s+('+'|'.join(sorted(words))+r')\b[^\n]*')
current_paths=git('ls-tree','-r','--name-only',CURRENT,'--','static/ergopti_plus/windows/tests').decode().splitlines()
# Inventory listing here is bounded source name receiving, not a validation or native execution.
rows=[];main_unique=[]
for path in current_paths:
    if not path.endswith('.ahk'):continue
    content=blob(CURRENT,path).decode('utf-8-sig')
    hits=list(pattern.finditer(content))
    if not hits:continue
    main=blob(MAIN,path).decode('utf-8-sig');dev=blob(DEV,path).decode('utf-8-sig')
    mainlines=set(pattern.findall(main))
    for m in hits:
        number=content.count('\n',0,m.start())+1
        # Record exact global declaration line and original immediately following registration span.
        suffix=content[m.start():];end=suffix.find('\n\n'); block=suffix[:end] if end>=0 else suffix
        exact_in_main=block in main;exact_in_dev=block in dev
        rows.append({'path':path,'line':number,'symbol':m.group(1),'declaration':m.group(0),'binding_registration_block':block,'block_sha256':sha(block.encode()),'exact_block_present_Main63cf':exact_in_main,'exact_block_present_Dev9ad':exact_in_dev,'current_file_sha256':sha(blob(CURRENT,path)),'main_file_sha256':sha(blob(MAIN,path)),'dev_file_sha256':sha(blob(DEV,path))})
assert rows and set(row['symbol'] for row in rows)==words
RUN='static/ergopti_plus/windows/tests/run_all.ahk'
for row in rows:
    expected='#Include '+row['path'].split('/windows/tests/',1)[1]
    assert expected in blob(CURRENT,RUN).decode('utf-8-sig')
OWNER='static/ergopti_plus/_shared/ahk/tap_hold/buffered_data_snapshot_owner.ahk';TEST='static/ergopti_plus/windows/tests/unit/test_buffered_data_snapshot_owner.ahk'
snapshot={}
for path in (OWNER,TEST):
    text=blob(CURRENT,path).decode('utf-8-sig')
    assert not re.search(r'(?m)^for\s+',text)
    assert not re.search(r'(?im)^\s*global\s+(?:Worker|Name|Callback|Count|Source|Owner|Command|Index)\b',text)
    assert not re.search(r'(?m)^(?:Worker|Name|Callback|Count|Source|Owner|Command|Index)\s*:=',text)
    assert not re.search(r'\b(?:Worker|Callback|Command)\b',text)
    snapshot[path]={'sha256':sha(blob(CURRENT,path)),'bare_top_level_for_count':0,'generic_global_declarations_or_unindented_assignments':0,'Worker_Callback_Command_identifiers':0}
warns=re.findall(r'Specifically:\s*([A-Za-z_][A-Za-z_0-9]*)\s+\(in function ([A-Za-z_][A-Za-z_0-9]*)\)',launch['stdout']['tail_utf8'])
assert {w[0] for w in warns}==words-{'Worker'}
assert 'y: Worker  (in function _WBID_DrainRunsInTheDetachedWorker)' in launch['stdout']['tail_utf8']
partial_warning=('Worker','_WBID_DrainRunsInTheDetachedWorker')
NATIVE='static/ergopti_plus/windows/tests/run_native_desktop.ahk'
mainentry=blob(MAIN,NATIVE).decode('utf-8-sig')
assert re.findall(r'(?m)^#Include unit/([^\n]*)',mainentry)==['test_console_window.ahk','test_key_combinations.ahk']
summary={'current_source':CURRENT,'Main':MAIN,'Dev':DEV,'received_log_sha256':sha(raw),'archive_sha256':sha(archive),'actual_launch':{'mode':'dry','pid':launch['pid'],'status':0,'signal':None,'tap_bytes':445,'stdout_bytes':1253792,'stderr_bytes':0,'first_mismatch_offset':0,'expected_byte':35,'observed_byte':68},'warning_tail_observations':warns,'warning_tail_partial_first_line':partial_warning,'unscoped_registration_binding_sites':rows,'snapshot_source_scope':snapshot,'Main_native_desktop_owning_tests':['test_console_window.ahk','test_key_combinations.ahk'],'warning_source_principle':'top-level for bindings are global; ordinary function auto-local declarations of same names trigger LocalSameAsGlobal','full_stdout_warning_census':'NOT_RECEIVED; prefix64/tail4096 only, no exact total/complete cause attribution','native16_run_phase':'NOT_LAUNCHED; only dry launch receipt exists','ordinary_whole_Main_stdout_control':'UNRUN_NOT_BORROWED_FROM_ISOLATED_NATIVE_PASS','canonical_index_refs_modified':False,'tests_imports_native_executed':False}
(P/'source-census.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'sites':len(rows),'files':len({r['path'] for r in rows}),'exact_Main_blocks':sum(r['exact_block_present_Main63cf'] for r in rows),'exact_Dev_blocks':sum(r['exact_block_present_Dev9ad'] for r in rows),'changed_source_blocks':[{'path':r['path'],'line':r['line']} for r in rows if not r['exact_block_present_Main63cf']], 'census_sha256':sha((P/'source-census.json').read_bytes())},indent=2))
