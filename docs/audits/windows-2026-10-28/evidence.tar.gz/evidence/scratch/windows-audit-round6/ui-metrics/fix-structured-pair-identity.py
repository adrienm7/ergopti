from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-ui-metrics/static/ergopti_plus/_shared/ui/metrics_typing/data.js');s=p.read_text()
a='''	const pair_count = {};
	_apps_data.forEach((d) => {
		Object.entries(d.switches_out).forEach(([other, n]) => {
			const key = [d.name, other].sort().join(' ↔ ');
			pair_count[key] = (pair_count[key] || 0) + n;
		});
	});
	const top_pair = Object.entries(pair_count).sort((a, b) => b[1] - a[1])[0];'''
b='''	const pair_count = new Map();
	_apps_data.forEach((d) => {
		Object.entries(d.switches_out).forEach(([other, n]) => {
			const endpoints = [d.name, other].sort();
			const key = JSON.stringify(endpoints);
			const pair = pair_count.get(key);
			if (pair) pair.count += n;
			else pair_count.set(key, { endpoints, count: n });
		});
	});
	const top_pair = Array.from(pair_count.values()).sort((a, b) => b.count - a.count)[0];'''
assert s.count(a)==1;s=s.replace(a,b)
a='''top_pair ? `${escape_html(top_pair[0])} (${format_number(top_pair[1])}×)` : '—' '''.strip()
b='''top_pair ? `${escape_html(top_pair.endpoints.join(' ↔ '))} (${format_number(top_pair.count)}×)` : '—' '''.strip()
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
