﻿; tests/unit/test_ollama_direct_listener.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Direct Owned Ollama Listener Regression
; DESCRIPTION:
; Exercises real Unicode environment, listener admission and original-task borrow
; bodies through recorded OS ports. It never creates a server or changes EnvSet.
; ==============================================================================

Test("ollama-direct-environment-unicode-sorted", _ODL_Environment)
Test("ollama-direct-environment-parent-unchanged", _ODL_Parent)
Test("ollama-direct-environment-invalid", _ODL_EnvironmentRefuses)
Test("ollama-direct-listener-owned", () => _ODL_Result("owned"))
Test("ollama-direct-listener-foreign", () => _ODL_Result("foreign"))
Test("ollama-direct-listener-wildcard", () => _ODL_Result("wildcard"))
Test("ollama-direct-listener-missing", () => _ODL_Result("missing"))
Test("ollama-direct-listener-ambiguous", () => _ODL_Result("ambiguous"))
Test("ollama-direct-listener-original-terminal", () => _ODL_Result("terminal"))
Test("ollama-direct-listener-malformed", () => _ODL_Result("malformed"))
Test("ollama-direct-listener-borrow-and-cancel", _ODL_Borrow)
Test("ollama-direct-loopback-exact-url", _ODL_LocalUrl)
Test("ollama-direct-loopback-policy-sealed", _ODL_LocalSealed)
Test("ollama-direct-legacy-construction", _ODL_Legacy)

_ODL_Compare(Left, Right) {
	return StrCompare(Left, Right, false)
}
_ODL_Decode(Block) {
	local rows := [], offset := 0
	while offset < Block.Size - 2 && NumGet(Block, offset, "UShort") != 0 {
		local text := StrGet(Block.Ptr + offset, "UTF-16")
		rows.Push(text)
		offset += (StrLen(text) + 1) * 2
	}
	AssertEqual(offset, Block.Size - 2)
	AssertEqual(NumGet(Block, Block.Size - 2, "UShort"), 0)
	AssertEqual(NumGet(Block, Block.Size - 4, "UShort"), 0)
	return rows
}
_ODL_Environment() {
	local block := _SR_DaemonEnvironmentBuild(["ZED=last", "=C:=C:\fixture", "alpha=é😀"],
		"127.0.0.1:11434", "C:\fixture\modèles", _ODL_Compare)
	local rows := _ODL_Decode(block)
	AssertEqual(rows.Length, 5)
	AssertEqual(rows[1], "=C:=C:\fixture")
	AssertEqual(rows[2], "alpha=é😀")
	AssertEqual(rows[3], "OLLAMA_HOST=127.0.0.1:11434")
	AssertEqual(rows[4], "OLLAMA_MODELS=C:\fixture\modèles")
	AssertEqual(rows[5], "ZED=last")
}
_ODL_Parent() {
	local entries := ["ollama_host=foreign:9", "OLLAMA_MODELS=C:\old", "KEEP=unchanged"]
	local rows := _ODL_Decode(_SR_DaemonEnvironmentBuild(entries,
		"127.0.0.1:11434", "C:\new", _ODL_Compare))
	AssertEqual(entries[1], "ollama_host=foreign:9")
	AssertEqual(entries[2], "OLLAMA_MODELS=C:\old")
	AssertEqual(rows.Length, 3)
	AssertEqual(rows[1], "KEEP=unchanged")
	AssertEqual(rows[2], "OLLAMA_HOST=127.0.0.1:11434")
	AssertEqual(rows[3], "OLLAMA_MODELS=C:\new")
}
_ODL_EnvironmentRefuses() {
	AssertThrows(() => _SR_DaemonEnvironmentBuild(["SAME=one", "same=two"], "127.0.0.1:11434", "C:\models", _ODL_Compare))
	AssertThrows(() => _SR_DaemonEnvironmentBuild(["bad-entry"], "127.0.0.1:11434", "C:\models", _ODL_Compare))
	AssertThrows(() => _SR_DaemonEnvironmentBuild([], "127.0.0.1:65536", "C:\models", _ODL_Compare))
	AssertThrows(() => _SR_DaemonEnvironmentBuild([], "0.0.0.0:11434", "C:\models", _ODL_Compare))
}
class _ODL_Listener {
	__New(Mode) {
		this.Mode := Mode
		this.Waits := 0
		this.Tables := 0
	}
	Wait(Process, Timeout) {
		AssertEqual(Process, 201)
		AssertEqual(Timeout, 0)
		this.Waits += 1
		return this.Mode == "terminal" && this.Waits == 2 ? 0 : 258
	}
	Pid(Process) {
		AssertEqual(Process, 201)
		return 7
	}
	Job(Process, Job) {
		AssertEqual(Process, 201)
		AssertEqual(Job, 202)
		return true
	}
	Table() {
		this.Tables += 1
		local count := this.Mode == "missing" ? 0 : this.Mode == "ambiguous" ? 2 : 1
		local table := Buffer(4 + count * 24, 0)
		NumPut("UInt", this.Mode == "malformed" ? count + 1 : count, table, 0)
		loop count {
			local offset := 4 + (A_Index - 1) * 24
			NumPut("UInt", 2, table, offset)
			NumPut("UInt", this.Mode == "wildcard" ? 0 : 0x0100007f, table, offset + 4)
			NumPut("UInt", 0xaa000000 | ((11434 & 0xff) << 8) | (11434 >> 8), table, offset + 8)
			NumPut("UInt", this.Mode == "foreign" ? 8 : 7, table, offset + 20)
		}
		return Map("table", table, "bytes", table.Size, "count", count)
	}
}
_ODL_Result(Mode) {
	local world := _ODL_Listener(Mode)
	local ports := Map("wait", ObjBindMethod(world, "Wait"), "pid", ObjBindMethod(world, "Pid"),
		"job", ObjBindMethod(world, "Job"), "table", ObjBindMethod(world, "Table"))
	local receipt := _OllamaListenerOwned(11434, 202, 201, 7, ports)
	AssertEqual(receipt["state"], Mode == "owned" ? "owned" : Mode == "missing" ? "missing" : "refused")
	AssertEqual(world.Tables, 1)
	if Mode == "owned" || Mode == "missing"
		AssertEqual(receipt["error"], 0)
	else
		AssertTrue(receipt["error"] != 0)
}
_ODL_Borrow() {
	global _SR_TreeHandleOwners
	local task := ShellRunner_StageTreeOwned("C:\fixture\ollama.exe", ["serve"], (*) => 0)
	local previous := Critical("On"), state := 0
	try state := _SR_TreeAuthenticateHandleLocked(task)
	finally Critical(previous)
	try {
		state["Started"] := true
		state["ProcessHandle"] := 201
		state["JobHandle"] := 202
		state["Pid"] := 7
		state["GuardianRequired"] := true
		state["GuardianActivationClaimed"] := true
		state["GuardianEnvironment"] := Buffer(4, 0)
		local receipt := _SR_GuardianWithLiveDaemon(task, (Job, Process, Pid) => _ODL_Inspect(state, Job, Process, Pid, false))
		AssertEqual(receipt["state"], "owned")
		AssertEqual(state["NativeBorrowCount"], 0)
		AssertThrows(() => _SR_GuardianWithLiveDaemon(task,
			(Job, Process, Pid) => _ODL_Inspect(state, Job, Process, Pid, true),
			(Original) => _ODL_Finalize(state, Original)), "Cancellation during inspection cannot publish owned.")
		AssertEqual(state["NativeBorrowCount"], 0)
	} finally {
		previous := Critical("On")
		try {
			state["ProcessHandle"] := 0
			state["JobHandle"] := 0
			state["Started"] := false
			state["TerminationRequested"] := false
			_SR_TreeHandleOwners.Delete(ObjPtr(task))
		} finally Critical(previous)
	}
}
_ODL_Inspect(State, Job, Process, Pid, Cancel) {
	AssertEqual(State["NativeBorrowCount"], 1)
	AssertEqual(A_IsCritical, 0)
	AssertEqual(Job, 202)
	AssertEqual(Process, 201)
	AssertEqual(Pid, 7)
	if Cancel
		State["TerminationRequested"] := true
	return Map("state", "owned", "error", 0)
}
_ODL_Finalize(Expected, Original) {
	AssertTrue(Expected == Original)
	AssertEqual(Original["NativeBorrowCount"], 0)
}
_ODL_LocalUrl() {
	local request := CurlAsyncRequest()
	request.Open("GET", "http://localhost:11434/api/version", true)
	request.SetLoopbackOrigin("http://localhost:11434")
	request.OutputSealed := true
	local policy := _HTTP_CurlLoopbackPolicy(request)
	AssertEqual(policy["url"], "http://localhost:11434/api/version")
	AssertEqual(policy["config"], 'ipv4`nresolve = "localhost:11434:127.0.0.1"`n')
	request.Url := "http://foreign:11434/api/version"
	AssertThrows(() => _HTTP_CurlLoopbackPolicy(request))
	AssertEqual(policy["url"], "http://localhost:11434/api/version")
	AssertFalse(IsObject(request.Handle))
	AssertFalse(request.Completed)
}
_ODL_LocalSealed() {
	local request := CurlAsyncRequest()
	request.Open("GET", "http://127.0.0.1:11434/api/tags", true)
	AssertEqual(_HTTP_CurlLoopbackPolicy(request), 0)
	request.SetLoopbackOrigin("http://127.0.0.1:11434")
	request.OutputSealed := true
	AssertThrows(() => request.SetLoopbackOrigin("http://localhost:11434"))
	local policy := _HTTP_CurlLoopbackPolicy(request)
	AssertEqual(policy["config"], "ipv4`n")
	AssertFalse(request.Completed)
	AssertEqual(request.Handle, 0)
}
_ODL_Legacy() {
	local actor := OllamaGuardianTask((*) => 0, Map(), "C:\fixture\powershell.exe", ["legacy-argument"],
		(*) => 0, (*) => true, 1000, 5, 1000)
	AssertEqual(actor.DirectDaemon, 0)
	AssertEqual(actor.Executable, "C:\fixture\powershell.exe")
	AssertEqual(actor.Arguments.Length, 1)
	AssertEqual(actor.Arguments[1], "legacy-argument")
	AssertFalse(actor.Started)
	AssertFalse(IsObject(actor.Native))
	AssertFalse(IsObject(actor.Source))
	AssertFalse(IsObject(actor.Daemon))
}