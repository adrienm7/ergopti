﻿; tests/unit/test_ollama_existing_session.ahk

; ==============================================================================
; MODULE: Existing Runtime Session Recording Controls
; DESCRIPTION:
; Reuses genuine session/source validators with recorded runtime dispatch only.
; Original native worker/guardian READY and user consent receiving remain required.
; ==============================================================================

class _OES_Runtime {
	__New(World) {
		this.World := World
		this.Starts := 0
		this.Owner := 0
		this.Owned := false
	}
	HasOwner() {
		return this.Owned
	}
	Start(Receipt, Target, OnExit) {
		OllamaRuntimeSourceSpec(Receipt).ForTarget(Target)
		this.Starts += 1
		this.Owned := true
		if this.World.Reenter
			this.World.Current := false
		return true
	}
	Invalidate() {
		this.Owned := false
		return true
	}
}

class _OES_Session extends _SSR_Session {
	__New() {
		super.__New()
		this.Reenter := false
		this.Runtime := _OES_Runtime(this)
		this.Deliveries := 0
		this.Dispatched := (*) => ++this.Deliveries
	}
}

_OES_Receipt() {
	local receipt := _OMS_Receipt()
	receipt["Version"] := "0.24.0"
	receipt["Asset"] := "windows-amd64"
	receipt["CatalogueHash"] := Format("{:064}", 0)
	receipt["ArchiveHash"] := Format("{:064}", 1)
	return receipt
}

_OES_Plan(Receipt) {
	return Map("prepare", Map("AssetId", "windows-amd64", "CatalogueSha256", Receipt["CatalogueHash"]),
		"target", Map("models_dir", Receipt["ModelsDirectory"], "models_folder_name", Receipt["ModelsFolderName"],
			"origin", "http://127.0.0.1:11434", "port", 11434), "version", "0.24.0")
}

_OES_Healthy() {
	local session := _OES_Session(), receipt := _OES_Receipt()
	try {
		AssertTrue(session.StartExisting(_OES_Plan(receipt), receipt))
		AssertEqual(session.Consents, 1)
		AssertEqual(session.Runtime.Starts, 1)
		AssertEqual(session.Deliveries, 1)
		AssertEqual(session.Files.Port.Calls.Length, 0, "Reuse must not invoke prepare, publish or a download.")
		AssertFalse(session.ArchiveOwned)
		AssertTrue(session.Runtime.HasOwner())
		AssertEqual(session.Record["phase"], "runtime-dispatched")
	} finally session.Stop()
}

_OES_ConsentRefusal() {
	local session := _OES_Session(), receipt := _OES_Receipt()
	session.Consent := false
	try {
		AssertFalse(session.StartExisting(_OES_Plan(receipt), receipt))
		AssertEqual(session.Runtime.Starts, 0)
		AssertEqual(session.Deliveries, 0)
		AssertEqual(session.Files.Port.Calls.Length, 0)
	} finally session.Stop()
}

_OES_ForeignRelease() {
	for field in ["Version", "Asset", "CatalogueHash"] {
		local session := _OES_Session(), receipt := _OES_Receipt(), plan := _OES_Plan(receipt)
		receipt[field] := field == "Version" ? "0.24.1" : field == "Asset" ? "windows-arm64" : Format("{:064}", 2)
		AssertThrows(() => session.StartExisting(plan, receipt))
		AssertEqual(session.Runtime.Starts, 0)
		AssertEqual(session.Files.Port.Calls.Length, 0)
	}
}

_OES_RuntimeReentry() {
	local session := _OES_Session(), receipt := _OES_Receipt()
	session.Reenter := true
	try {
		AssertFalse(session.StartExisting(_OES_Plan(receipt), receipt))
		AssertEqual(session.Runtime.Starts, 1)
		AssertEqual(session.Deliveries, 0)
		AssertTrue(session.Runtime.HasOwner(), "A changed source cannot discard the acquired runtime.")
		AssertTrue(session.Record["cancelled"], "False admission must revoke the acquired runtime immediately.")
	} finally session.Stop()
}

_OES_IndependentReceipt() {
	local receipt := _OES_Receipt(), captured := OllamaManagedCopyExistingReceipt(receipt)
	receipt["ManifestHash"] := Format("{:064}", 9)
	AssertEqual(captured["ManifestHash"], 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb')
	receipt["Version"] := []
	AssertThrows(() => OllamaManagedCopyExistingReceipt(receipt))
}

Test("Ollama existing session no archive operation", _OES_Healthy)
Test("Ollama existing session explicit consent", _OES_ConsentRefusal)
Test("Ollama existing session captured release", _OES_ForeignRelease)
Test("Ollama existing session runtime reentry debt", _OES_RuntimeReentry)
Test("Ollama existing session independent scalar receipt", _OES_IndependentReceipt)
