local view = "/workspace/.ergopti-cloud/config-personal-root-view/static/ergopti_plus/"
package.path = view .. "linux/?.lua;" .. view .. "linux/?/init.lua;" .. view .. "_shared/lua/?.lua;" .. view .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local uv = require("luv")
local Helpers = require("tests.helpers")
for _, backend in ipairs({ "native", "pump" }) do
 local parent = assert(uv.fs_mkdtemp("/var/tmp/eg-root-XXXXXX"))
 local root, file = parent .. "/personal", parent .. "/personal/rules.toml"
 assert(uv.fs_mkdir(root, 448))
 local watcher = Helpers.load_module_with_dependency("infra.file_watchers", "luv", backend == "native" and uv or false)
 local now, reloads, latest = 0, 0, nil
 watcher.start({ personal_dir = root, now_ms = function() return now end, on_reload = function()
  reloads = reloads + 1
  local f = io.open(file, "r")
  if f then latest = f:read("*a"); assert(f:close()) end
 end })
 local function step()
  local deadline = uv.hrtime() + 60000000
  repeat uv.run("nowait"); uv.sleep(1) until uv.hrtime() >= deadline
  watcher.pump(); now = now + 600; watcher.pump(); uv.run("nowait")
 end
 assert(uv.fs_rmdir(root)); step(); step()
 local missing = reloads
 assert(uv.fs_mkdir(root, 448))
 local f = assert(io.open(file, "w")); assert(f:write('[personal]\nvalue = "new"\n')); assert(f:close()); step(); step(); step()
 local recovered = reloads
 f = assert(io.open(file, "w")); assert(f:write('[personal]\nvalue = "later"\n')); assert(f:close()); step(); step()
 print("RECEIPT", backend, "missing", missing, "recreated", recovered, "later", reloads, "latest", tostring(latest))
 watcher.stop(); uv.run("nowait")
 assert(uv.fs_unlink(file)); assert(uv.fs_rmdir(root)); assert(uv.fs_rmdir(parent))
end
