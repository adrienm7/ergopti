// _shared/ui/hotstrings_config_window/script.js

/**
 * ==============================================================================
 * MODULE: Hotstrings Config Window UI Script
 * DESCRIPTION:
 * Renders the categories / sections tree from the data pushed by Lua, and
 * sends every user mutation back through the `hotstrings_config_bridge`
 * usercontent channel. The page never keeps a divergent local copy of the
 * truth — Lua pushes a fresh state after each action, and we re-render.
 *
 * A group selector (<select>) at the top of the page filters the category
 * list to the active group (Commun / Personnel / one per extension).
 * ==============================================================================
 */

let state = { categories: [], groups: [], presets: [], global_default_delay_ms: 750 };

// The currently selected group key — persisted across Lua-pushed state updates
// so the user's position is not lost after every mutation round-trip.
let activeGroup = null;

// The categories the user folded, by identity. Every mutation makes the host
// push a fresh state and the page draws again: the fold must outlive that.
const foldedCategories = new Set();

// One category's identity across state pushes.
function categoryKey(cat) {
	return [cat.group, cat.name, cat.ext_id || '', cat.personal_path || ''].join('\u0000');
}

// Show or hide a category's sections and turn its caret accordingly.
function applyFold(toggle, sectionsBox, folded) {
	sectionsBox.hidden = folded;
	toggle.classList.toggle('open', !folded);
	toggle.setAttribute('aria-expanded', folded ? 'false' : 'true');
}

// Resolve a translation key via the loaded locale strings (set by i18n.js).
function _t(key) {
	return (window._i18n_strings && window._i18n_strings[key]) || key;
}

// Reads a typed field through the shared value check (_shared/ui/value_check.js,
// generated from the one schema the three drivers read). A refusal is shown on
// the field itself with the localized text naming the accepted range, and
// nothing is sent; an admitted value is returned in the typed unit. Every
// field of this page is an override: with `override`, a blank answers
// INHERITED, and its caller removes the override.
const INHERITED = Object.freeze({ inherited: true });
function checkedField(input, key, override) {
	const V = window.ErgoptiValueCheck;
	const entry = V.entryFor(V.SCHEMA, key);
	// A number field hands text it cannot read over as an empty value: that is
	// an unreadable answer, refused as such, never a blank that inherits.
	const typed = input.validity?.badInput
		? V.parseEntry(entry, 'NaN')
		: V.parseEntry(entry, input.value, override ? V.INHERIT : undefined);
	if (!typed.ok) {
		input.setCustomValidity(V.renderMessage(V.messageParts(entry, typed), _t));
		input.reportValidity();
		return null;
	}
	input.setCustomValidity('');
	if (typed.inherit) return INHERITED;
	// The host takes the typed unit (ms for a delay): the text, already admitted.
	return Number(input.value.trim().replace(',', '.'));
}

// Apply data-i18n-key / data-i18n-title-key inside a freshly cloned template
// fragment (i18n.js cannot reach inside <template> nodes before cloning).
function applyTemplateI18n(node) {
	node.querySelectorAll('[data-i18n-key]').forEach(function (el) {
		el.textContent = _t(el.getAttribute('data-i18n-key'));
	});
	node.querySelectorAll('[data-i18n-title-key]').forEach(function (el) {
		el.title = _t(el.getAttribute('data-i18n-title-key'));
	});
}

// Numbers the controls of the rendered fields; a template cannot hold ids.
let fieldCount = 0;

/**
 * Ties each field's label to its control, and names the control after the
 * category or section it sets: every card repeats the same four labels, so a
 * screen reader hears which one it is in (WCAG 1.3.1, 2.4.6, 4.1.2).
 * @param {ParentNode} node - A rendered category head or section.
 * @param {Element} heading - The category's or section's heading.
 */
function labelFields(node, heading) {
	heading.id = 'hs-heading-' + ++fieldCount;
	node.querySelectorAll('.field').forEach(function (field) {
		const label = field.querySelector('label');
		const control = field.querySelector('.ctrl input, .ctrl select');
		if (!label || !control) return;
		control.id = 'hs-field-' + ++fieldCount;
		label.htmlFor = control.id;
		label.id = control.id + '-label';
		control.setAttribute('aria-labelledby', label.id + ' ' + heading.id);
	});
}

// ============================================================
// 1/ Bridge primitives
// ============================================================

const send = makeHostBridge('hotstrings_config_bridge');

function setData(next) {
	if (!next || typeof next !== 'object') return;
	state = next;

	// Preserve the active group across state pushes; fall back to the first group.
	if (state.groups && state.groups.length > 0) {
		const keys = state.groups.map(function (g) {
			return g.key;
		});
		if (!activeGroup || keys.indexOf(activeGroup) === -1) {
			activeGroup = keys[0];
		}
	}

	renderGroupSelector();
	render();
}

// The cards are built from the host's data, and on Windows the locale strings
// are fetched: data that lands first drew every field label as its locale key
// (hs_config.label_delay). Draw again once i18n.js has applied the strings.
document.addEventListener('i18n:applied', function () {
	renderGroupSelector();
	render();
});

function closeWindow() {
	send({ action: 'close' });
}

function resetAll() {
	send({ action: 'reset_all' });
}

function setAllGrey() {
	send({ action: 'set_all_grey' });
}

// ============================================================
// 2/ Group selector
// ============================================================

function renderGroupSelector() {
	const sel = document.getElementById('group-select');
	if (!sel) return;
	sel.innerHTML = '';
	(state.groups || []).forEach(function (g) {
		const o = document.createElement('option');
		o.value = g.key;
		o.textContent = g.label;
		if (g.key === activeGroup) o.selected = true;
		sel.appendChild(o);
	});
}

function onGroupChange() {
	const sel = document.getElementById('group-select');
	if (sel) activeGroup = sel.value;
	render();
}

// ============================================================
// 3/ Rendering
// ============================================================

function render() {
	const main = document.getElementById('content');
	main.innerHTML = '';

	const tplCat = document.getElementById('tpl-category').content;
	const tplSec = document.getElementById('tpl-section').content;

	// Filter categories to the active group only
	const visible = (state.categories || []).filter(function (cat) {
		return cat.group === activeGroup;
	});

	for (const cat of visible) {
		const node = document.importNode(tplCat, true);
		applyTemplateI18n(node);
		const card = node.querySelector('.cat');

		// The heading's one button, caret and title, folds the category's
		// sections: a disclosure the keyboard reaches (WCAG 2.1.1, 4.1.2).
		const toggle = card.querySelector('[data-role=toggle]');
		toggle.textContent = cat.title;
		labelFields(card.querySelector('.cat-head'), card.querySelector('.cat-title'));
		const sectionsBox = card.querySelector('.sections');
		const key = categoryKey(cat);
		const fold = () => {
			if (foldedCategories.has(key)) foldedCategories.delete(key);
			else foldedCategories.add(key);
			applyFold(toggle, sectionsBox, foldedCategories.has(key));
		};
		applyFold(toggle, sectionsBox, foldedCategories.has(key));
		toggle.addEventListener('click', fold);

		// File-level (category) controls
		bindDelay(card.querySelector('.field-delay'), cat, null);
		bindColor(card.querySelector('.field-color'), cat, null);
		bindPriority(card.querySelector('.field-priority'), cat, null);
		bindTooltip(card.querySelector('.field-tooltip'), cat, null);
		applyMetadataAvailability(card, cat);

		// Sections
		for (const sec of cat.sections) {
			const secNode = document.importNode(tplSec, true);
			applyTemplateI18n(secNode);
			const secTitle = secNode.querySelector('.sec-title');
			secTitle.textContent = sec.title || sec.name;
			labelFields(secNode, secTitle);
			bindDelay(secNode.querySelector('.field-delay'), cat, sec);
			bindColor(secNode.querySelector('.field-color'), cat, sec);
			bindPriority(secNode.querySelector('.field-priority'), cat, sec);
			bindTooltip(secNode.querySelector('.field-tooltip'), cat, sec);
			applyMetadataAvailability(secNode, sec);
			sectionsBox.appendChild(secNode);
		}
		if (cat.readonly === true) {
			for (const control of card.querySelectorAll('input, select, button')) control.disabled = true;
		}

		main.appendChild(node);
	}
}

// ============================================================
// 4/ Field bindings
// ============================================================

function applyMetadataAvailability(node, target) {
	const unavailable = target.readonly_metadata || {};
	for (const [key, selector] of [
		['delay', 'delay'],
		['color', 'color'],
		['priority', 'priority'],
		['show_tooltip', 'tooltip']
	]) {
		if (unavailable[key] !== true) continue;
		const field = node.querySelector('.field-' + selector);
		if (!field) continue;
		field.title = target.readonly_metadata_reason || '';
		for (const control of field.querySelectorAll('input, select, button')) control.disabled = true;
	}
}

function bindDelay(field, cat, sec) {
	const ms = sec ? sec.delay_ms : cat.delay_ms;
	const overridden = sec ? sec.delay_overridden : cat.delay_overridden;
	// When the TOML default is 0, fall back to the global default as the hint
	// so the user understands what value will actually be applied.
	const defaultMs =
		((sec ? sec.delay_default_ms : cat.delay_default_ms) || state.global_default_delay_ms) ?? 750;
	const input = field.querySelector('input');
	const reset = field.querySelector('.reset');

	// Zero is the effective unlimited delay, not a missing value.
	input.value = ms ?? defaultMs;
	input.placeholder = defaultMs;
	field.classList.toggle('overridden', !!overridden);

	function clearDelay() {
		send({
			action: 'clear_delay',
			category: cat.name,
			group: cat.group,
			section: sec ? sec.name : '',
			personal_path: cat.personal_path || '',
			ext_id: cat.ext_id || ''
		});
	}

	input.addEventListener('change', () => {
		const v = checkedField(
			input,
			sec
				? window.ErgoptiValueCheck.KEY.HOTSTRINGS_CONFIG_ANY_ANY_DELAY
				: window.ErgoptiValueCheck.KEY.HOTSTRINGS_CONFIG_ANY_DELAY,
			true
		);
		// A blank delay removes the override, so the inherited delay applies
		// again (maintainer decision of 2026-11-22, PCK-13 for overrides).
		if (v === INHERITED) {
			clearDelay();
			return;
		}
		if (v !== null) {
			send({
				action: 'set_delay',
				category: cat.name,
				group: cat.group,
				section: sec ? sec.name : '',
				personal_path: cat.personal_path || '',
				ext_id: cat.ext_id || '',
				ms: v
			});
		}
	});

	reset.addEventListener('click', clearDelay);
}

// Collision priority (0-100, higher wins a same-trigger collision). The input
// shows the effective value and the placeholder shows the source/TOML default,
// so an empty field means "inherit the default". Mirrors bindDelay.
function bindPriority(field, cat, sec) {
	if (!field) return;
	const value = sec ? sec.priority : cat.priority;
	const overridden = sec ? sec.priority_overridden : cat.priority_overridden;
	const def = sec ? sec.priority_default : cat.priority_default;
	const input = field.querySelector('input');
	const reset = field.querySelector('.reset');

	input.value = typeof value === 'number' ? value : '';
	if (typeof def === 'number') input.placeholder = def;
	field.classList.toggle('overridden', !!overridden);

	function clearPriority() {
		send({
			action: 'clear_priority',
			category: cat.name,
			group: cat.group,
			section: sec ? sec.name : '',
			personal_path: cat.personal_path || '',
			ext_id: cat.ext_id || ''
		});
	}

	input.addEventListener('change', () => {
		const v = checkedField(
			input,
			sec
				? window.ErgoptiValueCheck.KEY.HOTSTRINGS_CONFIG_ANY_ANY_PRIORITY
				: window.ErgoptiValueCheck.KEY.HOTSTRINGS_CONFIG_ANY_PRIORITY,
			true
		);
		if (v === INHERITED) {
			clearPriority();
			return;
		}
		if (v !== null) {
			send({
				action: 'set_priority',
				category: cat.name,
				group: cat.group,
				section: sec ? sec.name : '',
				personal_path: cat.personal_path || '',
				ext_id: cat.ext_id || '',
				priority: v
			});
		}
	});

	reset.addEventListener('click', clearPriority);
}

function bindColor(field, cat, sec) {
	const color = sec ? sec.color : cat.color;
	const overridden = sec ? sec.color_overridden : cat.color_overridden;
	const select = field.querySelector('select');
	const swatch = field.querySelector('.swatch');
	const reset = field.querySelector('.reset');

	// Build the dropdown: presets + a current-value entry when the active
	// hex is not part of the preset list, so the user always sees the
	// current selection clearly.
	select.innerHTML = '';
	const opts = state.presets.slice();
	const lower = (color || '').toLowerCase();
	const known = opts.find((p) => (p.hex || '').toLowerCase() === lower);
	if (color && !known) {
		opts.unshift({ label: color, hex: color });
	}
	for (const p of opts) {
		const o = document.createElement('option');
		o.value = p.hex;
		o.textContent = p.label;
		if ((p.hex || '').toLowerCase() === lower) o.selected = true;
		select.appendChild(o);
	}
	swatch.style.background = color || 'transparent';
	field.classList.toggle('overridden', !!overridden);

	select.addEventListener('change', () => {
		const hex = select.value;
		if (hex) {
			send({
				action: 'set_color',
				category: cat.name,
				group: cat.group,
				section: sec ? sec.name : '',
				personal_path: cat.personal_path || '',
				ext_id: cat.ext_id || '',
				hex
			});
		}
	});

	reset.addEventListener('click', () => {
		send({
			action: 'clear_color',
			category: cat.name,
			group: cat.group,
			section: sec ? sec.name : '',
			personal_path: cat.personal_path || '',
			ext_id: cat.ext_id || ''
		});
	});
}

function bindTooltip(field, cat, sec) {
	if (!field) return;
	const showTooltip = sec ? sec.show_tooltip : cat.show_tooltip;
	const overridden = sec ? sec.show_tooltip_overridden : cat.show_tooltip_overridden;
	const chk = field.querySelector('.chk-tooltip');
	const reset = field.querySelector('.reset');

	chk.checked = showTooltip !== false;
	field.classList.toggle('overridden', !!overridden);
	reset.disabled = !overridden;

	chk.addEventListener('change', () => {
		send({
			action: 'set_tooltip',
			category: cat.name,
			group: cat.group,
			section: sec ? sec.name : '',
			personal_path: cat.personal_path || '',
			ext_id: cat.ext_id || '',
			show_tooltip: chk.checked
		});
	});

	reset.addEventListener('click', () => {
		send({
			action: 'clear_tooltip',
			category: cat.name,
			group: cat.group,
			section: sec ? sec.name : '',
			personal_path: cat.personal_path || '',
			ext_id: cat.ext_id || ''
		});
	});
}

// ============================================================
// 6/ The contract with the host
// ============================================================

// The host pushes data by calling `window.setData(...)`, guarded with
// `if(window.setData)`. Publishing it explicitly rather than relying on a
// top-level function declaration being globalised: the guard means a page that
// does not expose it turns every push into a silent no-op, and an implicit
// global is a fragile thing to hang that on across two files in two languages.
//
// The Linux hardware harness found this window unreachable that way while the
// editor — which has always assigned `window.initData` explicitly — worked.
window.setData = setData;

// Ask for the state once setData is published. Windows and macOS also push it
// when the navigation completes and drop this string message; the Linux bridge
// pushes only on it, so without it the window opened empty (WVH-001).
if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', function () {
		send('ready');
	});
} else {
	send('ready');
}
