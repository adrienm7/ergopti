from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/group6-brew-timeout-diagnostic-20261010-r1')
paths=['tools/diagnostics/macos_brew_archive_acceptance.py','tools/diagnostics/macos_brew_archive_acceptance_test.py','tools/test/test-homebrew-cask.cjs']
pre=[]
for name in paths:
 data=(Path('/workspace/ergopti')/name).read_bytes()
 for side in ('preimage','candidate'):
  p=root/side/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 pre.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(root/'PREIMAGES.json').write_text(json.dumps({'head':subprocess.run(['git','-C','/workspace/ergopti','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),'files':pre},indent=2)+'\n')
p=root/'candidate'/paths[0];s=p.read_text();s=s.replace('import json\n','import json\nimport math\n',1)
validator='''def _validate_command_timeout(packet):
    """Closed observations only; these timings cannot authorize or extend a wait."""
    keys = {
        "schema", "command", "stage", "budget_seconds", "request_deadline_ns",
        "started_ns", "expired_ns", "spent_ns",
    }
    require(type(packet) is dict and set(packet) == keys, "Unadmitted command timeout fields")
    require(type(packet["schema"]) is int and packet["schema"] == 1,
            "Unadmitted command timeout schema")
    require(type(packet["command"]) is str and packet["command"] in
            ("permission-request", "consent-observer", "other"),
            "Unadmitted command timeout identity")
    require(type(packet["stage"]) is str and packet["stage"] in
            ("readiness", "ui-observer", "exit-wait"), "Unadmitted command timeout stage")
    budget = packet["budget_seconds"]
    require(type(budget) in (int, float) and 0 < budget <= 180 and math.isfinite(budget),
            "Unadmitted command timeout budget")
    limit = 2**64 - 1
    for key in ("started_ns", "expired_ns", "spent_ns"):
        require(type(packet[key]) is int and 0 <= packet[key] <= limit,
                "Unadmitted command timeout clock")
    deadline = packet["request_deadline_ns"]
    require(deadline is None or (type(deadline) is int and 0 <= deadline <= limit),
            "Unadmitted command timeout request deadline")
    require(packet["command"] != "permission-request" or deadline is not None,
            "Command timeout lost its original request deadline")
    require(packet["expired_ns"] >= packet["started_ns"] and
            packet["spent_ns"] == packet["expired_ns"] - packet["started_ns"],
            "Unadmitted command timeout duration")
    return dict(packet)


'''
s=s.replace('class PhaseEvidence:\n',validator+'class PhaseEvidence:\n',1)
s=s.replace('        self.previous = None\n','        self.previous = None\n        self.first_timeout = None\n',1)
retain='''    def retain_timeout(self, fact, *, groups=()):
        """Retain the first typed timeout through all later bounded checkpoints."""
        try:
            admitted = _validate_command_timeout(fact)
            if getattr(self, "first_timeout", None) is None:
                self.first_timeout = admitted
            else:
                _validate_command_timeout(self.first_timeout)
            return self.record("command.timeout", status="refused", groups=groups)
        except OwnedProcessInterrupted:
            raise
        except Exception:
            self.failed = True
            return False

'''
pos=s.index('    def record(\n',s.index('class PhaseEvidence:'));s=s[:pos]+retain+s[pos:]
s=s.replace('            semantic = json.dumps(packet, sort_keys=True)\n','''            first_timeout = getattr(self, "first_timeout", None)
            if first_timeout is not None:
                packet["first_timeout"] = _validate_command_timeout(first_timeout)
            semantic = json.dumps(packet, sort_keys=True)
''',1)
s=s.replace('        self.capture_identities = {}\n','        self.capture_identities = {}\n        self._timeout_request_deadline_ns = None\n',1)
needle='''        before_active = tuple(self.active)
'''
insert='''        # Diagnostic samples never schedule native work. The opaque group-wait
        # deadline is deliberately not reconstructed from a new timer.
        timeout_started_ns = None
        timeout_stage = "exit-wait"
        timeout_deadline_ns = (
            request.deadline_ns if request is not None
            else getattr(self, "_timeout_request_deadline_ns", None)
        )
        timeout_command = (
            "permission-request"
            if request is not None and request[-1] == "permission-request"
            else "consent-observer"
            if Path(arguments[0]) == self.root / "native-appleevent-consent"
            else "other"
        )
        if self.evidence is not None and getattr(self.evidence, "descriptor", None) is not None:
            try:
                timeout_started_ns = time.monotonic_ns()
            except BaseException:
                pass  # Optional telemetry must not alter acquisition or its primary.
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle,1)
needle='''                if after_start is not None:
                    if readiness is None or readiness.wait(process):
                        after_start(process, request.deadline_ns / 1_000_000_000)
                remaining = request.remaining()
'''
insert='''                if after_start is not None:
                    timeout_stage = "readiness" if readiness is not None else "ui-observer"
                    if readiness is None or readiness.wait(process):
                        timeout_stage = "ui-observer"
                        previous_timeout_deadline = getattr(self, "_timeout_request_deadline_ns", None)
                        self._timeout_request_deadline_ns = request.deadline_ns
                        try:
                            after_start(process, request.deadline_ns / 1_000_000_000)
                        finally:
                            self._timeout_request_deadline_ns = previous_timeout_deadline
                timeout_stage = "exit-wait"
                remaining = request.remaining()
'''
assert s.count(needle)==1;s=s.replace(needle,insert,1)
needle='''                deadline = time.monotonic() + timeout
                after_start(process, deadline)
                self.groups[process].wait_for_exit(max(0, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            failure = AdmissionError("Owned native command exceeded deadline")
'''
insert='''                deadline = time.monotonic() + timeout
                timeout_stage = "ui-observer"
                after_start(process, deadline)
                timeout_stage = "exit-wait"
                self.groups[process].wait_for_exit(max(0, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            failure = AdmissionError("Owned native command exceeded deadline")
            if timeout_started_ns is not None:
                try:
                    expired_ns = time.monotonic_ns()
                    self.evidence.retain_timeout(
                        {
                            "schema": 1,
                            "command": timeout_command,
                            "stage": timeout_stage,
                            "budget_seconds": timeout,
                            "request_deadline_ns": timeout_deadline_ns,
                            "started_ns": timeout_started_ns,
                            "expired_ns": expired_ns,
                            "spent_ns": expired_ns - timeout_started_ns,
                        },
                        groups=[self.groups[child] for child in self.active],
                    )
                except BaseException:
                    pass  # Preserve this exact primary; native retirement still runs below.
'''
assert s.count(needle)==1;s=s.replace(needle,insert,1)
p.write_text(s)
print(json.dumps({'prepared_helper_only':True,'preimage_head':json.loads((root/'PREIMAGES.json').read_text())['head'],'product_execution':'UNRUN'}))
