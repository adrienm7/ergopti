from pathlib import Path
import datetime,hashlib,json,re,subprocess
from zoneinfo import ZoneInfo
s=Path('/workspace/scratch/oct28-combined34-common');r=Path('/workspace/ergopti-macos-final-common')
def load(name):return json.loads((s/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
receipt=load('receipt.json');go=load('go.json');exit_record=load('tool-exit.json');observer=load('residual-observer.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==go['commit']
assert receipt['physical_initial']['index_tree']==receipt['physical_final']['index_tree']==go['tree']
for state in [receipt['physical_initial'],receipt['physical_final']]:
 assert not state['mismatches'] and not state['unstaged'] and not state['untracked']
assert receipt['physical_initial']['digest']==receipt['physical_final']['digest']
raw=(s/'js.log').read_bytes();text=raw.decode(errors='replace')
rows=re.findall(r'^  (PASS|FAIL) (\d+)/(\d+) — (.*)$',text,re.M)
assert len(rows)==529 and {int(x[1])for x in rows}==set(range(1,530))
assert all(x[2]=='529'for x in rows)
failed=[x for x in rows if x[0]=='FAIL']
assert {int(x[1])for x in failed}=={250,474},failed
assert 'locale catalogue completeness' in failed[0][3]
assert 'raw config-key and command-id literals' in failed[1][3]
gates=receipt['gates'];assert len(gates)==19
assert [x['actual_exit']for x in gates if x['name']=='js']==[1]
assert all(x['actual_exit']==0 for x in gates if x['name']!='js')
assert exit_record['actual_child_wait_exit']==1
assert observer['qualified'] and not observer['live_refs'] and not observer['unreadable_live_same_uid']
not_run=re.search(r'(\d+) case\(s\) in (\d+) check\(s\) were NOT EXECUTED on this host:',text)
assert not_run and not_run.groups()==('1','1')
paths=['static/ergopti_plus/_shared/data/locales/'+code+'.json'for code in ['en','da','it','nl','no','sv']]+['static/ergopti_plus/windows/ui/menu/menu_gestures.ahk']
pins=[]
for path in paths:
 item={'path':path,'refs':{}}
 for ref in [go['commit'],go['base_dev'],'80e8092f2051ad4927dcc880f9585a0e69f6613a']:
  data=subprocess.check_output(['git','show',ref+':'+path],cwd=r)
  item['refs'][ref]={'sha256':hashlib.sha256(data).hexdigest(),'git_blob':subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=r,text=True).strip()}
 assert len({x['sha256']for x in item['refs'].values()})==1
 pins.append(item)
(s/'protected-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
qualification={'state':'COMPLETE_WITH_TWO_PROTECTED_UPSTREAM_FAILURES','overall_green':False,'qualified_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_commit':go['commit'],'source_tree':go['tree'],'canonical_js_checks':{'planned':529,'completed':529,'unique_indices_complete':True,'passed_checks':527,'failed_checks':2,'failed_check_details':failed,'actual_js_exit':1,'host_specific_cases_not_executed':{'count':1,'checks':1,'description':'Pre-existing AHK host-specific cases remain explicitly not executed, never passed.'}},'actual_child_wait_exit':1,'all_other_gates_actual_zero':True,'gates':[{'name':x['name'],'actual_exit':x['actual_exit'],'command':x['command']}for x in gates],'source_physical_invariant':receipt['physical_final'],'residual_observer':observer,'native_darwin_executed':False,'protected_failure_source_pins':str(s/'protected-source-pins.json'),'receipt_sha256':sha(s/'receipt.json'),'tool_exit_sha256':sha(s/'tool-exit.json'),'js_log_sha256':hashlib.sha256(raw).hexdigest(),'scope':'One complete canonical Common run on final merge10/field-admission tree. Only exact excluded upstream checks remain red; no tests disabled, retried or weakened. No earlier source receipt is rebound.'}
(s/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'state':qualification['state'],'source':go['commit'],'counts':[527,2],'other_gates':18,'source_invariant':True,'observer_qualified':True,'qualification_sha256':sha(s/'qualification.json')}))
