from pathlib import Path
import subprocess,json,datetime,os
s=Path('/workspace/scratch/oct28-recommended-final-common')
t=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).isoformat()
assert json.loads((s/'go.json').read_text())['go_from_parent'] is True
assert not (s/'tool-exit.json').exists(), 'Refuse overwriting a completed producer receipt'
with(s/'producer.log').open('xb')as f:
 p=subprocess.Popen(['python3',str(s/'run.py')],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 (s/'producer.json').write_text(json.dumps({'wrapper_pid':os.getpid(),'producer_pid':p.pid,'started_paris':t(),'base_head_commit':json.loads((s/'go.json').read_text())['commit'],'qualified_index_tree':json.loads((s/'go.json').read_text())['tree'],'source_state':'staged_precommit'})+'\n')
 rc=p.wait()
(s/'tool-exit.json').write_text(json.dumps({'wrapper_pid':os.getpid(),'producer_pid':p.pid,'actual_child_wait_exit':rc,'finished_paris':t(),'scope':'Actual subprocess wait status recorded by detached owned wrapper; no tool-session exit inferred.'},indent=2)+'\n')
raise SystemExit(rc)
