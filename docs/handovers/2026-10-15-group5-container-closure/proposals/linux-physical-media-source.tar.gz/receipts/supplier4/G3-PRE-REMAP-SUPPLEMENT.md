Group 5 private-only supplier supplement coordinated by Root: source review found
that post-remapper onPhysical cannot account for original media events consumed
or transformed by configured remaps. That draft is not claimed complete.

Before private code changes, the exact additional Hook span proposed is:
- optional start option `onPhysicalSource(capability, detached_original_view)`;
- invoke it in `_dispatch_event` after original EV_KEY/SYN-loss admission and
  before the tap-hold/remapper branch can consume/transform the event;
- issue only an actual original Reader capability through Hook's private
  physical/source/session/owner/observer join, preserving all existing callbacks;
- bind this callback to the current original Hook start/options lifecycle;
- record semantic media only from this intake, never again from post-remapper
  onPhysical, preventing duplicate credit even for multiple synthetic outputs.

The existing onPhysical first four facts/callback scheduling remain unchanged.
No second device reader/open/grab/output channel. Consumed/remapped/non-media and
synthetic-output duplicate cases are frozen before repair. Canonical Hook/Reader
remain G3-owned and untouched until the owner checkpoint; all work is in regular
private copies. Native evdev/uinput hardware remains unavailable in this container.
