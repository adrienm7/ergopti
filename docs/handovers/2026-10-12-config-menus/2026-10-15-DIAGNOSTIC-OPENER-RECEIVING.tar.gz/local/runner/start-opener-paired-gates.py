from pathlib import Path
import subprocess,json,time,datetime
out=Path('/workspace/.ergopti-cloud');owned=out/'resume-healthcheck-opener/owned-paths.json';tree='5f3a0f0c5926593b8fe10802ca779d5e55222e51';children={};handles={};record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_tree':tree,'views_physical_separate':True,'state':'RUNNING','children':{}}
for lane in ['js','native']:
 log=(out/('opener-selected-'+lane+'-controller.log')).open('w');handles[lane]=log
 cmd=['python',str(out/'run-opener-selected-gates.py'),'--lane',lane,'--tree',tree,'--owned',str(owned)];child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);children[lane]=child;record['children'][lane]={'pid':child.pid,'command':cmd,'exit_code':None}
(out/'opener-paired-gates-status.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
while any(p.poll() is None for p in children.values()):
 changed=False
 for lane,child in children.items():
  code=child.poll()
  if code is not None and record['children'][lane]['exit_code'] is None:record['children'][lane]['exit_code']=code;changed=True;print(json.dumps({'lane':lane,'exit_code':code}),flush=True)
 if changed:(out/'opener-paired-gates-status.json').write_text(json.dumps(record,indent=2)+'\n')
 time.sleep(5)
for lane,child in children.items():record['children'][lane]['exit_code']=child.returncode;handles[lane].close()
record['state']='PASSED' if all(p.returncode==0 for p in children.values()) else 'FAILED';record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'opener-paired-gates-status.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(0 if record['state']=='PASSED' else 1)
