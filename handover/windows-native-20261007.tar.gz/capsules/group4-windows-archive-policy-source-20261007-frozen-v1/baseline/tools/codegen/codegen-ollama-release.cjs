// tools/codegen/codegen-ollama-release.cjs

/** Project the shared Ollama release pins into native macOS and Windows consumers. */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { REPO_ROOT, sharedRel } = require('../lib/paths.cjs');

const SOURCE = sharedRel('modules', 'llm', 'ollama_release.json');
const MACOS_OUTPUT = 'static/ergopti_plus/macos/modules/llm/ollama-release.sh';
const WINDOWS_OUTPUT = 'static/ergopti_plus/windows/_generated/ollama_release.ahk';
const ASSET_FILENAMES = Object.freeze({
	'macos-universal': 'ollama-darwin.tgz',
	'linux-amd64': 'ollama-linux-amd64.tar.zst',
	'linux-arm64': 'ollama-linux-arm64.tar.zst',
	'windows-amd64': 'ollama-windows-amd64.zip',
	'windows-arm64': 'ollama-windows-arm64.zip'
});

/** Reject incomplete records and fields that no pinned release consumer owns. */
function exactKeys(value, keys, label) {
	if (
		!value ||
		typeof value !== 'object' ||
		Array.isArray(value) ||
		![Object.prototype, null].includes(Object.getPrototypeOf(value))
	)
		throw new TypeError(`Ollama release ${label} requires exactly its closed fields.`);
	const actual = Object.keys(value).sort();
	const expected = [...keys].sort();
	if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index]))
		throw new TypeError(`Ollama release ${label} requires exactly its closed fields.`);
}

/** Validate every platform pin before any projection or native consumer can use one. */
function validate(data) {
	exactKeys(data, ['schema_version', 'version', 'assets'], 'root');
	if (data.schema_version !== 1) throw new TypeError('Ollama release schema_version must be 1.');
	if (
		typeof data.version !== 'string' ||
		/[\r\n]/.test(data.version) ||
		!/^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$/.test(data.version)
	)
		throw new TypeError('Ollama release version must be canonical stable semver.');
	exactKeys(data.assets, Object.keys(ASSET_FILENAMES), 'assets');
	for (const [id, filename] of Object.entries(ASSET_FILENAMES)) {
		const asset = data.assets[id];
		exactKeys(asset, ['filename', 'sha256', 'bytes'], `asset ${id}`);
		if (asset.filename !== filename)
			throw new TypeError(`Ollama release asset ${id} requires its official basename.`);
		if (
			typeof asset.sha256 !== 'string' ||
			asset.sha256.length !== 64 ||
			!/^[0-9a-f]{64}$/.test(asset.sha256)
		)
			throw new TypeError(`Ollama release asset ${id} requires lowercase SHA-256.`);
		if (!Number.isSafeInteger(asset.bytes) || asset.bytes <= 0)
			throw new TypeError(`Ollama release asset ${id} requires a positive safe byte count.`);
	}
	return data;
}

/** Derive an official URL from the same validated version and asset identity. */
function assetUrl(data, id) {
	validate(data);
	if (typeof id !== 'string' || !Object.hasOwn(ASSET_FILENAMES, id))
		throw new TypeError('Ollama release asset identity is unavailable.');
	return `https://github.com/ollama/ollama/releases/download/v${data.version}/${data.assets[id].filename}`;
}

/** Render the Windows asset provider only from the validated shared pins. */
function windowsProjection(data) {
	validate(data);
	const amd64 = data.assets['windows-amd64'];
	const arm64 = data.assets['windows-arm64'];
	return '\uFEFF' + "; _generated/ollama_release.ahk\n; AUTO-GENERATED from _shared/modules/llm/ollama_release.json.\n; DO NOT EDIT BY HAND — run `node tools/codegen/codegen-ollama-release.cjs`.\n#Requires AutoHotkey v2.0\n\n; ==============================================================================\n; MODULE: Pinned Ollama Windows Release\n; DESCRIPTION:\n; Returns a fresh closed asset record from the canonical cross-driver release.\n; No mutable global initializer, download, installation or process is acquired.\n; ==============================================================================\n\n/** Returns the pinned official archive for one exact Windows asset identity. */\nOllamaReleaseWindowsAsset(AssetId) {\n\tif !(AssetId is String) || !(AssetId == \"windows-amd64\" || AssetId == \"windows-arm64\")\n\t\tthrow ValueError(\"Pinned Windows Ollama asset identity is unavailable.\")\n\tswitch AssetId {\n\t\tcase \"windows-amd64\":\n\t\t\treturn Map(\"asset_id\", \"windows-amd64\", \"version\", \"@VERSION@\",\n\t\t\t\t\"filename\", \"@AMD_FILENAME@\", \"sha256\", \"@AMD_SHA@\",\n\t\t\t\t\"bytes\", @AMD_BYTES@, \"url\", \"@AMD_URL@\")\n\t\tcase \"windows-arm64\":\n\t\t\treturn Map(\"asset_id\", \"windows-arm64\", \"version\", \"@VERSION@\",\n\t\t\t\t\"filename\", \"@ARM_FILENAME@\", \"sha256\", \"@ARM_SHA@\",\n\t\t\t\t\"bytes\", @ARM_BYTES@, \"url\", \"@ARM_URL@\")\n\t}\n}\n"
		.replaceAll('@VERSION@', data.version)
		.replaceAll('@AMD_FILENAME@', amd64.filename)
		.replaceAll('@AMD_SHA@', amd64.sha256)
		.replaceAll('@AMD_BYTES@', String(amd64.bytes))
		.replaceAll('@AMD_URL@', assetUrl(data, 'windows-amd64'))
		.replaceAll('@ARM_FILENAME@', arm64.filename)
		.replaceAll('@ARM_SHA@', arm64.sha256)
		.replaceAll('@ARM_BYTES@', String(arm64.bytes))
		.replaceAll('@ARM_URL@', assetUrl(data, 'windows-arm64'));
}

/** Render deterministic LF output without reading or mutating the working tree. */
function render(data) {
	validate(data);
	const macos = data.assets['macos-universal'];
	return {
		[WINDOWS_OUTPUT]: windowsProjection(data),
		[MACOS_OUTPUT]: `#!/bin/bash
# modules/llm/ollama-release.sh

# ============================================================================
# MODULE: Pinned Ollama Release
# DESCRIPTION:
# Generated by tools/codegen/codegen-ollama-release.cjs; do not edit.
# Source: _shared/modules/llm/ollama_release.json.
# Digest and size come from the official GitHub release asset for this exact
# tag; the size only drives the download progress bar, the digest gates use.
# ============================================================================

OLLAMA_RELEASE_VERSION="${data.version}"
OLLAMA_DARWIN_TGZ_SHA256="${macos.sha256}"
OLLAMA_DARWIN_TGZ_BYTES="${macos.bytes}"
`
	};
}

/** Check drift without writing, or regenerate only validated projections in Root. */
function generate(root = REPO_ROOT, { check = false } = {}) {
	if (typeof root !== 'string' || !path.isAbsolute(root))
		throw new TypeError('Ollama release projection root must be absolute.');
	if (typeof check !== 'boolean') throw new TypeError('Ollama release check mode must be boolean.');
	const data = JSON.parse(fs.readFileSync(path.join(root, SOURCE), 'utf8'));
	const outputs = render(data);
	if (check) {
		for (const [file, output] of Object.entries(outputs)) {
			const destination = path.join(root, file);
			if (!fs.existsSync(destination) || !fs.readFileSync(destination).equals(Buffer.from(output)))
				throw new Error(
					`Ollama release projection drift: ${file}. Run node tools/codegen/codegen-ollama-release.cjs.`
				);
		}
		return Object.keys(outputs);
	}
	for (const [file, output] of Object.entries(outputs)) {
		const destination = path.join(root, file);
		fs.mkdirSync(path.dirname(destination), { recursive: true });
		fs.writeFileSync(destination, output, 'utf8');
	}
	return Object.keys(outputs);
}

if (require.main === module) {
	try {
		const args = process.argv.slice(2);
		if (args.some((arg) => arg !== '--check') || args.length > 1)
			throw new TypeError('Usage: node tools/codegen/codegen-ollama-release.cjs [--check]');
		const check = args.includes('--check');
		generate(REPO_ROOT, { check });
		console.log(
			check ? 'Ollama release projections are current.' : 'Ollama release projections regenerated.'
		);
	} catch (error) {
		console.error(error.message);
		process.exitCode = 1;
	}
}

module.exports = {
	SOURCE,
	MACOS_OUTPUT,
	WINDOWS_OUTPUT,
	ASSET_FILENAMES,
	validate,
	assetUrl,
	render,
	generate
};
