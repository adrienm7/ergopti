# Original23 source preflight versus the existing PAC publisher

This is a finite source diagnosis. No source proposal, builder, parser of candidate code, test, native process, workflow, Git reference or index change was executed. The immutable seven-source capsule `7c24dc7af458ec9a1b94ded3f3e0dbaf2b9d24b0b8cf6814aa975ec9649648dc` is unchanged. Committed sources are read from Git object `85b7f0f55e58e8949033d28b92ed1d46da030160`, not temporarily mutable generator outputs. `preimages.json` binds their exact Git blobs/SHA256 and the frozen proposal files. This note does not authenticate fresh official artifact bytes.

## Concrete producer and output boundary

The original Windows job runs `./tools/build/build_windows_network_pac.ps1 -Publish` in step `native-pac-build`, before updater receiving. Its successful publication copies three files (builder lines120–124):

| Tracked vendor path | Original85b Git blob | Original85b SHA256 | Required receiving distinction |
| --- | --- | --- | --- |
| `static/ergopti_plus/windows/vendor/ergopti_network_pac.exe` | `2de2cc4c365dbf0d39deea495866fedbc80e57de` | `ed879d3e9f861bf536005d9880c2f484ece51146761f08833fe5845d74083eeb` | One of exactly two genuinely rebuilt outputs. |
| `static/ergopti_plus/windows/vendor/ergopti_network_pac.json` | `ea6b84063141513e45dfeef827923e2d5e2c431f` | `a9ceb7bc9acf5e031dd908c2df8552aa092ab20d1d6a862c1d987b0ca581d1e5` | The exact serialized artifact receipt copied by the original producer. |
| `static/ergopti_plus/windows/vendor/ergopti_network_pac.LICENSE.txt` | `b018c0c62cf6f0a43ae689180dc085cf5ca7d93c` | `c6b6659630ca6cb837afe982ecc79511bfca878b56296d628b02eb6f18789c29` | Third copied output remains an original source pin; it is not a third permitted mismatch. |

Owner-reported Root manual38162146256 at3bd46b01 refused only the first two files: original3259 pins, allother3257 unchanged, updater/Restore native children0. The cited diagnostic artifact11710689424 has ZIP digest `b96c3778788f7a7e56a8b89b2495f156038efc5e1f9307d279cc19aaa921af8c`; separate nativePAC artifact11710807032 digest `6d69131a2a016e886e8d34ab3c5578905916b3081dfc9c34077ac8dfedee573f`. Exact comments6112314005/6112325834 are retained in `coordinated-source-evidence.json`. The abbreviated actual output hashes in that comment are not promoted to complete hashes or trusted fingerprints here.3259 is that owner's run census; this helper derives its roster from the current Git tree, so a later committed candidate must receive its own exact census.

The original producer also creates untracked/ignored files beneath `static/ergopti_plus/windows/build/native/network_pac`. Those files are compiler evidence, not original tracked inputs and not a reason to delete a source pin.

## Actual original compiler evidence and its limits

The builder uses the uniquely parsed original `Import-MsvcEnvironment` function from `tools/build/build_windows_nav_owner.ps1`, retained as `build/native/network_pac/msvc_function.source.ps1`. It imports x64 MSVC, verifies the canonical Duktape2.7.0 archive against the shared catalogue, then invokes the unchanged preparer and actual native compiler/tests. The shared source, Windows source, canonical PAC policy/defaults/helper, two builder scripts and preparer are part of the original source fingerprint.

Original receiving locations are:

- `static/ergopti_plus/windows/build/native/network_pac/prepared/source_receipt.json`: schema1, source fingerprint, Duktape archive digest, twelve input paths, four prepared archive/configuration file digests, helper byte count and limits. The preparer generates `pac_generated.h`; its generated_files map does not itself contain that header's digest.
- `static/ergopti_plus/windows/build/native/network_pac/ergopti_network_pac.exe`: actual built executable, from which the builder runs `--identity`. Parsed response must have schema1, Duktape20700 and the prepared source fingerprint.
- `static/ergopti_plus/windows/build/native/network_pac/artifact_receipt.json`: schema1, source fingerprint, Duktape archive digest, exact three system DLL imports, PE mitigation value, LICENSE digest and executable digest.
- Vendor JSON is copied from that artifact receipt; vendor EXE and LICENSE are copied from the actual built files.

The preparer runs again after compilation and the builder rejects a changed source fingerprint. The original commands run core/runtime tests and native platform tests, validate x64 PE32+ executable mitigations, and enforce exactly kernel32/ws2_32/iphlpapi static-runtime imports. These are genuine compiler contracts, not whole-source Git preflight or independent transport authentication. The fingerprint does not identify the actual compiler/Python/dumpbin executable bytes or versions; it is not a compiler receipt by itself. The existing artifact upload retains exactly three vendor files plus artifact_receipt.json. It does not retain prepared/source_receipt.json, the raw compiled `--identity` response, extracted MSVC function, or a toolchain/image/command receipt. Those missing observations must come from the authentic original publisher interface, not inferred from JSON prose. No replacement builder is proposed.

## Every frozen helper and consumer refusal seam

Frozen helper postimage is `6446316c34b6282895745ec8d1b9cfdf2c969702fa3cae3bc10a31d2678b7e13`.

1. `candidateSourceReceipt`, line134, demands actual HEAD equals the run's candidate SHA. This remains necessary and does not distinguish publication.
2. Lines135 and207 each run global `git diff --exit-code HEAD --`, covering staged and unstaged tracked files. Either of the two published differences refuses before any child. The final invocation repeats this refusal.
3. Lines140–150 enroll every tracked AHK and the fixed Windows/shared/native/build/receiver/workflow input roots from the candidate Git tree. Both PAC outputs and LICENSE remain present; there is no hardcoded3259 exclusion.
4. Lines166–180 enforce original source directories, regular unaliased files, acquired/final identity and SHA1 Git-blob equality for every enrolled file. Even bypassing the global diff alone leaves both genuinely rebuilt outputs refused by `actualBlob === blob`. All original directory/link/read stability controls must remain.
5. Lines191–192 enforce the21 independent updater pins. Neither PAC output is one of these21. Their body/data/oracle constraints do not require an amendment for the two-output provenance distinction.
6. Main line367 receives the complete source preflight before any child. Lines368–383 independently enforce HEAD and the21 pins again. The2307-byte original child routine only acquires/awaits/retires its actual process and captures; it has no source-policy whitelist or preflight to change.
7. Finally lines477–497 read HEAD and21 pins and repeat the entire complete source receipt, then require exact pre/post receipt equality. Genuine producer evidence must therefore be bound to the same frozen final output bytes at both boundaries, alongside the original commitment. A newly accepted output must never mean ongoing mutable publication during the native children.
8. Source receipt currently emits `tracked_source_clean:true` atline220. With two non-Git publication bytes present, that literal would be false as a statement about all tracked working bytes. It cannot survive by merely labeling a bypassed diff as clean.
9. Frozen workflow late verdict lines644–652 requires both `tracked_source_clean` booleans true, exact whole pre/post source receipt JSON, and joins actual helper/inputs/oracle/Node observations. Thus a correct producer-aware source representation needs an explicitly reviewed late-consumer change as well as helper receiving. Capture/source cleanup errors continue to refuse original-suite overlap; physical retirement acknowledgements do not follow from a producer hash.
10. Both the exact four Windows blocks in the workflow and their fixed source copy in `tools/test/ci-full-default.cjs` are consumed by the owning Default/Pipeline source guards. Future narrowly approved receipt-consumer edits must compose these copies and additive controls together. Generic mandatory Raw rules, three retirement/artifact/late rows, observercontinue-on-error:true, full-unit25minute/watchdog and original bodies remain unchanged.

## Finite integration boundary awaiting the public interface

G3 has offered its frozen six-source original publisher receiver. Its source cuts/loader/API are not yet received. Consequently no actual import name, receipt fields, output path, or source preimage for that interface is invented here.

The required join is explicit: original complete Git source commitment BEFORE existing builder allocation; actual original native-pac-build success and original compiler/source/archive/catalogue/toolchain evidence; exactly two declared genuinely published output bytes; unchanged original bytes for every other source including LICENSE and all21 updater pins; actual HEAD/current Git blob integrity; identical final acquired output bytes before and after the updater children; independently retained raw producer/runtime/artifact evidence joined to the official run/SHA/attempt/arch and API artifact digest. Original commitment and runtime publication must be distinguishable in the receipt. Neither a caller-supplied JSON object nor the current output digest authenticates the producer.

Only after independently receiving the six-source interface can a successor identify the exact loader/receiver addition to the updater helper, its pre/final complete-source checks, and the corresponding exact late-consumer/fixed-block/owning-guard spans. This is not an exemption request for git-diff-clean: every changed tracked file must be independently attributable to the fixed two-output producer, and any other mismatch, missing/failed builder, altered thirdvendor/LICENSE, stale/wrong-run receipt, altered compiler/source/archive identity, missing retained evidence, alias or final-byte drift must still refuse. The original23 filters18/4/1, original oracle7925/241, formatted transport7588/2b00, child2307/c768,21pins,300000ms shared budget and30000ms disposal remain strict.

The three corrected FULL_STEPS Source rows have ACK6112013288; that is custody, not a Windows result. Existing Root Restore/all-suite defects and the pending candidate original23/Windows5/native/PAC receiving remain distinct. No test/native credit or42-case transfer is asserted.
