local root = "/workspace/.ergopti-cloud/resume-personal-topology-fixture-portability/source/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local helpers = require("tests.helpers")
local mode, refusals = assert(arg[1]), 0
assert(mode == "available" or mode == "topology-absent" or mode == "global-absent")
local function absent()
 package.loaded["posix"] = nil
 package.preload["posix"] = function()
  refusals = refusals + 1
  error("controlled receiving environment: lua-posix is unavailable")
 end
end
if mode == "global-absent" then absent() end
if mode == "topology-absent" then
 local original_describe = helpers.describe
 helpers.describe = function(name, run)
  if name ~= "file_watchers Personal topology" then return original_describe(name, run) end
  local loaded, preload = package.loaded["posix"], package.preload["posix"]
  absent()
  local called, detail = pcall(original_describe, name, run)
  package.loaded["posix"], package.preload["posix"] = loaded, preload
  if not called then error(detail, 0) end
 end
end
require("tests.unit.meta.test_file_watchers")
local results = helpers.get_results()
results.receiving_mode, results.controlled_posix_refusals = mode, refusals
print(require("json").encode(results))
os.exit(results.failed == 0 and 0 or 1)
