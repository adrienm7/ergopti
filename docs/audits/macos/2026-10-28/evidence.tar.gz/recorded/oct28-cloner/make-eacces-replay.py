from pathlib import Path
p=Path('/workspace/scratch/cloner-log-guard-peer/matrix.py').read_text();body=p[p.index('rows=[]'):]
body=body.replace("for version,text in [('old',old),('new',source)]:", "for version,resources in [('old',old_resources),('new',new_resources)]:\n text=(resources/'clone_app.sh').read_text()")
body=body.replace("+'\\nexit 0\\n'", "+'\\nprintf healthy-tee-marker\\\\n\\nexit 0\\n'")
body=body.replace("p=subprocess.run([shell,str(script),str(app),'Log audit','','','tint','','0',str(diag)],env=env,capture_output=True,text=True,timeout=15)", "p=run_owned([shell,str(script),str(app),'Log audit','','','tint','','0',str(diag)],env)")
body=body.replace("assert tee_receipt.read_text()=='0','The actual tee must have returned and closed its captured pipes'", "assert tee_receipt.read_text() in (['0'] if mode=='healthy' else ['0','1']),'The actual tee must have returned and closed its captured pipes'")
body=body.replace("assert p.returncode==0 and not dest.exists() and not workspace.exists()", "assert p.returncode==0 and not dest.exists() and not workspace.exists() and p.stdout=='healthy-tee-marker\\n'")
body=body.replace("assert ('permission denied' in log.lower())==(mode!='healthy');", "assert ('permission denied' in (p.stdout+p.stderr).lower())==(mode!='healthy');")
body=body.replace("'tee_retired':'0'", "'tee_retired':tee_receipt.read_text()")
head='''from pathlib import Path
import subprocess,os,json,hashlib,shlex,sys,ctypes,time,signal
from types import SimpleNamespace
from datetime import datetime
from zoneinfo import ZoneInfo
root=Path('/workspace/scratch/oct28-cloner/eacces-replay');root.mkdir(mode=0o700)
old_resources=Path('/workspace/scratch/oct28-cloner/00-base/resources')
new_resources=Path('/workspace/scratch/oct28-cloner/01-second/resources')
old=(old_resources/'clone_app.sh').read_text();source=(new_resources/'clone_app.sh').read_text()
port=Path('/workspace/ergopti-macos-picker-observer/tools/test/lib/app-cloner-native-stat-port.cjs')
if sys.platform=='linux':
 if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'Private subreaper admission failed')
def retire_group(gid):
 deadline=time.monotonic()+5
 while time.monotonic()<deadline:
  if sys.platform=='linux':
   while True:
    try: child,_=os.waitpid(-gid,os.WNOHANG)
    except ChildProcessError:break
    if not child:break
  try:os.killpg(gid,0)
  except ProcessLookupError:return
  time.sleep(.01)
 raise RuntimeError('Owned exact process group remains; retain fixture')
def run_owned(argv,env):
 child=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 try:output,errors=child.communicate(timeout=15)
 except subprocess.TimeoutExpired:
  if child.returncode is None:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
  child.communicate(timeout=5);retire_group(child.pid);raise
 retire_group(child.pid)
 return SimpleNamespace(returncode=child.returncode,stdout=output,stderr=errors)
'''
Path('/workspace/scratch/oct28-cloner/eacces-replay.py').write_text(head+body)
