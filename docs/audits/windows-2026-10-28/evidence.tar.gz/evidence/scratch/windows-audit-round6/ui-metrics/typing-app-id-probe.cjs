'use strict';
const assert=require('node:assert/strict');
const vm=require('node:vm');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
for(const name of ['Editor.exe','__proto__','constructor','toString','hasOwnProperty']) {
 const page=loadMetricsTypingPage('windows');
 const manifest={'2026-10-26':{[name]:{chars:5,time:500,app_time_ms:1000}}};
 const blob={metrics_manifest:manifest,_prefetch_data:{historical:{},today:{}},app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}};
 page.messageListeners.filter(e=>e.name==='message').at(-1).callback({data:{type:'prefetch',blob}});
 page.context.render_apps_kpi();
 const rows=JSON.parse(vm.runInContext('JSON.stringify(_apps_data)',page.context));
 console.log(JSON.stringify({name,rows,card:page.elements.get('apps_val').innerHTML,diagnostics:page.diagnostics}));
 assert.deepEqual(rows.map(r=>({name:r.name,chars:r.chars})),[{name,chars:5}]);
}
