# This library is loaded only by the pinned, tree-owned verified-stream worker.
Set-StrictMode -Version Latest

function Initialize-OllamaSourceProducer([Reflection.Assembly]$AssemblyAuthority) {
	if (Get-Variable -Name OSP_Rows -Scope Script -ErrorAction SilentlyContinue) {
		throw 'Source producer initialization is exclusive.'
	}
	if (-not ('Ergopti.Ollama.SourceProducerNative' -as [type])) { throw 'The pinned managed source bridge must be loaded before helper initialization.' }
	if (-not [object]::ReferenceEquals($AssemblyAuthority, [Ergopti.Ollama.SourceProducerNative].Assembly)) {
		throw 'Source producer type is not the held, verified assembly.'
	}
	$script:OSP_Rows = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal)
	$script:OSP_Publications = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal)
}

function Open-OllamaPublishedSourceOwner($Root, [string]$Ticket, [string]$StageIdentity,
	[string]$ManifestHash, [string]$DescriptorIdentity, [string]$DescriptorHash, $AcquisitionOwner) {
	if ($Ticket -notmatch '\A[0-9a-f]{32}\z' -or $ManifestHash -notmatch '\A[0-9a-f]{64}\z' -or
		$DescriptorHash -notmatch '\A[0-9a-f]{64}\z') { throw 'Published source requires its exact captured install receipts.' }
	$id = [Guid]::NewGuid().ToString('N')
	$row = [ordered]@{ id = $id; root = $Root; ticket = $Ticket; stage = $null;
		wal = $null; descriptor = $null; descriptor_identity = $DescriptorIdentity; descriptor_hash = $DescriptorHash;
		manifest_hash = $ManifestHash; phase = 'acquiring'; first_error = ''; consumers = 0; closed = $false;
		rename_attempted = $false; destination = ''; final_leaf = ''; native_container = ''; native_root = '';
		native_versions = ''; versions_identity = ''; close_debt = [Collections.Generic.List[object]]::new() }
	$script:OP_Rows.Add($id, $row)
	try {
		$native = Get-OllamaPublicationNativeRoot $Root
		$row.native_root = $native.root_native_path
		$row.native_versions = $native.versions_native_path
		$row.versions_identity = $native.versions_identity
		$row.stage = Open-OllamaPreparedStage $Root $Ticket $StageIdentity $ManifestHash $false $AcquisitionOwner
		$row.native_container = [Ergopti.Ollama.PublicationNative]::FinalPath($row.stage.handle)
		if (-not [StringComparer]::OrdinalIgnoreCase.Equals($row.native_container, [IO.Path]::Combine($row.native_root, '.stage-' + $Ticket))) {
			throw 'Source container is outside its retained native root.'
		}
		$m = $row.stage.manifest
		$row.final_leaf = $m.version + '-' + $m.asset + '-' + $m.archive_sha256 + '.json'
		[void](Assert-OllamaRelativePath $row.final_leaf)
		$row.destination = [IO.Path]::Combine($row.native_versions, $row.final_leaf)
		$row.descriptor = Open-OllamaReadFile $row.destination
		Assert-OllamaPublicationImage $row
		Assert-OllamaPublicationLocation $row
		$image = Read-OllamaJsonStream $row.descriptor
		if ($image.kind -ne 'ollama-immutable-container-reference' -or $image.schema -ne 1 -or
			$image.root_identity -ne $Root.identity -or $image.container_identity -ne $StageIdentity -or
			$image.ticket -ne $Ticket -or $image.manifest_sha256 -ne $ManifestHash -or
			$image.catalogue_sha256 -ne $m.catalogue_sha256 -or $image.archive_sha256 -ne $m.archive_sha256 -or
			$image.version -ne $m.version -or $image.asset -ne $m.asset -or
			$image.container -ne ('.stage-' + $Ticket) -or $image.versions_identity -ne $row.versions_identity -or
			-not [StringComparer]::OrdinalIgnoreCase.Equals($image.root_native_path, $row.native_root)) {
			throw 'Published descriptor does not advertise the admitted immutable container.'
		}
		# This adopts an existing verified publication, not another rename attempt.
		# Published confirmation still revalidates its native identity/path/hash.
		$row.rename_attempted = $true
		$row.phase = 'published'
		$script:OSP_Publications.Add($id, $row)
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		$_.Exception.Data['ollama_publication_owner'] = $id
		throw
	}
	return $id
}

function Convert-OllamaDigestBytes([string]$Digest) {
	if ($Digest -notmatch '\A[0-9a-f]{64}\z') { throw 'Source digest requires exact lowercase SHA-256.' }
	$bytes = [byte[]]::new(32)
	for ($index = 0; $index -lt 32; $index++) { $bytes[$index] = [Convert]::ToByte($Digest.Substring($index * 2, 2), 16) }
	return ,$bytes
}

function Add-OllamaVerifiedSourceMember($Owner, [IntPtr]$Handle, [uint32]$Kind, [string]$Hash) {
	if ($Handle -eq [IntPtr]::Zero -or $Handle -eq [IntPtr]::new(-1) -or $Kind -gt 1) { throw 'Source member requires a retained native handle.' }
	$identity = [Ergopti.Ollama.ManagedNative]::Identity($Handle)
	if ($identity -notmatch '\A([0-9a-f]{8}):([0-9a-f]{16})\z') { throw 'Source member native identity is malformed.' }
	$volume = [Convert]::ToUInt64($Matches[1], 16)
	$index = [Convert]::ToUInt64($Matches[2], 16)
	$path = [Ergopti.Ollama.PublicationNative]::FinalPath($Handle)
	foreach ($old in $Owner.members) {
		if ($old.handle -eq $Handle -or ($old.volume -eq $volume -and $old.index -eq $index)) { throw 'Source offer contains a duplicate native identity.' }
	}
	$Owner.members.Add([ordered]@{ handle = $Handle; kind = $Kind; volume = $volume; index = $index;
		path = $path; digest = (Convert-OllamaDigestBytes $Hash) })
}

function Add-OllamaVerifiedDirectoryMember($Owner, [IntPtr]$Handle) {
	if ($Handle -eq [IntPtr]::Zero -or $Handle -eq [IntPtr]::new(-1)) { throw "Source directory projection requires a retained handle." }
	$identity = [Ergopti.Ollama.ManagedNative]::DirectoryIdentity($Handle)
	# Query every borrowed alias while the raw acquisition ledger still holds it.
	# FileID/volume is the dedup key; native DOS aliases need not be text-equal.
	$nativePath = [Ergopti.Ollama.PublicationNative]::FinalPath($Handle)
	# Volume roots are genuine retained directory ancestors, not managed file paths.
	if ($nativePath -notmatch '\A[A-Za-z]:\\\z') { [void](Assert-OllamaLocalPath $nativePath) }
	if ($Owner.directory_ids.ContainsKey($identity)) {
		$existing = $Owner.directory_ids[$identity]
		if ($existing.kind -ne 1 -or [Ergopti.Ollama.ManagedNative]::DirectoryIdentity($existing.handle) -cne $identity) {
			throw "The retained directory projection lost its exact native authority."
		}
		return
	}
	Add-OllamaVerifiedSourceMember $Owner $Handle 1 ("0" * 64)
	$Owner.directory_ids.Add($identity, $Owner.members[$Owner.members.Count - 1])
}

function Add-OllamaManagedModelsOffer($Owner, $Root) {
	if (-not $Root.ContainsKey('models')) { return }
	$models = $Root.models
	if ($models.phase -ne 'held' -or $null -eq $models.marker -or
		[Ergopti.Ollama.ManagedNative]::DirectoryIdentity($models.handle) -cne $models.identity -or
		-not [StringComparer]::OrdinalIgnoreCase.Equals([Ergopti.Ollama.ManagedNative]::FinalPath($models.handle), $models.path)) {
		throw 'The models offer lost its continuously retained native owner.'
	}
	# Root.handles already contains this mutable directory. Only its immutable
	# typed ownership receipt is a known leased file; arbitrary model files are not.
	Add-OllamaVerifiedSourceMember $Owner $models.marker.SafeFileHandle.DangerousGetHandle() 0 $models.marker_hash
}

function New-OllamaVerifiedSourceOffer([string]$PublicationId, [string]$ModulePath, [string]$ModuleHash,
	[string]$GuardianPath, [string]$GuardianHash, [string]$LauncherPath, [string]$LauncherHash) {
	$id = [Guid]::NewGuid().ToString('N')
	$owner = [ordered]@{ id = $id; publication = $null; module_stream = $null; guardian_stream = $null;
		members = [Collections.Generic.List[object]]::new();
		directory_ids = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal);
		phase = 'acquiring'; first_error = '';
		close_debt = [Collections.Generic.List[object]]::new(); launcher_stream = $null; sent = $false }
	$script:OSP_Rows.Add($id, $owner)
	try {
		$row = Get-OllamaPublicationRow $PublicationId
		$owner.publication = $row
		if ($row.phase -ne 'published' -or $row.closed -or $row.consumers -ne 0 -or $row.close_debt.Count -ne 0) {
			throw 'Source offer requires the exact live published owner before consumer reservation.'
		}
		if (-not $script:OSP_Publications.ContainsKey($PublicationId) -or
			-not [object]::ReferenceEquals($script:OSP_Publications[$PublicationId], $row)) {
			throw 'A source offer must consume this process exact verified publication owner.'
		}
		# Consume the strong same-process admission once. The exact file handles
		# never released their deny-writer/delete fence; do not hash them again.
		$script:OSP_Publications.Remove($PublicationId) | Out-Null
		$row.consumers = 1
		# The stage owner already hashed its manifest and every runtime stream while
		# denying writers. Reuse that authority and those exact streams continuously.
		# Raw ledgers keep every acquisition; only the offer projection is unique.
		foreach ($directory in $row.root.handles) { Add-OllamaVerifiedDirectoryMember $owner $directory }
		Add-OllamaManagedModelsOffer $owner $row.root
		Add-OllamaVerifiedDirectoryMember $owner $row.stage.handle
		foreach ($directory in $row.stage.directory_handles.Values) {
			Add-OllamaVerifiedDirectoryMember $owner $directory
		}
		Add-OllamaVerifiedSourceMember $owner $row.stage.owned_files['prepared.json'].SafeFileHandle.DangerousGetHandle() 0 $row.manifest_hash
		$creationStream = $row.stage.owned_files['stage-owner.json']
		Add-OllamaVerifiedSourceMember $owner $creationStream.SafeFileHandle.DangerousGetHandle() 0 (Get-OllamaStreamHash $creationStream)
		Add-OllamaVerifiedSourceMember $owner $row.descriptor.SafeFileHandle.DangerousGetHandle() 0 $row.descriptor_hash
		foreach ($file in $row.stage.manifest.files) {
			$stream = $row.stage.owned_files[$file.path]
			if ([Ergopti.Ollama.ManagedNative]::Identity($stream.SafeFileHandle.DangerousGetHandle()) -ne $file.identity -or $stream.Length -ne $file.bytes) {
				throw 'The continuously leased runtime member no longer has its admitted identity/size.'
			}
			Add-OllamaVerifiedSourceMember $owner $stream.SafeFileHandle.DangerousGetHandle() 0 $file.sha256
		}
		$owner.module_stream = Open-OllamaReadFile (Assert-OllamaLocalPath $ModulePath)
		if ((Get-OllamaStreamHash $owner.module_stream) -ne $ModuleHash) { throw 'The pinned channel module stream differs.' }
		$owner.guardian_stream = Open-OllamaReadFile (Assert-OllamaLocalPath $GuardianPath)
		if ((Get-OllamaStreamHash $owner.guardian_stream) -ne $GuardianHash) { throw 'The pinned guardian image stream differs.' }
		Add-OllamaVerifiedSourceMember $owner $owner.guardian_stream.SafeFileHandle.DangerousGetHandle() 0 $GuardianHash
		$owner.launcher_stream = Open-OllamaReadFile (Assert-OllamaLocalPath $LauncherPath)
		if ((Get-OllamaStreamHash $owner.launcher_stream) -ne $LauncherHash) { throw 'The pinned daemon launcher stream differs.' }
		Add-OllamaVerifiedSourceMember $owner $owner.launcher_stream.SafeFileHandle.DangerousGetHandle() 0 $LauncherHash
		[Ergopti.Ollama.SourceProducerNative]::Load([Ergopti.Ollama.PublicationNative]::FinalPath($owner.module_stream.SafeFileHandle.DangerousGetHandle()))
		$owner.phase = 'prepared'
	} catch {
		if ($owner.first_error -eq '') { $owner.first_error = $_.Exception.Message }
		$owner.phase = 'retained-debt'
		$_.Exception.Data['ollama_source_offer'] = $id
		throw
	}
	return $id
}

function Send-OllamaVerifiedSourceOffer([string]$Id, [IntPtr]$Mapping, [IntPtr]$Ready,
	[IntPtr]$Release, [IntPtr]$Parent) {
	if (-not $script:OSP_Rows.ContainsKey($Id)) { throw 'Unknown source offer owner.' }
	$owner = $script:OSP_Rows[$Id]
	if ($owner.phase -ne 'prepared' -or $owner.sent) { throw 'Source offer publication is once-only.' }
	$owner.sent = $true
	try {
		$members = $owner.members
		[Ergopti.Ollama.SourceProducerNative]::Publish($Mapping, $Ready, $Release, $Parent,
			(Convert-OllamaDigestBytes $owner.publication.manifest_hash),
			[IntPtr[]]@($members | ForEach-Object { $_.handle }), [uint32[]]@($members | ForEach-Object { $_.kind }),
			[uint64[]]@($members | ForEach-Object { $_.volume }), [uint64[]]@($members | ForEach-Object { $_.index }),
			[string[]]@($members | ForEach-Object { $_.path }), [byte[][]]@($members | ForEach-Object { ,$_.digest }))
		$owner.phase = 'offered'
	} catch {
		if ($owner.first_error -eq '') { $owner.first_error = $_.Exception.Message }
		$owner.phase = 'retained-debt'
		throw
	}
}

function Wait-OllamaSourceHandoff([string]$Id, [IntPtr]$Release, [IntPtr]$Parent) {
	if (-not $script:OSP_Rows.ContainsKey($Id)) { throw 'Unknown source offer owner.' }
	$owner = $script:OSP_Rows[$Id]
	if ($owner.phase -ne 'offered') { throw 'Only an actual offered source may wait for handoff.' }
	# The native factory signals release only after actual guardian READY. Parent
	# death also permits source exit: the guardian's retained job protects consumers.
	$waited = [Ergopti.Ollama.SourceProducerNative]::WaitForMultipleObjects(2, [IntPtr[]]@($Release, $Parent), $false, [uint32]::MaxValue)
	if ($waited -notin @(0, 1)) {
		$owner.phase = 'retained-debt'
		if ($owner.first_error -eq '') { $owner.first_error = 'Source handoff wait refused.' }
		throw $owner.first_error
	}
	$owner.phase = 'handoff-observed'
	# Process terminal, not a caller Boolean, retires this producer's copies and
	# loaded module. No close retry or publication consumer-count forgery occurs.
	return $waited
}

# This library is loaded only by the pinned same-process intake source worker.
Set-StrictMode -Version Latest

function Initialize-OllamaIntakeSource {
	if (Get-Variable -Name OIA_Rows -Scope Script -ErrorAction SilentlyContinue) {
		throw 'Archive intake source initialization is exclusive.'
	}
	if (-not (Get-Variable -Name OSP_Rows -Scope Script -ErrorAction SilentlyContinue)) {
		throw 'The verified source producer must own initialization first.'
	}
	$script:OIA_Rows = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal)
}

function New-OllamaIntakeSource([string]$RootPath, [string]$CataloguePath,
	[string]$CatalogueHash, [string]$AssetId, [string]$Ticket, [long]$ExpandedBudget,
	[int]$EntryBudget, [string]$NativeModulePath, [string]$NativeModuleHash,
	[string]$GuardianPath, [string]$GuardianHash, [string]$LauncherPath, [string]$LauncherHash,
	[string]$ModelsDirectory = '', [string]$ModelsFolderName = '') {
	if ($Ticket -notmatch '\A[0-9a-f]{32}\z' -or $ExpandedBudget -le 0 -or $EntryBudget -le 0) {
		throw 'Intake requires its captured closed ticket and positive archive budgets.'
	}
	$id = [Guid]::NewGuid().ToString('N')
	$row = [ordered]@{ id = $id; ticket = $Ticket; root = $null; release = $null;
		archive = $null; directory = [IntPtr]::Zero; directory_identity = ''; directory_path = '';
		wal = $null; phase = 'acquiring'; first_error = ''; prepared = $null; offer = '';
		expanded_budget = $ExpandedBudget; entry_budget = $EntryBudget;
		asset = $AssetId; catalogue_hash = $CatalogueHash; acquisition = [ordered]@{
			root_handles = $null; stage_handle = [IntPtr]::Zero; streams = $null;
			directory_handles = $null; phase = 'acquiring'; first_error = '' } }
	$script:OIA_Rows.Add($id, $row)
	try {
		# Both authorities stay resident in this exact worker through download and
		# extraction. No short-lived preflight helper releases/reopens the Root.
		$row.release = Open-OllamaReleaseSource $CataloguePath $CatalogueHash $AssetId
		$row.root = Open-OllamaManagedRoot $RootPath $true $row.acquisition
		$admitted = @{ version = $row.release.version; pin = $row.release.pin;
			asset = $AssetId; catalogue_sha256 = $CatalogueHash }
		# A distinct same-owner WAL ticket prevents collision with the later
		# original stage preparation's .creation-<captured-ticket> WAL.
		$row.wal = Begin-OllamaCreationWal $row.root $admitted $id
		if ($ModelsDirectory -ne '' -or $ModelsFolderName -ne '') {
			[void](Open-OllamaManagedModels $row.root $ModelsDirectory $ModelsFolderName $true $row.wal)
		}
		$leaf = '.intake-' + $Ticket
		$nativeRoot = [Ergopti.Ollama.ManagedNative]::FinalPath($row.root.root_handle)
		$row.directory_path = [IO.Path]::Combine($nativeRoot, $leaf)
		[void](Assert-OllamaRelativePath $leaf)
		Add-OllamaCreationRecord $row.wal 'intake-directory-intent' $leaf ''
		[Ergopti.Ollama.ManagedNative]::CreateProtectedDirectory($row.directory_path,
			(New-OllamaPrivateSecurity).GetSecurityDescriptorBinaryForm())
		$row.directory = [Ergopti.Ollama.ManagedNative]::OpenDirectory($row.directory_path, $true)
		$row.directory_identity = [Ergopti.Ollama.ManagedNative]::DirectoryIdentity($row.directory)
		$actual = [Ergopti.Ollama.ManagedNative]::FinalPath($row.directory)
		if (-not [StringComparer]::OrdinalIgnoreCase.Equals($actual, $row.directory_path)) {
			throw 'The intake directory did not remain within its exact retained native Root.'
		}
		Add-OllamaCreationRecord $row.wal 'intake-directory-owned' $leaf $row.directory_identity
		$offer = [ordered]@{ id = $id; publication = @{ manifest_hash = $CatalogueHash };
			module_stream = $null; guardian_stream = $null; launcher_stream = $null;
			members = [Collections.Generic.List[object]]::new();
			directory_ids = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal);
			phase = 'acquiring'; first_error = ''; close_debt = [Collections.Generic.List[object]]::new(); sent = $false }
		$script:OSP_Rows.Add($id, $offer)
		$row.offer = $id
		foreach ($handle in $row.root.handles) { Add-OllamaVerifiedDirectoryMember $offer $handle }
		Add-OllamaManagedModelsOffer $offer $row.root
		Add-OllamaVerifiedDirectoryMember $offer $row.directory
		$offer.module_stream = Open-OllamaReadFile (Assert-OllamaLocalPath $NativeModulePath)
		if ((Get-OllamaStreamHash $offer.module_stream) -cne $NativeModuleHash) { throw 'The intake native module pin differs.' }
		$offer.guardian_stream = Open-OllamaReadFile (Assert-OllamaLocalPath $GuardianPath)
		if ((Get-OllamaStreamHash $offer.guardian_stream) -cne $GuardianHash) { throw 'The intake guardian pin differs.' }
		$offer.launcher_stream = Open-OllamaReadFile (Assert-OllamaLocalPath $LauncherPath)
		if ((Get-OllamaStreamHash $offer.launcher_stream) -cne $LauncherHash) { throw 'The intake launcher pin differs.' }
		Add-OllamaVerifiedSourceMember $offer $offer.guardian_stream.SafeFileHandle.DangerousGetHandle() 0 $GuardianHash
		Add-OllamaVerifiedSourceMember $offer $offer.launcher_stream.SafeFileHandle.DangerousGetHandle() 0 $LauncherHash
		[Ergopti.Ollama.SourceProducerNative]::Load(
			[Ergopti.Ollama.PublicationNative]::FinalPath($offer.module_stream.SafeFileHandle.DangerousGetHandle()))
		$offer.phase = 'prepared'
		$row.phase = 'inventory-held'
	} catch {
		if ($row.first_error -eq '') { $row.first_error = 'intake_acquisition_refused' }
		$row.phase = 'retained-debt'
		$_.Exception.Data['ollama_intake_owner'] = $id
		# Partial raw acquisition stays in the reserved lookaside row. Its actual
		# task/job terminal is required before kernel capabilities can disappear.
		throw
	}
	return $id
}

function Get-OllamaIntakeInventory([string]$Id) {
	if (-not $script:OIA_Rows.ContainsKey($Id)) { throw 'Unknown exact intake source owner.' }
	$row = $script:OIA_Rows[$Id]
	if ($row.phase -ne 'inventory-held' -or -not $script:OSP_Rows.ContainsKey($row.offer)) {
		throw 'Only the retained intake source may describe its native inventory.'
	}
	$offer = $script:OSP_Rows[$row.offer]
	$records = [Collections.Generic.List[object]]::new()
	foreach ($member in $offer.members) {
		$records.Add([ordered]@{ handle = $member.handle.ToInt64().ToString('x16');
			kind = $member.kind; volume = $member.volume.ToString('x8');
			index = $member.index.ToString('x16');
			path = $member.path; sha256 = ([BitConverter]::ToString($member.digest)).Replace('-', '').ToLowerInvariant() })
	}
	# Candidate scalar metadata is not namespace admission or capacity authority.
	# The native parent duplicates/revalidates these exact source capabilities,
	# retains the validated projection, and only then computes channel capacity.
	return [ordered]@{ kind = 'ollama-intake-inventory'; ticket = $row.ticket; owner = $Id;
		root_identity = $row.root.identity; intake_identity = $row.directory_identity;
		catalogue_sha256 = $row.catalogue_hash; records = $records }
}

function Send-OllamaIntakeOffer([string]$Id, [IntPtr]$Mapping, [IntPtr]$Ready,
	[IntPtr]$Release, [IntPtr]$Parent) {
	if (-not $script:OIA_Rows.ContainsKey($Id)) { throw 'Unknown exact intake source owner.' }
	$row = $script:OIA_Rows[$Id]
	if ($row.phase -ne 'inventory-held') { throw 'Intake channel publication is once-only.' }
	$row.phase = 'publishing'
	Send-OllamaVerifiedSourceOffer $row.offer $Mapping $Ready $Release $Parent
	$row.phase = 'offered'
}

function Prepare-OllamaIntakeAfterNativeSeal([string]$Id, [IntPtr]$Release, [IntPtr]$Parent) {
	if (-not $script:OIA_Rows.ContainsKey($Id)) { throw 'Unknown exact intake source owner.' }
	$row = $script:OIA_Rows[$Id]
	if ($row.phase -ne 'offered') { throw 'No exact offered intake can await native seal.' }
	$waited = Wait-OllamaSourceHandoff $row.offer $Release $Parent
	if ($waited -ne 0) { throw 'Parent retirement cannot authorize archive preparation.' }
	# In the native intake mode only original curl terminal/exit0/private-job0
	# can signal this event; READY, cancellation and setup failure cannot do so.
	$row.phase = 'preparing'
	$archiveArguments = @($row.release, $row.asset,
		[IO.Path]::Combine($row.directory_path, 'archive.zip'), $row.expanded_budget, $row.entry_budget,
		$row.catalogue_hash, $true)
	$row.archive = Read-OllamaHeldReleaseArchive @archiveArguments
	$row.prepared = Prepare-OllamaManagedStage $row.root $row.archive $row.ticket
	$row.phase = 'prepared'
	# Keep the exact catalogue/archive/Root/offer streams and handles resident.
	# The natural original worker terminal, composite zero and guardian handback
	# retire them; a caller Boolean or disposable-map receipt never does.
	return $row.prepared
}

function Close-OllamaIntakeScratch([string]$Id, [IO.FileStream]$CommandStream) {
	if (-not $script:OIA_Rows.ContainsKey($Id)) { throw 'Unknown exact intake cleanup owner.' }
	$row = $script:OIA_Rows[$Id]
	if ($row.phase -ne 'prepared' -or $null -eq $row.archive -or $null -eq $CommandStream) {
		throw 'Intake cleanup has no same-worker prepared/archive authority.'
	}
	$row.phase = 'scratch-retiring'
	try {
		# These are the same DELETE-capable streams already held through reading,
		# never a path reopened after hash/extraction or a copied cleanup receipt.
		$row.archive.zip.Dispose()
		Remove-OllamaExactFile $row.archive.archive_stream
		$row.archive.archive_stream.Dispose()
		Remove-OllamaExactFile $CommandStream
		$CommandStream.Dispose()
		[Ergopti.Ollama.ManagedNative]::DeleteExactDirectory($row.directory)
		Remove-OllamaExactFile $row.wal.stream
		$row.wal.stream.Dispose()
		$row.phase = 'scratch-disposition-requested'
		# Directory duplicates remain in the native bootstrap/guardian. Natural
		# source terminal and final native close ACKs complete deletion; this phase
		# alone is not physical namespace retirement or ticket admission.
	} catch {
		if ($row.first_error -eq '') { $row.first_error = 'intake_scratch_retirement_refused' }
		$row.phase = 'retained-debt'
		throw
	}
}
