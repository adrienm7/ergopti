# Reload and diagnostics receiving

RECEIVING.json records the exact published source and CI boundary. The original T1 Mac gate and original C1 CI remain FAILED. The T2 fixture repair is joined through its actual one-path Git delta, delta-mapper selection, full HS follow-up and separate C2 CI. Frozen local logs and their before/after brackets qualify their capture only. Author records preserve intermediate failed and unqualified attempts; consult their receipts before interpreting a raw count. No success is inferred from file presence.

MANIFEST.json hashes every payload member. SHA256SUMS additionally hashes MANIFEST.json. SHA256SUMS is the checksum carrier and therefore does not claim a self hash. The builder independently reopens every regular tar member and verifies the complete name set and all payload/manifest checksums. No links or directory entries are admitted.

Sensitive signed-redirect stderr is excluded. Only hashes, byte sizes and reasons identify excluded inputs; no signed URL, authorization header or session history is published.
