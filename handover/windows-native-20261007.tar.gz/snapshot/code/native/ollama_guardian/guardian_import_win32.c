#include "guardian_import_win32.h"
#include <stdlib.h>
#include <string.h>

static int GI_WinError(GI_Win32Context *c,DWORD error) {
    if(c->first_os_error==ERROR_SUCCESS)
        c->first_os_error=error!=ERROR_SUCCESS?error:ERROR_INVALID_DATA;
    return 0;
}
static int GI_WinSourceLive(GI_Win32Context *c,HANDLE source) {
    FILETIME creation,exit_time,kernel,user;
    DWORD waited=WaitForSingleObject(source,0u);
    if(waited!=WAIT_TIMEOUT)return GI_WinError(c,waited==WAIT_FAILED?GetLastError():ERROR_PROCESS_ABORTED);
    if(GetProcessId(source)!=c->source_pid)return GI_WinError(c,ERROR_INVALID_DATA);
    if(!GetProcessTimes(source,&creation,&exit_time,&kernel,&user))return GI_WinError(c,GetLastError());
    if(CompareFileTime(&creation,&c->source_creation)!=0)return GI_WinError(c,ERROR_INVALID_DATA);
    return 1;
}
int GI_Win32ContextInit(GI_Win32Context *c,GSC_Owner *channel) {
    FILETIME exit_time,kernel,user;
    if(c==NULL || channel==NULL || GSC_State(channel)!=GSC_DATA_READY)return 0;
    memset(c,0,sizeof(*c));c->channel=channel;c->source=GSC_Source(channel);
    if(c->source==NULL)return GI_WinError(c,ERROR_INVALID_DATA);
    c->source_pid=GetProcessId(c->source);
    if(c->source_pid==0u)return GI_WinError(c,GetLastError());
    if(!GetProcessTimes(c->source,&c->source_creation,&exit_time,&kernel,&user))return GI_WinError(c,GetLastError());
    return GI_WinSourceLive(c,c->source);
}
static void *GI_WinAllocate(void *context,size_t bytes) {
    GI_Win32Context *c=context;
    void *value=calloc(1u,bytes);
    if(value==NULL)GI_WinError(c,ERROR_NOT_ENOUGH_MEMORY);
    return value;
}
int GI_Win32ContextInitIntake(GI_Win32Context *c,HANDLE source,const FILETIME *expected,
                            const GI_Expected *candidates,size_t count) {
    FILETIME exit_time,kernel,user;
    if(c==NULL || source==NULL || expected==NULL || candidates==NULL || count==0u)return 0;
    memset(c,0,sizeof(*c));c->source=source;c->held_candidates=candidates;c->held_count=count;
    c->source_pid=GetProcessId(source);
    if(c->source_pid==0u)return GI_WinError(c,GetLastError());
    if(!GetProcessTimes(source,&c->source_creation,&exit_time,&kernel,&user))return GI_WinError(c,GetLastError());
    if(CompareFileTime(expected,&c->source_creation)!=0)return GI_WinError(c,ERROR_INVALID_DATA);
    return GI_WinSourceLive(c,source);
}
static void GI_WinRelease(void *context,void *value) {
    (void)context;free(value);
}
static int GI_WinDuplicateSource(void *context,uintptr_t source,uintptr_t *out) {
    GI_Win32Context *c=context;HANDLE copied=NULL;
    if((HANDLE)source!=c->source || out==NULL || !GI_WinSourceLive(c,c->source))return GI_WinError(c,ERROR_INVALID_DATA);
    if(!DuplicateHandle(GetCurrentProcess(),c->source,GetCurrentProcess(),&copied,
        SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_DUP_HANDLE,FALSE,0u))
        return GI_WinError(c,GetLastError());
    *out=(uintptr_t)copied;
    return 1;
}
static int GI_WinDuplicateContent(void *context,uintptr_t source,
                                  const GI_Expected *expected,uintptr_t *out) {
    GI_Win32Context *c=context;HANDLE copied=NULL;
    const GI_Expected *records;size_t count,i;int exact=0;
    if(out==NULL || expected==NULL || !GI_WinSourceLive(c,(HANDLE)source))return GI_WinError(c,ERROR_INVALID_DATA);
    if(c->channel!=NULL)records=GSC_Records(c->channel,&count);
    else {records=c->held_candidates;count=c->held_count;}
    if(records==NULL)return GI_WinError(c,ERROR_INVALID_DATA);
    for(i=0u;i<count;++i)if(expected==&records[i]){exact=1;break;}
    if(!exact)return GI_WinError(c,ERROR_INVALID_DATA);
    /* Publish only a known successful duplicate. No unconfirmed failed-API
       output is ever interpreted as an owned handle to close. */
    if(!DuplicateHandle((HANDLE)source,(HANDLE)expected->source_handle,
        GetCurrentProcess(),&copied,0u,FALSE,DUPLICATE_SAME_ACCESS))
        return GI_WinError(c,GetLastError());
    *out=(uintptr_t)copied;
    return 1;
}
static int GI_WinValidateContent(void *context,uintptr_t handle,
                                 const GI_Expected *expected) {
    GI_Win32Context *c=context;
    GG_Win32Context check={0};GG_Win32Identity identity;
    if(expected->volume>UINT32_MAX || expected->path_units==0u)return GI_WinError(c,ERROR_INVALID_DATA);
    identity.volume_serial=(DWORD)expected->volume;
    identity.file_index_high=(DWORD)(expected->index>>32);
    identity.file_index_low=(DWORD)expected->index;
    identity.is_directory=expected->kind;
    identity.native_path=(const wchar_t *)expected->native_path;
    if(!GG_Win32CheckContent(&check,(HANDLE)handle,&identity))
        return GI_WinError(c,check.first_os_error);
    return GI_WinSourceLive(c,c->source);
}
static int GI_WinClose(void *context,uintptr_t handle) {
    GI_Win32Context *c=context;
    if(!CloseHandle((HANDLE)handle))return GI_WinError(c,GetLastError());
    return 1;
}
GI_Port GI_Win32ImportPort(GI_Win32Context *context) {
    GI_Port port={context,GI_WinAllocate,GI_WinRelease,GI_WinDuplicateSource,
        GI_WinDuplicateContent,GI_WinValidateContent,GI_WinClose};
    return port;
}
