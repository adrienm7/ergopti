"""Replay both exact physical owning entrypoints serially in private trees."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

BASE = Path(__file__).resolve().parent
REL = 'tools/test/macos_native_http_receiving_facts_test.py'
facts = json.loads((BASE / 'qualification.json').read_text())
for rel, expected in facts['runtime_source_hashes'].items():
    assert hashlib.sha256((BASE / 'runtime-source' / rel).read_bytes()).hexdigest() == expected
subprocess.run([sys.executable, '-I', '-B', str(BASE / 'verify_composed.py')], check=True)
logs = Path(tempfile.mkdtemp(prefix='canonical-replay-', dir=BASE))
results = []
for subject, expected in (('preimage', 1), ('candidate', 0)):
    root = logs / subject
    shutil.copytree(BASE / 'runtime-source', root)
    shutil.copyfile(BASE / subject / REL, root / REL)
    private = root / 'private-tmp'
    private.mkdir(mode=0o700)
    environment = os.environ.copy()
    environment['TMPDIR'] = str(private)
    with (logs / (subject + '.stdout')).open('wb') as out, (logs / (subject + '.stderr')).open('wb') as err:
        received = subprocess.run([sys.executable, '-I', '-B', str(root / REL)], cwd=root, env=environment, stdout=out, stderr=err)
    raw = (logs / (subject + '.stderr')).read_text()
    assert received.returncode == expected, (subject, received.returncode)
    assert 'Ran 103 tests' in raw
    assert ('FAILED (errors=6)' if subject == 'preimage' else '\nOK\n') in raw
    results.append({'subject': subject, 'exit': received.returncode, 'tests': 103, 'errors': 6 if subject == 'preimage' else 0, 'failures': 0, 'skips': 0})
(logs / 'receipt.json').write_text(json.dumps({'qualification': 'PORTABLE_SOFTWARE_ONLY_NO_NATIVE_CREDIT', 'discovery': 'unchanged physical owning unittest.main entrypoint', 'results': results}, indent=2) + '\n')
print(json.dumps({'logs': str(logs), 'results': results}, sort_keys=True))
