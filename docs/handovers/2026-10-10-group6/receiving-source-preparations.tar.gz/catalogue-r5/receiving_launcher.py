"""Private evidence launcher; executes the identical enrolled twelve cases."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

source, output = map(Path, sys.argv[1:])
specification = importlib.util.spec_from_file_location("catalogue_receiving", source)
module = importlib.util.module_from_spec(specification)
specification.loader.exec_module(module)
suite = unittest.defaultTestLoader.loadTestsFromTestCase(module.CatalogueRefusalTests)
result = unittest.TextTestRunner(verbosity=2).run(suite)
summary = {"total": result.testsRun, "pass": result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
           "fail": len(result.failures), "errors": len(result.errors), "skip": len(result.skipped),
           "observations": module.OBSERVATIONS, "native_macos_credit": False}
output.write_text(json.dumps(summary, indent=2, sort_keys=True)+"\n")
raise SystemExit(0 if result.wasSuccessful() and result.testsRun == 12 and not result.skipped else 1)
