# Linux shipped exact identity: independent source and receiving review

SOURCE_AND_FOCUSED_RECEIVING_CLEAR, finite custody still pending. Review read only: no replay/import/format/native process/canonical/index/ref changes. Production V3 source review d7aefbf9 remains separate and immutable.

Verified63 artifact/preservation/dependency checks: all preparation/receiving receipt file entries and summary bindings, committed45b414 original dependencies, both entire original test prefixes, V3 production images and original existing manifest enrollment. Loader gains45 appended cases; Exact gains10. No original body/assertion or expectation rotated. The complete original suites/verify-change remain unrun.

Actual raw receiving, independently counted without duplicate summaries:

| Per ABI | PASS | FAIL | Exit |
|---|---:|---:|---:|
| V2 controlled exact/legacy lifecycle |30|25|1|
| V3 same controlled cases |55|0|0|
| Genuine original canonical route pair |0|2|1|
| V3 genuine FS (original pair +6) |8|0|0|

These exact counts hold on LuaJIT and Lua5.4. The first attempted original-pair run failed before tests because the private runner's boolean/loadfile precedence was wrong. Its raws remain retained and supply no source-baseline evidence. The corrected run changes only two parentheses; inverse reconstructs the original runner exactly. Corrected raw failure is the original assertion at test_ergopti_extension_hotstrings.lua:483, for both absolute/relative real shipped routes. V3 uses the same whole original fixture bodies and passes both, including their later real selection/configuration assertions. No predicate/return replacement is used to make them pass.

The25 controlled causal failures are24 handwritten stat-ordinal1-4 x subject/fdinfo close x false/nil/throw cases plus the metadata getter case. V2 yields an outer true after the nested uncertain close; V3 refuses. The same originals additionally test successful nested cleanup, exact adjacent decimal inodes, changed repeated snapshots, constructor/no-entry refusal, legacy short circuit and malformed metadata. Actual owner/Loader constructors execute against controlled recorded filesystem ports; wrapper observations do not synthesize is_settled or weaken close ambiguity. These55 results are modeled-port software evidence, not native failure injection. Expected adjacent inode text and lifecycle statements are handwritten; no corpus is regenerated from production.

Native filesystem controls use actual current luv ports. The observation wrapper delegates every real uv.fs_open/fs_close and requires immediate uv.fs_fstat EBADF after each accepted close, before recording retirement. Both ABIs report72 acquired,72 native close calls,72 physically closed,0 refused close; no descriptor remains in the live roster. Actual Python os.stat-derived independent oracle observes shipped dev27/inode9223372036855917341/mode0600 and hash440f5c11... before the Lua runs; actual after checker requires identical full identity/mode/hash for all five files. Subject identity, regular/non-executable mode, genuine absolute/relative/CRLF aliases and distinct same-byte copies are therefore exercised without modifying/copy-up/hardlinking the foreign shipped file. Only newly owned fixture files receive links/chmod; copied bytes do not grant shipped identity.

The original native fixture source remains pinned, and private tests/production/harness before/after hashes remain identical. Main receiving snapshot covers2330 canonical read sources,13 private preparation files and exact index/HEAD45b414; corrected baseline separately preserves its full five-input/index/HEAD frame. These are actual retained-time frames, not a claim current sources can never undergo transient mutation. Native72 closure does not qualify uncertain-close liveness or loader unload while debt persists; those remain explicit source/lifecycle limits.

No vacuous source assertion or implementation-generated expectation found in this bounded proposal. Fixed descriptor counts are supplementary recorded observations; essential refusals/real independent stat oracle/EBADF/unchanged original pair prevent mirror-only positivity. Existing tests are registered at manifest49/347, with byte-exact manifest dependency preserved.

Before canonical use obtain G6 additive generic observe_regular + its original test append, and Root/G2/fixLinux exact Loader/same_file + owning fixture append grants. Preserve all V2/source-HOLD and runner-preallocation failures. Fresh final source composition and selected original suites/format/CI remain necessary; this review grants no keyboard/input, physical device, GUI, package/install or complete TODO authority.
