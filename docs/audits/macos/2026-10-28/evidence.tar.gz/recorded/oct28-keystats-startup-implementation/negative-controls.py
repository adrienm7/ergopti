from pathlib import Path
import importlib.util,os,subprocess,json,hashlib
root=Path('/workspace/ergopti-macos-native-validation');out=Path(__file__).parent/'safety-mutants';out.mkdir(exist_ok=True)
relative=Path('static/ergopti_plus/macos/modules/keystats/log_manager.lua');source=(root/relative).read_text()
mutants=[
 ('missing-ingest-fence','if _recovery ~= nil or _local_ledger_replay_pending then return false end','if _recovery ~= nil then return false end','test_replay_failures_block_both_ingest_paths_until_restart'),
 ('ignored-durable-mode-result','if not called or rc ~= sqlite3.OK then\n\t\tLogger.error(LOG, "Cannot restore the cache\'s durable commit mode; replay publication remains blocked.")','if false then\n\t\tLogger.error(LOG, "Cannot restore the cache\'s durable commit mode; replay publication remains blocked.")','test_durable_mode_refusal_retains_cleanup_and_blocks_publication'),
 ('ignored-id-publication','assert(SqliteWriter.persist_next_event_id() == true, "cannot publish the replayed event id")','SqliteWriter.persist_next_event_id()','test_metadata_refusals_never_clear_the_pending_replay'),
 ('ignored-cursor-publication', '''assert(db:exec(string.format("UPDATE meta SET value='%d' WHERE key='today_log_offset';", tonumber(cursor.offset) or 0)) == sqlite3.OK,
			"cannot publish the replayed cursor")''','''db:exec(string.format("UPDATE meta SET value='%d' WHERE key='today_log_offset';", tonumber(cursor.offset) or 0))''','test_metadata_refusals_never_clear_the_pending_replay'),
]
results=[]
def overlay(source_dir,target_dir,parts,mutated):
 target_dir.mkdir()
 for child in source_dir.iterdir():
  dest=target_dir/child.name
  if child.name==parts[0]:
   if len(parts)==1:dest.write_text(mutated)
   else:overlay(child,dest,parts[1:],mutated)
  else:dest.symlink_to(child,target_is_directory=child.is_dir())
for name,before,after,method in mutants:
 assert source.count(before)==1,name
 mutated=source.replace(before,after)
 folder=out/name;overlay(root/'static',folder,['ergopti_plus','macos','modules','keystats','log_manager.lua'],mutated)
 env=dict(os.environ,PATH='/workspace/toolchain/bin:'+os.environ['PATH'],ERGOPTI_PHYSICAL_SOURCE_ROOT=str(out/(name+'-root')))
 sparse=Path(env['ERGOPTI_PHYSICAL_SOURCE_ROOT']);sparse.mkdir();(sparse/'static').symlink_to(folder,target_is_directory=True)
 r=subprocess.run(['python3',str(root/'tools/diagnostics/keystats_startup_replay_test.py'),'StartupReplayTests.'+method],env=env,capture_output=True,text=True)
 (out/(name+'.log')).write_text(r.stdout+r.stderr)
 assert r.returncode==1 and 'AssertionError:' in r.stderr and 'Ran 1 test' in r.stderr,(name,r.returncode,r.stderr)
 results.append({'name':name,'exit':r.returncode,'method':method,'source_sha256':hashlib.sha256(mutated.encode()).hexdigest(),'log_sha256':hashlib.sha256((r.stdout+r.stderr).encode()).hexdigest()})
# Keep all other stop behavior intact; only remove the final database lifetime gate.
start=source.index('function M.stop(opts)');tail=source[start:];assert tail.count('if not recovery_settled then')==1
mutated=source[:start]+tail.replace('if not recovery_settled then','if false then');name='database-closed-before-cleanup';folder=out/name;overlay(root/'static',folder,['ergopti_plus','macos','modules','keystats','log_manager.lua'],mutated);sparse=out/(name+'-root');sparse.mkdir();(sparse/'static').symlink_to(folder,target_is_directory=True)
env=dict(os.environ,PATH='/workspace/toolchain/bin:'+os.environ['PATH'],ERGOPTI_PHYSICAL_SOURCE_ROOT=str(sparse));method='test_timer_cancel_refusal_retains_the_database_until_exact_cleanup'
r=subprocess.run(['python3',str(root/'tools/diagnostics/keystats_startup_replay_test.py'),'StartupReplayTests.'+method],env=env,capture_output=True,text=True);(out/(name+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==1 and 'AssertionError:' in r.stderr and 'Ran 1 test' in r.stderr,(r.returncode,r.stderr);results.append({'name':name,'exit':r.returncode,'method':method,'source_sha256':hashlib.sha256(mutated.encode()).hexdigest(),'log_sha256':hashlib.sha256((r.stdout+r.stderr).encode()).hexdigest()})
assert (root/relative).read_text()==source
(out/'ready.json').write_text(json.dumps({'actual_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'mutants':results,'repository_source_changed':False},indent=2)+'\n');print(json.dumps(results,indent=2))
