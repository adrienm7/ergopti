﻿; Real writer sharing proves the immutable held-source upgrade boundary.
_R7PI_HeldSourceReopenNative() {
	Root := A_Temp . "\ergopti_r7_held_source_" . PLC_CurrentProcessId() . "_" . A_TickCount
	Source := Root . "\download.tmp", Moved := Root . "\foreign-move.tmp"
	Holder := -1, Writer := -1, Strong := -1, NewWriter := -1
	try {
		DirCreate(Root)
		Holder := DllCall("kernel32\CreateFileW", "Str", Source, "UInt", 0x80000000, "UInt", 3,
			"Ptr", 0, "UInt", 1, "UInt", 0x80, "Ptr", 0, "Ptr")
		AssertTrue(Holder != -1, "CREATE_NEW must acquire the READ/shareREAD|WRITE/noDELETE source holder")
		Writer := DllCall("kernel32\CreateFileW", "Str", Source, "UInt", 0x40000000, "UInt", 1,
			"Ptr", 0, "UInt", 2, "UInt", 0x80, "Ptr", 0, "Ptr")
		AssertTrue(Writer != -1, "the actual CREATE_ALWAYS/WRITE/shareREAD sink must coexist with the source holder")
		Text := "native held source bytes`n", Count := StrPut(Text, "UTF-8") - 1
		Bytes := Buffer(Count + 1, 0)
		StrPut(Text, Bytes, "UTF-8")
		Written := 0
		AssertTrue(DllCall("kernel32\WriteFile", "Ptr", Writer, "Ptr", Bytes, "UInt", Count, "UInt*", &Written, "Ptr", 0, "Int"))
		AssertEqual(Count, Written)
		AssertTrue(DllCall("kernel32\FlushFileBuffers", "Ptr", Writer, "Int"))
		Before := FSHandleSnapshot(Holder)
		AssertTrue(Before["ok"])
		ActivePin := DllCall("kernel32\ReOpenFile", "Ptr", Holder, "UInt", 0x80000000, "UInt", 1, "UInt", 0, "Ptr")
		ActiveError := A_LastError
		if ActivePin != -1 {
			DllCall("kernel32\CloseHandle", "Ptr", ActivePin, "Int")
			throw Error("the active native writer must prevent immutable source pinning")
		}
		AssertEqual(32, ActiveError, "the actual active writer must produce ERROR_SHARING_VIOLATION")
		AssertFalse(DllCall("kernel32\DeleteFileW", "Str", Source, "Int"), "the weak holder already denies namespace deletion")
		MoveFailed := false
		try FileMove(Source, Moved, false)
		catch
			MoveFailed := true
		AssertTrue(MoveFailed, "the weak holder must deny a genuine namespace replacement")
		AssertTrue(DllCall("kernel32\CloseHandle", "Ptr", Writer, "Int"))
		Writer := -1
		Strong := DllCall("kernel32\ReOpenFile", "Ptr", Holder, "UInt", 0x80000000, "UInt", 1, "UInt", 0, "Ptr")
		ClosedWriterError := A_LastError
		AssertTrue(Strong != -1, "after the exact native writer closes, the immutable held-source upgrade must succeed; error=" . ClosedWriterError)
		After := FSHandleSnapshot(Strong)
		AssertTrue(After["ok"])
		for Key in ["volume", "index_high", "index_low", "size"]
			AssertEqual(Before[Key], After[Key], "ReOpenFile must preserve exact source " . Key)
		NewWriter := DllCall("kernel32\CreateFileW", "Str", Source, "UInt", 0x40000000, "UInt", 1,
			"Ptr", 0, "UInt", 3, "UInt", 0x80, "Ptr", 0, "Ptr")
		NewWriterError := A_LastError
		AssertEqual(-1, NewWriter, "the upgraded pin must deny every new ordinary writer")
		AssertEqual(32, NewWriterError)
		AssertFalse(DllCall("kernel32\DeleteFileW", "Str", Source, "Int"), "the upgraded pin must retain namespace ownership")
		Readback := Buffer(Count, 0), ReadCount := 0
		AssertTrue(DllCall("kernel32\ReadFile", "Ptr", Strong, "Ptr", Readback, "UInt", Count, "UInt*", &ReadCount, "Ptr", 0, "Int"))
		AssertEqual(Count, ReadCount)
		AssertEqual(Count, DllCall("ntdll\RtlCompareMemory", "Ptr", Bytes, "Ptr", Readback, "UPtr", Count, "UPtr"))
		_TestPrint("# held-source-native active_error=" . ActiveError . " closed_writer_pin=1 new_writer_error=" . NewWriterError
			. " volume=" . After["volume"] . " id_high=" . After["index_high"] . " id_low=" . After["index_low"] . " bytes=" . Count)
		AssertTrue(DllCall("kernel32\CloseHandle", "Ptr", Strong, "Int"))
		Strong := -1
		NewWriter := DllCall("kernel32\CreateFileW", "Str", Source, "UInt", 0x40000000, "UInt", 1,
			"Ptr", 0, "UInt", 3, "UInt", 0x80, "Ptr", 0, "Ptr")
		AssertTrue(NewWriter != -1, "retiring the strong pin restores write sharing while the weak identity holder remains")
	} finally {
		for Handle in [NewWriter, Strong, Writer, Holder]
			if Handle != -1
				DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int")
		if DirExist(Root)
			DirDelete(Root, true)
	}
}
Test("Config restore design: actual writer retirement admits the same held source (held-source-reopen-native)", _R7PI_HeldSourceReopenNative)
