#ifndef ERGOPTI_GROUP4_SOURCE_CHANNEL_H
#define ERGOPTI_GROUP4_SOURCE_CHANNEL_H
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stddef.h>
#include "guardian_import.h"

#define GSC_WIRE_MAGIC 0x47534331u
#define GSC_WIRE_VERSION 1u

/* Serialized scalar fields, followed by records and a UTF-16 path arena. No
   pointers are carried across processes. A ready event means data publication,
   never guardian READY or permission to close an active consumer's leases. */
typedef struct {
    uint32_t magic, version;
    uint64_t channel_id;
    uint32_t source_pid, record_count;
    uint64_t source_creation;
    uint8_t manifest_sha256[32];
    uint32_t path_units, bytes, record_capacity, path_capacity;
} GSC_Header;
typedef struct {
    uint64_t source_handle, volume, index;
    uint32_t kind, path_offset, path_units, reserved;
    uint8_t sha256[32];
} GSC_Record;

typedef enum {
    GSC_UNBOUND = 0, GSC_BOUND = 1, GSC_DATA_READY = 2,
    GSC_RETIRED = 3, GSC_RETAINED_DEBT = 4
} GSC_Phase;

typedef struct GSC_Owner GSC_Owner;

/* Parent owns the source intent before creating its suspended source task.
   Capacity is derived from that admitted receipt, not a hidden global default.
   Expected digest comes from the existing genuine install/source owner. */
GSC_Owner *GSC_Create(uint64_t channel_id, uint32_t record_capacity,
                      uint32_t path_capacity, const uint8_t manifest_sha256[32]);

/* Only the actual source task constructor may consume these inherited handles.
   The caller sets INHERIT only inside the existing explicit handle-list window.
   This does not transfer or close the parent's copies. */
int GSC_Inherited(GSC_Owner *, HANDLE *, HANDLE *, HANDLE *, HANDLE *);

/* Bound before SourceTask.start(), through the genuine staged-task borrow.
   Captures a retained exact process handle, PID/full FILETIME and its identity. */
int GSC_InheritanceUsed(const GSC_Owner *owner);
int GSC_AcquireInheritance(GSC_Owner *owner,uint64_t token);
int GSC_ReleaseInheritance(GSC_Owner *owner,uint64_t token);
uint64_t GSC_InheritanceToken(const GSC_Owner *owner);
int GSC_Bind(GSC_Owner *, HANDLE);
/* Internal fixed transfer mode; the genuine intake row owns the source. */
int GSC_BindTransferred(GSC_Owner *,HANDLE);

/* Samples kernel readiness and exact source liveness before/after a complete
   scalar snapshot; returns a private copied record/path image. The image remains
   parent-owned until retirement. Source must retain its verified deny-writer
   streams until the separate native guardian factory signals source release. */
int GSC_Poll(GSC_Owner *);
const GI_Expected *GSC_Records(const GSC_Owner *, size_t *);
HANDLE GSC_Source(const GSC_Owner *);
GSC_Phase GSC_State(const GSC_Owner *);
DWORD GSC_FirstError(const GSC_Owner *);

/* Request only. This event is never an attestation of guardian/job retirement.
   The default native factory must call it only after its actual handoff witness. */
int GSC_RequestSourceRelease(GSC_Owner *);

/* Retirement needs exact source process terminal; first close refusal retains
   the owner and is never retried. Caller retains the loaded module on debt. */
int GSC_Retire(GSC_Owner *);
/* Typed result distinguishes pending native process exit (0) from an uncertain
   close/query refusal (-1), including when an earlier admission already failed. */
int GSC_TryRetire(GSC_Owner *);
/* After the import has copied all members and requested source release: close
   the retained source process reference immediately on actual terminal. This
   permits the genuine source task's job accounting to reach zero independently
   of the daemon lifetime. No future import is allowed after this handoff. */
int GSC_DropSourceReference(GSC_Owner *);

/* Called only by the pinned immutable-stream helper in the bound source
   process. It clears inherited flags before publishing to avoid propagation
   into compiler/utility children. The producer must retain all offered native
   handles until release or actual parent death; these inputs are not a caller
   assertion that a guardian/job has retired. */
int GSC_Publish(HANDLE, HANDLE, HANDLE, HANDLE, const uint8_t[32],
                 const GI_Expected *, size_t);
int GSC_PublishIntake(uint64_t,HANDLE,HANDLE,HANDLE,HANDLE,const uint8_t[32],
                      const GI_Expected *,size_t);
#endif
