// Private execution of only the additive same-file control against physical sources.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const candidate = path.join(__dirname, 'candidate/tools/test/test-managed-ollama-protocol.cjs');
const source = fs.readFileSync(candidate, 'utf8');
const start = source.indexOf('function receivePortableFailureOutput() {');
const end = source.indexOf('\nreceivePortableFailureOutput();', start);
const file = path.join(__dirname, process.argv[2] || 'candidate', 'tools/test/test-managed-ollama-protocol.cjs');
vm.runInNewContext(source.slice(start, end) + '\nreceivePortableFailureOutput();', {
    require, fs, path, process, __filename: file, __dirname: path.dirname(file),
    assert: require('node:assert/strict'), os: require('node:os'),
    spawnSync: require('node:child_process').spawnSync
});
