"""Publish frozen group 6 preparations without executing their sources."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

DESTINATION = Path('/workspace/ergopti/docs/handovers/2026-10-10-group6')
CHECKPOINT = Path('/workspace/scratch/group6-restored-next-slices-20261010')
DESTINATION.mkdir(exist_ok=False)


def sha(data):
    return hashlib.sha256(data).hexdigest()


archives = {
    'original-preparations.tar.gz': (
        CHECKPOINT / 'private-preparations-and-receiving.tar.gz',
        '507be224c1cfe686148b53e216de44abfc6d5814cb69ff93465e59742ecc3281',
    ),
    'brew-capability-r3.tar.gz': (
        CHECKPOINT / 'brew-capability-r3-and-receiving.tar.gz',
        '350b39cb56880ff4c72037af443cc7b9436b6a0385c93a0087571a6024821751',
    ),
    'followup-source-preparations.tar.gz': (
        CHECKPOINT / 'followup-preparations-and-receipts.tar.gz',
        'f682122fc6ca2a132c50ba16e19db9dc2425119cfbb1de5b088bf65b76792c6d',
    ),
    'receiving-source-preparations.tar.gz': (
        Path('/tmp/group6-receiving-followup-preparations.tar.gz'),
        '691e966ea11fcbc07cb19acaf5599f8e3dfd9eb34244794deef2f95ae441efdb',
    ),
}
for name, (source, expected) in archives.items():
    data = source.read_bytes()
    if sha(data) != expected:
        raise RuntimeError('Frozen source archive identity changed')
    (DESTINATION / name).write_bytes(data)

root = Path('/workspace/scratch/group6-managed-ollama-migration-preparation62/revision6-canonical-owned-root')
members = {}
for source in sorted(root.rglob('*')):
    if source.is_symlink():
        raise RuntimeError('Preparation aliases are refused')
    if source.is_file():
        members['catalogue-r6/' + source.relative_to(root).as_posix()] = source.read_bytes()
receiving = Path('/tmp/group6-catalogue-alias-receiving-QyEwOI')
for name in ['RESULTS.json', 'before-alias.json', 'after-alias.json', 'after-ordinary.json']:
    members['root-receiving/' + name] = (receiving / name).read_bytes()
members['receipts/catalogue-r6-review.json'] = Path('/tmp/group6-review-resume-20261010/OLLAMA-CATALOGUE-R6-TEST-ALIAS-SOURCE-AND-SAVED-RECEIVING-ACK.json').read_bytes()
members['receipts/final-local-gates.json'] = (CHECKPOINT / 'CATALOGUE-R6-FINAL-GATES.json').read_bytes()
members['snapshot-generator.py'] = Path(__file__).read_bytes()
for name, data in members.items():
    data.decode('utf-8')
    if b'\r' in data or len(data) > 2 * 1024 * 1024:
        raise RuntimeError('Only bounded LF text is admitted')
manifest = {
    'version': 1,
    'members': {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(members.items())},
    'native_runtime_sha256': 'a913d36ac05f31d6b8b8158c8f40c320b2804ed303677cf662009e741ef176e6',
    'limits': ['R6 supersedes only the R5 test temporary-root bookkeeping', 'All test bodies and assertions remain unchanged', 'Actual Linux CLI/filesystem receiving; Darwin admission is modeled', 'Native macOS and full migration remain unqualified', 'Snapshot creation executes no prepared source'],
}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
destination = DESTINATION / 'catalogue-r6-receiving.tar.gz'
with destination.open('xb') as output:
    with gzip.GzipFile(fileobj=output, filename='', mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o600
                entry.mtime = entry.uid = entry.gid = 0
                archive.addfile(entry, io.BytesIO(data))
with tarfile.open(destination, 'r:gz') as archive:
    entries = archive.getmembers()
    assert len(entries) == len(members)
    for entry in entries:
        assert entry.isfile() and archive.extractfile(entry).read() == members[entry.name]
inventory = {}
for source in sorted(DESTINATION.glob('*.tar.gz')):
    with tarfile.open(source, 'r:gz') as archive:
        entries = archive.getmembers()
        assert all(e.isfile() and not e.name.startswith('/') and '..' not in Path(e.name).parts for e in entries)
    inventory[source.name] = {'sha256': sha(source.read_bytes()), 'bytes': source.stat().st_size, 'regular_members': len(entries)}
receipt = {
    'version': 1,
    'feature_candidate': '1576dce4a7cead68d252829a4e1c461e08e7130f',
    'dev_at_snapshot': '591d59a942780465bca95956dc3cc9b2e960fa9e',
    'archives': inventory,
    'source_execution_during_snapshot': 0,
    'todo_removed': [],
    'limits': ['Historical locators are provenance, not live authority', 'Never apply a saved patch before checking actual preimages and ownership', 'Superseded revisions are preserved as evidence only', 'An archived patch is not integrated or native-qualified functionality'],
}
(DESTINATION / 'manifest.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
