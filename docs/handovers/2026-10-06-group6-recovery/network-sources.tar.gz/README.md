# Group 6 Linux prepared networking recovery

This finite source archive preserves reviewed prepared-header, live Boolean-to-owned queue, body cancellation/retirement follow-up, separate output-hop composition and native fixture335 work. It is a recovery handover, not an integrated feature or a completed TODO62 claim. Root owns production application, merges, validation registration and CI. The site is outside this work.

## Exact statuses

| Cohort | LuaJIT | Lua5.4 | Scope |
| --- | --- | --- | --- |
| Prepared queue candidate | 34 passed, 0 failed | 34 passed, 0 failed | Immutable309b ordinary composition |
| Genuine original producer causal controls | 6 passed, 17 failed | 6 passed, 17 failed | New pure11 API absent and unexecuted |
| Preserved native owner/auth/forwarding | 528 passed, 0 failed | 525 passed, 0 failed | Three FFI cases genuinely unregistered on Lua5.4 |
| Actual preflight candidate | 25 passed, exit0 | Unexecuted | Real LuaJIT, unchanged sole guardian |
| Actual body candidate | 7 passed, 7 failed, exit1 | Unexecuted | All14 executed; seven failures remain visible |
| Body follow-up | Unexecuted | Unexecuted | Source ACK only: native11 plus coordinator3 controls |
| Output-hop prepared composition | Unexecuted | Unexecuted | Separate source composition, no ordinary runtime credit |
| Fixture335 | Unexecuted | Unexecuted | Separate bodylimit84/literal55/orphan50 future cohorts |

The first preserved LuaJIT command used the wrong working directory and produced524/4. Its failure remains in the typed ledger. Changing only cwd to the isolated driver produced528/0; all source/assertions stayed exact. The actual25/body14 guardians were physically reaped with adopted/pending/rescue0/0/0. Before24/14 fixtures and native body-pipe20 were not executed in that slot. See validation/PREPARED-MODELS.json and PREPARED-NATIVE.json; private captures are omitted and only their hashes remain. PID/birth metadata is historical observation, never authority for reattachment, signalling or cleanup.

Source review files may say UNEXECUTED because their bounded reviews preceded the recorded runs. This table and the immutable typed validation files state the actual qualification. A SOURCE ACK is never a native/installed/CI result.

## Composition and preservation

Apply source changes only after exact live preimage comparison and ownership coordination. The base prepared-queue package is superseded for live-only admission by live-queue and for protected callback proof by callback-control. Forwarding-ports migrates only genuine preparation receipts while retaining full assertion tails. Normal-registration contains additive manifest rows and canonical helper headers; its stale manifest must be rebased additively rather than replacing current upstream rows.

The ordinary final proposed native core and coordinator are the body-followup candidates; its public wrapper and shared immutable header module come from prepared-queue. The separate output-hop variant follows the same ordering and retains its own sink/cleanup logic. Body-followup keeps every original body14 predicate/assertion, adds three stronger actual close-boundary assertions, and probes before native physical close ACKs rather than inventing predecessor debt after retirement. Its narrow native descriptor-refusal receipt preserves logical revocation without claiming descriptor closure. Generic handle cancellation and failed process-signal delivery remain unchanged. All body follow-up execution is still UNEXECUTED.

The original failing body14 source is preserved for same-producer temporal comparison, along with a transparent fixed-scalar diagnostic. Do not overwrite it, retarget public tests to the raw engine, weaken assertions, infer absence from nil/error, or retry a consumed descriptor/PID/PGID. Fixture335 preserves exact-control reaping receipts and executes the original final reaping oracle without reusing numerical authority; the CLI fixture owns its own subreaper.

Every included source, original preimage, delta, manifest and control is bound in PAYLOAD-MANIFEST.json. The original source manifests remain byte-identical. Their independent assertion corpora are copied, never regenerated. Source ACK summaries are bounded review evidence only. Original authoring helpers are inert historical sources; inspect them before any reuse and never run them against the live tree.

## Reconstruct and qualify

The admitted ordinary cohort was the literal static/ergopti_plus Git archive of471e80b0b1572d589b67a434c07bbd7e0646cac2 plus canonical linux_native_runtime.json8a80607d9cc0d50cb710cd9b31a1bacd799961da6dd1b431804fc2ca65996f9f. The exact catalog is included. Thousands-file runtime/dependency stages and inventories are omitted; qualification input/admission digests bind their original identities but do not by themselves reconstruct or admit a replacement tree. Reconstruct a fresh isolated archive, reject symlinks/special files, overlay only the separately bound sources in the documented order, then write and verify a complete new file/kind/hash inventory before any execution. Current root code/packages require a new final-source cohort; these old-source results cannot qualify them automatically.

qualification/ORIGINAL-QUALIFICATION-PLAN.md preserves the prior commands; BODY-MODEL-COMMANDS.json preserves exact proposed commands. Relocate their stage/capture paths deliberately after reconstructing the admitted source sets. Capture stdout/stderr privately, take command exit immediately, and retain complete typed result/birth/closure receipts. Run only in a root-granted exclusive local slot, sequentially across LuaJIT and Lua5.4. Initialize the maintained environment and actual ABI-specific LUA_CPATH; use the isolated driver cwd. No JS/native overlap is allowed.

For new body follow-up: candidate14 models on both ABIs, genuine producer-before causals, unchanged34 and528/525 preservation, then actual candidate preflight25/body14. Stop on the first unexpected candidate failure. Only after success compare the original body fixture on that same corrected producer separately from the corrected fixture on original producer. Never guess expected-before outcome counts. The existing sole guardian and admitted native-launch exact-child wrapper own25/14; keep full stdout/stderr and actual parent/PIDbirth/physical closure receipts, with no competing reaper or outer hard kill. Native335 and body-pipe20 require separate slots; run the CLI orphan fixture directly because it already owns its reaper.

## Archive contents and limits

GENERATE.py reads only the pinned finite INPUTS.json allowlist. It verifies every source manifest/artifact before copying, emits a complete payload hash inventory and deterministic source tar.gz, and never imports a producer, executes authoring helpers, tests, contacts networks or touches main/index/refs. Re-running it requires original source/review folders or an explicitly reconstructed source packet; it refuses an existing output target.

There are no private logs, environment files, keys, installed binaries, package closures or thousands-source stages in this archive. Archive generation/byte admission is source work, not test qualification. All remaining caller/installer/owned serve/pull/ETag/archive continuation/enterprise auth/trust/WPAD/platform acceptance must retain their separate TODO62 scopes and validations. This packet provides no general enterprise availability or Windows/macOS qualification claim.
