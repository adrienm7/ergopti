"""Compare actual shared parsers/converters and native Compose on registry data."""

import argparse
import ctypes
import ctypes.util
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def require(value, message):
    """Reject a failed observation even when Python optimization is enabled."""
    if not value:
        raise AssertionError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def run(command, root):
    done = subprocess.run(command, cwd=root, capture_output=True, timeout=90)
    require(done.returncode == 0, (command, done.stderr.decode(errors="replace")))
    return done.stdout


class NativeCompose:
    """Actual libxkbcommon Compose API; no evdev, desktop or app is acquired."""

    def __init__(self):
        self.library = ctypes.util.find_library("xkbcommon")
        require(self.library, "libxkbcommon missing")
        self.lib = ctypes.CDLL(self.library)
        declarations = {
            "xkb_context_new": (ctypes.c_void_p, [ctypes.c_int]),
            "xkb_context_unref": (None, [ctypes.c_void_p]),
            "xkb_compose_table_new_from_buffer": (
                ctypes.c_void_p,
                [
                    ctypes.c_void_p,
                    ctypes.c_char_p,
                    ctypes.c_size_t,
                    ctypes.c_char_p,
                    ctypes.c_int,
                    ctypes.c_int,
                ],
            ),
            "xkb_compose_table_unref": (None, [ctypes.c_void_p]),
            "xkb_compose_state_new": (ctypes.c_void_p, [ctypes.c_void_p, ctypes.c_int]),
            "xkb_compose_state_unref": (None, [ctypes.c_void_p]),
            "xkb_compose_state_reset": (None, [ctypes.c_void_p]),
            "xkb_compose_state_feed": (
                ctypes.c_int,
                [ctypes.c_void_p, ctypes.c_uint32],
            ),
            "xkb_compose_state_get_status": (ctypes.c_int, [ctypes.c_void_p]),
            "xkb_compose_state_get_utf8": (
                ctypes.c_int,
                [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t],
            ),
            "xkb_keysym_from_name": (ctypes.c_uint32, [ctypes.c_char_p, ctypes.c_int]),
        }
        for name, (result, arguments) in declarations.items():
            function = getattr(self.lib, name)
            function.restype, function.argtypes = result, arguments
        self.context = self.lib.xkb_context_new(0)
        require(self.context, "native context construction")

    def load(self, text):
        data = text.encode()
        table = self.lib.xkb_compose_table_new_from_buffer(
            self.context, data, len(data), b"C.UTF-8", 1, 0
        )
        require(table, "native Compose table compilation")
        state = self.lib.xkb_compose_state_new(table, 0)
        require(state, "native Compose state construction")
        return table, state

    def replay(self, state, sequence):
        self.lib.xkb_compose_state_reset(state)
        trail = []
        for name in sequence:
            symbol = self.lib.xkb_keysym_from_name(name.encode(), 0)
            require(symbol != 0, "unknown generated keysym " + name)
            accepted = self.lib.xkb_compose_state_feed(state, symbol)
            status = self.lib.xkb_compose_state_get_status(state)
            row = {"keysym": name, "accepted": accepted, "status": status}
            if status == 2:
                count = self.lib.xkb_compose_state_get_utf8(state, None, 0)
                buffer = ctypes.create_string_buffer(count + 1)
                got = self.lib.xkb_compose_state_get_utf8(state, buffer, len(buffer))
                require(got == count, "native Compose result size")
                row["output"] = buffer.value.decode()
            trail.append(row)
            if status in (2, 3):
                # The public protocol requires clients to reset terminal results;
                # this is a declared harness policy, not an emulated input driver.
                self.lib.xkb_compose_state_reset(state)
        return trail

    def close_table(self, table, state):
        self.lib.xkb_compose_state_unref(state)
        self.lib.xkb_compose_table_unref(table)

    def close(self):
        self.lib.xkb_context_unref(self.context)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    generation = root / "static/ergopti/linux/xkb_generation"
    sys.path.insert(0, str(generation))
    import keylayout_to_xkb as converter

    registry = root / "static/layouts/registry"
    shared = root / "static/ergopti_plus/_shared"
    entries = json.loads((registry / "index.json").read_text())["layouts"]
    physical = json.loads((shared / "modules/layouts/mac_keycodes.json").read_text())[
        "keys"
    ]
    physical_by_code = {key["code"]: key for key in physical}
    native = NativeCompose()
    results = []
    try:
        for entry in entries:
            file = registry / entry["file"]
            raw = file.read_bytes()
            model = converter.parse_keylayout(raw.decode())
            canonical = model.to_canonical()
            runtimes = []
            with tempfile.TemporaryDirectory(
                prefix="shared-deadkey-converter-"
            ) as temp:
                for runtime in ("lua", "luajit"):
                    dumped = run(
                        [
                            runtime,
                            str(
                                root
                                / "tools/test/fixtures/keylayout-canonical-dump.lua"
                            ),
                            str(shared),
                            str(file),
                        ],
                        root,
                    )
                    require(
                        json.loads(dumped) == canonical,
                        (entry["id"], runtime, "parser"),
                    )
                    out = Path(temp) / runtime
                    out.mkdir()
                    run(
                        [
                            runtime,
                            str(root / "tools/test/fixtures/keylayout-xkb-convert.lua"),
                            str(shared),
                            str(generation / "data"),
                            str(file),
                            str(shared / "modules/layouts/mac_keycodes.json"),
                            entry["keycode_convention"],
                            entry["id"],
                            "Dead-key audit",
                            str(out),
                            str(registry / "index.json"),
                            entry["id"],
                        ],
                        root,
                    )
                    runtimes.append(
                        {
                            "runtime": runtime,
                            "canonical_equal": True,
                            "symbols_sha256": digest(
                                (out / (entry["id"] + ".xkb")).read_bytes()
                            ),
                            "compose_sha256": digest(
                                (out / (entry["id"] + ".XCompose")).read_bytes()
                            ),
                        }
                    )
                keycodes = converter.load_keycodes(
                    shared / "modules/layouts/mac_keycodes.json",
                    entry["keycode_convention"],
                )
                converted = converter.convert_layout(
                    model,
                    keycodes,
                    entry["id"],
                    "Dead-key audit",
                    converter.XkbHints.from_entry(entry),
                )
                for row in runtimes:
                    require(
                        row["symbols_sha256"]
                        == digest(converted.symbols_text.encode()),
                        (entry["id"], row["runtime"], "symbols"),
                    )
                    require(
                        row["compose_sha256"]
                        == digest(converted.compose_text.encode()),
                        (entry["id"], row["runtime"], "compose"),
                    )
            require(
                not converted.conflicts and not converted.unplaced,
                (entry["id"], "converter reports conflicts/unplaced"),
            )
            native_table, native_state = native.load(converted.compose_text)
            try:
                checks = {}
                state_entries = []
                for state, prefixes in converted.dead_sequences.items():
                    for prefix in prefixes:
                        state_entries.append(
                            {
                                "state": state,
                                "sequence": prefix,
                                "trail": native.replay(native_state, prefix),
                            }
                        )
                contexts = 0
                for xkb, code in keycodes:
                    for level, modifiers in enumerate(converter.XKB_LEVELS):
                        slot = model.key_entry(model.key_map_index(modifiers), code)
                        symbol = converted.key_symbols[xkb][level]
                        if (
                            not slot
                            or slot[0] != "action"
                            or symbol == converter.NO_SYMBOL
                        ):
                            continue
                        for state, (output, next_state) in model.actions[
                            slot[1]
                        ].whens.items():
                            if state == "none" or not output or next_state:
                                continue
                            for prefix in converted.dead_sequences.get(state, []):
                                contexts += 1
                                sequence = tuple(prefix) + (symbol,)
                                identity = (sequence, output)
                                checks.setdefault(
                                    identity,
                                    {
                                        "sequence": list(sequence),
                                        "expected": output,
                                        "action": slot[1],
                                        "state": state,
                                        "key": xkb,
                                        "level": level + 1,
                                    },
                                )
                mismatches = []
                for row in checks.values():
                    trail = native.replay(native_state, row["sequence"])
                    correct = (
                        trail[-1]["status"] == 2
                        and trail[-1].get("output") == row["expected"]
                        and all(step["status"] == 1 for step in trail[:-1])
                    )
                    if not correct:
                        mismatches.append(dict(row, trail=trail))
            finally:
                native.close_table(native_table, native_state)
            ambiguity = []
            seen_native = {}
            fallback_pairs = []
            explicit_two_ascii = []
            for action_id, action in model.actions.items():
                neutral, next_neutral = action.whens.get("none", (None, None))
                for state, step in action.whens.items():
                    if step[0] and len(step[0]) == 2 and step[0].isascii():
                        explicit_two_ascii.append(
                            {"action": action_id, "state": state, "output": step[0]}
                        )
                    if (
                        state == "none"
                        or next_neutral
                        or not converter.is_printable(neutral or "")
                    ):
                        continue
                    identity = (state, neutral)
                    if identity in seen_native and seen_native[identity][1] != step:
                        ambiguity.append(
                            [state, neutral, seen_native[identity], [action_id, step]]
                        )
                    else:
                        seen_native[identity] = (action_id, step)
                for state, terminator in model.terminators.items():
                    if (
                        state not in action.whens
                        and not next_neutral
                        and neutral
                        and len(terminator) == len(neutral) == 1
                        and terminator.isascii()
                        and neutral.isascii()
                    ):
                        fallback_pairs.append(
                            {
                                "state": state,
                                "action": action_id,
                                "terminator": terminator,
                                "neutral": neutral,
                                "source_fallback_pair": terminator + neutral,
                            }
                        )
            seed = None
            if entry["id"] == "ergopti_plus":
                require(
                    physical_by_code["Backslash"]["ahk"] == "SC02B"
                    and physical_by_code["Backslash"]["mac"] == 42,
                    "trigger physical identity",
                )
                require(
                    physical_by_code["KeyE"]["ahk"] == "SC012"
                    and physical_by_code["KeyE"]["mac"] == 14,
                    "follow physical identity",
                )
                index = model.key_map_index(frozenset())
                seed = {
                    "trigger": {
                        "code": "Backslash",
                        "ahk": "SC02B",
                        "mac": 42,
                        "resolved": converter.resolve(model, index, 42).state,
                    },
                    "follow": {
                        "code": "KeyE",
                        "ahk": "SC012",
                        "mac": 14,
                        "selected_neutral": converter.resolve(model, index, 14).text,
                        "selected_pending": model.actions[
                            model.key_entry(index, 14)[1]
                        ].whens["s1_circumflex"][0],
                        "native_us_text": "e",
                        "native_text_pending": model.actions["e"].whens[
                            "s1_circumflex"
                        ][0],
                    },
                    "qualification": "Original parsed layout and physical registry relation; native US character is an explicit external control, not AHK execution. Row IDs come from original Lua rows policy separately.",
                }
            results.append(
                {
                    "id": entry["id"],
                    "platforms": entry["platforms"],
                    "source": str(file.relative_to(root)),
                    "source_sha256": digest(raw),
                    "action_count": len(model.actions),
                    "states": len(model.terminators),
                    "state_entry_sequences": state_entries,
                    "explicit_output_key_level_contexts": contexts,
                    "unique_wire_expectations": len(checks),
                    "native_mismatches": mismatches,
                    "ambiguous_neutral_text_compositions": ambiguity,
                    "two_ascii_explicit_outputs": explicit_two_ascii,
                    "two_ascii_missing_state_pairs": fallback_pairs,
                    "parser_converter_results": runtimes,
                    "windows_disabled_row_source_seed": seed,
                }
            )
    finally:
        native.close()
    result = {
        "audited_sha": "f2c3ea43542c985fb20e5f0887976f1c02525341",
        "native_library": native.library,
        "native_locale": "C.UTF-8",
        "qualification": "Original Python/Lua parsers and converters; all six registry layouts and seven converter levels. Genuine libxkbcommon Compose table/keysym/state calls in a private process. No keyboard, native Mac input source, AHK, compositor or receiving application. Missing-state pairs are source relations, not measured Mac event payloads.",
        "layouts": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent="\t") + "\n")
    print(
        json.dumps(
            {
                "layouts": len(results),
                "states": sum(x["states"] for x in results),
                "native_wire_expectations": sum(
                    x["unique_wire_expectations"] for x in results
                ),
                "native_mismatches": sum(len(x["native_mismatches"]) for x in results),
            }
        )
    )


if __name__ == "__main__":
    main()
