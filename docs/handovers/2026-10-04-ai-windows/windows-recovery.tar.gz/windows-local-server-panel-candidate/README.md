# Windows local server panel production proposal

Scratch only. No production file, runner, frozen discovery owner/policy/test or private writer has been changed by this proposal. Native unit/E2E, actual loopback HTTP, DPAPI restart, packaging and installation have not been executed. Independent source review is pending.

## Native ownership and user flows

`local_server_panel.ahk` resolves the actual shared native catalogue and shared timings. Its singleton is initialized only after both restored menu and input runtime ownership are available; construction reserves its own creator and invokes no HTTP or native timers. The panel consumes actual `LLM_Menu_ApiPrivateSourceOwner.Ports()`, `LocalServerModelsOwner` and `LocalServersOwner`. It reads no independent credentials file and creates no second HTTP or config writer.

Every accepted discovery publication requests a new coordinated menu build, including unchanged model lists. The actual backend submenu captures a new original private source and one opaque native receipt per provider. It checks the original source before and after later private entry/model/source callbacks, then bounded view/config/model/cache/rescan/controller/private native publication identities before installing its detached display snapshot. Model/address/key actions hold this particular view; a later publication or configuration change refuses retained actions. Native Apply owns the final original-source/durable-candidate publication boundary.

Paused builds render the last detached display snapshot with every action removed by the shared policy. They read no private source, start no probe and mint no receipt. Resume retries exact native retirement and requests a fresh source/view build. An unavailable private source shows an existing translated AI-unavailable reason; it is not treated as an empty valid catalogue or an answering-server verdict.

Selecting a model uses the acknowledged joint writer, which selects entry+API backend together. Editing an address/key preserves exact configured key bytes; the key prompt is masked. Address/key choices without an existing model remain native session-private pending values and are probed again without claiming durable save. Existing saved API entry picker and full chat Test remain unchanged.

The backend title uses the shared checked-row policy on a display-only snapshot, fences the actual private native publication revision and performs no discovery/source/file lookup. `menu_main` must build the submenu first, then resolve that title. Resolving full `_BackendRows` a second time would invalidate just-created model receipts.

## Exact production hooks

`integration-hooks.patch` contains minimal proposed edits against hashes in `hook-preimages.json`:

- `windows/ErgoptiPlus.ahk`: include shared discovery/menu and native models/orchestration definitions after local auth and before runtime clients.
- `windows/ui/menu/menu_llm/_index.ahk`: include the definitions-only panel after native API source definitions. Its sentinel globals execute before menu initialization.
- `windows/ui/menu/menu_llm/init.ahk`: initialize after `_LLM_Menu_RuntimeActivated := true`. This schedules the first real row capture and asynchronous search after input registration; pre-runtime detached boot rows remain explicitly unavailable.
- `windows/ui/menu/menu_llm/actions.ahk`: retry native owner and request fresh source/view capture during existing resume flow, before coordinated build service.
- `windows/ui/menu/menu_llm/menu_models.ahk`: append shared-policy panel rows to existing backend choices/port controls; resolve labels from fixed choices and the panel's pure checked provider title.
- `windows/ui/menu/menu_llm/menu_main.ahk`: stage the backend submenu before evaluating its precise title.
- `windows/infra/lifecycle.ahk`: optional suspend invalidation immediately after existing auxiliary invalidation; optional shutdown exact-debt gate before installer/logger/final ownership transfer. This gate cancels without permanently closing the owner because a later shutdown veto must preserve the live driver. False settlement refuses through existing lifecycle machinery. ShellRunner retains independent capture deletion debt and its own shutdown authority.

Lifecycle and shared menu orchestrator file ownership must be serialized by the parent before adoption. The parent exclusively owns runner registration: include panel definitions after actual private API source definitions, along with reviewed native/shared prerequisites. No runner patch or new tests are prepared here.

Native API provider publication/order and prediction/chat routing already support local providers. This proposal does not change their data or transport. The existing private actor applies backend lifecycle after joint publication. It must retain originating model/view admission until the private final RAM swap; global discovery invalidation before that point would cancel the save itself.

## Focused checks and limits

`tools/rtk/rtk.sh proxy node .../check-candidate.cjs` passed exact repository convention functions for the panel and six hooks inside ordinary lint directories, exact closure analyser+self-tests and BOM/LF for all eight AHK candidates. The standalone root entrypoint has ten pre-existing convention findings when manually passed to these functions; it is outside the ordinary lint directory scan. The checker compares all ten messages to the actual unchanged preimage and rejects any difference. No assertion was removed or weakened.

`tools/rtk/rtk.sh proxy git apply --check .../integration-hooks.patch` passed against the observed source preimages, read-only. Full selected gates remain `ahk-encoding`, `ahk-suite`, `ahk-parse`, `ahk-e2e`; shared prerequisite adoption additionally selects JS. None of these full/native gates was run by this scratch panel task.

Existing native scalar/http(s) address admission is reused. macOS has additional normalization checks for userinfo/query/fragment/host/port. A shared normalizer and independent cross-driver URL corpus are still needed before claiming full address-policy parity. The existing native duplicate-label renderer is separately owned; same/case-distinct server model rows require real native qualification. Missing-model/backend failure notices and fallback routing remain their own unresolved TODO48 integration. Actual Windows discovery/chat, private DPAPI/WAL/restart, menu callbacks, packaging and installation remain required. This panel does not complete TODO47 by itself.
