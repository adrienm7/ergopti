# Linux About/browser header fixture prerequisite

This source-only successor changes two existing isolated positive fixtures. Their real Root builder now constructs the declared active header before reaching the About or model-browser provider. The shared explicit caption policy rejects untranslated text equal to its source key; the old doubles returned that key for the unrelated brand.

The added prerequisite reads `menu.builder.active_brand` from the actual shipped English catalogue. It does not compute any subject expectation from the implementation. About retains its independent source-only label/reason fixtures; the browser retains key-identity translation for every subject key and section. All original assertion-call lines, case/describe registrations and names remain in order. The existing canonical source modifications, real renderer, callbacks, capability withdrawals and boundary negatives are unchanged. The original module restoration remains exact; catalogue reading occurs inside the existing `xpcall`, and its file is closed before JSON decoding.

No production, declaration, locale, corpus, source proof, Root file, generator, index, ref or workflow is changed. Removing the precisely recorded insertion (and restoring the original browser `get` line) recovers each entire original file byte for byte. References are captured only as source evidence.

The predecessor full Linux run was reported as 12898 passed / 56 failed. This packet is not executed. Actual targeted successor receiving is UNRUN, and full native qualification is UNRUN. Source comparison and byte/hash checks establish only source custody.
