# Independent inactive Wrap preparation review

Verdict: **BLOCKED / UNAPPROVED for integration**.
Frozen 11-path packet `wrap-controls-current.patch`, SHA256
`f962e0c00565bfc2b4a2f9872cc41d59fa0b8cd402fb04dd07cb43c1444b9c5a`,
composes on the already blocked/unapproved per-key delay packet.

The shared manifest owns five fixed management sections with existing captions
and explicit platform projection. The parity change distinguishes composition
fragments from clicked submenus, only permitting a nonempty all-separator
fragment reached exclusively through composition. No section-ID exemption is
introduced. Actual native mutation/persistence owners remain in drivers.
All 11 exact postimages and saved preimages were verified, plus BOM/LF. Main
Mac and Windows native tests preserve their complete old byte prefixes. Removing
the two actual renderer-forwarder lines from the UTF8 fixture yields its entire
old file bytes exactly; old predicates are retained. Corpora remain handwritten.

Independent focused checks reproduce Mac40/0 owning module plus9/0 original
Unicode module under portable native dependencies. These green tests omit a
newly reachable failure: the previous custom parent used `menu` instead of
canonical provider `items`, so the renderer never exposed Delete. The packet
makes Delete reachable but keeps its native callback's mutation-before-save:
`table.remove(state.custom_wrap_symbols, index)` runs before `ctx.save_prefs()`.
False, nil or truthy-string save refusal returns false and omits refresh while
leaving the custom symbol removed from live state. The already registered live
wrap-pairs getter immediately reads the changed state, altering input behavior
although persistence was refused.

An independent appended six-case probe executes the actual rendered Delete
callback, without replacing the implementation or rewriting old expectations.
It requires the original custom model and active pair after each false/nil/
truthy refusal. All40 prior cases still pass; the six independent controls fail.
`custom-delete-refusal-probe.lua` and its 40passed/6failed transcript preserve
this concrete cause. Prior green refusal cases only asserted callback receipts
and no menu refresh; they did not certify unchanged live runtime.

Before integration, fix the native publication owner: stage/durably admit the
candidate, then publish runtime, or provide an owned inverse that cannot erase
successor state. Preserve complete model/source and active wrapping on refusal;
include throwing save and retained retry/admission tests. A naive unowned
snapshot restore is insufficient if save can invoke a reentrant successor.
The wider existing global/group/add/toggle mutation-before-save behavior also
remains a TODO5 boundary; this packet does not repair it.

No root files, index, refs, generated artifacts or CI were changed by this
reviewer. Tests ran in an owned disposable /workspace copy after /tmp quota
exhaustion. Native macOS, Windows, packaging, installation and physical input
remain unexecuted. The latest immediate partial-integration instruction keeps
this inactive preparation outside the qualified head/certification delivery.
