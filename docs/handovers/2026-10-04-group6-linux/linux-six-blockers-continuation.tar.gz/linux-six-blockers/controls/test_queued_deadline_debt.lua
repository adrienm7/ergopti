local helpers = require("tests.helpers")

--- Creates the minimum libuv process/pipe surface used by HttpClient.
--- @param config table|nil
--- @return table fake, table state
local function fake_luv(config)
	local options = config or {}
	local state = { kills = {}, handles = {}, requests = {}, closes = {}, deadlines = {}, time = 0 }
	local fake = {}

	local function handle(kind)
		if options.allocation_failure_at == #state.handles + 1 then error("allocation refused") end
		local value = { kind = kind, closing = false }
		state.handles[#state.handles + 1] = value
		return value
	end

	function fake.update_time() end
	function fake.exepath() return "/independent/runtime/luajit" end
	function fake.shutdown(_, callback) callback(nil); return true end
	function fake.new_pipe() return handle("pipe") end
	function fake.new_timer()
		state.timer = handle("timer")
		return state.timer
	end
	function fake.timer_start(timer, timeout_ms, repeat_ms, callback)
		if options.timer_failure then return nil, "timer refused" end
		timer.timeout_ms = timeout_ms
		timer.repeat_ms = repeat_ms
		timer.callback = callback
		return true
	end
	function fake.timer_stop(timer) timer.stopped = true; return true end
	function fake.read_start(pipe, callback) pipe.read_callback = callback; return true end
	function fake.write(pipe, data, callback)
		pipe.written = (pipe.written or "") .. data
		state.config = pipe.written
		if callback then callback(nil) end
		return true
	end
	function fake.read_stop(pipe) pipe.read_stopped = true; return true end
	function fake.is_closing(value) return value.closing end
	function fake.close(value, callback)
		if options.close_failure and not state.allow_closes then return nil, "close refused" end
		value.closing = true
		if callback then
			state.closes[#state.closes + 1] = { handle = value, callback = callback }
			if not options.defer_close then callback() end
		end
	end
	function state.ack_closes()
		for _, receipt in ipairs(state.closes) do
			if not receipt.acknowledged then
				receipt.acknowledged = true
				receipt.callback()
			end
		end
	end
	function fake.kill(pid, signal)
		state.kills[#state.kills + 1] = { pid = pid, signal = signal }
		if options.kill_missing then return nil, "ESRCH: no such process", "ESRCH" end
		if options.kill_failure and not state.allow_kills then return nil, "EPERM: operation not permitted", "EPERM" end
		return true
	end
	function fake.spawn(command, options, callback)
		if config and config.spawn_failure then return nil, "EACCES", "permission denied" end
		local pid = 4320 + #state.requests + 1
		state.command = command
		state.options = options
		state.exit_callback = callback
		state.process = handle("process")
		state.requests[#state.requests + 1] = {
			options = options,
			exit_callback = callback,
			process = state.process,
			pid = pid,
		}
		return state.process, pid
	end

	function state.stdout(chunk) state.options.stdio[2].read_callback(nil, chunk) end
	function state.stderr(chunk) state.options.stdio[3].read_callback(nil, chunk) end
	function state.exit(code, signal) state.exit_callback(code or 0, signal or 0) end
	function state.complete(code)
		state.stdout(nil)
		state.stderr(nil)
		state.exit(code or 0)
	end
	function state.complete_request(index, stdout_text, code)
		local request = assert(state.requests[index], "unknown fake request")
		if stdout_text ~= nil then request.options.stdio[2].read_callback(nil, stdout_text) end
		request.options.stdio[2].read_callback(nil, nil)
		request.options.stdio[3].read_callback(nil, nil)
		request.exit_callback(code or 0, 0)
	end
	return fake, state
end


local root = assert(os.getenv("ERGOPTI_SIX_STAGE"))
local Json = require("json")

--- Provides independent timer events and close acknowledgements to real owners.
--- @param state table
--- @param config table
--- @return function
local function deadline_port(state, config)
 return function(deadline, callback)
  local item = { deadline = deadline, callback = callback, settled = false, listeners = {}, closes = 0, index = #state.deadlines + 1 }
  local token = { started = config.refuse_deadline_arm_index ~= item.index }
  function token:is_settled() return item.settled end
  function token:on_settled(listener)
   if item.settled then listener() else item.listeners[#item.listeners + 1] = listener end
   return true
  end
  function item.ack()
   if item.settled then return end
   item.settled = true
   for _, listener in ipairs(item.listeners) do listener() end
  end
  function token:cancel()
   item.closes = item.closes + 1
   if state.refuse_deadline_close or state.refuse_deadline_index == item.index then return false end
   item.closing = true
   if not config.defer_deadline_close and config.defer_deadline_index ~= item.index then item.ack() end
   return true
  end
  function item.fire()
   if item.fired or item.closing then return end
   item.fired = true
   callback()
   token:cancel()
  end
  item.token = token
  state.deadlines[#state.deadlines + 1] = item
  return token
 end
end

--- Loads the actual public wrapper, core and shared policy with native ports.
--- @param config table|nil
--- @return table client, table state
local function fresh_client(config)
 config = config or {}
 local fake, state = fake_luv(config)
 local names = { "luv", "adapters.http_client", "adapters.curl_http_client", "adapters.system_proxy", "infra.proxy_policy", "infra.managed_http", "infra.monotonic", "infra.managed_http_deadline", "infra.paths" }
 local saved = {}
 for _, name in ipairs(names) do saved[name] = package.loaded[name]; package.loaded[name] = nil end
 package.loaded.luv = fake
 package.loaded["infra.monotonic"] = { now_ms = function() return state.time end }
 local policy_module = dofile(root .. "/static/ergopti_plus/_shared/lua/network/proxy_policy.lua")
 local file = assert(io.open(root .. "/static/ergopti_plus/_shared/modules/network/proxy_policy.json", "rb"))
 local data = Json.decode(file:read("*a")); file:close()
 local policy = assert(policy_module.new(data))
 package.loaded["infra.proxy_policy"] = { load = function() return policy end, environment = function() return {} end }
 package.loaded["infra.paths"] = { driver_root = function() return root .. "/static/ergopti_plus/linux" end,
  shared_root = function() return root .. "/static/ergopti_plus/_shared" end,
  shared = function(path) return assert(os.getenv("ERGOPTI_HTTP_REPOSITORY")) .. "/static/ergopti_plus/_shared/" .. path end }
 package.loaded["infra.managed_http_deadline"] = { start = deadline_port(state, config) }
 local client = dofile(root .. "/static/ergopti_plus/linux/adapters/http_client.lua")
 for _, name in ipairs(names) do package.loaded[name] = saved[name] end
 function state.fire_deadlines()
  for _, item in ipairs(state.deadlines) do
   if not item.settled and state.time >= item.deadline then item.fire() end
  end
 end
 return client, state
end

helpers.describe("queued deadline ownership: refusal and exact retry", function()
 helpers.it("keeps an expired queued timer addressable until its actual close acknowledgement", function()
  local client, state = fresh_client({ defer_close = true, defer_deadline_index = 2 })
  local results = {}
  helpers.assert_true(client.get("http://127.0.0.1:9000/models", {}, { owner = "queued-debt", timeout_ms = 5000 }, function() end))
  helpers.assert_true(client.get("http://127.0.0.1:9000/models", {}, { owner = "queued-debt", timeout_ms = 1000 }, function(result) results[#results + 1] = result end))
  state.refuse_deadline_index = 2
  state.time = 1001
  state.fire_deadlines()
  helpers.assert_eq(#results, 1)
  helpers.assert_eq(results[1].error, "timeout")
  helpers.assert_true(not state.deadlines[2].token:is_settled())
  state.complete_request(1, "late\nERGOPTI_HTTP_STATUS:200\n")
  state.ack_closes()
  helpers.assert_eq(#state.requests, 1)
  helpers.assert_eq(client.cancel("queued-debt"), false, "public cancellation must reach the precise refused queued timer")
  local refusal
  helpers.assert_eq(client.get("http://127.0.0.1:9000/models", {}, { owner = "queued-debt" }, function(value) refusal = value end), false)
  helpers.assert_eq(refusal.error, "previous request cancellation failed")
  helpers.assert_eq(#state.requests, 1)
  helpers.assert_eq(#state.deadlines, 2)
  state.refuse_deadline_index = nil
  helpers.assert_true(client.cancel("queued-debt"))
  helpers.assert_true(not state.deadlines[2].token:is_settled(), "accepted native close is still pending physical ACK")
  local refused_owned = client.get_owned("http://127.0.0.1:9000/models", {}, { owner = "queued-debt" }, function() end)
  helpers.assert_true(not refused_owned.started and refused_owned:is_settled())
  helpers.assert_eq(#state.requests, 1)
  helpers.assert_eq(#state.deadlines, 2)
  state.deadlines[2].ack()
  local successor = client.get_owned("http://127.0.0.1:9000/models", {}, { owner = "queued-debt" }, function() end)
  helpers.assert_true(successor.started)
  helpers.assert_eq(#state.requests, 2)
  state.complete_request(2, "fresh\nERGOPTI_HTTP_STATUS:200\n")
  state.ack_closes()
  helpers.assert_true(successor:is_settled())
  helpers.assert_eq(#results, 1)
 end)
end)
return helpers
