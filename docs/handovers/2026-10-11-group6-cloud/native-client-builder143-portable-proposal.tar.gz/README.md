# Native client root cleanup receiving preparation

This separate preparation leaves the received independent103 and builder136
packets unchanged. It addresses the newly reviewed independent caller cleanup
seam; it does not assert that the historical native Automation failure had this
cause.

`portable_root_replacement_test.py` is held until the parent releases the serial
portable slot. The control executes the actual frozen client's `setUpClass` and
the actual builder's build/source receipt/environment verification. Only locked
client imports, Swift compiler/signing results and the fixture Security/native
process owner are modeled. The private directories, source/staged/image bytes,
root rename, foreign replacement and cleanup observations are actual POSIX file
operations. No compiler, Security command, socket or native child is launched.

The injection moves the exact owned build root after successful modeled build,
creates a foreign directory at its original name, then lets the real environment
verification refuse the changed device/inode. The causal assertion requires the
original refusal object to propagate, the original fixture close to run once,
and the foreign marker to survive caller cleanup. The exact outer temporary
directory owner safely retires both names afterward. A red result is not yet
received; all runtime outcomes are currently **not executed**.

`prospective.patch` is a conditional source-only correction, not an applied or
validated fix. It uses the existing builder root identity to refuse a known
foreign replacement before bootstrap cleanup and teardown receipt reads. It
still attempts the original fixture close, retains the original bootstrap
exception if cleanup also fails, and requires the existing fixture/child/capture
debts to be settled before removal. It adds no process owner, settle call or
deadline. A bounded pathname check does not establish an atomic deletion claim
against concurrent replacement after admission.

The prospective edit changes `setUpClass` and `tearDownClass`. Every other
original function remains byte exact, including both original native test
methods and the original script body. The earlier independent packet's claim
that all thirteen functions outside `setUpClass` remained exact cannot apply to
this proposed teardown correction. The review JSON records precise provenance.

Required receiving after slot release: the original causal control first, then
the same control against the prospective source, ordinary owned-root successful
cleanup, physical cleanup refusal/debt retention, and exact primary precedence.
These controls cannot qualify native Darwin ownership, signing, native client
acceptance or the separate clock role. No activation is authorized by these
source-only preparations.
