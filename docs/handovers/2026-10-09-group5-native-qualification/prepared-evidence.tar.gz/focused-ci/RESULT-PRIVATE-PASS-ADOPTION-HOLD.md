# Private focused CI recognition — portable PASS, adoption HOLD

This proposal is private only. G6 exclusively owns the upcoming fastpolicy successor of test-macos-dev-qualification-deferral.cjs and its helper. Canonical and CI adoption remain HOLD until those frozen postimages are received and this independent delta is composed/reviewed. No canonical/index/ref/network/CI modification or native/compiler run occurred.

The exact previously approved two-step cohort is moved before the ACL observer, after the unique Sparkle installer and before full Swift. The original consecutive ACL→raw observer→raw upload→full Swift chain and every original wiring assertion/mutation remain intact. The new private third-file recognizer admits absence (default source) or exactly one literal approved cohort at this precise position. It rejects changed command/class/pipefail/status capture/budget/upload/condition, duplicates, and invalid positions. Only that exact validated block is removed from the existing whole-workflow no-filter scan; arbitrary filters/skips/XCTSkip remain visible to the original rejection.

The full original25-minute Swift owner, successful-summary gate, original45-minute job and all release/manual/permissions/install behavior are byte-whole. The exact single raw-upload STEP_CONDITIONS entry is the only wiring-test change. No upstream fastpolicy normalization or repair is included. Existing21 deferral control bodies/assertions/mutations/footer and all prior24 additive control bodies are byte-whole; one additional old-placement negative remains separate.

Actual authorized portable execution against16 Git-bound sparse inputs:

`bash /workspace/ergopti/tools/rtk/rtk.sh node tools/test/test-ci-pipeline-wiring.cjs`

Result EXIT0. Original21 deferral controls completed;24 independently frozen focused outcomes matched (2 accepted and22 rejected); the additional frozen former placement was rejected. All existing pipeline wiring assertions/mutations also completed. stdout/stderr and unchanged input hashes are retained. This executes Node/manual receipt and constructed Bash/Python transport controls; no Swift/native/physical or CI command runs.

Both real earlier red attempts remain immutable external predecessors: two-path no-filter failure at lease-focused-ci-two-path-774bpm9o (M f5d188424e37b33292c2e440d72306fac69376befe1dde1d68320aaebfba11d5), and first private recognition/full-adjacency failure at lease-focused-ci-third-private-v60abj5l (M ff33ede41d528d1db96f13b16e9cc1b558bde559985413a8600e3a5f253f7372). They were not overwritten or qualified as PASS.

Native/compiler/CI execution remains UNEXECUTED. Actual worker source inventory is146 total eligible methods, including the17 retained-diagnostic filesystem cases. There is no163-method claim or hardcoded native success/count gate. Actual terminal per-case completions, skips/failures/unfinished scopes and transcript must establish any later qualification; SwiftPM success/no-match alone is insufficient. Added subset duration fit inside the unchanged45-minute job is UNKNOWN. Formatting and broader gates are not executed here; final composed G6/CI sources require their own fresh checks.
