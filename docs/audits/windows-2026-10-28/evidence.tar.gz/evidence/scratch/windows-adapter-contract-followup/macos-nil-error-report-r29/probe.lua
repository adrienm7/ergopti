local root = "/workspace/ergopti-windows-r6-tests/static/ergopti_plus/macos"
local shared = "/workspace/ergopti-windows-r6-tests/static/ergopti_plus/_shared/lua"
package.path = root .. "/?.lua;" .. root .. "/?/init.lua;" .. shared .. "/?.lua;" .. shared .. "/?/init.lua;" .. root .. "/tests/stubs/?.lua;" .. package.path
require("test.runner_home").isolate()
local helpers = require("tests.helpers")
helpers.initialize_timing()
helpers.warm_timings()
local saved_it = helpers.it
local captured, captures = nil, 0
helpers.it = function(name, callback)
    if name == "a non-function callback is a no-op" then
        captured = callback
        captures = captures + 1
    end
end
local loaded, load_error = pcall(dofile, root .. "/tests/unit/modules/llm/streaming/test_callbacks_never_swallowed.lua")
helpers.it = saved_it
assert(loaded, load_error)
assert(captures == 1 and type(captured) == "function", "The exact original callback must be captured once.")
local native_loader = helpers.load_with_stubs
local calls, completions = 0, 0
local fault = arg[1] == "fault"
helpers.load_with_stubs = function(name, overrides)
    local module = native_loader(name, overrides)
    if name == "modules.llm.api_common" then
        local original = assert(module.protected_call)
        module.protected_call = function(...)
            calls = calls + 1
            local result = table.pack(original(...))
            completions = completions + 1
            if fault then error(nil, 0) end
            return table.unpack(result, 1, result.n)
        end
    end
    return module
end
local callback_ok, callback_error = pcall(captured)
helpers.load_with_stubs = native_loader
assert(calls == 2 and completions == 2, "Both actual protected_call producers must finish before observation.")
print("original_callback_ok=" .. tostring(callback_ok))
print("actual_producer_calls=" .. calls)
print("actual_producer_completions=" .. completions)
print("fault=" .. tostring(fault))
if callback_error ~= nil then print("callback_error=" .. tostring(callback_error)) end
if callback_ok == (not fault) then os.exit(0) else os.exit(1) end
