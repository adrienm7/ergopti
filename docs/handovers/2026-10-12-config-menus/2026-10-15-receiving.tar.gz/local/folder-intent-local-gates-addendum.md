# Local receiving addendum: onboarding folder target and retained edits

This records local evidence only. Complete composed gates, hosted CI and browser
receiving are recorded separately by the integration owner. No result below
qualifies an untested commit, native installed wizard or complete Group 1 scope.

## Source contexts

The first native candidate is inspection commit `dadcae0eb5d9b0db1e5605ca6d133b8d24b0472f`,
tree `d82efab0803a1049fa344ccec240155ecc614b29`. The cache URL correction is
inspection commit `e31e6820d5fbac23573fcdc45405cff53fc2d36c`, tree
`fddc20b78bec009d78b4e36f245b1f503cd2a0d4`. The second edit-retention gate
ran from `e31e6820` with three owned modified paths; its exact source hashes and
terminal status are retained in the [second gate receipt](/workspace/.ergopti-cloud/folder-intent-verify-status.json).
Inspection commits are source snapshots, not claims of publication or native
acceptance. The [source ledger](/workspace/.ergopti-cloud/folder-target-inspection.json)
records these identities and the subsequent composed snapshots.

## Completed local phases and incomplete aggregate

The [first aggregate log](/workspace/.ergopti-cloud/folder-target-first-verify.log)
records the following completed phases before interruption during macOS units.
Its partial unit output and absent aggregate completion do not count as a
completed `verify-change` run.

| Phase                         | Observed result                                                 |
| ----------------------------- | --------------------------------------------------------------- |
| Repository formatting         | PASS; 430 files already formatted                               |
| AHK encoding                  | PASS; 1,915 `.ahk` files, UTF-8 BOM and LF                      |
| AHK units and E2E             | SKIPPED; AutoHotkey v2 unavailable in this container            |
| AHK parse coverage            | SKIPPED; Ahk2Exe is Windows-only                                |
| JS                            | PASS; 426/426 checks                                            |
| macOS portable E2E            | PASS; 101/101, with one explicitly skipped driver/host scenario |
| macOS units in that aggregate | INTERRUPTED; no complete unit or aggregate verdict              |

The separate complete replays have exit 0 in the
[native phase status receipt](/workspace/.ergopti-cloud/folder-target-native-status.json):

| Complete replay | Result                             | Full log                                                                         |
| --------------- | ---------------------------------- | -------------------------------------------------------------------------------- |
| macOS Lua units | 19,827 PASS, 0 FAIL; 1,604 modules | [macOS units](/workspace/.ergopti-cloud/folder-target-test-hs-complete.log)      |
| Linux Lua units | 13,700 PASS, 0 FAIL; 521 modules   | [Linux units](/workspace/.ergopti-cloud/folder-target-test-linux-complete.log)   |
| Linux E2E       | 193/193 PASS                       | [Linux E2E](/workspace/.ergopti-cloud/folder-target-test-linux-e2e-complete.log) |

These Lua/portable E2E results exercise the registered production owners and
native-port fixtures. They do not establish Cocoa or WebView2 interaction,
GTK acceptance, installed restart, physical input, packaging or installation.

## Preserved failed full gates

The [cache correction gate](/workspace/.ergopti-cloud/folder-target-cache-verify.log)
terminated with exit 1: formatting passed, and JS passed 425/426. Its sole
failure was `managed native HTTP receives actual pipe closure and shared routing`.
The retained diagnostic reports
`test_progress_does_not_renew_an_existing_absolute_budget`, failing while entering
`with self.open("progress", timeout=0.2) as response`, before the context opens.
The aggregate excerpt explicitly omits 37 lines; it is not a full copy of the
nested Python traceback. No assertion or timeout was altered.

The [second edit-retention gate](/workspace/.ergopti-cloud/folder-intent-verify.log)
also terminated with exit 1: formatting passed, and JS passed 425/426. Its sole
failure was `managed Ollama portable admission and operation retirement`.
The collector's unchanged 60-second `spawnSync` of
`tools/test/test-native-http-clock-evidence.cjs` returned `ETIMEDOUT`; the
assertion was “The independent clock receiver controls must start.” This
occurred before the collector's subsequent Python/Lua case loop. Its mandatory
HTTP receiving check passed. The aggregate diagnostic omits 40 lines.

The second gate receipt proves all three owned source hashes remained unchanged
through its run and the previous complete page-test file remained a byte-exact
prefix. Both failed aggregates remain failures. Concurrent activity, source
identity and later passes do not establish the cause of either failure, attribute
it to historical debt or waive the failed gate.

## Unchanged controlled receiving comparisons

All streams and exit statuses below are retained. The comparisons changed no
helper, assertion, timer, timeout or count requirement.

| Receiver                    | Exact comparison                                                                                                                   | Results and scope                                                                                                                                                                                                      |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Mandatory HTTP Node owner   | Unchanged candidate before → sealed literal `6818cd94eba5966c26308f8e8dd30d0b8514023e` owner/resources → unchanged candidate after | Exit 0 → 0 → 0. Each phase receives 10 protocol/shared-policy tests, three dependency-exporter tests and three wire-fixture tests.                                                                                     |
| Managed clock and collector | Actual Git/index baseline `6818cd94e`: clock then collector → restored candidate `e31e6820`: clock then collector                  | All four exits 0. Each clock run receives 32 controls. Each collector receives those 32 clock controls, 667 Python tests across 32 suites and 375 Lua port/model controls across 12 result markers; no skipped marker. |

The [HTTP comparison receipt](/workspace/.ergopti-cloud/native-http-controlled-comparison.json)
records its sealed baseline archive digest and separate full stdout/stderr paths.
The original mandatory receiver and ten directly referenced/conditional
repository dependencies have identical hashes in the
[HTTP source comparison](/workspace/.ergopti-cloud/native-http-before-after-source-identities.json).
The three unchanged reruns did not reproduce the failed aggregate's constructor
error.

The [managed comparison receipt](/workspace/.ergopti-cloud/managed-ollama-controlled-comparison.json)
records each full stream, tested commit and exact timing. Standalone clock runs
took approximately 42.5 seconds on the literal baseline and 44.1 seconds on the
candidate. Full collectors took approximately 103.3 and 107.4 seconds,
respectively; these are whole collector durations, not their bounded nested
clock-child durations. The earlier 60-second timeout was not reproduced by
these controlled commands.

The reused private cache view was advanced from `dadcae0eb` to `e31e6820` only
through the authorized fast-forward, detached temporarily to the actual literal
baseline and restored to its private branch. Final candidate tree
`fddc20b78bec009d78b4e36f245b1f503cd2a0d4`, clean state and ignored-file listing
were preserved. No other checkout was changed for this comparison.

The [managed direct-input census](/workspace/.ergopti-cloud/managed-ollama-direct-input-source-identities.json)
records 52 identical directly declared executable/workflow/fixture inputs.
The [clock source comparison](/workspace/.ergopti-cloud/native-http-clock-broad-source-identities.json)
records 639 identical declared/broad-helper inputs across baseline, inspection
candidate and fresh Root. The wider 740-file census also observes the additive
`onboarding_delivery_fixture.lua`; that file lies outside the clock fixture's
copy roots and explicit HTTP/PAC cohort. These bounded censuses do not claim
exhaustive external-runtime identity or identical process scheduling.

The HTTP receiving uses authored protocol peers and loopback fixtures; actual
HTTPX/Hugging Face clients and Apple networking are not executed by this owner.
The managed/clock controls grant no native Go/macOS build, signing, model
exchange, SDK or official clock acceptance. Passing baseline/candidate controls
support the stated narrow boundaries and retain both failed full-gate results.

## Pending integration evidence

The integration owner must append terminal results for both composed gates,
exact tested CI commits and real-browser receiving. None of those still-active
runs is described as successful here. Installed Windows/macOS wizard acceptance,
actual native host behavior, physical input and Group 1's remaining TODO scope
stay open until their own receiving is completed.
