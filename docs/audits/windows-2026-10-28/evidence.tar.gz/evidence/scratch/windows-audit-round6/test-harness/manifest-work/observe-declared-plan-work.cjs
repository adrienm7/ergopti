const assert = require('node:assert/strict');
const { validateAhkSuiteManifest } = require('/workspace/ergopti-windows-r6-tests/tools/test/validate-ahk-suite-manifest.cjs');
const valid = '1..1\nRUNNING 1/1 - owned\nok 1 - owned\n# 1 passed, 0 failed.\n';
assert.equal(validateAhkSuiteManifest(valid).complete, true);
const source = '1..1000000000\n# 0 passed, 0 failed.\n';
const descriptor = Object.getOwnPropertyDescriptor(Map.prototype, 'get');
const original = descriptor.value;
const refusal = new Error('Observed validation work exceeds the transcript length.');
let reads = 0;
let exceeded = false;
let result;
try {
  Object.defineProperty(Map.prototype, 'get', { ...descriptor, value: function (...args) {
    reads += 1;
    if (reads > source.length) throw refusal;
    return Reflect.apply(original, this, args);
  }});
  result = validateAhkSuiteManifest(source);
} catch (error) {
  if (error !== refusal) throw error;
  exceeded = true;
} finally {
  Object.defineProperty(Map.prototype, 'get', descriptor);
}
console.log(JSON.stringify({ actual_node: process.version, transcript_characters: source.length,
  transcript_lines: source.trimEnd().split('\n').length, declared_plan: 1000000000,
  actual_map_reads: reads, input_bound_exceeded: exceeded, complete: result?.complete ?? null }));
assert.equal(exceeded, false, 'A malformed two-line transcript must not drive plan-sized validation work.');
assert.equal(result.complete, false, 'The impossible receipt must still be refused.');
