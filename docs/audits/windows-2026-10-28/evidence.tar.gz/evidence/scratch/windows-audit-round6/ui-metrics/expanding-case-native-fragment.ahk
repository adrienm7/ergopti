﻿; Private observation of original Windows scalar boundaries before UI case folding.
_R6Expanding_Native(Scalars, Id, ExpectedChars) {
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	Db := 0
	try {
		OutputDir := EnvGet("ERGOPTI_R6_EXPANDING_CASE_DIR")
		AssertTrue(OutputDir != "" && DirExist(OutputDir))
		KLW.ctx := Map()
		KLW_ResetBatch()
		Events := []
		for Scalar in Scalars
			Events.Push([Scalar, 100, Map("st", "none")])
		KLW_WalkTypingEntry(Map("timestamp", "2026-10-26 12:00:00.000",
			"app", "expanding-case.exe", "events", Events))
		App := KLW.batch["app_day"]["2026-10-26" . Chr(1) . "expanding-case.exe"]
		AssertEqual(ExpectedChars, App["chars"], "actual native scalar events conserve character count")
		Manifest := Map("2026-10-26", Map("expanding-case.exe", Map("chars", App["chars"], "time", App["time_ms"])))
		Db := _KLRShortcut_OpenFixture()
		AssertTrue(SQLite_Exec(Db, KLW_BuildBatchSql(SQLite_Q("expanding-case"), false)))
		Historical := KLR_BuildNgramsJson(Db, "2026-10-26", "2026-10-26", ["expanding-case.exe"])
		Decoded := JsonParse(Historical)
		AssertEqual(ExpectedChars, Decoded["c"].Count, "every original scalar remains a separate native character key")
		if Id == "capital-i-dot" {
			AssertTrue(Decoded["c"].Has("İ"))
			AssertEqual(1, Decoded["c"]["İ"]["c"])
			AssertEqual(1, Decoded["bg"].Count)
			AssertEqual(1, Decoded["bg"]["İa"]["c"])
		} else {
			AssertTrue(Decoded["c"].Has(Chr(0x0307)), "an independently typed combining scalar is a distinct native event")
			AssertEqual(2, Decoded["bg"].Count)
			AssertEqual(1, Decoded["bg"]["i" . Chr(0x0307)]["c"])
			AssertEqual(1, Decoded["bg"][Chr(0x0307) . "a"]["c"])
		}
		FileAppend('{"manifest":' . KL_JsonEncode(Manifest) . ',"range":{"historical":'
			. Historical . ',"today":{}}}', OutputDir . "\" . Id . ".json", "UTF-8-RAW")
		FileAppend("NATIVE_EXPANDING_CASE " . Id . " chars=" . App["chars"]
			. " native_character_keys=" . Decoded["c"].Count . " native_bigram_keys=" . Decoded["bg"].Count . "`n", "*")
	} finally {
		if Db
			SQLite_Close(Db)
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
	}
}
Test("audit: native capital I-dot character boundaries (r6-native-expanding-case)",
	_R6Expanding_Native.Bind(["İ", "a"], "capital-i-dot", 2))
Test("audit: native independent combining scalar boundaries (r6-native-expanding-case)",
	_R6Expanding_Native.Bind(["i", Chr(0x0307), "a"], "separate-combining-dot", 3))
