"""Preserve inactive source preparations and bounded receipts, without execution."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).parent
PACKETS = {
    "wpad-reason": Path("/tmp/group6-wpad-terminal-reason-591-ppeqqcqr"),
    "darwin-r3": Path("/tmp/group6-release-darwin-enrollment-ec170e2d6-r3-ci-admission"),
    "catalogue-r3": Path(
        "/workspace/scratch/group6-managed-ollama-migration-preparation62/"
        "revision3-native-typed-catalogue"
    ),
}
RECEIPTS = {
    "wpad-source-review.json": Path(
        "/tmp/group6-review-resume-20261010/WPAD-TERMINAL-REASON-591-SOURCE-ACK.json"
    ),
    "darwin-r3-source-review.json": Path(
        "/tmp/group6-review-resume-20261010/"
        "DARWIN-SELECTED-RELEASE-CI-ADMISSION-R3-SOURCE-ACK.json"
    ),
    "catalogue-r3-source-review.json": Path(
        "/tmp/group6-independent-native-typed-catalogue-r3-smo73oz5/SOURCE-ACK.json"
    ),
    "native-ec170e2-terminal.json": ROOT / "CI-MONITOR-38025197869-TERMINAL.json",
    "brew-native-report.json": Path(
        "/tmp/group6-brew-native-ec170e2-20261010-r1/CLOSED-NATIVE-REPORT.json"
    ),
    "wpad-local-gates.json": ROOT / "WPAD-SELECTED-GATES.json",
    "generator.py": Path(__file__),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(filename):
    if filename.is_symlink() or not filename.is_file():
        raise RuntimeError("Only regular owned source preparation files are accepted")
    data = filename.read_bytes()
    data.decode("utf-8")
    if b"\r" in data or len(data) > 2 * 1024 * 1024:
        raise RuntimeError("Preparation source must be bounded LF text")
    return data


members = {}
for prefix, directory in PACKETS.items():
    for filename in sorted(directory.rglob("*")):
        if filename.is_symlink():
            raise RuntimeError("Preparation aliases are refused")
        if filename.is_file():
            members[prefix + "/" + filename.relative_to(directory).as_posix()] = read_regular(
                filename
            )
for name, filename in RECEIPTS.items():
    members["receipts/" + name] = read_regular(filename)
manifest = {
    "version": 1,
    "kind": "inactive-preparations-and-bounded-receipts",
    "published_feature": "4e9f92fdc88367b087e4b15a0130d23972b6ba88",
    "members": {name: {"sha256": digest(data), "size": len(data)} for name, data in sorted(members.items())},
    "limits": [
        "Source review does not prove execution or authorize shared-file adoption",
        "Darwin R3 ownership coordination, formatting and native receiving remain pending",
        "Typed catalogue R3 receiving and adoption remain pending",
        "Full migration remains code and native qualification work",
        "No primary network or Homebrew consent failure is claimed repaired",
        "Historical source locators are provenance, not live filesystem authority",
        "No executed-image ABA or escaped-session ownership guarantee",
    ],
}
members["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
destination = ROOT / "followup-preparations-and-receipts.tar.gz"
with destination.open("wb") as output:
    with gzip.GzipFile(fileobj=output, filename="", mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o600
                entry.mtime = entry.uid = entry.gid = 0
                archive.addfile(entry, io.BytesIO(data))
with tarfile.open(destination, "r:gz") as archive:
    entries = archive.getmembers()
    if len(entries) != len(members) or any(not entry.isfile() for entry in entries):
        raise RuntimeError("Snapshot regular-member census refused")
    for entry in entries:
        if archive.extractfile(entry).read() != members[entry.name]:
            raise RuntimeError("Snapshot bytes refused")
receipt = {
    "version": 1,
    "archive": str(destination),
    "sha256": digest(destination.read_bytes()),
    "bytes": destination.stat().st_size,
    "regular_members": len(members),
    "source_execution": 0,
}
(ROOT / "FOLLOWUP-SNAPSHOT.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
