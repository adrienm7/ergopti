'use strict';

// Real Chromium DOM receiving against an immutable Git source snapshot.
// Native host bridges are explicit doubles. This does not qualify WebView2,
// Cocoa, GTK, installed persistence, restart, physical input or packaging.
// Prepare-only artifact: execute only after the source owner releases its gates.

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn, execFileSync } = require('node:child_process');
const { pathToFileURL } = require('node:url');
const { setTimeout: delay } = require('node:timers/promises');
const assert = require('node:assert/strict');

const LOCALES = ['ar', 'cs', 'da', 'de', 'en', 'es', 'fr', 'he', 'hi', 'it', 'ja', 'ko', 'nl', 'no', 'pl', 'pt', 'ru', 'sv', 'tr', 'uk', 'zh'];
const PLATFORMS = ['windows', 'macos', 'linux'];
const CURRENT = '/Volumes/Personal/B/';
const DEFAULT = '/Volumes/Default/A/';
const PICKED = '/Volumes/Picked/C/';
const RAW_TYPED = ' /Volumes/Typed/<D> & {1}/ ';
const TYPED = '/Volumes/Typed/<D> & {1}/';
const TIMEOUT_MS = 20000;
const args = process.argv.slice(2);
function option(name, fallback) {
  const position = args.indexOf(name);
  return position < 0 ? fallback : args[position + 1];
}
const repository = option('--repo', '/workspace/ergopti');
const commit = option('--commit');
const outputRoot = option('--outdir', '/workspace/.ergopti-cloud');
const executable = option('--chromium', '/usr/bin/chromium');
if (!commit || !/^[a-f0-9]{40}$/.test(commit)) {
  throw new Error('Pass --commit with the full immutable, validated commit SHA.');
}
if (typeof WebSocket !== 'function') throw new Error('Node 22+ with builtin WebSocket is required.');
if (!path.isAbsolute(repository) || !path.isAbsolute(outputRoot) || !path.isAbsolute(executable)) {
  throw new Error('Repository, output and Chromium executable must use absolute paths.');
}

class Cdp {
  constructor(socket) {
    this.socket = socket;
    this.sequence = 0;
    this.pending = new Map();
    this.events = [];
    socket.addEventListener('message', (event) => {
      const response = JSON.parse(String(event.data));
      if (!response.id) { this.events.push(response); return; }
      const retained = this.pending.get(response.id);
      if (!retained) return;
      clearTimeout(retained.timeout);
      this.pending.delete(response.id);
      if (response.error) retained.reject(new Error(JSON.stringify(response.error)));
      else retained.resolve(response.result);
    });
    socket.addEventListener('close', () => {
      for (const retained of this.pending.values()) {
        clearTimeout(retained.timeout);
        retained.reject(new Error('The owned Chromium CDP connection closed.'));
      }
      this.pending.clear();
    });
  }
  static async connect(url) {
    const socket = new WebSocket(url);
    await new Promise((resolve, reject) => {
      const deadline = setTimeout(() => reject(new Error('CDP connection timed out.')), TIMEOUT_MS);
      socket.addEventListener('open', () => { clearTimeout(deadline); resolve(); }, { once: true });
      socket.addEventListener('error', () => { clearTimeout(deadline); reject(new Error('CDP connection refused.')); }, { once: true });
    });
    return new Cdp(socket);
  }
  call(method, params = {}) {
    const id = ++this.sequence;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('CDP request timed out: ' + method));
      }, TIMEOUT_MS);
      this.pending.set(id, { resolve, reject, timeout });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }
  async evaluate(fn, ...args) {
    const reply = await this.call('Runtime.evaluate', {
      expression: '(' + fn.toString() + ')(' + args.map(value => JSON.stringify(value)).join(',') + ')',
      returnByValue: true,
      awaitPromise: true
    });
    if (reply.exceptionDetails) throw new Error('Browser evaluation failed: ' + JSON.stringify(reply.exceptionDetails));
    return reply.result.value;
  }
  close() { this.socket.close(); }
}

async function poll(probe, context, child) {
  const deadline = Date.now() + TIMEOUT_MS;
  let latest;
  while (Date.now() < deadline) {
    if (child && child.exitCode !== null) throw new Error('Chromium exited before ' + context + ': ' + child.exitCode);
    try { const result = await probe(); if (result) return result; }
    catch (error) { latest = error; }
    await delay(40);
  }
  throw new Error('Timed out while waiting for ' + context + (latest ? ': ' + latest.message : ''));
}

function bridgeBootstrap(platform) {
  return `(() => {
    window.__domReceivingMessages = [];
    window.__domReceivingErrors = [];
    window.addEventListener('error', event => window.__domReceivingErrors.push(String(event.message)));
    const retain = payload => window.__domReceivingMessages.push(JSON.parse(JSON.stringify(payload)));
    if (${JSON.stringify(platform)} === 'windows') {
      window.chrome = window.chrome || {};
      window.chrome.webview = { postMessage: payload => retain(JSON.parse(payload)) };
    } else {
      window.webkit = { messageHandlers: { hsOnboarding: { postMessage: retain } } };
      if (${JSON.stringify(platform)} === 'linux') window.__ergopti_host = 'linux';
    }
  })();`;
}

async function main() {
  const actualCommit = execFileSync('git', ['rev-parse', commit + '^{commit}'], { cwd: repository, encoding: 'utf8' }).trim();
  assert.equal(actualCommit, commit, 'the source is the requested immutable commit');
  const tree = execFileSync('git', ['rev-parse', commit + '^{tree}'], { cwd: repository, encoding: 'utf8' }).trim();
  await fsp.mkdir(outputRoot, { recursive: true });
  const runDirectory = await fsp.mkdtemp(path.join(outputRoot, 'wizard-chromium-'));
  const snapshot = path.join(runDirectory, 'source');
  const profile = path.join(runDirectory, 'owned-browser-profile');
  await fsp.mkdir(snapshot);
  await fsp.mkdir(profile);
  const runtimeDirectories = {};
  for (const name of ['cache', 'config', 'data', 'tmp']) {
    runtimeDirectories[name] = path.join(runDirectory, 'owned-runtime-' + name);
    await fsp.mkdir(runtimeDirectories[name]);
  }
  const shared = 'static/ergopti_plus/_shared';
  const sources = [
    shared + '/ui/onboarding/index.html', shared + '/ui/onboarding/script.js',
    shared + '/ui/onboarding/style.css', shared + '/ui/host_bridge.js',
    shared + '/ui/_generated/onboarding_catalogue.js',
    ...LOCALES.map(code => shared + '/data/locales/' + code + '.json')
  ];
  const archive = execFileSync('git', ['archive', '--format=tar', commit, '--', ...sources], { cwd: repository, maxBuffer: 64 * 1024 * 1024 });
  const archivePath = path.join(runDirectory, 'sealed-source.tar');
  await fsp.writeFile(archivePath, archive);
  execFileSync('tar', ['-xf', archivePath, '-C', snapshot]);
  const sourceIdentities = {};
  for (const source of sources) sourceIdentities[source] = crypto.createHash('sha256').update(await fsp.readFile(path.join(snapshot, source))).digest('hex');
  const labels = {};
  for (const code of LOCALES) labels[code] = JSON.parse((await fsp.readFile(path.join(snapshot, shared, 'data/locales', code + '.json'), 'utf8')).replace(/^\uFEFF/, ''));
  const receipt = {
    sourceCommit: commit, sourceTree: tree, sourceIdentities,
    archiveSha256: crypto.createHash('sha256').update(archive).digest('hex'),
    engine: execFileSync(executable, ['--version'], { encoding: 'utf8' }).trim(),
    startedAt: new Date().toISOString(),
    bridge: 'Explicit host-port doubles; real Chromium DOM and production shared page sources.',
    limitations: ['No native WebView2, Cocoa or GTK host execution.', 'No personal configuration, native IO, installed restart, physical input or packaging acceptance.'],
    cases: [], checksPassed: 0, verdict: 'RUNNING', cleanup: 'PENDING'
  };
  await fsp.writeFile(path.join(runDirectory, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  const stderr = fs.openSync(path.join(runDirectory, 'chromium.log'), 'wx');
  const browser = spawn(executable, [
    '--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--disable-background-networking',
    '--disable-component-update', '--disable-sync', '--disable-default-apps', '--no-first-run',
    '--no-default-browser-check', '--disable-breakpad', '--disable-crash-reporter', '--password-store=basic',
    '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', '--user-data-dir=' + profile,
    '--window-size=1100,850', 'about:blank'
  ], { stdio: ['ignore', stderr, stderr], env: Object.assign({}, process.env, {
    XDG_CACHE_HOME: runtimeDirectories.cache, XDG_CONFIG_HOME: runtimeDirectories.config,
    XDG_DATA_HOME: runtimeDirectories.data, TMPDIR: runtimeDirectories.tmp
  }) });
  fs.closeSync(stderr);
  let childError;
  browser.once('error', error => { childError = error; });
  let browserClient, pageClient, failure;
  const exit = new Promise(resolve => browser.once('exit', (code, signal) => resolve({ code, signal })));
  try {
    const debugAddress = await poll(async () => {
      if (childError) throw childError;
      const text = await fsp.readFile(path.join(profile, 'DevToolsActivePort'), 'utf8');
      const [port, route] = text.trim().split('\n');
      if (!/^\d+$/.test(port) || !route.startsWith('/devtools/browser/')) return null;
      return { http: 'http://127.0.0.1:' + port, socket: 'ws://127.0.0.1:' + port + route };
    }, 'the owned Chromium endpoint', browser);
    browserClient = await Cdp.connect(debugAddress.socket);
    const pages = await (await fetch(debugAddress.http + '/json/list')).json();
    const target = pages.find(item => item.type === 'page');
    if (!target) throw new Error('Chromium has no owned page target.');
    pageClient = await Cdp.connect(target.webSocketDebuggerUrl);
    await pageClient.call('Page.enable');
    await pageClient.call('Runtime.enable');
    const documentURL = pathToFileURL(path.join(snapshot, shared, 'ui/onboarding/index.html')).href;
    let sequence = 0, retainedBootstrap;
    function check(observed, expected, context) {
      assert.deepEqual(observed, expected, context);
      receipt.checksPassed++;
    }
    async function start(platform, extra = {}) {
      if (retainedBootstrap) await pageClient.call('Page.removeScriptToEvaluateOnNewDocument', { identifier: retainedBootstrap });
      retainedBootstrap = (await pageClient.call('Page.addScriptToEvaluateOnNewDocument', { source: bridgeBootstrap(platform) })).identifier;
      await pageClient.call('Page.navigate', { url: documentURL + '?receiving=' + (++sequence) });
      await poll(() => pageClient.evaluate(() => document.readyState === 'complete' && typeof window.initData === 'function'), 'the actual wizard document', browser);
      const ready = await pageClient.evaluate(() => window.__domReceivingMessages);
      check(ready, [{ action: 'ready' }], platform + ': actual DOM ready bridge');
      const expectedTarget = platform === 'macos' ? CURRENT : DEFAULT;
      const data = Object.assign({ platform, locale: 'en', strings: labels.en,
        locales: LOCALES.map(code => ({ code, flag: '', name: code })), config_dir: CURRENT,
        default_config_dir: DEFAULT, empty_config_dir: expectedTarget, current: {}, metrics_path: '/literal/independent/metrics'
      }, extra);
      await pageClient.evaluate(payload => { window.__domReceivingMessages.length = 0; window.initData(payload); }, data);
      return expectedTarget;
    }
    async function state() {
      return pageClient.evaluate(() => ({
        value: document.getElementById('config-input').value,
        placeholder: document.getElementById('config-input').placeholder,
        hint: document.getElementById('config-hint').textContent,
        nextDisabled: document.getElementById('btn-next').disabled,
        title: document.title,
        messages: window.__domReceivingMessages,
        errors: window.__domReceivingErrors
      }));
    }
    async function click(id) { await pageClient.evaluate(value => document.getElementById(value).click(), id); }
    async function clearMessages() { await pageClient.evaluate(() => { window.__domReceivingMessages.length = 0; }); }
    async function selectLocale(code) { await pageClient.evaluate(value => document.querySelector('[data-code="' + value + '"]').click(), code); }
    async function inputText(text) {
      await pageClient.evaluate(() => document.getElementById('config-input').focus());
      await pageClient.call('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: 2, windowsVirtualKeyCode: 65, key: 'a', code: 'KeyA' });
      await pageClient.call('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 2, windowsVirtualKeyCode: 65, key: 'a', code: 'KeyA' });
      if (text === '') {
        await pageClient.call('Input.dispatchKeyEvent', { type: 'rawKeyDown', windowsVirtualKeyCode: 8, key: 'Backspace', code: 'Backspace' });
        await pageClient.call('Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: 8, key: 'Backspace', code: 'Backspace' });
      } else await pageClient.call('Input.insertText', { text });
    }
    async function finish(expectedFolder, context) {
      let completed;
      for (let step = 0; step < 12; step++) {
        completed = (await state()).messages.find(item => item.action === 'finish');
        if (completed) break;
        await click('btn-next');
      }
      if (!completed) completed = (await state()).messages.find(item => item.action === 'finish');
      assert.ok(completed, context + ': the actual page reaches Finish');
      receipt.checksPassed++;
      check(completed.answers.config_dir, expectedFolder, context + ': exact final folder bridge payload');
      check((await state()).errors, [], context + ': no unhandled DOM error');
      return completed;
    }
    for (const platform of PLATFORMS) {
      const target = await start(platform);
      await click('btn-next');
      let observed = await state();
      check(observed.value, CURRENT, platform + ': existing custom folder');
      check(observed.placeholder, target, platform + ': exact native empty target');
      check(observed.hint, 'Personal files are loaded from this folder. Leave empty to use: ' + target, platform + ': independent English hint');
      const screenshot = await pageClient.call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
      const screenshotPath = path.join(runDirectory, platform + '-empty-target.png');
      await fsp.writeFile(screenshotPath, Buffer.from(screenshot.data, 'base64'));
      const localeObservations = [];
      for (const code of LOCALES) {
        await click('btn-back');
        await selectLocale(code);
        await pageClient.evaluate(payload => window.applyStrings(payload), { locale: code, strings: labels[code] });
        await click('btn-next');
        observed = await state();
        const template = labels[code]['onboarding.config_folder.hint'];
        assert.equal(typeof template, 'string', code + ': translated hint exists');
        receipt.checksPassed++;
        check(template.split('{1}').length - 1, 1, code + ': one canonical placeholder');
        check(observed.hint, template.replace('{1}', () => target), platform + '/' + code + ': actual translated path');
        check(observed.placeholder, target, platform + '/' + code + ': unchanged placeholder');
        check(observed.value, CURRENT, platform + '/' + code + ': unchanged field');
        localeObservations.push({ code, hint: observed.hint, placeholder: observed.placeholder });
      }
      receipt.cases.push({ platform, scenario: 'independent-empty-target-and-21-locales', target, screenshot: screenshotPath, localeObservations });
      for (const route of ['typed', 'cleared', 'picked']) {
        for (const response of ['matching', 'stale']) {
          await start(platform);
          await selectLocale('fr');
          check((await state()).messages, [{ action: 'previewLocale', locale: 'fr' }], platform + ': actual preview order');
          await clearMessages();
          await click('btn-next');
          check((await state()).messages, [{ action: 'localeSelected', locale: 'fr' }], platform + ': actual navigation order');
          await clearMessages();
          const raw = route === 'typed' ? RAW_TYPED : route === 'cleared' ? '' : PICKED;
          const final = route === 'typed' ? TYPED : raw;
          if (route === 'picked') {
            await click('config-browse');
            check((await state()).messages, [{ action: 'pickConfigDir', current: CURRENT }], platform + ': real picker request');
            await clearMessages();
            await pageClient.evaluate(value => window.setConfigDir(value), PICKED);
          } else await inputText(raw);
          check((await state()).value, raw, platform + '/' + route + ': actual input event text');
          check((await state()).messages, [], platform + '/' + route + ': no eager native read');
          await pageClient.evaluate(payload => window.applyStrings(payload), {
            locale: response === 'matching' ? 'fr' : 'en', strings: response === 'matching' ? labels.fr : labels.en
          });
          observed = await state();
          check(observed.value, raw, platform + '/' + route + '/' + response + ': retained folder intent');
          check(observed.placeholder, target, platform + ': retained empty policy');
          check(observed.title, response === 'matching' ? labels.fr['onboarding.welcome.title'] : labels.en['onboarding.welcome.title'], platform + ': accepted or stale locale');
          await click('btn-next');
          observed = await state();
          check(observed.messages, [
            { action: 'loadExistingConfig', config_dir: final, request: 1 },
            { action: 'resolveMetricsPath', config_dir: final, request: 1 }
          ], platform + ': independent folder read and metrics wire');
          check(observed.nextDisabled, true, platform + ': pending read blocks navigation');
          await clearMessages();
          await click('btn-next');
          check((await state()).messages, [], platform + ': disabled Next cannot submit Finish');
          await pageClient.evaluate(() => window.applyCurrentValues({ request: 0, values: {} }));
          check((await state()).nextDisabled, true, platform + ': stale native response cannot unlock');
          await pageClient.evaluate(() => window.applyCurrentValues({ request: 1, values: {} }));
          check((await state()).nextDisabled, false, platform + ': exact response admits pages');
          const completed = await finish(final, platform + '/' + route + '/' + response);
          receipt.cases.push({ platform, scenario: route + '-' + response + '-locale-response', raw, target, completed });
        }
      }
    }
    receipt.verdict = 'PASS';
  } catch (error) {
    failure = error;
    receipt.verdict = 'FAIL';
    receipt.failure = { message: error.message, stack: error.stack };
  } finally {
    if (pageClient) { receipt.runtimeExceptionEvents = pageClient.events.filter(event => event.method === 'Runtime.exceptionThrown'); pageClient.close(); }
    let graceful = false;
    if (browserClient) {
      try { await browserClient.call('Browser.close'); } catch (_) { /* Closing the owned engine also closes its socket. */ }
      browserClient.close();
      graceful = await Promise.race([exit.then(() => true), delay(3000).then(() => false)]);
    }
    if (!graceful && browser.exitCode === null) {
      browser.kill('SIGTERM');
      graceful = await Promise.race([exit.then(() => true), delay(3000).then(() => false)]);
    }
    if (!graceful && browser.exitCode === null) {
      browser.kill('SIGKILL');
      await Promise.race([exit, delay(3000)]);
      receipt.cleanup = 'FORCED';
      receipt.verdict = 'FAIL';
      if (!failure) failure = new Error('Owned Chromium required forced retirement.');
    } else receipt.cleanup = 'OWNED_ENGINE_RETIRED';
    if (browser.exitCode !== null || browser.signalCode !== null) {
      receipt.browserExit = await exit;
      if (receipt.browserExit.code !== 0 && receipt.browserExit.signal !== 'SIGTERM') {
        receipt.verdict = 'FAIL';
        if (!failure) failure = new Error('Chromium did not exit normally: ' + JSON.stringify(receipt.browserExit));
      }
    }
    receipt.finishedAt = new Date().toISOString();
    await fsp.writeFile(path.join(runDirectory, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
    console.log(JSON.stringify({ verdict: receipt.verdict, sourceCommit: commit, checksPassed: receipt.checksPassed, cases: receipt.cases.length, receipt: path.join(runDirectory, 'receipt.json'), cleanup: receipt.cleanup }));
  }
  if (failure) throw failure;
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
