"""Exact held CI bracket; the existing matrix/commands/budget remain selected."""
from pathlib import Path
import difflib, json, hashlib
BASE=Path(__file__).resolve().parent
REL='.github/workflows/ci-macos.yml'
before=(BASE/'preimage'/REL).read_text()
old='''              status=0
              "$ERGOPTI_NATIVE_HTTP_PYTHON" tools/diagnostics/macos_owned_process_native_test.py || status=1
              "$ERGOPTI_NATIVE_HTTP_PYTHON" static/ergopti_plus/macos/tests/support/native_http_receiving_test.py --client-only || status=1
              "$ERGOPTI_NATIVE_HTTP_PYTHON" static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py || status=1
              exit "$status"
'''
new='''              status=0
              echo "clock_expected=true" >> "$GITHUB_OUTPUT"
              clock_root="$RUNNER_TEMP/native-http-clock-${{ matrix.architecture }}-${{ github.run_id }}-${{ github.run_attempt }}"
              mkdir -m 700 "$clock_root" "$clock_root/private-cache"
              clock_status=0
              set +e
              "$ERGOPTI_NATIVE_HTTP_PYTHON" tools/diagnostics/macos_owned_process_native_test.py 2>&1 | tee "$clock_root/owned-process.log"
              owned_status=("${PIPESTATUS[@]}")
              "$ERGOPTI_NATIVE_HTTP_PYTHON" static/ergopti_plus/macos/tests/support/native_http_receiving_test.py --client-only 2>&1 | tee "$clock_root/public-native.log"
              public_status=("${PIPESTATUS[@]}")
              set -e
              node tools/ci/native_http_clock_evidence.cjs begin "${{ github.sha }}" "${{ github.run_id }}" "${{ github.run_attempt }}" "${{ matrix.architecture }}" "$clock_root/source-before.json" || clock_status=1
              set +e
              ERGOPTI_NATIVE_CLOCK_EVIDENCE="$clock_root/payload" "$ERGOPTI_NATIVE_HTTP_PYTHON" -I -B -X "pycache_prefix=$clock_root/private-cache" static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py 2>&1 | tee "$clock_root/independent-client.log"
              client_status=("${PIPESTATUS[@]}")
              set -e
              for code in "${owned_status[@]}" "${public_status[@]}" "${client_status[@]}"; do
                  if [ "$code" -ne 0 ]; then status=1; fi
              done
              node - "$clock_root/native-statuses.json" "${owned_status[@]}" "${public_status[@]}" "${client_status[@]}" <<'CLOCK_STATUS' || clock_status=1
              const fs = require('node:fs');
              const args = process.argv.slice(2);
              if (args.length !== 7 || args.slice(1).some(value => !/^(?:0|[1-9][0-9]{0,2})$/.test(value) || Number(value) > 255)) process.exit(1);
              fs.writeFileSync(args[0], JSON.stringify({schema:1, owned_process:{command:Number(args[1]),capture:Number(args[2])},public_native:{command:Number(args[3]),capture:Number(args[4])},independent_client:{command:Number(args[5]),capture:Number(args[6])}}) + '\\n', {flag:'wx',mode:0o600});
          CLOCK_STATUS
              node tools/ci/native_http_clock_evidence.cjs judge "$clock_root/source-before.json" "$clock_root/payload" "$clock_root/native-statuses.json" "${{ github.sha }}" "${{ github.run_id }}" "${{ github.run_attempt }}" "${{ matrix.architecture }}" "$clock_root/clock-verdict.json" || clock_status=1
              if [ "$clock_status" -ne 0 ]; then status=1; fi
              exit "$status"
'''
assert before.count(old)==1
source=before.replace(old,new,1)
step='      - name: Receive actual independent managed HTTP native clients\n'
step_id='        id: native_http_clock\n'
assert source.count(step)==1
source=source.replace(step,step+step_id,1)
anchor='''      - name: Qualify actual explicit curl stream ownership
'''
upload='''      - name: Retain independent native HTTP clock receiving
        if: ${{ always() && steps.native_http_clock.outputs.clock_expected == 'true' }}
        uses: actions/upload-artifact@v4
        with:
          name: native-http-clock-${{ matrix.architecture }}-${{ github.run_id }}-${{ github.run_attempt }}
          if-no-files-found: error
          path: ${{ runner.temp }}/native-http-clock-${{ matrix.architecture }}-${{ github.run_id }}-${{ github.run_attempt }}

'''
assert source.count(anchor)==1
source=source.replace(anchor,upload+anchor,1)
assert source.replace(upload+anchor,anchor,1).replace(new,old,1).replace(step+step_id,step,1)==before
(BASE/'candidate'/REL).write_text(source)
(BASE/'workflow-inverse.json').write_text(json.dumps({'qualification':'HELD_PENDING_WORKFLOW_CUSTODY_AND_NATIVE_RECEIVING','body_before':old,'body_after':new,'upload_anchor':anchor,'upload_addition':upload},indent=2)+'\n')
(BASE/'workflow-held.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),source.splitlines(keepends=True),fromfile='a/'+REL,tofile='b/'+REL)))
print(hashlib.sha256(source.encode()).hexdigest())
