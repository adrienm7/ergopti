# Settled timed-add capture: R2 portable proposal, not adopted

This isolated two-source-path successor is based on exact Dev
5f7a8467c9696b26a75de104f6329b39c181b8cb. It has no source custody
acknowledgment, canonical enrollment, or native qualification. The prior69
proposal, its source-only and portable capsules, and its original receipts
remain unchanged. FIRST_PROPOSAL_REVIEW.md records that earlier preparation,
including the blanket BaseException policy rejected by independent review.

## Existing gap, restricted observation

Current _command already captures the original command's phase/status and
primary, native owner settlement, capture closure and debt, and a closed trust
callee. The callee is read only after normal wait returns nonzero. On a timed
add, settlement occurs before existing error-file closure but its completed
capture is discarded without a category observation. This narrow preparation
reads that exact existing stderr once only after an explicit native reaped=True
acknowledgment; no process, query, clock, wait, retry, permission, or capture is
added. It exports fixed bounded category/size/truncation/callee and existing
settlement/closure/debt facts on stderr. Private bytes, byte hashes, PIDs, and
private exception attributes are neither retained nor exported. PAC stdout ABI
and original trust-outcome source remain unchanged. Unknown/localized/truncated
bytes remain unknown. A mapped interaction refusal is evidence, not a proven
cause, permission grant or successful trust installation.

The actual OwnedProcessGroup owner initializes reaped=False as an instance
field (tools/diagnostics/macos_owned_process.py:257), assigning literal True
only after closed_before_reap and successful process.wait (:312). The optional
observation does not authorize settlement; it observes this acknowledgment.
Both the conditional reaped read and publication's native-group check now sit
inside protected observer blocks, so refusal cannot bypass original capture
closure. A adversarial getter is tested rather than assumed passive. Process
ownership/settlement is modeled in these portable controls; capture files and
signals are real. This grants no Darwin trust or native acquisition credit.

## Cancellation correction requested by independent review

The first tested proposal caught every BaseException during added observation
and publication. A SIGINT/SIGTERM handler raises the existing FixtureFailure
("Native fixture cancelled"). After an otherwise successful command, blanket
suppression could return success despite that cancellation. The successor
retains a fresh non-Exception control interruption (KeyboardInterrupt,
SystemExit or other BaseException) or FixtureFailure if there was no original
primary. A capture-stage interruption is stored until original files close;
publication occurs after that closure. The exact interruption then propagates.
An existing command failure remains the exact primary; fresh observer/control
failure never replaces it. Optional technical exceptions such as OSError or
RuntimeError remain nonblocking. No new exception fields or authority exist.
For publication cancellation, the already completed native-command phase and
status remain observed as completed/status0; the trust-outcome primary is
exception and the method raises instead of returning successful output.

## Portable receipts and original preservation

All original63 receiving test bytes recover exactly by removing the additive
classes. All first proposal test/helper method bodies remain exact. Every
existing fixture function except the intentionally amended _command stays
byte-exact. The formatted inverse reconstructs the entire fixture preimage;
manifest and packet-files bind exact sources and controls. Pinned Ruff0.15.8
format --check and check pass on the two isolated candidate files.

Six new control methods against the FIRST TESTED proposal: two pass, four fail;
11 assertion/subtest failures, zero errors/skips, exit1. Real self SIGINT and
SIGTERM execute the exact AST-extracted existing main.interrupted handler in
both added observers. Other controls cover prior-primary preservation,
KeyboardInterrupt/SystemExit/BaseException, and throwing reaped reads. Those
controls establish the causal defect in that predecessor, not Dev itself.

Final R2 candidate: all75 methods pass, zero failures/errors/skips, 24.568s,
exit0. The original six observation controls against unchanged Dev remain red:
one passed method, four failed methods, one missing-helper error method,
10 assertion records, one error, zero skips, exit1. Missing-helper error is
classified honestly. Existing first69 pass receipts are preserved separately.
Tests executed serially after the parent's JS gate finished, using python -I -B.

## Missing canonical enrollment and native qualification

The live JS owner at tools/test/test-managed-ollama-protocol.cjs:302 strictly
requires63 methods. registry-activation is a separate hash-bound one-line
preparation requiring precisely75 for THIS successor, not an allowlist. It is
unexecuted and unadopted, preserving all other predicates and budgets. The
first69 and postinstall70 preparations remain separate; combining R2's12 and
postinstall's7 new tests would require an independently composed exact82 source
and count, with its own review/validation. No composition is prepared here.

Reproduce with python3 -I -B reproduce.py /workspace/ergopti --ruff
/workspace/ergopti-cloud/python/bin/ruff. It binds exact preimages/candidates,
Ruff version, predecessor fixture, and exact summaries for original red,
first-proposal cancellation red and final75 candidate. It reuses the existing
checkout support graph without copying a repository. build.py regenerates the
source candidates/patch and asserts exact original inverses; its preparation
status must not be mistaken for executed receipts. prepare_successor.py is the
one-time retained authoring transform, not the replay entry point.

Before adoption: obtain explicit held-path custody, independently review exact
source, activate the exact owned canonical count, and run canonical selected
JS/Python gates. Then qualify exact sources on both Darwin architectures and
inspect original capture/settlement facts. No post-install CA query or PAC
source-bound query callee is added. Same-WPAD CA admin presence is still absent
from official evidence. Native trust/removal, PAC/WPAD positive system TLS,
model, package/install and enterprise-device gates remain incomplete.
TODO36/62 and transversal16/38 remain open; no feature completion, release,
production guard change, or native credit is claimed.
