-- Private original-production regression: real controlled Reader/Hook/output,
-- no kernel FD, caller constructors must not replace the saved Manager policy.
local packet=assert(arg[1])
local root='/workspace/ergopti/static/ergopti_plus'
package.path=packet..'/candidate/static/ergopti_plus/linux/?.lua;'..packet..'/candidate/static/ergopti_plus/linux/?/init.lua;'
 ..packet..'/generator-context/static/ergopti_plus/linux/?.lua;'..root..'/linux/?.lua;'..root..'/linux/?/init.lua;'
 ..packet..'/candidate/static/ergopti_plus/_shared/lua/?.lua;'..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
package.path='/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v2/candidate/static/ergopti_plus/linux/?.lua;'..package.path
require('compat.utf8').install();local NativeLoop=require('luv')
local result={}
require('tests.support.input_owner_fixture').with_manager_session({public_chords=true,before_manager=function(s)
 s.bytes='[mod_combos.config.caps_lock_then_tab]\ncombo="private_unlisted"\n'
end},function(s)
 local Source=require('modules.shortcuts.key_combinations')
 local Engine=require('platform.remap.tap_hold_engine')
 local Pair=require('platform.remap.key_combination_engine')
 assert(s.owner.get_chord('caps_lock_then_tab')=='none','actual original Manager refuses the unlisted action')
 local caller=Source.new({keys={{id='caps_lock',key='caps_lock'},{id='tab',key='tab'}},
  hold_picker={modifiers={'ctrl'},layers={}},is_paused=function()return false end,
  changed=function()return true end,actions={is_assignable=function()return true end}})
 local configured=caller.engine_options({caps_lock=300,tab=300})
 result.registered=Source.buffered_settings_current(configured)
 local base=Engine.new({keys={caps_lock={tap_action='enter',hold_modifier='ctrl',time_activation_seconds=.3}},
  tap_min_ms=0,one_shot_timeout_ms=1000})
 local extra=Pair.new(base,configured,{capture_buffered_input=s.hook.capture_buffered_input,
  buffered_input_current=s.hook.buffered_input_current,buffered_input_view=s.hook.buffered_input_view,
  retire_buffered_input=s.hook.retire_buffered_input})
 local emitted={}
 assert(s.hook.set_remapper(extra,function(action,binding)emitted[#emitted+1]={action,binding};return true end))
 s.rows={};s.edge('a',58,1,1000);result.pending=#s.rows==0
 s.edge('a',15,1,1010);result.invoked=#emitted==1 and emitted[1][1]=='private_unlisted'
 s.edge('a',58,0,1011);s.edge('a',15,0,1012)
 assert(s.hook.set_remapper(nil));assert(s.broker.output_current())
 result.empty=next(s.broker.view().owners)==nil
end)
assert(require('luv')==NativeLoop)
print('CALLER_CONSTRUCTOR registered='..tostring(result.registered)..' pending='..tostring(result.pending)..' invoked='..tostring(result.invoked)..' cleaned='..tostring(result.empty))
assert(not result.registered and not result.pending and not result.invoked,'caller-selected catalogue must not receive saved public pending rights')
