"""One owned finite POSIX source round; no canonical refs or native qualification."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,tempfile
base=Path(__file__).resolve().parent
live=Path('/workspace/ergopti')
previous=Path('/workspace/ergopti-cloud/group6-native-clock-passive-evidence-proposal/runtime-source')
work=Path(tempfile.mkdtemp(prefix='clock-gate-receive-',dir=base))
root=work/'source';root.mkdir()
pins={}
for source in previous.rglob('*'):
    if not source.is_file():continue
    rel=source.relative_to(previous);actual=live/rel
    selected=actual if actual.is_file() else source
    target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(selected,target)
    pins[rel.as_posix()]={'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'basis':'actual_current_checkout' if selected==actual else 'retained_finite_input'}
relative='tools/test/test-native-http-clock-evidence.cjs'
shutil.copyfile(base/'candidate'/relative,root/relative)
resolver='tools/lib/git-bash.cjs';(root/resolver).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(live/resolver,root/resolver)
pins[resolver]={'sha256':hashlib.sha256((root/resolver).read_bytes()).hexdigest(),'basis':'actual_current_shared_resolver'}
pins[relative]={'sha256':hashlib.sha256((root/relative).read_bytes()).hexdigest(),'basis':'reviewed_isolated_candidate'}
(work/'source-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
for args in (['init','-q'],['config','user.name','Portable correction receiving'],['config','user.email','portable@example.invalid'],['add','--all'],['commit','-qm','Isolated current portable clock receiving source']):
    subprocess.run(['git','-c','core.hooksPath=/dev/null',*args],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
private=work/'private-tmp';private.mkdir(mode=0o700)
env=os.environ.copy();env['TMPDIR']=str(private);env['NODE_PATH']=str(live/'node_modules');env['PYTHONDONTWRITEBYTECODE']='1'
node=shutil.which('node');assert node
receipts=[]
for name,command in (
 ('actual_posix32',[node,str(root/relative)]),
 ('modeled_early_windows',[node,str(base/'receive-early-deferral.cjs')]),
):
 stdout=work/(name+'.stdout');stderr=work/(name+'.stderr')
 with stdout.open('wb') as out,stderr.open('wb') as err:
  result=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=err,timeout=180)
 record={'name':name,'exit':result.returncode,'stdout_sha256':hashlib.sha256(stdout.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(stderr.read_bytes()).hexdigest()}
 receipts.append(record);(work/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 assert result.returncode==0,(name,str(work))
 if name=='actual_posix32':
  names=re.findall(r'^PASS (.*)$',stdout.read_text(),re.M);assert len(names)==len(set(names))==32
  assert 'CLOCK_RECEIVER controls=32 native=false official=false' in stdout.read_text()
  record.update({'passing_unique_controls':32,'failures':0,'errors':0,'skips':0,'Windows': 'UNRUN_NATIVE'})
 else:record.update({'qualification':'MODELED_WIN32_SOURCE_ORDER_ONLY','actual_windows_native':False,'frozen_original_assertion_red':True})
 print(json.dumps(record),flush=True)
(work/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
identity=subprocess.run([node,'-e',"const fs=require('fs'),crypto=require('crypto'),s=require('./tools/lib/git-bash.cjs');console.log(JSON.stringify({nodeVersion:process.version,nodeExecPath:process.execPath,nodeSha256:crypto.createHash('sha256').update(fs.readFileSync(process.execPath)).digest('hex'),sharedResolverSha256:crypto.createHash('sha256').update(fs.readFileSync('./tools/lib/git-bash.cjs')).digest('hex'),bashExecutable:s.bashExecutable(),fixedInvocations:[['-c','frozen reviewed workflow runblock'],['-n','frozen reviewed workflow syntax via stdin']],native:false,official:false}));"],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
(work/'runtime-identity.json').write_bytes(identity.stdout)
print(json.dumps({'terminal':True,'receipts':str(work),'native_credit':False,'canonical_refs_changed':False}))
