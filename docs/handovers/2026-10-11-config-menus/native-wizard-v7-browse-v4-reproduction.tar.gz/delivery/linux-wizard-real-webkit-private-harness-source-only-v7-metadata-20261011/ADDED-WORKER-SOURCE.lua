		if mode == "locales" or mode == "recommended" then
			local oracle = assert(Json.decode(assert(read(assert(arg[4], "original oracle path missing")))))
			check(not Manager.is_visible("onboarding"), mode .. " configured startup remains hidden")
			check(Manager.show("onboarding") == true, mode .. " explicit native wizard opens")
			check(page_ready(), mode .. " genuine host data reaches native page")
			if mode == "locales" then
				local original = assert(read(target .. "/config.toml"))
				local original_locale = I18n.get_locale()
				check(evaluate("JSON.stringify(Array.from(document.querySelectorAll('#lang-list .lang-item')).map(function(row){return row.dataset.code;}))") == assert(Json.encode(oracle.locale_order)), "all original 21 ordered locale rows received")
				for _, code in ipairs(oracle.locale_order) do
					local expected = assert(oracle.locales[code])
					evaluate("document.querySelector('#lang-list .lang-item[data-code=' + " .. assert(Json.encode(code)) .. " + ']').click(); 'clicked'")
					check(wait(function()
						return evaluate("String(document.title)") == expected.document_title
							and Manager.webview_for("onboarding"):get_toplevel():get_title() == expected.native_title
					end), "original DOM and actual GTK title " .. code)
					check(evaluate("String(_selectedLocale)") == code, "actual selected locale " .. code)
					check(evaluate("String(document.getElementById('language-title').textContent)") == expected["language-title"], "original visible language heading " .. code)
					click_next("config")
					for _, id in ipairs({ "config-title", "config-desc", "config-hint", "config-browse" }) do
						check(evaluate("String(document.getElementById(" .. assert(Json.encode(id)) .. ").textContent)") == expected[id], "original visible " .. id .. " " .. code)
					end
					click_next("tap_holds")
					check(wait(function() return evaluate("String(!_configPending)") == "true" end), "locale chosen-folder read " .. code)
					for index, page in ipairs(oracle.pages) do
						check(step() == page, "locale original page order " .. code .. " " .. page)
						for _, id in ipairs({ "page-title", "page-desc", "page-question-label", "page-yes-label", "page-no-label" }) do
							check(evaluate("String(document.getElementById(" .. assert(Json.encode(id)) .. ").textContent)") == expected.pages[page][id], "original rendered " .. code .. " " .. page .. " " .. id)
						end
						evaluate("var n=document.getElementById('page-no'); n.checked=true; n.dispatchEvent(new Event('change',{bubbles:true})); 'chosen'")
						if index < #oracle.pages then click_next(oracle.pages[index + 1]) end
					end
					for _ = 1, 8 do evaluate("document.getElementById('btn-back').click(); 'clicked'") end
					check(step() == "language", "real Back returns to language " .. code)
					check(I18n.get_locale() == original_locale, "preview does not publish runtime locale " .. code)
				end
				close_native()
				check(read(target .. "/config.toml") == original, "all locale previews preserve actual config bytes")
			else
				english()
				click_next("config")
				evaluate("document.getElementById('config-input').value=" .. assert(Json.encode(target)) .. "; 'entered'")
				click_next("tap_holds")
				check(wait(function() return evaluate("String(!_configPending)") == "true" end), "recommended actual chosen-folder read acknowledged")
				evaluate("var y=document.getElementById('page-yes'); y.checked=true; y.dispatchEvent(new Event('change',{bubbles:true})); 'chosen'")
				if evaluate("String(document.getElementById('page-checklist').open)") ~= "true" then
					evaluate("document.getElementById('page-checklist-summary').click(); 'opened'")
				end
				check(evaluate("String(document.getElementById('page-checklist').open)") == "true", "actual recommended checklist expanded")
				local trigger = assert(Json.encode(oracle.recommended.visible_trigger))
				-- Genuine user change handlers redraw the checklist each time: requery,
				-- never mutate pageState, operation payloads, or native writer inputs.
				for _ = 1, 16 do
					local changed = evaluate("(function(){var spans=Array.from(document.querySelectorAll('#page-checklist .item-trigger')); var s=spans.find(function(s){return s.textContent!==" .. trigger .. " && s.closest('label').querySelector('input').checked;}); if(!s)return 'done'; var b=s.closest('label').querySelector('input'); if(b.disabled)throw Error('actual other-key checkbox locked'); b.checked=false;b.dispatchEvent(new Event('change',{bubbles:true}));return 'changed';})()")
					if changed == "done" then break end
					check(changed == "changed", "actual recommended other-key deselection")
				end
				evaluate("(function(){var s=Array.from(document.querySelectorAll('#page-checklist .item-trigger')).find(function(s){return s.textContent===" .. trigger .. ";}); if(!s)throw Error('original left Alt visible row absent');var b=s.closest('label').querySelector('input');if(b.disabled)throw Error('left Alt row locked');b.checked=true;b.dispatchEvent(new Event('change',{bubbles:true}));return 'chosen';})()")
				check(evaluate("JSON.stringify(Array.from(document.querySelectorAll('#page-checklist .item-trigger')).filter(function(s){return s.closest('label').querySelector('input').checked;}).map(function(s){return s.textContent;}))") == assert(Json.encode({ oracle.recommended.visible_trigger })), "only original left Alt leaf visibly selected")
				for index = 2, #oracle.pages do
					click_next(oracle.pages[index])
					evaluate("var n=document.getElementById('page-no');n.checked=true;n.dispatchEvent(new Event('change',{bubbles:true}));'chosen'")
				end
				check(evaluate("String(!document.getElementById('btn-next').disabled)") == "true", "recommended actual Finish admitted")
				Manager.webview_for("onboarding"):run_javascript("document.getElementById('btn-next').click()", nil, nil, nil)
				check(wait(function() return not Manager.is_visible("onboarding") end, 25), "recommended real Finish commits and retires")
				check(type(read(target .. "/tap_hold.toml")) == "string", "real recommended writer created chosen-folder TapHold file")
				check(type(read(target .. "/layers.toml")) == "string", "real recommended navigation writer created chosen-folder layer file")
				check(Paths.get_config_dir() == target, "recommended folder genuinely published")
			end
		elseif mode == "reopen" then
