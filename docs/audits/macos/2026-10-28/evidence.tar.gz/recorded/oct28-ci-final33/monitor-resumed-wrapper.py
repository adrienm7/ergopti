from pathlib import Path
import subprocess,json,datetime
s=Path('/workspace/scratch/oct28-ci-final33')
r=subprocess.run(['python3',str(s/'monitor-public-rest.py')],stdout=(s/'monitor-resumed.log').open('w'),stderr=subprocess.STDOUT)
(s/'monitor-resumed-exit.json').write_text(json.dumps({'exit_code':r.returncode,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
