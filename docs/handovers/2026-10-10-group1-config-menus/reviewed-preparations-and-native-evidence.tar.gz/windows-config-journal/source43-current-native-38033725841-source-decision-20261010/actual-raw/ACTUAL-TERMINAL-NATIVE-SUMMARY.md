# Actual Windows terminal native result

Run38033725841 / unit job114159896889 tested SHA `de96b36e8cb51bdd30aec54d7f556e1e21b307a6`, tree `a591a7b46f902f010c9df31ca9637ff4b08fc234`; both finished **failure**. Exact archived unit log was independently extracted from the unique safe ZIP member `Windows _ Unit tests/18_Run AHK test suite.txt`.

Actual partial execution: **10,962 planned; 1,954 terminal results with durations; 1,952 passed; 2 failed; 9,008 without terminal result; no terminal footer; complete=false**. There are9 explicitly excluded interactive subjects outside that plan and zero observed planned SKIP markers. Test1955 started without a result. The actual log records the unchanged **1,320,000ms watchdog** at07:39:29.9555539Z; its start is not evidence that this particular subject hung intrinsically.

The console contains one live stream and one UTF-8 physical-results-file replay; duplicated entries are not additional tests. Live failure text has replacement characters, while the physical replay preserves UTF-8. We extracted only the exact second plan through its last RUNNING line (raw17540..23422), excluding the following separately printed last duration. The unchanged pinned repository validator returns1 and reconstructs a deliberately incomplete manifest. This is explicit analysis of actual file replay, not a downloaded execution-manifest artifact or a qualification PASS. Full extraction/validator/source hashes are in the companion JSON.

## What actually passed

All11 original failing fixture subjects pass under immutable full-name matching:1842 obsolete-source manual repair;1867/1868 chords off/on;1870/1871 chords restore/clear;1893 personal external-edit refusal;1894 personal exact metadata;1898 BOM rollback;1904 first BOM header;1941/1942 pack staged cohorts. Their old1790/1815/1816/1818/1819/1840/1841/1845/1851/1888/1889 indices are historical only.

The four complete-save subjects also pass at1764/1777/1778/1781 (427.499/966.422/702.976/2949.253ms). Retired caps remain preserved until explicit cleanup. These concrete native passes do not qualify later unexecuted tests.

Guard32 subject1879 passes in719.890ms including genuine fixture/refusal/repair. Its actual measured predicate loop reports **calls32, accepted32, duration397.775ms** (12.43046875ms per complete captured source predicate). This qualifies the actual32 live guard calls, Count-getter observer refusal with zero effects, exact same-guard repair and unchanged target bytes. It does not isolate map/enumerator allocations or qualify different native owners.

Original genuine34-store capacity subject1880 passes in **238,768.561ms**: fixture498.337; **Apply127,281.460; Inspect16.951; refusal110,858.479; cleanup102.181ms**; pending verification5.894 and rollback verification2.804ms. It actually publishes and rolls back34 changed stores. The prior266,275.142ms measurement remains historical; these two runs do not establish a safe source optimization or whole-suite improvement.

## What failed or remains unexecuted

Two observed native failures remain: tray gestures source staging contract at264 (`test_tray_pause_greys_features.ahk:121`) and raw `TrayMenuSubmenuHandle` observer subject at1490 (`test_language_deferred_declared_parent.ahk:209`). The independent forward reviewer owns their bounded source-contract/test-only corrections. No renderer production relaxation follows from these results.

All9 genuine acquired-read temporal controls are **UNRUN**: recovery control/hash/port; guarded control/hash/port/exists/read_bounded/write_create_durable. None appears in the actual executed-name inventory. No native acquired-handle interleaving, foreign observer refusal or receipt repair for those9 can be inferred from guard32 success. The companion JSON lists every exact registered name and absence.

Native desktop cohorts, isolatedLLM, compiler warnings, full startup and fresh-clone startup were skipped after unit failure. Native E2E/packaging/installation qualification remains incomplete. Whole later Rootf319 has a different run_all source; this exact tested tree does not qualify it.

## Remaining receiving work

Receive the independently reviewed two native-menu test corrections, preserve all original assertions and run the final exact sources again. Keep the22-minute budget unchanged. The Windows owner must diagnose the measured guard/publication cost and establish a reviewed performance change before claiming complete native unit qualification. Count/prototype/key-index proposals remain blocked; no cache or authority shortcut is received. A diagnostic subset never replaces the full registered suite.

Finish the9 true temporal controls and remaining native startup/E2E/package/install checks on an actual Windows runner with complete receipts. These tests do not require the maintainer's physical device. Reserve physical Windows/macOS TODO steps for real wizard/menu interaction and session/install permissions absent from CI. Do not mark Group1 or transversal16/38 complete from this partial run.
