const t=""+new URL("../assets/ErgoptiPlus.KtIgsiUA.ahk",import.meta.url).href;export{t as default};
