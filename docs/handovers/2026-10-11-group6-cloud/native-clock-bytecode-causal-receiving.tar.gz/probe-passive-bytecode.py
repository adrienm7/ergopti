"""Serial actual private bytecode origin receiving; never live writes or native proof."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,tempfile,time
live=Path('/workspace/ergopti');previous=Path('/workspace/ergopti-cloud/group6-native-clock-passive-evidence-proposal/runtime-source');base=Path('/workspace/ergopti-cloud/clock-passive-bytecode-receiving');base.mkdir(exist_ok=True)
work=Path(tempfile.mkdtemp(prefix='actual-',dir=base));pins={}
paths={p.relative_to(previous).as_posix() for p in previous.rglob('*') if p.is_file()}
for branch in ('static/ergopti_plus/_shared/python','static/ergopti_plus/_shared/modules/llm','static/ergopti_plus/macos/platform','static/ergopti_plus/macos/modules/llm','static/ergopti_plus/macos/adapters'):
 for p in (live/branch).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.json','.lua'):paths.add(p.relative_to(live).as_posix())
for relative in paths:
 source=live/relative
 if not source.is_file():source=previous/relative
 pins[relative]={'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'bytes':source.stat().st_size,'source':str(source)}
(work/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
records=[]
def namespace(role):
 root=work/role/'source';root.mkdir(parents=True)
 for relative,pin in pins.items():
  target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);raw=Path(pin['source']).read_bytes();assert hashlib.sha256(raw).hexdigest()==pin['sha256'];target.write_bytes(raw)
 private=root.parent/'tmp';private.mkdir(mode=0o700)
 return root,private

def receive(role,args,expected=None):
 root,private=namespace(role);environment=os.environ.copy();environment.pop('PYTHONDONTWRITEBYTECODE',None);environment.pop('PYTHONPYCACHEPREFIX',None);environment['TMPDIR']=str(private)
 out=root.parent/'stdout';err=root.parent/'stderr';started=time.monotonic()
 with out.open('wb') as stdout,err.open('wb') as stderr:result=subprocess.run([sys.executable,*args],cwd=root,env=environment,stdout=stdout,stderr=stderr,timeout=120)
 pycs={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*.pyc')}
 platform=[name for name in pycs if name.startswith('static/ergopti_plus/macos/platform/')]
 record={'role':role,'exit':result.returncode,'seconds':round(time.monotonic()-started,3),'argv_prefix':args[:2],'platform_cache_names':platform,'all_created_pycs':pycs,'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest(),'qualification':'ACTUAL_PRIVATE_PYTHON_CACHE_EFFECTS_ONLY_NO_NATIVE'}
 records.append(record);(work/'receipts.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==0,(role,str(root.parent))
 if expected:
  text=err.read_text();assert re.search(r'Ran '+str(expected)+r' tests in',text) and '\nOK\n' in text;record.update({'tests':expected,'failures':0,'errors':0,'skips':0})
 print(json.dumps(record),flush=True)
 return record
one=receive('passive21_default',['tools/test/macos_native_http_clock_passive_receiving_controls.py'],21)
two=receive('passive21_no_bytecode',['-B','tools/test/macos_native_http_clock_passive_receiving_controls.py'],21)
if not one['platform_cache_names'] and not two['platform_cache_names']:
 for name in ('macos_source_alias_owner_test','macos_ollama_bootstrap_owner_test','macos_suspended_image_owner_test','macos_ollama_daemon_authority_test','macos_ollama_hint_metadata_test'):
  # Module import only, so no unittest/native test methods are executed. This
  # receives the legacy SourceFileLoader cache effect without a whole suite.
  code="import runpy;runpy.run_path("+repr('tools/diagnostics/'+name+'.py')+",run_name='actual_bytecode_origin_receiving');print('IMPORT_ONLY no_test_methods native=false')"
  receive('legacy_import_'+name,['-c',code])
(work/'receipts.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'terminal':True,'receipts':str(work),'new_passive21_platform_caches':one['platform_cache_names'],'native_credit':False}))
