from pathlib import Path
import hashlib,json,subprocess,re,os,sys
R=Path('/workspace/ergopti');Q=Path(__file__).resolve().parent
P=Path('/workspace/ergopti-delivery/group1-complete-resume-20261007/menu-private-peer-oct10/macos-script-action-dead-boundary-genuine-export-source-successor-20261010')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(sys.argv)==2, 'Supply a fresh outside-Root receipt directory'
out=Path(sys.argv[1]);out.mkdir(exist_ok=False);assert R not in out.parents
for name,pin in {'UNCHANGED-HOST-DEPENDENCY-PINS.json': 'b619cf6578cd087add15ad997cdf9e7ace301d2afcc853d6da34027d74bd3e8c', 'RUN-COMPLETE-REGISTERED-MAC-HOST.lua': '8bfebfcb7ecb95ab88d7c3f935e1d16b3202c2adc6c70abc4359f11097adf7de', 'EXPECTED-ACTUAL-SUBJECT-NAMES.json': '92f05b1927a4d89c4f5a2c5f236423284f8d21f095df3a0958b99c8fd6097c08'}.items():assert sha((Q/name).read_bytes())==pin
assert sha((P/'SOURCE-PROPOSAL.json').read_bytes())=='5e944ced52465ee3a5ff38cf91d3c32f3199c7a536e0c1c5be380f392576f293'
proposal=json.loads((P/'SOURCE-PROPOSAL.json').read_text())
assert sha((P/'source-only.patch').read_bytes())==proposal['patch_sha256']
for row in proposal['paths']:assert sha((R/row['path']).read_bytes())==row['post_sha256'], 'Source not actually received: '+row['path']
for row in proposal['source_pins']:
 # Full shared feature manifest may receive the independent Linux header EOF additions.
 # Its actual immutable full five-block script-control source section AND owning generated rows are checked below;
 # all active native/catalogue/locale sources retain their exact original full-file bytes.
 if row['path'].endswith('/manifest.toml'):continue
 if row['path']=='static/ergopti_plus/macos/ui/menu/menu_shortcuts.lua':continue
 assert sha((R/row['path']).read_bytes())==row['sha256'], 'Genuine original producer drift: '+row['path']
for path,pin in json.loads((Q/'UNCHANGED-HOST-DEPENDENCY-PINS.json').read_text()).items():assert sha((R/path).read_bytes())==pin
original=P/'preimages/static/ergopti_plus/macos/ui/menu/menu_shortcuts.lua'
original_pin=next(x['pre_sha256'] for x in proposal['paths'] if x['path'].endswith('/menu_shortcuts.lua'))
assert sha(original.read_bytes())==original_pin
subject_names=json.loads((Q/'EXPECTED-ACTUAL-SUBJECT-NAMES.json').read_text())
assert len(subject_names['ordered'])==24 and len(set(subject_names['ordered']))==24
assert sha((Q/'ORIGINAL-SCRIPT-CONTROL-DECLARATION.toml.txt').read_bytes())=='02484ee76cfd8e719efa34edb0163c61816ee0b45f7102037fbb2ebf4d2c82fd'
source_manifest=(R/'static/ergopti_plus/_shared/modules/features/manifest.toml').read_text()
assert source_manifest.count('[[menu.script_control_group]]')==5
assert source_manifest.count((Q/'ORIGINAL-SCRIPT-CONTROL-DECLARATION.toml.txt').read_text())==1, 'Actual owning shared source frame changed'
manifest=json.loads((R/'static/ergopti_plus/_shared/modules/menu/menu_manifest.json').read_bytes())
assert manifest['script_control_group']==[
 {'type':'toggle','id':'script_control_toggle','i18n':'menu.shortcuts.script_shortcuts_enable','checked_when':['script_control_enabled'],'category':'ScriptControl'},
 {'type':'command','id':'scope_restore','i18n':'common.restore_recommended'},
 {'type':'command','id':'scope_clear','i18n':'common.clear_to_system'},
 {'type':'---'}, {'type':'list','id':'script_control_shortcuts'}], 'Genuine canonical frame or separator changed'
paths=set(subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard','--','static/ergopti_plus','tools'],cwd=R).decode().split('\0'));paths.discard('')
for path in (R/'static/ergopti_plus').rglob('*'):
 if path.is_file() and not path.is_symlink() and ('_generated' in path.parts or path.suffix in {'.lua','.json','.toml','.ahk'}):paths.add(path.relative_to(R).as_posix())
snapshot=lambda:{p:sha((R/p).read_bytes()) for p in sorted(paths) if (R/p).is_file()}
before=snapshot();(out/'ROOT-PINS-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
results=[];interrupted=None
for mode in ['candidate','original']:
 assert snapshot()==before and sha(original.read_bytes())==original_pin
 command=['lua5.4',str(Q/'RUN-COMPLETE-REGISTERED-MAC-HOST.lua'),mode]
 log=out/(mode+'-RAW.log')
 with log.open('wb') as f:proc=subprocess.run(command,cwd=R/'static/ergopti_plus/macos',stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())
 plain=re.sub(r'\x1b\[[0-9;]*m','',log.read_bytes().decode(errors='replace'))
 def count(label):
  found=re.findall(label+r':\s*(\d+)',plain);return int(found[-1]) if found else None
 passed,failed=count('Passed tests'),count('Failed tests')
 names=re.findall(r'^  (?:ok   |FAIL )(.+?)(?: — .*)?$',plain,re.MULTILINE)
 result={'command':command,'mode':mode,'exit_code':proc.returncode,'passed':passed,'failed':failed,'modules':count('Total modules'),'executed_subject_names':names,'expected_subjects':24,'subject_inventory_exact':names==subject_names['ordered'],'load_errors':re.findall(r'! LOAD FAILURE in ([^\n]+)',plain),'case_filter_applied':'Filtering to test cases matching:' in plain,'root_inputs_unchanged':snapshot()==before,'original_preimage_before_after_exact':sha(original.read_bytes())==original_pin,'raw_sha256':sha(log.read_bytes()),'failure_subjects':re.findall(r'^\[\d+\] (.+)$',plain,re.MULTILINE)}
 result['whole_host_complete']=result['modules']==1 and passed is not None and failed is not None and passed+failed==24 and result['subject_inventory_exact'] and not result['load_errors'] and not result['case_filter_applied']
 result['ignored']=0 if result['whole_host_complete'] else None
 result['failure_family']={x:('original3' if x in subject_names['original'] else 'new21' if x in subject_names['new'] else 'unknown') for x in result['failure_subjects']}
 results.append(result);(out/(mode+'-ATTEMPT-RECEIPT.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 if not result['whole_host_complete'] or not result['root_inputs_unchanged'] or not result['original_preimage_before_after_exact']:
  interrupted={'reason':'Drift/load error/incomplete real module execution','attempt':len(results)-1};break
(out/'ROOT-PINS-AFTER.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
receipt={'results':results,'candidate_all_pass':len(results)>=1 and results[0]['whole_host_complete'] and results[0]['exit_code']==0 and results[0]['failed']==0,'original_all_pass':len(results)==2 and results[1]['whole_host_complete'] and results[1]['exit_code']==0 and results[1]['failed']==0,'expected_behavior':'Both actual24-subject cohorts pass; cleanup is observationally neutral on genuine826-entry/21locale source. No fabricated dash counterfactual.','interrupted':interrupted,'not_executed':2-len(results),'other_modules':'NOT EXECUTED','root_input_count':len(before),'root_inputs_unchanged':snapshot()==before,'original_provider_sha256':original_pin,'source_packet_sha256':proposal['patch_sha256'],'slot':'All requested attempts terminal; release immediately','limitations':'Software Mac host with existing Hammerspoon stubs; no physical Mac, whole-suite, generated census or hosted CI qualification.'}
(out/'TERMINAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
if interrupted or not receipt['candidate_all_pass'] or not receipt['original_all_pass']:raise SystemExit(1)
