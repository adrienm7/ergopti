local root = arg[1]
local driver = root .. "/static/ergopti_plus/macos"
package.path = driver .. "/?.lua;" .. driver .. "/?/init.lua;" .. root .. "/static/ergopti_plus/_shared/lua/?.lua;" .. root .. "/static/ergopti_plus/_shared/lua/?/init.lua;" .. package.path
_G.hs = require("tests.stubs.hs")
pcall(require, "lfs")
local fixture = require("tests.support.preferences_roundtrip_fixture")
local state = { shortcuts = true, wrap_symbol_states = { ["("] = false }, custom_wrap_symbols = { { left = "a", right = "b" } } }
fixture.with_roundtrip(state, function(saved, preferences, path)
 local f = assert(io.open(path, "rb"));local bytes=f:read("*a");f:close()
 print("physical source=" .. bytes)
 print("loaded wrap states type=" .. type(saved.wrap_symbol_states))
 print("loaded custom wrap symbols type=" .. type(saved.custom_wrap_symbols))
 assert(type(saved.wrap_symbol_states) == "table" and saved.wrap_symbol_states["("] == false, "acknowledged writer must durably preserve independently specified disabled built-in")
 assert(type(saved.custom_wrap_symbols) == "table" and #saved.custom_wrap_symbols == 1 and saved.custom_wrap_symbols[1].left == "a" and saved.custom_wrap_symbols[1].right == "b", "acknowledged writer must durably preserve independently specified custom pair")
end)
