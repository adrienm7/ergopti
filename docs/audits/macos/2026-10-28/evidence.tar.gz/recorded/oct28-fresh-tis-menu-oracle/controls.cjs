'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const Module = require('node:module');
const root = '/workspace/ergopti-macos-integration';
const scratch = '/workspace/scratch/oct28-fresh-tis-menu-oracle';
const filename = path.join(root, 'tools/lib/menu-native-layout-binding.cjs');
const owner = new Module(filename, module); owner.filename = filename; owner.paths = Module._nodeModulePaths(path.dirname(filename));
owner._compile(fs.readFileSync(path.join(scratch, 'after/menu-native-layout-binding.cjs'), 'utf8'), filename);
const source = fs.readFileSync(path.join(scratch, 'actual-menu.lua'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'static/ergopti_plus/_shared/modules/menu/menu_manifest.json'), 'utf8'));
const english = JSON.parse(fs.readFileSync(path.join(root, 'static/ergopti_plus/_shared/data/locales/en.json'), 'utf8'));
const section = 'layout_bundle_variant_add', definition = manifest[section];
const owns = (text) => owner.exports.nativeLayoutRowOwnership(text, '.lua', 'hs', section, definition[0], definition, key => Object.hasOwn(english, key) ? english[key] : undefined, 'behavior');
assert.equal(owns(source), true);
const tail = 'schedule_menu_refresh(update_menu)\n' + '\t'.repeat(9) + 'end)\n' + '\t'.repeat(8) + 'end)';
const early = 'schedule_menu_refresh(update_menu)\n' + '\t'.repeat(10) + 'return';
const cases = [
 ['fresh-native-port', 'input_sources.confirm_source_async(var.tis_id, {}, function(read, state)', 'Foreign.confirm_source_async(var.tis_id, {}, function(read, state)'],
 ['fresh-tis-id', 'input_sources.confirm_source_async(var.tis_id, {}, function(read, state)', 'input_sources.confirm_source_async(var.name, {}, function(read, state)'],
 ['response-read-admission', 'if read and state.enabled == true then', 'if state.enabled == true then'],
 ['typed-enabled-admission', 'if read and state.enabled == true then', 'if read then'],
 ['unread-response-branch', 'elseif read then', 'elseif true then'],
 ['consent-notification', 'i18n.get("menu.layout.add_consent")', 'i18n.get("menu.layout.add_ok")'],
 ['callback-refresh', tail, 'do end\n' + '\t'.repeat(9) + 'end)\n' + '\t'.repeat(8) + 'end)'],
 ['failed-enable-early-return', early, 'schedule_menu_refresh(update_menu)']
];
assert.equal(cases.length, 8); const seen = new Set();
const observed = cases.map(([name, from, to]) => {
 assert.equal(source.split(from).length - 1, 1, name + ': mutate exact real callback owner');
 const mutated = source.replace(from, to), sha256 = crypto.createHash('sha256').update(mutated).digest('hex');
 assert.equal(seen.has(sha256), false, 'independent mutant source census'); seen.add(sha256);
 const result = owns(mutated); assert.equal(result, false, name + ': necessary effect withdrawn');
 return {name, sha256, ownership: result};
});
assert.equal(seen.size, 8); assert.equal(owns(source), true, 'exact restoration must recover ownership');
process.stdout.write(JSON.stringify({healthy: true, controls: observed, count: seen.size, restored: true}, null, 2) + '\n');
