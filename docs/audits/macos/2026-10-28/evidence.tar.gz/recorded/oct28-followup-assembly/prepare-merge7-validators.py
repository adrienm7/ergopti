import os, subprocess, json, hashlib, importlib.util
from pathlib import Path
old=Path('/workspace/scratch/oct28-followup-assembly')
out=Path('/workspace/scratch/oct28-merge7-assembly');out.mkdir(mode=0o700)
root='/workspace/ergopti-macos-integration'
h=lambda b:hashlib.sha256(b).hexdigest()
def git(w,*args):return subprocess.check_output(['git',*args],cwd=w)
a=json.loads((old/'assembly.json').read_text());m=json.loads((old/'manifest-go.json').read_text())
assert not git(root,'status','--porcelain')
head=git(root,'rev-parse','HEAD').decode().strip();tree=git(root,'rev-parse','HEAD^{tree}').decode().strip()
full=git(root,'diff','--binary','--full-index',a['base'],'HEAD');delta=git(root,'diff','--binary','--full-index',a['root_commit'],'HEAD')
(out/'full.patch').write_bytes(full);(out/'delta.patch').write_bytes(delta)
for name,v in m['producers'].items():
 w=v['worktree'];assert git(w,'write-tree').decode().strip()==a['tree'];assert h(git(w,'diff','--cached','--binary','--full-index'))==a['full_patch_sha256'];assert not git(w,'diff','--name-only')
 subprocess.run(['git','apply','--check','--index',str(out/'delta.patch')],cwd=w,check=True)
 subprocess.run(['git','apply','--index',str(out/'delta.patch')],cwd=w,check=True)
 assert git(w,'write-tree').decode().strip()==tree
 assert h(git(w,'diff','--cached','--binary','--full-index'))==h(full)
 v['output']='/workspace/scratch/oct28-merge7-qualification-'+name
 assert not Path(v['output']).exists()
dep=out/'dependencies.json';dep.write_text(json.dumps({'npm_ci_actual_exit':0,'husky_install_actual_exit':0,'private_root':'/workspace/ergopti-macos-integration/node_modules','lock_sha256':h(Path(root+'/package-lock.json').read_bytes()),'root_node_modules_inode':Path(root+'/node_modules').stat().st_ino,'original_shared_modules_inode':Path('/workspace/ergopti/node_modules').stat().st_ino,'validators':{n:str(Path(v['worktree']+'/node_modules').resolve()) for n,v in m['producers'].items()}},indent=2)+'\n');m['expected_dependency_lock_sha256']=h(Path(root+'/package-lock.json').read_bytes());m['dependency_receipt']=str(dep)
m.update(tree=tree,full_patch_path=str(out/'full.patch'),full_patch_sha256=h(full),batch='macos-oct28-merge7-final',approval_identifier='ROOT_MERGE7_COMPLETE_SOURCE_BATCH',committed_source_root_sha=head,committed_source_root_tree=tree)
env=dict(os.environ);env['PATH']=m['toolchain']['path_prefix']+':'+env['PATH'];env['LD_LIBRARY_PATH']=m['toolchain']['ld_library_path'];binding={k:m[k] for k in ('base','tree','source_patch_base','full_patch_sha256')}
for label,cmd in [('plan',['node','./tools/test/verify-change.cjs','--plan']),('js-inventory',['node','./tools/test/run-js-suite.cjs','--list-features'])]:
 r=subprocess.run(cmd,cwd=m['producers']['hs']['worktree'],env=env,capture_output=True);p=out/(label+'.output.json');p.write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr)
 rp=out/(label+'.receipt.json');rp.write_text(json.dumps({'command':cmd,'actual_exit':r.returncode,'source_binding':binding,'output':{'path':str(p),'sha256':h(p.read_bytes())}},indent=2)+'\n');assert r.returncode==0
 m['verify_change_plan_receipt' if label=='plan' else 'js_inventory_receipt']={'path':str(rp),'sha256':h(rp.read_bytes())}
i=json.loads((out/'js-inventory.output.json').read_text());m.update(expected_js_features=i['planned_count'],js_inventory_sha256=i['inventory_sha256'])
p=out/'manifest-go.json';p.write_text(json.dumps(m,indent=2)+'\n')
s=importlib.util.spec_from_file_location('operator','/workspace/scratch/oct28-combined-operator/run-producer.py');mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod);mod.ORIGINAL_VALIDATE(m)
(out/'source.json').write_text(json.dumps({'head':head,'tree':tree,'dev':git(root,'rev-parse','origin/dev').decode().strip(),'full_patch_sha256':h(full),'manifest_sha256':h(p.read_bytes())},indent=2)+'\n')
print(json.dumps({'manifest':str(p),'head':head,'tree':tree,'js_features':i['planned_count']}))
