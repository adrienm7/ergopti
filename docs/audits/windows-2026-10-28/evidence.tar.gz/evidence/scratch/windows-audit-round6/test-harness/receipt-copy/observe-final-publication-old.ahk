﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Include Z:\workspace\scratch\windows-audit-round6\test-harness\receipt-copy\original-framework.ahk
global CopyDirectory := A_Temp . "\ergopti-copy-final-exit-" . A_ScriptHwnd . "-" . A_TickCount
global CopyHandle := 0
global CopyStale := "preceding healthy receipt"
try {
 AssertTrue(DllCall("Kernel32\CreateDirectoryW", "Str", CopyDirectory, "Ptr", 0, "Int"), "exclusive proof directory")
 global TEST_RESULTS_FILE := CopyDirectory . "\fresh.tap"
 global TEST_RESULTS_CANONICAL := CopyDirectory . "\canonical.tap"
 FileAppend("native control", TEST_RESULTS_FILE, "UTF-8")
 FileCopy(TEST_RESULTS_FILE, TEST_RESULTS_CANONICAL, true)
 AssertEqual("native control", FileRead(TEST_RESULTS_CANONICAL, "UTF-8"), "unlocked native copy positive")
 FileDelete(TEST_RESULTS_CANONICAL)
 FileAppend(CopyStale, TEST_RESULTS_CANONICAL, "UTF-8")
 CopyHandle := DllCall("Kernel32\CreateFileW", "Str", TEST_RESULTS_CANONICAL,
  "UInt", 0x80000000, "UInt", 1, "Ptr", 0, "UInt", 3, "UInt", 0x80, "Ptr", 0, "Ptr")
 AssertTrue(CopyHandle != 0 && CopyHandle != -1, "own genuine copy denial capability")
 OnExit(CopyExit)
 Test("owned final publication case", () => AssertTrue(FileExist(TEST_RESULTS_FILE)))
 RunTests()
} catch as CopyProbeTopError {
 FileAppend("FINAL_COPY_FIXTURE_ERROR=" . Type(CopyProbeTopError) . "|" . CopyProbeTopError.Message . "|" . CopyProbeTopError.Stack . "`n", "**", "UTF-8")
 ExitApp(2)
}
CopyExit(Reason, Code) {
 global CopyDirectory, CopyHandle, CopyStale, TEST_RESULTS_CANONICAL
 FileAppend("OBSERVED_EXIT=" . Code . ";STALE_CANONICAL=" . (FileRead(TEST_RESULTS_CANONICAL, "UTF-8") == CopyStale) . "`n", "*", "UTF-8")
 AssertTrue(DllCall("Kernel32\CloseHandle", "Ptr", CopyHandle, "Int"), "retire exact proof capability")
 CopyHandle := 0
 DirDelete(CopyDirectory, true)
}
