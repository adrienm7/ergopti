#!/usr/bin/env python3
"""Continue the exact owned partial installation; never reextract old payloads."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import urllib.request

PACKET = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def snapshot(prefix):
    result = {}
    for path in [prefix, *sorted(prefix.rglob('*'))]:
        name = '.' if path == prefix else str(path.relative_to(prefix))
        mode = stat.S_IMODE(path.lstat().st_mode)
        if path.is_symlink():
            value = {'kind': 'symlink', 'target': str(path.readlink()), 'mode': mode}
        elif path.is_dir():
            value = {'kind': 'directory', 'mode': mode}
        elif path.is_file():
            value = {'kind': 'file', 'mode': mode, 'bytes': path.stat().st_size, 'sha256': sha(path)}
        else:
            raise RuntimeError('Unexpected partial-prefix file kind: ' + name)
        result[name] = value
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print('SOURCE ONLY: no signature, downloads, extraction, schema compilation or installation.')
        return
    env = os.environ.copy()
    env['GIT_OPTIONAL_LOCKS'] = '0'

    def git(*arguments):
        return subprocess.check_output(['git', *arguments], cwd=ROOT, env=env)

    proposal = load(PACKET / 'SOURCE-PROPOSAL.json')
    for name, expected in proposal['files'].items():
        if sha(PACKET / name) != expected['sha256']:
            raise RuntimeError('Reviewed continuation Source changed: ' + name)
    manifest = load(PACKET / 'CONTINUATION-MANIFEST.json')
    prefix, compiler = Path(manifest['prefix']), Path(manifest['compiler_prefix'])
    if prefix.is_symlink() or not prefix.is_dir() or compiler != prefix / 'compiler':
        raise RuntimeError('Exact owned partial prefix is unavailable')
    if snapshot(prefix) != manifest['partial_prefix_preimages']:
        raise RuntimeError('Partial installation preimage changed; no continuation authorized')
    for name in manifest['required_absence']:
        if (prefix / name).exists() or (prefix / name).is_symlink():
            raise RuntimeError('Required new owned output already exists: ' + name)
    qualification = Path(manifest['qualification'])
    if sha(qualification) != manifest['qualification_sha256']:
        raise RuntimeError('Actual qualification receipt changed')
    q = load(qualification)
    if q['exit_code'] != 0 or not all(q[name] is True for name in ('inputs_unchanged', 'index_unchanged', 'head_unchanged')):
        raise RuntimeError('Actual Root qualification refused')
    if sha(qualification.with_suffix('.log')) != q['log_sha256']:
        raise RuntimeError('Actual qualification log changed')
    head = git('rev-parse', 'HEAD').decode().strip()
    if head != manifest['expected_head'] or git('show', '-s', '--format=%P', head).decode().split() != [q['head']]:
        raise RuntimeError('Exact sole ordinary qualified title commit is unavailable')
    if git('status', '--porcelain') or git('branch', '--show-current').decode().strip() != 'feat/config-menus':
        raise RuntimeError('Published owned feature must remain clean')
    if git('ls-remote', '--exit-code', '--heads', 'origin', 'refs/heads/feat/config-menus').decode().splitlines() != [head + '\trefs/heads/feat/config-menus']:
        raise RuntimeError('Actual published feature differs')
    index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index_path.is_absolute():
        index_path = ROOT / index_path
    raw_index = index_path.read_bytes()
    for name, expected in q['source_pins'].items():
        if sha(ROOT / name) != expected:
            raise RuntimeError('Qualified Source changed: ' + name)
    trust = manifest['signed_authority']
    for name in ('Packages', 'InRelease', 'keyring'):
        if sha(Path(trust[name + '_path'])) != trust[name + '_sha256']:
            raise RuntimeError('Original signed metadata/anchor changed: ' + name)
    if sha(Path('/var/lib/dpkg/status')) != manifest['host_status_sha256']:
        raise RuntimeError('Actual host dependency versions changed')
    if sha(Path(manifest['sqv_binary'])) != manifest['sqv_binary_sha256']:
        raise RuntimeError('Genuine current default verifier binary changed')
    for name, expected in manifest['original_inputs'].items():
        if sha(Path(name)) != expected:
            raise RuntimeError('Original schema/actual-failure/frozen Source input changed: ' + name)
    authenticated = Path(manifest['authenticated_release'])
    old_authenticated = Path(manifest['original_verification_output'])
    if sha(authenticated) != manifest['authenticated_release_sha256'] or old_authenticated.read_bytes() != authenticated.read_bytes():
        raise RuntimeError('Actual genuine V4 authenticated metadata changed')
    lines = authenticated.read_text().splitlines()
    sections = [index for index, line in enumerate(lines) if line == 'SHA256:']
    if len(sections) != 1:
        raise RuntimeError('Authenticated Release SHA256 owner is ambiguous')
    entries = []
    for line in lines[sections[0] + 1:]:
        if not line.startswith((' ', '\t')):
            break
        fields = line.split()
        if len(fields) != 3:
            raise RuntimeError('Authenticated SHA256 entry malformed')
        if fields[2] == 'main/binary-amd64/Packages':
            entries.append(fields)
    if entries != [[trust['Packages_sha256'], str(trust['Packages_bytes']), 'main/binary-amd64/Packages']]:
        raise RuntimeError('Compiler index is not the exact genuinely authenticated original Packages')
    if Path(trust['Packages_path']).stat().st_size != trust['Packages_bytes']:
        raise RuntimeError('Original signed Packages size changed')
    dependencies = load(PACKET / 'ORIGINAL-DEPENDENCIES.json')
    for item in dependencies['packages']:
        payload = prefix / 'packages' / Path(item['filename']).name
        if payload.stat().st_size != item['bytes'] or sha(payload) != item['sha256']:
            raise RuntimeError('Original eleven-payload provenance changed: ' + item['name'])
    # Respect the exact u5 bin/library constraint; existing unconstrained data
    # and all other host packages satisfy their actual captured dependencies.
    minimums = {'libatomic1': '4.8', 'libc6': '2.38', 'libffi8': '3.4', 'libmount1': '2.40~rc2',
                'libpcre2-8-0': '10.22', 'libselinux1': '3.1~', 'zlib1g': '1:1.2.2', 'libelf1t64': '0.142'}
    for name, minimum in minimums.items():
        subprocess.run(['/usr/bin/dpkg', '--compare-versions', manifest['host_provided_dependencies'][name]['version'],
                        'ge', minimum], check=True)
    if manifest['packages'][0]['version'] != manifest['packages'][1]['version']:
        raise RuntimeError('Exact GLib compiler/library package version mismatch')
    # Reverify the same signed authority with the genuine unchanged defaults,
    # without rerunning the old installer or allocating/replacing its prefix.
    auth_dir = Path(tempfile.mkdtemp(prefix='actual-compiler-signed-release-', dir=PACKET))
    fresh_authenticated = auth_dir / 'Release.authenticated'
    signed_command = [manifest['sqv_binary'], '--keyring', trust['keyring_path'],
                      '--cleartext', '--output', str(fresh_authenticated), trust['InRelease_path']]
    print(json.dumps({'verification_command': signed_command}), flush=True)
    signature = subprocess.run(signed_command, check=True)
    if fresh_authenticated.read_bytes() != authenticated.read_bytes():
        raise RuntimeError('Fresh genuine authenticated compiler index differs from preserved original')

    primary = None
    completion_errors = []
    try:
        compiler.mkdir(mode=0o700)
        payloads = compiler / 'packages'
        payloads.mkdir(mode=0o700)
        for item in manifest['packages']:
            pending = payloads / (Path(item['filename']).name + '.pending')
            with urllib.request.urlopen(item['uri'], timeout=60) as response:
                with pending.open('xb') as output:
                    shutil.copyfileobj(response, output)
            if pending.stat().st_size != item['bytes'] or sha(pending) != item['sha256']:
                raise RuntimeError('Signed compiler payload hash/size refused: ' + item['name'])
            control = subprocess.check_output(['/usr/bin/dpkg-deb', '--field', str(pending),
                                               'Package', 'Version', 'Architecture'], text=True)
            fields = dict(line.split(': ', 1) for line in control.splitlines())
            if (fields['Package'], fields['Version'], fields['Architecture']) != (item['name'], item['version'], item['architecture']):
                raise RuntimeError('Signed compiler payload control identity refused')
            payload = pending.with_suffix('')
            pending.rename(payload)
            subprocess.run(['/usr/bin/dpkg-deb', '--extract', str(payload), str(compiler)], check=True)
        binary = compiler / 'usr/bin/glib-compile-schemas'
        compiler_env = os.environ.copy()
        compiler_env['LD_LIBRARY_PATH'] = str(compiler / 'usr/lib/x86_64-linux-gnu') + (
            ':' + compiler_env['LD_LIBRARY_PATH'] if compiler_env.get('LD_LIBRARY_PATH') else '')
        command = [str(binary), '--strict', str(prefix / 'state/schemas')]
        subprocess.run(command, env=compiler_env, check=True)
        compiled = prefix / 'state/schemas/gschemas.compiled'
        if not compiled.is_file() or compiled.is_symlink() or compiled.stat().st_size == 0:
            raise RuntimeError('Actual compiler produced no genuine compiled schemas')
        bin_dir = prefix / 'bin'
        bin_dir.mkdir(mode=0o700)
        wrapper = bin_dir / 'zenity'
        with wrapper.open('xb') as output:
            output.write((Path(manifest['v4_packet']) / 'zenity-owned-wrapper.sh').read_bytes())
        wrapper.chmod(0o755)
        verifier_source = load(PACKET / 'ORIGINAL-VERIFIER-PROVENANCE.json')
        verification_command = [verifier_source['binary'], '--keyring', trust['keyring_path'],
                                '--cleartext', '--output', str(old_authenticated), trust['InRelease_path']]
        receipt = {
            'status': 'DEPENDENCIES_EXTRACTED; native chooser and Browse remain UNRUN',
            'prefix': str(prefix), 'binary_sha256': sha(prefix / 'usr/bin/zenity'),
            'wrapper_sha256': sha(wrapper), 'schemas_sha256': sha(compiled),
            'packages': [{'name': p['name'], 'version': p['version'], 'sha256': p['sha256']} for p in dependencies['packages']],
            'source_manifest_sha256': sha(PACKET / 'ORIGINAL-DEPENDENCIES.json'),
            'verifier': {'binary': verifier_source['binary'], 'binary_sha256': verifier_source['binary_sha256'],
                         'installed_package_version': verifier_source['installed_package_version'],
                         'command': verification_command, 'exit_code': 0,
                         'provenance_source_sha256': sha(PACKET / 'ORIGINAL-VERIFIER-PROVENANCE.json'),
                         'authenticated_release_sha256': sha(authenticated),
                         'original_packages_entry': entries[0]},
            'compiler': {'command': command, 'binary_sha256': sha(binary), 'exit_code': 0,
                         'index_verifier': {'command': signed_command, 'exit_code': signature.returncode,
                                            'authenticated_release_sha256': sha(fresh_authenticated)},
                         'packages': [{'name': p['name'], 'version': p['version'], 'sha256': p['sha256']} for p in manifest['packages']],
                         'continuation_manifest_sha256': sha(PACKET / 'CONTINUATION-MANIFEST.json'),
                         'continuation_source_proposal_sha256': sha(PACKET / 'SOURCE-PROPOSAL.json'),
                         'prior_actual_failure_log_sha256': sha(PACKET / 'FINAL-BROWSE-DEPENDENCY-INSTALL-V4-ACTUAL-20261011.log')},
            'old_environment_pins_unchanged': all(sha(Path(p)) == h for p, h in dependencies['unmodified_environment_pins'].items()),
        }
        if receipt['old_environment_pins_unchanged'] is not True:
            raise RuntimeError('Existing environment changed during continuation')
        # Write the actual installation acknowledgement only after final fences.
    except BaseException as error:
        primary = error
    finally:
        try:
            after = snapshot(prefix)
            for name, expected in manifest['partial_prefix_preimages'].items():
                if after.get(name) != expected:
                    raise RuntimeError('Original partial path changed: ' + name)
            allowed = {'compiler', 'bin', 'bin/zenity', 'state/schemas/gschemas.compiled'}
            if any(name not in allowed and not name.startswith('compiler/') for name in set(after) - set(manifest['partial_prefix_preimages'])):
                raise RuntimeError('Unexpected new path outside bounded compiler/schema/wrapper outputs')
        except BaseException as error:
            completion_errors.append('partial-prefix final fence: ' + str(error))
        try:
            if git('rev-parse', 'HEAD').decode().strip() != head or index_path.read_bytes() != raw_index:
                raise RuntimeError('Root HEAD/raw index changed')
            if any(sha(ROOT / p) != h for p, h in q['source_pins'].items()):
                raise RuntimeError('Qualified Root Source changed')
            if any(sha(Path(p)) != h for p, h in manifest['original_inputs'].items()):
                raise RuntimeError('Original input/schema/failure proof changed')
        except BaseException as error:
            completion_errors.append('Root/input final fence: ' + str(error))
    if primary is not None:
        if completion_errors:
            try:
                print(json.dumps({'primary': str(primary), 'secondary_completion_errors': completion_errors}), flush=True)
            except BaseException:
                pass
        raise primary
    if completion_errors:
        raise RuntimeError('; '.join(completion_errors))
    receipt['compiler']['original_partial_paths_unchanged'] = True
    receipt['compiler']['root_source_index_head_unchanged'] = True
    with (prefix / 'INSTALL-RECEIPT.json').open('x') as output:
        json.dump(receipt, output, indent=2)
        output.write('\n')
    print(json.dumps({'status': receipt['status'], 'receipt': str(prefix / 'INSTALL-RECEIPT.json'),
                      'receipt_sha256': sha(prefix / 'INSTALL-RECEIPT.json')}))


if __name__ == '__main__':
    main()
