# Restore stage collision — UNRUN

Only ConfigBackup_Restore calls FSCopyReplaceAtomic. The adapter copies to a
fixed destination.ergopti-restore.tmp with overwrite=true, then renames that path.
A preexisting unrelated sidecar can therefore be overwritten and consumed; the
backup extension rules do not include that.tmp file in the pre-restore snapshot.

The proposal first executes a successful actual restore on the same private
native paths, then creates an exclusive foreign sidecar and calls the genuine
restore again. It requires original sidecar bytes to survive. Either an owned
independent stage succeeds or an explicit write refusal leaves the destination
intact; the test does not prescribe a particular staging implementation.

No execution or production edit. This call tree is distinct from the prohibited
updater PublishCopy integrity fix; no change to that path is proposed. Root must
review scope and qualify genuine filesystem evidence before any correction.
