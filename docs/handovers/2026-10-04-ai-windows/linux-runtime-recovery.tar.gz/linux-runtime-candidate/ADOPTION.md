<!-- linux-runtime-candidate/ADOPTION.md -->

# Prepared owned-process adoption patches

`owned-process-adoption.patch` adds five previously absent paths:

- `static/ergopti_plus/linux/adapters/owned_process.lua`.
- `static/ergopti_plus/linux/tests/unit/adapters/test_owned_process.lua`.
- `static/ergopti_plus/linux/tests/hardware/run_owned_process_receipts.lua`.
- `static/ergopti_plus/linux/tests/hardware/run_owned_process_subreaper.py`.
- `static/ergopti_plus/linux/tests/hardware/run_owned_process_subreaper_teardown.py`.

`owned-process-manifest.patch` contains only the one-line unit-module insertion,
with context near the existing process adapters. The root must coordinate that
shared test inventory with group 3 before applying it. No workflow, shared
catalogue, schema, locale or generator is changed.

The adapter is byte-identical to the reviewed, qualified scratch source:
SHA-256 `3f175c7a1c92df4e835912551efab00115611f806e5be62e462796b399934d5f`.
The unit adaptation preserves all 17 independent cases and their assertions;
`tests.helpers` registers them with the `owned-process:` case prefix and
`load_module_with_dependency` restores the native dependency even on failure.
The native probe preserves all 10 cases, deriving actual source paths instead
of requiring scratch root arguments. The wrapper derives its default absolute
probe path, permits `ERGOPTI_OWNED_PROCESS_TEST_LUA=lua5.4`, and guards `add_note`
for Python 3.10 while preserving the primary failure. Its independent teardown
probe retains both actual process-identity cases.

These adoption adaptations have not been executed, applied or registered. The
scratch results in `QUALIFICATION.md` do not replace the post-adoption registered
suite, hardware probes, selected verification or hosted validation.

After the root applies and registers the patches, the focused invocations are:

```bash
# From static/ergopti_plus/linux, with native dependencies already prepared.
luajit tests/run.lua --only=owned-process:
lua5.4 tests/run.lua --only=owned-process:

python3 tests/hardware/run_owned_process_subreaper.py
ERGOPTI_OWNED_PROCESS_TEST_LUA=lua5.4 \
  python3 tests/hardware/run_owned_process_subreaper.py
python3 tests/hardware/run_owned_process_subreaper_teardown.py
```

The registered runner first checks its exact inventory, including all other
current groups' modules. The root owns phase serialization and decides when to
run these commands. No actual Ollama archive was downloaded or installed.
