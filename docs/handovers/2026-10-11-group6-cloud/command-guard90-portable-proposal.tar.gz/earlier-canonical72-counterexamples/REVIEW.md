# SOURCE_ONLY native command closure concern

`portable_counterexample.py` is authored but NOT EXECUTED while the parent owns the serial validation slot. It uses the exact unchanged canonical72 fixture6c37993b0895b169197748eb8812fcce8c1648f1824654e38519d95f92f5efe1.

The controlled native protocol acquires and retains an actual long-lived POSIX subprocess. Its wait raises a modeled timeout and settle returns false without retiring the child. The unchanged fixture._command should propagate the timeout and expose phase=settle while closing its known captures. The control then invokes unchanged fixture.close and observes whether it removes the root/marks closed while the exact retained child remains alive. The outer owner always terminates/kills only its actual acquired child via its Popen object and reaps it before returning.

A successful counterexample proves that this Python software protocol can discard the unsettled-owner fact despite the originally modeled refusal. It does not prove Darwin kernel behavior, the cause of historical managed-trust failure, or an actual native unresolved compiler receipt. No source correction, second child owner, forwarding proxy, relaxed assertion or deadline widening is included. Receive the control first, review the genuine owner contract, and separately coordinate any justified correction before adopting it.
