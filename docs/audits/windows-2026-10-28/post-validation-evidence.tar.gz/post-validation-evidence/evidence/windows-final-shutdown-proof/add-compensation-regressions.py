from pathlib import Path
root=Path('/workspace/ergopti-windows-final-shutdown')
p=root/'static/ergopti_plus/windows/tests/support/run_program_shutdown_envelope.ahk'
s=p.read_text(encoding='utf-8-sig')
old='\treturn _RPA_EnvelopeCount("nav")\n';new='\t_RPA_EnvelopeState["nav-prepared"] := true\n'+old;assert s.count(old)==1;s=s.replace(old,new)
old='LLM_NavEventOwner_CancelShutdown(*) {\n\treturn _RPA_EnvelopeCount("nav-cancel")\n}';new='LLM_NavEventOwner_CancelShutdown(*) {\n\tglobal _RPA_EnvelopeState\n\t_RPA_EnvelopeState["nav-prepared"] := false\n\treturn _RPA_EnvelopeCount("nav-cancel")\n}';assert s.count(old)==1;s=s.replace(old,new)
old='LayoutRegistry_PrepareShutdown(*) {\n\treturn _RPA_EnvelopeCount("registry")\n}';new='''LayoutRegistry_PrepareShutdown(*) {
	global _RPA_EnvelopeState
	_RPA_EnvelopeCount("registry")
	Mode := _RPA_EnvelopeState["registry-mode"]
	if Mode == "throw"
		throw Error("exact registry shutdown fixture exception")
	if Mode == "empty-error"
		throw Error("")
	return Mode != "refuse"
}''';assert s.count(old)==1;s=s.replace(old,new)
old='ConfigWriteAcquireLifecycleBundle(*) {\n\treturn Map("fixture", true)\n}';new='''ConfigWriteAcquireLifecycleBundle(*) {
	global _RPA_EnvelopeState
	_RPA_EnvelopeCount("bundle-acquire")
	Bundle := Map("fixture", true)
	_RPA_EnvelopeState["bundle"] := Bundle
	return Bundle
}''';assert s.count(old)==1;s=s.replace(old,new)
old='_ConfigWriteTerminalRelease(*) {\n\treturn _RPA_EnvelopeCount("bundle-release")\n}';new='''_ConfigWriteTerminalRelease(Bundle) {
	global _RPA_EnvelopeState
	_RPA_EnvelopeRequire(Bundle == _RPA_EnvelopeState["bundle"],
		"only the exact acquired configuration bundle may be returned")
	return _RPA_EnvelopeCount("bundle-release")
}''';assert s.count(old)==1;s=s.replace(old,new)
assert s.count('_RPA_EnvelopeState := Map()')==2;s=s.replace('_RPA_EnvelopeState := Map()', '_RPA_EnvelopeState := Map("registry-mode", "ready")')
old='try {\n\t_RPA_EnvelopeRun()\n';new='''_RPA_RegistryEnvelopeRun(Mode) {
	global _RPA_EnvelopeState, _UserProgramEntries, _UserProgramAcquiring
	global _UserProgramPaused, _UserProgramGeneration, _LifecycleShutdownReason
	global _LifecycleShutdownVetoAttempts
	_RPA_EnvelopeRequire(Mode == "ready" || Mode == "refuse" || Mode == "throw" || Mode == "empty-error",
		"the registry envelope requires an explicit known native owner result")
	for Paused in [false, true] {
		Suspend(Paused)
		try {
			_RPA_EnvelopeState := Map("registry-mode", Mode, "nav-prepared", false)
			_UserProgramEntries := Map(), _UserProgramAcquiring := 0
			_UserProgramPaused := Paused, _UserProgramGeneration := 0
			_LifecycleShutdownVetoAttempts := 0
			Result := Ergopti_OnShutdown("Reload", 0)
			_RPA_EnvelopeRequire((Result is Integer) && Result == 1,
				"an admitted shutdown refusal must keep the genuine handler alive")
			_RPA_EnvelopeRequire(_RPA_EnvelopeState.Get("nav", 0) == 1
				&& _RPA_EnvelopeState.Get("registry", 0) == 1,
				"the real handler must reach both native admission owners exactly once")
			Prepared := _RPA_EnvelopeState["nav-prepared"]
			CancelCalls := _RPA_EnvelopeState.Get("nav-cancel", 0)
			_RPA_EnvelopeRequire(!Prepared && CancelCalls == 1,
				"registry refusal must return native admission: prepared=" . Prepared . ", cancel=" . CancelCalls)
			_RPA_EnvelopeRequire(_RPA_EnvelopeState.Get("bundle-acquire", 0) == 1
				&& _RPA_EnvelopeState.Get("bundle-release", 0) == 1,
				"the registry gate must compensate its exact owned configuration bundle once")
			_RPA_EnvelopeRequire(_RPA_EnvelopeState.Get("modifier", 0) == 1,
				"held native modifiers must be released before registry retirement")
			_RPA_EnvelopeRequire(_UserProgramGeneration == (Mode == "ready" ? 1 : 0),
				"registry refusal must precede actual user-program retirement")
			_RPA_EnvelopeRequire(_RPA_EnvelopeState.Get("full-save", 0) == (Mode == "ready" ? 1 : 0),
				"only the healthy registry control may reach full-save settlement")
			_RPA_EnvelopeRequire(_LifecycleShutdownVetoAttempts == 1
				&& _RPA_EnvelopeState.Get("reload-refuse", 0) == 1,
				"each registry refusal must consume one honored veto and refuse the pending reload once")
			_RPA_EnvelopeRequire(_RPA_EnvelopeState["gate"] == (Mode == "ready"
				? "an accepted full configuration save remains non-durable"
				: "a registry download still owns native cleanup"),
				"the genuine refusal must name the exact unsettled owner")
			_RPA_EnvelopeRequire(_UserProgramPaused == Paused && A_IsSuspended == Paused,
				"registry refusal must preserve program and native pause posture")
		} finally Suspend(false)
	}
}

try {
	_RPA_EnvelopeRequire(A_Args.Length == 1, "the native envelope requires its exact scenario")
	Scenario := A_Args[1]
	if Scenario == "program"
		_RPA_EnvelopeRun()
	else if SubStr(Scenario, 1, 9) == "registry-"
		_RPA_RegistryEnvelopeRun(SubStr(Scenario, 10))
	else
		throw Error("Unknown shutdown envelope scenario: " . Scenario)
''';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf-8-sig',newline='\n')
p=root/'static/ergopti_plus/windows/tests/unit/modules/shortcuts/test_run_program_actions.ahk';s=p.read_text(encoding='utf-8-sig');old='_RPA_ExactNativeShutdownEnvelope() {';new='_RPA_ExactNativeShutdownEnvelope(Scenario := "program") {';assert s.count(old)==1;s=s.replace(old,new)
old='Handle := ShellRunner_SpawnTreeOwned(A_AhkPath, ["/ErrorStdOut", Harness], _RPA_EnvelopeDone.Bind(State))';new='Handle := ShellRunner_SpawnTreeOwned(A_AhkPath, ["/ErrorStdOut", Harness, Scenario], _RPA_EnvelopeDone.Bind(State))';assert s.count(old)==1;s=s.replace(old,new)
s+='''
for _RPA_RegistryMode in ["ready", "refuse", "throw", "empty-error"]
	Test("lifecycle registry shutdown: " . _RPA_RegistryMode . " returns native admission and its bundle (registry-shutdown-compensation)",
		_RPA_ExactNativeShutdownEnvelope.Bind("registry-" . _RPA_RegistryMode))
''';p.write_text(s,encoding='utf-8-sig',newline='\n')
