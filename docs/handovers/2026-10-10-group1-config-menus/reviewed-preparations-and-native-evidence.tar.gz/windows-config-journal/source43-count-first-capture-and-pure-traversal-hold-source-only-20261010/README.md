# Count and traversal proposals remain on hold

This is a source-only refusal of two proposed optimizations. It contains no production or test patch. The current repository is unchanged by this investigation. Windows execution and performance of these rejected candidates are **UNRUN**.

## Original count-producer provenance

The V2 count candidate checks function identity and absence of an own `Call` property, but named `CountOwner.Call(Value)` still resolves inherited `Call`. The exact shipped AutoHotkey 2.0.26 source permits a Func object base to change to a Func-derived prototype (`CanSetBase`, `script_object.cpp:1022–1028`). Named method lookup traverses that base (`GetMethodValue`, 611–639), whereas the original native shortcut requires an unnamed invocation and no own properties (`Func::Invoke`, 2578–2586).

Capturing public `Func.Prototype` at first construction does not independently prove the original prototype: `CreateClass`, 1057–1062, installs it as an ordinary mutable own data property. A raw descriptor avoids a replaced getter, but a pre-capture replacement of that data together with a matching derived CountOwner base can satisfy consistent identity metadata and still dispatch an inherited observer. The bounded proposal has no independently retained bootstrap anchor for that original prototype. Adding one would require bootstrap/native-owner coordination. An unnamed direct invocation would need its actual no-own-properties premise held through invocation; the current source does not establish that atomic interval. No such alternative is implemented here.

The old V2 source approval is historical and superseded by its inherited-Call blocking addendum. No V3 patch is prepared or offered for adoption. This conclusion does not assert the original whole program is immune to every prototype mutation; it refuses adding this unproven new producer surface.

## The proposed repeated-cohort optimization has no target

`ConfigMigrateBoot.NativeLive` (976–992) checks the captured cohort. `RegistryLive` (1052–1062) invokes it once before the actual registry producer and recursive comparison. `SameRegistry` (1002–1050) never invokes `NativeLive` at a primitive or container. Consequently there is no per-container full-cohort admission to collapse into a before/after check.

The recursive comparison performs its complete live structural walk on each actual guard invocation. Container admission checks exact native base and absence of own properties; maps then inspect Count/CaseSense, snapshot all Right cells into an invocation-local exact-key Map, and compare all Left cells. Arrays retain their original Length/Has/item observations. Primitive equality dispatches the captured `ConfigMigrateSameValue`, which calls actual `TOML_SameValue` and `_TOML_ValueKind` (the pinned sources show the entire chain).

That comparison cannot presently be certified as a closed, callback-free native operation. These are script functions, and the exact interpreter comment at `script_expression.cpp:2168–2172` explicitly permits MsgSleep/interruption during script-function calls. Enumeration invokes named `__Enum` (`script_object.cpp:304–346`), and member lookup consults mutable prototypes (611–639). `PlainContainer` rejects own properties and a changed object base; it does not independently retain every prototype descriptor used by enumeration/Count/CaseSense/Has/item access. This is a limit of the proposed proof, not an invented measured regression or a request to broaden the generic runtime policy.

The existing `AllLive` calls before and after each real native callback (`config_transition_runtime.ahk:738–762`) remain necessary observations at distinct native boundaries. The nested Read wrapper also adds observations, but removing one is not justified by a nonexistent pure/no-interruption premise. No admission is cached, no deadline changes, no assertion changes, and no expected corpus regeneration are proposed.

## Next evidence

The approved genuine retained-guard32 diagnostic is already received by Root. It measures 32 actual complete guard calls, then requires Count-getter refusal with zero observer effects and exact repair. Actual unchanged full-suite execution and the existing 34-store native phase reports remain necessary. Source alone cannot claim a faster or fully qualified Windows result.
