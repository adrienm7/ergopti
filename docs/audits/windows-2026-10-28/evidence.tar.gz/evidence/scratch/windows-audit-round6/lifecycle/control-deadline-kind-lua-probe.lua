local root="/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path=root.."lua/?.lua;"..package.path
local Json=require("json");local Policy=require("control.driver_control")
local f=assert(io.open(root.."modules/control/driver_control.json","rb"));local raw=assert(f:read("*a"));assert(f:close());local spec=Policy.validate(Json.decode(raw))
local rows={
 {"future integer","1700000120","claimed","completed"},
 {"expired integer","1","timeout","timeout"},
 {"boolean true","true",nil,nil},
 {"boolean false","false",nil,nil},
 {"numeric string",[["1700000120"]],nil,nil},
 {"null","null",nil,nil},
}
local passed,failed=0,0
for _,phase in ipairs({"pending","claimed"}) do
 for _,row in ipairs(rows) do
  local state=phase=="pending" and "requested" or "claimed"
  local successor=phase=="pending" and "null" or "200"
  local text='{"schema":1,"request_id":"deadline-kind","state":"'..state..'","driver_pid":200,"successor_pid":'..successor..',"deadline":'..row[2]..'}'
  local decoded=Json.decode(text);assert(decoded.request_id=="deadline-kind" and decoded.driver_pid==200)
  local kind,result=Policy.resolve(spec,text,200,1700000000,Json.decode)
  local want=row[phase=="pending" and 3 or 4]
  local prefix='{"schema":1,"request_id":"deadline-kind","state":"'
  local expected
  if want=="claimed" then expected=prefix..'claimed","driver_pid":200,"successor_pid":200,"deadline":1700000120}\n'
  elseif want=="completed" then expected=prefix..'completed","driver_pid":200,"successor_pid":200}\n'
  elseif want=="timeout" then expected=prefix..'timeout","driver_pid":200,"reason":"deadline"}\n' end
  local ok=kind==want and result==expected
  print((ok and "PASS " or "FAIL ")..phase.." "..row[1]);if ok then passed=passed+1 else failed=failed+1 end
 end
end
print(passed.." passed, "..failed.." failed");os.exit(failed==0 and 0 or 1)
