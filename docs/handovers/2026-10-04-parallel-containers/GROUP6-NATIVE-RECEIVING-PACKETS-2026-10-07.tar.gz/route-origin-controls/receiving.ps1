# Source-bound passive diagnostic controls only. Never execute the native fixture.
param([string]$PacketRoot='/tmp/group6-windows-route-origin-diagnostic-r1')
$ErrorActionPreference='Stop'
$Current='source-admission';$Passed=0;$Failed=$false
$Fixture=Join-Path $PacketRoot 'proposed/static/ergopti_plus/windows/tests/fixtures/managed_routes_native.ps1'
$ExpectedHash='fe52db99f7c822e3e8ba6107cbf85b6ab9c34819b7e3a4837c86509936d9a59b'
function Assert-Source {
    if((Get-FileHash -LiteralPath $script:Fixture -Algorithm SHA256).Hash.ToLowerInvariant() -cne $script:ExpectedHash){throw 'Source identity refused.'}
}
function Assert-Law {param([bool]$Condition) if(-not $Condition){throw 'Receiving law refused.'}}
function Measure-Projection {
    param($Result,[string]$Shape,[string]$Ok,[int]$Count,[string]$Limits,[string]$Source,[string]$Kind,
        [bool]$Native=$false,[int]$Errno=0,[string]$Status='unknown')
    Assert-Source
    Set-ManagedRoutesDiagnosticResult -Result $Result
    Assert-Law ($script:ManagedRoutesDiagnosticResultShape -ceq $Shape)
    Assert-Law ($script:ManagedRoutesDiagnosticOk -ceq $Ok)
    Assert-Law ($script:ManagedRoutesDiagnosticRouteCount -eq $Count)
    Assert-Law ($script:ManagedRoutesDiagnosticLimits -ceq $Limits)
    Assert-Law ($script:ManagedRoutesDiagnosticSingleSource -ceq $Source)
    Assert-Law ($script:ManagedRoutesDiagnosticSingleKind -ceq $Kind)
    Assert-Law ($script:ManagedRoutesDiagnosticNativeObserved -eq $Native)
    Assert-Law ($script:ManagedRoutesDiagnosticNativeErrno -eq $Errno)
    Assert-Law ($script:ManagedRoutesDiagnosticStatus -ceq $Status)
    # Capture the actual passive writer with only fixed owner metadata.
    $script:ManagedRoutesDiagnosticStage='vector_receipt'
    $script:ManagedRoutesDiagnosticVector=1
    $script:ManagedRoutesDiagnosticAttempted=$false
    $OriginalError=[Console]::Error
    $Capture=[IO.StringWriter]::new([Globalization.CultureInfo]::InvariantCulture)
    try {
        [Console]::SetError($Capture)
        Write-ManagedRoutesDiagnostic
        Write-ManagedRoutesDiagnostic
    } finally {[Console]::SetError($OriginalError)}
    $Frame=$Capture.ToString();$Capture.Dispose()
    $Expected='ROUTE_DIAG stage=vector_receipt vector=1 native_observed='+[int]$Native+
        ' native_errno='+$Errno+' status='+$Status+' result_shape='+$Shape+' ok='+$Ok+
        ' route_count='+$Count+' limits='+$Limits+' single_source='+$Source+' single_kind='+$Kind+[Environment]::NewLine
    Assert-Law ($Frame -ceq $Expected)
    Assert-Law (-not $Frame.Contains('private-origin-secret'))
    $script:Passed++
    [Console]::Out.WriteLine('PASS '+$script:Current)
}
function New-SingleResult {param($Source,$Kind)
    return @{Ok=$true;Routes=@(@{Source=$Source;Kind=$Kind;Endpoint='https://private-origin-secret.invalid/path?token=private-origin-secret';Extra='private-origin-secret'});MaxRoutes=128;MaxRedirects=50}
}
try {
    Assert-Source
    $Tokens=$null;$Errors=$null
    $Ast=[Management.Automation.Language.Parser]::ParseFile($Fixture,[ref]$Tokens,[ref]$Errors)
    Assert-Law ($Errors.Count -eq 0)
    foreach($Name in @('Set-ManagedRoutesDiagnosticResult','Write-ManagedRoutesDiagnostic')) {
        $Functions=@($Ast.FindAll({param($Node) $Node -is [Management.Automation.Language.FunctionDefinitionAst] -and $Node.Name -ceq $Name}.GetNewClosure(),$true))
        Assert-Law ($Functions.Count -eq 1)
        . ([scriptblock]::Create($Functions[0].Extent.Text))
    }
    # Independently authored vocabulary: no extraction of expected enum values.
    $Sources=@('loopback','environment','environment_bypass','system_direct','system_bypass',
        'system_config_absent_direct','system_config_absent_bypass','system_proxy','system_config_absent_proxy',
        'wpad_absent_direct','wpad_absent_bypass','wpad_absent_proxy','native_proxy','native_direct','native_bypass')
    Assert-Law ($Sources.Count -eq 15)
    foreach($Source in $Sources) {
        $Current='source-'+$Source
        Measure-Projection (New-SingleResult $Source 'direct') 'hashtable' 'true' 1 'match' $Source 'direct'
    }
    foreach($Kind in @('direct','proxy')) {
        $Current='kind-'+$Kind
        Measure-Projection (New-SingleResult 'native_proxy' $Kind) 'hashtable' 'true' 1 'match' 'native_proxy' $Kind
    }
    foreach($Bad in @('Native_direct','NATIVE_DIRECT','native_direct ',' native_direct','native_direct|private-origin-secret',
        'https://private-origin-secret.invalid/','private-origin-secret',[int]7,$null,@('native_direct'),@{Value='native_direct'})) {
        $Current='invalid-source-'+$Passed
        Measure-Projection (New-SingleResult $Bad 'proxy') 'hashtable' 'true' 1 'match' 'unknown' 'proxy'
    }
    foreach($Bad in @('Direct','PROXY','direct ',' proxy','private-origin-secret',[int]7,$null,@('direct'),@{Value='direct'})) {
        $Current='invalid-kind-'+$Passed
        Measure-Projection (New-SingleResult 'system_direct' $Bad) 'hashtable' 'true' 1 'match' 'system_direct' 'unknown'
    }
    $Current='null-resets-valid';Measure-Projection $null 'null' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='array';Measure-Projection @(@{Source='native_direct';Kind='direct'}) 'array' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='primitive';Measure-Projection 'private-origin-secret' 'other' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='custom-object';Measure-Projection ([pscustomobject]@{Routes=@(@{Source='native_direct';Kind='direct'})}) 'other' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='empty-hashtable';Measure-Projection @{} 'hashtable' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='zero-routes';Measure-Projection @{Ok=$false;Routes=@();MaxRoutes=128;MaxRedirects=50} 'hashtable' 'false' 0 'match' 'unknown' 'unknown'
    $Current='two-routes';Measure-Projection @{Ok=$true;Routes=@(@{Source='native_direct';Kind='direct'},@{Source='system_proxy';Kind='proxy'});MaxRoutes=128;MaxRedirects=50} 'hashtable' 'true' 2 'match' 'unknown' 'unknown'
    foreach($Bad in @($null,'private-origin-secret',[int]42,[pscustomobject]@{Source='native_direct';Kind='direct'},@('native_direct','direct'))) {
        $Current='malformed-single-route-'+$Passed
        $Routes=[object[]]::new(1);$Routes[0]=$Bad
        Measure-Projection @{Ok=$true;Routes=$Routes;MaxRoutes=128;MaxRedirects=50} 'hashtable' 'true' 1 'match' 'unknown' 'unknown'
    }
    $Current='routes-not-array';Measure-Projection @{Ok=$true;Routes=@{Source='native_direct';Kind='direct'};MaxRoutes=128;MaxRedirects=50} 'hashtable' 'true' -1 'match' 'unknown' 'unknown'
    $Current='closed-count-ceiling';Measure-Projection @{Routes=[object[]]::new(4096)} 'hashtable' 'unknown' 4096 'unknown' 'unknown' 'unknown'
    $Current='refused-count-over';Measure-Projection @{Routes=[object[]]::new(4097)} 'hashtable' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='long-limits';Measure-Projection @{Routes=@();MaxRoutes=[long]128;MaxRedirects=[long]50} 'hashtable' 'unknown' 0 'match' 'unknown' 'unknown'
    $Current='mismatched-limits';Measure-Projection @{Routes=@();MaxRoutes=129;MaxRedirects=50} 'hashtable' 'unknown' 0 'mismatch' 'unknown' 'unknown'
    $Current='string-limits';Measure-Projection @{Ok='true';Routes=@();MaxRoutes='128';MaxRedirects='50'} 'hashtable' 'unknown' 0 'unknown' 'unknown' 'unknown'
    $Current='case-insensitive-keys-closed-values';Measure-Projection @{ok=$true;routes=@(@{source='native_direct';kind='direct'});maxroutes=128;maxredirects=50} 'hashtable' 'true' 1 'match' 'native_direct' 'direct'
    foreach($Code in @('-2147483648','0','2147483647')) {
        $Current='signed-errno-'+$Passed
        Measure-Projection @{Receipt=@{failure_provenance='verified';native_errno_domain='win32';native_errno=$Code;proxy_resolution_status='pac_failed'}} 'hashtable' 'unknown' -1 'unknown' 'unknown' 'unknown' $true ([int]$Code) 'pac_failed'
    }
    foreach($Code in @('-2147483649','2147483648','01','+1','1 ','private-origin-secret',[int]5)) {
        $Current='invalid-errno-'+$Passed
        Measure-Projection @{Receipt=@{failure_provenance='verified';native_errno_domain='win32';native_errno=$Code;proxy_resolution_status='wpad_failed'}} 'hashtable' 'unknown' -1 'unknown' 'unknown' 'unknown' $false 0 'wpad_failed'
    }
    foreach($Status in @('unavailable','invalid_configuration','pac_failed','wpad_failed')) {
        $Current='status-'+$Status
        Measure-Projection @{Receipt=@{proxy_resolution_status=$Status}} 'hashtable' 'unknown' -1 'unknown' 'unknown' 'unknown' $false 0 $Status
    }
    $Current='unverified-errno';Measure-Projection @{Receipt=@{failure_provenance='Verified';native_errno_domain='win32';native_errno='5';proxy_resolution_status='Pac_failed'}} 'hashtable' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='non-win32-errno';Measure-Projection @{Receipt=@{failure_provenance='verified';native_errno_domain='WIN32';native_errno='5'}} 'hashtable' 'unknown' -1 'unknown' 'unknown' 'unknown'
    $Current='reset-native-and-source';Measure-Projection (New-SingleResult 'native_direct' 'direct') 'hashtable' 'true' 1 'match' 'native_direct' 'direct'
    $Current='final-reset';Measure-Projection $null 'null' 'unknown' -1 'unknown' 'unknown' 'unknown'
    Assert-Source
    Assert-Law ($Passed -ge 70)
} catch {[Console]::Error.WriteLine('ROUTE_ORIGIN_CONTROL_REFUSED case='+$Current);$Failed=$true}
if($Failed){exit 1}
[Console]::Out.WriteLine('PASS actual passive PowerShell route projection controls: '+$Passed+'; no WinHTTP or Windows native credit')
