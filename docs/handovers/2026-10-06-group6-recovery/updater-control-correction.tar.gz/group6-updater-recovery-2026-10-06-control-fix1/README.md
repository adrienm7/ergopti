<!-- group6-updater-recovery-2026-10-06-control-fix1/README.md -->

# Delimiter-only source correction addendum

Use together with group6-updater-recovery-2026-10-06.tar.gz SHA7bcf4405.
Original reviewed source packets and their faulty first-control delimiter remain
preserved. The first actual candidate launch stopped at an import syntax error
before any case executed (zero cases, one importFAIL,192 unexecuted); its safe
summary and unchanged source inventories are recorded here without raw runtime
logs or thousand-file snapshots.

This addendum changes only one outer end) in each raw and normally registered
manager control. All production sources, labels, bodies, oracles and floors are
unchanged. Peer source review0a9d8e5c accepted that exact six-binding delta.
Corrected96 launch2 PLANdaf97537/SCRIPTf1924338 is authored but UNEXECUTED.
No new tests/imports, root edits, Git/CI/generator actions or slot ownership.

Snapshot .source suffixes are inert byte-preserving aliases; PORTABLE-MAPPING
contains original locators and SHA256. Restore only into private scratch and
obtain the next exclusive root slot before any launch. Never rewrite failed
qualification1 logs/receipts or present a source ACK as a test pass.
