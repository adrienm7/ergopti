# Linux managed HTTP composition: native-owner extension proposal

Status: source-only proposal, not implemented, reviewed or qualified. No test or
native command ran for this proposal. No live repository, foreign branch,
workflow, manifest or generated artifact was edited.

## Exact prerequisite and ownership

The prerequisite is foreign `fix/linux` commit
`ec9673283b6d2eb1dadc7914cbcfba5043f94957`. Its
`static/ergopti_plus/linux/adapters/http_client.lua` is 893 lines, SHA256
`8c5d52f8c1d2e11fea477bab68f764f0315ff1997556faab1a92e8c41c903305`.
Relative to the six-blocker plan's dev checkpoint it adds 166 and removes 23
lines. `INPUTS-SHA256.json` pins its exact native dependencies and existing
independent unit assertions without copying any production implementation.

The frozen six-blocker scratch `curl_http_client.lua` is an older implementation.
It still uses `data-raw`, forces `--request POST`, and lacks `--globoff`; copying
it would discard the foreign owner's body-pipe and other fixes. It must never
be the source of the composed native engine. The six-blocker coordinator and
deadline ledger are separate design inputs, not proof that composition exists.

The native owner should publish and review the extension on their latest core.
If an extraction is approved, move that exact current core once to
`adapters/curl_http_client.lua`, preserving its history and native ownership,
then place the managed public wrapper at `adapters/http_client.lua` in the same
reviewable tranche. There must be one native implementation and one acquisition
ledger. Do not maintain an old copied core alongside a newer one, monkey-patch
public methods, or infer settlement from a boolean callback.

## Smallest viable extension contract

The existing stronger API is GET-only (`get_owned`, lines 779–815). Public POST,
streaming POST and downloads call private `start_request` without an operation.
A wrapper around existing ports therefore cannot retain physical ownership for
all managed requests. The minimum native API is additive and Linux-private:

1. `default_timeout_ms()` reads the existing native default rather than creating
   another policy value.
2. `preflight(url, headers, body, options)` performs the same admitted metadata
   checks as dispatch, without allocation, timer, cancellation, spawn, lookup or
   file writes. Factor the existing URL/body NUL, transport, redirect, header and
   argv admission once and consume it from both paths; do not create parallel
   validators. Reject invalid replacement metadata before touching an incumbent.
   Preflight must not consume or retain the body pipe. A first owned dispatch
   must preserve existing late-composition/allocated-handle refusal semantics;
   do not rewrite that lifetime merely to remove a second pure validation.
3. `dispatch_owned(url, headers, body, options, on_chunk, on_done)` starts any
   admitted GET/POST/download/stream transaction through the existing private
   `start_request` with a real operation. It does not allocate a second body
   owner, reinterpret caller bytes or release descriptors through another helper.
4. Its operation retains existing `cancel`, `is_settled`, and `on_settled`
   semantics. Add `request_cancel()` as an explicit signal/cleanup-acceptance
   receipt, separate from `cancel()`'s physical settlement result. Owned public
   intent fences delivery even if termination refuses. For the historical
   boolean public API, a refused cancellation retains activity and delivery
   eligibility, as the independent existing assertions require. Neither receipt
   can authorize successor acquisition before exact exit and all close ACKs.
5. `options.on_native_terminal(result)` is a private once-only logical observer.
   Invoke after `request.terminal` and its result are fixed and logical activity
   is removed, before cleanup may synchronously acknowledge settlement. Guard
   callbacks and stale generations; observer exceptions use fixed diagnostics.
   The observer cannot close handles or mark the operation settled. Delivery
   suppression and retry decisions remain coordinator-owned; physical
   `on_done`/`on_settled` remain gated by `settle_owned`. Owner review should use a
   safe result snapshot so observer mutation cannot alter a pending completion.

The proposed boundary introduces no shared HttpClient port requirement and no
production test override. Core callers keep their established public signatures;
the managed wrapper binds the native-private API explicitly after owner approval.

## Private routing and observed native evidence

The coordinator also needs admitted private `proxy_selection` and capability
inputs threaded through request normalization into `curl_args` and the actual
request record. These cannot be implemented by adding options to a public
wrapper: current `request_options` drops them at lines 472–483.

Selected proxy URI and bypass controls belong only in the existing quoted stdin
config. Never append them to argv, diagnostic strings or logs. Direct routing
must explicitly disable inherited proxy use; selected routing must obey the
canonical policy's environment/bypass precedence, including inherited NO_PROXY,
rather than quietly inheriting a second conflicting bypass decision. Reject
unrepresentable selection metadata before native acquisition/replacement.

Keep native curl TLS verification enabled. The routing bridge does not establish
PAC retrieval authentication, proxy SSPI support, owned Ollama server routing,
per-redirect PAC admission or an installed OS-store trust result.

Actual `%{http_connect}` and, only when supported, `%{proxy_used}` go to a distinct
bounded stderr trailer. Maintain the original status marker and exact buffered
body allowance. Size the private tail for the complete combined trailers, handle
every split boundary, and remove only the actual terminal trailer from public
diagnostics. A version probe is capability input, not proof that a request used
a proxy; missing/malformed metrics remain unavailable. The probe and request
must resolve the same executable or conservatively invalidate capabilities when
identity is not established. Preserve original ordinary core diagnostics when
no managed private selection is present; managed proxy-bearing native diagnostic
text must not leak credential suffixes after truncation. Retain observed safe
exit/status receipts, not heuristics from selected route or exception text.

Annotate final buffered/stream results only at `maybe_complete` (lines 418–426),
after actual exit and both output EOFs, without weakening complete error-body
admission (exit 0 or 22, no truncation). Early timer, write, allocation or read
refusals cannot acquire fabricated transport provenance. Logical observer
receipts and physical final callbacks must carry consistent safe evidence.

## Native invariants that cannot move to the coordinator

Preserve all owner changes, including:

- `BodyPipe.allocate`, nonblocking anonymous pipe ends, original descriptor
  identity, FD3 inheritance and parent read-handle retirement.
- Both raw-descriptor and transferred-handle cleanup debts, reused-descriptor
  protection, `retain_body_cleanup`, process-exit retry and all exact close ACKs.
- Literal/large body delivery independently of config-line size; literal NUL
  admission while JSON-escaped NUL and leading `@` retain their meaning.
- `--disable` first, `--globoff`, POST selected by data, native POST303 conversion,
  present empty-header semicolon semantics and HTTPS redirect fences.
- Complete error-body admission, overflow detection, exact buffered limits and
  marker-like caller text.
- Existing `NativeTimer.start` relative-clock refresh, termination refusal,
  bounded delivery and settlement behavior.

The managed absolute-deadline ledger may add one separate native timer for total
lookup/queue/curl budget, delegating arming to the foreign owner's published
`infra.native_timer`. It owns only its own timer close ACK. It cannot claim the
HTTP timer, anonymous pipe or child has retired. Native curl timeout remains a
remaining-budget protection; final logical success is additionally fenced at
coordinator clock boundaries and delayed deadline-close ACKs.

## Dependencies and honest stop point

First publish the foreign core and helpers, then native-owner extension review,
then exact one-core extraction if approved, then coordinator/wrapper binding,
then independent regression and native qualification. Rebase the seam proposal
onto the owner's actual published preimage; no stale patch application is safe.
The shared proxy policy JSON/Lua and any suite registrations retain their
existing coordinated owners and generators.

This is a small API surface, not a no-core-change adapter. The exact blockers
are GET-only physical ownership, dropped private routing inputs, absent native
metrics and absent pre-close logical observation. A genuinely tiny wrapper-only
solution is unavailable. Without native-owner approval/publication, the correct
stop point is this design and the six-blocker controls, not partial live routing.

## Qualification plan (all unexecuted for this proposal)

1. Run the exact foreign owner's unchanged
   `tests/unit/meta/test_http_client_curl.lua` and native body-pipe/cleanup/limit,
   curlrc, redirect/header/transport assertions against the published core first.
   Keep every body and expected outcome; report failed/skipped/unexecuted gates.
2. Add native-private API controls for all four request shapes, zero-side-effect
   invalid preflight, incumbent preservation, sole allocation, late construction
   refusal, signal refusal versus physical cancellation, and observer exactly
   once before synchronous/held close ACKs. Test observer reentrancy/throw without
   releasing debt or changing future delivery.
3. Replay the six-blocker public controls with the same original independent
   assertion bodies, then deadline/coordinator/GIO controls; fixture migration
   may add required independent native ports but must not regenerate outcomes.
4. Use actual owned GIO/curl/loopback fixtures: fixed and ordered PAC proxy/DIRECT
   choices, total lookup/queued/transport budget, predecessor refusal and exit,
   split/missing/truncated native metrics, unsupported curl capability, credential
   privacy across argv/logs/receipts, and no second child before physical ACK.
5. Run proportional verify-change gates sequentially with native suites, then
   targeted Linux native CI, package/install acceptance on final source SHA.
   Existing per-hop PAC, updater file lease, Ollama ownership, enterprise auth,
   trust and physical-host validations remain explicit TODO62/16/38 scope.

No success counts from an older extracted engine qualify this future composition.
