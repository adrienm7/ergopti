"""Run the private tar fixture through the existing sole subreaper guardian."""
from pathlib import Path
import hashlib
import importlib.util
import os
import stat
import sys

GUARDIAN_SHA256 = "a9d754ef0da5cac503b957b4f7d9260e91e685c1c3288d7c8a0c587832f44232"


def main():
    # Explicit fixture inputs only; no installed helper/path fallback.
    if len(sys.argv) != 7:
        raise ValueError("expected guardian, Lua, driver, candidate, helper, session")
    guardian, lua, driver, candidate, helper, session = map(Path, sys.argv[1:])
    if not all(path.is_absolute() for path in (guardian, lua, driver, candidate, helper, session)):
        raise ValueError("absolute owned inputs required")
    if hashlib.sha256(guardian.read_bytes()).hexdigest() != GUARDIAN_SHA256:
        raise ValueError("immutable existing guardian preimage mismatch")
    info = session.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700:
        raise ValueError("private ordinary owned session required")
    evidence = session / "tar-evidence"
    evidence.mkdir(mode=0o700)  # Exclusive newly owned bounded receipts only.
    os.environ["ERGOPTI_RETAINED_TAR_GUARDIAN_PID"] = str(os.getpid())
    spec = importlib.util.spec_from_file_location("owned_retained_tar_subreaper", guardian)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # This exact existing guardian owns Popen, all wait receipts and rescue.
    # Lua publishes its own PID/birth/group before any fixture action; native
    # spawn publishes tar identity before returning to downstream supervision.
    return module.main([str(lua), str(candidate / "native_retained_tar.lua"),
                        str(driver), str(candidate), str(helper), str(session)])


if __name__ == "__main__":
    sys.exit(main())
