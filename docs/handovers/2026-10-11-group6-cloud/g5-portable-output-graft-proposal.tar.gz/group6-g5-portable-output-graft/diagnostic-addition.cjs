
	// Preserve child output before the original spawn assertions reject it.
	// Optional diagnostics cannot replace the original failure or extend its budget.
	if (result.error || result.signal !== null || result.status !== 0) {
		try {
			process.stderr.write(
				`PORTABLE_RECEIVER_FAILURE ${JSON.stringify({
					script,
					status: result.status,
					signal: result.signal,
					error_code: result.error?.code || null,
					stdout_tail: typeof result.stdout === 'string' ? result.stdout.slice(-8192) : '',
					stderr_tail: typeof result.stderr === 'string' ? result.stderr.slice(-8192) : '',
					native_qualified: false
				})}\n`
			);
		} catch {
			// A failed diagnostic sink leaves every original assertion authoritative.
		}
	}