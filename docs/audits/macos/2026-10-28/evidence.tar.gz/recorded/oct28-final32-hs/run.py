from pathlib import Path
import os,subprocess,hashlib,json,stat,re,datetime,time
from zoneinfo import ZoneInfo
R=Path('/workspace/ergopti-macos-verify-batch18-hs'); O=Path('/workspace/scratch/oct28-final32-hs'); FINAL='c71552b77386ae5eaf4cb0d0461f1b47e4da5d43'; A34='a34bc3f01be4072053db8fd03d4788504fe6f214'; TREE='2aa61ec29cebd49834e27ee751ad5121d95b7dd0'
def now(): return datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def physical():
 census=hashlib.sha256();n=0;total=0;bad=[]
 for row in git('ls-files','--stage','-z').split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,oid,stage=meta.split();assert stage==b'0'
  p=R/os.fsdecode(name);st=p.lstat();data=os.fsencode(os.readlink(p)) if stat.S_ISLNK(st.st_mode) else p.read_bytes(); found=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode();actual=b'120000' if stat.S_ISLNK(st.st_mode) else b'100755' if st.st_mode&0o111 else b'100644'
  if found!=oid or actual!=mode:bad.append(os.fsdecode(name))
  census.update(row+b'\0');n+=1;total+=len(data)
 assert not bad,bad[:20]
 return {'at_paris':now(),'index_tree':git('write-tree').decode().strip(),'tracked_entries':n,'physical_bytes':total,'census_sha256':census.hexdigest(),'mismatches':bad,'unstaged':git('diff','--name-only').decode(),'untracked':git('ls-files','--others','--exclude-standard').decode()}
def observe():
 parents={os.getpid()};pid=os.getppid()
 while pid>1:
  parents.add(pid)
  try:pid=int(Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[1])
  except (OSError,ValueError):break
 refs=[];unreadable=[];zombies=0
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name) in parents:continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   state=(p/'stat').read_text().split(') ',1)[1].split()[0]
   if state=='Z':zombies+=1;continue
   cmd=(p/'cmdline').read_bytes();env=(p/'environ').read_bytes();cwd=os.readlink(p/'cwd');hits=[]
   if str(R).encode() in cmd:hits.append('argv')
   if str(R).encode() in env:hits.append('environment')
   if cwd.startswith(str(R)):hits.append('cwd')
   for fd in (p/'fd').iterdir():
    try:
     if os.readlink(fd).startswith(str(R)):hits.append('fd');break
    except OSError:pass
   if hits:refs.append({'pid':int(p.name),'hits':hits,'cmd':cmd.replace(b'\0',b' ').decode(errors='replace')[:200]})
  except FileNotFoundError:pass
  except PermissionError:unreadable.append(int(p.name))
 return {'live_refs':refs,'unreadable_live_same_uid':unreadable,'preexisting_zombie_count':zombies,'scope':'Exact owned checkout provenance in live same-UID cwd/argv/environment/fd; no sanitized-child or zombie-reaping claim.'}
D={'state':'PREPARING','source_commit':FINAL,'source_tree':TREE,'worktree':str(R),'pid':os.getpid(),'started_paris':now(),'gates':[]}
def save(): (O/'receipt.json').write_text(json.dumps(D,indent=2)+'\n')
assert os.getuid()!=0
assert git('rev-parse','HEAD').decode().strip()=='4c6c8a8f03fe284a0dbe5a869366630eed18c03b'
assert git('write-tree').decode().strip()=='a5f0f58a19666301cbeec55f0d11fae3b561f836'
assert hashlib.sha256(git('diff','--cached','--binary','--full-index')).hexdigest()=='d16b614218ef14f6d503b994a67b9702b44f2e6ef4fcd1637a3a90dbcb1b2c2b'
D['before_apply']=physical(); assert not D['before_apply']['unstaged'] and not D['before_apply']['untracked']
D['before_observer']=observe();assert not D['before_observer']['live_refs'] and not D['before_observer']['unreadable_live_same_uid'];save()
patch=git('diff','--binary','--full-index',A34,FINAL);(O/'delta.patch').write_bytes(patch);D['delta_sha256']=hashlib.sha256(patch).hexdigest();subprocess.run(['git','apply','--check','--index',str(O/'delta.patch')],cwd=R,check=True);subprocess.run(['git','apply','--index',str(O/'delta.patch')],cwd=R,check=True)
D['after_apply']=physical();assert D['after_apply']['index_tree']==TREE and not D['after_apply']['unstaged'] and not D['after_apply']['untracked'];D['state']='RUNNING';save()
env=dict(os.environ);env['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH'];env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';env['USER']='agent';env['LOGNAME']='agent'
for key,leaf in [('TMPDIR','tmpdir'),('XDG_RUNTIME_DIR','xdg_runtime_dir'),('XDG_CACHE_HOME','xdg_cache_home'),('XDG_CONFIG_HOME','xdg_config_home'),('XDG_DATA_HOME','xdg_data_home'),('XDG_STATE_HOME','xdg_state_home')]:
 p=O/leaf;p.mkdir(mode=0o700,exist_ok=True);env[key]=str(p)
old=json.load(open('/workspace/scratch/oct28-merge7-qualification-hs/receipt.json'))
for x in old['gates']:
 name=x['name'];cmd=x['command'];b=physical();assert b['index_tree']==TREE and not b['unstaged'] and not b['untracked'];log=O/(name+'.log');start=time.monotonic()
 with log.open('wb')as f: p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 raw=log.read_bytes();text=raw.decode('utf-8',errors='replace');a=physical();assert a['index_tree']==TREE and not a['unstaged'] and not a['untracked']
 row={'name':name,'command':cmd,'actual_exit':p.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'log_sha256':hashlib.sha256(raw).hexdigest(),'source_before':b,'source_after':a};D['gates'].append(row);save();print(name,p.returncode,flush=True)
 if p.returncode: D['state']='FAILED';save();raise SystemExit(p.returncode)
mods=[];passed=0;failed=0;groups=[]
for g in D['gates']:
 if g['name'].startswith('hs-') and g['name'] not in ('hs-groups-inventory','hs-e2e'):
  s=Path(g['log']).read_text(errors='replace');pm=re.search(r'Passed tests:\s+(\d+)',s);fm=re.search(r'Failed tests:\s+(\d+)',s);mm=re.search(r'Total modules:\s+(\d+)',s);assert pm and fm and mm
  loaded=re.findall(r'^>>> Loading ([^\r\n]+)',s,re.M);assert int(pm[1])>0 and int(fm[1])==0 and len(loaded)==int(mm[1]);passed+=int(pm[1]);failed+=int(fm[1]);mods+=loaded;groups.append({'name':g['name'],'modules':len(loaded),'passed':int(pm[1]),'failed':int(fm[1])})
assert len(groups)==8 and len(mods)==len(set(mods));D['hs_partition']={'groups':groups,'passed':passed,'failed':failed,'modules':len(mods),'unique_modules':len(set(mods))};(O/'modules.json').write_text(json.dumps(mods,indent=2)+'\n')
s=(O/'hs-e2e.log').read_text(errors='replace');D['e2e_summary_lines']=[x for x in s.splitlines()if 'passed' in x.lower()or 'failed' in x.lower()or 'skip' in x.lower()][-15:]
D['after_observer']=observe();D['ended_paris']=now();D['actual_producer_exit']=0;D['state']='ALL_SELECTED_GATES_ACTUAL0';save();print(json.dumps(D['hs_partition']),flush=True)
