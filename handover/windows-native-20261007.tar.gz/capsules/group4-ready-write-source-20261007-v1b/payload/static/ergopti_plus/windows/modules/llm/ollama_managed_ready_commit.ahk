﻿; modules/llm/ollama_managed_ready_commit.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Durable Managed Ollama Enable Handoff
; DESCRIPTION:
; Uses the existing terminal config transaction and semantic TOML writer. A
; same-record ready ticket suspends only owned observation callbacks; independent
; rendered bytes and a fresh post-publication snapshot authorize their resumption.
; ==============================================================================

/** Opaque identity; all source bytes and process references stay in the owner. */
class OllamaManagedReadyWriteTicket {
	__New(Owner) {
		if !(Owner is OllamaManagedCoordinator)
			throw TypeError("A ready write ticket requires its genuine coordinator.")
		this.Owner := Owner
	}
}

/** Owns one real enable commit without replacing the ordinary config barrier. */
class OllamaManagedReadyCommit {
	__New(Coordinator, Port := 0) {
		if !(Coordinator is OllamaManagedCoordinator) || (Port != 0 && !(Port is Map))
			throw TypeError("Managed enable requires the existing ready coordinator.")
		if Port is Map
			for name, callback in Port
				if !HasMethod(callback, "Call")
					throw TypeError("Managed enable recording boundaries must be callable.")
		this.Coordinator := Coordinator
		this.Port := Port is Map ? Port.Clone() : Map()
		this.Ticket := 0
		this.Expected := 0
		this.Written := false
		this.Published := false
		this.Completed := false
		this.Committing := false
		this.Attempted := false
	}

	_Call(Name, Default, Arguments*) {
		local callable := this.Port.Get(Name, Default)
		return callable.Call(Arguments*)
	}

	Commit() {
		if this.Attempted
			return false
		this.Attempted := true
		this.Committing := true
		try {
			return LLM_Menu_CommitMutation("the managed Ollama enabled-state change",
				ObjBindMethod(this, "_Mutate"), ObjBindMethod(this, "_Apply"),
				ObjBindMethod(this, "_Write"), 0, this.Port.Get("acquire", 0),
				this.Port.Get("settle", 0), this.Port.Get("collect", 0),
				ObjBindMethod(this, "_Prepare"), ObjBindMethod(this, "_Publish"))
		} finally {
			this.Committing := false
			if !this.Completed && this.Ticket is OllamaManagedReadyWriteTicket
				this.Coordinator.AbortReadyWrite(this.Ticket)
		}
	}

	_Mutate(Candidate) {
		if !this.Committing || !(Candidate is Map) || !this.Coordinator.ReadyForUse()
			return false
		local captured := this.Coordinator.Record["captured"]
		if Candidate.Get("backend", "") != captured["backend"] || Candidate.Get("model", "") != captured["model"]
				|| !(Candidate.Get("enabled", 0) is Integer) || Candidate["enabled"] != false
			return false
		Candidate["enabled"] := true
		return true
	}

	_Prepare(Candidate) {
		if !this.Committing || this.Ticket is OllamaManagedReadyWriteTicket
				|| !(Candidate.Get("enabled", 0) is Integer) || Candidate["enabled"] != true
			return false
		this.Ticket := this.Coordinator.BeginReadyWrite()
		return this.Ticket
	}

	_Write(Path, Updates) {
		if !this.Committing || !(this.Ticket is OllamaManagedReadyWriteTicket) || this.Written
			return false
		local build := this._Call("build", TOML_BuildConfigUpdatedContent, Path, Updates)
		if !(build is Map) || !(build.Get("status", 0) is String) || build["status"] != "ok"
				|| !(build.Get("kind", 0) is String) || build["kind"] != "rendered"
				|| !(build.Get("content", 0) is String) || !(build.Get("source_present", 0) is Integer)
				|| build["source_present"] != 1
				|| !(build.Get("source_content", 0) is String)
			return false
		local row := this.Coordinator._ReadyWriteEntry(this.Ticket)
		if !(row is Map) || Path != row["captured"]["source"]["path"]
				|| !_LLM_Menu_EnableSourceMatches(row["captured"]["source"],
					Map("path", Path, "bytes", _OllamaManagedReadyUtf8Bytes(build["source_content"])))
			return false
		this.Expected := Map("path", Path, "bytes", _OllamaManagedReadyUtf8Bytes(build["content"]))
		if !this.Coordinator.SealReadyWrite(this.Ticket, this.Expected)
			return false
		local written := this._Call("writer", TOML_ConfigBatchWrite, Path, Updates)
		if !(written is Integer) || written != true
			return false
		local source := this._Call("read_source", _LLM_Menu_EnableReadSource)
		if !this.Coordinator.AcknowledgeReadyWrite(this.Ticket, source)
			return false
		this.Written := true
		return true
	}

	_Publish(CandidateFeatures, CandidateMenu, Ticket) {
		if !this.Committing || Ticket != this.Ticket || !this.Written || this.Published
				|| !(this.Coordinator._ReadyWriteEntry(Ticket) is Map)
			return false
		local published := this._Call("publish", _LLM_Menu_PublishCandidate, CandidateFeatures, CandidateMenu)
		this.Published := published is Integer && published == true
		return this.Published
	}

	_Apply(Candidate) {
		if !this.Committing || !this.Written || !this.Published || this.Completed
				|| !this.Coordinator.FinishReadyWrite(this.Ticket)
			return false
		local applied := this._Call("apply", _LLM_Menu_ApplyToggleCommitted, Candidate, false)
		if !(applied is Integer) || applied != true || !this.Coordinator.ReadyForUse()
			return this.Coordinator.Stop() && false
		this.Completed := true
		return true
	}
}

/** Encodes the exact existing TOML owner's BOM-bearing image without a terminator. */
_OllamaManagedReadyUtf8Bytes(Content) {
	if !(Content is String)
		throw TypeError("Rendered configuration bytes require a String.")
	local size := StrPut(Content, "UTF-8") - 1, bytes := Buffer(size, 0)
	if size
		StrPut(Content, bytes, "UTF-8")
	return bytes
}
