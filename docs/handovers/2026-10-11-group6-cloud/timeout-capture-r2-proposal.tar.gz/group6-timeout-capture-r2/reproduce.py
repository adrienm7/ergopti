"""Replay an unadopted two-file proposal against its exact existing checkout."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("repository", type=Path)
parser.add_argument("--ruff", default="ruff")
options = parser.parse_args()
root = options.repository.resolve()
packet = Path(__file__).resolve().parent
manifest = json.loads((packet / "manifest.json").read_text())
for name, binding in manifest["files"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == binding["preimage"]
    for role in ("preimage", "candidate"):
        assert hashlib.sha256((packet / role / name).read_bytes()).hexdigest() == binding[role]
version = subprocess.run([options.ruff, "--version"], check=True, capture_output=True, text=True)
assert version.stdout.strip() == "ruff 0.15.8"
files = [str(packet / "candidate" / name) for name in manifest["files"]]
subprocess.run([options.ruff, "format", "--check", "--config", str(root / "pyproject.toml"), *files], check=True)
subprocess.run([options.ruff, "check", "--config", str(root / "pyproject.toml"), *files], check=True)
comparison = packet / manifest['first_tested_fixture']['path']
assert hashlib.sha256(comparison.read_bytes()).hexdigest() == manifest['first_tested_fixture']['sha256']
for subject, extra, expected_status, counts in [
    ('original', ['--additional-only'], 1, (6, 10, 1, 0)),
    ('first', ['--cancellation-only'], 1, (6, 11, 0, 0)),
    ('candidate', [], 0, (75, 0, 0, 0)),
]:
    result = subprocess.run([sys.executable, '-I', '-B', str(packet / 'receive.py'), subject, '--repository', str(root), *extra], capture_output=True, text=True)
    sys.stdout.write(result.stdout)
    sys.stderr.write(result.stderr)
    assert result.returncode == expected_status, (subject, result.returncode)
    summary = re.findall(r'receiving subject=\w+ total=(\d+) failures=(\d+) errors=(\d+) skips=(\d+)', result.stdout)
    assert len(summary) == 1 and tuple(map(int, summary[0])) == counts, (subject, summary)
