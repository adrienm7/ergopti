local root, os_name, module = arg[1], arg[2], arg[3]
local driver = root .. "/static/ergopti_plus/" .. os_name
local shared = root .. "/static/ergopti_plus/_shared/lua"
package.path = driver .. "/?.lua;" .. driver .. "/?/init.lua;" .. shared .. "/?.lua;" .. shared .. "/?/init.lua;" .. driver .. "/tests/?.lua;" .. driver .. "/tests/?/init.lua;" .. driver .. "/tests/stubs/?.lua;" .. package.path
if os_name == "macos" then _G.hs = require("tests.stubs.hs") end
local factory = require("menu.renderer")
local original_new = factory.new
factory.new = function(deps)
 local renderer, err = original_new(deps)
 if not renderer then return renderer, err end
 local original_template = renderer.template_rows
 renderer.template_rows = function(key, commands, getters, children)
  if key == "tap_hold_key_head" then getters.tap_hold_key_hold_caption = function() return 123 end end
  return original_template(key, commands, getters, children)
 end
 return renderer, err
end
local helpers = require("tests.helpers")
require(module)
local r = helpers.get_results()
print(string.format("RESULT %s: %d passed / %d failed", os_name, r.passed, r.failed))
for _, f in ipairs(r.failures) do print(f.name, f.err) end
assert(r.passed > 0 and r.failed == 0)
