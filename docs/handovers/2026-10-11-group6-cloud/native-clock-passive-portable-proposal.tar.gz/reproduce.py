"""Serial focused portable receiver; never canonical refs or native qualification."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,tempfile
BASE=Path(__file__).resolve().parent
facts=json.loads((BASE/'runtime-source-inventory.json').read_text())['files']
for relative,pin in facts.items():
    source=BASE/'runtime-source'/relative
    assert source.stat().st_size==pin['bytes']
    assert hashlib.sha256(source.read_bytes()).hexdigest()==pin['sha256']
subprocess.run([sys.executable,'-I','-B',str(BASE/'prove_source.py')],check=True)
work=Path(tempfile.mkdtemp(prefix='passive-receive-',dir=BASE));receipts=[]

def namespace(name,mutate=None):
    root=work/name/'source';root.parent.mkdir();shutil.copytree(BASE/'runtime-source',root)
    if mutate is not None:mutate(root)
    options={'cwd':root,'stdout':subprocess.DEVNULL,'stderr':subprocess.PIPE,'check':True}
    for args in (['init','-q'],['config','user.name','Portable receiving'],['config','user.email','portable@example.invalid'],['add','--all'],['commit','-qm','Isolated passive receiving inputs']):
        subprocess.run(['git','-c','core.hooksPath=/dev/null',*args],**options)
    private=root.parent/'private-tmp';private.mkdir(mode=0o700)
    return root,private

def receive(name,command,root,private,expected,red=False):
    environment=os.environ.copy();environment['TMPDIR']=str(private)
    environment['NODE_PATH']='/workspace/ergopti/node_modules'
    stdout=root.parent/(name+'.stdout');stderr=root.parent/(name+'.stderr')
    with stdout.open('wb') as out,stderr.open('wb') as err:
        result=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err,timeout=180)
    raw=stderr.read_text();out=stdout.read_text()
    record={'name':name,'exit':result.returncode,'stdout_sha256':hashlib.sha256(stdout.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(stderr.read_bytes()).hexdigest(),'qualification':'PORTABLE_ONLY_NATIVE_MODELED','expected':expected,'red':red}
    if command[0]==sys.executable:
        count=re.search(r'Ran (\d+) tests?',raw);assert count,(name,str(root.parent))
        assert int(count[1])==expected,(name,count[1],expected)
        summary=re.search(r'FAILED \(([^)]+)\)',raw)
        numbers={key:int(value) for key,value in re.findall(r'(failures|errors|skipped)=(\d+)',summary[1] if summary else '')}
        record.update({'tests':expected,'failures':numbers.get('failures',0),'errors':numbers.get('errors',0),'skips':numbers.get('skipped',0)})
        if red:assert result.returncode!=0 and record['failures']>0 and record['errors']==0 and record['skips']==0,(name,record,str(root.parent))
        else:assert result.returncode==0 and '\nOK\n' in raw and not summary,(name,str(root.parent))
    elif red:assert result.returncode!=0 and 'AssertionError' in raw and 'MODULE_NOT_FOUND' not in raw,(name,str(root.parent))
    else:assert result.returncode==0 and f'CLOCK_RECEIVER controls={expected} native=false official=false' in out,(name,str(root.parent))
    receipts.append(record);(work/'receipts.json').write_text(json.dumps({'state':'PORTABLE_ONLY_NO_NATIVE_OR_API_CREDIT','receipts':receipts},indent=2)+'\n')
    print(json.dumps(record,sort_keys=True),flush=True)

root,private=namespace('candidate')
receive('original156',[sys.executable,'-I','-B',str(root/'tools/test/macos_native_http_receiving_facts_test.py')],root,private,156)
receive('passive21',[sys.executable,'-I','-B',str(root/'tools/test/macos_native_http_clock_passive_receiving_controls.py')],root,private,21)
node=shutil.which('node');assert node
receive('receiver32',[node,str(root/'tools/test/test-native-http-clock-evidence.cjs')],root,private,32)

wire_relative='static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
collector_relative='tools/ci/native_http_clock_evidence.cjs'
registry_relative='tools/test/test-managed-ollama-protocol.cjs'
inverses=json.loads((BASE/'formatted-literal-inverses.json').read_text())
wire_change=inverses[wire_relative]['replacements'][0]

def omit_callback(root):
    path=root/wire_relative;source=path.read_text();assert source.count(wire_change['candidate_span'])==1
    original=wire_change['original_span'].replace('        trust_operation=None,\n','        trust_operation=None,\n        passive_receiving=None,\n',1)
    path.write_text(source.replace(wire_change['candidate_span'],original,1))

# The classifier omission affects only the new callback catch, leaving every
# original guard/R2 cancellation path byte-exact in this controlled mutant.
def swallow_callback_signal(root):
    path=root/wire_relative;source=path.read_text();begin=source.index('            except BaseException as observation_failure:',source.index('        if passive_receiving is not None:'))
    end=source.index('        if trust_operation == "add":',begin)
    block=source[begin:end];assert 'Native fixture cancelled' in block
    replacement='''            except BaseException as observation_failure:
                if failure is None and not isinstance(observation_failure, Exception):
                    failure = observation_failure
'''
    path.write_text(source[:begin]+replacement+source[end:])

def omit_integer_token(root):
    path=root/collector_relative;source=path.read_text();needle="integerToken(parsed, 'version') &&";assert source.count(needle)==1;path.write_text(source.replace(needle,'true &&',1))

def omit_alias_admission(root):
    path=root/collector_relative;source=path.read_text()
    for owner in ('named','before','after','final'):
        needle=owner+'.nlink === 1n &&';assert source.count(needle)==1;source=source.replace(needle,'',1)
    path.write_text(source)

def omit_selector(root):
    path=root/registry_relative;source=path.read_text();needle="\tcases.push(['tools/test/macos_native_http_clock_passive_receiving_controls.py', 21]);\n";assert source.count(needle)==1;path.write_text(source.replace(needle,'',1))

for name,mutation,language,census in (
    ('omitted_callback',omit_callback,'python',21),
    ('swallowed_callback_signal',swallow_callback_signal,'python',21),
    ('omitted_integer_token',omit_integer_token,'node',32),
    ('omitted_alias_admission',omit_alias_admission,'node',32),
    ('omitted_selector',omit_selector,'node',32),
):
    root,private=namespace(name,mutation)
    command=[sys.executable,'-I','-B',str(root/'tools/test/macos_native_http_clock_passive_receiving_controls.py')] if language=='python' else [node,str(root/'tools/test/test-native-http-clock-evidence.cjs')]
    receive(name,command,root,private,census,red=True)
print(json.dumps({'terminal':True,'logs':str(work),'successful_candidate_suites':3,'expected_assertion_red_controls':5,'native_or_api_credit':False},sort_keys=True))
