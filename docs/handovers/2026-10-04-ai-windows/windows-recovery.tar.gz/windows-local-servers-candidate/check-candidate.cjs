// windows-local-servers-candidate/check-candidate.cjs
'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const root = '/workspace/ergopti';
const candidates = ['local_servers.ahk', 'local_server_menu.ahk', 'test_local_servers.ahk', 'test_local_server_menu.ahk', 'test_local_server_write_admission.ahk'].map(
  (name) => path.join(__dirname, name)
);
let lint = fs.readFileSync(path.join(root, 'tools/lint/lint-conventions.js'), 'utf8');
lint = lint.slice(0, lint.indexOf('const ahkSourceDirs'));
lint = lint.replace(/^#!.*\n/, '').replace(/^import .*;\n/gm, '').replace(
  /const REPO_ROOT = [\s\S]*?;\n/, 'const REPO_ROOT = ' + JSON.stringify(root) + ';\n'
);
const prelude = 'const {readFileSync,writeFileSync,readdirSync,statSync}=require("fs"); '
  + 'const {join,relative,extname}=require("path"); const {execSync}=require("child_process"); '
  + 'const sharedPaths=require(' + JSON.stringify(path.join(root, 'tools/lib/paths.cjs')) + ');\n';
const checks = '\nfor(const candidate of candidates){checkFileHeader(candidate);'
  + 'checkSectionSpacing(candidate);checkBannerAlignment(candidate);'
  + 'checkAhkAntiPatterns(candidate);checkAhkStringEscaping(candidate);}'
  + 'if(totalViolations)throw Error(totalViolations+" scoped violations");'
  + 'console.log("PASS: exact repository convention functions on 5 scratch candidates");';
vm.runInNewContext(prelude + lint + checks, { require, console, process, candidates });
let capture = fs.readFileSync(path.join(root, 'tools/test/test-ahk-loop-capture.cjs'), 'utf8');
capture = capture.slice(0, capture.indexOf('selfTest();\n\nconst findings'));
vm.runInNewContext(capture + '\nselfTest(); for(const candidate of candidates){'
  + 'const findings=analyse(fs.readFileSync(candidate,"utf8"));'
  + 'if(findings.length)throw Error(JSON.stringify(findings));}'
  + 'console.log("PASS: repository closure analyser and self-tests on 5 scratch candidates");',
{ require, console, process, __dirname: path.join(root, 'tools/test'), candidates });
for (const candidate of candidates) {
  const bytes = fs.readFileSync(candidate);
  if (!bytes.subarray(0, 3).equals(Buffer.from([0xEF, 0xBB, 0xBF])) || bytes.includes(13)) {
    throw Error('Encoding failed: ' + candidate);
  }
}
console.log('PASS: UTF-8 BOM and LF on 5 scratch candidates');
const verify = require(path.join(root, 'tools/test/verify-change.cjs'));
console.log('Selected normal verification gates:', [...verify.selectGates([
  'static/ergopti_plus/windows/modules/llm/local_servers.ahk',
  'static/ergopti_plus/_shared/modules/llm/local_server_menu.ahk',
  'static/ergopti_plus/windows/tests/unit/test_local_servers.ahk',
  'static/ergopti_plus/windows/tests/unit/test_local_server_menu.ahk',
  'static/ergopti_plus/windows/tests/unit/test_local_server_write_admission.ahk'
]).keys()].join(', '));
