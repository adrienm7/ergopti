# Direct managed daemon and listener source

The optional managed mode keeps the source PowerShell task and original guardian/staging/READY gates. Its daemon is the captured leased executable with argv serve. A child-only sorted Unicode environment overrides OLLAMA_HOST and OLLAMA_MODELS without changing the parent. The old wrapper default remains byte-equivalent by whole reversal. Partial process creation still belongs to the existing call-scoped failure carrier; no PID lookup becomes an adoption capability.

Listener observation borrows the exact original daemon process and Job handles, preventing native close during the call and rechecking cancellation before publication. The native IPv4 owner table admits one exact loopback listening row belonging to that still-live original process/job. Foreign/wildcard/ambiguous/malformed/terminal observations refuse; absence stays pending under the unchanged workflow deadline.

Managed HTTP preserves its selected URL/origin bytes and explicit direct-proxy policy, while typed local resolve and ipv4 bind localhost to the authenticated127.0.0.1 endpoint. The connection policy and URL are captured before yielding preflight effects; post-Send setters refuse. No system hosts/proxy/config change or fallback is introduced. Version/tags/model/ready paths reuse this current listener fence.

Fourteen recording controls and six whole-exact causal profiles are prepared, not executed. Native same-version foreign IPv6 and IPv4 receiving, process/environment identity, legacy behaviour and retirement remain Root qualification requirements. Canonical menu/init, archive limits and complete inference admission are still open; this is not Group4 readiness.
