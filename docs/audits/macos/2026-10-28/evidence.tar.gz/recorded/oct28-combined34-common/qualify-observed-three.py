from pathlib import Path
import datetime,hashlib,json,re,subprocess
from zoneinfo import ZoneInfo
s=Path('/workspace/scratch/oct28-combined34-common');r=Path('/workspace/ergopti-macos-final-common')
def load(name):return json.loads((s/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
receipt=load('receipt.json');go=load('go.json');exit_record=load('tool-exit.json');observer=load('residual-observer.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==go['commit']
assert receipt['physical_initial']['index_tree']==receipt['physical_final']['index_tree']==go['tree']
for state in [receipt['physical_initial'],receipt['physical_final']]:
 assert not state['mismatches'] and not state['unstaged'] and not state['untracked']
assert receipt['physical_initial']['digest']==receipt['physical_final']['digest']
raw=(s/'js.log').read_bytes();text=raw.decode(errors='replace');rows=re.findall(r'^  (PASS|FAIL) (\d+)/(\d+) — (.*)$',text,re.M)
assert len(rows)==529 and {int(x[1])for x in rows}==set(range(1,530)) and all(x[2]=='529'for x in rows)
failed=[x for x in rows if x[0]=='FAIL'];assert {int(x[1])for x in failed}=={250,474,483},failed
assert 'locale catalogue completeness' in failed[0][3] and 'raw config-key and command-id literals' in failed[1][3] and 'timing and size constant names' in failed[2][3]
assert 'NS_PER_MS gained a copy in macos/adapters/unicode_carrier.lua' in text
gates=receipt['gates'];assert len(gates)==19
assert [x['actual_exit']for x in gates if x['name']=='js']==[1]
assert all(x['actual_exit']==0 for x in gates if x['name']!='js') and exit_record['actual_child_wait_exit']==1
assert observer['qualified'] and not observer['live_refs'] and not observer['unreadable_live_same_uid']
not_run=re.search(r'(\d+) case\(s\) in (\d+) check\(s\) were NOT EXECUTED on this host:',text);assert not_run and not_run.groups()==('1','1')
pins=[]
for path in ['static/ergopti_plus/_shared/data/locales/'+code+'.json'for code in ['en','da','it','nl','no','sv']]+['static/ergopti_plus/windows/ui/menu/menu_gestures.ahk','static/ergopti_plus/macos/adapters/unicode_carrier.lua']:
 item={'path':path,'refs':{}}
 refs=[go['commit'],go['base_dev']]
 if not path.endswith('unicode_carrier.lua'):refs.append('80e8092f2051ad4927dcc880f9585a0e69f6613a')
 for ref in refs:
  data=subprocess.check_output(['git','show',ref+':'+path],cwd=r);item['refs'][ref]={'sha256':hashlib.sha256(data).hexdigest(),'git_blob':subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=r,text=True).strip()}
 assert len({x['sha256']for x in item['refs'].values()})==1
 pins.append(item)
(s/'observed-failure-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
qualification={'state':'COMPLETE_WITH_THREE_UPSTREAM_FAILURES','overall_green':False,'qualified_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_commit':go['commit'],'source_tree':go['tree'],'canonical_js_checks':{'planned':529,'completed':529,'unique_indices_complete':True,'passed_checks':526,'failed_checks':3,'failed_check_details':failed,'actual_js_exit':1,'host_specific_cases_not_executed':{'count':1,'checks':1,'description':'Pre-existing AHK host-specific cases remain explicitly not executed, never passed.'}},'actual_child_wait_exit':1,'all_other_gates_actual_zero':True,'gates':[{'name':x['name'],'actual_exit':x['actual_exit'],'command':x['command']}for x in gates],'source_physical_invariant':receipt['physical_final'],'residual_observer':observer,'native_darwin_executed':False,'failure_source_pins':str(s/'observed-failure-source-pins.json'),'receipt_sha256':sha(s/'receipt.json'),'tool_exit_sha256':sha(s/'tool-exit.json'),'js_log_sha256':hashlib.sha256(raw).hexdigest(),'original_qualifier':{'path':str(s/'qualify.py'),'sha256':sha(s/'qualify.py'),'executed':False,'reason':'Its a-priori assertion expects only two protected failures. The actual run has a third incoming-dev duplicate-constant failure; preserve the original and qualify the observed red without weakening any gate.'},'scope':'One complete canonical Common run on final merge10/field-admission tree. Two protected upstream checks plus a new incoming-dev Unicode-carrier duplicate-constant check remain red. No tests disabled, retried or weakened. This qualification certifies completeness and provenance, never a passing suite.'}
(s/'qualification-observed-three.json').write_text(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'state':qualification['state'],'source':go['commit'],'counts':[526,3],'other_gates':18,'source_invariant':True,'observer_qualified':True,'qualification_sha256':sha(s/'qualification-observed-three.json')}))
