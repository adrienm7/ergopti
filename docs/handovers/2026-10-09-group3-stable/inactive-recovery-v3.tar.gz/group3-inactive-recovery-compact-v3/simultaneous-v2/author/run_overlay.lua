local packet = assert(arg[1])
local frozen = assert(arg[2])
local root = "/workspace/ergopti/static/ergopti_plus"
package.path = packet .. "/candidate/static/ergopti_plus/linux/?.lua;" .. packet .. "/candidate/static/ergopti_plus/linux/?/init.lua;" .. frozen .. "/candidate/static/ergopti_plus/linux/?.lua;" .. frozen .. "/candidate/static/ergopti_plus/linux/?/init.lua;" .. root .. "/linux/?.lua;" .. root .. "/linux/?/init.lua;" .. root .. "/_shared/lua/?.lua;" .. root .. "/_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local native_loop = require("luv")
require("tests.unit.modules.test_key_combinations")
local result = require("tests.helpers").get_results()
assert(native_loop == require("luv"))
print("SIMULTANEOUS_CONTROLLED " .. result.passed .. "/" .. result.failed)
os.exit(result.failed > 0 and 1 or 0)
