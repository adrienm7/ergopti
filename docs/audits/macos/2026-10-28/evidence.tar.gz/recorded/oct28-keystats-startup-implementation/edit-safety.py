from pathlib import Path
p=Path('static/ergopti_plus/macos/modules/keystats/log_manager.lua');s=p.read_text();s=s.replace('local _recovery = nil','local _recovery = nil\n\n--- Runtime fence mirroring the durable pending replay row until publication commits.\nlocal _local_ledger_replay_pending = false',1)
a=s.index('--- Replays the durable portion');s=s[:a]+'''--- Restore the exact replay owner's durable mode before publication or release.
--- A refusal retains its flag so teardown can retry without closing the database.
---@param db userdata
---@param job table|nil Exact recovery owner, when running cooperatively.
---@return boolean restored
local function _restore_replay_durability(db, job)
	local called, rc = pcall(db.exec, db, SqliteWriter.SYNCHRONOUS_PRAGMA)
	if not called or rc ~= sqlite3.OK then
		Logger.error(LOG, "Cannot restore the cache's durable commit mode; replay publication remains blocked.")
		return false
	end
	if job then job.durability_off = nil end
	return true
end

'''+s[a:]
s=s.replace('local started_ns, resumed_at = timer.absoluteTime(), state.offset or 0','local started_ns, resumed_at = timer.absoluteTime(), state.offset or 0\n\tlocal replay_job = _recovery',1)
s=s.replace('''	elseif _recovery then
		-- An interrupted replay restores it too (_cancel_aggregate_recovery).
		_recovery.durability_off = true
	end
	local function restore_durability()
		if _recovery then _recovery.durability_off = nil end
		if db:exec(SqliteWriter.SYNCHRONOUS_PRAGMA) ~= sqlite3.OK then
			Logger.error(LOG, "Cannot restore the cache's durable commit mode: %s.", tostring(db:errmsg()))
		end
	end''','''	elseif replay_job then
		-- An interrupted replay retains this exact restoration owner.
		replay_job.durability_off = true
	end
	local function restore_durability()
		return _restore_replay_durability(db, replay_job)
	end''',1)
s=s.replace('''		if status == "done" then
			restore_durability()''','''		if status == "done" then
			if not restore_durability() then return false, empty_cursor end''',1)
a=s.index('\tSqliteWriter.set_next_event_id(max_id + 1)',s.index('local function _persist_recovery_state'));b=s.index('\nend',a)
s=s[:a]+'''	local context_ok, context_json = pcall(json.encode, Aggregator.get_ngram_ctx() or {})
	if not context_ok or type(context_json) ~= "string" then
		Logger.error(LOG, "Cannot encode the replayed typing context; replay publication remains pending.")
		return false
	end
	local old_id = SqliteWriter.get_next_event_id()
	local published, failure = pcall(function()
		assert(db:exec("BEGIN TRANSACTION;") == sqlite3.OK, "cannot begin replay publication")
		SqliteWriter.set_next_event_id(max_id + 1)
		assert(SqliteWriter.persist_next_event_id() == true, "cannot publish the replayed event id")
		assert(db:exec(string.format("UPDATE meta SET value='%d' WHERE key='today_log_offset';", tonumber(cursor.offset) or 0)) == sqlite3.OK,
			"cannot publish the replayed cursor")
		assert(db:exec("UPDATE meta SET value=" .. _sq(cursor.date or "") .. " WHERE key='today_log_date';") == sqlite3.OK,
			"cannot publish the replayed date")
		assert(db:exec("UPDATE meta SET value=" .. _sq(context_json) .. " WHERE key='ngram_ctx_json';") == sqlite3.OK,
			"cannot publish the replayed context")
		assert(db:exec("COMMIT;") == sqlite3.OK, "cannot commit replay publication")
	end)
	if not published then
		local rolled_back, rollback_rc = pcall(db.exec, db, "ROLLBACK;")
		if not rolled_back or rollback_rc ~= sqlite3.OK then
			Logger.error(LOG, "Replay publication rollback remains pending.")
		end
		SqliteWriter.set_next_event_id(old_id)
		Logger.error(LOG, "Replay metadata publication refused: %s.", tostring(failure))
		return false
	end
	return true''' +s[b:]
s=s.replace('''		_persist_recovery_state(db, cursor)
		Rotation.set_offset''','''		if _persist_recovery_state(db, cursor) ~= true then return end
		Rotation.set_offset''',1)
s=s.replace('''			Logger.error(LOG, "The finished ledger replay could not be marked; the next start repeats it.")
		end
	end''','''			Logger.error(LOG, "The finished ledger replay could not be marked; the next start repeats it.")
			return
		end
		_local_ledger_replay_pending = false
	end''',1)
a=s.index('--- Runs one budgeted slice');s=s[:a]+'local _cancel_aggregate_recovery\n\n'+s[a:]
s=s.replace('if _recovery ~= job then return end\n\tjob.slice_start_ns','if _recovery ~= job or job.cancelled then return end\n\tjob.slice_start_ns',1)
s=s.replace('''	if coroutine.status(job.co) == "dead" then
		_recovery = nil
		_restore_live_aggregator(job.db)''','''	if coroutine.status(job.co) == "dead" then
		if job.durability_off and not _restore_replay_durability(job.db, job) then return end
		_recovery = nil
		if not _local_ledger_replay_pending then _restore_live_aggregator(job.db) end''',1)
s=s.replace('''		_recovery = nil
		_restore_live_aggregator(job.db)
	end
end

--- Starts the aggregate''','''		_cancel_aggregate_recovery()
	end
end

--- Starts the aggregate''',1)
s=s.replace('local function _cancel_aggregate_recovery()','_cancel_aggregate_recovery = function()',1)
s=s.replace('''	_recovery = nil
	local settled = true
	if job.handle''','''	job.cancelled = true
	local settled = true
	if job.handle''',1)
s=s.replace('''		if not settled then
			pcall(Logger.error, LOG, "Aggregate recovery timer cleanup remains pending: %s.", tostring(cancelled))
		end''','''		if settled then job.handle = nil
		else
			pcall(Logger.error, LOG, "Aggregate recovery timer cleanup remains pending: %s.", tostring(cancelled))
		end''',1)
s=s.replace('''	if job.durability_off then
		local called, rc = pcall(function() return job.db:exec(SqliteWriter.SYNCHRONOUS_PRAGMA) end)
		if not called or rc ~= sqlite3.OK then pcall(Logger.error, LOG, "Cannot restore the cache's durable commit mode after an interrupted replay.") end
	end''','''	if job.durability_off and not _restore_replay_durability(job.db, job) then settled = false end
	if settled then _recovery = nil end''',1)
s=s.replace('''	pcall(_restore_live_aggregator, job.db)
	return settled''','''	if not _local_ledger_replay_pending then pcall(_restore_live_aggregator, job.db) end
	return settled''',1)
s=s.replace('if _recovery ~= nil then return false end\n\tif not _resume_pending_rollover()', 'if _recovery ~= nil or _local_ledger_replay_pending then return false end\n\tif not _resume_pending_rollover()',1)
s=s.replace('local replay_state = db and _read_ledger_replay_state(db) or nil','local replay_state = db and _read_ledger_replay_state(db) or nil\n\t\t_local_ledger_replay_pending = replay_state ~= nil',1)
# In a same-process off/on cycle the cache's durable pending row remains the
# source of truth; do not replace a retained timer/durability cleanup owner.
s=s.replace('''	if _ingest_timer then
		if _physical_sink_generation''','''	if _recovery and _recovery.cancelled then return false end
	if _local_ledger_replay_pending and _recovery == nil then
		local db = SqliteWriter.get_db()
		if not db then return false end
		local replay_state = _read_ledger_replay_state(db)
		if replay_state == nil then
			Logger.error(LOG, "Pending local replay has no durable resume state; ingest remains blocked.")
			return false
		end
		_start_aggregate_recovery(db, replay_state)
	end

	if _ingest_timer then
		if _physical_sink_generation''',1)
# Both teardown paths retain the database while its exact recovery owner still
# owes timer retirement or restoration of its durable commit mode.
s=s.replace('''	local complete = _cancel_aggregate_recovery()
	local readers_ok''','''	local recovery_settled = _cancel_aggregate_recovery()
	local complete = recovery_settled
	local readers_ok''',1)
a=s.index('local function _release_failed_init_resources()');i=s.index('\tlocal db_ok, db_result_or_err',a);s=s[:i]+'''	if not recovery_settled then
		Logger.error(LOG, "Failed-init database close waits for recovery cleanup.")
		return false
	end
'''+s[i:]
s=s.replace('''	local complete = _cancel_aggregate_recovery()
	local ingest_timer = _ingest_timer''','''	local recovery_settled = _cancel_aggregate_recovery()
	local complete = recovery_settled
	local ingest_timer = _ingest_timer''',1)
a=s.index('function M.stop(opts)');i=s.index('\tif process_exit then',a);s=s[:i]+s[i:].replace('\tif process_exit then','\tif process_exit and not _local_ledger_replay_pending and recovery_settled then',1)
i=s.index('\telse\n\t\tlocal ingest_ok',a);s=s[:i]+s[i:].replace('\telse\n\t\tlocal ingest_ok','\telseif not _local_ledger_replay_pending and recovery_settled then\n\t\tlocal ingest_ok',1)
i=s.index('\tlocal db_ok, db_result_or_err',a);s=s[:i]+'''	if not recovery_settled then
		Logger.error(LOG, "Database close waits for exact recovery cleanup.")
		return false
	end
'''+s[i:]
p.write_text(s)
