from pathlib import Path
import os,stat,hashlib,json,subprocess,sys,datetime
from zoneinfo import ZoneInfo
R=Path('/workspace/ergopti-macos-release-linux');O=Path('/workspace/scratch/oct28-recommended-oracle-peer/revision2');P=O.parent
SUB='tools/test/test-recommended-defaults-rule.cjs';filename=str(R/SUB)
expected_tree=sys.argv[1]
env=os.environ.copy();env['PATH']='/workspace/toolchain/node-v22.22.2-linux-x64/bin:'+env['PATH'];env['USER']='agent';env['LOGNAME']='agent'
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def sha(data):return hashlib.sha256(data).hexdigest()
def physical(label):
 entries={};bad=[];total=0
 for line in git('ls-files','--stage','-z').split(b'\0'):
  if not line:continue
  info,path=line.split(b'\t',1);mode,oid,stage=info.split();assert stage==b'0'
  f=R/os.fsdecode(path);st=f.lstat();data=os.fsencode(os.readlink(f)) if stat.S_ISLNK(st.st_mode) else f.read_bytes()
  actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode();m=b'120000' if stat.S_ISLNK(st.st_mode) else(b'100755' if st.st_mode&0o111 else b'100644')
  if actual!=oid or m!=mode:bad.append(os.fsdecode(path))
  entries[os.fsdecode(path)]=(mode.decode(),oid.decode());total+=len(data)
 tree_entries={}
 for line in git('ls-tree','-r','-z',expected_tree).split(b'\0'):
  if not line:continue
  info,path=line.split(b'\t',1);mode,kind,oid=info.split();tree_entries[os.fsdecode(path)]=(mode.decode(),oid.decode())
 assert entries==tree_entries and not bad
 assert git('diff','--name-only')==b'' and git('ls-files','--others','--exclude-standard')==b''
 assert git('diff','--cached','--name-only').decode().splitlines()==[SUB]
 result={'label':label,'files':len(entries),'bytes':total,'stage_digest':sha(json.dumps(entries,sort_keys=True).encode()),'mismatches':bad,'expected_index_tree':expected_tree}
 (O/('physical-'+label+'.json')).write_text(json.dumps(result,indent=2)+'\n');return result
before=physical('before');source=(R/SUB).read_text();(O/'candidate-exact.cjs').write_text(source)
old=git('show','HEAD:'+SUB).decode();(O/'old-exact.cjs').write_text(old)
rows=[]
def run(name,command,expected,marker=None):
 with(O/(name+'.log')).open('wb')as f:rc=subprocess.run(command,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 data=(O/(name+'.log')).read_bytes();row={'name':name,'command':command,'actual_exit':rc,'expected_exit':expected,'log_sha256':sha(data)};rows.append(row);(O/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n');assert rc==expected,(name,rc)
 if marker:assert marker in data.decode(errors='replace'),name
 return data.decode(errors='replace')
node=['node',str(P/'compile-virtual.cjs'),filename]
run('normal-fixed',['node',filename],0)
count=run('negative-count',['node',str(O/'compile-count.cjs'),filename,str(O/'candidate-exact.cjs')],0)
run('old-exact',node+[str(O/'old-exact.cjs')],1,'registers the Infos command')
initial=(P/'candidate-exact.cjs').read_text();probes=[]
for driver in ['windows','macos','linux']:
 for kind in ['binding-string','helper-string','unused-reason']:
  probes.append(driver+'-'+kind+'-probe.cjs')
for driver in ['windows','macos']:probes.append(driver+'-handler-definition-string-probe.cjs')
for name in probes:
 recorded=(P/name).read_text();assert recorded.startswith(initial)
 rewritten=source+recorded[len(initial):];(O/name).write_text(rewritten)
 run(name[:-4],node+[str(O/name)],0)
after=physical('after');assert before['stage_digest']==after['stage_digest']
print(json.dumps({'actual_positive_exit':0,'negative_count':22,'known_decoy_replays':len(probes),'source_sha256':sha(source.encode()),'index_tree':expected_tree,'stage_digest_same':True}))
