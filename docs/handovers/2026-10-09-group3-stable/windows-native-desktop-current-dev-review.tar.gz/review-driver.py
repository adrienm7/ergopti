from pathlib import Path
import json,hashlib,subprocess,shutil
A=Path('/workspace/.ergopti-cloud/preparations/windows-native-desktop-source-prototype-v3');V=Path('/workspace/.ergopti-cloud/preparations/windows-native-desktop-source-prototype-v2');B=Path('/workspace/.ergopti-cloud/reviews/windows-native-desktop-source-v3-delta-independent');B.mkdir(mode=0o700);repo=Path('/workspace/ergopti')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(folder,index='SHA256SUMS'):
 rows=[]
 for line in (folder/index).read_text().splitlines():
  h,n=line.split('  ',1);assert not Path(n).is_absolute() and '..' not in Path(n).parts;assert sha(folder/n)==h;rows.append({'path':n,'sha256':h})
 return rows
seals=verify(A);assert len(seals)==152;assert sha(A/'SHA256SUMS')=='01eca523bcc83f1a9d58578deea6f4d720a699364a9bf81d96bc33ea993cd4a5';assert sha(A/'RECEIPT.json')=='e1e7393a0dc77d57fb13e0b271c6e2adb8139b1eab2e04c8ebc44c3ca5d113d0'
ancestors=[]
for row in json.loads((A/'ancestor-preservation.json').read_text()):
 folder=Path(row['packet']);assert sha(folder/'SHA256SUMS')==row['seal_index_sha256'];assert len(verify(folder))==row['seals'];ancestors.append(row)
pairs=json.loads((A/'source-pairs.json').read_text());assert pairs['origin_dev']=='e896bd3ee047eb4795b0bd13c2ac715d626042ea';joins=[]
runner='static/ergopti_plus/windows/tests/run_all.ahk';anchor=b'#Include unit/test_curl_proxy_auth_integration.ahk\n';incoming=b'#Include unit/test_curl_proxy_discovery.ahk\n';before=(V/'projection'/runner).read_bytes();after=(A/'projection'/runner).read_bytes();assert before.count(anchor)==1 and before.count(incoming)==0 and after.count(incoming)==1;assert before.replace(anchor,anchor+incoming)==after
for row in pairs['changed_paths']:
 file=row['file'];assert sha(A/'projection'/file)==row['after_sha256']
 if file!=runner:assert (A/'projection'/file).read_bytes()==(V/'projection'/file).read_bytes()
 for spec in [pairs['origin_dev']+':'+file,':'+file]:
  cp=subprocess.run(['git','show',spec],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if row['new']:assert cp.returncode!=0
  else:assert cp.returncode==0 and cp.stdout==(A/'preimage'/file).read_bytes() and hashlib.sha256(cp.stdout).hexdigest()==row['before_sha256']
  joins.append({'path':file,'spec':spec,'matches':True})
newcase=json.loads((A/'incoming-ordinary-include.json').read_text())
for spec in [pairs['origin_dev']+':'+newcase['file'],':'+newcase['file']]:
 cp=subprocess.run(['git','show',spec],cwd=repo,stdout=subprocess.PIPE,check=True);assert hashlib.sha256(cp.stdout).hexdigest()==newcase['sha256']
for p,name in [(V/'projection'/runner,'prior-v2-run_all.ahk'),(A/'projection'/runner,'current-v3-run_all.ahk'),(A/'preimage'/runner,'original-e896-run_all.ahk')]:shutil.copyfile(p,B/name)
for name in ['RECEIPT.json','forward.patch','inverse.patch','incoming-ordinary-include.json','ancestor-preservation.json']:shutil.copyfile(A/name,B/name)
(B/'source-joins.json').write_text(json.dumps(joins,indent=2)+'\n');(B/'original152seals.json').write_text(json.dumps(seals,indent=2)+'\n')
# Tiny independent source-order control consumes real unchanged V3/V2 reader ports.
source="""'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const packet='/workspace/.ergopti-cloud/preparations/windows-native-desktop-source-prototype-v3';
const {sharedRunnerSource}=require(packet+'/projection/tools/lib/ahk-runner-source.cjs');
const {scriptTokens}=require(packet+'/projection/tools/lib/script-source.cjs');
const read=file=>fs.readFileSync(path.join(packet,'projection',file),'utf8');
const runner='static/ergopti_plus/windows/tests/run_all.ahk';
const tokens=s=>scriptTokens(s,'.ahk').map(t=>[t.kind,t.value]);
const original=tokens(fs.readFileSync(path.join(__dirname,'original-e896-run_all.ahk'),'utf8'));
assert.deepEqual(tokens(sharedRunnerSource(read,'run_all.ahk')),original);
const anchor='#Include unit/test_curl_proxy_auth_integration.ahk\\n',incoming='#Include unit/test_curl_proxy_discovery.ahk\\n';
for(const [name,modified] of [['omitted',read(runner).replace(incoming,'')],['moved',read(runner).replace(anchor+incoming,incoming+anchor)]]){
 assert.throws(()=>assert.deepEqual(tokens(sharedRunnerSource(file=>file===runner?modified:read(file),'run_all.ahk')),original),{name:'AssertionError'});
}
console.log('PASS: complete e896 runner token/order identity; omission and name-preserving reorder CAUSAL RED; no native execution.');
"""
(B/'source-order.cjs').write_text(source);cp=subprocess.run(['node',str(B/'source-order.cjs')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10);(B/'source-order.log').write_bytes(cp.stdout);assert cp.returncode==0;print(cp.stdout.decode(),flush=True)
D=B/'roundtrip';D.mkdir()
for row in pairs['changed_paths']:
 if not row['new']:
  out=D/row['file'];out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(A/'preimage'/row['file'],out)
operations=[]
for reverse,patch in [(False,A/'forward.patch'),(True,A/'inverse.patch')]:
 for check in [True,False]:
  cmd=['git','apply','--whitespace=error']+(['--check'] if check else [])+[str(patch)];cp=subprocess.run(cmd,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert cp.returncode==0,cp.stderr;operations.append({'direction':'inverse' if reverse else 'forward','check':check,'exit':0})
 for row in pairs['changed_paths']:
  if not reverse:assert (D/row['file']).read_bytes()==(A/'projection'/row['file']).read_bytes()
  elif row['new']:assert not (D/row['file']).exists()
  else:assert (D/row['file']).read_bytes()==(A/'preimage'/row['file']).read_bytes()
assert verify(A)==seals
(B/'results.json').write_text(json.dumps({'current_source':pairs['origin_dev'],'sixteen_e896_and_stage0_joins':32,'fifteen_posts_V2_exact':True,'only_runner_delta':'exact incoming include after authentic curl_proxy_auth and before managed_curl_owner','new_ordinary_test_e896_and_stage0_exact':True,'complete_current_runner_tokens_order':'PASS','incoming_omit_and_reorder':'CAUSAL_RED','patch_roundtrip':operations,'V3_seals':152,'ancestors':ancestors,'native':'UNRUN','custody':'WINDOWS_PENDING','canonical_mutations':False},indent=2)+'\n');print('PASS bounded delta:32 source joins,15 exact prior posts,152+165+51+36+8 seals,4 roundtrip operations')
