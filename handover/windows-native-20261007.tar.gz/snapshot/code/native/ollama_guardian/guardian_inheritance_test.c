/* Recording ports exercise the actual lease state machine, not kernel identity. */
#include "guardian_inheritance.h"
#include <stdio.h>
#include <string.h>
typedef struct { uint32_t flags[4],sets[4],clears[4],get_fail,set_fail,clear_fail; } World;
static const uintptr_t handles[4]={11u,22u,33u,44u};
static size_t Slot(uintptr_t value) { size_t i;for(i=0u;i<4u;++i)if(handles[i]==value)return i;return 4u; }
static int Get(void *context,uintptr_t handle,uint32_t *flags,uint32_t *error) {
    World *world=context;size_t i=Slot(handle);
    if(i==4u){*error=6u;return 0;}
    if(world->get_fail==i+1u){*error=5u;return 0;}
    *flags=world->flags[i];return 1;
}
static int Set(void *context,uintptr_t handle,uint32_t flags,uint32_t *error) {
    World *world=context;size_t i=Slot(handle);
    if(i==4u){*error=6u;return 0;}
    if(flags){world->sets[i]++;world->flags[i]=1u;if(world->set_fail==i+1u){*error=5u;return 0;}}
    else {world->clears[i]++;if(world->clear_fail==i+1u){*error=32u;return 0;}world->flags[i]=0u;}
    return 1;
}
#define CHECK(value) do {if(!(value)){fprintf(stderr,"FAIL %s:%d: %s\n",name,__LINE__,#value);return 0;}} while(0)
static int Run(unsigned number) {
    const char *name="inheritance lease";World world;GIL_Owner owner;GIL_Ports ports;uintptr_t bad[4];size_t i;
    memset(&world,0,sizeof(world));memset(&owner,0,sizeof(owner));ports.context=&world;ports.get=Get;ports.set=Set;
    if(number==1u){CHECK(GIL_Begin(&owner,1u,handles,&ports));CHECK(!GIL_CanRetire(&owner)&&owner.pending==15u);}
    if(number==2u){CHECK(GIL_Begin(&owner,2u,handles,&ports));world.clear_fail=2u;CHECK(!GIL_Release(&owner,2u));CHECK(owner.pending==2u&&!GIL_CanRetire(&owner)&&owner.first_error==32u);world.clear_fail=0u;CHECK(GIL_Release(&owner,2u)&&GIL_CanRetire(&owner)&&world.clears[1]==2u);CHECK(world.clears[0]==1u&&world.clears[2]==1u&&world.clears[3]==1u);}
    if(number==3u){world.set_fail=3u;CHECK(!GIL_Begin(&owner,3u,handles,&ports));CHECK(owner.pending==7u&&world.flags[2]==1u&&!GIL_CanRetire(&owner));world.clear_fail=1u;CHECK(!GIL_Release(&owner,3u)&&owner.pending==1u&&owner.first_error==5u);world.clear_fail=0u;CHECK(GIL_Release(&owner,3u)&&GIL_CanRetire(&owner)&&owner.first_error==5u);}
    if(number==4u){world.get_fail=2u;CHECK(!GIL_Begin(&owner,4u,handles,&ports)&&owner.used&&owner.active);for(i=0u;i<4u;++i)CHECK(world.sets[i]==0u);CHECK(GIL_Release(&owner,4u)&&GIL_CanRetire(&owner));}
    if(number==5u){world.flags[2]=1u;CHECK(!GIL_Begin(&owner,5u,handles,&ports));CHECK(GIL_Release(&owner,5u)&&world.flags[2]==1u&&world.clears[2]==0u);}
    if(number==6u){CHECK(GIL_Begin(&owner,6u,handles,&ports));CHECK(!GIL_Release(&owner,7u)&&owner.pending==15u);for(i=0u;i<4u;++i)CHECK(world.clears[i]==0u);}
    if(number==7u){CHECK(GIL_Begin(&owner,7u,handles,&ports));CHECK(GIL_Release(&owner,7u)&&GIL_Release(&owner,7u));for(i=0u;i<4u;++i)CHECK(world.clears[i]==1u);CHECK(!GIL_Begin(&owner,8u,handles,&ports));}
    if(number==8u){memcpy(bad,handles,sizeof(bad));bad[3]=bad[0];CHECK(!GIL_Begin(&owner,8u,bad,&ports));for(i=0u;i<4u;++i)CHECK(world.sets[i]==0u);CHECK(GIL_Release(&owner,8u));}
    if(number==9u){CHECK(!GIL_Begin(&owner,0u,handles,&ports)&&!owner.used);CHECK(!GIL_Begin(&owner,UINT64_MAX,handles,&ports)&&!owner.used);CHECK(GIL_CanRetire(&owner));}
    if(number==10u){CHECK(GIL_Begin(&owner,10u,handles,&ports));world.clear_fail=4u;CHECK(!GIL_Release(&owner,10u));CHECK(!GIL_Release(&owner,10u)&&owner.pending==8u&&world.clears[3]==2u);for(i=0u;i<3u;++i)CHECK(world.clears[i]==1u);world.clear_fail=0u;CHECK(GIL_Release(&owner,10u)&&owner.first_error==32u);}
    return 1;
}
int main(void) {
    unsigned i;const char *names[]={"active lease blocks original closure","failed reset retains exact subset until ACK","after-effect acquisition failure retains rollback","query refusal burns token without setters","foreign pre-existing flag is not reset","foreign token has no reset effects","duplicate release is effect-free and token is once only","duplicate capabilities refuse before setters","server token never accepts zero or wrap","repeated refusal never retries acknowledged resets"};
    puts("1..10");for(i=1u;i<=10u;++i){int ok=Run(i);printf("%s %u - %s\n",ok?"ok":"not ok",i,names[i-1u]);if(!ok)return 1;}return 0;
}
