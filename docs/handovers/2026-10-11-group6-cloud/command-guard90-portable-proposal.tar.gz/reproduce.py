from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time

P = Path(__file__).resolve().parent
TMP = Path(tempfile.mkdtemp(prefix='g6-command-guard-tmp-', dir='/tmp'))
TMP.chmod(0o700)
commands = [
    ('frozen-red', ['portable_guard_tests.py', '--source', 'frozen', 'GuardControls.test_truthy_integer_ack_refuses', 'GuardControls.test_real_sigint_before_registration_persistence_retains_owner', 'GuardControls.test_real_sigterm_before_registration_persistence_retains_owner'], 1),
    ('original72', ['receive72.py'], 0),
    ('guard', ['portable_guard_tests.py'], 0),
]
facts = []
for name, arguments, expected in commands:
    before = time.monotonic()
    result = subprocess.run([sys.executable, '-I', '-B', *arguments], cwd=P,
                            env={**os.environ, 'TMPDIR': str(TMP)}, capture_output=True, timeout=90)
    out = P / (name + '.stdout'); err = P / (name + '.stderr')
    out.write_bytes(result.stdout); err.write_bytes(result.stderr)
    fact = {'cohort': name, 'returncode': result.returncode, 'expected_returncode': expected,
            'elapsed_seconds': round(time.monotonic() - before, 3),
            'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
            'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    facts.append(fact)
    print(json.dumps(fact), flush=True)
    if result.returncode != expected:
        break
(P / 'portable-receiving.json').write_text(json.dumps({'qualification': 'REAL_POSIX_CONTROL_ONLY_NATIVE_SECURITY_MODELED_NO_NATIVE_CREDIT', 'private_tmp': str(TMP), 'cohorts': facts}, indent=2) + '\n')
assert len(facts) == len(commands)
assert all(fact['returncode'] == fact['expected_returncode'] for fact in facts)
