# Physical editor lifecycle fixture SDK acknowledgement

The object-pinned Dev source d8243dae8a291fe1555233ad7c9da4583353594d adds actual window restoration before raise/focus in ui_builder.force_focus (incoming commit 9982c0039). The existing controlled lifecycle fixture provided no unminimize method, so its real Builder refuses host admission before the original scenarios can execute. The product focus implementation remains byte-exact.

The one-path fixture correction supplies the native chain contract unminimize()->same window and records its invocation. One appended case strictly verifies actual Builder restoration before successful host admission. All original 16 test bodies, assertions and registration order are unchanged; removing the exact fixture hunk and appended case reconstructs the entire preimage. Existing incoming test_webview_focus_failures already covers unminimize refusal; this proposal does not alter it.

Both Lua 5.4 and LuaJIT, using the unchanged existing focused runner in an owned sparse Lua projection: current Dev lifecycle 0 passed/16 failed; original fixture with only the pre-9982 Builder 16 passed/0 failed; candidate 17 passed/0 failed. The unchanged physical_editor_host family passes 1/0 before and after on both ABIs. An initial incomplete sparse-directory runner setup attempt failed before any test and is not qualification; before-lua54.log records the subsequent real 0/16 baseline.

These are controlled portable native-API fixtures, not actual Hammerspoon/macOS GUI qualification. Native macOS, full suites, packaging and public UI reachability are unexecuted. No canonical files/index/refs/workflows were changed. The source patch requires only Group 3 ownership of macos/tests/unit/ui/test_physical_editor_native_lifecycle.lua.

Replay (after existing cloud activate.sh): lua5.4 run_exact.lua <absolute candidate path> tests.unit.ui.test_physical_editor_native_lifecycle ; luajit uses the existing shared UTF8 compatibility shim installed by this runner. Snapshot source hashes are recorded in snapshot.json; dependencies.json pins unchanged relevant production/runner paths.
