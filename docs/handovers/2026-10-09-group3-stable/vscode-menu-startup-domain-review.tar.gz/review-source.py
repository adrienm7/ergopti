from pathlib import Path
import datetime, hashlib, json, subprocess, tempfile, tarfile, shutil, os
REPO=Path('/workspace/ergopti')
PACK=Path('/workspace/.ergopti-cloud/continuation-2026-10-09/vscode-menu-startup-domain-fixture')
OUT=Path('/workspace/.ergopti-cloud/reviews/vscode-menu-startup-domain-independent')
PATH='static/ergopti_plus/macos/tests/meta/test_init_vscode_bridge_setup_error_logged.lua'
BASE='338a2bbd1688d3b7c52fff3b0d5e45380faa2a33'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
pre=(PACK/'preimages'/PATH).read_bytes()
post=(PACK/'postimages'/PATH).read_bytes()
patch=(PACK/'source.patch').read_bytes()
ready=json.loads((PACK/'source-ready-receipt.json').read_text())
runtime=json.loads((PACK/'runtime-receipt.json').read_text())
checks={}
checks['receipt_pre_hash']=sha(pre)==ready['pre_sha256']
checks['receipt_post_hash']=sha(post)==ready['post_sha256']
checks['receipt_patch_hash']=sha(patch)==ready['patch_sha256']
checks['base_preimage']=git('show',BASE+':'+PATH)==pre
checks['canonical_preimage']= (REPO/PATH).read_bytes()==pre
checks['index_preimage']=git('show',':'+PATH)==pre
replacements=[
 (b'--- @return table facts\n',b'--- @return table facts\n--- @return nil|string result The actual chunk return or fatal startup diagnostic.\n'),
 (b'local ok = pcall(chunk)\n\treturn ok, facts',b'local ok, result = pcall(chunk)\n\treturn ok, facts, result'),
 (b'local ok, facts = startup_slice(true)',b'local ok, facts, result = startup_slice(true)'),
 (b'\t\thelpers.assert_true(ok, "the existing UI can progress without the retired feature")\n',b'\t\thelpers.assert_true(ok, "the existing UI can progress without the retired feature")\n\t\thelpers.assert_eq(result, nil, "committed menu startup returns no domain value")\n'),
 (b'local ok, facts = startup_slice(false)',b'local ok, facts, result = startup_slice(false)'),
 (b'\t\thelpers.assert_eq(ok, false)\n',b'\t\thelpers.assert_eq(ok, false)\n\t\thelpers.assert_type(result, "string")\n\t\thelpers.assert_eq(result:match(": ([^\\n]+)$"), "menu.start did not commit")\n')]
expected=pre
for before,after in replacements:
 assert expected.count(before)==1
 expected=expected.replace(before,after)
checks['exact_authorized_replacements']=expected==post
pre_assertions=[l for l in pre.decode().splitlines() if 'helpers.assert_' in l]
post_assertions=[l for l in post.decode().splitlines() if 'helpers.assert_' in l]
i=0
for line in post_assertions:
 if i<len(pre_assertions) and line==pre_assertions[i]: i+=1
checks['all13_assertions_preserved_ordered']=i==len(pre_assertions)==13
checks['three_assertions_added']=len(post_assertions)==16
checks['patch_one_exact_path']=patch.count(b'--- a/')==1 and patch.count(b'+++ b/')==1 and patch.startswith(('--- a/'+PATH+'\n+++ b/'+PATH+'\n').encode())
dependencies=[]
for row in runtime['dependencies']:
 path=row['path']; disk=(REPO/path).read_bytes(); baseline=git('show',BASE+':'+path)
 info={'path':path,'sha256':sha(disk),'recorded_sha256':row['sha256'],'matches_git338':disk==baseline,'matches_receipt':sha(disk)==row['sha256']}
 dependencies.append(info)
checks['six_dependencies_unchanged']=len(dependencies)==6 and all(d['matches_git338'] and d['matches_receipt'] for d in dependencies)
projection=PACK/'classifier-projection'
projection_files=sorted(str(p.relative_to(projection)) for p in projection.rglob('*') if p.is_file())
checks['classifier_projection_only_three_files']=projection_files==sorted([PATH,'tools/test/find-false-greens.cjs','tools/test/false-greens-baseline.json'])
checks['classifier_source_exact']=all((projection/p).read_bytes()==git('show',BASE+':'+p) for p in ['tools/test/find-false-greens.cjs','tools/test/false-greens-baseline.json'])
checks['classifier_projection_postimage']=(projection/PATH).read_bytes()==post
selector='local function has_common_hotstring_groups'
selector_files=[]
for p in (REPO/'static/ergopti_plus/macos').rglob('*.lua'):
 if 'tests' not in p.relative_to(REPO/'static/ergopti_plus/macos').parts and selector in p.read_text(): selector_files.append(str(p.relative_to(REPO)))
checks['source_selector_unique']=selector_files==['static/ergopti_plus/macos/init.lua']
production=(REPO/'static/ergopti_plus/macos/init.lua').read_text()
start_token='Boot.stage("UI: menu.start (menubar + state sync + engines + LLM handler)")'
end_token='Boot.stage("File watchers armed")'
start=production.index(start_token); end=production.index(end_token,start)+len(end_token)
slice_text=production[start:end]
checks['original_fatal_exact']=slice_text.count('error("menu.start did not commit")')==1
checks['real_ready_slice_no_explicit_return']='return' not in slice_text
apply=[]
with tempfile.TemporaryDirectory(prefix='vscode-domain-source-',dir='/tmp') as td:
 target=Path(td)/PATH; target.parent.mkdir(parents=True); target.write_bytes(pre)
 for label,args in [('forward_check',['--check']),('forward',[]),('reverse_check',['--reverse','--check']),('reverse',['--reverse'])]:
  result=subprocess.run(['git','apply',*args,str(PACK/'source.patch')],cwd=td,capture_output=True)
  apply.append({'operation':label,'exit':result.returncode,'stderr':result.stderr.decode()})
  assert result.returncode==0
  if label=='forward': checks['private_forward_exact']=target.read_bytes()==post
 checks['private_reverse_exact']=target.read_bytes()==pre
checks['canonical_preimage_after']=(REPO/PATH).read_bytes()==pre
checks['index_preimage_after']=git('show',':'+PATH)==pre
assert all(checks.values()),json.dumps(checks,indent=2)
result={
 'verdict':'SOURCE_CLEAR','scope':'Independent source-only review; no runtime, Node, suite or native checks executed by reviewer.',
 'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_observed':git('rev-parse','HEAD').decode().strip(),
 'grant':'issue86#6086131641 G5 exact fixture delegation','base':BASE,'path':PATH,
 'pre_sha256':sha(pre),'post_sha256':sha(post),'patch_sha256':sha(patch),
 'checks':checks,'private_git_apply_operations':apply,'dependencies':dependencies,'source_selector_files':selector_files,
 'domain_review':{
  'success':'Actual extracted production slice falls through with nil; result is the second pcall result, tested after success status.',
  'noncommit':'Actual source throws menu.start did not commit; string type is checked before matching and comparing the complete final diagnostic after its source-location separator.',
  'preserved':'All 13 original assertion lines remain in order. Source type, present/ordered boundaries, nonempty slice, require refusal, menu calls, zero bridge calls, readiness mark, final stage, failed status and zero marks remain unchanged.',
  'mutations':'Recorded wrong-domain error replaces only the fatal diagnostic. Recorded returned-value mutation preserves final stage recording and returns unexpected-domain. Neither mutant is asserted only through a pcall status.',
  'classifier':'Unmodified Git338 checker and zero baseline run in private three-file projection. New result assertion is within checker lookahead; matching names describe real values captured from pcall, with no scanner-specific fake variable.'},
 'inherited_runtime_evidence':{
  'execution':'Read and sealed parent artifacts; reviewer did not rerun.',
  'Lua54':'Genuine old/new 2/0 each; two wrong-domain mutants old 2/0 each, new 1/1 each.',
  'classifier':'Target projection old exit 1/new exit 0; this is target-specific evidence, not the full repository JS gate.',
  'raw_LuaJIT':'Old/new 0/2; existing command_lines.lua table.pack unavailable. Unqualified for runtime readiness.',
  'native_Hammerspoon':'UNRUN',
  'receipt_note':'runtime-receipt retains initial source-ready kind/tests-held fields; controlled_Lua54, raw_LuaJIT and unchanged_classifier plus logs describe the later recorded observations.'},
 'limitations':'SOURCE_CLEAR supports source adoption after parent gates. It does not certify those gates, raw LuaJIT or native Hammerspoon.',
 'canonical_index_ref_writes':False,'production_scanner_baseline_writes':False,'reviewer_validation_commands':[]}
(OUT/'review-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
report='''SOURCE_CLEAR

The exact G5 fixture correction retains the second pcall result and tests both actual startup domains: nil after committed menu startup, and the existing fatal menu.start did not commit after noncommit. All 13 original assertions remain in order; three real result assertions are added. Source extraction, readiness, menu calls, final stage, zero bridge activation, and refusal controls are unchanged.

The preimage equals Git338, the current canonical file and its index entry. The patch changes one exact fixture path. All six listed dependencies equal their Git338 bytes and receipt hashes. The genuine checker and baseline are identical in the private three-file target projection. Forward check/apply and reverse check/apply succeeded only in a private temporary fixture, with exact postimage and restored preimage.

The two recorded mutants change meaningful domains while preserving surrounding controls. The new nil check detects unexpected success output; the exact final diagnostic check detects an unrelated failure. Their variable names carry actual pcall values. No production, checker, baseline, original VS Code retirement, canonical file, index or ref was edited by this review.

Parent artifacts record Lua 5.4 genuine old/new 2/0, both mutants old 2/0 and new 1/1, and target classifier old exit 1/new exit 0. Those observations were read and sealed, not rerun. Raw LuaJIT old/new 0/2 fails in existing command_lines.lua because table.pack is unavailable; native Hammerspoon is UNRUN. The runtime receipt retains stale initial tests-held labels alongside explicit later results. This source verdict does not imply parent gate completion or native/runtime readiness.
'''
(OUT/'report.txt').write_text(report)
# Retain only compact evidence, never a full checkout.
evidence=OUT/'evidence'; evidence.mkdir(exist_ok=True)
for filename in ['source.patch','source-ready-receipt.json','runtime-receipt.json','runtime-results.json','classifier-results.json','run_exact.lua']:
 shutil.copyfile(PACK/filename,evidence/filename)
for p in PACK.glob('*.log'): shutil.copyfile(p,evidence/p.name)
(evidence/'preimage.lua').write_bytes(pre); (evidence/'postimage.lua').write_bytes(post)
for p in ['tools/test/find-false-greens.cjs','tools/test/false-greens-baseline.json']:
 shutil.copyfile(projection/p,evidence/Path(p).name)
(evidence/'actual-production-slice.txt').write_text(slice_text+'\n')
sealpaths=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in ['SHA256SUMS','capsule.tar.gz','capsule.sha256'])
(OUT/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(OUT))+'\n' for p in sealpaths))
with tarfile.open(OUT/'capsule.tar.gz','w:gz') as tf:
 for p in sealpaths+[OUT/'SHA256SUMS']: tf.add(p,arcname=str(p.relative_to(OUT)))
(OUT/'capsule.sha256').write_text(sha((OUT/'capsule.tar.gz').read_bytes())+'  capsule.tar.gz\n')
for p in OUT.rglob('*'):
 if p.is_file(): p.chmod(0o444)
print(json.dumps({'verdict':result['verdict'],'checks':checks,'review':str(OUT),'capsule_sha256':sha((OUT/'capsule.tar.gz').read_bytes())},indent=2))
