# Independent macOS JSON control stub review

CLEAR for exact packet SHA-256 `3a95694e0313b43b6ceb0915b63b6fd6cd046325df26395f9b7249746b1202e4`. No root changes or refs.

Exactly two branches decode the standard JSON short escapes b/f to byte 8 (backspace) and byte 12 (form feed). Removing precisely these branches recovers the complete original stub bytes; all remaining decoder behavior, error handling and equal-dictionary interning are untouched. LF retained. Production parser, shared JSON decoder, independent release-parser corpus and actual owning native test retain their four recorded exact hashes.

Independent Python JSON decodes the untouched golden string to bytes 66,97,99,107,8,102,111,114,109,12. The native-shaped stub previously retained literal backslash/letter pairs, so it misread the expectation. The shared production parser already returns the prescribed controls. This correction repairs the reader; it does not regenerate or weaken an expectation.

Independently reproduced actual owning Mac corpus module: original 60 passed/1 failed, candidate 61 passed/0 failed. Adjacent actual JSON decode contract 5/0; codec tree 2/0. Four independently authored direct probes pass for prescribed short-control bytes, literal escaped backslashes, control keys/nested values, and equal-dictionary alias identity. Original isolated stub restored after all runs.

Qualification uses Lua 5.4 and repository Mac stubs. Actual Hammerspoon/macOS native device and final integrated CI are not executed by this reviewer. No production source or test/golden assertions changed.
