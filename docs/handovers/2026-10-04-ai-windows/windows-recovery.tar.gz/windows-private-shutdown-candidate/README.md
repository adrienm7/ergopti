# Private Windows AI shutdown authority

Scratch-only candidate against the exact saved checkout preimages. No gate,
AHK parser, native unit/E2E, packaging or installation executed. Root owns
adoption and independent review.

## Contract

`LLM_Menu_ApiPrivateBeginShutdown()` runs a bounded Critical claim, advances
its lazy private lifecycle generation and returns that exact positive Integer
as the active attempt. A later begin supersedes earlier attempts.
`LLM_Menu_ApiPrivateRefuseShutdown(exactAttempt)` clears only the currently
active exact Integer attempt, advances generation again and returns a strict
Boolean. Wrong, String, zero, repeated and superseded attempts cannot clear it.
Both functions restore their caller's exact Critical state and perform no I/O,
menu, logging, network or timer effects. Lazy state avoids late auto-execute
reinitialization after early OnExit.

OnExit stores its own attempt before fallible preflight. The honored-veto
branch invokes exact refusal after the existing reload handback. Accepted exit
and exhausted veto keep the marker active. Historical `_LifecycleShutdownReason`
assignment and reload refusal call remain unchanged, as do all existing gate
bodies and teardown/lease release finally blocks. OnExit is noninterruptible;
no fresh menu rebuild or discovery is invoked during its unwind. Native debt,
WAL, terminal and reload owners retain their original checks.

Ordinary receipts capture private lifecycle generation before their complete
native/file validation. Native revalidation and final bounded publication
stamp recheck that generation and inactive attempt. An honored veto therefore
permits fresh authority only after independent barriers allow it; pre-attempt
receipts never resurrect. The API RAM publication revision remains separate,
so identical ordinary API reloads still preserve source receipt semantics.

## Prepared regression inventory

All original 35 assertions, inputs and explicit registrations are preserved.
One additive native fixture branch invokes only the pure attempt hooks in the
actual final native claim; it deliberately simulates a synchronous lifecycle
boundary to prove the second native fence. Six new explicit registrations use
real private files and the existing actual DPAPI/WAL owner: historical-reason
fresh acquisition and old-receipt revocation; superseded/wrong/repeated tokens;
foreign terminal debt after veto; final-claim active attempt; final-claim
attempt followed by veto; inherited Critical restoration. Total 41 native
cases are UNEXECUTED. There is no corpus mutation or expectation regeneration.

The original native source without these hooks cannot execute the added API
cases; that establishes an interface prerequisite rather than causal behavior.
Native qualification must also disable only the epoch fence to demonstrate
that the actual final-claim attempt-then-veto case detects the stale authority.
Actual OnExit honored/exhausted gates, canceled Exit followed by fresh panel
rebuild/discovery/selection, pause, packaging and installation remain required.
The separate panel owner will retain post-unwind recovery intent; this patch
does not synchronously repair the view while OnExit owns a terminal bundle.

## Review and adoption

`preimages/` are immutable original bytes; `receipt.json` contains SHA-256 for
each preimage/candidate; `shutdown.patch` contains only owned changes. The TODO
change touches only item 47. Existing Group3 hook boundaries are preserved.
Static byte checks confirm AHK BOM/LF and preservation of the complete original
35-case test prefix apart from the additive branch. These checks are not
native execution or approval of the self-authored candidate.
