// AUTO-GENERATED from _shared/data/identifiers.json.
// DO NOT EDIT BY HAND — run `npm run codegen:identifiers` to refresh.

// Application names, bundle ids, service labels and external hosts for the
// classic-script pages. Hosts are bare names: build a URL as
// 'https://' + ERGOPTI_IDENTIFIERS.hosts.github + '/...'.
const ERGOPTI_IDENTIFIERS = Object.freeze({
	app: Object.freeze({
		name: 'ErgoptiPlus',
		ahk: 'ErgoptiPlus.ahk',
		exe: 'ErgoptiPlus.exe',
		bundle: 'ErgoptiPlus.app'
	}),
	bundle_ids: Object.freeze({
		launcher: 'com.ergoptiplus.app',
		hammerspoon: 'com.ergoptiplus.app.hammerspoon'
	}),
	signing_ids: Object.freeze({
		runtime_installer: 'com.ergoptiplus.app.runtime-installer',
		installed_physical_source: 'com.ergoptiplus.app.installed-physical-source',
		remap_core: 'com.ergoptiplus.remap.core',
		remap_console: 'com.ergoptiplus.remap.console',
		remap_cli: 'com.ergoptiplus.remap.cli'
	}),
	service_labels: Object.freeze({
		macos_core: 'com.ergoptiplus.runtime.core',
		macos_remap_guardian: 'com.ergoptiplus.remap-guardian',
		macos_virtual_hid: 'com.ergoptiplus.runtime.vhid'
	}),
	hosts: Object.freeze({
		github: 'github.com',
		github_api: 'api.github.com',
		huggingface: 'huggingface.co',
		ollama: 'ollama.com',
		ollama_registry: 'registry.ollama.ai'
	}),
	dev_source: Object.freeze({
		plist_key: 'ErgoptiDevSourceRoot',
		environment: 'ERGOPTI_DEV_SOURCE_ROOT'
	}),
	field_report: Object.freeze({
		branch_prefix: 'field/',
		folder: 'docs/field-reports',
		base_config_key: 'ergoptiFieldBase'
	})
});
