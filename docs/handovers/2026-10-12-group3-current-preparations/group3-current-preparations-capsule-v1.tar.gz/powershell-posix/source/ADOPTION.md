# PowerShell POSIX forward adoption after the frozen peer gate

The actual prospective tree is8261a83773a190403c1a7bb05e73e0a5b30e8ce4,
with current merged G6 TODO and published Snapshot91 retained. Parent owns
canonical adoption after its gate/CI checkpoint; this preparation performs no
canonical, index, ref, generator, source oracle or runtime change.

The saved checkpoint is actually in
`windows91-snapshot16-canonical-qualified-preparation-v1`, not the similarly
named staged-selected folder. Its saved five-path patch/checkpoint remain
unchanged. Every four-code postimage stays byte-exact to that saved patch and
the independently reviewed original PowerShell source packet. Only the owned
TODO106 paragraph/context is refreshed. Removing that paragraph reconstructs
all prospective TODO bytes; no other item or Snapshot91/foreign block changes,
and no item is removed. The candidate contains no V4 fixture source.

## Apply only against exact current preimages

1. After the parent frozen gate/CI checkpoint is terminal, verify all five
   canonical path digests against `preparation.json`. The prospective Git tree
   may become a merge commit with a different SHA; exact source bytes matter.
2. Run `git apply --check` on `forward-five.patch`, then apply that patch to the
   five owned paths only. Do not copy the full TODO postimage over newer work.
   On any preimage drift, preserve current bytes and rejoin only the affected
   owned hunk; never overwrite a foreign change or modify code posts silently.
3. Confirm all five postimage digests, four exact original code posts and the
   exact inverse of the added TODO106 paragraph. Stage only these owned paths.
4. Run Root's selected `verify-change` gates serially, retaining current source
   stability and prior failures separately. The original shared catalogue change
   needs authentic native qualification on affected drivers; prior controlled
   Mac23 and real Linux pwsh receipts do not qualify Windows/Mac installation.
   Keep original budgets/corpora/assertions and native errors/refusals intact.

## Receiving status

Private file-only forward-check, forward-apply, reverse-check and reverse-apply
all exit0 and produce exact five posts/originals. Five small source files only;
no new worktree/repository/index. The four original code hunks are retained
byte-exact from the saved patch, without generated artifacts or rebuilt oracles.

Historical exact d316 gates pass Hammerspoon18611/0 and retain Linux13277/2,
with the two original same_file absolute/relative-route fixture failures.
Their real logs/hash receipts are referenced, never rerun or relabeled here.
The future V4 correction remains separate and unadmitted by this packet.
Original actual Linux pwsh7.5.4 execution and controlled Mac23 evidence remain
unchanged; actual native Mac/Windows PowerShell receiving is unexecuted.
Final prospective-source formatting/JS/HS/Linux/native/full package/install
checks are NOT performed by this source-only receiving preparation.
