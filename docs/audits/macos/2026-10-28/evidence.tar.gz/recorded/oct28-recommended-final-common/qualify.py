from pathlib import Path
import datetime,hashlib,json,re,subprocess
from zoneinfo import ZoneInfo
s=Path('/workspace/scratch/oct28-recommended-final-common');r=Path('/workspace/ergopti-macos-final-common')
def load(name):return json.loads((s/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
receipt=load('receipt.json');go=load('go.json');exit_record=load('tool-exit.json');observer=load('residual-observer.json')
assert go['source_state']=='staged_precommit' and go['go_from_parent'] is True
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==go['commit']
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=r,text=True).strip()==go['base_head_tree']
assert go['expected_owned_paths']==['tools/test/test-recommended-defaults-rule.cjs']
assert subprocess.check_output(['git','rev-parse',go['commit']+':static/ergopti_plus'],cwd=r).strip()==subprocess.check_output(['git','rev-parse',go['tree']+':static/ergopti_plus'],cwd=r).strip()
assert receipt['physical_initial']['index_tree']==receipt['physical_final']['index_tree']==go['tree']
for state in [receipt['physical_initial'],receipt['physical_final']]:
 assert not state['mismatches'] and not state['unstaged'] and not state['untracked']
assert receipt['physical_initial']['digest']==receipt['physical_final']['digest']
raw=(s/'js.log').read_bytes();text=raw.decode(errors='replace');rows=re.findall(r'^  (PASS|FAIL) (\d+)/(\d+) — (.*)$',text,re.M)
count=go['expected_js_features'];assert count==529
assert load('inventory.log')==load('prelaunch-inventory.json')
assert len(rows)==count and {int(x[1])for x in rows}==set(range(1,count+1)) and all(int(x[2])==count for x in rows)
assert all(x[0]=='PASS'for x in rows),[x for x in rows if x[0]=='FAIL']
gates=receipt['gates'];assert len(gates)==19 and len({x['name']for x in gates})==19
assert all(x['actual_exit']==0 for x in gates) and receipt['all_actual_exit_zero'] is True
assert exit_record['actual_child_wait_exit']==0
assert observer['qualified'] and not observer['live_refs'] and not observer['unreadable_live_same_uid']
not_run=re.search(r'(\d+) case\(s\) in (\d+) check\(s\) were NOT EXECUTED on this host:',text);assert not_run and not_run.groups()==('1','1')
qualification={'state':'COMPLETE_ALL_COMMON_GATES_PASS','overall_green':True,'qualified_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_state':'STAGED_PRECOMMIT_CONTENT','base_head_commit':go['commit'],'base_head_tree':go['base_head_tree'],'qualified_index_tree':go['tree'],'committed_source_sha':None,'canonical_js_checks':{'planned':count,'completed':count,'unique_indices_complete':True,'passed_checks':count,'failed_checks':0,'actual_js_exit':0,'host_specific_cases_not_executed':{'count':1,'checks':1,'description':'Pre-existing AHK host-specific cases remain explicitly not executed, never passed.'}},'actual_child_wait_exit':0,'all_other_gates_actual_zero':True,'gates':[{'name':x['name'],'actual_exit':x['actual_exit'],'command':x['command']}for x in gates],'source_physical_invariant':receipt['physical_final'],'residual_observer':observer,'native_darwin_executed':False,'receipt_sha256':sha(s/'receipt.json'),'tool_exit_sha256':sha(s/'tool-exit.json'),'js_log_sha256':hashlib.sha256(raw).hexdigest(),'scope':'One complete canonical Common run on frozen one-file test-oracle staged precommit content. HEAD identifies the unchanged ae73 base only; the staged tree identifies tested content. All static/ergopti_plus product, driver tests and driver harness source remain byte-identical to base; prior driver qualifications require a separate explicit content mapping. The later atomic commit must retain this exact staged tree and bind it separately. All nineteen producer gates must pass, including all canonical JS checks; no expected failure exceptions. No tests disabled, retried or weakened. Host-specific native cases remain explicitly unexecuted.'}
(s/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'state':qualification['state'],'base_head':go['commit'],'qualified_index_tree':go['tree'],'counts':[count,0],'other_gates':18,'source_invariant':True,'observer_qualified':True,'qualification_sha256':sha(s/'qualification.json')}))
