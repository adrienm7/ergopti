<!-- linux-runtime-candidate/RUNTIME-PLAN.md -->

# Linux Ollama runtime implementation plan

This is a scratch preparation, not an integrated feature or native runtime
qualification. Existing checkout files and another group's native helpers remain
unchanged. The user explicitly selected a user-local official archive installation
without administrator privileges. That preference is settled.

## Ownership boundaries

- Group3's announced `_shared/lua/native_worker_owner.lua` is the intended common
  policy owner. The reviewed scratch `adapters.owned_process` is a qualification
  reference, not approved for adoption alongside a duplicate state machine. The
  eventual Linux native adapter must own a referenced process group, all allocated
  pipe/timer/process handles, bounded diagnostics and physical settlement.
  Signal acceptance does not release its owner. Native ESRCH, direct child exit
  and every owned close callback are all required. Unreaped descendant zombies
  remain debt, not fabricated group absence.
- `HttpClient.get_owned` owns archive and version-request curl children and
  retains their actual exit/close acknowledgements. Its existing operation ABI
  must be preserved. `HttpClient.download` has a weaker boolean API and is not
  appropriate for this transaction.
- The existing enable owner retains exact configuration source, backend, model,
  origin, generation, pause and writer admission. Runtime installation/startup
  never writes `llm.enabled`. Only ordinary fresh version admission may enable.
- A Linux runtime controller owns the overall staged install/start transaction,
  explicit consent, currentness predicate, HTTP/process capabilities and private
  filesystem state. It blocks successors while any cleanup operation is pending.
- The runtime activation actor owns `prediction_engine`, `enable_admission` and
  the existing native refusal dialog. Changes to those files must be serialized.

## Canonical pinned assets

The official GitHub release API for `v0.24.0` supplied the following digests and
sizes. This matches the existing macOS pinned release. The official release
installer itself was SHA-256 verified against its authoritative asset digest.

| Architecture | Asset | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| `x86_64` | `ollama-linux-amd64.tar.zst` | 1198635318 | `15c5f8d66ba06e0d3b4719df8868612dbd66e14e82760929bb3552e1657cdcdb` |
| `aarch64`, `arm64` | `ollama-linux-arm64.tar.zst` | 1323731537 | `6e9a3ce5f64e93312902e39c420ec336255f078a368ca25e99b339d08a6dfa4b` |

Other architectures are unavailable explicitly. Keep the full verified archive's
sibling `bin/ollama` and `lib/ollama` trees. Optional ROCm, JetPack and MLX overlays
are separate explicit scope; do not silently download them. No GPU or physical
hardware qualification follows from selecting an architecture.

Prefer a canonical shared Ollama release JSON catalogue plus the registered
generator for the existing macOS shell constants, retaining existing pin
assertions. Coordinate ownership before touching shared data or generators.
Do not introduce unrelated manifest/schema/locales/workflow changes.

The acquisition URL is
`https://github.com/ollama/ollama/releases/download/v0.24.0/<asset>`. The actual
verified HTTPS redirect host is `release-assets.githubusercontent.com`.
`api.github.com` is a maintainer pin-refresh requirement, not a necessary runtime
dependency. Never disable TLS, artifact checksums or existing signature checks.

## Resolver and installation

1. Resolve existing installed Ollama by native regular-file/executable-access
   receipts at fixed absolute candidates and absolute PATH entries. No version
   subprocess, download, shell launch or cache is needed to build a menu.
2. Derive one managed directory under the user's valid absolute XDG data root,
   falling back to an actual absolute HOME plus `.local/share`. Reject unusable
   identities instead of installing into TMPDIR or guessed homes. A proposed
   managed path is `ergopti_plus/ollama`; the resolver and installer share it.
3. Require an explicit acknowledged native download choice. A read-only enable,
   boot, retry with another backend or generic requirement check cannot install.
   Use a translated existing label that accurately promises the scope. The
   current `llm.unreachable.install` promises the model as well as the binary;
   either implement that scope or use the existing binary-only download label.
4. Prepare private owner-only staging with native filesystem receipts. Reject
   symlinked or foreign managed targets; preserve unrelated user directories and
   existing files. Admission failures keep the AI off.
5. Download through `get_owned` with `output_path`, `follow_redirects=true`,
   `https_only=true`, maximum pinned size and the existing bootstrap deadline.
   Inherit provided proxy/system trust settings without printing values, forcing
   CA files or silently weakening trust. Group 6 owns broader managed-network
   detection and policy.
6. Check exact downloaded byte count, then run an owned foreground SHA-256
   helper. Parse only its successful complete receipt and compare against the
   canonical pinned digest before extraction. A gigabyte-scale hash must not
   block the keyboard event loop.
7. Extract with an owned foreground `tar --zstd` helper only into private stage.
   Validate the resulting regular executable, full library tree and permissions.
   The trusted official archive layout comes from its tagged build script.
8. Fence the exact source again immediately before publication. Publish the
   whole staged directory atomically at its resolver-owned location; preserve
   acknowledged inverse state if a supported replacement is required.
9. Cancellation after publication can leave the verified installed runtime.
   It suppresses launch and enable. Cleanup removes only this operation's
   unpublished stage/archive after both native HTTP and process owners settle.

## Foreground-owned daemon startup

1. Admit the configured canonical HTTP loopback origin and existing supported
   port, then derive `OLLAMA_HOST` from that owner. Do not start a local process
   to pretend to repair a remote or HTTPS origin. Never invent another port.
2. Resolve and execute one exact absolute binary with `serve`, using the owned
   libuv operation. Its session/process-group flag remains referenced; never
   unref it, background it with a shell, use broad pkill, or control a foreign
   system service.
3. Preserve inherited environment bindings and append only the required daemon
   binding through a validated native env vector. Downloads issued by the daemon
   retain supplied proxy and system trust. Do not log credentials or its argv.
4. Use `capture_tail=true` for the daemon: bounded recent diagnostics plus a
   central logger output consumer. Helper processes retain overflow refusal.
   Total historical server logs must not eventually kill a healthy daemon.
5. The runtime controller owns the startup deadline and repeated owned version
   probes. Before every dispatch, callback and publication, require the original
   ticket to remain current and all predecessor capabilities physically settled.
6. A successful, complete, nonredirected `/api/version` receipt permits runtime
   publication; it does not itself prove model availability or permit a secret
   preference write. Return through the existing current enable admission owner.
7. Published daemon admission must use its stable native owner, rather than the
   original disabled preference predicate. Otherwise enabling AI would invalidate
   and kill the daemon on its next log output. Preserve macOS's existing boundary
   that a published daemon is outside global pause ownership; unpublished startup
   is fenced and retired on pause, source change, cancellation or refused writes.
8. Retain the exact published process operation until actual app shutdown or a
   deliberate owned stop. Unexpected daemon exit reports its actual receipt,
   leaves AI admission honest, and never invokes an automatic download.

## Test registration and qualification

- Convert seam cases to `tests.helpers.describe/it` in
  `linux/tests/unit/adapters/test_owned_process.lua`. Keep every independent
  assertion outside the product's protected callbacks, use
  `load_module_with_dependency` for exception-safe cache restoration, and add the
  exact module to `linux/tests/test_manifest.lua` before claiming suite coverage.
- Put the actual process fixture and independent Python subreaper under
  `linux/tests/hardware`. Retain real group absence and actual exit/close checks;
  the wrapper's timeout and failed-child teardown also have independent actual
  descendant tests. Document its invocation before any coordinated CI hookup.
- Run real native fixtures serially with root verification. Do not overlap them
  with JS/generator drift gates. Both LuaJIT and Lua 5.4 require qualification.
- Add independent install/start seams for stale consent, exact source, permission
  refusal, bad size/checksum, extraction failure, publication refusal, cancellation
  after publication, daemon exit, probe refusal and no automatic downloads.
- Qualify a real official checksum-verified runtime installation and owned serve,
  actual version response, cancellation, cleanup and known model handling. An
  external loopback fixture cannot substitute for this installation evidence.
- Hosted native Linux packaging/install/launch and cross-driver validation remain
  separate final requirements. This plan does not complete TODO 48 or TODO 16/38.
