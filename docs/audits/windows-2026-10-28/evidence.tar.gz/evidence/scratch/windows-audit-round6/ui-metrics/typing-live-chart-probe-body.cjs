
const page=loadMetricsTypingPage('windows');freezePageClock(page,'2026-01-01T12:30:00Z');
const charts=[];const canvas=page.context.document.createElement('canvas');canvas.getContext=()=>({owner:'wpm'});page.elements.set('wpm_chart',canvas);
page.context.Chart=class ChartPort{constructor(port,config){assert.equal(port.owner,'wpm');charts.push(config);}destroy(){}};
const manifest=chars=>({'2026-01-01':{Editor:{chars,time:3000,wpm_chars:chars,hourly:{'12':{c:chars}},hourly_min5:{'12:05':{c:chars}}}}});
publishTypingPage(page,'windows',manifest(3));
page.messageListeners.filter(x=>x.name==='message').at(-1).callback({data:{type:'prefetch',blob:{metrics_manifest:manifest(7)}}});
const actual={currentManifest:page.context.metrics_manifest['2026-01-01'].Editor.chars,projectedChars:vm.runInContext("app_state.time_series['2026-01-01'].chars",page.context),points:Array.from(charts.at(-1).data.datasets[0].data,p=>({x:p.x.toISOString(),y:p.y})),chartCount:charts.length,errors:page.diagnostics.filter(x=>x.level==='error')};
console.log(JSON.stringify(actual));assert.equal(actual.points[0].y,7,'a supported manifest-only live push must update the visible chart');
