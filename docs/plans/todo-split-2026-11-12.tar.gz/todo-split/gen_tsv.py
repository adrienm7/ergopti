import sys, csv
sys.path.insert(0, '.')
from residual_spec import R, ALWAYS
keys = [l.rstrip('\n').split('\t', 1)[1] for l in open('keys.txt', encoding='utf-8')]
with open('decisions.tsv', 'w', encoding='utf-8') as d, open('residual.tsv', 'w', encoding='utf-8') as r:
    for i, k in enumerate(keys):
        d.write(f"{k}\t{'residual' if i in R else 'drop'}\n")
        for f, sec, text in R.get(i, []):
            r.write('\t'.join([k, f, sec, text.replace('\n', '\\n')]) + '\n')
    for f, sec, text in ALWAYS:
        r.write('\t'.join(['*', f, sec, text.replace('\n', '\\n')]) + '\n')
print(len(keys), 'decisions;', sum(len(v) for v in R.values()) + len(ALWAYS), 'residual lines')
