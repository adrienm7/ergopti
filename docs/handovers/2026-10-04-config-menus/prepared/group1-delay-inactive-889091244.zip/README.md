# Inactive Tap-Hold per-key delay preparation

This is an inactive source preparation based on dev `88909124461a3dbdfe5b745453fe50333eb64adc`. It is not an integrated feature and does not complete TODO 54 or 81. The source patch has 14 exact owned paths. No root checkout, index, refs, CI branches, or workflows were changed by its author.

The shared records make the per-key Delay group and custom command available on Windows, macOS and Linux. Windows receives a genuine prompt and durable setter using the existing dual-lease transaction owner, authoritative effective per-key duration, and strict persistence/reload acknowledgements. macOS retains its existing global-reset command; Windows has no invented global-reset provenance. Linux and macOS retain their established setters and refusal behavior. New prompt failures, nonfinite/rounded-zero inputs and retained callbacks are tested without weakening original state/disk assertions.

## Contents and dependency ownership

- `source.patch`, `identities.json`, `preimages/`, `postimages/`: exact 14-path candidate and pinned preimages. SHA256 identifies every byte. `git apply --check` on these preimages passed.
- `evidence/shared-record-additions.toml` and `shared-record-transformations.json`: proposed root-owned manifest records. The complete manifest under `local-fixture-only/` is only a focused reproduction fixture; do not copy it over a newer shared manifest.
- `evidence/locale-contract.json`: root-owned new neutral prompt key, exact one `%d` and one newline contract, plus existing keys requiring genuine translations in all 21 locales. The new prompt key is absent from current locales. Native default prompt qualification is therefore pending.
- `local-fixture-only/`: exact focused manifest, generated menu projection, and the Gesture-owned two-file check-template prerequisite. These prerequisite renderer bytes are independent ownership, not part of the Delay source patch. Their publication and source review belong to the root/Gesture agents.
- The one-line compiler allowance for a check caption getter and the two JS source guards are root-publication proposals. Compose them after the reviewed Metrics V3 prerequisite and retain all strict malformed-field controls. This combined prerequisite composition is not qualified here.
- `independent-windows-review/`: final source-clear five-file Windows review, actual definition/registration checks, portable logs and exact hashes. Native execution is pending.
- `evidence/`: actual focused runner, portable/JS logs, provider/compiler causal controls, and owner generation repeat receipts. Earlier first-attempt failures remain identifiable and are not counted as passing qualification.

## Reproduction

Create an isolated archive of the pinned parent. Apply `source.patch` only after checking exact preimages. Consume the exact Gesture-owned check-template runtime prerequisite (Lua SHA256 `20685d3287e1fe89456a649ab4b66fb4907a4e233da5e66c417c4a9bd1144f0e`, AHK SHA256 `2de32979e52f4d55e49f6d01b132c9b6eb99328985990029919255add9744112`). Apply only the proposed manifest records to the actual current shared owner. For an exact focused replay, use the full pinned manifest fixture, then run the actual owner `node tools/build/build-menu-manifest.js`; never hand-edit the generated JSON. Load the toolchain with `source /workspace/tooling/activate-ergopti.sh` in this environment.

The focused runner accepts checkout, driver and registered module:

```sh
lua5.4 evidence/focused-delay.lua "$TASK_CHECKOUT" linux tests.unit.meta.test_tap_hold_menu
luajit evidence/focused-delay.lua "$TASK_CHECKOUT" linux tests.unit.meta.test_tap_hold_menu
lua5.4 evidence/focused-delay.lua "$TASK_CHECKOUT" macos tests.unit.ui.menu.test_menu_tap_holds_hand_sections
lua5.4 evidence/focused-delay.lua "$TASK_CHECKOUT" linux tests.unit.meta.test_menu_matches_manifest
lua5.4 evidence/focused-delay.lua "$TASK_CHECKOUT" linux tests.unit.meta.test_tap_hold_writer
```

Run these actual JS guards serially with native suites because drift controls temporarily regenerate artifacts:

```sh
node tools/test/test-menu-manifest.cjs
node tools/test/test-menu-parity.cjs
node tools/test/test-menu-manifest-keys-have-readers.cjs
node tools/test/test-menu-action-handler-bijection.cjs
``` `verify-change-selection.json` records the actual exported selector and test-registration result; a full CLI verify-change run requires a real Git checkout and remains the publisher's responsibility.

## Qualified results

- Linux Delay module: 36 passed, 0 failed on Lua 5.4 and LuaJIT.
- macOS Delay module: 30 passed, 0 failed on Lua 5.4 with controlled native adapters.
- Linux actual menu certification: 5 passed, 0 failed.
- Linux private POSIX Tap-Hold writer: 52 passed, 0 failed; real filesystem publication with controlled engine reload.
- JS menu manifest, parity, readers and bijection checks passed. Existing keys resolve in 21 locales; this does not certify genuine translations or the unpublished new prompt key.
- Five final portable AHK checks passed (encoding, syntax antipatterns, loop capture, verify-change registration/parser controls). Independent review additionally qualified format placeholders. New menu fixtures use recursive `_CTC_ReleaseMenu`; actual IEEE NaN/Infinity fixtures assert their native classification before invalid-input tests.
- Restoring only the actual pinned Linux provider yields 25 passed, 11 failed; restoring only the pinned macOS provider yields 18 passed, 12 failed. Both actual JS consumer guards reject the old providers. Controls preserve candidate bytes.
- Restoring only the actual pinned compiler rejects the check-caption declaration. Four actual malformed compiler controls also reject. Every refusal leaves the generated artifact unchanged.
- Two actual menu owner generations reproduce identical JSON SHA256 `c336001fd53c9154d138895bfcddeb474e71adf2c1e8755934285049c1256dcf`.

## Remaining limits and resumption

The 14-path combined packet has not received an independent complete cross-driver/shared review. Final five-file Windows source review is clear; runtime Windows suites and manual all-OS workflow_dispatch CI have not executed this packet. Packaging, installation, physical keyboard behavior, real macOS menu/AppleScript and Linux desktop interaction are unexecuted. Stubbed adapters and private filesystem tests are not device acceptance. Preserve transverse TODO 16 and 38.

Publish genuine 21-language prompt and existing Delay translations, regenerate with their actual owners, compose the current reviewed Metrics/check-template prerequisites, independently review the resulting packet, and run verify-change plus native CI on the final source SHA before integrating. The new Windows tests are registered in existing suites, including real writer/reload/refusal boundaries; registration alone is not execution.

Known existing native limits are not silently changed: shared schema maximum is 5 seconds while Windows/Linux runtime maximum is 10 seconds; the Windows scalar formatter may serialize Boolean values as integers because AHK uses integer Booleans; the existing Windows writer reconstructs its owned model and emits runtime TOML in CRLF. Arbitrary external comments, unknown root structures and future nested fields are not proven preserved by that owner. The new setter changes only the candidate duration and does not claim broader writer preservation. These are concrete source/policy follow-ups, not physical-machine-only blockers.

All retained AHK sources in this packet are UTF-8 with BOM and LF. Original independent head corpus bytes and original transaction test prefix are preserved; complete Windows menu expectations explicitly add the newly requested Delay row while preserving old head/native/caption/separator/payload/refusal assertions.
