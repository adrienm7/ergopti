"""Prepare prospective bounded cleanup refusal; performs no suite/import."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
PACKET = BASE.parent / 'group6-native-http-callee103-independent-proposal/candidate'
RELATIVE = 'static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
original = (PACKET / RELATIVE).read_text()
old = '''        except BaseException:
            cls.fixture.close()
            if cls.root is not None:
                shutil.rmtree(cls.root)
            raise
'''
new = '''        except BaseException as primary:
            root_refusal = None
            if cls.root is not None:
                try:
                    cls.build._root_owned()
                except BaseException as failure:
                    root_refusal = failure
            close_failure = None
            try:
                cls.fixture.close()
            except BaseException as failure:
                close_failure = failure
            if cls.root is not None and root_refusal is None and close_failure is None:
                try:
                    cls._root_removal_admitted()
                    shutil.rmtree(cls.root)
                except BaseException as failure:
                    root_refusal = failure
            # These are retained failure facts, never a second process owner.
            cls.root_cleanup_failures = [
                failure for failure in (close_failure, root_refusal) if failure is not None
            ]
            if cls.root_cleanup_failures:
                raise primary from cls.root_cleanup_failures[0]
            raise

    @classmethod
    def _root_removal_admitted(cls):
        # Bounded pathname identity admission, not an atomic deletion proof.
        cls.build._root_owned()
        if (
            cls.fixture.closed is not True
            or cls.fixture.command_group_debt
            or cls.fixture.command_file_debt
            or cls.fixture.trust_attempted
            or cls.fixture.keychain_created
            or cls.fixture.receiving_facts()["active"]
        ):
            raise RuntimeError("Native fixture build root cleanup remains unsettled")
        if any(not worker_receiving_facts(value)["settled"] for value in cls.receiving_workers):
            raise RuntimeError("Native fixture receiving child remains unsettled")
'''
assert original.count(old) == 1
candidate = original.replace(old, new, 1)
old_prefix = '''    def tearDownClass(cls):
        try:
            cls.fixture.close()
'''
new_prefix = '''    def tearDownClass(cls):
        root_refusal = None
        try:
            cls.build._root_owned()
        except BaseException as failure:
            root_refusal = failure
        try:
            cls.fixture.close()
        except BaseException as primary:
            if root_refusal is not None:
                raise primary from root_refusal
            raise
'''
assert candidate.count(old_prefix) == 1
candidate = candidate.replace(old_prefix, new_prefix, 1)
old_receipt = '''        receipt = json.loads((cls.root / "source-receipt.json").read_text())
'''
new_receipt = '''        if root_refusal is not None:
            raise root_refusal
        cls._root_removal_admitted()
        receipt = json.loads((cls.root / "source-receipt.json").read_text())
'''
assert candidate.count(old_receipt) == 1
candidate = candidate.replace(old_receipt, new_receipt, 1)
old_remove = '''        shutil.rmtree(cls.root)
        if all(worker_receiving_facts(value)["settled"] for value in cls.receiving_workers):
'''
new_remove = '''        cls._root_removal_admitted()
        shutil.rmtree(cls.root)
        if all(worker_receiving_facts(value)["settled"] for value in cls.receiving_workers):
'''
assert candidate.count(old_remove) == 1
candidate = candidate.replace(old_remove, new_remove, 1)
# Exact finite reverse, no regenerated independent expectations.
inverse = candidate.replace(new_remove, old_remove, 1).replace(new_receipt, old_receipt, 1).replace(new_prefix, old_prefix, 1).replace(new, old, 1)
assert inverse == original
ast.parse(candidate)
target = BASE / 'prospective-candidate' / RELATIVE
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(candidate)
(BASE / 'prospective.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True), fromfile='a/' + RELATIVE, tofile='b/' + RELATIVE)))

def body_map(source):
    lines = source.splitlines(True)
    return {node.name: ''.join(lines[node.lineno - 1:node.end_lineno]) for node in ast.walk(ast.parse(source)) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
old_map, new_map = body_map(original), body_map(candidate)
changed = sorted(name for name in old_map if old_map[name] != new_map[name])
assert changed == ['setUpClass', 'tearDownClass']
assert old_map['test01RealHTTPXFullURLPACURLFallbackAndVerifiedPhysicalChildEOF'] == new_map['test01RealHTTPXFullURLPACURLFallbackAndVerifiedPhysicalChildEOF']
assert old_map['test02ActualHFFactoryRedirectAuthRefusalAndNativeClosure'] == new_map['test02ActualHFFactoryRedirectAuthRefusalAndNativeClosure']
# Original independent builder altered only setUpClass; this follow-up also
# changes teardown, so its prior all13 remaining-body claim no longer applies.
def digest(content):
    return hashlib.sha256(content.encode()).hexdigest()
(BASE / 'prospective-review.json').write_text(json.dumps({
    'status': 'SOURCE_ONLY_CONDITIONAL_UNRUN',
    'path': RELATIVE,
    'preimage_sha256': digest(original), 'postimage_sha256': digest(candidate),
    'exact_inverse': inverse == original,
    'changed_original_functions': changed,
    'retained_original_function_count': len(old_map) - len(changed),
    'retained_original_functions': {name: digest(old_map[name]) for name in old_map if name not in changed},
    'new_function': '_root_removal_admitted',
    'scope': 'Bounded same-name replacement refusal; identity check is not atomic deletion authority.',
    'portable_tests': 'NOT_EXECUTED_PARENT_SERIAL_SLOT_HELD',
    'native_tests': 'NOT_EXECUTED',
}, indent=2, sort_keys=True) + '\n')
