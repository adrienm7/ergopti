import importlib.util
from pathlib import Path
import sys
import unittest
sys.path.insert(0,"/workspace/ergopti/tools/diagnostics")
root=Path(__file__).parent
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path)
 m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
new=module("new_capability_controls",root/"candidate/tools/diagnostics/macos_brew_archive_acceptance_test.py")
if sys.argv[1]=="old":
 old=module("old_capability_controls",root/"preimage/tools/diagnostics/macos_brew_archive_acceptance_test.py")
 new.TimeoutEvidenceMissingCapabilityControls.world=old.FirstCommandTimeoutControls.world
suite=unittest.TestSuite([new.TimeoutEvidenceMissingCapabilityControls("test_actual_missing_nofollow_refuses_before_child_acquisition_and_emits_closed_unexecuted_receipt")])
result=unittest.TextTestRunner(verbosity=2).run(suite)
assert result.testsRun==1
assert not result.skipped,"Existing mandatory no-skip registration rejects an unexecuted positive case"
assert result.wasSuccessful()
