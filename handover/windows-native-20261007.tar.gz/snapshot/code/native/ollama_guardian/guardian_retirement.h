#ifndef ERGOPTI_GROUP4_GUARDIAN_RETIREMENT_H
#define ERGOPTI_GROUP4_GUARDIAN_RETIREMENT_H
#include <stdint.h>

typedef struct {
    void *context;
    /* 1 is exact retained process terminal (or no process ever created),
       0 is pending, -1 is an external refusal. These are native owner ports. */
    int (*host_terminal)(void *);
    int (*job_empty)(void *);
    /* Releases only this owner's recorded copies, once. Pending source exit
       returns 0; a refused/uncertain native close returns -1 permanently. */
    int (*release_copies)(void *);
} GFR_Port;
typedef struct {
    uint32_t initialized, retired, uncertain, first_error, host_done, job_done;
    GFR_Port port;
} GFR_Owner;
int GFR_Init(GFR_Owner *, GFR_Port);
int GFR_Poll(GFR_Owner *);
#endif
