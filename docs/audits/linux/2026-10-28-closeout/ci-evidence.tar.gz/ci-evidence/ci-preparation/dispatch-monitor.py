#!/usr/bin/env python3
"""One-shot fix/linux CI dispatch and exact-source read-only monitoring."""
import argparse
import datetime as dt
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.parse
from zoneinfo import ZoneInfo

REPO = "adrienm7/ergopti"
BRANCH = "fix/linux"
WORKFLOW = 284301090
BASE = Path(__file__).resolve().parent
ROOT = Path("/workspace/ergopti-linux-integration")


def stamp():
    now = dt.datetime.now(dt.timezone.utc)
    return {"utc": now.isoformat(), "paris": now.astimezone(ZoneInfo("Europe/Paris")).isoformat()}


def save(path, value):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2) + "\n")
    tmp.chmod(0o600)
    tmp.replace(path)


def command(args):
    result = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(json.dumps({"command": args, "exit": result.returncode,
                                       "stderr": result.stderr.decode(errors="replace")}))
    return result.stdout


def api(path, paginate=False):
    args = ["gh", "api", path]
    if paginate:
        args += ["--paginate"]
    raw = command(args).decode("utf-8")
    if not paginate:
        return json.loads(raw)
    pages = []
    decoder = json.JSONDecoder()
    offset = 0
    while offset < len(raw):
        while offset < len(raw) and raw[offset].isspace():
            offset += 1
        if offset == len(raw):
            break
        page, offset = decoder.raw_decode(raw, offset)
        assert isinstance(page, dict), "API pagination must return JSON objects"
        pages.append(page)
    assert pages, "Empty API pagination output"
    return pages


def matching_runs(sha):
    query = urllib.parse.urlencode({"branch": BRANCH, "event": "workflow_dispatch", "head_sha": sha, "per_page": 100})
    pages = api(f"repos/{REPO}/actions/workflows/{WORKFLOW}/runs?{query}", True)
    rows = [row for page in pages for row in page["workflow_runs"]]
    unique = {row["id"]: row for row in rows}
    assert len(unique) == len(rows), "Duplicate run IDs in pagination"
    return list(unique.values())


def preflight(sha):
    local = command(["git", "rev-parse", "HEAD"]).decode().strip()
    assert local == sha, f"Local HEAD {local} differs from requested {sha}"
    assert not command(["git", "status", "--porcelain"]), "Integration source must be clean"
    remote = api(f"repos/{REPO}/branches/fix%2Flinux")["commit"]["sha"]
    workflow = api(f"repos/{REPO}/actions/workflows/ci.yml")
    actor = api("user")["login"]
    assert remote == sha, f"Remote fix/linux {remote} differs from requested {sha}; no dispatch"
    assert actor == "adrienm7", f"Unexpected actor {actor}"
    assert workflow["id"] == WORKFLOW and workflow["state"] == "active"
    return {"observed": stamp(), "sha": sha, "remote_sha": remote, "actor": actor,
            "workflow": workflow, "existing_runs": matching_runs(sha),
            "source_tree": command(["git", "rev-parse", "HEAD^{tree}"]).decode().strip()}


def dispatch(sha, directory):
    prepared = preflight(sha)
    save(directory / "dispatch-preflight.json", prepared)
    assert not prepared["existing_runs"], "An exact-SHA dispatch already exists; inspect without repeating"
    intent_path = directory / "dispatch-intent.json"
    descriptor = os.open(intent_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    intent = {"state": "intent_created", "source_sha": sha, "branch": BRANCH,
              "repository": REPO, "workflow_id": WORKFLOW, "actor": "adrienm7",
              "os_lanes": "linux", "existing_run_ids": [], "created": stamp()}
    with os.fdopen(descriptor, "w") as handle:
        json.dump(intent, handle, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    args = ["gh", "workflow", "run", "ci.yml", "--repo", REPO, "--ref", BRANCH, "-f", "os_lanes=linux"]
    intent.update(state="request_started", request_started=stamp(), command=args)
    save(intent_path, intent)
    # This is the only remote mutation. Never retry on uncertain response.
    result = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (directory / "dispatch.stdout").write_bytes(result.stdout)
    (directory / "dispatch.stderr").write_bytes(result.stderr)
    intent.update(state="response_recorded", request_finished=stamp(), exit_code=result.returncode)
    save(intent_path, intent)
    print(json.dumps({"dispatch_exit": result.returncode, "intent": str(intent_path)}), flush=True)
    return result.returncode


def discover(sha, directory):
    intent = json.loads((directory / "dispatch-intent.json").read_text())
    assert intent["source_sha"] == sha and intent["state"] in ("request_started", "response_recorded")
    rows = matching_runs(sha)
    save(directory / "discovery-latest.json", {"observed": stamp(), "runs": rows})
    earliest = dt.datetime.fromisoformat(intent["request_started"]["utc"]) - dt.timedelta(seconds=5)
    admitted = []
    for run in rows:
        assert run["head_sha"] == sha and run["head_branch"] == BRANCH and run["event"] == "workflow_dispatch"
        assert run["workflow_id"] == WORKFLOW and run["repository"]["full_name"] == REPO
        assert run["actor"]["login"] == "adrienm7"
        created = dt.datetime.fromisoformat(run["created_at"].replace("Z", "+00:00"))
        if run["id"] not in intent["existing_run_ids"] and created >= earliest:
            admitted.append(run)
    assert len(admitted) <= 1, "Multiple matching runs; do not select newest or redispatch"
    if not admitted:
        return None
    run = admitted[0]
    record = {"observed": stamp(), "id": run["id"], "attempt": run["run_attempt"],
              "source_sha": sha, "url": run["html_url"], "run": run}
    target = directory / "admitted-run.json"
    if target.exists():
        prior = json.loads(target.read_text())
        assert prior["id"] == record["id"] and prior["attempt"] == record["attempt"]
    else:
        save(target, record)
    return record


def jobs_for(run_id, attempt):
    pages = api(f"repos/{REPO}/actions/runs/{run_id}/attempts/{attempt}/jobs?per_page=100", True)
    jobs = [job for page in pages for job in page["jobs"]]
    assert len(jobs) == len({job["id"] for job in jobs}), "Duplicate job ID"
    assert pages and all(page["total_count"] == len(jobs) for page in pages), "Incomplete jobs pagination"
    return jobs


def failure_log(job, directory):
    target = directory / f"job-{job['id']}-cli-log.json"
    if target.exists():
        return
    # Keep the actual CLI bytes. A failed download is evidence unavailable, never a success.
    raw = directory / f"job-{job['id']}.cli.log"
    err = directory / f"job-{job['id']}.cli.stderr"
    with raw.open("wb") as stdout, err.open("wb") as stderr:
        child = subprocess.run(["gh", "run", "view", "--repo", REPO, "--job", str(job["id"]), "--log"],
                               cwd=ROOT, stdout=stdout, stderr=stderr)
    receipt = {"observed": stamp(), "job_id": job["id"], "exit": child.returncode,
               "bytes": raw.stat().st_size, "sha256": hashlib.file_digest(raw.open("rb"), "sha256").hexdigest(),
               "format": "raw gh CLI transcript, not original runner log bytes"}
    if raw.stat().st_size <= 32 * 1024 * 1024:
        packed = raw.with_suffix(raw.suffix + ".gz")
        with raw.open("rb") as source, gzip.open(packed, "wb") as destination:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                destination.write(chunk)
        receipt["gzip"] = packed.name
        raw.unlink()
    else:
        receipt["oversize_retained_locally"] = True
    save(target, receipt)


def monitor(sha, directory, seconds):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        admitted = discover(sha, directory)
        if admitted is None:
            print(json.dumps({"observed": stamp(), "status": "awaiting run discovery"}), flush=True)
            time.sleep(15)
            continue
        run = api(f"repos/{REPO}/actions/runs/{admitted['id']}")
        assert run["head_sha"] == sha and run["head_branch"] == BRANCH
        assert run["event"] == "workflow_dispatch" and run["workflow_id"] == WORKFLOW
        assert run["run_attempt"] == admitted["attempt"], "Attempt changed; do not mix results"
        jobs = jobs_for(admitted["id"], admitted["attempt"])
        snapshot = {"observed": stamp(), "run": run, "jobs": jobs}
        save(directory / "monitor-latest.json", snapshot)
        for job in jobs:
            if job["conclusion"] in ("failure", "timed_out", "cancelled", "action_required"):
                failure_log(job, directory)
        verdicts = [{"id": j["id"], "name": j["name"], "conclusion": j["conclusion"]} for j in jobs
                    if "Verdict (All mandatory results)" in j["name"]]
        brief = {"observed": stamp(), "run_id": run["id"], "status": run["status"],
                 "conclusion": run["conclusion"], "jobs": len(jobs), "verdicts": verdicts,
                 "failures": [{"id": j["id"], "name": j["name"], "conclusion": j["conclusion"]}
                              for j in jobs if j["conclusion"] in ("failure", "timed_out", "cancelled", "action_required")]}
        with (directory / "monitor-progress.jsonl").open("a") as handle:
            handle.write(json.dumps(brief) + "\n")
        print(json.dumps(brief), flush=True)
        if run["status"] == "completed":
            required = ["Common / Verdict (All mandatory results)",
                        "Linux / Verdict (All mandatory results)",
                        "Release / Verify all lanes and original plan"]
            mandatory = {name: [j for j in jobs if j["name"] == name] for name in required}
            snapshot["mandatory_jobs"] = {name: [{"id": j["id"], "status": j["status"],
                                                   "conclusion": j["conclusion"]} for j in rows]
                                          for name, rows in mandatory.items()}
            qualified = run["conclusion"] == "success" and all(
                len(rows) == 1 and rows[0]["status"] == "completed"
                and rows[0]["conclusion"] == "success" for rows in mandatory.values())
            snapshot["qualified_green"] = qualified
            save(directory / "terminal.json", snapshot)
            return 0 if qualified else 1
        time.sleep(30)
    save(directory / "monitor-timeout.json", {"observed": stamp(), "source_sha": sha,
                                             "meaning": "monitor stopped; CI result remains unknown"})
    return 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("preflight", "dispatch", "discover", "monitor"))
    parser.add_argument("sha")
    parser.add_argument("--seconds", type=int, default=21600)
    args = parser.parse_args()
    assert re.fullmatch(r"[0-9a-f]{40}", args.sha), "A complete lowercase SHA is required"
    directory = BASE / args.sha
    directory.mkdir(mode=0o700, exist_ok=True)
    if args.mode == "preflight":
        receipt = preflight(args.sha)
        save(directory / "preflight.json", receipt)
        print(json.dumps({"preflight": "ready", "sha": args.sha, "existing_runs": len(receipt["existing_runs"])}))
        return 0
    if args.mode == "dispatch":
        return dispatch(args.sha, directory)
    if args.mode == "discover":
        receipt = discover(args.sha, directory)
        print(json.dumps(receipt))
        return 0 if receipt else 2
    return monitor(args.sha, directory, args.seconds)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"error": str(error), "observed": stamp()}), file=sys.stderr, flush=True)
        raise SystemExit(1)
