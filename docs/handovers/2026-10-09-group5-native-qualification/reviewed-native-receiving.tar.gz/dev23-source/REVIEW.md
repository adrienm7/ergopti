# Current Dev synchronization source preparation

CLEAR for the bounded source composition, with shared ownership and qualification pending.

This packet binds 23 resolved paths to genuine Group 5 commit
6e67c5da3a9e91edbd6a9d692c71a557a7d7c567 and Dev commit
9652afc3d121b19851e02d93446d91e4c1fcc877, merge base
56cbdc4ecf8a0659a4d57483508f478445297043 and preview tree
e07ba5bcb33c1110784e0797515dcfea12b7d355. All 69 captured preimages
match the earlier reviewed proposals exactly; all 23 proposed postimages remain
identical to those earlier source images. No translation or functional source
change was required to adapt this cohort to the current parents.

Each of the 21 canonical locale JSON files preserves every Dev key, value and
order. Its nine original language-specific Group 5 additions remain whole,
with only the necessary separator adjustment. Exact removal recovers the entire
Dev file; all 189 additions are borrowed, and duplicate keys are rejected.
Healthcheck preserves the entire Dev source plus the two Group 5 structural
factory contracts: the actual ADAPTER_SPECS table contains 59 unique IDs.
Main preserves every Dev byte except the two owned explicit worker dispatch
insertions. The previous native roles, keyboard geometry behavior, private umask
and default GUI entry remain whole. These declarations do not activate an owned
runtime or prove hardware behavior.

Both 23-path patches were actually checked, applied, checked in reverse and
reversed in separate temporary sparse contexts. Every resulting postimage and
recovered preimage is exact. This is patch preparation evidence, not an executed
application or native test suite. PREIMAGES-AND-PRESERVATION.json includes the
full current Git blob identities, SHA-256 values and inverse results.

The genuine auto-merged manifest and menu-generator source preserve the complete
current Dev source after inverting only the original Group 5 delta with exact
unique surrounding contexts. The feature generator remains unchanged across
both parents and base. GENERATOR-FOLLOWUP.json records the genuine inputs,
commands and all six feature/config outputs plus the shared menu output.
Coordinate their regeneration with G1. The locale-table generator reads only
locale order/names, whose input bytes are unchanged; it does not regenerate
translated locale JSON values. The architecture generator reads the combined
adapter/port/domain tree and belongs to a separate owner followup, run last when
selected. Merge-tree generated artifacts are recorded as unqualified snapshots.
The unrelated hardcoded Windows-path locale injection helper is not a generator
for this task. No expected independent corpus or historical witness is recut.

No canonical file, index, Git ref, shared generator, generated artifact or
workflow was modified. No JS/native suite, compiler, release, installation or
CI was executed. Shared ownership remains pending; the three other conflict
paths are outside this packet and owned by the parallel workflow reviewer.
Final merge sources require their ordinary owner regeneration and verify-change
qualification. No integration into Dev is authorized by this source receipt.

The three refused metadata preparation attempts are retained separately. Their
corrected context/absence handling changes only this private evidence script;
they do not weaken application or test assertions.
