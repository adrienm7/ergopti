'use strict';

// Inert raw-byte endpoint only; no collector, native driver, network or hooks.
const fs = require('node:fs');
function readExact(length, done) {
    const buffer = Buffer.alloc(length);
    let offset = 0;
    function next() {
        fs.read(3, buffer, offset, length - offset, null, (error, count) => {
            if (error || count <= 0 || count > length - offset) return fail();
            offset += count;
            if (offset === length) done(buffer);
            else next();
        });
    }
    next();
}
function writeExact(buffer, done) {
    let offset = 0;
    function next() {
        fs.write(3, buffer, offset, buffer.length - offset, null, (error, count) => {
            if (error || count <= 0 || count > buffer.length - offset) return fail();
            offset += count;
            if (offset === buffer.length) done();
            else next();
        });
    }
    next();
}
function fail() {
    fs.writeSync(2, Buffer.from('INERT_FD3_REFUSAL\n'));
    process.exitCode = 1;
    try { fs.closeSync(3); } catch {
        fs.writeSync(2, Buffer.from('INERT_FD3_CLOSE_REFUSAL\n'));
    }
}
readExact(4, (header) => {
    const length = header.readUInt32LE(0);
    if (length < 1 || length > 4096) return fail();
    readExact(length, (payload) => {
        writeExact(Buffer.concat([header, payload]), () => {
            fs.writeSync(1, Buffer.from('INERT_FD3_COMPLETE é ☃\n', 'utf8'));
            fs.writeSync(2, Buffer.from('INERT_FD3_STDERR α\n', 'utf8'));
            fs.closeSync(3);
        });
    });
});
