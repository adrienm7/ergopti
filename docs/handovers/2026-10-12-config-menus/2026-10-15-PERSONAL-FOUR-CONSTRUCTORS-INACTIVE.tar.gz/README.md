# Inactive four-constructor Windows Personal proposal

This packet supplies source for all four current Windows Personal frame sites,
not an integrated feature. Native Windows parsing, callback/lifetime behavior,
cleanup, unit/E2E, packaging, installed startup and physical acceptance are UNRUN.
No census baseline, independent corpus, generated output, runner, workflow,
registration, Root proof helper or Root JS consumer is modified.

The exact three-file source preimage is published feature commit
`280174ee225a5d28869efec6061e43dd20bfe015`. A fresh read after the separate
publication `02713ee472c70ac2a659f5798953c9749e883349` confirms those preimages
remain byte-identical. The files are listed in `PATCH-MANIFEST.json` with
preimage, postimage and patch SHA-256 fingerprints. `SHA256SUMS` seals this packet.

`HANDWRITTEN-FOUR-SITE-CONTRACT.json` was written before the new producer. It maps
native descriptors, callback and child identities, late count owners, ordering,
placement and cleanup independently of the candidate output. All four recipes
are Windows-only and add no labels, translations or OS fallback policy.

The first site reuses the previous sealed default-child proposal exactly:
shared allocation, caller ledger registration, native default DATA, two frame
reads and original count/child handoff. Its original four independent control
inputs remain byte-identical under `prior-controls/`; their original expected
verdicts are not regenerated. The current Root helper does not yet understand
that recipe.

The additional three sites share one finite placement interpreter. File and
folder allocations, ledger registration, recursive traversal, captions, coercion,
callback factories and all four existing primary/cleanup blocks retain their
original bytes. File and folder native placement retain two frame reads.
Directory reads retain their two distinct empty command maps. The original
native count expressions are closures evaluated only after the append, keeping
late variable reads even if a provider replaces its rows. The recursive Array
handoff returns first-materialization rows without a native append/count read.

## Received checks and mandatory joins

`BOUNDED-CHECKS.json` records 40 bounded source/data checks, zero failures. These
include the actual owner convention functions against only the three candidate
files, UTF-8 BOM/LF, lexical brace balance (not an AHK parse), unchanged old
manifest values, all original cleanup blocks, independent literal declarations,
placement/count ordering and the current Root rejection. `git apply --check
--whitespace=error-all` accepts the combined patch on the fresh matching source.

The current Root physical proof accepts the original default, file and complete
folder owners and rejects the candidate versions. This is an expected BLOCKING
owner join; the packet does not weaken or replace those proofs. The current
schema also accepts malformed versions of all four new recipe records because
it has no validation for them. That acceptance is a demonstrated schema gap,
not successful qualification. Root must add closed validation and compose both
`test-menu-manifest.cjs` and `test-menu-parity.cjs` with the physical proof helper
before adoption, retaining all independent negative/mutation expectations.

The existing native 31 behavioral and 12 source-witness cases remain UNRUN.
The three additional sites need native coverage of ordinary/empty/adopted data,
two materializations, late provider count changes, both recursive handoff forms,
whole-tree refusal, source withdrawal and primary-error-preserving cleanup.
`verify-change` selects AHK encoding, general units, parse, E2E and JS. These
complete gates are UNRUN on this inactive proposal. After the owner join, use the
actual menu generator, retain original corpora/assertions, review its generated
diff and execute the selected complete gates and Windows receiving. The existing
Windows-only counts are not extrapolated to macOS/Linux qualification.

Two preliminary bounded-check fixture authoring errors are preserved as
unqualified logs: comparing parser null-prototype records to cloned ordinary
objects, and assuming three rather than the actual four unchanged cleanup
blocks. They were corrected in the external checker only. Neither is a native
or production regression, and no producer/assertion was changed to hide one.

## Reproduce without touching a checkout

Extract the packet into a fresh owned external directory and verify SHA256SUMS.
Run `python3 materialize.py /path/to/ergopti` to obtain six sealed before/candidate
files using read-only `git show` and zero-fuzz external patch application. Then
run `ERGOPTI_PROPOSAL_SOURCE_ROOT=/path/to/ergopti node check-proposal.cjs` with the
repository's pinned Node/dependencies. The checker reads the current Root
helper/schema to expose its current verdict; a later explicit owner join should
change those formerly expected blocking observations and requires fresh review.
Do not extract, materialize or apply the packet over an active gate checkout.
