"""Compact genuine private Git/source preparation; no canonical mutation or GHA context."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess

root=Path('/workspace/ergopti')
base=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/xi2-declared-local-native-components-v1')
assert not base.exists()
base.mkdir()
source=base/'source';source.mkdir()
declaration=Path('/workspace/.ergopti-cloud/continuation-2026-10-13/xi2-declaration-current-source-proposal-v1')
receiver=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/xi2-declared-runtime-receiver-successor-v3')
hardware='static/ergopti_plus/linux/tests/hardware/'
files=[hardware+n for n in ['native_fixture_family.py','run_xi2_property_cookies.py','xi2_property_cookie.c','xi2_property_types.h','xi2_property_display.py','xi2_luajit_abi.c','xi2_luajit_receiver.lua','run_xi2_luajit_diagnostic.py','test_xi2_luajit_diagnostic_portable.py']]
files+=['static/ergopti_plus/linux/adapters/xkb_source_probe.lua','static/ergopti_plus/linux/infra/display_server.lua','static/ergopti_plus/_shared/lua/logger/shim.lua','static/ergopti_plus/_shared/lua/logger/init.lua','static/ergopti_plus/_shared/data/linux_native_runtime.json','tools/codegen/codegen-linux-native-runtime.cjs']
pins=[]
for name in files:
    target=source/name;target.parent.mkdir(parents=True,exist_ok=True)
    data=(root/name).read_bytes()
    origin='canonical-current'
    if name in [hardware+'xi2_luajit_receiver.lua',hardware+'run_xi2_luajit_diagnostic.py',hardware+'test_xi2_luajit_diagnostic_portable.py']:
        data=(receiver/'projection'/name).read_bytes();origin='reviewed-receiver-V3'
    if name in ['static/ergopti_plus/_shared/data/linux_native_runtime.json','tools/codegen/codegen-linux-native-runtime.cjs']:
        data=(declaration/'postimages'/name).read_bytes();origin='frozen-declaration-source-proposal'
    target.write_bytes(data)
    pins.append({'path':name,'origin':origin,'sha256':hashlib.sha256(data).hexdigest()})
# Consume the actual proposed generator; its read callback copies only genuine current dependencies.
script=r'''const fs=require('fs'),path=require('path');const [canonical,source]=process.argv.slice(1);const owner=require(source+'/tools/codegen/codegen-linux-native-runtime.cjs');const data=JSON.parse(fs.readFileSync(source+'/'+owner.SOURCE,'utf8'));const reads=[];const outputs=owner.render(data,name=>{const image=fs.readFileSync(canonical+'/'+name,'utf8');const destination=source+'/'+name;fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,image);reads.push(name);return image;});for(const [name,image]of Object.entries(outputs)){const destination=source+'/'+name;fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,image);}console.log(JSON.stringify({reads,outputs:Object.keys(outputs)}));'''
generated=json.loads(subprocess.check_output(['node','-e',script,str(root),str(source)],text=True))
assert not any(n.startswith('.github/') or n.endswith('PINS.json') for n in generated['reads']+generated['outputs'])
runtime=source/'static/ergopti_plus/linux/_generated/native_runtime.lua'
assert runtime.read_bytes()==(declaration/'postimages/static/ergopti_plus/linux/_generated/native_runtime.lua').read_bytes()
subprocess.run(['git','init','-q',str(source)],check=True)
canonical_objects=(root/'.git/objects').resolve(strict=True)
(source/'.git/objects/info/alternates').write_text(str(canonical_objects)+'\n')
subprocess.run(['git','config','user.name','Ergopti Local Source Fixture'],cwd=source,check=True)
subprocess.run(['git','config','user.email','local-source-fixture@invalid'],cwd=source,check=True)
names=[str(p.relative_to(source)) for p in sorted(source.rglob('*')) if p.is_file() and '.git' not in p.relative_to(source).parts]
subprocess.run(['git','add','--',*names],cwd=source,check=True)
subprocess.run(['git','commit','-q','-m','test: freeze genuine local declared XI2 component sources'],cwd=source,check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
manifest={'status':'GENUINE_PRIVATE_LOCAL_SOURCE_COMMIT','canonical_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_commit':commit,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),'source':str(source),'original_inputs':pins,'generated':generated,'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'GHA_context':'NONE','official_wrapper':'UNRUN_GHA_AND_ROOT_OWNERSHIP_BARRIERS','canonical_changes':False}
(base/'SOURCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'directory':str(base),'source_commit':commit,'files':len(names),'generated':generated},indent=2))
