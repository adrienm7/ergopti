# Genuine Browse adapter V4

This private source packet has not been parsed, installed, or executed. It changes
no repository source, Git state, saved environment configuration, existing
activation, namespace, or tooling prefix. The original five-mode V7 packet and
its independent original 21-locale/preset expectations remain byte-identical.
The Browse directory/title expectations were frozen before actor authoring and
are copied unchanged from V1.

V1's independent review found one actor failure-accounting blocker. V2 moves
post-argument setup into the protected native attempt, tries its durable receipt
independently, retains the raw primary exception object, and records secondary
receipt/log debt. Invalid CLI argument parsing remains normal usage validation;
it is not claimed to produce a native receiving receipt. Genuine native
window/process ownership, XTest commands, and original expectations are retained.

The new worker opens the actual configured wizard with real Manager/Startup,
I18n, WebKit, picker, shell, modal, path resolver, and directory-reading modules.
It clicks the actual Browse button four times: cancel, accept a independently
predetermined path containing spaces, cancel while retaining that accepted path,
and retry with the second original path. Only the genuine external XTest actor
operates the native chooser while the GTK callback blocks. No chooser result,
command output, DOM folder value, host callback, or native writer is mocked.
After each picker result, real Next requests the chosen folder through the
unchanged host and real Back permits another Browse. The worker never clicks
Finish; close/reopen must restore the old published folder.

The controller requires a real successful retained V7 profile, reconciles its
entire actual preallocation snapshot with that earlier result, and refuses
existing target directories. It directly imports the frozen original
OwnedSession lifecycle owner after byte guards, retains each unreaped native
PGID/starttime, observes actual commands through the owner's status files, and
independently retires every exact owned group before final qualification. Config,
bootstrap, former/current presets, metrics bytes, and both empty new targets are
checked independently before/after input and after cleanup. All654 production
source pins, original V7 pins, and read-only HEAD/index/status fences are checked.

V3 preserved V2 Sources except two reviewed fixture corrections: JSON is encoded
before acquiring its output stream, and both Git fence reads explicitly use a
Git-only environment with GIT_OPTIONAL_LOCKS=0. The V1 and V2 packets remain
immutable; no canonical index refresh is authorized by the new fixture.

V4 changes only installer verification/provenance: actual V3 installation failed
before prefix allocation because /usr/bin/gpgv is absent. The genuine installed
APT verifier sqv is pinned by binary, installed package and Root observed version.
Its default current-time/expiry/cryptographic/trust policies remain intact.
Verified cleartext is written to a new owned private file, then its unique
SHA256 Packages entry must match the original frozen hash and byte size before
prefix allocation or downloads. Successful installation retains that authentic
output and verifier command/exit/provenance in the receipt. Source review does
not replace that genuine signature execution; V3 failure evidence is retained.
DEPENDENCIES/package rows, wrapper, controller, worker, actor and all oracles
remain exact V3 bytes. The V3 literal gpgv readiness description in the preserved
DEPENDENCIES file is historical and superseded only by this explicit V4 verifier
provenance; its hashes, package authority and trust anchors are unchanged.

## Root execution after gates are terminal

First review the frozen Sources and release the native slot. Installation uses
only the new `/workspace/tooling/wizard-browse-zenity-v1` prefix, refuses an
existing prefix, verifies genuine cached InRelease with the pinned APT sqv verifier, downloads exactly
the11 signed-index pinned packages (9,624,216 bytes), checks size/hash/control
identity, extracts genuine artifacts, and compiles their actual GTK4 schemas.
The existing wrapper simply sets its isolated library path and execs zenity
without changing arguments, stdout, or exit status. Existing namespaces and
activation files are unchanged. Name closure and Source provenance alone do
not qualify package version constraints, actual loader, schema, renderer, or GUI
readiness. Root must inspect those actual results and retain the install receipt.

```bash
python3 /workspace/ergopti-delivery/group1-complete-resume-20261007/linux-wizard-genuine-browse-adapter-source-v4-sqv-verifier-20261011/install-owned-chooser.py --execute
```

Next run the original V7 five-mode scenario in its reviewed native slot, unchanged,
and retain its actual PASS result/profile. Then use its exact ACTUAL-RESULTS path:

```bash
python3 /workspace/tooling/run-with-reaper.py \
  python3 /workspace/tooling/run-with-gtk-namespace.py \
  python3 /workspace/ergopti-delivery/group1-complete-resume-20261007/linux-wizard-genuine-browse-adapter-source-v4-sqv-verifier-20261011/run-browse.py \
  --checkout /workspace/ergopti \
  --v7-receipt /ABSOLUTE/RETAINED/V7/actual-wizard-OWNED/ACTUAL-RESULTS.json \
  --execute
```

The original saved reaper/namespace wrapper owns the invocation. The new chooser
prefix is visible at its absolute workspace path in that unchanged namespace.
The adapter adds only the new wrapper PATH entry and schema directory to its
private environment. Logs, atomic handshake files, native/actor receipts and
ACTUAL-RESULTS are written under a fresh private `actual-browse-*` directory.
The original V7 profile only receives the two new predetermined empty target
directories; its configuration and bootstrap are never rewritten by the fixture.

## Claims and limitations

Actor INPUT_SEQUENCE_COMPLETED proves input and chooser retirement only. PASS
requires all four genuine DOM/folder-read phases, real close/reopen, independent
file oracles, cleanup acknowledgement, and final Source/Git reconciliation.
This packet does not directly capture production shell stdout/exit; the actual
unmodified picker receives those internally and its DOM receiving is tested.
The independently frozen standalone stdout/exit assertions remain explicitly
UNRUN, alongside physical input, Wayland, installed daemon restart, Windows,
macOS and native chooser labels in all21 languages. A private virtual X11 test
cannot substitute for those validations. Runtime failures must be preserved and
fixed; dependency extraction or Source review must never be called native PASS.
