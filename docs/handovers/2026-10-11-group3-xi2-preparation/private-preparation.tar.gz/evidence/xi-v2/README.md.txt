<!-- README.md -->

# Private Xi dependency receiving candidate V2

This inactive 14-path patch is against `2c144060853239c9c416ea1a9c08030382ed2b1f` in the parent-created detached worktree `/workspace/.ergopti-cloud/worktrees/group3-xi2-forward`. Canonical sources, index, refs and CI were not changed. The private index remains untouched; the worktree contains only these reviewable unstaged changes. Shared Root/fix-linux/G6 adoption custody remains pending.

The patch contains three handwritten catalogue/generator/stager sources, six genuine generated projections, four existing registered guards and one workflow file with only two `libxi-dev` tokens added. Original four libraries remain the exact prefix; independent fifth Xi/provider/pkg-config/Nix/root expectations are added. Runtime package names come from the prior official metadata receipts, not candidate projections. Current Nix is `libxi`; no other existing library or requirement is migrated.

The actual owning generator was run in this private worktree. All seven registered outputs reproduce byte-exactly: six changed and the portable trust template is unchanged. No generated file was hand-edited. `generator-result.json` pins each image. The stager resolves actual xi.pc library metadata, requires a regular resolved source and exactly one ELF SONAME, then uses the original copy owners and ELF closure. OpenSSL, GIO/schema/Flatpak/trust, glibc exceptions, deadlines, retained FDs and installed network probe are unchanged. Ruff changed only Python presentation; AST equality against reviewed V1 is recorded.

## Actual receiving

All five final targeted guards exited zero serially through activation and the existing owned subreaper:

- Launcher: original 24 mappings/48 modeled admission trials retained, plus six Xi mappings/12 trials; final truthful total 30/60.
- Network: 39 groups, zero skips; original 26 plus 13 additive Xi groups.
- Crypto: original 21 groups, zero failures/skips.
- Portable packaging: original controls retained, two per-job xi.pc prerequisites added, and 25 controlled Xi resolver/copy/closure cases passed.
- Portable registration: original 12 admission controls passed.

`targeted-final` retains exact commands, outer exits and raw stdout/stderr with before/after source hashes. Earlier five successful targeted runs are retained separately; their launcher still printed the old hardcoded 24/48 summary, which was corrected before final receiving.

Sixteen counterfactual runs matched their predeclared exits: four original-source/original-test guards passed; four updated guards rejected original source; the original stager and seven narrow omissions all failed. The omissions cover generator validation, resolver descriptor checks, ELF SONAME checks, explicit root copy, closure seeding and each of the two job-local build prerequisites. Each case retains its changed source image, command, raw streams, exit and before/after closure. Original images and all final images were restored exactly after the serial runs. Some original GIO failure wrappers expose only the controlled child's nonzero status at their unchanged outer assertion; no inner raw diagnostic is claimed where it was not forwarded.

The 25 Xi cases execute the real Python resolver/copy/closure code with independent command replies and ordinary sample files. File writes, retained destination ownership, conflicting-copy refusal, descriptor retirement, original seed order, Xi explicit copying and transitive dependency copying are exercised. No dummy bytes or mocked pkg-config/readelf/ldd replies are represented as real ELF/native proof. Existing meaningful repair refusals, historical floors and package conditions remain unchanged.

## Review and recovery

`receipt.json` pins all 14 pre/post/blob/mode pairs and unchanged effective source consumers. `candidate.patch` is the complete Git diff against the pinned base. `source-pair.tar.gz` contains only 28 regular pre/post source members with deterministic metadata. The sealer verified every member and every in-memory full forward/inverse patch roundtrip. Removing the new Xi resolver/stage spans restores the complete original stager; removing the two package tokens restores the complete original workflow. The original V1 packet and independent three-source/six-projection review remain unchanged and are referenced.

Verify transport bytes with `sha256sum -c files.sha256` in this directory. Source review and any application must recheck actual receiving preimages; do not overwrite a later owner's image. No commit, push or canonical application is part of this packet. The preparation helpers are retained for provenance, not instructions to run into an already occupied immutable receiving directory.

## Unqualified receiving

No full JS suite, native suite, `--native` flag, GUI, device, input injection, display/queue operation or installed AppDir Xi load/export test ran. Existing installed network probe qualifies network components only. No local native prerequisite failure is inferred from lack of execution. Genuine installed Xi loading/required symbols and package/retirement evidence remain UNRUN, as do actual package builds and all six distributions/Nix/Flatpak receiving. Source metadata is not signature validation or binary qualification. The ordinary validation subreaper does not establish full native-family closure.

The two job-local `libxi-dev` prerequisites supply build metadata only; they grant no native output/source readiness. Existing Xi ABI/cookie/input/capture corpus is untouched and remains independent. No source epoch, physical device, modifier, output authority, CapsWord/OneShot or public simultaneous capability is enabled by this dependency tranche.
