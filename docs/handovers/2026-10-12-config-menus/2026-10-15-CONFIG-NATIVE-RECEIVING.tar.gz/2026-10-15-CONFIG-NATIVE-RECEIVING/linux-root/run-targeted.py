from pathlib import Path
import os, subprocess, tempfile, json
r=Path('/workspace/ergopti-root-picker'); out=Path('/workspace/.ergopti-cloud/resume-root-picker')
paths=['static/ergopti_plus/linux/ui/config_dir_picker.lua','static/ergopti_plus/linux/infra/config_paths.lua']
images={p:(r/p).read_bytes() for p in paths}
base={paths[0]:Path('/workspace/.ergopti-cloud/resume-config-picker-exit/candidate-picker.lua').read_bytes(), paths[1]:subprocess.check_output(['git','show','7523f4b:'+paths[1]],cwd=r)}
expr='require("compat.utf8").install(); local h=require("tests.helpers"); %s require("tests.unit.ui.test_native_dialog_titles"); require("tests.unit.meta.test_bridge_persistence"); local r=h.get_results(); print("RESULT",r.passed,r.failed); os.exit(r.failed==0 and 0 or 1)'
env=os.environ.copy(); env['TMPDIR']=env['TEMP']=tempfile.mkdtemp(prefix='eg-rp-',dir='/var/tmp'); env['LUA_PATH']='./?.lua;./?/init.lua;../_shared/lua/?.lua;../_shared/lua/?/init.lua;;'
results=[]
try:
 for phase, contents, filt in [('literal',base,'h.set_only_filter("linux-config-root:");'),('candidate',images,'')]:
  for p,b in contents.items(): (r/p).write_bytes(b)
  for engine in ['luajit','lua5.4']:
   worker=out/(phase+'-'+engine+'-worker.lua'); worker.write_text(expr%filt+'\n')
   proc=subprocess.run([engine,str(worker)],cwd=r/'static/ergopti_plus/linux',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   (out/(phase+'-'+engine+'.log')).write_bytes(proc.stdout)
   results.append({'phase':phase,'engine':engine,'exit_code':proc.returncode,'tail':proc.stdout.decode().splitlines()[-1]})
finally:
 for p,b in images.items(): (r/p).write_bytes(b)
(out/'targeted.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
