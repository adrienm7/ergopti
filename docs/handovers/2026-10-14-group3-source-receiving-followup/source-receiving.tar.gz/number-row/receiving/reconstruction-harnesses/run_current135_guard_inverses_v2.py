from pathlib import Path
import hashlib,json,subprocess,sys
p=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');post=p/'postimages/tools/diagnostics';receiver=(post/'number_row_native_causal.py').read_text();control=(post/'test_number_row_source_composition.py').read_text();h=lambda b:hashlib.sha256(b).hexdigest();original_sha=h(receiver.encode());rows=[]
closures='''    if SHA(serialized) != CURRENT_BUILD_INPUTS_SHA:
        raise ValueError("reviewed current build source closure refused")
'''
rejoin='''    for path, data in inputs.items():
        item = repo / path
        if item.is_symlink() or not item.is_file() or item.read_bytes() != data:
            raise ValueError("reviewed working source changed after reads: " + path)
'''
ancestry='''        if ancestry.returncode != 0:
            raise ValueError("approved committed source is not an ancestor")
'''
head_guard='''        if subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() != head:
            raise ValueError("actual current source commit changed")
'''
assert receiver.count(closures)==1 and receiver.count(rejoin)==1 and receiver.count(head_guard)==1
# Only remove the new current135 ancestry guard, not the original99 guard.
start=receiver.index('def _current_build_inputs');end=receiver.index('def _composition_contract',start);body=receiver[start:end];assert body.count(ancestry)==1
mutants=[('missing-finite-source-closure',receiver.replace(closures,''),'CurrentBuildControls.test_10_duplicate_foreign_or_symlink_source_refused'),('missing-final-working-rejoin',receiver.replace(rejoin,''),'CurrentBuildControls.test_13_unreceived_authority_digest_or_zero_review_refused'),('missing-current135-ancestry',receiver[:start]+body.replace(ancestry,'')+receiver[end:],'CurrentBuildControls.test_04_frozen_canonical_cannot_impersonate_current_supplier'),('missing-current135-head-guard',receiver.replace(head_guard,'        pass\n',1),'CurrentBuildControls.test_13_unreceived_authority_digest_or_zero_review_refused')]
argv=json.loads((p/'source-control-runs/current135-composition-controls-fresh-negative-root/argv.json').read_text())['argv'];root=json.loads((p/'sparse-fixtures.json').read_text());fixture=next(x for x in root if x['fixture']=='current135');argv[argv.index('--head')+1]=fixture['actual_private_controller_commit'];actual_root=Path(fixture['root']);out=p/'causal-omission-runs-v2-named-case';out.mkdir(exist_ok=True)
for name,mutant,selected in mutants:
 dest=out/name;dest.mkdir();source=dest/'number_row_native_causal.py';source.write_text(mutant);mutant_sha=h(source.read_bytes());test=dest/'single-controlled-source-case.py';body=control.replace(original_sha,mutant_sha);marker='if __name__ == "__main__":';begin=body.rindex(marker);body=body[:begin]+'''if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromName('''+repr(selected)+''', sys.modules[__name__])
    )
    raise SystemExit(0 if result.wasSuccessful() else 1)
''';test.write_text(body);command=list(argv);command[2]=str(test);command[command.index('--receiver')+1]=str(source);(dest/'argv.json').write_text(json.dumps({'argv':command,'cwd':str(actual_root),'expected':'controlled source invariant failure, never native evidence','selected_original_case':selected,'receiver_omission':name,'original_receiver_sha256':original_sha,'mutant_receiver_sha256':mutant_sha,'test_changes':'only explicit dependency hash and single-case main; all original15 assertion bodies intact'},indent=2)+'\n');result=subprocess.run(command,cwd=actual_root,capture_output=True,timeout=120);(dest/'stdout.raw').write_bytes(result.stdout);(dest/'stderr.raw').write_bytes(result.stderr);(dest/'exit.raw').write_text(str(result.returncode)+'\n');row={'name':name,'exit':result.returncode,'selected':selected,'original_sha256':original_sha,'mutant_sha256':mutant_sha,'stdout_sha256':h(result.stdout),'stderr_sha256':h(result.stderr)};rows.append(row);(out/'results-in-progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,result.returncode,flush=True);print(result.stderr.decode()[-1700:],flush=True);assert result.returncode!=0 and 'ModuleNotFoundError' not in result.stderr.decode() and selected.split('.')[-1]+' (__main__.CurrentBuildControls.' in result.stderr.decode() and 'AssertionError' in result.stderr.decode()
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2),flush=True)
