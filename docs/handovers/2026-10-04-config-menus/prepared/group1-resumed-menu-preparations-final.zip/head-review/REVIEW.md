# Independent resumed Tap-Hold key-head review

Verdict: **CLEAR for source integration and the selected verification gates**.
Reviewed frozen packet `tap-hold-key-head-current.patch`, SHA256 `b3ce412465b6b071106e63a50375bba66cfb9baea5d0c0a597c8c85dc661e4d1`,
16 paths against root base `6370e0d9344f1a94ce2caeddced4a0528ba93dfd`.
All exact preimages/postimages independently verified; root checkout, index,
branches, remotes and CI were not mutated.

The canonical shared declaration owns order, existing translated caption keys,
platform projection and include composition. Lua drivers share the renderer;
Windows supplies its native equivalent and callbacks. The original clearing
command declaration and readiness policy survive the include. Native picker,
writer, exact-regeneration and refusal owners remain unchanged; strict macOS
literal-true persistence receipts still gate regeneration and menu refresh.
The native mutation tests use actual provider closures. Linux classified writer
refusal/retry and macOS refusal/retry remain exercised by historical assertions.

All three old native test modules remain exact byte prefixes. The independent
native-command corpus is unchanged; the new key-head corpus stays handwritten.
No old corpus was derived from the candidate implementation. Touched AHK files
retain UTF-8 BOM; all 16 packet files are LF.

The first guard candidate incorrectly admitted include descendants from orphan
group-derived roots and did not reject reachable cyclic/missing include targets.
The frozen guard fixes both: only literal driver readers seed new include edges,
DFS rejects missing/cyclic targets, and an actual native recursive consumer is
required. Existing source/field/section floors, field assertions and historical
group suffix convention remain intact. Independent actual source/manifest
mutations reject orphan sections, mutually referencing orphan sections,
reachable self cycles, missing targets and a disconnected Windows recursive
consumer. The unmodified frozen guard passes: 42 fields, 50 sections,
972 production sources. No assertion was removed to obtain green.

Independent isolated checks:

- Linux owning module: 24 passed, 0 failed on Lua 5.4; separately 24/0 on LuaJIT.
- macOS owning module: 17 passed, 0 failed on Lua 5.4 with repository stubs.
- Actual manifest contract and menu parity: exit 0. Parity projects 46 menus,
  resolves 226 label keys in all 21 locales, and finds zero unreasoned hidden rows.
- Replacing only the three native providers with exact original base sources:
  Linux 21 passed/3 failed; macOS 14 passed/3 failed; actual JS wiring assertion
  fails. The independent order/caption/platform requirements cause these failures.
- Actual reader-guard successor mutations: five individually expected exit 1
  cases, with the specific unread/missing/cyclic classifications in retained logs.
- Repeated real menu generator output matches frozen postimage
  `cc0baec3287e107d446ccacda464c0e4afb3a8acb208d3920ca687c039f9782f`.

Qualification boundary: these focused runs do not qualify native Windows,
physical input, Hammerspoon/Karabiner, packaging or installation. The macOS
LuaJIT harness is unsupported and is not counted as a pass. Root still owns
serial full verify-change gates and three-OS workflow_dispatch qualification
for this shared three-driver change. Failed earlier native CI on an older SHA
is not a qualification of this packet. TODO54/81 remain partial: this is the
key head only, not delay, picker children or all native menu families.
