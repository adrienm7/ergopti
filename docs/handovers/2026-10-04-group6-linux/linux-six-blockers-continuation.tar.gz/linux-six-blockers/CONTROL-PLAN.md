# Six Linux producer blockers: source/control plan

Status: scratch-only focused correction packet. See VALIDATION.md for exact executed statuses; final producer composition remains unqualified. The live checkout, foreign fix/linux branch and frozen old packet remain unchanged. `preimages/` is the exact final frozen diagnostic candidate; `candidate/` overlays only the shared proxy policy JSON/Lua, new coordinator, GIO adapter, public wrapper dependency and one new absolute-deadline ledger.

## Native owner prerequisite and integration boundary

Current remote dev is `02ad69e06ecea424de11facf3dced404a6fdd602`; its HTTP core is SHA256 `0e50f5b7347be875d7d37f977424ff33379c280f98da3ca31a109ae420ef7a22`. Current foreign fix/linux is `ec9673283b6d2eb1dadc7914cbcfba5043f94957`; its HTTP core is SHA256 `8c5d52f8c1d2e11fea477bab68f764f0315ff1997556faab1a92e8c41c903305`. The foreign diff adds 166 and removes23 core lines and substantially extends the native assertions. Do not substitute our old extracted core: that loses actual anonymous body-pipe ownership/descriptors/retirement, request-body NUL admission, large/literal body support, POST303 conversion, globoff, explicit empty headers, complete error-body admission and refreshed relative timers.

The exact owner-authored `infra.native_timer.lua` from that SHA is stored only under `support/` as a qualification dependency (SHA256 `35db96358d9224e70b54d60cb1cadacc043186fa2dbab88d8340b570d6b49c63`). It is not an ours-owned production addition. It only refreshes/arms; it has no close ledger. Our new deadline ledger delegates arming to it and adds exact timer closure acknowledgement. Final composition must first obtain the published/owner-approved native helper and core bridge. Neither current core exports all private proxy selection/metrics, generic owned dispatch/preflight and logical-terminal observer seams. The public wrapper replacement and native extraction remain coordination points. Six corrected source blocks do not qualify that final bridge.

## Independently fixed causal controls

The public replay calls actual saved/new wrappers, actual unchanged saved native curl engine and actual GIO adapter through independent libuv ports. The two original public owned-cancellation assertion bodies (dev1234–1244 and1264–1270) are copied byte exact; no assertion or expected error is relaxed. The new deadline native dependency is represented by separately acknowledged timer events and close ACKs, not a production test override.

1. Cancel signal refusal keeps owned activity true while suppressing late completion, and preserves the independent owner.
2. Both successor APIs refuse behind owned debt until original process/pipe ACKs complete, with the exact cleanup-pending error and no new native acquisition.
3. Four supported-resolution/supervision failures return the original safe typed error, zero curl acquisition and unknown failure provenance. Two explicit missing-native/GDummy vectors retain ordinary routing. Shared fallback is driven by the new canonical two-code absence allowlist, never by arbitrary non-success.
4. A queued boolean request expires from an independent timer while predecessor ACKs are withheld; timeout once, no successor child, predecessor process debt still owned.
5. The actual GIO supervision timer publishes proxy-stage logical timeout while process exit/close ACKs remain withheld; later receipt cannot start curl or deliver another callback.
6. Boolean and owned success arriving after the original deadline but before timer dispatch become timeout; owned publication still waits physical ACK. A separately held deadline close ACK cannot publish a success after budget expiration.

The 13 public cases ran identically on original/corrected source (2/11 versus13/0). Four additional independent candidate-seam controls preserve their exact negative checkpoints. The ten new native-deadline ledger cases separately prove native helper clock refresh, unchanged remaining budget, logical/physical separation, refusal/missing/throwing arming receipts, stop/close retry, stale callback fencing and fixed diagnostic logging. They have no old production equivalent and must not be counted as baseline failures. Existing coordinator23, native adapter16 plus callback18, runtime9 and shared policy8 bodies/expectations remain unchanged: fixture migrations only add the newly required independent deadline port and `uv.update_time` port. Reverse-migration byte equality is checked before qualification.

## Deferred commands and scheduler

Source the existing cloud runtime helper, use `TMPDIR=/tmp`. Bind `ERGOPTI_SIX_ROOT` to this packet, `ERGOPTI_HTTP_REPOSITORY` to the dependency checkout, and `ERGOPTI_SIX_STAGE`/`ERGOPTI_MANAGED_HTTP_CANDIDATE` to `preimages` for original replay or `candidate` for corrected replay. Bind `ERGOPTI_PROXY_ADAPTER_CANDIDATE` to that stage's exact system_proxy.lua. Run `run-focused.lua` with `ERGOPTI_SIX_PHASE=public`, then `preserved`; only candidate has `deadline`. No test may start until root grants an exclusive serialized slot. Before failures, after passes/failures, skipped and unexecuted cases will be recorded separately.

These are model/native-port controls, not actual GIO/curl/kernel, E2E or installed packaging proof. Later actual GIO/curl/loopback timing/privacy and native qualification must compose the final approved core. Per-hop PAC redirects, updater exact file lease, owned Ollama installer/serve/pull and enterprise auth/trust/WPAD remain TODO62 work; original items16/38 validation requirements remain. Existing six E2E follow-ups in the saved README are separate from these six producer defects; four executed baseline scenarios still lack exact runtime causes.

Remaining estimate: 2–4 hours for six source corrections and scoped causal proofs; final core composition plus native gates another4–8 hours after owner alignment, excluding unrelated existing E2E causes and full TODO62 coverage.
