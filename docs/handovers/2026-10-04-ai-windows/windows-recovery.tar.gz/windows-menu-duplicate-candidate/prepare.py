from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path('/workspace/ergopti')
HERE = Path(__file__).resolve().parent
PATHS = ['infra/menu_dispatcher.ahk', 'infra/manifest_menu.ahk',
         'tests/run_llm_model_menu_disabled.ahk']
PRE = HERE / 'preimages'
CAND = HERE / 'candidate'
receipts = {}

def once(source, old, new):
    assert source.count(old) == 1, (source.count(old), old)
    return source.replace(old, new, 1)

for path in PATHS:
    raw = (ROOT / 'static/ergopti_plus/windows' / path).read_bytes()
    assert raw.startswith(b'\xef\xbb\xbf') and b'\r' not in raw
    s = raw.decode('utf-8-sig')
    if path == 'infra/menu_dispatcher.ahk':
        start = s.index('RegisterMenuItemInsert(MenuObj, BeforeItem, ItemName, Callback) {')
        end = s.index('\n; Parse the leading 1-based position', start)
        segment = s[start:end]
        segment = once(segment, '\t\ttry {\n\t\t\t\tMenuObj.Insert(BeforeItem, ItemName, Wrapper)',
            '\t\t; Blank BeforeItem appends a distinct row even when its label exists.\n'
            '\t\tAppend := BeforeItem == ""\n'
            '\t\tCountBefore := Append ? _MenuItemCount(MenuObj) : -1\n'
            '\t\tif Append && CountBefore < 0 {\n'
            '\t\t\t\ttry LoggerWarn("MenuDispatcher", "Could not read the native count before appending \'{1}\'.", ItemName)\n'
            '\t\t\t\treturn 0\n'
            '\t\t}\n\n'
            '\t\ttry {\n\t\t\t\tMenuObj.Insert(BeforeItem, ItemName, Wrapper)')
        segment = once(segment, '\t\tItemId := 0\n\t\tif (InsertPos > 0) {',
            '\t\tItemId := 0\n'
            '\t\tif Append {\n'
            '\t\t\t\tCountAfter := _MenuItemCount(MenuObj)\n'
            '\t\t\t\tif CountAfter != CountBefore + 1 {\n'
            '\t\t\t\t\t\ttry LoggerWarn("MenuDispatcher", "Native append count was refused for \'{1}\'.", ItemName)\n'
            '\t\t\t\t\t\treturn 0\n'
            '\t\t\t\t}\n'
            '\t\t\t\tItemId := _MenuItemIdAtPosition(MenuObj, CountAfter - 1)\n'
            '\t\t} else if (InsertPos > 0) {')
        segment = once(segment, '\t\tif (!ItemId) {\n\t\t\t\tItemId := _FindUniqueMenuItemIdByName(MenuObj, ItemName)\n\t\t}',
            '\t\tif (!ItemId && !Append) {\n\t\t\t\tItemId := _FindUniqueMenuItemIdByName(MenuObj, ItemName)\n\t\t}')
        segment = once(segment, '; (BeforeItem given as a name, not "N&"). A non-unique label degrades to',
            '; (BeforeItem given as a name, not "N&" or blank append). A non-unique label degrades to')
        s = s[:start] + segment + s[end:]
    elif path == 'infra/manifest_menu.ahk':
        start = s.index('_MR_RenderRows(TargetMenu, Rows, ListId, Depth, PopulationOwner := unset, RequireTracking := false) {')
        end = s.index('\n; Renders the same declared command/check', start)
        segment = s[start:end]
        segment = once(segment, '\t\tLabel := StrReplace(Label, "&", "&&")\n',
            '\t\tLabel := StrReplace(Label, "&", "&&")\n'
            '\t\t; Row data is appended, including equal labels and later population batches.\n'
            '\t\tRowPosition := TrayMenuItemCount(TargetMenu) + 1\n'
            '\t\tRowReference := RowPosition . "&"\n')
        segment = once(segment, 'TargetMenu.Add(Label, SubMenu)', 'TargetMenu.Insert("", Label, SubMenu)')
        segment = once(segment, 'TargetMenu.Add(Label, Row["submenu"])', 'TargetMenu.Insert("", Label, Row["submenu"])')
        segment = once(segment, 'RegisterMenuItem(TargetMenu, Label, Row["action"])',
            'RowPosition == 1\n'
            '\t\t\t\t? RegisterMenuItem(TargetMenu, Label, Row["action"])\n'
            '\t\t\t\t: RegisterMenuItemInsert(TargetMenu, "", Label, Row["action"])')
        segment = once(segment, 'RegisterMenuItem(TargetMenu, Label, (*) => "")',
            'RowPosition == 1\n'
            '\t\t\t\t? RegisterMenuItem(TargetMenu, Label, (*) => "")\n'
            '\t\t\t\t: RegisterMenuItemInsert(TargetMenu, "", Label, (*) => "")')
        segment = once(segment, '\n\t\t; An optional per-row icon.',
            '\n\t\tif TrayMenuItemCount(TargetMenu) != RowPosition\n'
            '\t\t\tthrow Error("Native row append did not preserve its position")\n'
            '\n\t\t; An optional per-row icon.')
        for method, args in [('SetIcon', ', Row["icon"]'), ('Check', ''), ('Disable', '')]:
            segment = once(segment, f'TargetMenu.{method}(Label{args})', f'TargetMenu.{method}(RowReference{args})')
        s = s[:start] + segment + s[end:]
    else:
        s = once(s, 'RegisterMenuItem(m, l, cb*)  => m.Add(l, cb.Length ? cb[1] : (*) => 0)\n',
            'RegisterMenuItem(m, l, cb*)  => m.Add(l, cb.Length ? cb[1] : (*) => 0)\n'
            'RegisterMenuItemInsert(m, before, label, callback) {\n'
            '\tm.Insert(before, label, callback)\n\treturn 1\n}\n')
    pre, cand = PRE / path, CAND / path
    pre.parent.mkdir(parents=True, exist_ok=True)
    cand.parent.mkdir(parents=True, exist_ok=True)
    if pre.exists():
        assert pre.read_bytes() == raw, f'Production source differs from immutable preimage: {pre}'
    else:
        pre.write_bytes(raw)
    changed = b'\xef\xbb\xbf' + s.encode()
    cand.write_bytes(changed)
    receipts[path] = {'preimage_sha256': hashlib.sha256(raw).hexdigest(),
        'candidate_sha256': hashlib.sha256(changed).hexdigest()}
    patch = ''.join(difflib.unified_diff(raw.decode('utf-8').splitlines(True),
        changed.decode('utf-8').splitlines(True),
        fromfile='a/static/ergopti_plus/windows/' + path,
        tofile='b/static/ergopti_plus/windows/' + path))
    (HERE / (Path(path).name + '.patch')).write_text(patch)

(HERE / 'source-receipts.json').write_text(json.dumps({
    'checkout_head': subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
    'files': receipts, 'native_execution': 'not executed'}, indent=2) + '\n')
