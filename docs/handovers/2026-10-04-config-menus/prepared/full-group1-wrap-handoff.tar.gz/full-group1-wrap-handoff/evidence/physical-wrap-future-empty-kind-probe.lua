local root = arg[1]
local driver = root .. "/static/ergopti_plus/macos"
package.path = driver .. "/?.lua;" .. driver .. "/?/init.lua;" .. root .. "/static/ergopti_plus/_shared/lua/?.lua;" .. root .. "/static/ergopti_plus/_shared/lua/?/init.lua;" .. package.path
_G.hs = require("tests.stubs.hs")
pcall(require, "lfs")
local fixture = require("tests.support.preferences_roundtrip_fixture")
local fixture = require("tests.support.toml_output_fixture")
local helpers = require("tests.helpers")
helpers.with_stub_scope({"infra.preferences","infra.logger","adapters.file_system","infra.fs_dir"},function()
 local preferences=helpers.load_with_stubs("infra.preferences")
 fixture.with_output(function(path)
  local original='[shortcuts]\nwrap_symbols = {states={"("=false},custom=[{left="a",right="b",future=[]}],future=[]}\n'
  local f=assert(io.open(path,"wb"));assert(f:write(original));assert(f:close())
  local saved,status=preferences.load(path);assert(status=="ok")
  saved.wrap_symbol_states["("]=true
  assert(preferences.save(path,saved,{},{}))
  f=assert(io.open(path,"rb"));local bytes=f:read("*a");f:close();print(bytes)
  local doc,shapes=require("toml_codec").decode_with_shapes(bytes)
  assert(shapes.arrays[doc.shortcuts.wrap_symbols.future]==true,"unknown future empty-array metadata must retain source kind")
  assert(shapes.arrays[doc.shortcuts.wrap_symbols.custom[1].future]==true,"custom future empty-array metadata must retain source kind")
 end)
end)
