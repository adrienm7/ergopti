from pathlib import Path
import subprocess,json,os,datetime
from zoneinfo import ZoneInfo
out=Path('/workspace/scratch/windows-adapter-contract-followup/live-r29')
env=dict(os.environ,WINEPREFIX='/workspace/toolchain/wine-r3-metrics-owned')
rows=[]
for mode in ['healthy','empty','message']:
    argv=['timeout','--kill-after=5s','120s','xvfb-run','-a','wine','/workspace/toolchain/ahk/AutoHotkey64.exe','/ErrorStdOut=UTF-8','Z:'+str(out/'baseline.ahk').replace('/',chr(92)),mode]
    with (out/(mode+'.log')).open('w') as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
    rows.append({'mode':mode,'exit_code':r.returncode,'log':str(out/(mode+'.log')),'ended_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()})
(out/'baseline-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
