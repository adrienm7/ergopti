# native/ollama_guardian/tests/test_existing_runtime_shape.ps1
# Exercises genuine JSON decoding and the closed descriptor guard; no Win32 ports.
[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$FilesHelper,
	[Parameter(Mandatory = $true)][string]$PublicationHelper)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Assert-InspectionTest([bool]$Condition, [string]$Reason) {
	if (-not $Condition) { throw $Reason }
}
function Read-InspectionSpecimen($Value) {
	$bytes = [Text.UTF8Encoding]::new($false, $true).GetBytes(($Value | ConvertTo-Json -Depth 8 -Compress))
	$stream = [IO.MemoryStream]::new($bytes, $false)
	try { return Read-OllamaJsonStream $stream }
	finally { $stream.Dispose() }
}
function Refuse-InspectionSpecimen($Value) {
	$refused = $false
	try { Assert-OllamaExistingDescriptorShape (Read-InspectionSpecimen $Value) }
	catch { $refused = $true }
	Assert-InspectionTest $refused 'A malformed inspection descriptor was admitted.'
}
function New-InspectionSpecimen {
	return [ordered]@{ kind = 'ollama-immutable-container-reference'; schema = 1;
		root_identity = '12345678:0000000000000001'; container_identity = '12345678:0000000000000002';
		versions_identity = '12345678:0000000000000003'; ticket = ('1' * 32);
		manifest_sha256 = ('2' * 64); catalogue_sha256 = ('3' * 64); archive_sha256 = ('4' * 64);
		version = '0.24.0'; asset = 'windows-amd64'; container = ('.stage-' + ('1' * 32));
		root_native_path = 'C:\owned-inspection-model' }
}
try {
	. $FilesHelper
	. $PublicationHelper
	Assert-OllamaExistingDescriptorShape (Read-InspectionSpecimen (New-InspectionSpecimen))
	[Console]::Out.WriteLine('PASS existing-descriptor-valid-json')
	foreach ($field in @('kind', 'root_identity', 'container_identity', 'ticket', 'manifest_sha256',
		'catalogue_sha256', 'archive_sha256', 'version', 'asset', 'container', 'versions_identity', 'root_native_path')) {
		foreach ($singleton in @($false, $true)) {
			$specimen = New-InspectionSpecimen
			$expected = $specimen[$field]
			$specimen[$field] = if ($singleton) { ,([object[]]@($expected)) } else { ,([object[]]@()) }
			Refuse-InspectionSpecimen $specimen
		}
	}
	[Console]::Out.WriteLine('PASS existing-descriptor-24-collection-fields-refused')
	foreach ($schema in @('1', $true, 1.5)) {
		$specimen = New-InspectionSpecimen
		$specimen.schema = $schema
		Refuse-InspectionSpecimen $specimen
	}
	[Console]::Out.WriteLine('PASS existing-descriptor-schema-types-refused')
	$specimen = New-InspectionSpecimen
	$specimen['foreign'] = 'unowned'
	Refuse-InspectionSpecimen $specimen
	$specimen = New-InspectionSpecimen
	[void]$specimen.Remove('ticket')
	Refuse-InspectionSpecimen $specimen
	[Console]::Out.WriteLine('PASS existing-descriptor-closed-fields')
	foreach ($field in @('kind', 'ticket', 'manifest_sha256', 'catalogue_sha256', 'archive_sha256',
		'root_identity', 'container_identity', 'versions_identity', 'version', 'asset', 'container')) {
		$specimen = New-InspectionSpecimen
		$specimen[$field] = 'foreign'
		Refuse-InspectionSpecimen $specimen
	}
	[Console]::Out.WriteLine('PASS existing-descriptor-scalar-values-refused')
	$descriptor = New-Object PSObject
	$descriptor | Add-Member ScriptMethod Dispose { $this.Calls++; throw 'controlled close refusal' }
	$descriptor | Add-Member NoteProperty Calls 0
	$row = [ordered]@{ descriptor = $descriptor; source_stream = $null;
		close_debt = [Collections.Generic.List[object]]::new() }
	Close-OllamaRuntimeInspectionReaders $row
	Close-OllamaRuntimeInspectionReaders $row
	Assert-InspectionTest ($descriptor.Calls -eq 1 -and $null -eq $row.descriptor) 'Inspection close was retried after uncertain retirement.'
	Assert-InspectionTest ($row.close_debt.Count -eq 1 -and
		[object]::ReferenceEquals($row.close_debt[0].resource, $descriptor)) 'Inspection close refusal lost its exact resource.'
	[Console]::Out.WriteLine('PASS existing-descriptor-close-debt-once')
	exit 0
} catch {
	[Console]::Error.WriteLine($_.Exception.Message)
	exit 1
}
