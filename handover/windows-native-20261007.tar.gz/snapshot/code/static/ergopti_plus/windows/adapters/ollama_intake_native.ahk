﻿; adapters/ollama_intake_native.ahk
#Requires AutoHotkey v2.0

/** Reuses the same resident pinned module for legacy runtime and intake rows. */
class OllamaIntakeNativePort extends OllamaGuardianNativePort {
	__New(Pins) {
		super.__New(Pins)
		try {
			for name in ["GAI_Reserve", "GAI_AttachSource", "GAI_BindSource", "GAI_ClaimSource",
				"GAI_BindInventory", "GAI_TransferChannel", "GAI_WriteChannelCommand", "GAI_OutputIntent",
				"GAI_OutputUnits", "GAI_ConfirmOutput", "GAI_AttachDownload", "GAI_BindDownload", "GAI_BeginGuardian",
				"GAI_ClaimDownload", "GAI_RequestSeal", "GAI_Stop", "GAI_Poll"] {
				local address := DllCall("Kernel32\GetProcAddress", "Ptr", this.Module, "AStr", name, "Ptr")
				if !address
					throw OSError(A_LastError, "GetProcAddress(intake bridge)")
				this.Exports[name] := address
			}
		} catch as Err {
			this.FirstError := "intake_exports_refused"
			this.Phase := "retained-debt"
			throw Err
		}
	}

	Reserve(Ticket, CatalogueHash) {
		if !RegExMatch(Ticket, "\A[0-9a-f]{32}\z")
			throw ValueError("Intake requires a closed captured ticket.")
		local manifest := this._Digest(CatalogueHash), guardian := this._Digest(this.Pins["Guardian"]["sha256"]), id := 0
		if !DllCall(this._Entry("GAI_Reserve"), "Str", Ticket, "Ptr", manifest.Ptr,
				"Ptr", guardian.Ptr, "Int64*", &id, "CDecl Int") || id <= 0
			throw Error("The native intake reservation refused.")
		return id
	}

	AttachSource(Id, Process) {
		return DllCall(this._Entry("GAI_AttachSource"), "Int64", Id, "Ptr", Process, "CDecl Int")
	}
	BindSource(Id, Process, Job) {
		return DllCall(this._Entry("GAI_BindSource"), "Int64", Id, "Ptr", Process, "Ptr", Job, "CDecl Int")
	}
	ClaimSource(Id) {
		return DllCall(this._Entry("GAI_ClaimSource"), "Int64", Id, "CDecl Int")
	}
	AttachDownload(Id, Process) {
		return DllCall(this._Entry("GAI_AttachDownload"), "Int64", Id, "Ptr", Process, "CDecl Int")
	}
	BindDownload(Id, Process, Job) {
		return DllCall(this._Entry("GAI_BindDownload"), "Int64", Id, "Ptr", Process, "Ptr", Job, "CDecl Int")
	}
	BeginIntakeGuardian(Id) {
		return DllCall(this._Entry("GAI_BeginGuardian"), "Int64", Id, "CDecl Int")
	}
	ConfirmOutput(Id, Path) {
		return DllCall(this._Entry("GAI_ConfirmOutput"), "Int64", Id, "Str", Path, "CDecl Int")
	}
	ClaimDownload(Id) {
		return DllCall(this._Entry("GAI_ClaimDownload"), "Int64", Id, "CDecl Int")
	}
	Seal(Id) {
		return DllCall(this._Entry("GAI_RequestSeal"), "Int64", Id, "CDecl Int")
	}
	StopIntake(Id) {
		return DllCall(this._Entry("GAI_Stop"), "Int64", Id, "CDecl Int")
	}

	BindInventory(Id, Inventory, Ticket) {
		if !(Inventory is Map) || Inventory.Get("kind", "") != "ollama-intake-inventory"
				|| Inventory.Get("ticket", "") != Ticket || !(Inventory.Get("records", 0) is Array)
				|| !RegExMatch(Inventory.Get("root_identity", ""), "\A([0-9a-f]{8}):([0-9a-f]{16})\z", &root)
			throw ValueError("The source inventory is not a matching typed candidate.")
		local count := Inventory["records"].Length
		if count <= 0 || count > 0xffffffff
			throw ValueError("The source candidate inventory is empty or unrepresentable.")
		local paths := [], wire := Buffer(count * 80, 0)
		for i, record in Inventory["records"] {
			if !(record is Map) || !RegExMatch(record.Get("handle", ""), "\A[0-9a-f]{16}\z")
					|| !RegExMatch(record.Get("volume", ""), "\A[0-9a-f]{8}\z")
					|| !RegExMatch(record.Get("index", ""), "\A[0-9a-f]{16}\z")
					|| !(record.Get("kind", -1) is Integer) || (record["kind"] != 0 && record["kind"] != 1)
					|| !(record.Get("path", 0) is String) || record["path"] == "" || this._IntakeHasNul(record["path"])
				throw ValueError("The source candidate tuple has malformed fields.")
			local name := Buffer(StrPut(record["path"], "UTF-16") * 2, 0), digest := this._Digest(record.Get("sha256", ""))
			StrPut(record["path"], name, "UTF-16")
			paths.Push(name)
			local offset := (i - 1) * 80
			NumPut("UInt64", Integer("0x" . record["handle"]), "UInt", record["kind"], wire, offset)
			NumPut("UInt64", Integer("0x" . record["volume"]), "UInt64", Integer("0x" . record["index"]), wire, offset + 16)
			NumPut("Ptr", name.Ptr, "UPtr", StrLen(record["path"]), wire, offset + 32)
			DllCall("RtlMoveMemory", "Ptr", wire.Ptr + offset + 48, "Ptr", digest.Ptr, "UPtr", 32)
		}
		return DllCall(this._Entry("GAI_BindInventory"), "Int64", Id, "Ptr", wire.Ptr, "UPtr", count,
			"UInt64", Integer("0x" . root[1]), "UInt64", Integer("0x" . root[2]), "CDecl Int")
	}

	TransferAndPublish(Id) {
		local handles := Buffer(40, 0)
		if !DllCall(this._Entry("GAI_TransferChannel"), "Int64", Id, "Ptr", handles.Ptr, "CDecl Int")
			return false
		return DllCall(this._Entry("GAI_WriteChannelCommand"), "Int64", Id, "CDecl Int")
	}

	_IntakeHasNul(Text) {
		loop StrLen(Text)
			if NumGet(StrPtr(Text), (A_Index - 1) * 2, "UShort") == 0
				return true
		return false
	}

	OutputIntent(Id) {
		local Capacity := 0
		if !DllCall(this._Entry("GAI_OutputUnits"), "Int64", Id, "UInt*", &Capacity, "CDecl Int") || Capacity <= 0
			throw Error("Native intake output capacity lookup refused.")
		local path := Buffer(Capacity * 2, 0)
		if !DllCall(this._Entry("GAI_OutputIntent"), "Int64", Id, "Ptr", path.Ptr, "UInt", Capacity, "CDecl Int")
			throw Error("The native intake output intent refused.")
		return StrGet(path.Ptr, "UTF-16")
	}

	PollIntake(Id) {
		local wire := Buffer(56, 0)
		if !DllCall(this._Entry("GAI_Poll"), "Int64", Id, "Ptr", wire.Ptr, "CDecl Int")
			throw Error("The native intake owner refused its lookup.")
		if NumGet(wire, 0, "Int64") != Id || NumGet(wire, 52, "UInt") != 0
			throw Error("The native intake status has a foreign identity or layout.")
		return Map("id", Id, "phase", NumGet(wire, 8, "UInt"), "error", NumGet(wire, 12, "UInt"),
			"guardian_phase", NumGet(wire, 16, "UInt"), "activation_claimed", NumGet(wire, 20, "UInt"),
			"download_terminal", NumGet(wire, 24, "UInt"), "download_exit", NumGet(wire, 28, "UInt"),
			"download_members", NumGet(wire, 32, "UInt"), "source_terminal", NumGet(wire, 36, "UInt"),
			"source_exit", NumGet(wire, 40, "UInt"), "composite_members", NumGet(wire, 44, "UInt"),
			"seal_claimed", NumGet(wire, 48, "UInt"))
	}
}
