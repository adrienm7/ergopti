from pathlib import Path
import difflib,hashlib,json,re,subprocess
r=Path('/tmp/group6-release-darwin-enrollment-ec170e2d6-r3-ci-admission');r2=Path('/tmp/group6-release-darwin-enrollment-ec170e2d6-r2-deadline');repo=Path('/workspace/ergopti')
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return {'path':str(p),'sha256':sha(b),'size':len(b)}
workflow='.github/workflows/ci-macos.yml';native='tools/diagnostics/macos_release_stage_native_receiving.cjs';full='tools/test/ci-full-default.cjs';wiring='tools/test/test-ci-pipeline-wiring.cjs'
for name in [workflow,full,wiring]:assert (r/'preimage'/name).read_bytes()==(repo/name).read_bytes()
assert not (repo/native).exists()
assert (r/'candidate'/native).read_bytes()==(r2/'candidate'/native).read_bytes()
wf=(r/'candidate'/workflow).read_text();wf2=(r2/'candidate'/workflow).read_text();before='      - name: Retain selected-release native ownership receiving\n        if: ${{ always() }}\n';after=before.replace('${{ always() }}','always()');assert wf.replace(after,before)==wf2
mapping=[]
for rel, marker, stop in [(full,'const FULL_STEPS = [\n',"\t[\n\t\t'.github/workflows/ci-macos.yml',\n\t\t'item36-native',"),(wiring,'const MACOS_NATIVE_STEP_CONDITIONS = [\n',"\t[\n\t\tMACOS_BOX,\n\t\t'managed-ollama-native',\n\t\t'Qualify actual native PAC source ownership XCTest controls',")]:
 s=(r/'candidate'/rel).read_text();start=s.index(marker)+len(marker);end=s.index(stop,start);mapping.append({'path':rel,'added':s[start:end]})
s=(r/'candidate'/full).read_text();start=s.index("\t\tif (name === 'Receive selected-release shell corpus and native guardian cancellation') {");end=s.index('\n\t\trequireEqual(',start)+1;mapping.append({'path':full,'added':s[start:end]})
s=(r/'candidate'/wiring).read_text();start=s.index('// The Darwin receiver is mandatory raw work, never a deferred qualification alias.');end=s.index('if (errors.length > 0) {\n',start);mapping.append({'path':wiring,'added':s[start:end]})
for rel in [full,wiring]:
 s=(r/'candidate'/rel).read_text()
 for op in reversed([x for x in mapping if x['path']==rel]):assert s.count(op['added'])==1;s=s.replace(op['added'],'')
 assert s==(r/'preimage'/rel).read_text()
(r/'R3-MAPPING.json').write_text(json.dumps({'version':1,'additions':mapping,'whole_original_guard_bytes_inverse_exact':True,'r2_native_caller_exact':True,'r2_workflow_inverse_exact':'one literal artifact condition spelling only'},indent=2)+'\n')
paths=[workflow,native,full,wiring];patch=''
def apply(before,delta):
 rows=delta.splitlines(True);lines=before.splitlines(True);out=[];pos=0;i=2
 while i<len(rows):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',rows[i]);assert match
  at=int(match[1])-1 if int(match[1]) else 0;out+=lines[pos:at];pos=at;i+=1
  while i<len(rows) and not rows[i].startswith('@@ '):
   row=rows[i];i+=1
   if row[0]==' ':assert lines[pos]==row[1:];out.append(lines[pos]);pos+=1
   elif row[0]=='-':assert lines[pos]==row[1:];pos+=1
   elif row[0]=='+':out.append(row[1:])
   else:raise AssertionError('Unknown hunk')
 out+=lines[pos:];return ''.join(out)
for name in paths:
 old=(r/'preimage'/name).read_text() if (r/'preimage'/name).exists() else '';new=(r/'candidate'/name).read_text()
 delta=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name));assert apply(old,delta)==new;patch+=delta
 reverse=''.join(difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile='new',tofile='old'));assert apply(new,reverse)==old
(r/'darwin-enrollment.patch').write_text(patch)
contract=(r/'CONTRACT.md').read_text();text='''\nR3 enrolls the exact artifact always() condition in the existing native condition inventory and requires both receiver null condition and artifact always() rows in FULL_STEPS. A narrow literal bash/three-line receiving command check rejects deleted or modified commands. Fourteen handwritten actual raw-workflow models cover deletion, rename, duplicate, failure forgiveness, foreign/deleted/modified commands, foreign shell and five conditional/deferred predicates. The original condition inventory's unchanged loop also covers missing artifact and missing/false/success artifact conditions. Two additive models retain exact condition spelling and unknown-step conditional rejection. Every old guard byte reconstructs exactly by removing the four additive fragments. No deferred exception, parser change or original finding/assertion removal is introduced. Shared guard/workflow adoption requires root/Group5 coordination. R2 native receiving and workflow owner/deadline/corpus scope remain unchanged.\n'''
if text not in contract:(r/'CONTRACT.md').write_text(contract+text)
m=json.loads((r2/'MANIFEST.json').read_text());m['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();m['kind']='source-only-Darwin-native-owner-enrollment-R3-exact-CI-admission-CODE';m['candidate_paths']=paths;m['preimages']=[bind(r/'preimage'/x) for x in [workflow,full,wiring]];m.pop('preimage',None);m['postimages']=[bind(r/'candidate'/x) for x in paths];m['patch']=bind(r/'darwin-enrollment.patch');m['workflow_fragment']=bind(r/'WORKFLOW-ADDITIVE-BLOCK.txt');m['contract']=bind(r/'CONTRACT.md');m['source_proof_addendum']=bind(r/'SOURCE-PROOF.json');m['authoring_sources']=[bind(r/'freeze-r3.py'),bind(r/'R3-MAPPING.json')];m['r3_revision']={'r2_immutable':[bind(r2/'MANIFEST.json'),bind(r2/'candidate'/native),bind(r2/'candidate'/workflow)],'guard_mapping':bind(r/'R3-MAPPING.json'),'every_guard_byte_inverse_exact':True,'every_patch_hunk_forward_reverse_exact':True,'handwritten_receiver_mutants':14,'condition_inventory_existing_mutants_extended_without_edits':True,'new_conditional_or_deferred_exceptions':0,'shared_guard_ownership':'root/Group5 coordination required; private only','new_source_qualification':'UNRUN; original baseline guard findings/assertions unchanged'};m['source_proofs']['shared_guard_additions']=2
(r/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'manifest':bind(r/'MANIFEST.json'),'patch':bind(r/'darwin-enrollment.patch'),'postimages':m['postimages']}))
