import{l as o,a as r}from"../chunks/DO11evmt.js";export{o as load_css,r as start};
