Confirmed counter semantic mismatch; deliberately no patch.

Windows KLR_RebuildTitleCounts derives c from COUNT(*) events_window_switch, including windows with zero typing. Shared HTML calls this characters; shared Lua typing walker increments once per typing entry rather than per nested character. Existing Windows title-cap conservation tests explicitly require raw switch counts, so a shared-header correction would mislabel macOS/Linux, and changing only writer c would double-count or lose reader-owned values. Root should report intended semantics question.

Actual SQLite source-extracted proof: sqlite-proof.json. No private user data used.
