const fs=require('fs'), acorn=require('/workspace/ergopti/node_modules/acorn');
const [oldFile,newFile,out]=process.argv.slice(2);
function calls(file){const text=fs.readFileSync(file,'utf8'),ast=acorn.parse(text,{ecmaVersion:'latest'}),found=[];
 function walk(n){if(!n||typeof n!=='object')return;
  if(n.type==='CallExpression' && n.callee.type==='MemberExpression' && n.callee.object.name==='errors' && n.callee.property.name==='push')found.push(text.slice(n.start,n.end));
  for(const v of Object.values(n)){if(Array.isArray(v))v.forEach(walk);else if(v && typeof v==='object')walk(v)}
 }walk(ast);return found;
}
const old=calls(oldFile),post=calls(newFile);if(old.length<30)throw Error('original guard assertion floor');
let i=0;for(const body of old){const at=post.indexOf(body,i);if(at<0)throw Error('original error assertion changed: '+body);i=at+1;}
fs.writeFileSync(out,JSON.stringify({original_error_assertions:old.length,post_error_assertions:post.length,all_original_executable_assertion_bodies_exact_ordered:true},null,2)+'\n');
console.log('Original executable guard error assertions preserved: '+old.length+'/'+post.length);
