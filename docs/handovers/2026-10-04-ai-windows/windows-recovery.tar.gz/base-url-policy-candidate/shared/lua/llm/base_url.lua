--- _shared/lua/llm/base_url.lua

--- ==============================================================================
--- MODULE: Remote Base URL Policy
--- DESCRIPTION:
--- Extracts the established Mac normalization without native state or logging.
--- Drivers retain defaults, transport scalar admission and request/source owners.
--- ==============================================================================

local M = {}

local function rtrim_slash(s)
	return (tostring(s or ""):gsub("/+$", ""))
end





-- ===============================================
-- ===============================================
-- ======= 1/ Address Admission ==================
-- ===============================================
-- ===============================================

--- Validates an HTTP(S) base without logging the rejected input.
--- @param raw any Candidate address.
--- @return string|nil normalized
--- @return string reason Privacy-safe refusal category.
function M.normalize(raw)
	if type(raw) ~= "string" or raw == "" then
		return nil, "base URL is empty"
	end
	if raw:find("[%c%s]") then
		return nil, "base URL contains whitespace or control characters"
	end
	if raw:find("\\", 1, true) then
		return nil, "base URL contains a backslash"
	end

	local scheme, authority, suffix = raw:match("^([%a][%w+%.%-]*)://([^/?#]+)(.*)$")
	if not scheme or not authority then
		return nil, "base URL must include a scheme and host"
	end
	scheme = scheme:lower()
	if scheme ~= "http" and scheme ~= "https" then
		return nil, "base URL scheme must be http or https"
	end
	if authority:find("@", 1, true) then
		return nil, "base URL authority must not contain userinfo"
	end
	if suffix:find("?", 1, true) or suffix:find("#", 1, true) then
		return nil, "base URL must not contain a query or fragment"
	end

	local host = authority
	local port
	if authority:sub(1, 1) == "[" then
		local bracket_host, remainder = authority:match("^(%[[^%]]+%])(.*)$")
		local bracket_value = bracket_host and bracket_host:sub(2, -2) or ""
		if bracket_value == ""
			or not bracket_value:match("^[%w:%.%%%-]+$")
			or not bracket_value:find(":", 1, true)
			or not bracket_value:find("[%x]") then
			return nil, "base URL host is invalid"
		end
		host = bracket_host
		if remainder ~= "" then
			port = remainder:match("^:(%d+)$")
			if not port then return nil, "base URL port is invalid" end
		end
	else
		local host_with_port, port_text = authority:match("^([^:]+):(%d+)$")
		if host_with_port then
			host = host_with_port
			port = port_text
		elseif authority:find(":", 1, true) then
			return nil, "base URL port is invalid"
		end
		if not host:match("^[%w%._%-]+$") or not host:find("[%w]") then
			return nil, "base URL host is invalid"
		end
	end
	if port then
		local numeric_port = tonumber(port)
		if not numeric_port or numeric_port < 1 or numeric_port > 65535 then
			return nil, "base URL port is outside 1..65535"
		end
	end

	return rtrim_slash(scheme .. "://" .. authority .. suffix), "ok"
end

return M
