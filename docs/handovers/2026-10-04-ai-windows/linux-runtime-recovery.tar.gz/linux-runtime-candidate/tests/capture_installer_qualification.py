"""Serial runner preserving raw transcripts, statuses and exact source receipts."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("repository")
parser.add_argument("candidate")
parser.add_argument("results")
args = parser.parse_args()
repository = Path(args.repository).resolve()
candidate = Path(args.candidate).resolve()
results = Path(args.results).resolve()
results.mkdir(parents=True, exist_ok=False)
sources = (
    "modules/llm/ollama_archive_installer.lua", "modules/llm/ollama_install_files.lua", "adapters/owned_process.lua",
    "tests/test_archive_installer_seams.lua", "tests/test_install_files_seams.lua", "tests/run_install_files_native.lua",
    "tests/run_install_files_native.py", "tests/run_archive_installer_mutants.py",
    "tests/run_native_subreaper.py", "tests/run_native_subreaper_teardown.py",
)

def hashes():
    return {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in sources}

initial = hashes()
summary = {"started_utc": datetime.now(timezone.utc).isoformat(), "uid": os.getuid(), "sources": initial, "runs": []}

def save():
    (results / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")

save()
commands = []
for runtime in ("luajit", "lua5.4"):
    binary = f"/workspace/.native/bin/{runtime}"
    commands.extend((
        (f"{runtime}-transaction", [binary, str(candidate / "tests/test_archive_installer_seams.lua"), str(candidate)], "Archive installer seams: 21 passed, 0 failed."),
        (f"{runtime}-files", [binary, str(candidate / "tests/test_install_files_seams.lua"), str(candidate)], "Install file seams: 22 passed, 0 failed."),
        (f"{runtime}-native", ["python3", str(candidate / "tests/run_install_files_native.py"), str(repository), str(candidate), "--lua", binary], "Install native filesystem receipts: 11 passed, 0 failed."),
        (f"{runtime}-mutants", ["python3", str(candidate / "tests/run_archive_installer_mutants.py"), binary, str(candidate)], "Archive installer causal mutants: 10 rejected, 0 escaped"),
    ))
commands.append(("wrapper-teardown", ["python3", str(candidate / "tests/run_native_subreaper_teardown.py")], "Native wrapper failure teardown: 2 passed, 0 failed"))
for name, command, expected in commands:
    completed = subprocess.run(command, cwd=candidate, capture_output=True, timeout=60)
    stdout_path, stderr_path = results / f"{name}.stdout.log", results / f"{name}.stderr.log"
    stdout_path.write_bytes(completed.stdout)
    stderr_path.write_bytes(completed.stderr)
    entry = {
        "name": name, "command": command, "returncode": completed.returncode,
        "stdout": str(stdout_path), "stderr": str(stderr_path),
        "stdout_sha256": hashlib.sha256(completed.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(completed.stderr).hexdigest(),
        "expected_receipt": expected, "receipt_observed": expected.encode() in completed.stdout,
    }
    summary["runs"].append(entry)
    save()
    print(f"{name}: exit={completed.returncode}, exact receipt={entry['receipt_observed']}", flush=True)
    if completed.returncode != 0 or not entry["receipt_observed"]:
        raise RuntimeError(f"qualification failed; preserved raw transcripts: {name}")
final = hashes()
summary["sources_unchanged"] = final == initial
summary["finished_utc"] = datetime.now(timezone.utc).isoformat()
summary["final_sources"] = final
save()
if final != initial:
    raise RuntimeError("source drift during exclusive serial qualification")
(candidate / "installer-qualified-sha256.json").write_text(json.dumps(initial, indent=2) + "\n")
print(f"Qualified raw evidence preserved at {results}", flush=True)
