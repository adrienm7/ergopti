L66 bounded analysis — next batch only

Evidence and scope

The maintainer's current ledger at docs/ERGOPTIPLUS_TODO.md:374–382 records the actual macOS 12:02 run: at 12:03:56 the ctrl_g factory returned nil, RegisterEventHotKey reported -9878 (another owner), bindings_rebind did not commit, and keyboard_shortcuts_rebind_recovery subsequently failed repeatedly. This is a cited field observation, not a native reproduction performed here. The separate layout-probe timeout belongs to L64's 138-second main-thread hold and must not be included in this fix. The identity of the other Ctrl+G owner is unknown. The later configurable-keyboard recovery failures are a distinct child boundary; source reading does not establish that each is directly caused by the static ctrl_g failure.

Exact path and root cause

1. macos/modules/shortcuts/bindings.lua:364 defines ctrl_g with bind_log({"ctrl"}, "g", ...).
2. bind_log at line246 first registers its physical claim, then calls hs.hotkey.bind under pcall at line258. A nil/native-invalid result attempts to release the claim and returns nil. Native throws are rethrown. Failed claim release is retained in native_claim_cleanup.
3. start_bindings at line648 treats every unsuccessful factory alike. Its factory loop near line717 sends nil to reject_start, which closes delivery_enabled, releases ALL acquired native hotkeys, rolls back reopened child owners and leaves started=false. Thus one conflict suppresses unrelated successful bindings. This is a deliberate all-or-nothing transaction contract, now inconsistent with L66's requested per-hotkey availability.
4. Bindings.rebind at line945 first closes delivery, clears started and releases the previous native owners. It then calls the same start_bindings(false,true), so a cleanly refused single hotkey leaves no usable replacement cohort.
5. macos/modules/shortcuts/init.lua:419 rebind_for_layout places Bindings.rebind before the configurable keyboard rebind in a StartupTransaction. Failure compensates the child cohort and records REBIND_RECOVERY_CLAIM; recover_layout_rebind at line260 retries it under the aggregate lifecycle fence.

Safe change boundary for the next batch

Isolate a specifically identified, cleanly settled native hotkey refusal in bind_log and start_bindings; do not turn arbitrary factory nil, exceptions, malformed returns, child failures or outstanding physical-claim cleanup into success. bind_log currently collapses native refusal and claim-acquisition/cleanup failure to nil, so a bare `continue on nil` would lose essential ownership information. A future implementation must preserve that distinction explicitly through the factory result and the registry's existing physical-claim debt. No hs.keycode fallback, Carbon workaround or guessed keycode should be added from this evidence.

Successful siblings may commit only when lifecycle admission/epoch remains current and every non-acquired native/physical claim has been settled. The missing binding must stay visibly unbound but enabled as a preference; it must not enter _disabled_set or persist a new setting. Report the failed identity/chord explicitly through the existing logger. Real stop/pause/rollback must still retain and retry unknown cleanup debt. Keep-awake and child action scopes must not churn on layout-only rebind. Document the revised start success contract: the requested lifecycle is active with an explicitly diagnosed unavailable hotkey, rather than every enabled hotkey necessarily owning a native object. Retry through an existing explicit start/enable/rebind boundary; do not add an unsolicited timer or unbounded retry loop.

Regression plan before production edits

- Through the actual ctrl_g factory, make hs.hotkey.bind return nil only for Ctrl+G. On old source, assert aggregate false and sibling release; on the intended new behavior, assert a live sibling callback, ctrl_g unbound, preference still enabled, a concrete refusal diagnostic, and no retained physical claim for the refused native binding. Exercise more than one acquisition order so pairs iteration cannot make the test vacuous.
- Drive a complete layout rebind through Shortcuts.rebind_for_layout with the same refusal: unrelated static and configurable shortcuts remain usable, aggregate recovery debt is not manufactured by this settled refusal, and keep-awake is untouched. Remove the conflict and exercise an existing explicit rebind: ctrl_g becomes usable with one owner and no duplicate callbacks.
- Retain negative controls: physical claim release refusal, native exception, special/eventtap factory nil, child resume failure and malformed factory output remain transactional failures. Existing test_bindings_start_transaction.lua intentionally makes a SPECIAL factory nil after another acquisition; its rollback assertions must remain intact.
- Retain lifecycle controls: re-entrant pause/stop while acquiring or cleaning the refused native binding, final epoch loss, exact failed-handle retirement, explicit user-disabled preferences, and stopped-layer rebind. Existing test_layout_rebind_preserves_disabled.lua, test_rebind_preserves_keep_awake.lua and startup/child lifecycle suites are relevant.
- Darwin native validation, after the batch is authorized, must deliberately reserve a private test chord with a separately owned first handle, reject the second registration, demonstrate an unrelated shortcut stays live, then retire every exact owner. Do not reserve the user's Ctrl+G merely to reproduce a field conflict. The field's other owner and missing-keymap observation remain separate diagnostics.

Other OS

Linux modules/shortcuts/keyboard_shortcuts.lua:32–35 explicitly matches through the daemon's input-grab dispatch rather than a native chord-reservation API. It cannot have this Carbon registration failure or the macOS static Bindings transaction. Windows modules/shortcuts/utils.ahk:26–40 already contains Hotkey registration failure inside AddShortcut, logs the failed chord and returns false without aborting remaining feature registrations. No Linux or Windows production change is indicated by L66.

Status

Read-only source analysis only. No repository or worktree file, index or ref modified; no repository tests, native registration experiments or wider audit executed. No patch proposed for the active 19-atom batch. Begin a separately proved next batch only after its CI and coordinator authorization.
