local root = "/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path = root .. "lua/?.lua;" .. package.path
local Json = require("json")
local Policy = require("control.driver_control")
local function read(path)
 local f=assert(io.open(path,"rb")); local s=assert(f:read("*a")); assert(f:close()); return s
end
local spec=Policy.validate(Json.decode(read(root.."modules/control/driver_control.json")))
local corpus=Json.decode(read(root.."tests/corpus/control/driver_control.json"))
local cases={
 {"canonical", [["schema":1]], true},
 {"escaped key", [["sc\u0068ema":1]], true},
 {"last decimal", [["schema":1,"schema":1.0]], false},
 {"last boolean", [["schema":1,"schema":true]], false},
 {"last numeric string", [["schema":1,"schema":"1"]], false},
}
local passed,failed=0,0
for _,row in ipairs(cases) do
 local text="{"..row[2]..',"token":"'..corpus.token..'","request_id":"schema-token"}'
 local decoded=Json.decode(text); assert(type(decoded)=="table" and decoded.request_id=="schema-token")
 local id,reason=Policy.parse_request(spec,text,corpus.token,Json.decode)
 local ok = (row[3] and id=="schema-token" and reason==nil) or (not row[3] and id==nil and reason=="malformed")
 print((ok and "PASS " or "FAIL ")..row[1].." id="..tostring(id).." reason="..tostring(reason))
 if ok then passed=passed+1 else failed=failed+1 end
end
print(passed.." passed, "..failed.." failed")
os.exit(failed==0 and 0 or 1)
