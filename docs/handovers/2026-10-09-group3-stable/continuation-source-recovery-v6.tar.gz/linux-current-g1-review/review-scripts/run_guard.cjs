// Private closed Git-object source overlay; no checkout writes or guard edits.
'use strict';
const fs=require('fs'),path=require('path'),Module=require('module'),cp=require('child_process');
const root='/workspace/ergopti',repo='/workspace/ergopti';
const tree="1028f6bd3eeb08a1aa50f96d1ad9738d2826d7bb";const packet="/workspace/.ergopti-cloud/reviews/group3-linux93-current-g1-union-independent";
const originalRead=fs.readFileSync.bind(fs),originalDir=fs.readdirSync.bind(fs),originalExists=fs.existsSync.bind(fs);
const overrides=process.argv[3]?JSON.parse(originalRead(process.argv[3],'utf8')):{};
const dependencies={};
function blob(rel){return cp.execFileSync('git',['show',tree+':'+rel],{cwd:repo,maxBuffer:8*1024*1024});}
function select(rel){
 let file=overrides[rel]||path.join(packet,'projection',rel);
 if(originalExists(file))return originalRead(file);
 if(rel==='static/ergopti_plus/_shared/modules/menu/menu_manifest.json'||rel==='static/ergopti_plus/linux/_generated/features_manifest.lua')
  return originalRead(path.join(packet,'projection',rel));
 return blob(rel);
}
fs.readFileSync=function(file,options){
 const absolute=path.resolve(String(file));
 if(absolute.startsWith(root+'/static/ergopti_plus/')||absolute.startsWith(root+'/tools/')){
  const rel=path.relative(root,absolute);const bytes=select(rel);
  dependencies[rel]=require('crypto').createHash('sha256').update(bytes).digest('hex');
  const encoding=typeof options==='string'?options:options?.encoding;
  return encoding?bytes.toString(encoding):bytes;
 }
 return originalRead(file,options);
};
fs.existsSync=function(file){
 const absolute=path.resolve(String(file));
 if(absolute.startsWith(root+'/static/ergopti_plus/')||absolute.startsWith(root+'/tools/')){
  const rel=path.relative(root,absolute);if(overrides[rel]||originalExists(path.join(packet,'projection',rel)))return true;
  return cp.spawnSync('git',['cat-file','-e',tree+':'+rel],{cwd:repo}).status===0;
 }
 return originalExists(file);
};
fs.readdirSync=function(dir,options){
 const absolute=path.resolve(String(dir));
 if(absolute.startsWith(root+'/static/ergopti_plus/')){
  const rows=cp.execFileSync('git',['ls-tree',tree+':'+path.relative(root,absolute)],{cwd:repo,encoding:'utf8'}).trim().split('\n').filter(Boolean);
  return rows.map(row=>{const [header,name]=row.split('\t');const type=header.split(' ')[1];
   return options?.withFileTypes?{name,isDirectory:()=>type==='tree',isFile:()=>type==='blob',isSymbolicLink:()=>header.startsWith('120000')}:name;});
 }
 return originalDir(dir,options);
};
const priorJs=Module._extensions['.js'];
function load(module,filename){
 if(filename.startsWith(root+'/tools/'))module._compile(fs.readFileSync(filename,'utf8'),filename);
 else priorJs(module,filename);
}
Module._extensions['.js']=load;Module._extensions['.cjs']=load;
process.on('exit',()=>fs.writeFileSync(path.join(packet,'guard-dependencies-'+path.basename(process.argv[2])+'.json'),JSON.stringify(dependencies,null,2)+'\n'));
const rel=process.argv[2];if(!/^tools\/test\/[\w-]+\.cjs$/.test(rel))throw Error('Unlisted guard target');
const m=new Module(path.join(root,rel),module);m.filename=path.join(root,rel);m.paths=Module._nodeModulePaths(path.join(root,'tools/test'));
// Give unchanged guarded entrypoints their genuine require.main contract.
process.mainModule=m;
m._compile(fs.readFileSync(m.filename,'utf8'),m.filename);
