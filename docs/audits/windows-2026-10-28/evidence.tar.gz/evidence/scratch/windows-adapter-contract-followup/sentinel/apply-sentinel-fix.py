from pathlib import Path
root=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests')
rows=[
 ('unit/adapters/input/test_text_sender_sendinput_failure.ahk','_TSSIF_AdapterMethodsContainSendInputFailure','Err','Failure','TextEraseChars/TextPressKey must contain injected SendInput failures'),
 ('unit/infra/logger/test_logger.ahk','TestLogger_FanOutQueueSurvivesFlushSwap','ErrorText','Err','a flush swap between queue lookup and push must not crash logger fan-out'),
 ('unit/modules/llm/api/test_llm_api_remote_async_registry.ahk','_RemoteTrimRegistry_DetachesBeforeReentrantCallback','Err','Caught','remote trim must not delete an owner already detached by reentrant work'),
 ('unit/modules/llm/api/test_llm_api_ollama.ahk','_OllamaTrimRegistry_DetachesBeforeReentrantCallback','Err','Caught','Ollama trim must not delete an owner already detached by reentrant work')]
for relative,name,variable,caught,message in rows:
 p=root/relative;s=p.read_text(encoding='utf-8-sig');start=s.index(name+'() {');end=s.index('\n}\n',start)+2;body=s[start:end]
 assert body.count(variable+' := ""')==1
 body=body.replace(variable+' := ""',variable+' := "", ContractThrew := false')
 if name.startswith('_TSSIF'):
  body=body.replace('Err := Failure.Message','ContractThrew := true\n            Err := Failure.Message')
 else:
  old='catch as '+caught+'\n\t\t\t'+variable+' := '+caught+'.Message' if name.startswith('TestLogger') else 'catch as '+caught+'\n\t\t'+variable+' := '+caught+'.Message'
  if name.startswith('TestLogger'):
   new='catch as '+caught+' {\n\t\t\tContractThrew := true\n\t\t\t'+variable+' := '+caught+'.Message\n\t\t}'
  else:new='catch as '+caught+' {\n\t\tContractThrew := true\n\t\t'+variable+' := '+caught+'.Message\n\t}'
  assert body.count(old)==1,(name,old);body=body.replace(old,new)
 old='AssertEqual("", '+variable+',';assert body.count(old)==1;body=body.replace(old,'AssertFalse(ContractThrew,')
 assert body.count('"'+message+'"')==1;body=body.replace('"'+message+'"','"'+message+': " . '+variable)
 assert body.count('ContractThrew := true')==1
 s=s[:start]+body+s[end:];p.write_text(s,encoding='utf-8-sig',newline='\n')
