# Finite extraction of the authenticated f1db before/after CLI receiver.
# Import defines a function; it does not receive sources or invoke compilers.
function Invoke-NativePacBuildSourceReceipt {
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidateSet('prebuild', 'receive')][string]$Stage,
    [Parameter(Mandatory = $true)][string]$Root,
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][ValidateRange(1, 2147483647)][int]$SourceCount
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Inputs = Get-Content -LiteralPath $InputPath -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable
$Policy = $Inputs.build_provenance
$Encoding = [Text.UTF8Encoding]::new($false, $true)
$Directory = $null
$Primary = $null
$ReceiptFailure = $null
$PreviousOptionalLocks = [Environment]::GetEnvironmentVariable('GIT_OPTIONAL_LOCKS')
$Receipt = [ordered]@{ scope = $Policy.scope; stage = $Stage; status = 'FAIL'; started_at = [DateTime]::UtcNow.ToString('o') }
function Demand([bool]$Condition, [string]$Message) {
	if (-not $Condition) { throw $Message }
}
function Hash-File([string]$Path) {
	$Item = Get-Item -LiteralPath $Path
	Demand (-not $Item.PSIsContainer -and -not ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'Source or output is not an ordinary held file.'
	return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Hash-Bytes([byte[]]$Bytes) {
	return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Bytes)).ToLowerInvariant()
}
function Snapshot-Sources {
	$Image = [ordered]@{}
	foreach ($Name in $Inputs.source_sha256.Keys) { $Image[$Name] = Hash-File (Join-Path $Root $Name) }
	return $Image
}
function Require-Image($Actual, $Expected) {
	Demand ($Actual.Count -eq $Expected.Count) 'Source inventory count changed.'
	foreach ($Name in $Expected.Keys) { Demand ($Actual.Contains($Name) -and $Actual[$Name] -ceq $Expected[$Name]) ('Source image refused: ' + $Name) }
}
function Snapshot-Producers {
	$Image = [ordered]@{}
	foreach ($Name in $Policy.producer_sha256.Keys) { $Image[$Name] = Hash-File (Join-Path $Root $Name) }
	Demand ((Hash-File (Join-Path $Root '.node-version')) -ceq $Policy.node_version_sha256) 'Node contract changed.'
	return $Image
}
function Observe-OriginalToolchain {
	$Tokens = $null; $Errors = $null
	$Ast = [Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'tools/build/build_windows_nav_owner.ps1'), [ref]$Tokens, [ref]$Errors)
	Demand ($Errors.Count -eq 0) 'Original compiler discovery source refused.'
	$Definitions = @($Ast.FindAll({ param($Node)
		$Node -is [Management.Automation.Language.FunctionDefinitionAst] -and $Node.Name -ceq 'Import-MsvcEnvironment' -and -not $Node.IsFilter
	}, $true))
	Demand ($Definitions.Count -eq 1 -and $Definitions[0].Parent -is [Management.Automation.Language.NamedBlockAst]) 'Original compiler discovery owner is ambiguous.'
	Demand ((Hash-Bytes ($Encoding.GetBytes($Definitions[0].Extent.Text))) -ceq $Policy.msvc_function_sha256) 'Original compiler discovery function changed.'
	. ([ScriptBlock]::Create($Definitions[0].Extent.Text))
	Import-MsvcEnvironment
	$Tools = [ordered]@{}
	foreach ($Name in @('cl.exe', 'link.exe', 'dumpbin.exe')) {
		$Command = Get-Command $Name -CommandType Application | Select-Object -First 1
		Demand ($Command -is [Management.Automation.ApplicationInfo] -and [IO.Path]::IsPathFullyQualified($Command.Source)) 'Original PATH-first application identity is missing.'
		$Item = Get-Item -LiteralPath $Command.Source
		Demand (-not [string]::IsNullOrWhiteSpace($Item.VersionInfo.FileVersion)) 'Native tool FileVersion is missing.'
		$Tools[$Name] = [ordered]@{ path = $Command.Source; sha256 = Hash-File $Command.Source; file_version = $Item.VersionInfo.FileVersion }
	}
	return $Tools
}
function Require-Toolchain($Before, $After) {
	Demand ($Before.Count -eq 3 -and $After.Count -eq 3) 'Original discovery tool inventory changed.'
	foreach ($Name in @('cl.exe', 'link.exe', 'dumpbin.exe')) {
		Demand ($Before.Contains($Name) -and $After.Contains($Name)) 'Original discovery tool is missing.'
		foreach ($Field in @('path', 'sha256', 'file_version')) { Demand ($Before[$Name][$Field] -ceq $After[$Name][$Field]) 'Original discovery tool identity changed across compilation.' }
	}
}
function Read-Object([string]$Path) { return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable) }
function Require-Fields($Object, [string[]]$Names) {
	Demand ($Object -is [Collections.IDictionary] -and $Object.Count -eq $Names.Count) 'Native manifest field inventory refused.'
	foreach ($Name in $Names) { Demand ($Object.Contains($Name)) ('Native manifest field missing: ' + $Name) }
}
try {
	Demand ($Inputs.status -ceq 'SEALED_FINAL_COMMITTED_SOURCE' -and $Inputs.source_sha256.Count -eq $SourceCount) 'Original committed Source seal refused.'
	Demand ($Policy.rebuilt_paths.Count -eq 2 -and $Policy.rebuilt_paths[0] -ceq 'static/ergopti_plus/windows/vendor/ergopti_network_pac.exe' -and $Policy.rebuilt_paths[1] -ceq 'static/ergopti_plus/windows/vendor/ergopti_network_pac.json') 'Only the original two native build outputs can be received.'
	Demand ([IO.Path]::IsPathFullyQualified($env:RUNNER_TEMP)) 'RUNNER_TEMP must be absolute.'
	[Environment]::SetEnvironmentVariable('GIT_OPTIONAL_LOCKS', '0')
	$Head = (& git -C $Root rev-parse HEAD).Trim()
	Demand ($LASTEXITCODE -eq 0 -and $Head -cmatch '^[0-9a-f]{40}$' -and $Head -ceq $env:GITHUB_SHA) 'Actual checkout differs from the current CI SHA.'
	Demand ($env:GITHUB_RUN_ID -cmatch '^[1-9][0-9]*$' -and $env:GITHUB_RUN_ATTEMPT -cmatch '^[1-9][0-9]*$' -and -not [string]::IsNullOrWhiteSpace($env:GITHUB_JOB)) 'Current CI run identity is missing.'
	$Receipt.ci = [ordered]@{ sha = $Head; run_id = $env:GITHUB_RUN_ID; run_attempt = $env:GITHUB_RUN_ATTEMPT; job = $env:GITHUB_JOB }
	$Receipt.inputs_sha256 = Hash-File $InputPath
	$Receipt.producer_source = Snapshot-Producers
	Require-Image $Receipt.producer_source $Policy.producer_sha256
	$Target = Join-Path $env:RUNNER_TEMP $Policy.directory_name
	if ($Stage -ceq 'prebuild') {
		Demand (-not (Test-Path -LiteralPath $Target)) 'Refusing prior build-source evidence.'
		[IO.Directory]::CreateDirectory($Target) | Out-Null
		$Directory = $Target
		$Receipt.source_before = Snapshot-Sources
		Require-Image $Receipt.source_before $Inputs.source_sha256
		$Receipt.toolchain = Observe-OriginalToolchain
		$Receipt.toolchain_scope = 'Before-build original discovery plus tool hashes/FileVersion; not a trace of compiler invocations.'
		$Receipt.status = 'PASS'
	} else {
		Demand ((Test-Path -LiteralPath $Target -PathType Container) -and -not ((Get-Item -LiteralPath $Target).Attributes -band [IO.FileAttributes]::ReparsePoint)) 'Genuine prebuild evidence directory is absent.'
		$Directory = $Target
		$BeforePath = Join-Path $Directory 'PREBUILD.json'
		$Before = Read-Object $BeforePath
		$Receipt.prebuild_sha256 = Hash-File $BeforePath
		Demand ($Before.scope -ceq $Policy.scope -and $Before.stage -ceq 'prebuild' -and $Before.status -ceq 'PASS' -and $Before.inputs_sha256 -ceq $Receipt.inputs_sha256) 'Actual original prebuild commitment is missing.'
		foreach ($Field in @('sha', 'run_id', 'run_attempt', 'job')) { Demand ($Before.ci[$Field] -ceq $Receipt.ci[$Field]) 'Prebuild belongs to another CI run.' }
		Require-Image $Before.source_before $Inputs.source_sha256
		Require-Image $Before.producer_source $Policy.producer_sha256
		Demand ($env:NATIVE_PAC_BUILD_OUTCOME -ceq 'success') 'Original native PAC build did not succeed.'
		$Receipt.original_build = [ordered]@{ step_id = $Policy.original_build_step_id; command = $Policy.original_build_command; outcome = $env:NATIVE_PAC_BUILD_OUTCOME }
		$Receipt.toolchain = Observe-OriginalToolchain
		Require-Toolchain $Before.toolchain $Receipt.toolchain
		$Receipt.toolchain_scope = 'Same original discovery tool identity before/after build; no retroactive used-compiler trace is claimed.'
		$BuildRoot = Join-Path $Root 'static/ergopti_plus/windows/build/native/network_pac'
		$SourcePath = Join-Path $BuildRoot 'prepared/source_receipt.json'
		$Source = Read-Object $SourcePath
		Require-Fields $Source @('schema_version', 'source_fingerprint', 'duktape_archive_sha256', 'inputs', 'generated_files', 'helper_bytes', 'limits')
		Demand (($Source.schema_version -is [int] -or $Source.schema_version -is [long]) -and $Source.schema_version -eq 1 -and $Source.source_fingerprint -ceq $Policy.expected_current_source_fingerprint -and $Source.duktape_archive_sha256 -ceq $Policy.duktape_archive_sha256) 'Original prepared source authority refused.'
		Demand (($Source.inputs | ConvertTo-Json -Compress) -ceq ($Policy.fingerprint_files | ConvertTo-Json -Compress)) 'Original source recipe input domain changed.'
		Demand ((Hash-File (Join-Path $BuildRoot 'msvc_function.source.ps1')) -ceq $Policy.msvc_function_sha256) 'The actual builder used another discovery function source.'
		Require-Fields $Source.generated_files @('duktape.c', 'duktape.h', 'duk_config.h', 'LICENSE.txt')
		foreach ($Name in $Source.generated_files.Keys) { Demand ((Hash-File (Join-Path (Join-Path $BuildRoot 'prepared') $Name)) -ceq $Source.generated_files[$Name]) 'Prepared file does not match the original producer receipt.' }
		$Helper = Join-Path $Root 'static/ergopti_plus/_shared/modules/network/pac_helpers.js'
		Demand (($Source.helper_bytes -is [int] -or $Source.helper_bytes -is [long]) -and $Source.helper_bytes -eq (Get-Item -LiteralPath $Helper).Length) 'Original helper byte count changed.'
		$PolicyImage = Read-Object (Join-Path $Root 'static/ergopti_plus/_shared/modules/network/proxy_policy.json')
		$Defaults = Read-Object (Join-Path $Root 'static/ergopti_plus/_shared/modules/updater/defaults.json')
		$Limits = [ordered]@{ HEAP_BYTES = $PolicyImage.native_pac.max_heap_bytes; SCRIPT_BYTES = $PolicyImage.native_pac.max_script_bytes; INPUT_BYTES = $PolicyImage.max_proxy_bytes; OUTPUT_BYTES = $PolicyImage.max_proxy_bytes; NATIVE_QUERIES = $PolicyImage.native_pac.max_native_queries; LOOKUP_MS = $Defaults.release_sources.proxy_resolve_timeout_sec * 1000 }
		Require-Fields $Source.limits @($Limits.Keys)
		foreach ($Name in $Limits.Keys) { Demand (($Source.limits[$Name] -is [int] -or $Source.limits[$Name] -is [long]) -and $Source.limits[$Name] -eq $Limits[$Name]) 'Original prepared policy limits changed.' }
		$ArtifactPath = Join-Path $BuildRoot 'artifact_receipt.json'
		$VendorPath = Join-Path $Root $Policy.rebuilt_paths[1]
		Demand ((Hash-File $ArtifactPath) -ceq (Hash-File $VendorPath)) 'Published manifest is not the original built manifest.'
		$Artifact = Read-Object $ArtifactPath
		Require-Fields $Artifact @('schema_version', 'source_fingerprint', 'duktape_archive_sha256', 'imports', 'pe_mitigations', 'license_sha256', 'exe_sha256')
		Demand (($Artifact.schema_version -is [int] -or $Artifact.schema_version -is [long]) -and $Artifact.schema_version -eq 1 -and $Artifact.source_fingerprint -ceq $Source.source_fingerprint -and $Artifact.duktape_archive_sha256 -ceq $Policy.duktape_archive_sha256) 'Original native artifact authority refused.'
		Demand (($Artifact.imports | ConvertTo-Json -Compress) -ceq (@('iphlpapi.dll', 'kernel32.dll', 'ws2_32.dll') | ConvertTo-Json -Compress)) 'Original static-system dependency contract changed.'
		$License = Hash-File (Join-Path $Root $Policy.license_path)
		Demand ($License -ceq $Inputs.source_sha256[$Policy.license_path] -and $License -ceq $Artifact.license_sha256 -and $License -ceq (Hash-File (Join-Path $BuildRoot 'prepared/LICENSE.txt'))) 'Original archive/published license changed.'
		$ExePath = Join-Path $BuildRoot 'ergopti_network_pac.exe'
		$ExeHash = Hash-File $ExePath
		Demand ($ExeHash -ceq $Artifact.exe_sha256 -and $ExeHash -ceq (Hash-File (Join-Path $Root $Policy.rebuilt_paths[0]))) 'Published executable is not the actual original built artifact.'
		$Bytes = [IO.File]::ReadAllBytes($ExePath)
		Demand ($Bytes.Length -ge 64 -and [BitConverter]::ToUInt16($Bytes, 0) -eq 0x5a4d) 'Actual native executable DOS header refused.'
		$Pe = [BitConverter]::ToInt32($Bytes, 0x3c)
		Demand ($Pe -ge 64 -and [long]$Pe + 96 -le $Bytes.LongLength -and [BitConverter]::ToUInt32($Bytes, $Pe) -eq 0x4550 -and [BitConverter]::ToUInt16($Bytes, $Pe + 4) -eq 0x8664 -and [BitConverter]::ToUInt16($Bytes, $Pe + 24) -eq 0x20b) 'Actual built x64 PE32+ identity refused.'
		$Mitigations = [BitConverter]::ToUInt16($Bytes, $Pe + 94)
		Demand (([BitConverter]::ToUInt16($Bytes, $Pe + 22) -band 0x2002) -eq 2 -and ($Mitigations -band 0x4160) -eq 0x4160 -and ($Artifact.pe_mitigations -is [int] -or $Artifact.pe_mitigations -is [long]) -and $Artifact.pe_mitigations -eq $Mitigations) 'Actual built executable/mitigation contract refused.'
		$Receipt.received_files = [ordered]@{ source_receipt = Hash-File $SourcePath; artifact_receipt = Hash-File $ArtifactPath; msvc_function = Hash-File (Join-Path $BuildRoot 'msvc_function.source.ps1') }
		$Receipt.actual_artifact_manifest = $Artifact
		$Receipt.runtime_source = Snapshot-Sources
		foreach ($Name in $Inputs.source_sha256.Keys) {
			if ($Name -cnotin $Policy.rebuilt_paths) { Demand ($Receipt.runtime_source[$Name] -ceq $Inputs.source_sha256[$Name]) ('Non-build Source changed: ' + $Name) }
		}
		Demand ($Receipt.runtime_source.Count -eq $SourceCount) 'No original Source binding can be dropped.'
		$Receipt.runtime_pair = [ordered]@{}
		foreach ($Name in $Policy.rebuilt_paths) { $Receipt.runtime_pair[$Name] = $Receipt.runtime_source[$Name] }
		$Receipt.status = 'PASS'
	}
} catch { $Primary = $_ }
finally {
	try { [Environment]::SetEnvironmentVariable('GIT_OPTIONAL_LOCKS', $PreviousOptionalLocks) }
	catch { if (-not $Primary) { $Primary = $_ }; $Receipt.status = 'FAIL' }
	if (-not $Primary -and $Receipt.status -ceq 'PASS') {
		try {
			Require-Image (Snapshot-Producers) $Policy.producer_sha256
			if ($Stage -ceq 'prebuild') { Require-Image (Snapshot-Sources) $Inputs.source_sha256 }
			else { Require-Image (Snapshot-Sources) $Receipt.runtime_source }
		} catch { $Primary = $_; $Receipt.status = 'FAIL' }
	}
	$Receipt.ended_at = [DateTime]::UtcNow.ToString('o')
	if ($Directory) {
		try {
			$Path = Join-Path $Directory $(if ($Stage -ceq 'prebuild') { 'PREBUILD.json' } else { 'POSTBUILD.json' })
			$Data = $Encoding.GetBytes(($Receipt | ConvertTo-Json -Depth 20) + "`n")
			$Stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
			$WritePrimary = $null; $CloseFailure = $null
			try { $Stream.Write($Data, 0, $Data.Length); $Stream.Flush($true) }
			catch { $WritePrimary = $_ }
			finally { try { $Stream.Dispose() } catch { $CloseFailure = $_ } }
			if ($WritePrimary) { throw $WritePrimary }
			if ($CloseFailure) { throw $CloseFailure }
		} catch { $ReceiptFailure = $_ }
	}
}
if ($Primary) { if ($ReceiptFailure) { try { [Console]::Error.WriteLine('Secondary build-source receipt failure retained.') } catch {} }; throw $Primary }
if ($ReceiptFailure) { throw $ReceiptFailure }
Write-Output ($Receipt | ConvertTo-Json -Depth 20 -Compress)
}
Export-ModuleMember -Function Invoke-NativePacBuildSourceReceipt
