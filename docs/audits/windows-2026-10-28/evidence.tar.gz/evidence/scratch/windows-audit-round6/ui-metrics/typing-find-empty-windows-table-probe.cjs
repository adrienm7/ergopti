const assert=require('node:assert/strict');
const{loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const page=loadMetricsTypingPage('windows');
const native=page.messageListeners.filter(e=>e.name==='message').at(-1).callback;
function publish(apps){native({data:{type:'prefetch',blob:{metrics_manifest:{'2026-10-27':apps},_prefetch_data:{historical:{},today:{}},app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}}}});}
function app(){return{chars:10,time:1000};}
publish({'Editor.exe':app()});
const doc=page.context.document;
const createElement=doc.createElement;
const body=doc.body;
body.tagName='DIV';body.closest=()=>null;
body.replaceChild=(fragment,node)=>{const i=body.children.indexOf(node);body.children.splice(i,1,...fragment.children);for(const child of fragment.children){child.parentNode=body;child.parentElement=body;}};
body.normalize=()=>{};
doc.createElement=(tag)=>{const n=createElement(tag);n.tagName=tag.toUpperCase();n.classList={add(){},remove(){}};n.scrollIntoView=()=>{};return n;};
doc.createTextNode=(text)=>({nodeType:3,textContent:text});
doc.createDocumentFragment=()=>({children:[],appendChild(n){this.children.push(n);}});
doc.querySelectorAll=()=>body.children.filter(n=>n.className==='find-highlight');
doc.contains=(n)=>body.children.includes(n);
let scans=0;
page.context.NodeFilter={SHOW_TEXT:4,FILTER_REJECT:2,FILTER_ACCEPT:1};
doc.createTreeWalker=()=>{scans++;let i=0;const nodes=body.children.filter(n=>n.nodeType===3);return{nextNode:()=>nodes[i++]||null};};
function admitVisibleList(){const html=page.elements.get('apps_table_container').innerHTML;const text=Array.from(html.matchAll(/<tr><td>([^<]*)<\/td>/g),m=>m[1]).join(' ');const node=doc.createTextNode(text);node.parentNode=body;node.parentElement=body;body.children=[node];return text;}
page.elements.get('find_input').value='RemoteTarget';
admitVisibleList();page.context.find_in_page(true);
const firstStatus=page.elements.get('find_status').textContent;
publish({'Editor.exe':app(),'RemoteTarget.exe':app()});
const visible=admitVisibleList();page.context.find_in_page(true);
const finalStatus=page.elements.get('find_status').textContent;
console.log(JSON.stringify({firstStatus,visible,finalStatus,scans,highlights:body.children.filter(n=>n.className==='find-highlight').map(n=>n.textContent),diagnostics:page.diagnostics}));
assert.equal(finalStatus,'1\u202f/\u202f1','the same search must discover text introduced by an admitted native update');
