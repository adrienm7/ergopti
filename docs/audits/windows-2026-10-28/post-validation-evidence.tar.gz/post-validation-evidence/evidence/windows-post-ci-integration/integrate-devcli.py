import subprocess,json,datetime
from pathlib import Path
from zoneinfo import ZoneInfo
root=Path('/workspace/ergopti-windows-integration');out=Path('/workspace/scratch/windows-post-ci-integration');stage=out/'devcli';stage.mkdir(exist_ok=True)
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert not git('status','--porcelain') and git('rev-parse','HEAD')==json.loads((out/'shutdown-completed.json').read_text())['head']
sha='7348172a5698c0ab5251a1958b9d1e1448676fb4'
with (stage/'cherry-pick.log').open('w') as f:subprocess.run(['git','cherry-pick','--no-commit',sha],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
checks=[]
for q in json.loads(Path('/workspace/scratch/windows-changelog-qualified-delivery/qualification.json').read_text())['stages']:
 if q['name'].startswith('native-') or q['name']=='full-js':continue
 with (stage/(q['name']+'.log')).open('w') as f:r=subprocess.run(q['argv'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 checks.append(dict(name=q['name'],argv=q['argv'],exit_code=r.returncode));(stage/'quick-gates.json').write_text(json.dumps(checks,indent=2)+'\n');assert r.returncode==0,q['name']
argv=['node','tools/test/test-windows-dev-script.cjs']
with (stage/'host-devcli.log').open('w') as f:r=subprocess.run(argv,cwd=root,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
text=(stage/'host-devcli.log').read_text();assert '(21 checks; native_entry_cases=0; host_entry_body_cases=8)' in text,text
with (stage/'commit.log').open('w') as f:subprocess.run(['git','commit','-C',sha],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
assert not git('status','--porcelain')
rows=json.loads((out/'receipts.json').read_text());assert len(rows)==2
rows.append(dict(label='devcli-null-receipt',original_sha=sha,integrated_sha=git('rev-parse','HEAD'),quick_gates=checks,host_integration=dict(argv=argv,exit_code=r.returncode,checks=21,native_windows_qualified=False),proof='/workspace/scratch/windows-final-devcli-proof/proof.json',normal_hooks=True,at_paris=datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()))
(out/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'completed.json').write_text(json.dumps(dict(head=git('rev-parse','HEAD'),at_paris=datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()),indent=2)+'\n');print(git('rev-parse','HEAD'))
