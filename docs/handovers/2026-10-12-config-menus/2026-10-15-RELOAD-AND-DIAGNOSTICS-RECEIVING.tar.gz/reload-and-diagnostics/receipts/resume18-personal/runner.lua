local root = assert(os.getenv("ERGOPTI_PROBE_REPO")) .. "/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
if os.getenv("ERGOPTI_PROBE_PRODUCER") then
 local producer = os.getenv("ERGOPTI_PROBE_PRODUCER")
 package.preload["infra.file_watchers"] = function() return assert(loadfile(producer))() end
end
local helpers = require("tests.helpers")
if arg[1] then helpers.set_only_filter(arg[1]) end
require("tests.unit.meta.test_file_watchers")
local results = helpers.get_results()
print("FOCUSED_RESULTS " .. require("json").encode(results))
os.exit(results.failed == 0 and 0 or 1)
