﻿; tests/unit/test_base_url_policy.ahk

; ==============================================================================
; MODULE: Shared Base URL Policy Tests
; DESCRIPTION:
; Independent URI literals and the unchanged complete-endpoint builder preserve
; valid routes while refusing malformed local-server addresses before acquisition.
; ==============================================================================

#Requires AutoHotkey v2.0





; ===============================================
; ===============================================
; ======= 1/ Independent Literal Cases ==========
; ===============================================
; ===============================================

_BUP_IndependentLiterals() {
	global _SharedDir
	Corpus := JsonParse(FileRead(_SharedDir . "\tests\corpus\llm\base_url_vectors.json", "UTF-8"))
	AssertEqual(35, Corpus["cases"].Length, "exact independent corpus is present")
	Checked := 0
	for Case in Corpus["cases"] {
		Normalized := RemoteBaseUrlNormalize(Case["input"], &Reason)
		if Case["valid"] {
			AssertEqual(Case["normalized"], Normalized, Case["id"])
			AssertEqual("ok", Reason, Case["id"] . " successful category")
		} else {
			AssertEqual("", Normalized, Case["id"])
			Assert(Reason is String && Reason != "", Case["id"] . " refusal category")
			Assert(!InStr(Reason, "secret"), Case["id"] . " private value absent")
		}
		Checked += 1
	}
	AssertEqual(35, Checked, "every independent case executed")
}
Test("shared base URL: every independent literal executes", _BUP_IndependentLiterals)

_BUP_NonStringRefusal() {
	for Value in [0, 1, false, true, Map(), [], (*) => 0] {
		AssertEqual("", RemoteBaseUrlNormalize(Value, &Reason), "nonstring scalar refused")
		AssertEqual("base URL is empty", Reason, "type refusal is private")
	}
}
Test("shared base URL: primitive typing fails closed", _BUP_NonStringRefusal)

_BUP_CompleteEndpointCompatibility() {
	Endpoint := "HTTPS://Fixture.Invalid/flows/run/"
	AssertEqual(Endpoint, _LLMRemoteBuildUrl(Endpoint, "decisions", "k", "m"),
		"existing complete decisions endpoint keeps its exact meaningful trailing slash")
	AssertEqual("http://127.0.0.1:19273/v1/chat/completions",
		_LLMRemoteBuildUrl("http://127.0.0.1:19273/v1/", "openai", "k", "m"),
		"existing appended endpoint keeps its original behavior")
}
Test("shared base URL: existing full endpoint semantics remain unchanged", _BUP_CompleteEndpointCompatibility)
