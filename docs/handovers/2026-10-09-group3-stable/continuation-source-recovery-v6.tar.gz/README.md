# Inactive continuation recovery

This archive preserves source evidence, not integrated product or native
acceptance. See MANIFEST.json for each proposal's review/custody boundary.
Windows and Linux enrollment reviews were still pending when this snapshot
was made; do not infer source clearance from the archive's existence.
The earlier original/V1 HOLD failures remain retained in the sealed review
records. Current Dev qualification is red; no assertion was weakened.

Extract only into a new owned directory; verify every manifest/inner seal.
Reconcile every exact preimage with latest Dev and its live source owners.
Generate artifacts through actual owners, never from archived output.
Do not adopt validation-history commits, overwrite workflows or independent
oracles, mint native authority from descriptors, or claim device coverage.
The previously published V4 packet remains the SDK/Caps/row recovery owner.
