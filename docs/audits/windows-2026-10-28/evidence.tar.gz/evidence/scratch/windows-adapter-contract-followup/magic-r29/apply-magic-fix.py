from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/unit/modules/hotstrings/magic_key/test_magic_editor.ahk')
s=p.read_text(encoding='utf-8-sig');start=s.index('_MET_CohortRefusal(Refuse) {');end=s.index('\n}\n',start)+2;body=s[start:end]
old='Events := [], Handles := Map(), Debt := ""';assert body.count(old)==1;body=body.replace(old,old+', ContractThrew := false')
old='catch as Err {\n\t\tDebt := Err.Message';assert body.count(old)==1;body=body.replace(old,'catch as Err {\n\t\tContractThrew := true\n\t\tDebt := Err.Message')
old='AssertEqual("", Debt)';assert body.count(old)==1;body=body.replace(old,'AssertFalse(ContractThrew, "The complete native cohort must not throw: " . Debt)')
s=s[:start]+body+s[end:];p.write_text(s,encoding='utf-8-sig',newline='\n')
