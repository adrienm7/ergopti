import sys,signal,time,json,os
from pathlib import Path
request,result,ready,mode=map(str,sys.argv[1:])
def respond(signum,frame):
 data=json.loads(Path(request).read_text())
 record={'schema':True if mode=='boolean-schema' else 1,'request_id':data['request_id'],'state':'completed','driver_pid':os.getpid(),'successor_pid':os.getpid()}
 text=json.dumps(record,separators=(',',':'))
 if mode=='broken-json':text=text[:-1]
 stage=Path(result+'.fixture-stage');stage.write_text(text+'\n');stage.replace(result)
signal.signal(signal.SIGUSR1,respond)
Path(ready).write_text('ready\n')
while True:time.sleep(.05)
