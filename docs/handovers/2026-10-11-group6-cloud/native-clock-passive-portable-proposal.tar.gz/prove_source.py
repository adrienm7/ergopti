"""Finite byte preservation and whole-source inverses; never a test runner."""
from pathlib import Path
import ast,difflib,hashlib,json
BASE=Path(__file__).resolve().parent

def functions(source):
    lines=source.splitlines(keepends=True)
    found={}
    def visit(node,prefix=()):
        for child in ast.iter_child_nodes(node):
            if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                route=prefix+(child.name,)
                if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    start=min([child.lineno]+[d.lineno for d in child.decorator_list])-1
                    found['.'.join(route)]={'start':start,'end':child.end_lineno,'body':''.join(lines[start:child.end_lineno])}
                visit(child,route)
            else:visit(child,prefix)
    visit(ast.parse(source));return found

records=[];inverses={}
for relative,exceptions in (
 ('static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py',{'WireFixture._command'}),
 ('static/ergopti_plus/macos/tests/support/native_http_fixture_builder.py',{'OwnedFixtureBuild._command'}),
 ('static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py',{'receive_native_clock','RealNativeClientReceiving.setUpClass'}),
):
    before=(BASE/'preimage'/relative).read_text();after=(BASE/'candidate'/relative).read_text()
    old=functions(before);new=functions(after)
    assert old.keys()<=new.keys()
    preserved=[]
    for route in old:
        if route not in exceptions:
            assert old[route]['body']==new[route]['body'],(relative,route)
            preserved.append(route)
    inverse=after
    # Whole function replacements are finite independent preimage inverses, never
    # a historical corpus regenerated from the implementation.
    changes=[]
    for route in exceptions:
        assert inverse.count(new[route]['body'])==1
        changes.append({'candidate_span':new[route]['body'],'original_span':old[route]['body'],'function':route})
        inverse=inverse.replace(new[route]['body'],old[route]['body'],1)
    addition=None
    if relative.endswith('native_http_wire_client_receiving.py'):
        begin=inverse.index('def native_clock_python_loader(cache):\n')
        end=inverse.index('def receive_native_clock(build, builder):\n')
        addition=inverse[begin:end]
        inverse=inverse[:begin]+inverse[end:]
    assert inverse==before,relative
    inverses[relative]={'replacements':changes,'addition':addition}
    records.append({'path':relative,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'preserved_function_bodies':preserved,'explicit_additive_seam_exceptions':sorted(exceptions),'whole_literal_inverse':True})
relative='tools/test/test-managed-ollama-protocol.cjs'
before=(BASE/'preimage'/relative).read_text();after=(BASE/'candidate'/relative).read_text()
ops=difflib.SequenceMatcher(a=before.splitlines(keepends=True),b=after.splitlines(keepends=True),autojunk=False).get_opcodes()
insertions=[];oldlines=before.splitlines(keepends=True);newlines=after.splitlines(keepends=True)
for tag,a,b,c,d in ops:
    if tag!='equal':
        assert tag=='insert',(tag,a,b,c,d)
        insertions.append(''.join(newlines[c:d]))
inverse=after
for addition in insertions:
    assert inverse.count(addition)==1;inverse=inverse.replace(addition,'',1)
assert inverse==before
inverses[relative]={'additions':insertions}
records.append({'path':relative,'whole_literal_inverse':True,'original_156_census_preserved':True,'new_children':{'python_passive':21,'cjs_receiver':32}})
relative='.github/workflows/ci-macos.yml'
before=(BASE/'preimage'/relative).read_text();after=(BASE/'candidate'/relative).read_text()
# Exact finite line diff yields only independently reviewed body/upload spans.
ops=difflib.SequenceMatcher(a=before.splitlines(keepends=True),b=after.splitlines(keepends=True),autojunk=False).get_opcodes()
oldlines=before.splitlines(keepends=True);newlines=after.splitlines(keepends=True);changes=[]
for tag,a,b,c,d in ops:
    if tag!='equal':changes.append({'original_span':''.join(oldlines[a:b]),'candidate_span':''.join(newlines[c:d])})
inverse=after
for change in changes:
    assert change['candidate_span'] and inverse.count(change['candidate_span'])==1
    inverse=inverse.replace(change['candidate_span'],change['original_span'],1)
assert inverse==before
inverses[relative]={'replacements':changes,'qualification':'HELD_PENDING_CUSTODY_AND_NATIVE_COMPATIBILITY'}
records.append({'path':relative,'whole_literal_inverse':True,'original_job_roster_and_package_step_preserved':True,'original_timeout_minutes':5,'changed_invocation':'independent client fixed -I -B -X private prefix; native compatibility UNRUN'})
(BASE/'source-preservation.json').write_text(json.dumps({'state':'SOURCE_ONLY_NO_UNIT_OR_NATIVE_CREDIT','records':records},indent=2)+'\n')
(BASE/'formatted-literal-inverses.json').write_text(json.dumps(inverses,indent=2)+'\n')
patch=''
for relative in sorted(p.relative_to(BASE/'candidate').as_posix() for p in (BASE/'candidate').rglob('*') if p.is_file()):
    target=BASE/'candidate'/relative;original=BASE/'preimage'/relative
    before=original.read_text() if original.exists() else ''
    patch+=''.join(difflib.unified_diff(before.splitlines(keepends=True),target.read_text().splitlines(keepends=True),fromfile=('a/'+relative if original.exists() else '/dev/null'),tofile='b/'+relative))
(BASE/'proposal.patch').write_text(patch)
files={p.relative_to(BASE).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted((BASE/'candidate').rglob('*')) if p.is_file()}
(BASE/'candidate-manifest.json').write_text(json.dumps({'state':'SOURCE_ONLY_UNRUN','native_factory':'HELD','files':files},indent=2)+'\n')
print(json.dumps({'whole_inverses':len(records),'preserved_original_python_functions':sum(len(r.get('preserved_function_bodies',[])) for r in records),'new_child_cases':53,'source_only':True}))
