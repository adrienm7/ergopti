from pathlib import Path
import re,json,hashlib,datetime
from zoneinfo import ZoneInfo
s=Path('/workspace/scratch/oct28-merge11-final-ci');snap=json.loads((s/'latest.json').read_text());head='b56677ea345e115828e2bf5b5dbfcf5cf5e46c7e';assert snap['run']['id']==40765470617 and snap['run']['head_sha']==head
ids={'core':123089783882,'menu_llm':123089783841,'menu_input':123089783886,'modules':123089783963,'meta':123089783999,'ui':123089784021,'other':123089784110,'integration':123096608526};allmods=[];groups=[];regressions=[];declared=[]
for name,jid in ids.items():
 job=next(x for x in snap['jobs']['jobs']if x['id']==jid);assert job['conclusion']=='success'and job['run_id']==40765470617
 p=s/('hs-'+name+'-connected.log');raw=p.read_bytes();text=raw.decode();assert head in text
 if name=='integration':
  assert 'lua5.4 tests/run.lua --module=integration' in text
  profile='No profile banner emitted by direct complete integration-group invocation'
 else:
  assert 'Qualification profile inactive; full execution is required.'in text
  profile='inactive'
 lines=[re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+Z ', '',x)for x in text.splitlines()];body='\n'.join(lines)
 h=re.findall(r'Module group "([^\"]+)": (\d+) of (\d+) module\(s\)',body);assert len(h)==1 and h[0][0]==name
 loaded=re.findall(r'^>>> Loading ([^\r\n]+)',body,re.M);assert int(h[0][1])==len(loaded);declared.append(int(h[0][2]));allmods+=loaded
 summaries=re.findall(r'OVERALL RESULTS:\s*Total modules:\s*(\d+)\s*Passed tests:\s*(\d+)\s*Failed tests:\s*(\d+)',body);assert len(summaries)==1;modules,passed,failed=map(int,summaries[0]);assert modules==len(loaded)>0 and passed>0 and failed==0
 rows=[json.loads(x[len('# lua_timing '):])for x in lines if x.startswith('# lua_timing ')];assert rows and all(x['schema']==1 and x['driver']=='macos'and x['status']=='pass'and x['timing_error']==''for x in rows);assert len({x['id']for x in rows})==len(rows)
 cases=[x for x in rows if x['kind']=='case'];mods=[x for x in rows if x['kind']=='module'];assert len(cases)+len(mods)==len(rows)and len(cases)==passed and len(mods)==modules;assert {x['module']for x in mods}==set(loaded)
 regressions +=[x for x in cases if x['module']in['tests.unit.infra.field_run.test_field_run','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_deferred_errors']or'text_carrier_avoids_held_key'in x['module']]
 groups.append({'name':name,'job_id':jid,'conclusion':job['conclusion'],'modules':modules,'passed':passed,'failed':failed,'log_sha256':hashlib.sha256(raw).hexdigest(),'actual_case_frames':len(cases),'actual_module_frames':len(mods),'profile':profile})
assert len(set(declared))==1 and len(allmods)==len(set(allmods))==declared[0]
assert sum(x['module']=='tests.unit.infra.field_run.test_field_run'for x in regressions)==34
assert sum(x['module']=='tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_deferred_errors'for x in regressions)==2
assert sum('text_carrier_avoids_held_key'in x['module']for x in regressions)==3
out={'run_id':40765470617,'head_sha':head,'observed_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'groups':groups,'passed':sum(x['passed']for x in groups),'failed':0,'unique_complete_disjoint_modules':len(set(allmods)),'declared_canonical_modules':declared[0],'loaded_modules':allmods,'regression_case_frames':regressions,'scope':'Actual eight current-run portable Lua unit/integration cohorts. Every positive case/module timing frame matches the one positive summary and canonical loaded-module census. Not native Darwin, installed app, physical keyboard or TCC qualification. Separate E2E/native/installed evidence required.'};p=s/'reviewed-evidence/macos-lua-unit-integration.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'passed':out['passed'],'modules':out['unique_complete_disjoint_modules'],'failed':0,'regression_frames':len(regressions),'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
