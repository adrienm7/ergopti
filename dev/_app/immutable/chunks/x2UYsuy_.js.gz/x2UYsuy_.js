import{B as a}from"./CiRgm-OL.js";a();
