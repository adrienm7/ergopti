#!/usr/bin/env python3
"""Install a signed/hash-pinned genuine chooser in a new owned prefix only."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import urllib.request

PACKET = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print("SOURCE ONLY: no chooser installation or native execution.")
        return
    manifest = json.loads((PACKET / "DEPENDENCIES.json").read_text())
    for name, expected in manifest["unmodified_environment_pins"].items():
        if digest(Path(name)) != expected:
            raise RuntimeError("Retained environment preimage changed: " + name)
    trust = manifest["trust"]
    for key in ("Packages", "InRelease", "keyring"):
        if digest(Path(trust[key + "_path"])) != trust[key + "_sha256"]:
            raise RuntimeError("Pinned signed metadata/keyring changed: " + key)
    verifier = json.loads((PACKET / "VERIFIER-PROVENANCE.json").read_text())
    if digest(Path(verifier["binary"])) != verifier["binary_sha256"]:
        raise RuntimeError("Genuine pinned APT verifier changed")
    if digest(Path("/var/lib/dpkg/status")) != verifier["dpkg_status_sha256"]:
        raise RuntimeError("Installed verifier package provenance changed")
    # Preserve a real authenticated cleartext output before prefix allocation.
    # Default signature, expiry and cryptographic policies are not overridden.
    verification_dir = Path(tempfile.mkdtemp(prefix="actual-signed-release-", dir=PACKET))
    authenticated = verification_dir / "Release.authenticated"
    command = [verifier["binary"], "--keyring", trust["keyring_path"],
               "--cleartext", "--output", str(authenticated), trust["InRelease_path"]]
    print(json.dumps({"verification_directory": str(verification_dir), "command": command}), flush=True)
    signature = subprocess.run(command, check=True)
    body = authenticated.read_bytes()
    lines = body.decode("utf-8").splitlines()
    sections = [index for index, line in enumerate(lines) if line == "SHA256:"]
    if len(sections) != 1:
        raise RuntimeError("Authenticated Release SHA256 authority is ambiguous")
    entries = []
    for line in lines[sections[0] + 1:]:
        if not line.startswith((" ", "\t")):
            break
        fields = line.split()
        if len(fields) != 3:
            raise RuntimeError("Authenticated SHA256 entry is malformed")
        if fields[2] == "main/binary-amd64/Packages":
            entries.append(fields)
    expected_entry = [trust["Packages_sha256"], str(trust["Packages_bytes"]), "main/binary-amd64/Packages"]
    if entries != [expected_entry] or Path(trust["Packages_path"]).stat().st_size != trust["Packages_bytes"]:
        raise RuntimeError("Original Packages hash/size is not uniquely authenticated")
    prefix = Path(manifest["new_owned_prefix"])
    # Refuse to replace any previous tooling or half-prepared attempt.
    prefix.mkdir(mode=0o700)
    provenance = prefix / "provenance"
    provenance.mkdir(mode=0o700)
    (provenance / "Release.authenticated").write_bytes(body)
    packages = prefix / "packages"
    packages.mkdir(mode=0o700)
    for item in manifest["packages"]:
        payload = packages / Path(item["filename"]).name
        pending = payload.with_suffix(payload.suffix + ".pending")
        with urllib.request.urlopen(item["uri"], timeout=60) as response:
            with pending.open("xb") as output:
                shutil.copyfileobj(response, output)
        if pending.stat().st_size != item["bytes"] or digest(pending) != item["sha256"]:
            raise RuntimeError("Signed-index payload hash/size refusal: " + item["name"])
        control = subprocess.check_output([
            "/usr/bin/dpkg-deb", "--field", str(pending), "Package", "Version", "Architecture",
        ], text=True)
        fields = dict(line.split(": ", 1) for line in control.splitlines())
        if (fields["Package"], fields["Version"], fields["Architecture"]) != (
                item["name"], item["version"], item["architecture"]):
            raise RuntimeError("Payload control identity refusal: " + item["name"])
        pending.rename(payload)
        subprocess.run(["/usr/bin/dpkg-deb", "--extract", str(payload), str(prefix)], check=True)
    binary = prefix / "usr/bin/zenity"
    if not binary.is_file():
        raise RuntimeError("Genuine zenity executable is absent after trusted extraction")
    # Package triggers are not run by dpkg-deb. Compile the actual GTK4 schemas
    # with the existing GLib tool into a new owned schema directory, not /usr.
    schemas = prefix / "state/schemas"
    schemas.mkdir(parents=True, mode=0o700)
    for source_root in (Path("/usr/share/glib-2.0/schemas"), prefix / "usr/share/glib-2.0/schemas"):
        for source in sorted(source_root.glob("*")):
            if source.suffix not in (".xml", ".override"):
                continue
            destination = schemas / source.name
            if destination.exists() or destination.is_symlink():
                if destination.read_bytes() != source.read_bytes():
                    raise RuntimeError("Schema name collision: " + source.name)
                continue
            destination.symlink_to(source)
    subprocess.run(["/usr/bin/glib-compile-schemas", "--strict", str(schemas)], check=True)
    bin_dir = prefix / "bin"
    bin_dir.mkdir(mode=0o700)
    wrapper = bin_dir / "zenity"
    wrapper.write_bytes((PACKET / "zenity-owned-wrapper.sh").read_bytes())
    wrapper.chmod(0o755)
    receipt = {
        "status": "DEPENDENCIES_EXTRACTED; native chooser and Browse remain UNRUN",
        "prefix": str(prefix), "binary_sha256": digest(binary),
        "wrapper_sha256": digest(wrapper), "schemas_sha256": digest(schemas / "gschemas.compiled"),
        "packages": [{"name": p["name"], "version": p["version"], "sha256": p["sha256"]}
                     for p in manifest["packages"]],
        "source_manifest_sha256": digest(PACKET / "DEPENDENCIES.json"),
        "verifier": {"binary": verifier["binary"], "binary_sha256": verifier["binary_sha256"],
                     "installed_package_version": verifier["installed_package_version"],
                     "command": command, "exit_code": signature.returncode,
                     "provenance_source_sha256": digest(PACKET / "VERIFIER-PROVENANCE.json"),
                     "authenticated_release_sha256": digest(provenance / "Release.authenticated"),
                     "original_packages_entry": expected_entry},
        "old_environment_pins_unchanged": all(digest(Path(p)) == h
                                                for p, h in manifest["unmodified_environment_pins"].items()),
    }
    if receipt["old_environment_pins_unchanged"] is not True:
        raise RuntimeError("Existing activation/namespace/tooling changed during extraction")
    (prefix / "INSTALL-RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")


if __name__ == "__main__":
    main()
