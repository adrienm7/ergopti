const assert=require('node:assert/strict');
const vm=require('node:vm');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
function fixture(manifest){
 const page=loadMetricsTypingPage('windows');
 page.elements.get('app_search').focus=()=>{};
 const native=page.messageListeners.filter(e=>e.name==='message').at(-1).callback;
 function publish(value,initial=false){native({data:{type:'prefetch',blob:{metrics_manifest:value,...(initial?{_prefetch_data:{historical:{},today:{}},app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}}:{})}}});}
 function state(){return JSON.parse(vm.runInContext('JSON.stringify({available:app_state.available_apps,selected:[...app_state.selected_apps],mode:app_state.app_selection_mode,dates:app_state.manifest_dates_sorted})',page.context));}
 publish(manifest,true);
 return{page,publish,state};
}
const populated=fixture({'2026-10-27':{'Editor.exe':{chars:10,time:1000}}});
assert.deepEqual(populated.state().available,['Editor.exe']);
populated.publish({});
const cleared=populated.state();
const empty=fixture({});empty.page.context.open_app_modal();empty.page.context.deselect_all_apps();empty.page.context.close_app_modal();
const none=empty.state();const label=empty.page.elements.get('app_filter_btn').innerText;
console.log(JSON.stringify({cleared,none,label,expectedNone:empty.page.context._t('ui_typing.apps_none'),diagnostics:[...populated.page.diagnostics,...empty.page.diagnostics]}));
assert.deepEqual(cleared.available,[],'admitted empty native history retires all stale application names');
assert.equal(label,empty.page.context._t('ui_typing.apps_none'),'explicit NONE keeps its meaning with zero available apps');
