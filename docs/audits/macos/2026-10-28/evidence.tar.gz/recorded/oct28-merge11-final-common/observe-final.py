from pathlib import Path
import os,json,datetime
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-merge11-final-common');roots=['/workspace/ergopti-macos-final-common',str(O)];parent_ids={os.getpid()};pid=os.getppid()
while pid>1:
 parent_ids.add(pid)
 try:pid=int(Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[1])
 except(OSError,ValueError):break
refs=[];unreadable=[];zombies=0
for p in Path('/proc').iterdir():
 if not p.name.isdigit()or int(p.name)in parent_ids:continue
 try:
  if p.stat().st_uid!=os.getuid():continue
  if (p/'stat').read_text().split(') ',1)[1].split()[0]=='Z':zombies+=1;continue
  cmd=(p/'cmdline').read_bytes();env=(p/'environ').read_bytes();cwd=os.readlink(p/'cwd');maps=(p/'maps').read_bytes();hits=[]
  for root in roots:
   rb=root.encode()
   for key,data in [('argv',cmd),('environment',env),('maps',maps)]:
    if rb in data:hits.append(key+':'+root)
   if cwd.startswith(root):hits.append('cwd:'+root)
  for fd in (p/'fd').iterdir():
   try:
    target=os.readlink(fd)
    if any(target.startswith(root)for root in roots):hits.append('fd:'+target)
   except FileNotFoundError:pass
  if hits:refs.append({'pid':int(p.name),'hits':hits,'command':cmd.replace(b'\0',b' ').decode(errors='replace')[:200]})
 except FileNotFoundError:pass
 except PermissionError:unreadable.append(int(p.name))
d={'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'roots':roots,'live_refs':refs,'unreadable_live_same_uid':unreadable,'observed_zombie_count':zombies,'qualified':not refs and not unreadable,'scope':'Exact private output and checkout provenance in live same-UID argv/cwd/environment/fd/maps. Excludes observer ancestry and already-dead zombies; no sanitized-detached-child or zombie reaping/attribution claim.'};(O/'residual-observer.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2));assert d['qualified']
