const fs=require('node:fs');
const path=require('node:path');
const cp=require('node:child_process');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const root='/workspace/ergopti-windows-r6-tests';
const packet=__dirname;
const runner=path.join(root,'static/ergopti_plus/windows/tests/run_all.ahk');
const original=fs.readFileSync(runner);
let source=original.toString('utf8');
const marker='\nRunTests()\n';
assert.equal(source.split(marker).length,2,'one canonical final runner entry is required');
source=source.replace('#SingleInstance Force','#SingleInstance Off');
source=source.replace(marker,'\n#Include Z:'+path.join(packet,'regression-fragment.ahk').replace(/\//g,'\\')+'\nRunTests()\n');
const owned=path.join(path.dirname(runner),'.r6-legacy-capture-'+crypto.randomBytes(6).toString('hex')+'.ahk');
const fd=fs.openSync(owned,'wx');fs.writeFileSync(fd,source);fs.closeSync(fd);
const tap=path.join(packet,'legacy-native-old.tap');
let safeToRemove=false;
try {
 const argv=['--kill-after=5s','300s','xvfb-run','-a','wine','/workspace/toolchain/ahk/AutoHotkey64.exe','/ErrorStdOut','Z:'+owned.replace(/\//g,'\\'),'--only','legacy-identity-fixture-capture-debt'];
 const result=cp.spawnSync('timeout',argv,{encoding:'utf8',maxBuffer:4*1024*1024,env:{...process.env,WINEPREFIX:'/workspace/toolchain/wine-r3-metrics-owned',LC_ALL:'C.UTF-8',ERGOPTI_AHK_RESULTS_FILE:'Z:'+tap.replace(/\//g,'\\')}});
 safeToRemove=result.status!==null&&result.status!==124&&result.signal===null&&!result.error;
 fs.writeFileSync(path.join(packet,'native-old.stdout'),result.stdout||'');fs.writeFileSync(path.join(packet,'native-old.stderr'),result.stderr||'');
 const receipt={argv,status:result.status,signal:result.signal,error:result.error?.message,canonical_runner_sha256:crypto.createHash('sha256').update(original).digest('hex'),private_runner_sha256:crypto.createHash('sha256').update(source).digest('hex'),production_sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'static/ergopti_plus/windows/adapters/shell_runner.ahk'))).digest('hex')};
 fs.writeFileSync(path.join(packet,'old-native-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log(result.stdout,result.stderr);
 assert(safeToRemove,'the exact observer must actually retire');
 const raw=fs.readFileSync(tap,'utf8');assert(raw.includes('1..1'),'one actual synthetic-fixture regression must be registered');
 assert.equal(result.status,0,'the synthetic fixture must not leak capture ownership');
} finally {
 if(safeToRemove)fs.unlinkSync(owned);
}
