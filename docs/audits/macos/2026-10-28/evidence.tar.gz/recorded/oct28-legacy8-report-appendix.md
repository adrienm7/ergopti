## Historical appendix — eight commits already published before this batch

These are the eight commits listed in `oct28-preserved-published-commits.json`, with subjects checked against Git. They are historical work whose surviving behavior was already adopted or superseded by `dev`, not eight additional fixes in the current batch. Several entries improve test observers rather than the product. In particular, `efa02d82` was explicitly reverted by `5aeec2a7` after Darwin disproved its premise; that pair must not be counted as two surviving product fixes.

All eight commits are ancestors of historical merge `74f683f5a6ad49a62e5dad8837b8375375a01d3c`. Its tree, `5df1a4f2744da5eb7ee3e2a1dcd7fe02f3a918ec`, equals the tree of then-current `dev` at `ed95abafa1`. This establishes the historical integration boundary, not byte-for-byte identity between each old patch and today's sources. Paths below name the regression sources at the listed historical commit.

### e8ea64ff1e414a6e523ccfc3e3cfe18f760b8316 — fix(macos): serialize App Cloner Dock preference updates

- **Bug:** two cooperating clone creators could read the same Dock preferences and overwrite one another's new entry while both reported success.
- **Proof:** the retained baseline and disabled-lock controls each exit 1 and persist only label `B`; the candidate records 14/14 physical controls passing. These exercise the actual extracted Dock update code, real plist files and kernel locks, with Foundation, registration and restart ports controlled. They do not establish a live Dock/UI result. The five committed file hashes and tree match the retained Dock commit receipt, whose pre-integration SHA differs.
- **Cause and correction:** the complete read–modify–write lacked shared ownership. One private lock now covers it, its stable inode remains available to waiting writers, and the exact descriptor closes on every exit.
- **Regression paths:** `static/ergopti_plus/macos/tests/support/apps/dock_update_campaign.py`; `static/ergopti_plus/macos/tests/unit/modules/shortcuts/apps/test_app_cloner_dock_lock.lua`; `static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/NativeAppClonerDockUpdateTests.swift`; `tools/test/test-app-cloner-dock-url.cjs`.
- **Retained evidence:** `/workspace/scratch/cloner-dock-integration/red-final.json`, `ready.json` and `commit-receipt.json`.

### 08958f5c24c181bd8cc519045e77a8b1ba5f62ae — test(macos): require native App Cloner worker completion

- **Gap:** worker completion depended on files that can fail to persist, but portable shell checks did not qualify the actual Darwin launcher, worker and completion predicate together.
- **Proof and limit:** the committed native regression runs the source launcher and worker through `osascript`, checks healthy and file-size-refused cases under the requested signal dispositions, and requires the source completion predicate. The retained candidate receipt explicitly says native execution was unrun on Linux; its absent/duplicate-predicate and pure assertion controls are not native execution evidence. No independent historical old-code-red result is asserted here.
- **Cause and correction:** source extraction or a successful parent exit alone could miss the detached worker's actual completion. The test now requires that completion, preserves an absent-file negative control, and bounds owned children without deleting uncertain fixtures. This is test coverage, not the later product supervisor repair.
- **Regression paths:** `static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/NativeAppClonerWorkerCompletionTests.swift`, method `testActualCompletionPredicateSettlesAfterStatusPersistenceRefusal`; `tools/test/lib/app-cloner-worker-completion-probe.py`.
- **Retained evidence:** `/workspace/scratch/cloner-worker-native-candidate/ready.json` and `peer-final-review.json`.

### 91c95a6cdec445b6b4884331ad49b59a9fb4f216 — fix(test): admit the current macOS metrics page scripts

- **Bug:** the macOS native metrics observer rejected the current page after the generated category-alias asset became part of its script list.
- **Proof:** the Git diff shows the obsolete `len(parser.scripts) == 11` check replaced by the exact ordered twelve-script contract, including `../_generated/metrics_general_category_aliases.js`. The regression reads the actual repository page, verifies the alias asset's hash, and rejects missing, duplicate, unknown and reordered scripts. This is supported by the committed source and regression, not a newly executed historical red run.
- **Cause and correction:** an outdated count was being used as source admission. The observer now checks ordered asset identities and includes the alias in the hashed source manifest.
- **Regression path:** `tools/diagnostics/macos_metrics_apps_page_test.py`, method `test_source_manifest_uses_actual_declared_scripts_and_caller_query`.
- **Scope:** only the macOS observer's admission changed; this does not claim a Windows, Linux or web product fix.

### 65842cf77932b2355c3e187de1fffd51e6b7f034 — test(macos): materialize native picker callback diagnostics

- **Bug:** the native picker observer could report the AppleScript property reference `fixturePickerError of script` instead of the callback's stored diagnostic, hiding the underlying failure.
- **Proof and limit:** the retained receipt records three historical picker failures with the literal property-reference diagnostic (`-2700`). The added test executes the exact generated post-modal branch and requires stored failure, readiness and setter text, a successful stored receipt, and rejection of a missing receipt. That branch test opens no panel. The pre-CI receipt marks local native execution unrun; no new Darwin result or historical old/new count is invented here.
- **Cause and correction:** callback-owned properties reached commands and Foundation without an explicit value snapshot. The observer now materializes them with `get` and text coercion before use. The native locale assertions and public Cancel observation remain in the historical test source.
- **Regression path:** `static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/AppClonerWizardLocaleTests.swift`, method `testPickerObserverMaterializesCallbackDiagnosticsAndReceipt`.
- **Retained evidence:** `/workspace/scratch/cloner-picker-observer-diagnostic/ready.json` and `peer-review.json`.

### 5aeec2a70d464b0f26e655379b7ce93cf9051214 — revert(macos): restore the original App Cloner helper admission

- **Correction of a false positive:** this reverses the production admission change in `efa02d82`; it does not establish a new failure of an already-executable helper on Darwin.
- **Proof:** the commit records the native contradiction and changes the regression accordingly. On the owned read-only Darwin volume, BSD `chmod +x` succeeds when mode `0755` is unchanged, while a direct `Darwin.chmod` syscall still receives `EROFS` or `EPERM`. The test requires unchanged helper bytes and permissions, actual helper output, and missing/nonexecutable-helper refusal. No fresh execution of that native fixture was performed for this appendix.
- **Cause and correction:** GNU chmod behavior had been generalized to BSD chmod, which can omit the unnecessary syscall. The original admission is restored, and the invalid old-command-must-fail expectation is replaced by the measured no-op success.
- **Regression path:** `static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/NativeAppClonerReadOnlyBundleTests.swift`, methods `testActualAdmissionExecutesReadOnlyHelperWithNoOpPermissions` and `testActualAdmissionRefusesMissingAndNonExecutableHelpers`.

### 9795eab6c9feacfcf8179edf237059590f018939 — fix(macos): retire failed App Cloner bundle reservations

- **Bug:** a bundle destination reserved before `mktemp` or a later failing operation could remain as a broken `.app`; retries then selected suffixed names instead of reclaiming the failed reservation.
- **Proof:** the retained regression receipt records 21/29 on the old source with exit 1 and 29/29 on the candidate with exit 0. Both candidate file hashes match this historical commit. The receipt separately identifies Linux zsh probes and explicitly leaves native AppKit unrun; those probes must not be relabeled as Darwin validation.
- **Cause and correction:** reservation lifetime was not owned through failure. EXIT cleanup now tracks the reserved directory's identity, retires only that owned incomplete bundle, preserves replacements and completed bundles, keeps the primary error, and handles temporary cleanup independently.
- **Regression path:** `tools/test/test-app-cloner-generated-literals.cjs`.
- **Retained evidence:** `/workspace/scratch/appcloner-lifecycle-audit/ready-draft.json`, `first-worktree-ready.json` and `native-zsh-final.json`. The recorded scope excludes atomic compare-and-unlink protection against adversarial same-user renames and transactional rollback of previously published Dock/profile side effects.

### 98e1bf11ee406916caf7486b50e3fe2f38b04358 — test(macos): observe the visible App Cloner cancel button title

- **Bug:** the native observer read `cancelButtonTitle` through KVC; rejection by `NSOpenPanel` aborted observation before the locale assertions. A failed getter did not prove that the production setter failed.
- **Proof and limit:** the commit body and diff document that observation failure and replace it with observation of the visible control through public Accessibility title APIs. The English, French and old-French-prompt mutant assertions remain, together with owned timer and panel cancellation/retirement requirements. No separate historical old-code-red execution record is claimed here.
- **Cause and correction:** the test relied on an unsupported getter rather than the displayed button. It now observes the actual Cancel control while the source panel is modal. This is an observer correction; historical custom-title expectations are not asserted to be today's product contract.
- **Regression path:** `static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/AppClonerWizardLocaleTests.swift`, including `testActualEnglishPickerUsesTheSelectedCatalogue`, `testActualFrenchPickerPreservesItsSelectedCatalogue` and `testActualEnglishPickerRejectsTheOldFrenchPromptMutant`.

### efa02d82b135e1ceee625122e14521852bc2adb7 — fix(macos): admit executable App Cloner helpers without chmod

- **Withdrawn hypothesis:** this attempted to replace `chmod +x` with regular-file/executable admission on the premise that chmod must fail for an executable helper on a read-only or differently owned bundle. Its production change was later reverted by `5aeec2a7` and is not counted as a surviving product fix.
- **Evidence and limit:** retained physical Linux evidence shows an executable root-owned `0755` helper can run while GNU chmod returns `EPERM`. The original ready receipt explicitly left Darwin unrun. The later BSD no-op measurement disproved transferring that Linux result to Darwin; the original mutant expectation must not be reported as a valid Darwin old-code red.
- **Cause and final disposition:** the portability inference, rather than the measured Linux result itself, was wrong. The enduring contribution is native read-only-bundle coverage and the subsequent corrected oracle described above.
- **Historical regression path:** `static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/NativeAppClonerReadOnlyBundleTests.swift`; its initial `testActualAdmissionExecutesReadOnlyHelperAndRejectsOldMutation` expectation was replaced by the no-op-permission method in the revert.
- **Retained evidence:** `/workspace/scratch/cloner-readonly-owned-proof/proof.json` and `/workspace/scratch/cloner-readonly-fix/ready.json`, read together with the revert, not as current Darwin proof.

### Historical CI boundary

[Workflow run 40658634706](https://github.com/adrienm7/ergopti/actions/runs/40658634706) succeeded for historical merge head `74f683f5a6ad49a62e5dad8837b8375375a01d3c`, finishing on 28 October 2026 at **10:26:51 Paris**. Its receipt records 48 successful jobs and three intentional skipped lanes/jobs. Evidence: `/workspace/scratch/oct28-ci-merge/final-receipt.json`.

That result qualifies the historical merged baseline only. It does not qualify the subsequent batch, later dev merges, current source tree or currently running CI; no historical native-test count is carried forward as evidence for those sources. This appendix was assembled from Git objects and retained records without running tests, changing repository sources/index/refs, or modifying the main report.
