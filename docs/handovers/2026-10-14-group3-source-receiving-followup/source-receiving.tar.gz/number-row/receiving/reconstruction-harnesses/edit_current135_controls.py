from pathlib import Path
import hashlib
p=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');r='tools/diagnostics/number_row_native_causal.py';newsha=hashlib.sha256((p/'postimages'/r).read_bytes()).hexdigest();oldsha='d913505e2d3522d5023227b947f3c7896ba3ef4aeadfbd0c1a7042fa9686c148'
for name in ['prepare_number_row_native_causal.py','generate_number_row_source_composition.py','test_number_row_source_composition.py']:
 f='tools/diagnostics/'+name;s=(p/'preimages'/f).read_text();assert oldsha in s;s=s.replace(oldsha,newsha)
 if name=='test_number_row_source_composition.py':
  anchor='args, unittest_args = parser.parse_known_args()';assert s.count(anchor)==1;s=s.replace(anchor,'parser.add_argument("--current-build", action="store_true")\nparser.add_argument("--source-basis", type=Path)\n'+anchor)
  anchor='active_auxiliary_path = (\n    approval["approvals"][0]["path"] if "approvals" in approval else subject.AUXILIARY_PATH\n)';assert s.count(anchor)==1;s=s.replace(anchor,'if args.current_build:\n    if args.source_basis is None:\n        raise ValueError("explicit independently received source basis required")\n    active_auxiliary_path = approval["sources"][0]["path"]\nelse:\n    '+anchor.replace('\n','\n    ').rstrip())
  anchor='if __name__ == "__main__":\n    unittest.main(argv=[sys.argv[0], *unittest_args], verbosity=2)';assert s.count(anchor)==1;s=s.replace(anchor,Path('/tmp/current135_control_class.txt').read_text()+'if __name__ == "__main__":\n    if args.current_build:\n        result = unittest.TextTestRunner(verbosity=2).run(\n            unittest.defaultTestLoader.loadTestsFromTestCase(CurrentBuildControls)\n        )\n        raise SystemExit(0 if result.wasSuccessful() else 1)\n    del CurrentBuildControls\n    unittest.main(argv=[sys.argv[0], *unittest_args], verbosity=2)')
 (p/'postimages'/f).write_text(s)
print(newsha)
