# Refreshed Windows native stdout refusal

This packet receives manual run 38663542439 on exact CI ae6245f0a158290c600a3589d0e32db2273c971f, copied append-only from Dev d60ad231ae41c7391c1012c5feb9fc5723bbcca4. It includes the published seventeen-case receiver correction. The independent terminal receipt records complete paginated API jobs/annotations, source/tree joins, terminal counts and Release outcome.

Windows units fail `snapshot16 complete stdout differs`, comparing full native stdout with disk TAP minus BOM. This is distinct from the preceding source-pin refusal. Exact native output bytes and failing phase were not received; no warning cause is inferred. General Windows units and the two new wizard initializer cases remain UNRUN/unqualified. Preserve #Warn, original callbacks and all full-output/source/exit assertions. Native stderr, selection and TAP assertions after the refused comparison are unqualified.

All-OS run 38658948881, local portable suites, genuine GTK source sessions and Chromium are separate evidence in the sibling 2026-10-15 receiving packet. This follow-up does not establish installed wizard, physical-device or whole-group acceptance. Every Group 1 item remains partial. No production/test/workflow source is modified by this documentary packet.

Read receipts/folder-intent-windows-followup-root-handoff.md for the precise Root-owned receiving action. Historical active observations remain historical; the completed terminal receipt and status are authoritative. API metadata is not complete native logs or a native SDK fingerprint. Source files here are literal immutable Git bytes, never replacement expectations.
