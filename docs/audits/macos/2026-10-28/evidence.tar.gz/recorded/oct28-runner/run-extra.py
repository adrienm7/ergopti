from pathlib import Path
import os,subprocess,json,concurrent.futures,time
w=Path('/workspace/ergopti-macos-native-validation');d=Path('/workspace/scratch/oct28-runner');e=dict(os.environ);e.update(USER='agent',LOGNAME='agent');e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu'
for key in ['TMPDIR','XDG_RUNTIME_DIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_STATE_HOME']:e[key]=str(d/key.lower())
cmds=[('plan',['node','tools/test/verify-change.cjs','--plan']),('false-green',['node','tools/test/find-false-greens.cjs']),('strict',['npm','run','-s','lint:conventions:strict']),('source-lua',['node','tools/test/test-no-pinned-source-reads-lua.cjs']),('source-ahk',['node','tools/test/test-no-pinned-source-reads.cjs']),('ahk-locals',['npm','run','-s','test:ahk-local-same-as-global']),('sealed-source',['node','tools/test/test-windows-updater-original-source.cjs']),('linux-contract',['node','tools/test/run-linux-lua.cjs','tests/run.lua','--module=infra','--only=declares every segment it emits'])]
def run(spec):
 name,cmd=spec;start=time.monotonic()
 with (d/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT)
 x={'name':name,'command':cmd,'actual_exit':r.returncode,'seconds':time.monotonic()-start};print(json.dumps(x),flush=True);return x
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:r=list(pool.map(run,cmds))
(d/'extra-receipt.json').write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(any(x['actual_exit'] for x in r))
