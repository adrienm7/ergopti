Use the saved pinned environment and a writable private packet directory. The physical reproduction intentionally retains its newly owned tree for review; remove only those explicitly created paths after review. It copies actual tracked source inputs from /workspace/ergopti and records their hashes, verifies their canonical byte fence before/after each child, commits only the private tree, and runs the original-comparison red, focused candidate green, and full physical candidate 32 serially.

```sh
. /workspace/ergopti-cloud/activate.sh
python -I -B receive.py
node prove-source.cjs
```

The receiver requires Node 22.22.2 and the repository-installed acorn dependency. Run the pinned repository Prettier check with cwd /workspace/ergopti so its Svelte plugin resolves. freeze.py is a one-time archive author, not the reproduction entrypoint. author.py records the initial unformatted authoring; the exact final source candidates and final forward/inverse patches are authoritative.
