The packet requires pinned Node22.22.2 and Linux PowerShell7.4.11. Both commands operate only on packet source/model state, not a real Windows checkout or compiler. Run the finite Node reader first, then the PowerShell parser/import check. Set XDG_DATA_HOME, XDG_CONFIG_HOME and XDG_CACHE_HOME to private packet subdirectories for PowerShell.

    node ./receive_pure.cjs
    /workspace/ergopti-cloud/powershell-7.4.11/runtime/pwsh -NoLogo -NoProfile -NonInteractive -File ./receive_ps_portable.ps1 -Packet "$PWD"

Expected software counts are21 Node and4 PowerShell, with zero failures/errors/skips. The exact original function-only counterfactual remains active in each protocol refusal. This does not reproduce genuine original676, official3262 build artifacts or native original23. Do not run candidate CLI wrappers without fresh sealed current inputs/module pins and ownership; they are incomplete Source-only integration candidates.
