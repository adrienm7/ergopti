; Outside-only actual public config restore controls for the held-copy proposal.
_R7HP_Snapshot(Path) {
	File := FileOpen(Path, "r")
	try return FSHandleSnapshot(File.Handle)
	finally File.Close()
}
_R7HP_Restore(Mode) {
	Root := A_Temp . "\ergopti_r7_config_proposal_" . Mode . "_" . PLC_CurrentProcessId() . "_" . A_TickCount
	Cfg := Root . "\cfg", Target := Cfg . "\config.toml", Stage := Target . ".ergopti-restore.tmp"
	Copier := FSCopyReplaceAtomic, Publisher := _FSCopyPublish, NativeIo := _FSCopyNativeIo
	Captured := 0, Lock := -1, Writer := -1, BusyOwner := 0
	ObservedPublish := false, SourceShort := false, WriteShort := false
	SourceBytes := "original`n", CurrentBytes := "current`n", ForeignBytes := "foreign stage bytes`n"
	if Mode == "partial" {
		Loop 10000
			SourceBytes .= "raw " . A_Index . " " . Chr(0) . " payload`n"
	}
	if Mode == "empty"
		SourceBytes := ""
	AssertFalse(FileReadActivityBusy(), "the candidate fixture cannot adopt existing reader debt")
	AssertFalse(ConfigWriteLeaseBusy(), "the candidate fixture cannot retire an existing writer")
	for Function in [Copier, Publisher, NativeIo]
		AssertFalse(Function.HasOwnProp("Call"), "a foreign native observer cannot be detached")
	Capture(Self, Source, Destination, &Receipt := 0) {
		Copier.DeleteProp("Call")
		Result := Copier.Call(Source, Destination, &Receipt)
		Captured := Receipt
		return Result
	}
	ObservePublish(Self, Handle, Destination, &NativeError := 0) {
		Publisher.DeleteProp("Call")
		AssertEqual(0, A_IsCritical, "native publication must not run under Critical")
		AssertTrue(FileReadActivityBusy(Stage))
		AssertTrue(FileReadActivityBusy(Target), "the destination admission alias must cover the renamed handle")
		DeniedWriter := _ConfigWriteLeaseTryAcquire(Target)
		AssertFalse(IsObject(DeniedWriter), "the real domain restore lease must deny reentrant target writers")
		Before := FSHandleSnapshot(Handle)
		AssertTrue(Before["ok"])
		if Mode == "stage-denial" {
			Moved := DllCall("kernel32\MoveFileExW", "Str", Stage, "Str", Root . "\moved.tmp", "UInt", 0, "Int")
			MoveError := A_LastError
			AssertFalse(Moved, "the actual foreign stage rename must be denied")
			AssertTrue(MoveError != 0)
			AssertFalse(DllCall("kernel32\DeleteFileW", "Str", Stage, "Int"), "the actual foreign stage delete must be denied")
			ForeignWriter := DllCall("kernel32\CreateFileW", "Str", Stage, "UInt", 0x40000000,
				"UInt", 7, "Ptr", 0, "UInt", 3, "UInt", 0x80, "Ptr", 0, "Ptr")
			WriterError := A_LastError
			if ForeignWriter != -1
				DllCall("kernel32\CloseHandle", "Ptr", ForeignWriter, "Int")
			AssertEqual(-1, ForeignWriter, "the actual foreign stage writer must be denied")
			AssertEqual(32, WriterError)
			_TestPrint("# held-copy stage_move_error=" . MoveError . " stage_writer_error=" . WriterError)
		}
		Published := Publisher.Call(Handle, Destination, &NativeError)
		After := FSHandleSnapshot(Handle)
		for Key in ["volume", "index_high", "index_low", "size"]
			AssertEqual(Before[Key], After[Key], "publication must preserve exact held stage " . Key)
		ObservedPublish := true
		_TestPrint("# held-copy native_publish=" . Published . " error=" . NativeError . " stage_volume=" . After["volume"]
			. " stage_high=" . After["index_high"] . " stage_low=" . After["index_low"])
		return Published
	}
	ObserveIo(Self, Write, Handle, Address, Count, &Transferred, &NativeError := 0) {
		NativeIo.DeleteProp("Call")
		AssertEqual(0, A_IsCritical, "native copy I/O must remain interruptible")
		Limit := ((!Write && !SourceShort) || (Write && !WriteShort)) ? Min(4093, Count) : Count
		try {
			Completed := NativeIo.Call(Write, Handle, Address, Limit, &Transferred, &NativeError)
			if Completed && Transferred > 0 && Transferred < Count {
				if Write
					WriteShort := true
				else
					SourceShort := true
			}
			return Completed
		} finally {
			if !SourceShort || !WriteShort
				NativeIo.DefineProp("Call", {Call: ObserveIo})
		}
	}
	try {
		_RIT_WriteFile(Target, SourceBytes)
		Rules := ConfigBackup_Rules()
		Clock := () => Map("stamp", "20261027-063000", "iso", "2026-10-27T06:30:00Z")
		Later := () => Map("stamp", "20261027-063100", "iso", "2026-10-27T06:31:00Z")
		Backup := ConfigBackup_Create(Cfg, "pre_install", "", "", Rules, Clock)
		Source := Backup["path"] . "\config\config.toml"
		AssertTrue(FSWriteDurable(Target, CurrentBytes))
		if Mode == "foreign-stage" {
			AssertTrue(FSWriteCreateDurable(Stage, ForeignBytes))
			ForeignBefore := _R7HP_Snapshot(Stage)
		}
		if Mode == "locked-destination" {
			Lock := DllCall("kernel32\CreateFileW", "Str", Target, "UInt", 0x80000000,
				"UInt", 1, "Ptr", 0, "UInt", 3, "UInt", 0x80, "Ptr", 0, "Ptr")
			AssertTrue(Lock != -1)
		}
		if Mode == "active-source-writer" {
			Writer := DllCall("kernel32\CreateFileW", "Str", Source, "UInt", 0x40000000,
				"UInt", 1, "Ptr", 0, "UInt", 3, "UInt", 0x80, "Ptr", 0, "Ptr")
			AssertTrue(Writer != -1)
		}
		if Mode == "busy-target" {
			BusyOwner := _ConfigWriteLeaseTryAcquire(Target)
			AssertTrue(IsObject(BusyOwner))
		} else
			Copier.DefineProp("Call", {Call: Capture})
		if Mode == "stage-denial" || Mode == "locked-destination"
			Publisher.DefineProp("Call", {Call: ObservePublish})
		if Mode == "partial"
			NativeIo.DefineProp("Call", {Call: ObserveIo})
		Result := ConfigBackup_Restore(Cfg, Backup["id"], Rules, Later)
		if Mode == "foreign-stage" || Mode == "locked-destination" || Mode == "active-source-writer" || Mode == "busy-target" {
			AssertFalse(Result["ok"])
			AssertEqual("write", Result["reason"])
			AssertEqual(CurrentBytes, FSReadUtf8Exact(Target), "refusal must preserve the existing live destination")
			if Mode == "busy-target" {
				AssertTrue(_ConfigWriteLeaseOwns(BusyOwner, Target), "the refusal cannot retire the original writer")
				AssertEqual(0, Captured, "busy admission must precede the native copy")
			} else {
				AssertTrue(Captured is Map)
				_TestPrint("# held-copy refusal mode=" . Mode . " phase=" . Captured["phase"] . " error=" . Captured["native_error"])
			}
			if Mode == "foreign-stage" {
				AssertEqual(ForeignBytes, FSReadUtf8Exact(Stage))
				After := _R7HP_Snapshot(Stage)
				for Key in ["volume", "index_high", "index_low"]
					AssertEqual(ForeignBefore[Key], After[Key])
				AssertEqual("create_stage", Captured["phase"])
			}
			if Mode == "locked-destination" {
				AssertTrue(ObservedPublish)
				AssertEqual("refused", Captured["publication"])
				AssertEqual(SourceBytes, FSReadUtf8Exact(Stage), "native publication refusal retains the verified owned stage")
			}
			if Mode == "active-source-writer" {
				AssertEqual("pin_source", Captured["phase"])
				AssertEqual(32, Captured["native_error"])
				AssertFalse(FileExist(Stage))
			}
		} else {
			AssertTrue(Result["ok"], "the actual public restore must publish the verified source")
			AssertEqual(SourceBytes, FSReadUtf8Exact(Target))
			AssertTrue(Captured["ok"])
			AssertEqual("completed", Captured["publication"])
			AssertEqual(0, Captured["close_errors"].Count)
			PublishedIdentity := _R7HP_Snapshot(Target)
			for Key in ["volume", "index_high", "index_low"]
				AssertEqual(Captured["stage_identity"][Key], PublishedIdentity[Key], "live bytes must retain the created stage identity")
			AssertFalse(FileExist(Stage))
			if Mode == "stage-denial"
				AssertTrue(ObservedPublish)
			if Mode == "partial"
				AssertTrue(SourceShort && WriteShort, "actual positive partial reads and writes must both be consumed")
		}
		AssertFalse(FileReadActivityBusy(), "every ordinary native close must retire its exact reader metadata")
		if Mode != "busy-target"
			AssertFalse(ConfigWriteLeaseBusy(), "the public restore must release its exact domain writer")
	} finally {
		for Function in [Copier, Publisher, NativeIo]
			if Function.HasOwnProp("Call")
				Function.DeleteProp("Call")
		for Handle in [Writer, Lock]
			if Handle != -1
				DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int")
		if BusyOwner is Object
			_ConfigWriteLeaseRelease(BusyOwner)
		if DirExist(Root)
			DirDelete(Root, true)
	}
}
for Mode in ["ordinary", "empty", "partial", "stage-denial", "foreign-stage", "locked-destination", "active-source-writer", "busy-target"]
	Test("Config held-copy proposal: actual public restore " . Mode . " (held-config-copy-native)", _R7HP_Restore.Bind(Mode))
