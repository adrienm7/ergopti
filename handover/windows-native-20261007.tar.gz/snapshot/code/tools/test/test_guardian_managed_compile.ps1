# tools/test/test_guardian_managed_compile.ps1
<#
==============================================================================
MODULE: Native Managed Guardian Compiler Controls
DESCRIPTION:
Extracts the actual ManagedCompile branch; the typed recording relay forwards
to the genuine Framework64 CodeDOM compiler for private source bytes only.
No guardian, source producer, compiled type method or driver is executed.
==============================================================================
#>
[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$Repository,
    [Parameter(Mandatory = $true)][string]$Namespace)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSEdition -cne 'Desktop' -or
    -not [Environment]::Is64BitProcess) { throw 'Native managed controls require x64 Windows PowerShell5.' }
$builder = [IO.Path]::Combine($Repository, 'tools', 'build', 'build_windows_ollama_guardian.ps1')
$tokens = $null
$parseErrors = $null
$tree = [Management.Automation.Language.Parser]::ParseFile($builder, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw 'The actual builder has parse errors.' }
$branches = @($tree.FindAll({ param($node)
    $node -is [Management.Automation.Language.IfStatementAst] -and $node.Clauses.Count -eq 1 -and
    $node.Clauses[0].Item1.Extent.Text -ceq '$ManagedCompile'
}, $true))
if ($branches.Count -ne 1) { throw 'The actual managed branch must be unique and nonempty.' }
$branchText = $branches[0].Clauses[0].Item2.Extent.Text
if (-not $branchText.StartsWith('{') -or -not $branchText.EndsWith('}')) {
    throw 'The actual managed branch has no complete source body.'
}
$script:GMC_Branch = [scriptblock]::Create($branchText.Substring(1, $branchText.Length - 2))
$compilerDefinitions = @($tree.FindAll({ param($node)
    $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Invoke-GuardianManagedCompiler'
}, $true))
if ($compilerDefinitions.Count -ne 1) { throw 'The genuine native compiler owner must be unique.' }
$compilerBody = $compilerDefinitions[0].Body.Extent.Text
$script:GMC_Compiler = [scriptblock]::Create($compilerBody.Substring(1, $compilerBody.Length - 2))
$script:GMC_Observed = @()

# The explicit recording relay executes the actual native provider body.
# It never reads CompilerResults.CompiledAssembly or generates a substitute DLL.
function Invoke-GuardianManagedCompiler {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][System.CodeDom.Compiler.CompilerParameters]$Parameters,
        [Parameter(Mandatory = $true)][string]$Source)
    if ($Parameters.CompilerOptions -cne '/platform:x64 /optimize+ /warnaserror' -or
        -not $Parameters.TreatWarningsAsErrors -or $Parameters.GenerateExecutable -or
        $Parameters.GenerateInMemory -or [string]::IsNullOrEmpty($Parameters.OutputAssembly)) {
        throw 'The real managed compile transport dropped its exact native options.'
    }
    $result = & $script:GMC_Compiler -Parameters $Parameters -Source $Source
    $script:GMC_Observed += @{ options = $Parameters.CompilerOptions;
        warnings_fatal = $Parameters.TreatWarningsAsErrors; output = $Parameters.OutputAssembly;
        exit_code = $result.NativeCompilerReturnValue; errors = @($result.Errors | ForEach-Object { $_.ErrorNumber }) }
    return $result
}
function Require-GMC([bool]$Value, [string]$Reason) {
    if (-not $Value) { throw $Reason }
}
function Invoke-GMC([string]$CaseName, [string]$Code) {
    $sourceRoot = [IO.Path]::Combine($Namespace, 'native-managed-' + $CaseName)
    Require-GMC (-not [IO.Directory]::Exists($sourceRoot)) 'Native case namespace already exists.'
    [void][IO.Directory]::CreateDirectory($sourceRoot)
    [IO.File]::WriteAllText([IO.Path]::Combine($sourceRoot, 'SourceProducerNative.cs'), $Code, [Text.UTF8Encoding]::new($false))
    $ManagedCompile = [IO.Path]::Combine($sourceRoot, 'owned-' + $CaseName + '.dll')
    & $script:GMC_Branch
    return $ManagedCompile
}
$controls = @(
    @{ name = 'actual managed branch publishes an amd64 CLR library with exact compiler options'; body = {
        $image = Invoke-GMC 'positive' 'public static class OwnedManagedPositive { public static int FixtureValue() { return new System.ComponentModel.Win32Exception(5).NativeErrorCode; } }'
        Require-GMC ($script:GMC_Observed.Count -eq 1) 'The real native compiler must be forwarded exactly once.'
        $bytes = [IO.File]::ReadAllBytes($image)
        Require-GMC ($bytes.Length -ge 512 -and [BitConverter]::ToUInt16($bytes, 0) -eq 0x5a4d) 'The native compiler did not publish a real PE image.'
        $pe = [BitConverter]::ToUInt32($bytes, 60)
        Require-GMC ($pe -le $bytes.Length - 256 -and [BitConverter]::ToUInt32($bytes, $pe) -eq 0x4550) 'The real PE header is incomplete.'
        Require-GMC ([BitConverter]::ToUInt16($bytes, $pe + 4) -eq 0x8664) 'The actual managed compiler lost amd64.'
        Require-GMC (([BitConverter]::ToUInt16($bytes, $pe + 22) -band 0x2000) -ne 0) 'The actual output is not a DLL.'
        Require-GMC ([BitConverter]::ToUInt16($bytes, $pe + 24) -eq 0x20b) 'The actual amd64 image is not PE32+.'
        Require-GMC ([BitConverter]::ToUInt32($bytes, $pe + 24 + 112 + 14 * 8) -gt 0) 'The actual output lacks a CLR directory.'
        $identity = [Reflection.AssemblyName]::GetAssemblyName($image)
        Require-GMC ($identity.ProcessorArchitecture.ToString() -ceq 'Amd64') 'The actual CLR assembly identity is not amd64.'
        Require-GMC (@([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -ceq $identity.Name }).Count -eq 0) 'The native compiler may not load the produced assembly.'
        Require-GMC ($script:GMC_Observed[0].exit_code -eq 0 -and $script:GMC_Observed[0].errors.Count -eq 0) 'The genuine compiler must report a clean native result.'
    } },
    @{ name = 'actual native warning is refused without a published DLL'; body = {
        $caught = $null
        try { Invoke-GMC 'warning' "#warning OWNED_COMPILER_WARNING`npublic static class OwnedManagedWarning {}" } catch { $caught = $_ }
        Require-GMC ($null -ne $caught) 'The actual native warning must remain fatal.'
        Require-GMC ($script:GMC_Observed.Count -eq 2) 'The warning must reach the genuine native compiler.'
        Require-GMC ($script:GMC_Observed[1].exit_code -ne 0 -and $script:GMC_Observed[1].errors -contains 'CS1030') 'The actual CSharp warning must cause the native refusal.'
        Require-GMC (-not [IO.File]::Exists([IO.Path]::Combine($Namespace, 'native-managed-warning', 'owned-warning.dll'))) 'A warning cannot publish a successful DLL.'
    } },
    @{ name = 'actual native syntax error remains failed without a published DLL'; body = {
        $caught = $null
        try { Invoke-GMC 'syntax' 'public static class OwnedManagedSyntax { this is not CSharp; }' } catch { $caught = $_ }
        Require-GMC ($null -ne $caught) 'The actual native syntax error must remain failed.'
        Require-GMC ($script:GMC_Observed.Count -eq 3) 'The syntax error must reach the genuine native compiler.'
        Require-GMC ($script:GMC_Observed[2].exit_code -ne 0 -and $script:GMC_Observed[2].errors.Count -gt 0) 'The real syntax diagnostics must cause the native refusal.'
        Require-GMC (-not [IO.File]::Exists([IO.Path]::Combine($Namespace, 'native-managed-syntax', 'owned-syntax.dll'))) 'A syntax error cannot publish a DLL.'
    } }
)
[Console]::Out.WriteLine('1..3')
for ($index = 0; $index -lt $controls.Count; ++$index) {
    try {
        & ($controls[$index].body)
        [Console]::Out.WriteLine('ok ' + ($index + 1) + ' - ' + $controls[$index].name)
    } catch {
        [Console]::Out.WriteLine('not ok ' + ($index + 1) + ' - ' + $controls[$index].name)
        [Console]::Error.WriteLine('The actual native managed compiler control refused.')
        exit 1
    }
}
exit 0
