const { runnerPrelude, sharedRunnerSource, nativeSourceClosure } = require('../lib/ahk-runner-source.cjs');
const readRunnerImage = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const nativeTests = 'static/ergopti_plus/windows/tests/';
const nativeIncludes = [
	'runner_prelude.ahk',
	'../infra/tick_count.ahk',
	'../ui/console_window.ahk',
	'../infra/logger.ahk',
	'runner_log_directories.ahk',
	'../infra/toml/toml_helpers.ahk',
	'../infra/key_combinations.ahk',
	'../infra/toml/toml_loader.ahk',
	'../platform/remap/tap_hold_loader.ahk',
	'../platform/remap/tap_hold_writer.ahk',
	'../infra/json.ahk',
	'../adapters/text_sender.ahk',
	'../adapters/key_state.ahk',
	'../adapters/shell_runner.ahk',
	'unit/test_console_window.ahk',
	'unit/test_key_combinations.ahk',
	'../platform/remap/constants.ahk',
	'../platform/remap/altgr_criteria.ahk',
	'runner_completion.ahk'
];

/** The sparse entry retains genuine sources and every original shared admission/terminal owner. */
function checkNativeSources(read) {
	const prelude = runnerPrelude(read, 'run_native_desktop.ahk');
	assert.equal(prelude, runnerPrelude(read, 'run_all.ahk'));
	const code = stripComments(prelude, '.ahk');
	assert.match(code, /^#Requires Autohotkey v2\.0\+$/m);
	assert.equal((code.match(/^#Warn All, StdOut$/gm) || []).length, 1);
	assert.equal((code.match(/^#Warn VarUnset, Off$/gm) || []).length, 1);
	assert.match(code, /^SetWorkingDir\(A_ScriptDir\)$/m);
	assert.ok(code.indexOf('_riArgIndex := 1') < code.indexOf('#Include test_framework.ahk'));
	assert.ok(code.indexOf('#Include test_framework.ahk') < code.indexOf('_TestResultsBeginRun()'));
	assert.ok(code.indexOf('_TestResultsBeginRun()') < code.indexOf('#Include ../infra/app_state.ahk'));
	assert.equal((code.match(/^_TestResultsBeginRun\(\)$/gm) || []).length, 1);
	assert.match(code, /^OnError\(_FatalErrorHandler\)$/m);
	const native = stripComments(read(nativeTests + 'run_native_desktop.ahk'), '.ahk');
	assert.deepEqual([...native.matchAll(/^#Include (.+)$/gm)].map((m) => m[1]), nativeIncludes);
	assert.equal((native.match(/^InstallSendNoOps\(\)$/gm) || []).length, 1);
	assert.ok(native.indexOf('#Include ../adapters/text_sender.ahk') < native.indexOf('InstallSendNoOps()'));
	assert.ok(native.indexOf('InstallSendNoOps()') < native.indexOf('#Include unit/test_console_window.ahk'));
	assert.equal((native.match(/^TestQualificationRegisterParser\(JsonParse\)$/gm) || []).length, 1);
	assert.ok(native.indexOf('#Include ../infra/json.ahk') < native.indexOf('TestQualificationRegisterParser(JsonParse)'));
	assert.doesNotMatch(native, /^(?!#Include\b)[ \t]*(?:Test\(|#Warn|#Requires|#SingleInstance|SetWorkingDir\(|global\b|RunTests\()/m);
	const complete = stripComments(read(nativeTests + 'runner_completion.ahk'), '.ahk');
	assert.match(complete, /^global _SUITE_STARTUP_BUDGET_MS := 120000$/m);
	assert.match(complete, /^global _SUITE_PER_TEST_BUDGET_MS := 200$/m);
	assert.match(complete, /^global _SUITE_MAX_TIMEOUT_MS := 1320000$/m);
	assert.match(complete, /^global _SUITE_TIMEOUT_MS := _SuiteTimeoutForCount\(TEST_REGISTRY\.Length\)$/m);
	assert.match(complete, /_WatchdogFire\(\) \{[\s\S]*?_CopyTestResultsForCi\(\)[\s\S]*?ExitApp\(2\)/);
	assert.match(complete, /^SetTimer\(_WatchdogFire, -_SUITE_TIMEOUT_MS\)$/m);
	assert.equal((complete.match(/^RunTests\(\)$/gm) || []).length, 1);
	assert.ok(complete.indexOf('SetTimer(_WatchdogFire') < complete.indexOf('\nRunTests()'));
	const logs = stripComments(read(nativeTests + 'runner_log_directories.ahk'), '.ahk').trim();
	assert.equal(logs, 'global _LogsDir := A_Temp . "\\ergopti_test_logs\\ergopti_plus\\"\nglobal _DefaultLogsDir := _LogsDir');
	for (const entry of ['run_all.ahk', 'run_native_desktop.ahk']) {
		const expanded = stripComments(sharedRunnerSource(read, entry), '.ahk');
		assert.equal((expanded.match(/^#Warn All, StdOut$/gm) || []).length, 1);
		assert.doesNotMatch(expanded, /^#Warn\s+(?:All|LocalSameAsGlobal),\s*(?:Off|MsgBox|OutputDebug)$/im);
	}
	const graph = nativeSourceClosure(read);
	assert.equal(graph.size, 32, 'the native runner owns only its reviewed authored dependency graph');
	for (const file of ['unit/test_console_window.ahk', 'unit/test_key_combinations.ahk'])
		assert.ok(graph.has(nativeTests + file), 'each exact original case file must be compiled');
	assert.ok(graph.has('static/ergopti_plus/windows/adapters/editor_replace.ahk'));
	assert.ok(graph.has('static/ergopti_plus/windows/infra/toml/toml_document.ahk'));
}

checkNativeSources(readRunnerImage);
let nativeSourceRefusals = 0;
for (const [file, before, after] of [
	['run_native_desktop.ahk', '#Include runner_prelude.ahk', '#Include unrelated_prelude.ahk'],
	['run_native_desktop.ahk', '#Include runner_prelude.ahk', 'SetWorkingDir(A_Temp)\n#Include runner_prelude.ahk'],
	['run_all.ahk', '#Include runner_prelude.ahk', '#Include runner_prelude.ahk\n#Include runner_prelude.ahk'],
	['runner_prelude.ahk', '#Warn All, StdOut', '#Warn All, Off'],
	['runner_prelude.ahk', '_TestResultsBeginRun()\n', ''],
	['run_native_desktop.ahk', '#Include unit/test_console_window.ahk', '#Include unit/test_key_combinations.ahk'],
	['run_native_desktop.ahk', 'InstallSendNoOps()', ''],
	['run_native_desktop.ahk', 'TestQualificationRegisterParser(JsonParse)', ''],
	['runner_completion.ahk', '_CopyTestResultsForCi()', '_SuiteTimeoutForCount(0)'],
	['runner_completion.ahk', 'ExitApp(2)', 'ExitApp(0)'],
	['runner_completion.ahk', 'RunTests()', ''],
	['runner_completion.ahk', '1320000', '1500000'],
	['runner_log_directories.ahk', 'A_Temp', 'A_ScriptDir'],
	['run_native_desktop.ahk', '#Include runner_completion.ahk', '#Include missing_completion.ahk']
]) {
	const full = nativeTests + file;
	const original = readRunnerImage(full);
	const changed = original.replace(before, after);
	assert.notEqual(changed, original, 'the source mutation must change its actual owner');
	assert.throws(() => checkNativeSources((target) => target === full ? changed : readRunnerImage(target)));
	nativeSourceRefusals += 1;
}
for (const file of ['runner_prelude.ahk', 'runner_completion.ahk', 'runner_log_directories.ahk', '../adapters/console_window.ahk']) {
	const full = path.posix.normalize(nativeTests + file);
	assert.throws(() => checkNativeSources((target) => {
		if (target === full) throw new Error('independently omitted native source');
		return readRunnerImage(target);
	}), /unresolved|omitted/);
	nativeSourceRefusals += 1;
}
console.log(`Native runner source ownership PASS: ${nativeSourceRefusals} independent source refusals; native execution remains unrun here.`);
