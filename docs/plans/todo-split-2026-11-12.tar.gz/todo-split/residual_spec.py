"""Judgement of 2026-11-12: which [x] items leave work behind. Index = keys.txt order on dev 20b9ef34e."""
LG = '## Layout generator from an Ergopti TOML source (maintainer request, 2026-11-06)'
WIN = "## Remaining code work > ### Windows (the PC agent's)"
MAC = '## Remaining code work > ### macOS'
ALL = '## Remaining code work > ### All drivers'
LPERF = '## Remaining code work > ### Linux performance (2026-11-11, branch `claude/ergopti-todo-linux-perf`)'
DEC = '## Maintainer decisions pending'
TW = ('TODO-tests-windows.md', '## To confirm on the Windows PC')
T = 'TODO.md'
R = {
 5: [(T, LG, "- [ ] **Sign the generated Windows layout DLLs.** The four DLLs, the uninstaller and `<dll>-setup.exe` (SHA-256,\n      RFC 3161 timestamp) once SignPath or the release PFX is on, as `docs/design/layout-windows-dll.md` « Signing » says.")],
 8: [(T, LG, "- [ ] **Keyboard types JIS and ABNT.** Deferred on 2026-11-11: their keys (Yen, Ro, Henkan, Muhenkan, Kana, keypad\n      comma) would enter `physical_keys.json`, which the Windows driver parses at boot; add them once that cost is measured.")],
 9: [(T, LG, "- [ ] **Retire the composer and the navigation layer editor.** The Windows host takes a source since 2026-11-12: delete\n      the composer section (`layout_composer/composer_page.js` and its markup), then retire `_shared/ui/layer_editor` and\n      its three hosts once every driver reads the source's `nav` layer.")],
 17: [(T, '## Dead-key composition parity follow-up', "- [ ] **Pause and a pending dead key (macOS, Linux).** A pending composition is native state there and Ergopti's pause\n      does not cancel it (both Windows engines do); decide whether the pause must clear it, and how.")],
 20: [(TW[0], TW[1], "- [ ] Metrics ledgers: the Windows reader replays a Linux `by_device/` ledger (never run, no AutoHotkey in the cloud\n      containers).")],
 46: [(T, DEC, "- [ ] **One-shot Shift unlimited timeout (OSM-002).** The macOS menu can persist an unlimited or zero timeout; decide\n      whether an unlimited one-shot timeout is allowed on every OS or refused at entry.")],
 71: [(T, WIN, "- [ ] **Immediate-Backspace restoration after Notepad-paste and terminal expansions.** Those owners emit after the\n      keystroke and keep no undo record, so a Backspace right after their expansion does not type the trigger back.")],
 114: [(T, MAC, "- [ ] **Owned runtime rebuild (macOS release step).** The next runtime build ships the MRT-004 « Réparer le service »\n      helper role and the helper's one-hash report rule (`OwnedVirtualHIDDaemonReportStageOwner.admitImage`); rebuild it\n      and update its manifest pin.")],
 178: [(T, MAC, "- [ ] **`events_typing.rich_text` in clear (AHK-005 / WM-002 left).** With metrics encryption on, Windows and Linux\n      store it empty; macOS still writes the typed text to SQLite.")],
 197: [(T, WIN, "- [ ] **LogsDirPath under the old folder name.** `infra/legacy_folder_migration.ahk` renames a custom logs folder named\n      like the old app folder to `Ergopti`, as macOS and Linux do since 2026-11-11 (shared `renamed` rule).")],
 222: [(T, WIN, "- [ ] **Hotstring header rows outlive their expiry** in the « both » stack of `llm.trigger.while_hotstring_tooltip`\n      until the next render."),
       (TW[0], TW[1], "- [ ] AI tooltip « both » mode: with a hotstring tooltip showing, the prediction draws under its rows in one stack and\n      the rows leave on their own expiry.")],
 223: [(T, ALL, "- [ ] **Modifier-chord action labels from the key name table.** The action pickers still show raw or French chords\n      (« Cmd + Option + Shift + Enter ») on every driver; the tests that pin this label family change with it.")],
 263: [(TW[0], TW[1], "- [ ] Layout editor host (2026-11-12): the real UAC install of a source's DLLs, typing, switching and the uninstall\n      (Settings > Apps and « Remove »), in source and compiled mode.")],
 281: [(T, LPERF, "- [ ] Keystats boot: `open_db`'s own spawns (mkdir, schema checks), device registration and the open-walk read still\n      cost about 30 ms of sqlite3 processes.")],
 290: [(TW[0], TW[1], "- [ ] Metrics export and purge on Windows (`KL_RunMetricsMaintenance`): only source contracts check that path.")],
 291: [(T, WIN, "- [ ] **Restored API entry without a usable key.** DPAPI keeps the key inside the backup: check whether a restore under\n      another user or machine yields an unusable key, and give it the « API key… » re-enter row as macOS and Linux do.")],
}
# Added on every run, tied to no item.
ALWAYS = [
 (T, DEC, "- [ ] **Review the coordinator's decisions of 2026-11-11 and 2026-11-12.** The items closed with « decided by the\n      coordinator …, to review by the maintainer » are in `git show {BASE}:TODO.md` (search « decided by the coordinator »)."),
]
