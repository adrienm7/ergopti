"""Exact bounded source closure for original and paired 52-case cohorts."""
from pathlib import Path
import hashlib
import json
import stat

PACKET = Path(__file__).parent
ROOT = Path('/workspace/ergopti')
ENROLLMENT = Path('/tmp/group6-http-debug-inverse-enrollment-ahpgiiv8')
DIAGNOSTIC = Path('/tmp/group6-http-debug-certificate-code-4e9-tb831oxi')
TEST = 'tools/test/macos_native_http_receiving_facts_test.py'
WORKER = 'static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/ManagedHTTPWorker.swift'
SOURCES = [TEST, WORKER,
 'static/ergopti_plus/macos/tests/support/native_http_fixture_main.swift',
 'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py',
 'static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py']
OWNERS = ['tools/test/run-linux-managed-http-native.cjs',
 'tools/test/run-linux-managed-http-phase.py',
 'tools/build/stage-linux-network-runtime.py', 'tools/lib/git_bash.py']

def fact(path):
 s = path.lstat()
 if not stat.S_ISREG(s.st_mode):
  raise RuntimeError('Regular exact input required')
 return {'path':str(path), 'dev':str(s.st_dev), 'ino':str(s.st_ino), 'uid':str(s.st_uid),
         'mode':str(s.st_mode), 'bytes':s.st_size, 'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def copy(path, raw):
 path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 with path.open('xb') as output:
  output.write(raw)
 path.chmod(0o600)
 return fact(path)

previous = json.loads((ENROLLMENT/'RECEIVING-SOURCE-BINDINGS.json').read_text())
for name in SOURCES + OWNERS:
 old = next(row for row in previous['originals'] if row['path']==str(ROOT/name))
 if fact(ROOT/name) != old:
  raise RuntimeError('Original input changed since independently reviewed packet')
tool_paths = ['/workspace/ergopti-subreaper.py', '/workspace/.tools/node/node_modules/node/bin/node',
 str(Path('/workspace/.tools/python/bin/python3').resolve()), '/usr/bin/openssl',
 '/usr/lib/x86_64-linux-gnu/libssl.so.3', '/usr/lib/x86_64-linux-gnu/libcrypto.so.3']
originals = [fact(ROOT/name) for name in SOURCES+OWNERS+['tools/test/test-managed-ollama-protocol.cjs']]
originals += [fact(Path(name)) for name in tool_paths]
old_test=(ROOT/TEST).read_bytes()
new_test=(ENROLLMENT/'payload'/TEST).read_bytes()
old_worker=(ROOT/WORKER).read_bytes()
new_worker=(DIAGNOSTIC/'payload'/WORKER).read_bytes()
assert hashlib.sha256(old_test).hexdigest()=='fdcd83823d814455bf2dd148dcd2d3604a12c97ac7b6252f4e6efc95b02b81fc'
assert hashlib.sha256(new_test).hexdigest()=='7122e745d7ca4ad815ab9107dfaa4f59299934c761502c7d166f9b23ed7874c7'
assert hashlib.sha256(old_worker).hexdigest()=='bbd2916577ea77b338d627f541d05228d342714331fd8ccaf621d1bf32b733f4'
assert hashlib.sha256(new_worker).hexdigest()=='761b1a636bfc69d987545a30502db5a7c549e76c9b674630fc27bb4b157febc7'
assert [x for x in old_test.splitlines() if b'self.assert' in x]==[x for x in new_test.splitlines() if b'self.assert' in x]
normal=(ROOT/'tools/test/test-managed-ollama-protocol.cjs').read_bytes()
assert b"cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 52]);" in normal
assert b'timeout: 60000' in normal
private=[]
for name in OWNERS:
 private.append(copy(PACKET/'owner'/name,(ROOT/name).read_bytes()))
for label,test,worker in [('original',old_test,old_worker),('paired',new_test,new_worker)]:
 for name in SOURCES:
  raw=test if name==TEST else worker if name==WORKER else (ROOT/name).read_bytes()
  private.append(copy(PACKET/'cohorts'/label/name,raw))
bindings={'schema':1,'originals':originals,'private':private,'variants':['original','paired'],
 'original_full_cohort':52,'normal_entry_phase_budget_ms':60000,'existing_receiver_clock_ms':120000,
 'all_397_original_assertion_lines_exact':True,'historical_whole_source_sha256_unchanged':'68659ddec98c9a427244b315b69c17750b743eab2cdd3688308690a66d1c6e98',
 'dependency_closure':'Five exact cohort sources; native client Swift compilation class never discovered by facts-module unittest loader. Wire fixtures explicitly construct native=False and original tests use controlled POSIX subprocess ports. Native=True assignments inside original controls do not invoke native constructor; no Apple helper required.',
 'native_swift_compile_or_certificate_cause_credit':False,'prior_nine_case_packet_untouched':True}
target=PACKET/'SOURCE-BINDINGS.json';target.write_text(json.dumps(bindings,indent=2)+'\n');target.chmod(0o600)
print(json.dumps({'private_files':len(private),'private_bytes':sum(x['bytes'] for x in private),'bindings_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
