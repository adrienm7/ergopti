# Exact two-addition G5 portable receiver diagnostic graft

This unadopted one-path patch uses authenticated G5 source26e920ff0359177bc55b8477883fbb2896da168a, Gitblob0c45da7e16270e61885710ee657eeb6430bab5b4, SHA256bded506a094ac930dacf7ca2eb24c143aa5cd325c4959409ea614c5f8ec8c36b. Proposed candidate SHA256dfe01cdc4942f9e3d1810927b5fbaf8c0b8dde244f916490df9b841b64370c4b.

Only two literal spans from published G6 correction72b29be3999a8666938736e1fb5fc25defb6c263 are inserted: its same-file actual-loop causal function/call, and failure-only bounded output before the existing assertions. Both insertion contexts and each added span are unique. Removing those two spans restores EVERY original G5 byte, including every original executable, argument, source pin, assertion, case/census,60000 budget and success stdout/stderr write. No current whole-file replacement,589991 native metadata admission, deadline change, workflow/peer/native/source-profile change is included.

The original G5 Python spawn is at line352 with timeout60000 at355. Its first error assertion precedes its success-only stream forwarding. The actual run38174614308/attempt1/Core114574407725 raw logs and Core qualification ZIP were Forbidden/zero bytes on sa3. Their blocking and authenticated source/job comparison remain in triage capsule987b06643ce7c831cbcf6ba3ebba16eb71294e75ebaf872c46ad469e25e7b827. Thus the cited90-second duration and actual failed Python script/cause are NOT independently received. This graft is a diagnostic unblock, not a demonstrated timeout repair.

## Focused actual software receiving

`receive-six.cjs` evaluates only the unchanged published control function. It supplies __filename pointing to the actual candidate (or exact original) file, so the function itself reads/extracts its actual Python cases loop. It never evaluates any earlier default/producer/native/G5 suite code. Six real Node child dispositions are received on Linux: success, exit7, SIGTERM, missing executable, bounded failed streams, and ETIMEDOUT. The real diagnostic child has its original separate3-second timeout; the actual loop continues to require60000. Every started direct control child is checked already reaped with ESRCH before its output assertions. Sink-refusal controls retain the same original assertion code/message/actual/expected/operator.

Candidate: six controls PASS, zero failures/errors/skips on Node22.22.2; `PORTABLE_FAILURE_OUTPUT controls=6 native=false`. Frozen original-loop counterfactual exits1 on the first nonzero-result lost-output assertion (actual0 writes versus expected1), ERR_ASSERTION/strictEqual; real success and exit7 children are already reaped. Its four later dispositions are NOT_RUN because the first assertion stops the function. This is an assertion red, not a harness/native failure.

Node whole candidate syntax check passes. Pinned Prettier with explicit repository .prettierrc passes without changing any source. The first formatting invocation lacked the repository config for an outside path and reported failure; its raw receipt is retained distinctly. No assertions or source were edited to obtain the correct-config pass.

Normal whole G5 wrapper/full JS/Python cohorts/native/CI replay are NOT_RUN. Windows receives five controls with the unchanged donor's explicit POSIX-signal deferral; that Windows execution is also NOT_RUN. No actual G5 timeout cause, used executable image, native macOS/windows process/trust, installation or feature acceptance follows from these portable controls.

## Adoption boundary

G5 must independently receive this exact Source graft at its next terminal checkpoint, preserve its own latest preimage/additions, check whole insertion/removal inverse and perform proportional Source/software validation. A changed G5 preimage requires a fresh bounded rebase, not replacing the entire file or silently changing counts. Only the existing G6-owned wrapper spans are proposed; no G5 compiler/native correction is touched. Future real failure retains exact script/status/signal/error code and8192-byte stream tails before the same original refusal. The original optional sink cannot override the primary failure.
