from pathlib import Path
import datetime, hashlib, json, re, subprocess
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-durable-backup');R=Path('/workspace/ergopti-macos-integration')
old=(O/'historical-source-report.md').read_text()
shas=[]
for n in range(1,20):
    match=re.search(r'^### '+str(n)+r'\. .*?\n\nCommit: `([a-f0-9]{40})`',old,re.M|re.S)
    assert match,(n,'missing original commit');shas.append(match.group(1))
for n in range(20,31):
    match=re.search(r'^### '+str(n)+r'\. ([a-f0-9]{40}) — ',old,re.M)
    assert match,(n,'missing original followup');shas.append(match.group(1))
shas += ['9811f27f344e9ce6b8fb93b7f0aee1484a3754ad','c71552b77386ae5eaf4cb0d0461f1b47e4da5d43','bdd4ff26c5a182c4a53de8f5966795a4bdb2cd5f','5d14ff8156196892edb2c3d7d39551a4a42c07ed','d02675fa2df11b8d5d0adbfa1e673164b7a41ea1']
assert len(shas)==len(set(shas))==35
head='b56677ea345e115828e2bf5b5dbfcf5cf5e46c7e';tree='1a36008ddbe51aea487668c69c25e09a5109edef';dev='18d69a24c06586186a221c1afb5ce703732ac4a1'
rows=[]
for n,commit in enumerate(shas,1):
    assert subprocess.run(['git','merge-base','--is-ancestor',commit,head],cwd=R).returncode==0
    subject=subprocess.check_output(['git','show','-s','--format=%s',commit],cwd=R,text=True).strip()
    rows.append({'number':n,'sha':commit,'subject':subject})
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=R,text=True).strip()==tree
assert subprocess.check_output(['git','rev-parse',shas[-1]+'^{tree}'],cwd=R,text=True).strip()==tree
(O/'delivered-commits.json').write_text(json.dumps(rows,indent=2)+'\n')
checkpoint={'state':'CODE_COMPLETE_PUBLISHED_CI_PENDING_NOT_FINAL_HANDOFF','at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'code_commit':head,'code_tree':tree,'dev':dev,'delivered_atoms':35,'normal_dev_merges':12,'oracle_commit':shas[-1],'common_passed':529,'other_common_gates_actual0':18,'common_actual_child_wait_exit':0,'ci':{'run':40765470617,'attempt':1,'head':head,'created_paris':'2026-10-28T21:41:08+01:00','status':'PENDING_PARENT_TERMINAL_RECEIPT','conclusion':None,'url':'https://github.com/adrienm7/ergopti/actions/runs/40765470617'},'pending_before_final_handoff':['Actual terminal CI result and final native/install/verdict evidence on b566; do not copy running CI outputs.','Final documentation/evidence commit and normal push to fix/macos, with its SHA recorded in the final response.']}
(O/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
table='\n'.join(f"| {x['number']} | `{x['sha']}` | {x['subject']} |"for x in rows)
preamble=f'''<!-- docs/audits/macos/2026-10-28/report.md -->

# macOS audit report and bounded handoff

Code checkpoint updated **28 October 2026 at {datetime.datetime.now(ZoneInfo('Europe/Paris')).strftime('%H:%M')} Paris**. All reported times use Europe/Paris (UTC+01:00). The user asked to finish the already-engaged work and already-found defects, save the outcome, and stop new research before deleting the container.

## Current published code and pending CI

The published code checkpoint is **`{head}`**, tree **`{tree}`**, on **`fix/macos`**. The final development merge imports `{dev}`. All **35 delivery atoms** and **12 normal development merges** are preserved; no rebase, force-push, pull request, or push to dev/main was performed. Delivery atoms include test infrastructure and one style change; they are not a claim of 35 distinct runtime bugs.

The final code push completed with actual exit0. Workflow dispatch completed with HTTP204 and actual exit0 at **21:41:08.929658 Paris**, requesting `os_lanes=macos`. New run [**40765470617**](https://github.com/adrienm7/ergopti/actions/runs/40765470617), attempt1, names exact source `{head}` and was created at **21:41:08 Paris**. **Its final conclusion is not yet known.** This code-complete checkpoint must not be described as final CI success; the terminal parent-approved receipt will replace this pending status.

Local full Common qualification executes **529/529 checks successfully**, plus **18 other gates with actual exit0** and durable child wait0. It completed **21:33:34.061 Paris**, followed by the sequential final observer and qualifier at **21:34:53 Paris**. Source and index fingerprints are unchanged and no relevant live process remains. The immutable qualification has SHA256 `923686606c37f2ab92d607567ff88ed3eb7ca5dde02a44095a8c2f06e060a761` and explicitly records staged precommit contents. The ordinary oracle commit and subsequent merge have exactly that qualified whole tree; old receipts were not rewritten to later commits.

The full driver receipts retain their actual parent source `ae73ed2f4d7b915e66b1628c057d346c456d91aa`: macOS **25,385 passed / 2,040 modules +185/185 E2E** (one historical explicit host-specific NA), Linux **19,810 passed /804 modules +302/302 E2E result records**. All product code, driver tests and harness projections are byte-identical in the final code checkpoint. The real change planner selects only format and JS for the final test-only change. Linux's 302 printed records have 274 distinct human labels; no unique-scenario-identity claim is made. The corrected diagnostic and its original failures remain archived, including the single bounded menu-row measurement change 2258 to 2257.

## Final atomic test repair:35

`d02675fa2df11b8d5d0adbfa1e673164b7a41ea1` — **test: verify executable recommended info owners**.

**Bug and original proof:** Common check 487 failed because its Windows source oracle still required raw `gesture_recommended_info`, whereas dev correctly used `MenuCommand.GESTURE_RECOMMENDED_INFO` with the same handler. The exact old gate exits1 on the current product source. The initial proposed guard also accepts eleven reproduced nonexecuting-string decoys: registration, native helper and required reason only in unused strings on each OS, plus two separate handler definitions only in strings on Windows/macOS. Linux's inline handler is covered by its registration case.

**Cause and correction:** source spelling and substring searches could certify comments or string content as executable ownership. The one changed CJS test now reuses the existing comment/string lexical owner, locates actual handler definitions and finite native-call argument spans, and requires the canonical registration and reason literals in the actual dialog call. It preserves all original three-OS default, gesture, debounce, MLX, dialog and absence assertions. No driver, generated artifact, default or user-facing text changes.

**Regression and review:** the corrected gate passes with **22 actually executed negative controls**. All eleven prior lexical-decoy probes now observe the expected specific assertion failure. Five deliberately weakened oracle variants fail: old predicate, missing registration guard, missing comment boundary, missing string boundary and missing native-call argument boundary. The exact old original remains a positive-gate failure. Independent peer acceptance has SHA256 `61cca1939044943817ad64c7090e413e43fd3c5926454c2c7a4d58e7e98b1d0f`; the author revision2 receipt has SHA256 `bf71be21cba49cfde64847d8809c72bee0a25b12ec6a33c73bca6a207b4f8ec1`. Diagnostic-only selection/import-order mistakes remain recorded; they were not product-test skips or weakened assertions. Normal commit hooks exit0 and the committed tree equals the fully qualified content.

**Three-OS scope:** this is the shared source-contract test that blocks Common qualification of every selected lane, including macOS. The original failure concerns the Windows command spelling; all three executable dialog owners and all eleven known lexical decoys are checked. Product behavior on all three OS remains unchanged.

## Twelfth normal development merge

`{head}` — **chore(macos): merge the upstream command guard repair**. Parents are the oracle commit above and `{dev}`. The incoming development commit independently fixes the simple canonical command guard. The one CJS conflict is resolved by preserving dev's canonical command and same handler together with the independently verified stricter 22-control oracle. The **entire resulting tree remains `{tree}`**, identical to the fully qualified oracle commit. All 13 quick gates and normal merge hooks pass; a full rerun is unnecessary for identical bytes. The initial merge conflict exit1 is archived as a merge event, not a failing test.

The private candidate `f699073f0d9fe66a23cfb2f2e45a71a28c4ec785` remains **superseded recovery data only**. It was not integrated or counted among these 35 atoms. Its ref is preserved in the evidence bundle with an explicit DO_NOT_CHERRY_PICK warning.

## Complete delivered commit index

Per-commit bug, cause and regression details for atoms 1–34 remain in the source-specific historical ledger below; atom 35 is detailed above. The eight earlier historical commits and twelve merge commits are documented separately and are not extra new bug fixes.

| # | SHA | Exact subject |
| --- | --- | --- |
{table}

## Remaining work and evidence

[TODO.md](TODO.md) records the one confirmed protected owned-Ollama bootstrap workspace leak. The two Swift source-flow hypotheses and physical/TCC/field questions are explicitly unconfirmed. The old locale, Windows-literal and duplicate-unit issues were repaired upstream; check 487 and the eleven known oracle decoys are now repaired by atom 35. The user stopped new audits; no additional research is authorized by this handoff.

[README.md](README.md), [manifest.json](manifest.json) and `evidence.tar.gz` preserve the recorded receipts, original negative probes, source freezes, reproducible protected-helper proof and recoverable Git refs. Historical `/workspace/scratch/...` paths identify their recorded archive locations; they are not promises that the deleted container still exists.

## Historical source-specific ledger through 20:46 Paris

The following ledger is retained from the earlier report snapshot. Its checkpoint words such as “current”, “pending”, “not pushed” and “candidate” describe the explicit earlier times and source hashes there, not the current published checkpoint above. Its original bytes and SHA are also preserved in the archive. Current code35, merge12 and CI status are owned by the sections above.

'''
# Preserve the earlier body and source identities under an explicit historical scope.
historical=old.replace('# macOS audit batch — 28 October 2026','### Earlier audit ledger',1)
(O/'report-overlay.md').write_text(preamble+historical)
print(json.dumps({'code':head,'tree':tree,'atoms':len(rows),'report_bytes':(O/'report-overlay.md').stat().st_size,'status':checkpoint['state']}))
