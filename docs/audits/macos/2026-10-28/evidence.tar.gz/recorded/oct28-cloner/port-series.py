from pathlib import Path
import subprocess,os,json,hashlib,datetime,time,stat
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-picker-observer');d=Path('/workspace/scratch/oct28-cloner');e=dict(os.environ);e.update(USER='agent',LOGNAME='agent',HUSKY='1');e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu'
rel='static/ergopti_plus/macos/apps/App Cloner.app/Contents/Resources'
def g(*a):return subprocess.check_output(['git',*a],cwd=w)
def snap(name):
 p=d/name/'resources';p.mkdir(parents=True,exist_ok=True)
 for n in ['clone_app.sh','make_shortcut.sh','reserve_bundle.sh','quote_launcher_values.py']:(p/n).write_bytes((w/rel/n).read_bytes())
 return str(p)
def run(label,cmd):
 log=d/(label+'.log');started=time.monotonic()
 with log.open('w') as f:r=subprocess.run(cmd,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT)
 x={'label':label,'command':cmd,'actual_exit':r.returncode,'seconds':time.monotonic()-started,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};print(json.dumps(x),flush=True)
 if r.returncode:raise RuntimeError(str(x))
 return x
assert g('rev-parse','HEAD').decode().strip()=='74f683f5a6ad49a62e5dad8837b8375375a01d3c';assert not g('status','--porcelain');snap('00-base')
run('hooks',['npx','husky','install'])
ready=json.loads(Path('/workspace/scratch/cloner-minimal-owner-final/ready.json').read_text());stages=ready['stages']+[{'stage':'SIGNAL','patch':'/workspace/scratch/cloner-finalize-delivery/final-six-delta.patch','sha256':'ab5330eb0054b8931d8eaee36444104744fcc0140eb36866879efb2e91bc1275'}];rows=[]
for i,s in enumerate(stages,1):
 p=Path(s['patch']);assert hashlib.sha256(p.read_bytes()).hexdigest()==s['sha256'];before=g('write-tree').decode().strip();subprocess.run(['git','apply','--check','--index',str(p)],cwd=w,check=True);subprocess.run(['git','apply','--index',str(p)],cwd=w,check=True)
 paths=[os.fsdecode(raw) for raw in g('diff','--cached','--name-only','-z').split(b'\0') if raw];assert 'tools/test/test-bash-resolution.cjs' not in paths
 for n in paths:
  mode=g('ls-files','-s','--',n).decode().split()[0];(w/n).chmod(0o755 if mode=='100755' else 0o644)
 gates=[run(f'{i:02d}-{s["stage"].lower()}-hook',['sh','.husky/pre-commit']),run(f'{i:02d}-{s["stage"].lower()}-generated',['node','tools/test/test-app-cloner-generated-literals.cjs'])]
 assert not g('diff','--name-only')
 after=g('write-tree').decode().strip();patch=g('diff','--cached','--binary','--full-index',before);out=d/f'{i:02d}-{s["stage"].lower()}.patch';out.write_bytes(patch);snapshot=snap(f'{i:02d}-{s["stage"].lower()}')
 rows.append({'order':i,'stage':s['stage'],'before_tree':before,'after_tree':after,'patch':str(out),'patch_sha256':hashlib.sha256(patch).hexdigest(),'resources_snapshot':snapshot,'gates':gates,'source_input_patch_sha256':s['sha256'],'paths':[os.fsdecode(raw) for raw in g('diff','--cached','--name-only','-z',before).split(b'\0') if raw]})
 (d/'stages.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps({'stage_ready':s['stage'],'tree':after}),flush=True)
extra=[]
for label,cmd in [('maximize',['node','tools/test/test-app-cloner-shortcut-maximize.cjs']),('dock',['node','tools/test/test-app-cloner-dock-url.cjs']),('false-green',['node','tools/test/find-false-greens.cjs']),('verify-plan',['node','./tools/test/verify-change.cjs','--plan']),('source-encoding',['npm','run','-s','test:source-encoding']),('ahk-encoding',['npm','run','-s','test:ahk-encoding'])]:extra.append(run(label,cmd))
final=g('diff','--cached','--binary','--full-index');(d/'combined.patch').write_bytes(final);(d/'port-receipt.json').write_text(json.dumps({'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'head':g('rev-parse','HEAD').decode().strip(),'tree':g('write-tree').decode().strip(),'stages':rows,'extra':extra,'combined_patch_sha256':hashlib.sha256(final).hexdigest(),'native':'UNCOMPILED/UNRUN on Linux; real Darwin CI required','node_modules_inode':(w/'node_modules').stat().st_ino},indent=2)+'\n')
