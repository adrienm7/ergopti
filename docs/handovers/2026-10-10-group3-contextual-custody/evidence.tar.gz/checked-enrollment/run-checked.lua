local root, source, tests, cohort = assert(arg[1]), assert(arg[2]), assert(arg[3]), assert(arg[4])
local this = assert(debug.getinfo(1, "S").source:match("^@(.*)/[^/]+$"))
local census = assert(dofile(this .. "/census.lua")[cohort], "Unknown independent cohort: " .. cohort)
local filter = arg[5] or census.filter
local expected = {}
for _, name in ipairs(census.names) do
	assert(type(name) == "string" and expected[name] == nil, "Duplicate or invalid independent expected case")
	expected[name] = true
end
assert(#census.names == census.count and census.count > 0, "Invalid independent expected count")

local linux, shared = root .. "/static/ergopti_plus/linux", root .. "/static/ergopti_plus/_shared/lua"
package.path = linux .. "/?.lua;" .. linux .. "/?/init.lua;" .. shared .. "/?.lua;" .. shared .. "/?/init.lua;" .. package.path
require("compat.utf8").install()
package.preload["modules.shortcuts.keyboard_shortcuts"] = assert(loadfile(source))
local helpers = require("tests.helpers")
helpers.set_only_filter(filter)
local original_it, observed, selected, enrollment_errors = helpers.it, {}, 0, {}
helpers.it = function(name, body)
	if not name:find(filter, 1, true) then return end
	-- The owner cohort deliberately selects its three exact owner scenarios.
	-- The ordinary-rebind sibling is preserved and left to the canonical suite.
	if census.excluded_names and census.excluded_names[name] then return end
	if not expected[name] then
		enrollment_errors[#enrollment_errors + 1] = "Foreign selected case: " .. name
		error(enrollment_errors[#enrollment_errors], 0)
	end
	if observed[name] then
		enrollment_errors[#enrollment_errors + 1] = "Duplicate selected case: " .. name
		error(enrollment_errors[#enrollment_errors], 0)
	end
	observed[name], selected = true, selected + 1
	print("SELECTED " .. name)
	original_it(name, body)
end
local loaded, load_error = pcall(dofile, tests)
helpers.it = original_it
if not loaded then enrollment_errors[#enrollment_errors + 1] = "Enrollment load error: " .. tostring(load_error) end
for _, name in ipairs(census.names) do
	if not observed[name] then enrollment_errors[#enrollment_errors + 1] = "Missing selected case: " .. name end
end
local results = helpers.get_results()
local completed = results.passed + results.failed
if selected ~= census.count then
	enrollment_errors[#enrollment_errors + 1] = string.format("Selected census differs: %d/%d", selected, census.count)
end
if completed ~= census.count then
	enrollment_errors[#enrollment_errors + 1] = string.format("Completed census differs: %d/%d", completed, census.count)
end
for _, reason in ipairs(enrollment_errors) do print("ENROLLMENT_REFUSED " .. reason) end
print(string.format("RESULT %d passed, %d failed; selected=%d intended=%d completed=%d enrollment_errors=%d cohort=%s filter=%s",
	results.passed, results.failed, selected, census.count, completed, #enrollment_errors, cohort, filter))
os.exit(loaded and #enrollment_errors == 0 and results.failed == 0 and 0 or 1)
