// _shared/ui/metrics_apps/helpers.js
/**
 * _shared/ui/metrics_apps/helpers.js
 * ==============================================================================
 * MODULE: Apps Time UI Logic
 * DESCRIPTION:
 * Logic for the apps time tracker UI.
 *
 * FEATURES & RATIONALE:
 * 1. Time Aggregation: Seamlessly merges data by Day, Week, Month, or Year.
 * 2. Visualizer Engine: Computes raw milliseconds into HHh MMm.
 * 3. Dynamic Categories: Plots data grouped by user-defined categories.
 * 4. Chronological Timeline: Stacked bar charts for intraday or interday evolution.
 * ==============================================================================
 */

// Shared i18n helper — reads from window._i18n_strings populated by i18n.js.
function _t(key) {
	return (window._i18n_strings && window._i18n_strings[key]) || key;
}

let manifestData = window.ManifestData || {};
let userCategories = window.UserCategories || {};
let appIcons = window.AppIcons || {};
let currentSelectedDate = null;
let currentPeriod = 'day';
// One calendar-length owner for period queries and their previous-period comparison.
const METRICS_PERIOD_DAYS = Object.freeze({
	day: 1,
	week: 7,
	month: 30,
	year: METRICS_CALENDAR_YEAR_DAYS
});
// #53 — null means "all categories enabled"; otherwise a Set of allowed cats.
let currentCategoryFilter = null;
// #54 — null means "all weekdays enabled"; otherwise a Set of allowed dows (0=Mon..6=Sun).
let currentWeekdayFilter = null;
// #55 — when true, the comparator panel computes stats vs the equivalent
// previous period and shows the delta.
let currentCompareEnabled = false;
// Keep-awake counting toggle. Default OFF: awake_ms is subtracted from focus
// time so jiggler intervals don't inflate per-app stats. Toggle ON to count
// keep-awake time normally.
let currentCountAwake = false;

// Dominant colour cache: app_name → '#rrggbb' (computed once per icon via Canvas)
const _dominantColorCache = Object.create(null);

let appsBarChart = null;
let catPieChart = null;
let timelineChart = null;

const safeLog = (fn, ...args) => {
	try {
		if (console && typeof console[fn] === 'function') console[fn](...args);
	} catch (e) {}
};

function $id(id) {
	try {
		return document.getElementById(id);
	} catch (e) {
		return null;
	}
}

// ===================================
// ===================================
// ======= 1/ Helper Functions =======
// ===================================
// ===================================

// Map macOS LSApplicationCategoryType (English) → stable i18n id matching
// _shared/data/locales/<code>.json app_category.* keys.
const CATEGORY_ID_MAP = {
	Productivity: 'productivity',
	'Social networking': 'social',
	Games: 'games',
	Entertainment: 'entertainment',
	Utilities: 'utility',
	Education: 'education',
	Finance: 'finance',
	Business: 'business',
	'Graphics design': 'graphics_design',
	Photography: 'photography',
	Video: 'video',
	Music: 'music',
	Medical: 'medical',
	'Health fitness': 'health',
	Lifestyle: 'lifestyle',
	News: 'news',
	Weather: 'weather',
	Sports: 'sports',
	Travel: 'travel',
	Navigation: 'navigation',
	Reference: 'reference',
	'Developer tools': 'development',
	Unknown: 'general'
};
const CATEGORY_IDS = new Set(Object.values(CATEGORY_ID_MAP));

// Reverse map (any locale label → stable id), populated lazily by translateCategory
// so getCategoryColor can resolve a translated label back to its id.
const _labelToId = {};

// Pre-seed the French legacy labels so existing user categories stored with
// the old hardcoded French strings still resolve to the correct id.
const _FRENCH_LEGACY_LABELS = {
	Productivité: 'productivity',
	'Réseaux sociaux': 'social',
	Jeux: 'games',
	Divertissement: 'entertainment',
	Utilitaires: 'utility',
	Éducation: 'education',
	Finance: 'finance',
	Business: 'business',
	'Design graphique': 'graphics_design',
	Photographie: 'photography',
	Vidéo: 'video',
	Musique: 'music',
	Médical: 'medical',
	'Santé & Forme': 'health',
	'Style de vie': 'lifestyle',
	Actualités: 'news',
	Météo: 'weather',
	Sport: 'sports',
	Voyage: 'travel',
	Navigation: 'navigation',
	Références: 'reference',
	Développement: 'development',
	Général: 'general'
};

// Perceptually distinct palette — spread across hue wheel to avoid blue clustering
const CHART_PALETTE = [
	ThemeTokens.color('pink-dark'), // Red-Pink
	ThemeTokens.color('orange-dark'), // Orange
	ThemeTokens.color('yellow-dark'), // Yellow
	ThemeTokens.color('hue-32d74b'), // Green
	ThemeTokens.color('cyan-dark'), // Sky Blue
	ThemeTokens.color('blue-dark'), // Blue
	ThemeTokens.color('indigo-dark'), // Indigo
	ThemeTokens.color('purple-dark'), // Purple
	ThemeTokens.color('hue-ff6b35'), // Burnt Orange
	ThemeTokens.color('hue-00c7be'), // Teal
	ThemeTokens.color('hue-e588f8'), // Lavender
	ThemeTokens.color('hue-f4a460'), // Sandy
	ThemeTokens.color('hue-30b0c7'), // Cyan-Teal
	ThemeTokens.color('red-dark'), // Deep Red
	ThemeTokens.color('green'), // Leaf Green
	ThemeTokens.color('hue-5ac8fa') // Light Blue
];

// Fixed aesthetic mappings for standard categories keyed on stable i18n ids —
// each hue is deliberately distant from the others on the colour wheel.
const FIXED_CAT_COLORS = {
	productivity: ThemeTokens.color('blue-dark'),
	development: ThemeTokens.color('indigo-dark'),
	social: ThemeTokens.color('pink-dark'),
	games: ThemeTokens.color('red-dark'),
	entertainment: ThemeTokens.color('purple-dark'),
	utility: ThemeTokens.color('cyan-dark'),
	education: ThemeTokens.color('orange-dark'),
	business: ThemeTokens.color('yellow-dark'),
	finance: ThemeTokens.color('hue-30b0c7'),
	graphics_design: ThemeTokens.color('hue-e588f8'),
	photography: ThemeTokens.color('hue-ff6b35'),
	video: ThemeTokens.color('pink-dark'),
	music: ThemeTokens.color('hue-32d74b'),
	health: ThemeTokens.color('green'),
	news: ThemeTokens.color('hue-f4a460'),
	weather: ThemeTokens.color('hue-5ac8fa'),
	travel: ThemeTokens.color('hue-00c7be'),
	general: ThemeTokens.color('gray')
};

// Every localised spelling of the default category, from the generated alias
// data (tools/build/gen-metrics-category-aliases.cjs). app_categories.json stores
// the spelling of the language active when it was written, so a user who changed
// language holds an older one: all fold into the canonical 'general' id instead of
// showing as a custom category. A page without the data would orphan them, so it
// fails here rather than falling back to a partial list.
if (!Array.isArray(window.GeneralCategoryAliases))
	throw new Error('metrics_general_category_aliases.js must load before helpers.js');
const _GENERAL_CATEGORY_ALIASES = new Set(window.GeneralCategoryAliases);

/**
 * Resolves a preset to its stable i18n id while preserving custom category text.
 * Accepts an English macOS category, a French legacy label, or an already-stable id.
 * @param {string} catName
 * @returns {string} Preset id or custom text; empty/invalid input defaults to 'utility'.
 */
function categoryToId(catName) {
	if (typeof catName !== 'string' || !catName.trim()) return 'utility';
	// Direct English → id
	if (Object.prototype.hasOwnProperty.call(CATEGORY_ID_MAP, catName))
		return CATEGORY_ID_MAP[catName];
	// French legacy label → id (backward compat with existing user categories)
	if (Object.prototype.hasOwnProperty.call(_FRENCH_LEGACY_LABELS, catName))
		return _FRENCH_LEGACY_LABELS[catName];
	// Already a stable id?
	if (CATEGORY_IDS.has(catName)) return catName;
	// Reverse cache populated by previous translateCategory calls
	if (Object.prototype.hasOwnProperty.call(_labelToId, catName)) return _labelToId[catName];
	// The default category as written under any other UI language
	if (_GENERAL_CATEGORY_ALIASES.has(catName)) return 'general';
	return catName;
}

function translateCategory(catName) {
	const id = categoryToId(catName);
	// Custom text is already a display label, not a locale catalogue key.
	if (!CATEGORY_IDS.has(id)) return id;
	const label = _t('app_category.' + id);
	_labelToId[label] = id;
	return label;
}

/**
 * Hashes a string to a stable index into CHART_PALETTE, using a better
 * mixing function so similar names land on distant hues.
 * @param {string} str
 * @returns {number}
 */
function paletteIndex(str) {
	let h = 2166136261;
	for (let i = 0; i < str.length; i++) {
		h ^= str.charCodeAt(i);
		h = Math.imul(h, 16777619) >>> 0;
	}
	return h % CHART_PALETTE.length;
}

function getCategoryColor(catName, score) {
	if (score > 0) return ThemeTokens.color('green-dark');
	if (score < 0) return ThemeTokens.color('red-dark');
	const id = categoryToId(catName);
	if (Object.prototype.hasOwnProperty.call(FIXED_CAT_COLORS, id)) return FIXED_CAT_COLORS[id];
	return CHART_PALETTE[paletteIndex(catName)];
}

const postBridge = makeHostBridge('metrics_apps_bridge');

function getAppColor(appName, score) {
	// Always prefer the dominant icon colour — score is reflected in the score column, not the bar
	if (_dominantColorCache[appName]) return _dominantColorCache[appName];
	if (score > 0) return ThemeTokens.color('green-dark');
	if (score < 0) return ThemeTokens.color('red-dark');
	return CHART_PALETTE[paletteIndex(appName)];
}

/**
 * Extracts the dominant (most saturated, non-white/black) colour from an image
 * data URL by sampling pixels via an off-screen Canvas.
 * @param {string} dataUrl - Base64 image data URL.
 * @returns {string} Hex colour string '#rrggbb'.
 */
function extractDominantColorFromImage(img) {
	try {
		const canvas = document.createElement('canvas');
		canvas.width = 24;
		canvas.height = 24;
		const ctx = canvas.getContext('2d');
		ctx.drawImage(img, 0, 0, 24, 24);
		const data = ctx.getImageData(0, 0, 24, 24).data;
		// Bucket pixels into 4-bit-per-channel bins, weighted by saturation; pick heaviest bin.
		const buckets = {};
		for (let i = 0; i < data.length; i += 4) {
			const r = data[i],
				g = data[i + 1],
				b = data[i + 2],
				a = data[i + 3];
			if (a < 100) continue;
			const lum = (r + g + b) / 3;
			if (lum > 235 || lum < 20) continue;
			const max = Math.max(r, g, b),
				min = Math.min(r, g, b);
			const sat = max === 0 ? 0 : (max - min) / max;
			if (sat < 0.18) continue;
			const key = (r >> 4) * 256 + (g >> 4) * 16 + (b >> 4);
			if (!buckets[key]) buckets[key] = { r: 0, g: 0, b: 0, w: 0 };
			const wt = sat;
			buckets[key].r += r * wt;
			buckets[key].g += g * wt;
			buckets[key].b += b * wt;
			buckets[key].w += wt;
		}
		let best = null;
		for (const k in buckets) {
			if (!best || buckets[k].w > best.w) best = buckets[k];
		}
		if (!best || best.w === 0) return null;
		const r = Math.round(best.r / best.w);
		const g = Math.round(best.g / best.w);
		const b = Math.round(best.b / best.w);
		return '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
	} catch (_) {
		return null;
	}
}

/**
 * Asynchronously computes dominant colours for all icons. Resolves once every
 * image has either loaded (and been sampled) or failed.
 * @returns {Promise<void>}
 */
function precomputeIconColors() {
	const entries = Object.entries(appIcons).filter(([n, u]) => u && !_dominantColorCache[n]);
	if (entries.length === 0) return Promise.resolve();
	return Promise.all(
		entries.map(
			([appName, dataUrl]) =>
				new Promise((resolve) => {
					const img = new Image();
					img.onload = () => {
						const color = extractDominantColorFromImage(img);
						if (color) _dominantColorCache[appName] = color;
						resolve();
					};
					img.onerror = () => resolve();
					img.src = dataUrl;
				})
		)
	).then(() => undefined);
}

function formatDuration(ms) {
	if (!ms && ms !== 0) return '0m';
	const n = Number(ms) || 0;
	const totalMinutes = Math.floor(n / 60000);
	const hours = Math.floor(totalMinutes / 60);
	const minutes = totalMinutes % 60;
	if (hours > 0) return `${hours}h ${String(minutes).padStart(2, '0')}m`;
	return `${minutes}m`;
}

function formatDurationDecimal(ms) {
	if (!ms) return 0;
	return Number((ms / 3600000).toFixed(2));
}

function formatDisplayDate(dateStr) {
	const ts = parseDateKey(dateStr);
	if (isNaN(ts)) return dateStr;
	const d = new Date(ts);
	return `${String(d.getUTCDate()).padStart(2, '0')}/${String(d.getUTCMonth() + 1).padStart(2, '0')}/${d.getUTCFullYear()}`;
}

// ===================================
// ===================================
