// Full original module; unchanged ownPhase remains sole physical phase owner.
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const packet=__dirname;
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const bindingsPath=path.join(packet,'SOURCE-BINDINGS.json');
const bindings=JSON.parse(fs.readFileSync(bindingsPath));
function identity(file){
 const s=fs.lstatSync(file,{bigint:true});
 if(!s.isFile()||s.isSymbolicLink())throw Error('Regular source input refused');
 return {path:file,dev:String(s.dev),ino:String(BigInt.asUintN(64,s.ino)),uid:String(s.uid),mode:String(s.mode),bytes:Number(s.size),sha256:sha(file)};
}
const fences=[...bindings.originals,...bindings.private,...['run-receiving.cjs','receiving_launcher.py','SOURCE-BINDINGS.json'].map(name=>identity(path.join(packet,name)))];
const refence=()=>{for(const row of fences)if(JSON.stringify(identity(row.path))!==JSON.stringify(row))throw Error('Full source identity changed');};
refence();
const owner=require(path.join(packet,'owner/tools/test/run-linux-managed-http-native.cjs'));
refence();
const work=fs.mkdtempSync('/tmp/group6-http-debug-full52-owned-');fs.chmodSync(work,0o700);
const deadline=process.hrtime.bigint()+120000000000n;
let cancelled=false;
const cancel=()=>{cancelled=true;owner.requestActiveCancellation();};
process.on('SIGTERM',cancel);process.on('SIGINT',cancel);
(async()=>{
 const results=[];
 for(const label of bindings.variants){
  refence();
  if(cancelled||process.hrtime.bigint()>=deadline)throw Error('Original full-cohort clock refused');
  const cohort=path.join(packet,'cohorts',label);
  const result=await owner.ownPhase({command:'python3',args:['-B',path.join(packet,'receiving_launcher.py'),path.join(cohort,'tools/test/macos_native_http_receiving_facts_test.py'),path.join(work,label+'.json')],
   env:{...process.env,TMPDIR:'/tmp',PYTHONDONTWRITEBYTECODE:'1'},cwd:cohort,work,label,
   worker:path.join(packet,'owner/tools/test/run-linux-managed-http-phase.py'),owner:path.join(packet,'owner/tools/build/stage-linux-network-runtime.py'),
   ownerSha:'ac48a4e9755fb2b9e9cbe35c81b097942bf7be76d14466e03b891b4c78f302f5',kind:'command',budgetMs:60000,gateDeadline:deadline});
  refence();
  const closed=JSON.parse(fs.readFileSync(path.join(work,label+'.owner/closed.json')));
  const summary=JSON.parse(fs.readFileSync(path.join(work,label+'.json')));
  const physicallyClosed=result.signal===null&&result.error===null&&!owner.hasRetainedPhases()&&!closed.cancelled&&owner.phaseReceipt(closed,closed.pid,'command',result.status);
  const ok=physicallyClosed&&result.status===0&&summary.total===52&&summary.pass===52&&summary.fail===0&&summary.errors===0&&summary.skip===0&&!cancelled;
  const sameOriginalCensus=results.length===0||JSON.stringify(summary.selected)===JSON.stringify(results[0].summary.selected);
  results.push({label,ok:ok&&sameOriginalCensus,status:result.status,signal:result.signal,error:result.error,retained:owner.hasRetainedPhases(),closed,summary,
   stdout_sha256:sha(path.join(work,label+'.stdout')),stderr_sha256:sha(path.join(work,label+'.stderr'))});
  fs.writeFileSync(path.join(work,'RESULTS.json'),JSON.stringify({schema:1,results,source_identity_refences_exact:true,
   source_bindings_sha256:sha(bindingsPath),original_full_case_census:52,phase_budget_seconds:60,receiver_clock_seconds:120,
   owner_grace_and_cancellation_unchanged:true,native_swift_compile_or_certificate_cause_credit:false,main_index_refs_mutated:false},null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({label,ok:ok&&sameOriginalCensus,pass:summary.pass,fail:summary.fail,errors:summary.errors,skip:summary.skip,status:result.status,retained:owner.hasRetainedPhases()}));
  if(!physicallyClosed||!sameOriginalCensus)throw Error('Full-cohort closure/census refused');
  // Preserve a genuine assertion failure and still receive the second cohort.
 }
 refence();
 if(cancelled||process.hrtime.bigint()>=deadline||owner.hasRetainedPhases())throw Error('Final full-cohort source/clock/debt refused');
 fs.writeFileSync(path.join(packet,'RESULT-LOCATOR.json'),JSON.stringify({work,results_sha256:sha(path.join(work,'RESULTS.json'))},null,2)+'\n',{flag:'wx',mode:0o600});
 console.log('RESULT_DIRECTORY='+work);
 if(results.some(row=>!row.ok))process.exitCode=1;
})().catch(error=>{console.error('FULL_COHORT_RECEIVING_REFUSED work='+work+' reason='+error.message);process.exitCode=1;}).finally(()=>{
 if(!owner.hasRetainedPhases()){process.removeListener('SIGTERM',cancel);process.removeListener('SIGINT',cancel);}
});
