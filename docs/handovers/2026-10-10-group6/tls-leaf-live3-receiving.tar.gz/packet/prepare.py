"""Source-bind unchanged live-peer controls with original or digest-pinned fixture."""
from pathlib import Path
import hashlib
import json
import stat

PACKET=Path(__file__).parent
ROOT=Path('/workspace/ergopti')
PIN=Path('/tmp/group6-wire-leaf-sha256-4e9-kxr2b817')
TEST='static/ergopti_plus/macos/tests/support/native_http_wire_fixture_test.py'
FIXTURE='static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
OWNERS=['tools/test/run-linux-managed-http-native.cjs','tools/test/run-linux-managed-http-phase.py',
 'tools/build/stage-linux-network-runtime.py','tools/lib/git_bash.py']

def fact(q):
 s=q.lstat()
 if not stat.S_ISREG(s.st_mode):raise RuntimeError('Exact regular input required')
 return {'path':str(q),'dev':str(s.st_dev),'ino':str(s.st_ino),'uid':str(s.st_uid),'mode':str(s.st_mode),
         'bytes':s.st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}

def copy(q,raw):
 q.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 with q.open('xb') as out:out.write(raw)
 q.chmod(0o600)
 return fact(q)

pin=json.loads((PIN/'SOURCE-ACK.json').read_text())
old=(ROOT/FIXTURE).read_bytes();new=(PIN/'payload'/FIXTURE).read_bytes()
assert old==(PIN/'preimages'/FIXTURE).read_bytes()
assert hashlib.sha256(old).hexdigest()==pin['preimage_sha256']
assert hashlib.sha256(new).hexdigest()==pin['candidate_sha256']
assert new.replace(b'                "-sha256",\n',b'',1)==old
assert hashlib.sha256((PIN/'candidate.patch').read_bytes()).hexdigest()==pin['patch_sha256']
assert hashlib.sha256((PIN/'inverse.patch').read_bytes()).hexdigest()==pin['inverse_sha256']
for row in pin['controls_exact']:
 assert fact(ROOT/row['path'])['sha256']==row['sha256']
normal=ROOT/'tools/test/test-macos-native-http-receiving.cjs'
assert TEST.encode() in normal.read_bytes() and b'timeout: 60000' in normal.read_bytes()
extras=[normal]+[ROOT/row['path'] for row in pin['controls_exact'] if row['path']!=TEST]
tools=[Path(q) for q in ['/workspace/ergopti-subreaper.py','/workspace/.tools/node/node_modules/node/bin/node',
 str(Path('/workspace/.tools/python/bin/python3').resolve()),'/usr/bin/openssl',
 '/usr/lib/x86_64-linux-gnu/libssl.so.3','/usr/lib/x86_64-linux-gnu/libcrypto.so.3']]
originals=[fact(ROOT/q) for q in [TEST,FIXTURE]+OWNERS]+[fact(q) for q in extras+tools]
private=[]
for q in OWNERS:private.append(copy(PACKET/'owner'/q,(ROOT/q).read_bytes()))
for label,fixture in [('original',old),('explicit-sha256',new)]:
 private.append(copy(PACKET/'cohorts'/label/TEST,(ROOT/TEST).read_bytes()))
 private.append(copy(PACKET/'cohorts'/label/FIXTURE,fixture))
bindings={'schema':1,'originals':originals,'private':private,'variants':['original','explicit-sha256'],
 'original_cohort':3,'phase_budget_ms':60000,'receiver_clock_ms':120000,
 'literal_original_assertions_and_case_corpus_unchanged':True,'whole_single_flag_inverse_exact':True,
 'fixture_patch_sha256':pin['patch_sha256'],'fixture_inverse_sha256':pin['inverse_sha256'],
 'scope':'Actual Linux original TLS/CONNECT/SOCKS5 peers, fetched PAC, no-origin proxy refusal and untrusted certificate refusal. Explicit fixture signing digest only; no original macOS signature algorithm or TLS cause credit.',
 'source_guard_impact':'Existing historical facts pin covers ManagedHTTPWorker.swift only, unchanged. Original three-control normal entry preserves census and exit checks, has no fixed fixture whole-source pin. Native receiving source SHA inventories capture actual inputs dynamically; no fixed digest expectations changed.',
 'main_index_refs_mutated':False,'leaf_pin_adopted_in_main':False}
target=PACKET/'SOURCE-BINDINGS.json';target.write_text(json.dumps(bindings,indent=2)+'\n');target.chmod(0o600)
print(json.dumps({'private_files':len(private),'private_bytes':sum(q['bytes'] for q in private),'bindings_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
