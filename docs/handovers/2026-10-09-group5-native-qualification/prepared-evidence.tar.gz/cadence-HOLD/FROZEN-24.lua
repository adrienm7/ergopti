--- tests/unit/platform/remap/test_lease_start_heartbeat_anchor.lua

--- ==============================================================================
--- MODULE: Lease Startup Heartbeat Anchor Controls
--- DESCRIPTION:
--- Tests the real controller against bounded task/timer models, without native claims.
--- ==============================================================================

local helpers = require("tests.helpers")
local support = require("tests.support.lease_controller_fixture")

local function recurring(ctx, live_only)
	local result = {}
	for _, timer in ipairs(ctx.timers) do
		if timer.repeating and (not live_only or not timer.cancelled) then result[#result + 1] = timer end
	end
	return result
end

helpers.describe("lease startup heartbeat anchor", function()
	helpers.it("retains one original cadence before delayed paused READY without a followup write", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local armed_at
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every = scheduler.every
			scheduler.every = function(delay, fn) armed_at = ctx.clock; return every(delay, fn) end
			assert(controller.start_paused())
			assert(armed_at == 0, "READY delivery must not rebase the first existing periodic pulse")
			ctx.clock = 2
			ctx.chunk(1, "READY\n")
			assert(controller.status() == "paused" and #ctx.spawns[1].inputs == 0)
			local timers = recurring(ctx, true)
			assert(#timers == 1 and timers[1].delay == 5)
			assert(armed_at + timers[1].delay < 5 + 1.75)
			ctx.clock = 5
			ctx.fire_heartbeat_timer()
			assert(ctx.spawns[1].inputs[1] == "PING 1\n")
		end)
	end)

	helpers.it("keeps late accepted READY inside the same first cadence", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			assert(controller.start_paused())
			local timer = recurring(ctx, true)[1]
			assert(timer and timer.delay == 5, "Timer ownership must precede accepted READY delivery")
			ctx.clock = 3.75
			ctx.chunk(1, "READY\n")
			assert(controller.status() == "paused" and recurring(ctx, true)[1] == timer)
			ctx.clock = 5
			ctx.fire_heartbeat_timer()
			assert(ctx.spawns[1].inputs[1] == "PING 1\n")
		end)
	end)

	helpers.it("leaves pre-READY timer callbacks inert without claiming readiness", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			assert(controller.start_paused())
			local timer = recurring(ctx, true)[1]
			assert(timer, "The starting generation must retain its cadence")
			timer.fn()
			assert(controller.status() == "starting" and #ctx.spawns[1].inputs == 0)
			ctx.chunk(1, "READY\n")
			assert(controller.status() == "paused" and #ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("serializes periodic PING after the existing RESUME acknowledgement", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			assert(controller.start_paused())
			ctx.clock = 2
			ctx.chunk(1, "READY\n")
			assert(controller.resume_prepared(controller.token()))
			assert(ctx.spawns[1].inputs[1] == "RESUME\n")
			ctx.clock = 5
			ctx.fire_heartbeat_timer()
			assert(#ctx.spawns[1].inputs == 1, "In-flight RESUME retains sole task input ownership")
			ctx.chunk(1, "RESUMED\n")
			ctx.fire_heartbeat_timer()
			assert(controller.status() == "active" and ctx.spawns[1].inputs[2] == "PING 1\n")
		end)
	end)

	helpers.it("reuses the exact timer when READY is synchronous inside task start", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			ctx.ready_on_start = true
			local callbacks = 0
			assert(controller.start_paused(function(ok) assert(ok == true); callbacks = callbacks + 1 end))
			assert(callbacks == 1 and controller.status() == "paused")
			assert(#recurring(ctx, false) == 1 and #recurring(ctx, true) == 1)
			assert(#ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("does not rearm after a synchronous READY start callback stops its generation", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			ctx.ready_on_start = true
			assert(controller.start_paused(function(ok) assert(ok == true); assert(controller.stop("retained-callback-stop")) end))
			assert(#recurring(ctx, false) == 1 and #recurring(ctx, true) == 0)
			assert(ctx.spawns[1].inputs[1] == "STOP\n")
		end)
	end)

	helpers.it("does not rearm an older generation after synchronous replacement and ignores its queued timer", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			ctx.ready_on_start = true
			local original_token
			assert(controller.start_paused(function(ok)
				assert(ok == true)
				original_token = controller.token()
				assert(controller.stop("replace"))
				assert(controller.start_paused())
			end))
			assert(controller.token() ~= original_token and controller.status() == "paused")
			local all = recurring(ctx, false)
			assert(#all == 2 and #recurring(ctx, true) == 1)
			local before_old, before_new = #ctx.spawns[1].inputs, #ctx.spawns[2].inputs
			all[1].fn()
			assert(#ctx.spawns[1].inputs == before_old and #ctx.spawns[2].inputs == before_new)
			ctx.fire_heartbeat_timer()
			assert(ctx.spawns[2].inputs[1] == "PING 1\n")
		end)
	end)

	helpers.it("allocates no heartbeat for a refused native start", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			ctx.next_start_result = false
			assert(controller.start_paused() == false)
			assert(#recurring(ctx, false) == 0 and controller.status() ~= "active")
		end)
	end)

	helpers.it("allocates no heartbeat when native start throws", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local runner = package.loaded["adapters.shell_runner"]
			local spawn = runner.spawn
			runner.spawn = function(...)
				local handle = spawn(...)
				handle.start = function() error("controlled start refusal") end
				return handle
			end
			assert(controller.start_paused() == false)
			assert(#recurring(ctx, false) == 0 and controller.status() ~= "active")
		end)
	end)

	helpers.it("retires cadence on STOP before READY and refuses the retained callback", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			assert(controller.start_paused())
			local timer = recurring(ctx, true)[1]
			assert(timer, "Starting generation must already own its cadence")
			assert(controller.stop("before-ready"))
			assert(timer.cancelled and #recurring(ctx, true) == 0)
			local count = #ctx.spawns[1].inputs
			timer.fn()
			ctx.chunk(1, "READY\n")
			assert(#ctx.spawns[1].inputs == count and #recurring(ctx, true) == 0)
		end)
	end)

	helpers.it("refuses an uncommitted cadence during start and preserves exact rollback", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			ctx.next_every_committed = false
			assert(controller.start_paused() == false, "Startup cannot succeed without retained cadence")
			local all = recurring(ctx, false)
			assert(#all == 1 and all[1].cancelled and #recurring(ctx, true) == 0)
			assert(controller.status() ~= "active" and #ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("does not write native input from a reentrant timer constructor before READY", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every = scheduler.every
			local deliveries = 0
			scheduler.every = function(delay, fn)
				fn(); deliveries = deliveries + 1
				return every(delay, fn)
			end
			assert(controller.start_paused())
			assert(deliveries == 1, "Constructor must run at the actual pre-READY allocation boundary")
			assert(controller.status() == "starting" and #ctx.spawns[1].inputs == 0)
			ctx.chunk(1, "READY\n")
			assert(deliveries == 1 and controller.status() == "paused" and #ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("rolls back a timer whose constructor reentrantly stops its owning generation", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every = scheduler.every
			local calls = 0
			scheduler.every = function(delay, fn)
				local timer, committed = every(delay, fn)
				calls = calls + 1
				assert(controller.stop("constructor-stop"))
				return timer, committed
			end
			controller.start_paused()
			if calls == 0 then ctx.chunk(1, "READY\n") end
			assert(calls == 1 and #recurring(ctx, false) == 1)
			assert(#recurring(ctx, true) == 0, "Constructor return cannot publish a stopped generation timer")
			local count = #ctx.spawns[1].inputs
			recurring(ctx, false)[1].fn()
			assert(#ctx.spawns[1].inputs == count)
		end)
	end)

	helpers.it("rolls back a timer whose constructor replaces the current generation", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every = scheduler.every
			local first = true
			local original
			scheduler.every = function(delay, fn)
				local timer, committed = every(delay, fn)
				if first then
					first = false
					original = controller.token()
					assert(controller.stop("constructor-replace"))
					assert(controller.start_paused())
				end
				return timer, committed
			end
			controller.start_paused()
			if first then ctx.chunk(1, "READY\n") end
			assert(controller.token() ~= original and #ctx.spawns >= 2)
			ctx.chunk(2, "READY\n")
			assert(controller.status() == "paused" and #recurring(ctx, true) == 1,
				"Only the exact successor may retain its cadence")
			local all = recurring(ctx, false)
			assert(#all == 2)
			local old_count, new_count = #ctx.spawns[1].inputs, #ctx.spawns[2].inputs
			all[1].fn()
			assert(#ctx.spawns[1].inputs == old_count and #ctx.spawns[2].inputs == new_count)
		end)
	end)

	helpers.it("replays actual constructor READY only after one exact committed cadence", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every = scheduler.every
			local calls, successful, inside_phase = 0, 0, nil
			scheduler.every = function(delay, fn)
				calls = calls + 1
				assert(calls == 1, "READY cannot recursively construct another heartbeat timer")
				ctx.chunk(1, "READY\n")
				inside_phase = controller.status()
				assert(successful == 0, "Uncommitted allocation cannot publish successful readiness")
				return every(delay, fn)
			end
			controller.start_paused(function(ok) if ok then successful = successful + 1 end end)
			if calls == 0 then ctx.chunk(1, "READY\n") end
			assert(inside_phase == "starting" and successful == 1 and controller.status() == "paused")
			assert(calls == 1 and #recurring(ctx, true) == 1 and #ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("never publishes held constructor READY when the cadence commit is refused", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every = scheduler.every
			local calls, successful = 0, 0
			scheduler.every = function(delay, fn)
				calls = calls + 1
				assert(calls == 1, "Refused constructor READY must not allocate recursively")
				ctx.chunk(1, "READY\n")
				assert(successful == 0)
				local timer = every(delay, fn)
				return timer, false
			end
			controller.start_paused(function(ok) if ok then successful = successful + 1 end end)
			if calls == 0 then ctx.chunk(1, "READY\n") end
			assert(successful == 0 and controller.status() ~= "active" and controller.status() ~= "paused")
			assert(calls == 1 and #recurring(ctx, true) == 0 and #ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("discards held constructor READY after an exact reentrant STOP", function()
		support.with_fixture(function(load)
			local controller, ctx = load()
			controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every = scheduler.every
			local calls, successful = 0, 0
			scheduler.every = function(delay, fn)
				calls = calls + 1
				assert(calls == 1)
				ctx.chunk(1, "READY\n")
				assert(controller.stop("held-ready-stop"))
				return every(delay, fn)
			end
			controller.start_paused(function(ok) if ok then successful = successful + 1 end end)
			if calls == 0 then ctx.chunk(1, "READY\n") end
			assert(successful == 0 and #recurring(ctx, true) == 0)
			assert(ctx.spawns[1].inputs[1] == "STOP\n")
		end)
	end)
end)

helpers.describe("lease cadence retained READY transaction", function()
	helpers.it("preserves the original READY watchdog origin before delayed recurring construction", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local after, every = scheduler.after, scheduler.every
			local ready_at, ready_timer, calls, successful = nil, nil, 0, 0
			scheduler.after = function(delay, fn)
				local timer, committed = after(delay, fn)
				if delay == 4 then ready_at, ready_timer = ctx.clock, timer end
				return timer, committed
			end
			scheduler.every = function(delay, fn)
				calls = calls + 1;assert(ready_at == 0 and ready_timer and not ready_timer.cancelled)
				ctx.clock = 3.8;ctx.chunk(1, "READY\n")
				assert(successful == 0 and controller.status() == "starting" and not ready_timer.cancelled)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and ready_timer.cancelled and controller.status() == "paused")
		end)
	end)

	helpers.it("does not hide a malformed line after authentic held READY", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, calls, results = scheduler.every, 0, {}
			scheduler.every = function(delay, fn)
				calls = calls + 1;ctx.chunk(1, "READY\nBOGUS\n")
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) results[#results + 1] = ok end) == false)
			assert(calls == 1 and #results == 0 and controller.status() == "fencing")
			assert(#recurring(ctx, true) == 0 and #ctx.spawns == 2)
			ctx.complete(2, 0);assert(#results == 1 and results[1] == false)
		end)
	end)

	helpers.it("admits duplicate authentic held READY only once after commit", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, calls, successful = scheduler.every, 0, 0
			scheduler.every = function(delay, fn)
				calls = calls + 1;ctx.chunk(1, "READY\nREADY\n")
				assert(controller.status() == "starting" and successful == 0)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and #recurring(ctx, true) == 1)
			ctx.chunk(1, "READY\n");assert(successful == 1 and #recurring(ctx, false) == 1)
		end)
	end)

	helpers.it("preserves an inline READY during the original ACK constructor", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local after, every = scheduler.after, scheduler.every
			local ready_timer, calls, successful = nil, 0, 0
			scheduler.after = function(delay, fn)
				local timer, committed = after(delay, fn)
				if delay == 4 then ready_timer = timer;ctx.chunk(1, "READY\n") end
				return timer, committed
			end
			scheduler.every = function(delay, fn)
				calls = calls + 1;assert(successful == 0)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and ready_timer.cancelled)
			assert(controller.status() == "paused" and #recurring(ctx, true) == 1)
		end)
	end)

	helpers.it("keeps a recurring callback inert while authentic READY is held before commit", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, calls, successful = scheduler.every, 0, 0
			scheduler.every = function(delay, fn)
				calls = calls + 1;ctx.chunk(1, "READY\n");fn()
				assert(successful == 0 and controller.status() == "starting" and #ctx.spawns[1].inputs == 0)
				return every(delay, fn)
			end
			assert(controller.start_paused(function(ok) assert(ok);successful = successful + 1 end))
			assert(calls == 1 and successful == 1 and #ctx.spawns[1].inputs == 0)
		end)
	end)

	helpers.it("does not replay an old held READY over a STOP successor", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, first, successful, failed, successor = scheduler.every, true, 0, 0, 0
			scheduler.every = function(delay, fn)
				local timer, committed = every(delay, fn)
				if first then
					first = false;ctx.chunk(1, "READY\n");assert(controller.stop("held-replace"))
					assert(controller.start_paused(function(ok) assert(ok);successor = successor + 1 end))
				end
				return timer, committed
			end
			assert(controller.start_paused(function(ok) if ok then successful = successful + 1 else failed = failed + 1 end end) == false)
			assert(successful == 0 and failed == 1 and successor == 0 and controller.status() == "starting")
			ctx.chunk(2, "READY\n");assert(successor == 1 and controller.status() == "paused")
			ctx.chunk(1, "READY\n");assert(successful == 0 and successor == 1)
			local all = recurring(ctx, false);assert(#all == 2 and all[1].cancelled and not all[2].cancelled)
			local old, new = #ctx.spawns[1].inputs, #ctx.spawns[2].inputs;all[1].fn()
			assert(#ctx.spawns[1].inputs == old and #ctx.spawns[2].inputs == new)
		end)
	end)

	helpers.it("preserves authentic inline STOPPED and reinitialization cleanup debt after held READY", function()
		support.with_fixture(function(load)
			local controller, ctx = load();controller.init()
			local scheduler = package.loaded["adapters.timer_scheduler"]
			local every, retained, stopped, successful, failed = scheduler.every, nil, nil, 0, 0
			scheduler.every = function(delay, fn)
				local timer, committed = every(delay, fn);retained = timer
				ctx.chunk(1, "READY\n");ctx.next_input_chunk = "STOPPED\n"
				assert(controller.stop("held-inline-stop", function(ok) stopped = ok end))
				assert(stopped == true and controller.status() == "idle")
				ctx.cancel_target, ctx.cancel_failures = timer, 1
				assert(controller.init())
				return timer, committed
			end
			assert(controller.start_paused(function(ok) if ok then successful = successful + 1 else failed = failed + 1 end end) == false)
			assert(successful == 0 and failed == 1 and stopped == true and #ctx.spawns == 1)
			assert(retained.cancel_attempts == 1 and not retained.cancelled)
			assert(controller.init());assert(retained.cancel_attempts == 1)
			local inputs = #ctx.spawns[1].inputs;retained.fn();assert(#ctx.spawns[1].inputs == inputs)
			assert(controller.status() == "idle" and retained.cancelled and retained.cancel_attempts == 2)
		end)
	end)
end)
