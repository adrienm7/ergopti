local project = '/workspace/ergopti-diagnostic-report/static/ergopti_plus/'
local driver = project .. assert(arg[1])
package.path = driver .. '/?.lua;' .. driver .. '/?/init.lua;' .. driver .. '/tests/stubs/?.lua;'
	.. project .. '_shared/lua/?.lua;' .. project .. '_shared/lua/?/init.lua;' .. package.path
require('compat.utf8').install()
local helpers = require('tests.helpers')
helpers.set_only_filter('issue-report-corpus')
require('tests.unit.meta.test_corpus_diagnostics')
local results = helpers.get_results()
print(require('json').encode(results))
os.exit(results.failed == 0 and 0 or 1)
