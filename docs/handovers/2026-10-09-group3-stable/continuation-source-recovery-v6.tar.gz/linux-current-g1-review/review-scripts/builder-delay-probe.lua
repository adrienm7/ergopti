local helpers=require('tests.helpers')
local prompt=require('ui.text_prompt');local original_prompt=prompt.ask
local calls,seen=0
prompt.ask=function(title,text,initial)
 calls=calls+1;seen={title,text,initial};return nil
end
local provider=require('ui.menu.key_combinations');local original=provider.build
local received
provider.build=function(ctx,ui)received=ui;return original(ctx,ui)end
local ok,failure=pcall(function()
 local builder=require('ui.menu.menu_builder');local build
 for i=1,100 do
  local name,value=debug.getupvalue(builder.build,i)
  if name=='_build_shortcuts' then build=value;break end
  if not name then break end
 end
 assert(type(build)=='function')
 build({shortcuts={is_enabled=function()return false end,get_wrap_pairs=function()return{}end,
  is_wrap_on_type_enabled=function()return false end},is_paused=function()return false end})
 assert(type(received)=='table','actual builder must call the genuine pair provider')
 assert(type(received.prompt_delay)=='function','actual builder must supply the delay callback')
 assert(received.prompt_delay(150,100)==nil,'cancel remains cancel')
 assert(calls==1,'one actual UI-port observation, no retry')
 assert(seen[3]=='150','current explicit value enters the native prompt unchanged')
 assert(type(seen[1])=='string' and type(seen[2])=='string')
 assert(seen[2]:find('100',1,true),'declared Linux value enters the actual translated prompt')
end)
prompt.ask=original_prompt;provider.build=original
if not ok then error(failure,0)end
print('ACTUAL_BUILDER_DELAY_CALLBACK PASS')
