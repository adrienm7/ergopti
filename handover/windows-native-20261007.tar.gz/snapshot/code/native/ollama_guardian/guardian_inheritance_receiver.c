/* Optional root-owned kernel receiving control. No child is started. */
#include "source_channel.h"
#include <stdio.h>
#define CHECK(value) do {if(!(value)){fprintf(stderr,"FAIL native inheritance:%d: %s Win32=%lu\n",__LINE__,#value,(unsigned long)GetLastError());return 1;}} while(0)
int main(void) {
    const uint8_t digest[32]={1u};HANDLE handles[4];DWORD flags;size_t i;
    GSC_Owner *owner=GSC_Create(91u,1u,64u,digest);
    CHECK(owner!=NULL && GSC_FirstError(owner)==0u);
    CHECK(GSC_Inherited(owner,&handles[0],&handles[1],&handles[2],&handles[3]));
    CHECK(GSC_AcquireInheritance(owner,71u));
    CHECK(GSC_TryRetire(owner)==0);
    for(i=0u;i<4u;++i){CHECK(GetHandleInformation(handles[i],&flags));CHECK((flags&HANDLE_FLAG_INHERIT)!=0u);}
    puts("ok 1 - active native lease retains all original capabilities");
    CHECK(!GSC_ReleaseInheritance(owner,72u));
    for(i=0u;i<4u;++i){CHECK(GetHandleInformation(handles[i],&flags));CHECK((flags&HANDLE_FLAG_INHERIT)!=0u);}
    puts("ok 2 - foreign token cannot clear an original flag");
    CHECK(GSC_ReleaseInheritance(owner,71u));
    for(i=0u;i<4u;++i){CHECK(GetHandleInformation(handles[i],&flags));CHECK((flags&HANDLE_FLAG_INHERIT)==0u);}
    CHECK(!GSC_AcquireInheritance(owner,73u));
    CHECK(GSC_ReleaseInheritance(owner,71u));
    CHECK(GSC_TryRetire(owner)==1 && GSC_State(owner)==GSC_RETIRED);
    puts("ok 3 - exact reset permits once-only physical channel retirement");
    return 0;
}
