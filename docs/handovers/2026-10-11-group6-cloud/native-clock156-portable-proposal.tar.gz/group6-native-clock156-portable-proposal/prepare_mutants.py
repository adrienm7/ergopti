"""Prepare finite parser/context omissions only; never alter independent vectors."""
from pathlib import Path
import ast
import hashlib
import json

BASE=Path(__file__).resolve().parent
REL='static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py'
source=(BASE/'candidate'/REL).read_text()
loop='''    for index, sample in enumerate(samples):
        if (
            not finite_number(sample)
            or not before <= sample <= after
            or (index > 0 and sample < samples[index - 1])
        ):
            raise NativeClockRefused("Native clock epoch/order refused")
'''
endpoint='''    for sample in (samples[0], samples[-1]):
        if not finite_number(sample) or not before <= sample <= after:
            raise NativeClockRefused("Native clock epoch/order refused")
'''
variants={
    'endpoint_only': [(loop,endpoint)],
    'missing_exact_sixteen': [('        or len(fields["system_uptime"]) != 16\n','')],
    'missing_original_cap': [('        or after - before > 15\n','')],
    'unbounded_run_attempt': [('r"[1-9][0-9]{0,19}"','r"[1-9][0-9]*"'),('r"[1-9][0-9]{0,5}"','r"[1-9][0-9]*"')],
    'partial_epoch_optional': [('    if all(value is None for value in values):\n','    if any(value is None for value in values):\n')],
}
manifest={}
for label,replacements in variants.items():
    changed=source
    for before,after in replacements:
        assert changed.count(before)==1,(label,before)
        changed=changed.replace(before,after,1)
    ast.parse(changed)
    target=BASE/'mutants'/label/REL
    target.parent.mkdir(parents=True,exist_ok=True);target.write_text(changed)
    manifest[label]={'candidate_sha256':hashlib.sha256(source.encode()).hexdigest(),'mutant_sha256':hashlib.sha256(changed.encode()).hexdigest(),'replacements':replacements,'state':'UNRUN_EXPECT_ASSERTION_FAILURE_NO_ERROR_NO_SKIP'}
(BASE/'mutant-manifest.json').write_text(json.dumps({'qualification':'SOURCE_ONLY_UNRUN_CONTROLLED_OMISSIONS_NOT_CORPUS_REGEN','variants':manifest,'vectors':'candidate fixed13 helper unchanged in every variant','baseline':'physical143 previously passed independently; new13 not runnable against original client lacking clock functions; no false original-green credit'},indent=2)+'\n')
print(json.dumps({'variants':len(manifest),'qualification':'SOURCE_ONLY_UNRUN'},sort_keys=True))
