param([string]$Builder,[string]$Source,[string]$Build)
$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($Builder,[ref]$tokens,[ref]$errors)
if($errors.Count -ne 0){throw 'Canonical build owner parser refused.'}
$nodes=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Import-MsvcEnvironment'},$true))
if($nodes.Count -ne 1){throw 'Canonical compiler environment owner is absent or ambiguous.'}
Invoke-Expression $nodes[0].Extent.Text
Import-MsvcEnvironment
Push-Location -LiteralPath $Build
try{
 $argsList=@('/nologo','/Brepro','/TC','/std:c11','/W4','/WX','/wd5105','/O2','/MT','/guard:cf',('/I'+$Source),'/DERGOPTI_NAV_TESTING=1')
 foreach($name in @('nav_event_owner_test.c','capture_provenance_test.c','editor_replace_test.c','nav_event_owner.c','capture_provenance.c','editor_replace.c')){$argsList+=(Join-Path $Source $name)}
 $argsList+=@('/Fe:headless.exe','/link','/Brepro','/MACHINE:X64','/DYNAMICBASE','/NXCOMPAT','/guard:cf','user32.lib')
 & cl.exe @argsList
 if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
}finally{Pop-Location}
