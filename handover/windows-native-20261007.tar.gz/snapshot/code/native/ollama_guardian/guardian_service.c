#include "guardian_service.h"
#include <stdlib.h>
#include <string.h>

typedef struct GB_Row {
    uint64_t id;
    GB_Phase phase;
    DWORD first_error;
    uint32_t factory_attempted,activation_claimed,stop_requested;
    GF_Phase factory_phase;
    uint32_t intake_mode;
    uint8_t guardian_digest[32];
    GSC_Owner *source;
    GF_Owner *factory;
    struct GB_Row *next;
} GB_Row;
static GB_Row *GB_rows;
static uint64_t GB_last_id;
static uint64_t GB_last_inheritance;
static volatile LONG GB_busy;
_Static_assert(sizeof(GB_Status)==32u,"Guardian status wire layout");

static int GB_Enter(void) {
    if(InterlockedCompareExchange(&GB_busy,1,0)!=0){SetLastError(ERROR_BUSY);return 0;}
    return 1;
}
static void GB_Leave(void) { InterlockedExchange(&GB_busy,0); }
static GB_Row *GB_Find(uint64_t id) {
    GB_Row *row;
    if(id==0u)return NULL;
    for(row=GB_rows;row!=NULL;row=row->next)if(row->id==id)return row;
    return NULL;
}
static int GB_Error(GB_Row *row,DWORD error) {
    if(row!=NULL){
        if(row->first_error==ERROR_SUCCESS)row->first_error=error!=0u?error:ERROR_INVALID_DATA;
        row->phase=GB_DEBT;
    }
    SetLastError(error!=0u?error:ERROR_INVALID_DATA);return 0;
}
static void GB_Progress(GB_Row *row) {
    if(row->phase==GB_RETIRED)return;
    if(row->factory!=NULL){
        GF_Phase phase=GF_Poll(row->factory);
        row->factory_phase=phase;
        DWORD error=GF_FirstError(row->factory);
        if(error!=0u && row->first_error==0u)row->first_error=error;
        if(phase==GF_RETIRED)row->phase=GB_RETIRED;
        else if(phase==GF_RETAINED_DEBT)row->phase=GB_DEBT;
        else if(row->first_error!=0u)row->phase=GB_DEBT;
        else if(row->stop_requested || phase==GF_STOPPING)row->phase=GB_STOPPING;
        else if(phase==GF_READY)row->phase=GB_READY;
        return;
    }
    if(row->stop_requested){
        int retired=row->source!=NULL?GSC_TryRetire(row->source):1;
        if(retired==1)row->phase=GB_RETIRED;
        else if(retired<0)GB_Error(row,GSC_FirstError(row->source));
        return;
    }
    if(row->phase==GB_BOUND){
        if(GSC_Poll(row->source))row->phase=GB_OFFERED;
        else if(GSC_FirstError(row->source)!=0u)GB_Error(row,GSC_FirstError(row->source));
    }
}

static int GB_CreateMode(uint32_t intake_mode,uint32_t records,uint32_t paths,const uint8_t manifest[32],
                const uint8_t guardian[32],uint64_t *id) {
    GB_Row *row;
    if(id==NULL || manifest==NULL || guardian==NULL || records==0u || paths==0u)return 0;
    *id=0u;
    if(!GB_Enter())return 0;
    /* AHK's genuine caller represents IDs as signed Int64. Do not mint an
       unreachable high-bit ID or wrap/reuse a retired registry row. */
    if(GB_last_id==(uint64_t)INT64_MAX){GB_Leave();SetLastError(ERROR_ARITHMETIC_OVERFLOW);return 0;}
    row=calloc(1u,sizeof(*row));
    if(row==NULL){GB_Leave();SetLastError(ERROR_NOT_ENOUGH_MEMORY);return 0;}
    row->id=++GB_last_id;row->intake_mode=intake_mode;row->next=GB_rows;GB_rows=row;*id=row->id;
    memcpy(row->guardian_digest,guardian,32u);
    /* Publish the row before any channel/kernel acquisition. Even partial
       constructor failure returns this owned ID for stop/physical retirement. */
    row->source=GSC_Create(row->id,records,paths,manifest);
    if(row->source==NULL || GSC_FirstError(row->source)!=0u)
        GB_Error(row,row->source!=NULL?GSC_FirstError(row->source):ERROR_NOT_ENOUGH_MEMORY);
    GB_Leave();return 1;
}

int GB_Create(uint32_t records,uint32_t paths,const uint8_t manifest[32],const uint8_t guardian[32],uint64_t *id) {
    return GB_CreateMode(0u,records,paths,manifest,guardian,id);
}
int GB_CreateIntake(uint32_t records,uint32_t paths,const uint8_t manifest[32],const uint8_t guardian[32],uint64_t *id) {
    return GB_CreateMode(1u,records,paths,manifest,guardian,id);
}
int GB_IntakeHasContainment(uint64_t id) {
    GB_Row *row;int result=0;
    if(!GB_Enter())return 0;row=GB_Find(id);
    if(row!=NULL && row->intake_mode)result=GF_HasIntakeContainment(row->factory);
    GB_Leave();return result;
}
int GB_IntakeMatchInventory(uint64_t id,const GI_Expected *expected,size_t count) {
    GB_Row *row;const GI_Expected *actual;size_t n,i;int result=0;
    if(expected==NULL || !GB_Enter())return 0;row=GB_Find(id);
    if(row!=NULL && row->intake_mode && !row->stop_requested){
        GB_Progress(row);actual=GSC_Records(row->source,&n);
        if(actual!=NULL && n==count){
            result=1;
            for(i=0u;i<count;++i){
                if(actual[i].source_handle!=expected[i].source_handle || actual[i].kind!=expected[i].kind ||
                    actual[i].volume!=expected[i].volume || actual[i].index!=expected[i].index ||
                    actual[i].path_units!=expected[i].path_units || memcmp(actual[i].sha256,expected[i].sha256,32u)!=0 ||
                    memcmp(actual[i].native_path,expected[i].native_path,expected[i].path_units*sizeof(uint16_t))!=0){result=0;break;}
            }
        }
    }
    GB_Leave();return result;
}
int GB_IntakeConfirmInventory(uint64_t id,const GI_Expected *expected,size_t count,size_t root,size_t intake) {
    GB_Row *row;int result=0;
    if(expected==NULL || root>=count || intake>=count || !GB_Enter())return 0;row=GB_Find(id);
    if(row!=NULL && row->intake_mode && row->factory!=NULL && !row->stop_requested){
        GB_Progress(row);
        if(row->phase==GB_READY && row->first_error==0u)
            result=GF_ConfirmIntakeDirectory(row->factory,&expected[root],&expected[intake]);
    }
    GB_Leave();return result;
}
int GB_IntakeReleaseSource(uint64_t id) {
    GB_Row *row;int result=0;
    if(!GB_Enter())return 0;row=GB_Find(id);
    if(row!=NULL && row->intake_mode && row->factory!=NULL && row->activation_claimed && !row->stop_requested){
        GB_Progress(row);
        if(row->phase==GB_READY && row->first_error==0u)result=GF_ReleaseIntakeSource(row->factory);
    }
    GB_Leave();return result;
}
int GB_Inherited(uint64_t id,HANDLE *map,HANDLE *ready,HANDLE *release,HANDLE *parent) {
    GB_Row *row;int result=0;
    if(!GB_Enter())return 0;
    row=GB_Find(id);
    if(row!=NULL && row->phase==GB_SOURCE)result=GSC_Inherited(row->source,map,ready,release,parent);
    GB_Leave();return result;
}
int GB_AcquireInheritance(uint64_t id,uint64_t *token) {
    GB_Row *row;int result=0;uint64_t next;
    if(token==NULL)return 0;
    *token=0u;if(!GB_Enter())return 0;row=GB_Find(id);
    if(row!=NULL && row->phase==GB_SOURCE && !row->stop_requested &&
        !GSC_InheritanceUsed(row->source) && GB_last_inheritance<(uint64_t)INT64_MAX){
        next=++GB_last_inheritance;
        result=GSC_AcquireInheritance(row->source,next);
        /* Partial acquisition returns its exact token, including native refusal. */
        *token=GSC_InheritanceToken(row->source);
        if(!result)GB_Error(row,GSC_FirstError(row->source));
    }
    GB_Leave();return result;
}
int GB_ReleaseInheritance(uint64_t id,uint64_t token) {
    GB_Row *row;int result=0;
    if(!GB_Enter())return 0;row=GB_Find(id);
    if(row!=NULL && token!=0u && token==GSC_InheritanceToken(row->source)){
        result=GSC_ReleaseInheritance(row->source,token);
        if(!result)GB_Error(row,GSC_FirstError(row->source));
    }
    GB_Leave();return result;
}
int GB_Bind(uint64_t id,HANDLE process) {
    GB_Row *row;int result=0;
    if(!GB_Enter())return 0;
    row=GB_Find(id);
    if(row!=NULL && row->phase==GB_SOURCE && process!=NULL){
        result=GSC_Bind(row->source,process);
        if(result)row->phase=GB_BOUND;else GB_Error(row,GSC_FirstError(row->source));
    }
    GB_Leave();return result;
}
int GB_IntakeBindTransferredSource(uint64_t id,HANDLE source) {
    GB_Row *row;int result=0;if(!GB_Enter())return 0;row=GB_Find(id);
    if(row!=NULL && row->intake_mode && row->phase==GB_SOURCE && !row->stop_requested && row->first_error==0u && source!=NULL){
        result=GSC_BindTransferred(row->source,source);
        if(result)row->phase=GB_BOUND;else GB_Error(row,GSC_FirstError(row->source));
    }
    GB_Leave();return result;
}

int GB_BeginGuardian(uint64_t id,HANDLE job,HANDLE daemon,HANDLE source) {
    GB_Row *row;const GI_Expected *members;
    const wchar_t *image=NULL;
    size_t count=0u,i;
    uint32_t matches=0u;DWORD pid;
    FILETIME creation,exit_time,kernel,user;
    int result=0;
    if(!GB_Enter())return 0;
    row=GB_Find(id);
    if(row==NULL || row->phase!=GB_OFFERED || row->factory_attempted || row->stop_requested)goto done;
    row->factory_attempted=1u;
    { HANDLE retained=GSC_Source(row->source);FILETIME expected,ex,k,u;
      if(source==NULL || retained==NULL || GetProcessId(source)!=GetProcessId(retained)){
          GB_Error(row,ERROR_INVALID_DATA);goto done;
      }
      if(!GetProcessTimes(source,&creation,&exit_time,&kernel,&user) ||
          !GetProcessTimes(retained,&expected,&ex,&k,&u)){
          GB_Error(row,GetLastError());goto done;
      }
      if(CompareFileTime(&creation,&expected)!=0){GB_Error(row,ERROR_INVALID_DATA);goto done;}
    }
    members=GSC_Records(row->source,&count);
    if(members==NULL){GB_Error(row,ERROR_INVALID_DATA);goto done;}
    for(i=0u;i<count;++i)if(members[i].kind==0u && memcmp(members[i].sha256,row->guardian_digest,32u)==0){
        image=(const wchar_t *)members[i].native_path;matches++;
    }
    if(matches!=1u || image==NULL || job==NULL || daemon==NULL){GB_Error(row,ERROR_INVALID_DATA);goto done;}
    pid=GetProcessId(daemon);
    if(pid==0u){GB_Error(row,GetLastError());goto done;}
    if(!GetProcessTimes(daemon,&creation,&exit_time,&kernel,&user)){GB_Error(row,GetLastError());goto done;}
    row->factory=row->intake_mode?GF_BeginIntake(row->id,row->source,job,daemon,pid,&creation,image):GF_Begin(row->id,row->source,job,daemon,pid,&creation,image);
    if(row->factory==NULL){GB_Error(row,ERROR_NOT_ENOUGH_MEMORY);goto done;}
    row->phase=GB_HOST;GB_Progress(row);result=1;
done:
    GB_Leave();return result;
}
int GB_Poll(uint64_t id,GB_Status *status) {
    GB_Row *row;
    if(status==NULL || !GB_Enter())return 0;
    row=GB_Find(id);
    if(row==NULL){GB_Leave();return 0;}
    GB_Progress(row);
    memset(status,0,sizeof(*status));status->id=row->id;status->phase=(uint32_t)row->phase;
    status->first_error=row->first_error;
    status->source_phase=(uint32_t)GSC_State(row->source);
    status->factory_phase=(uint32_t)row->factory_phase;
    status->activation_claimed=row->activation_claimed;
    GB_Leave();return 1;
}
int GB_ClaimActivation(uint64_t id) {
    GB_Row *row;int result=0;
    if(!GB_Enter())return 0;
    row=GB_Find(id);
    if(row!=NULL){
        GB_Progress(row);
        if(row->phase==GB_READY && row->first_error==0u && !row->stop_requested && !row->activation_claimed){
            row->activation_claimed=1u;result=1;
        }
    }
    GB_Leave();return result;
}
int GB_Stop(uint64_t id) {
    GB_Row *row;int result=0;
    if(!GB_Enter())return 0;
    row=GB_Find(id);
    if(row!=NULL && row->phase!=GB_RETIRED){
        if(!row->stop_requested){
            row->stop_requested=1u;
            if(row->factory!=NULL)result=GF_RequestStop(row->factory);
            else if(row->source!=NULL && !row->intake_mode)result=GSC_RequestSourceRelease(row->source);
            else result=1;
            if(!result)GB_Error(row,row->factory!=NULL?GF_FirstError(row->factory):GSC_FirstError(row->source));
        }
        GB_Progress(row);
    }
    GB_Leave();return result;
}
