"""Read-only provenance, original-body, typed declaration and LF verification."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tomllib

repo=Path('/workspace/ergopti')
v1=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v1/freeze')
v2=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v2/freeze')
r=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-public-join-v2-independent')
sha=lambda content:hashlib.sha256(content).hexdigest()
source='cbb0efd431752da5ec8ccf38029463a76bb4ee55'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
pairs=json.loads((v1/'source-pairs.json').read_text())
joins=[]
for row in pairs:
 path=row['path'];post=(v1/'candidate'/path).read_bytes()
 assert sha(post)==row['post_sha256']
 assert b'\r' not in post,path
 if row['pre_sha256'] is not None:
  original=subprocess.check_output(['git','show',source+':'+path],cwd=repo)
  assert sha(original)==row['pre_sha256']
  assert original==(v1/'preimages'/path).read_bytes()
  current=subprocess.check_output(['git','show',head+':'+path],cwd=repo)
  joins.append({'path':path,'cbb_preimage_exact':True,'observed_HEAD':head,'HEAD_matches_preimage':sha(current)==row['pre_sha256'],'HEAD_sha256':sha(current)})
 else:
  joins.append({'path':path,'new_path':True,'observed_HEAD':head})
for row in json.loads((v2/'receipt.json').read_text())['source_pairs']:
 path=row['path'];pre=(v2/'preimages'/path).read_bytes();post=(v2/'candidate'/path).read_bytes()
 assert pre==(v1/'candidate'/path).read_bytes()
 assert sha(pre)==row['pre_sha256'] and sha(post)==row['post_sha256']
 assert b'\r' not in post
 if '/tests/' in path:assert post.startswith(pre)

# Parse block structure while ignoring comments/quoted strings. Every original
# registered callback body must appear in the same order without byte changes.
tokens=re.compile(r'--\[(=*)\[.*?\]\1\]|--[^\n]*|\[(=*)\[.*?\]\2\]|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\b[A-Za-z_][A-Za-z_0-9]*\b',re.S)
def bodies(text):
 result=[]
 for match in re.finditer(r'helpers\.it\s*\(',text):
  stream=list(tokens.finditer(text,match.end()))
  first=next(i for i,token in enumerate(stream) if token.group()=='function')
  begin=stream[first].start();stack=[]
  for token in stream[first:]:
   value=token.group()
   if value in ['function','if','repeat']:stack.append(value)
   elif value in ['for','while']:stack.append('await_do')
   elif value=='do':
    if stack and stack[-1]=='await_do':stack[-1]='do'
    else:stack.append('do')
   elif value in ['end','until']:
    assert stack
    stack.pop()
    if not stack:result.append(text[begin:token.end()]);break
 return result
preserved=[]
for row in pairs:
 path=row['path']
 if '/tests/unit/' not in path or row['pre_sha256'] is None:continue
 old=(v1/'preimages'/path).read_text();target=v2/'candidate'/path
 new=(target if target.exists() else v1/'candidate'/path).read_text()
 originals=bodies(old);post=bodies(new);position=0
 for body in originals:
  at=next(i for i in range(position,len(post)) if post[i]==body);position=at+1
 position=0;assertions=[line for line in old.splitlines() if 'helpers.assert_' in line]
 for line in assertions:position=new.index(line,position)+len(line)
 preserved.append({'path':path,'original_callback_count':len(originals),'post_callback_count':len(post),'original_assert_lines':len(assertions),'all_original_callback_bodies_exact_ordered':True,'all_original_assert_lines_exact_ordered':True,'original_body_sha256':[sha(body.encode()) for body in originals]})
runtime_path='static/ergopti_plus/linux/tests/unit/modules/test_key_combinations.lua'
runtime_packet=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-simultaneous-runtime-v2')
old_runtime=(runtime_packet/'candidate'/runtime_path).read_bytes()
assert (v2/'candidate'/runtime_path).read_bytes().startswith(old_runtime)
new_runtime=(v2/'candidate'/runtime_path).read_bytes()
old_v1=(v1/'candidate'/runtime_path).read_bytes()
assert new_runtime.startswith(old_v1)

manifest=tomllib.loads((v1/'candidate/static/ergopti_plus/_shared/modules/features/manifest.toml').read_text())
features=manifest['features']['mod_combos']
for key,kind,value in [('simultaneous_threshold_ms','number',100),('symmetric','boolean',False)]:
 rows=[entry for entry in features if entry['id']==key and 'linux' in entry.get('platforms',[])]
 assert len(rows)==1 and rows[0]['platforms']==['linux']
 assert rows[0]['type']==kind and type(rows[0]['default']) is type(value) and rows[0]['default']==value
 assert type(rows[0]['recommended']) is type(value) and rows[0]['recommended']==value
 assert rows[0]['input_altering'] is False
original_manifest=tomllib.loads((v1/'preimages/static/ergopti_plus/_shared/modules/features/manifest.toml').read_text())
# G1 Source44 is the actual About/LLM/slot-frame incoming union, rather than a
# guessed action id. Preserve every unrelated menu section, with a real floor.
original_menu=original_manifest['menu'];current_menu=manifest['menu']
unchanged_sections=[key for key in original_menu if key!='key_combinations_group']
assert len(unchanged_sections)>100
for key in unchanged_sections:assert original_menu[key]==current_menu[key],key
for key in ['llm_native_parent','llm_profile_parent_ahk','llm_backend_parent_ahk','slot_binding_frame','slot_binding_clear_frame']:
 assert key in original_menu and original_menu[key]==current_menu[key],key
assert next(row for row in original_menu['top_level'] if row.get('id')=='about')['type']=='group'
builder='static/ergopti_plus/linux/ui/menu/menu_builder.lua'
old=(v1/'preimages'/builder).read_text();new=(v1/'candidate'/builder).read_text()
def function_body(text,name):
 match=re.search(r'local function '+re.escape(name)+r'\(',text);assert match,name
 stream=list(tokens.finditer(text,match.start()));stack=[]
 for token in stream:
  value=token.group()
  if value in ['function','if','repeat']:stack.append(value)
  elif value in ['for','while']:stack.append('await_do')
  elif value=='do':
   if stack and stack[-1]=='await_do':stack[-1]='do'
   else:stack.append('do')
  elif value in ['end','until']:
   assert stack
   stack.pop()
   if not stack:return text[match.start():token.end()]
 raise AssertionError(name)
source44_functions=['slot_binding_rows','about_dense','about_source','about_parent_unchanged','_build_about']
for name in source44_functions:assert function_body(old,name)==function_body(new,name),name
schema=json.loads((v1/'candidate/static/ergopti_plus/_shared/core/config_schema/config.schema.json').read_text())
properties=schema['properties']['mod_combos']['properties']
assert properties['enabled']['type']=='boolean'
assert properties['simultaneous_threshold_ms']=={'type':'number','exclusiveMinimum':0}
assert properties['symmetric']['type']=='boolean'
assert schema['properties']['mod_combos']['additionalProperties'] is True
assert properties['config']['additionalProperties']['additionalProperties'] is True
result={'kind':'READ_ONLY_SOURCE_PRESERVATION','source_preimages':joins,'original_tests':preserved,
 'runtime189_prefix_byte_exact':True,'public199_prefix_byte_exact':True,
 'runtime_original425_assertion_prefix_preserved_via_whole_bytes':True,
 'linux_declared_100ms_and_false_exactly_once':True,'incoming_G1_Source44_preserved':True,
 'G1_unchanged_menu_section_count':len(unchanged_sections),'G1_exact_function_bodies':source44_functions,
 'schema_future_leaves_preserved':True,'changed_source_LF':True,'native_kernel':'UNRUN'}
(r/'independent-preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print('19 V1 preimages; 3 exact V2 successors; original test bodies/assertions; declared 100ms/false; G1 and LF: PASS')
print([(x['path'].split('/')[-1],x['original_callback_count'],x['post_callback_count'],x['original_assert_lines']) for x in preserved])
print('Current HEAD join mismatches:',[x['path'] for x in joins if x.get('HEAD_matches_preimage') is False])
