"""Complete focused replay after adding the original independent corpus fixture."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

review = Path('/workspace/.ergopti-cloud/reviews/group3-linux93-public-join-v2-independent')
projection = review / 'projection'
root = projection / 'candidate/static/ergopti_plus'
repo = Path('/workspace/ergopti')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
relative = 'static/ergopti_plus/_shared/tests/corpus/tap_hold/key_combination_chords.json'
fixture = projection / 'candidate' / relative
fixture.parent.mkdir(parents=True, exist_ok=True)
assert not fixture.exists()
fixture.write_bytes(subprocess.check_output(['git', 'show', 'cbb0efd431752da5ec8ccf38029463a76bb4ee55:' + relative], cwd=repo))
(review / 'supplemental-corpus-pin.json').write_text(json.dumps({'source': 'cbb0efd431752da5ec8ccf38029463a76bb4ee55', 'path': relative, 'sha256': sha(fixture), 'original_harness_failure': 'luajit-shared-copy.log; missing original fixture, no product assertions executed', 'regenerated': False}, indent=2) + '\n')
results = json.loads((review / 'results.json').read_text())
environment = dict(os.environ, TMPDIR='/tmp', PYTHONDONTWRITEBYTECODE='1')
def run(abi, case, module, variant=None, expected=0):
    command = ['/workspace/.ergopti-cloud/bin/' + abi, str(review / 'run.lua'), str(projection), module]
    if variant is not None:
        command.append(str(review / 'variants' / variant))
    process = subprocess.run(command, cwd=root / 'linux', env=environment, capture_output=True, timeout=60)
    log = review / (abi + '-' + case + '.log')
    assert not log.exists(), log
    log.write_bytes(process.stdout + process.stderr)
    summaries = [line for line in process.stdout.decode(errors='replace').splitlines() if line.startswith('INDEPENDENT_PUBLIC93 ')]
    row = {'abi': abi, 'case': case, 'exit': process.returncode, 'summary': summaries[-1:], 'command': command, 'log_sha256': sha(log)}
    results.append(row)
    (review / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(abi, case, row['exit'], row['summary'], flush=True)
    assert row['exit'] == expected and row['summary'], row
for abi in ['luajit', 'lua5.4']:
    if abi == 'lua5.4':
        for case, module in [('candidate', 'tests.unit.modules.test_key_combinations'),
                             ('scope', 'tests.unit.infra.test_key_combinations_scope'),
                             ('menu', 'tests.unit.ui.test_key_combinations_menu'),
                             ('global', 'tests.unit.infra.test_global_shortcuts_pair_scope')]:
            run(abi, case, module)
    run(abi, 'shared-copy-closed-fixture', 'original-shared-copy')
    variants = Path('/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v2/freeze/variants')
    for variant in sorted(path.name for path in variants.iterdir() if path.is_dir()):
        run(abi, variant, 'tests.unit.modules.test_key_combinations', variant, 1)
    for case, module in [('old_local_scope','tests.unit.infra.test_key_combinations_scope'),
                         ('old_global_scope','tests.unit.infra.test_global_shortcuts_pair_scope'),
                         ('copy_wrong_namespace','tests.unit.infra.test_key_combinations_scope'),
                         ('native_receiver_filter_omitted','tests.unit.infra.test_key_combinations_scope'),
                         ('future_pair_filter_omitted','tests.unit.infra.test_global_shortcuts_pair_scope')]:
        run(abi, case, module, case, 1)
pins = json.loads((review / 'source-pins.json').read_text())
for relative, expected in pins['projection'].items():
    assert sha(projection / relative) == expected, relative
assert sha(fixture) == json.loads((review / 'supplemental-corpus-pin.json').read_text())['sha256']
for name, wanted in [('group3-linux93-public-join-v1','3da5ab41a31cf1176a39552c51fe5fe21a8738a6bfe1b5ff36eddbe858cb684d'),
                     ('group3-linux93-public-join-v2','b641ef20792023aafc2c5ece36e1043a90a134b935a5b1a0a3c4592a063ff5d0')]:
    packet = Path('/workspace/.ergopti-cloud/preparations') / name / 'freeze'
    assert sha(packet / 'receipt.json') == wanted
    for relative, expected in json.loads((packet / 'receipt.json').read_text())['artifacts'].items():
        assert sha(packet / relative) == expected, relative
print('SOURCE_AND_FROZEN_PACKETS_UNCHANGED', flush=True)
