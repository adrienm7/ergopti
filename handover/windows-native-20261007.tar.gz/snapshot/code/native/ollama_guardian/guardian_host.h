#ifndef ERGOPTI_GROUP4_GUARDIAN_HOST_H
#define ERGOPTI_GROUP4_GUARDIAN_HOST_H
#include "guardian_win32.h"
#include <stdint.h>
#include <stddef.h>

#define GH_CONFIG_MAGIC 0x47484831u
typedef struct {
    uint32_t magic, bytes;
    uint64_t id;
    uint64_t job,parent,setup,stop,ready,notice;
    uint32_t parent_pid,daemon_pid,record_count,path_units;
    FILETIME parent_creation,daemon_creation;
} GH_Config;
typedef struct {
    uint64_t handle;
    uint32_t volume,index_high,index_low,kind,path_offset,path_units;
} GH_Record;
typedef struct {
    uint32_t magic,pid;
    uint64_t id;
    FILETIME creation;
    volatile LONG ready,retired,phase;
    uint32_t first_error,first_os_error;
} GH_Notice;
int GH_Run(HANDLE);
#endif
