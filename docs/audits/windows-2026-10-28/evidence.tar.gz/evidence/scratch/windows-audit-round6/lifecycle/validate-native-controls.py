from pathlib import Path
import sys,re,json,hashlib
repo=Path(sys.argv[1]).resolve();packet=Path(__file__).parent;worker=packet.parent/'verification-worker'
identifier='187-lifecycle-native-controls-green'
receipt=json.loads((worker/'receipts'/(identifier+'-exit.json')).read_text())
assert receipt['exit_code']==0 and not receipt.get('cancelled') and receipt['cwd']==str(repo),'Native owner cohort did not qualify this checkout'
tap=worker/(identifier+'.tap');assert tap.stat().st_size<16*1024*1024
text=tap.read_text(encoding='utf-8-sig');expected=(packet/'native-controls-all.txt').read_text().splitlines()
assert len(expected)==46 and len(set(expected))==46
assert re.findall(r'^1\.\.(\d+)$',text,re.M)==['46']
results=re.findall(r'^(not ok|ok) (\d+) - ([^\r\n]+)$',text,re.M)
assert len(results)==46 and all(x[0]=='ok' for x in results)
assert [int(x[1]) for x in results]==list(range(1,47))
names=[x[2] for x in results]
assert len(set(names))==46 and set(names)==set(expected),'Actual native case coverage differs from exact whole-owner list'
running=re.findall(r'^RUNNING (\d+)/(\d+) - ([^\r\n]+)$',text,re.M)
assert [(int(x[0]),int(x[1]),x[2]) for x in running]==[(i,46,n) for i,n in enumerate(names,1)],'Native RUNNING/results are inconsistent'
assert list(map(int,re.findall(r'^# duration_ms (\d+) ',text,re.M)))==list(range(1,47))
for name,digest in json.loads((packet/'native-controls-qualified-hashes.json').read_text()).items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,'Qualified native source changed: '+name
print('Actual46/46 native owner cases and exact4 qualified source bytes validated; nativeWindows CI/fullsuite remain integration work.')
