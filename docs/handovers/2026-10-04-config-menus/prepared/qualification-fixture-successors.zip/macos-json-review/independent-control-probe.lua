local root = arg[1]
package.path = root .. "/static/ergopti_plus/macos/?.lua;" .. root .. "/static/ergopti_plus/macos/?/init.lua;" .. package.path
local hs = require("tests.stubs.hs")
local decode = hs.json.decode
local escaped = decode([["\b\f\n\r\t"]])
assert(escaped == string.char(8, 12, 10, 13, 9), "JSON standard short controls must decode to prescribed bytes")
print("PASS short controls")
assert(decode([["\\b\\f"]]) == "\\b\\f", "escaped backslash must preserve literal letter")
print("PASS literal backslashes")
local tree = decode([[{"\b":"\f","children":["\b","\f"]}]])
assert(tree[string.char(8)] == string.char(12) and tree.children[1] == string.char(8) and tree.children[2] == string.char(12))
print("PASS object keys and nested values")
local equal = decode([[ [{"value":"\b"},{"value":"\b"},{"value":"\f"}] ]])
assert(rawequal(equal[1], equal[2]) and not rawequal(equal[1], equal[3]), "native-shaped dictionary interning remains exact")
print("PASS alias identity")
