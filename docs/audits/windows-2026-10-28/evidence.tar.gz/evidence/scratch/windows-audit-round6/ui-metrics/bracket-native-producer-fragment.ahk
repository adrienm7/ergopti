﻿; Private native producer observation; no tracked source is edited.
_R6B_Events(Scalars) {
	Events := []
	for Scalar in Scalars
		Events.Push([Scalar, 100, Map("st", "none")])
	return Events
}
_R6B_Run(Scalars) {
	KLW.ctx := Map()
	KLW_ResetBatch()
	KLW_WalkTypingEntry(Map("timestamp", "2026-10-26 12:00:00.000",
		"app", "bracket-probe.exe", "events", _R6B_Events(Scalars)))
}
_R6B_LiteralQuadgrams() {
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	try {
		for Token in ["[ab]", "[BS]"] {
			_R6B_Run(StrSplit(Token))
			Key := "2026-10-26" . Chr(1) . "bracket-probe.exe" . Chr(1) . Token
			Rows := KLW.batch["ngram"]["ngram_quadgrams"]
			AssertTrue(Rows.Has(Key), "four separately typed literal scalars must produce their raw four-gram")
			AssertEqual(1, Rows[Key]["c"])
			FileAppend("NATIVE_LITERAL_QG " . JsonStringLiteral(Token) . " count=" . Rows[Key]["c"] . "`n", "*")
		}
		_R6B_Run(["a", "b", "[BS]", "c"])
		Key := "2026-10-26" . Chr(1) . "bracket-probe.exe" . Chr(1) . "ab[BS]c"
		Rows := KLW.batch["ngram"]["ngram_quadgrams"]
		AssertTrue(Rows.Has(Key), "an interior real Backspace followed by a scalar produces a native four-gram")
		AssertEqual(1, Rows[Key]["c"])
		FileAppend("NATIVE_BS_INTERIOR_QG count=" . Rows[Key]["c"] . "`n", "*")
	} finally {
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
	}
}
Test("audit: native bracket scalar sequences retain four-gram identity (r6-bracket-native-producer)",
	_R6B_LiteralQuadgrams)
_R6B_AmbiguousSixgrams() {
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	try {
		Key := "2026-10-26" . Chr(1) . "bracket-probe.exe" . Chr(1) . "[BS][BS]x"
		for Events in [["[", "B", "S", "]", "[BS]", "x"], ["[BS]", "[", "B", "S", "]", "x"]] {
			_R6B_Run(Events)
			Rows := KLW.batch["ngram"]["ngram_hexagrams"]
			AssertTrue(Rows.Has(Key), "distinct six-event histories must be inspected against the exact stored token")
			AssertEqual(1, Rows[Key]["c"])
			FileAppend("NATIVE_AMBIGUOUS_HX events=" . JsonStringLiteral(Events[1])
				. " token=" . JsonStringLiteral("[BS][BS]x") . " count=" . Rows[Key]["c"] . "`n", "*")
		}
	} finally {
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
	}
}
Test("audit: flat bracket marker keys alias distinct six-event histories (r6-bracket-native-producer)",
	_R6B_AmbiguousSixgrams)
