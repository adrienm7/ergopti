"""Prepare bounded postinstall72 from retained postinstall70, without R2 code."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
OUT=Path(__file__).resolve().parent
POST=Path('/workspace/ergopti-cloud/group6-postinstall-proposal')
COMPOSED=Path('/workspace/ergopti-cloud/group6-composed-trust-proposal')
TIME=Path('/workspace/ergopti-cloud/group6-timeout-capture-r2')
ROOT=Path('/workspace/ergopti')
WIRE=Path('static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py')
TEST=Path('tools/test/macos_native_http_receiving_facts_test.py')
RUFF=Path('/workspace/ergopti-cloud/python/bin/ruff')
assert subprocess.run([str(RUFF),'--version'],check=True,capture_output=True,text=True).stdout.strip()=='ruff 0.15.8'
if (OUT/'interaction_tests.py').exists():
 extra=(OUT/'interaction_tests.py').read_text()
else:
 extra=(COMPOSED/'interaction_tests.py').read_text()
 s= (TIME/'candidate'/TEST).read_text()
 cls=next(node for node in ast.parse(s).body if isinstance(node,ast.ClassDef) and node.name=='NativeTimedAddCancellationTests')
 method=next(node for node in cls.body if isinstance(node,ast.FunctionDef) and node.name=='actual_signal_handler')
 handler='    @staticmethod\n    '+ast.get_source_segment(s,method)+'\n\n'
 anchor='    def interrupted_installation(self, signum, actor):\n'
 assert extra.count(anchor)==1
 extra=extra.replace(anchor,handler+anchor,1).replace('NativeTimedAddCancellationTests.actual_signal_handler()','self.actual_signal_handler()')
 (OUT/'interaction_tests.py').write_text(extra)
manifest={'schema':1,'base':'5f7a8467c9696b26a75de104f6329b39c181b8cb','qualification':'SOURCE_ONLY_UNEXECUTED_NO_NATIVE_NO_ADOPTION','files':{},'all_original63_and_retained_postinstall7_test_helper_bodies_byte_exact':True,'no_r2_product_observation_or_test_cohort':True,'total_methods':72,'frozen_methods':70}
inverse={}
patch=''
def methods(source):
 result={}
 def walk(node,parents=()):
  path=parents+(node.name,) if isinstance(node,(ast.ClassDef,ast.FunctionDef)) else parents
  if isinstance(node,ast.FunctionDef): result['.'.join(path)]=ast.get_source_segment(source,node)
  for child in ast.iter_child_nodes(node): walk(child,path)
 walk(ast.parse(source))
 return result
for relative in (WIRE,TEST):
 preimage_path=OUT/'preimage'/relative
 frozen_path=OUT/'frozen'/relative
 before=(preimage_path if preimage_path.exists() else POST/'preimage'/relative).read_text()
 frozen=(frozen_path if frozen_path.exists() else POST/'candidate'/relative).read_text()
 if relative==WIRE:
  old='''        except Exception:
            if self.command_fact and self.command_fact["phase"] == "settle":
                # Unknown output cannot retire an unsettled query's authority.
'''
  new='''        except Exception as refused:
            # This new optional query must preserve the existing worker's exact
            # cancellation. Other settled query refusals remain observations.
            if (
                after_install
                and type(refused) is FixtureFailure
                and refused.args == ("Native fixture cancelled",)
            ):
                raise
            if self.command_fact and self.command_fact["phase"] == "settle":
                # Unknown output cannot retire an unsettled query's authority.
'''
  assert frozen.count(old)==1
  candidate=frozen.replace(old,new,1)
  assert candidate.replace(new,old,1)==frozen
 else:
  tail='\n\nif __name__ == "__main__":\n    unittest.main()\n'
  assert frozen.count(tail)==1
  candidate=frozen.replace(tail,'\n\n'+extra+tail,1)
  assert candidate.replace('\n\n'+extra+tail,tail,1)==frozen
 for role,value in [('preimage',before),('frozen',frozen),('candidate',candidate)]:
  target=OUT/role/relative
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_text(value)
 subprocess.run([str(RUFF),'format','--config',str(ROOT/'pyproject.toml'),str(OUT/'candidate'/relative)],check=True)
 candidate=(OUT/'candidate'/relative).read_text()
 a,b=methods(frozen),methods(candidate)
 excluded={'_observe_admin_trust'} if relative==WIRE else set()
 assert all(b[name]==body for name,body in a.items() if name.rsplit('.',1)[-1] not in excluded)
 if relative==WIRE:
  assert methods(before)['WireFixture._command']==b['WireFixture._command']
 else:
  assert sum(isinstance(node,ast.FunctionDef) and node.name.startswith('test') for node in ast.walk(ast.parse(candidate)))==72
  start=candidate.index('class NativePostInstallCancellationInteractionTests(unittest.TestCase):')-2
  end=candidate.index(tail,start)
  assert candidate[:start]+candidate[end:]==frozen
  start=candidate.index('class NativePostInstallTrustObservationTests(unittest.TestCase):')-2
  assert candidate[:start]+candidate[end:]==before
 old,new=before.splitlines(keepends=True),candidate.splitlines(keepends=True)
 spans=[]
 for kind,a,b,c,d in difflib.SequenceMatcher(a=old,b=new,autojunk=False).get_opcodes():
  if kind!='equal': spans.append({'old':''.join(old[a:b]),'new':''.join(new[c:d]),'start':c,'end':d})
 restored=new[:]
 for span in reversed(spans): restored[span['start']:span['end']]=span['old'].splitlines(keepends=True)
 assert ''.join(restored)==before
 inverse[str(relative)]=spans
 manifest['files'][str(relative)]={role:hashlib.sha256((OUT/role/relative).read_bytes()).hexdigest() for role in ('preimage','frozen','candidate')}
 patch+=''.join(difflib.unified_diff(before.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/'+str(relative),tofile='b/'+str(relative)))
registry=Path('tools/test/test-managed-ollama-protocol.cjs')
registry_preimage=OUT/'registry-activation/preimage'/registry
registry_before=(registry_preimage if registry_preimage.exists() else POST/'registry-activation/preimage'/registry).read_text()
old="cases.push(['tools/test/macos_native_http_receiving_facts_test.py', 63]);"
new=old.replace('63','72')
assert registry_before.count(old)==1
registry_after=registry_before.replace(old,new,1)
assert registry_after.replace(new,old,1)==registry_before
for role,value in [('preimage',registry_before),('candidate',registry_after)]:
 target=OUT/'registry-activation'/role/registry
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_text(value)
(OUT/'registry-activation/manifest.json').write_text(json.dumps({'schema':1,'path':str(registry),'preimage_sha256':hashlib.sha256(registry_before.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(registry_after.encode()).hexdigest(),'exact_count':72,'inverse_spans':1,'qualification':'PREPARED_EXACT_COUNT_ONLY_NO_ADOPTION_UNEXECUTED'},indent=2)+'\n')
(OUT/'registry-activation/activation.patch').write_text(''.join(difflib.unified_diff(registry_before.splitlines(keepends=True),registry_after.splitlines(keepends=True),fromfile='a/'+str(registry),tofile='b/'+str(registry))))
(OUT/'proposal.patch').write_text(patch)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'exact-inverse.json').write_text(json.dumps(inverse,indent=2)+'\n')
