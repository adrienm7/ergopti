#ifndef ERGOPTI_GROUP4_GUARDIAN_SERVICE_H
#define ERGOPTI_GROUP4_GUARDIAN_SERVICE_H
#include "guardian_factory.h"

typedef enum {
    GB_SOURCE=0,GB_BOUND=1,GB_OFFERED=2,GB_HOST=3,GB_READY=4,
    GB_STOPPING=5,GB_RETIRED=6,GB_DEBT=7
} GB_Phase;
typedef struct {
    uint64_t id;
    uint32_t phase,first_error,source_phase,factory_phase,activation_claimed,reserved;
} GB_Status;

/* These entry points are used only by the internal authenticated ShellRunner
   bridge. Caller keeps the module resident and serializes lifecycle requests.
   IDs are allocated by this registry and never reused. Lookups precede access.
   Four channel handles may be inherited only by the pinned source constructor;
   opaque task provenance is established by the AHK owner before this boundary. */
int GB_Create(uint32_t,uint32_t,const uint8_t[32],const uint8_t[32],uint64_t *);
/* Internal intake registry only: legacy Create and activation stay unchanged. */
int GB_CreateIntake(uint32_t,uint32_t,const uint8_t[32],const uint8_t[32],uint64_t *);
int GB_IntakeReleaseSource(uint64_t);
int GB_IntakeHasContainment(uint64_t);
int GB_IntakeBindTransferredSource(uint64_t,HANDLE);
int GB_IntakeMatchInventory(uint64_t,const GI_Expected *,size_t);
int GB_IntakeConfirmInventory(uint64_t,const GI_Expected *,size_t,size_t,size_t);
int GB_Inherited(uint64_t,HANDLE *,HANDLE *,HANDLE *,HANDLE *);
/* Both operations authenticate row and single-use server token. The source
   owner keeps originals resident until actual reset acknowledgements. */
int GB_AcquireInheritance(uint64_t,uint64_t *);
int GB_ReleaseInheritance(uint64_t,uint64_t);
int GB_Bind(uint64_t,HANDLE);
int GB_BeginGuardian(uint64_t,HANDLE,HANDLE,HANDLE);
int GB_Poll(uint64_t,GB_Status *);
int GB_ClaimActivation(uint64_t);
int GB_Stop(uint64_t);
#endif
