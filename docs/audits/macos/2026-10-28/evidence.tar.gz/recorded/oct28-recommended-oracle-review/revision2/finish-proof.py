from pathlib import Path
import os,subprocess,json,hashlib,time,datetime,re,stat
from zoneinfo import ZoneInfo
r=Path('/workspace/ergopti-macos-release-linux'); o=Path('/workspace/scratch/oct28-recommended-oracle-review/revision2');target=r/'tools/test/test-recommended-defaults-rule.cjs';base='ae73ed2f4d7b915e66b1628c057d346c456d91aa'
e=os.environ.copy();e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';e['USER']='agent';e['LOGNAME']='agent'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
def run(name,cmd,expected=0,reason=None):
 t=time.monotonic();(o/'active.json').write_text(json.dumps({'name':name,'command':cmd,'started_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()})+'\n')
 with(o/(name+'.log')).open('wb')as f:rc=subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 row={'name':name,'command':cmd,'actual_exit':rc,'expected_exit':expected,'seconds':round(time.monotonic()-t,3),'log':str(o/(name+'.log'))};rows.append(row);(o/'verification.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,rc,flush=True);assert rc==expected,row
 if reason:assert reason in(o/(name+'.log')).read_text(),name
 return row
assert git('rev-parse','HEAD')==base and git('diff','--cached','--name-only')=='tools/test/test-recommended-defaults-rule.cjs' and not git('diff','--name-only')
run('normal-precommit-hook-final',['sh','.husky/pre-commit'])
text=target.read_text();(o/'final-frozen-source.cjs').write_text(text)
execute=Path('/workspace/scratch/oct28-recommended-oracle-review/execute-text.cjs').read_text().replace('assert.equal(count, 11,','assert.equal(count, 22,')
(o/'execute-text.cjs').write_text(execute)
script=['node',str(o/'execute-text.cjs'),str(target)]
run('actual-fixed-with-negative-count',script+[str(target)],reason='"actual_negative_controls_executed":22')
old=subprocess.check_output(['git','show',base+':tools/test/test-recommended-defaults-rule.cjs'],cwd=r,text=True);(o/'old-original.cjs').write_text(old)
run('old-original',script+[str(o/'old-original.cjs')],1,'registers the Infos command')
old_pred=[x.split('register: ',1)[1]for x in old.splitlines()if 'register: /"gesture_recommended_info"'in x];assert len(old_pred)==1
lines=text.splitlines();ix=[i for i,x in enumerate(lines)if x.strip().startswith('/^')and'MenuCommand\\.GESTURE_RECOMMENDED_INFO'in x];assert len(ix)==1
old_lines=lines.copy();old_lines[ix[0]]='\t\t\t'+old_pred[0]
variants={
 'old-raw-predicate':('\n'.join(old_lines)+'\n','registers the Infos command'),
 'missing-registration-guard':(text.replace('assert.match(executable, owner.register, `${owner.file} registers the Infos command`);',''),'foreign command must fail the unchanged dialog contract'),
 'no-comment-boundary':(text.replace('const code = stripComments(source, extension);','const code = source;'),'block-comment binding must fail the unchanged dialog contract'),
 'no-string-boundary':(text.replace("if (token.kind !== 'string') continue;",'continue;'),'windows/ui/menu/menu_gestures.ahk string-only registration must fail the executable dialog contract')
}
for name,(data,reason)in variants.items():
 assert data!=text,name
 path=o/(name+'.cjs');path.write_text(data);run(name,script+[str(path)],1,reason)
for name,cmd in [('focused',['node','tools/test/test-recommended-defaults-rule.cjs']),('gen-check',['npm','run','-s','gen:check']),('format',['npm','run','-s','format:check']),('strict',['npm','run','-s','lint:conventions:strict']),('false-green',['node','tools/test/find-false-greens.cjs']),('ahk-locals',['npm','run','-s','test:ahk-local-same-as-global']),('windows-source',['node','tools/test/test-windows-updater-original-source.cjs']),('encoding',['node','tools/test/test-source-encoding.cjs']),('ahk-encoding',['npm','run','-s','test:ahk-encoding']),('undefined-lua',['node','tools/test/test-lua-undefined-globals.cjs']),('plan',['node','tools/test/verify-change.cjs','--plan'])]:run(name,cmd)
assert target.read_text()==text and not git('diff','--name-only')
patch=subprocess.check_output(['git','diff','--cached','--binary','--full-index'],cwd=r);(o/'final.patch').write_bytes(patch)
index_tree=git('write-tree');unchanged={}
for path in ['static/ergopti_plus','tools/ci','.github','tools/test/run-hs-tests.cjs','tools/test/run-linux-lua.cjs']:
 try:
  before=git('rev-parse',base+':'+path);after=git('rev-parse',index_tree+':'+path)
 except subprocess.CalledProcessError:
  if path.startswith('tools/test/'):continue
  raise
 assert before==after,path;unchanged[path]=before
bad=[];total=0;dig=hashlib.sha256()
for record in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=r).split(b'\0'):
 if not record:continue
 inf,path=record.split(b'\t',1);mode,oid,stage=inf.split();p=r/os.fsdecode(path);st=p.lstat();data=os.fsencode(os.readlink(p))if stat.S_ISLNK(st.st_mode)else p.read_bytes();observed=b'120000'if stat.S_ISLNK(st.st_mode)else(b'100755'if st.st_mode&0o111 else b'100644');actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()
 if mode!=observed or actual!=oid:bad.append(os.fsdecode(path))
 dig.update(mode+b' '+oid+b'\t'+path+b'\0');total+=1
assert not bad
receipt={'state':'FROZEN_REVIEW_READY','at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'base_commit':base,'base_tree':git('rev-parse','HEAD^{tree}'),'staged_tree':index_tree,'owned_paths':['tools/test/test-recommended-defaults-rule.cjs'],'full_patch':str(o/'final.patch'),'patch_sha256':sha(o/'final.patch'),'source_sha256':sha(target),'actual_negative_controls_executed':22,'known_lexical_decoy_controls':11,'new_audit_or_probes':False,'normal_hook_actual_exit':0,'quick_gates_actual0':11,'negative_variants_actual1':['old-original',*variants.keys()],'physical_files':total,'physical_stage_digest':dig.hexdigest(),'physical_mismatches':bad,'unchanged_subtrees':unchanged,'source_unstaged':git('diff','--name-only'),'source_untracked':git('ls-files','--others','--exclude-standard'),'verification_sha256':sha(o/'verification.json'),'full_suite_started':False,'commit_created':False,'pushed':False}
assert not receipt['source_untracked']
(o/'source-freeze.json').write_text(json.dumps(receipt,indent=2)+'\n');(o/'ready.json').write_text(json.dumps(receipt,indent=2)+'\n');(o/'active.json').unlink();print(json.dumps({'state':receipt['state'],'tree':index_tree,'patch_sha256':receipt['patch_sha256'],'ready_sha256':sha(o/'ready.json')}),flush=True)
