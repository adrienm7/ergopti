from pathlib import Path
import hashlib,json,subprocess,re,collections,shutil,tarfile
A=Path('/workspace/.ergopti-cloud/preparations/group3-linux-healthcheck-share-fixture-82a');B=Path('/workspace/.ergopti-cloud/reviews/linux-healthcheck-share-fixture-independent');B.mkdir(mode=0o700);repo=Path('/workspace/ergopti')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'receipt.json')=='3b14ef47c50fb9a0c0ab3c16145a98000fbb480d1530eb1e21d6c95b0482688a';r=json.loads((A/'receipt.json').read_text());pins=r['pins'];assert len(pins)==17
for row in pins:assert sha(A/row['path'])==row['sha256']
file=r['owned_path'];old=(A/'preimages'/file).read_bytes();new=(A/'candidate'/file).read_bytes();assert hashlib.sha256(old).hexdigest()==r['preimage_sha256'] and hashlib.sha256(new).hexdigest()==r['postimage_sha256'];assert b'\r' not in new
joins=[]
for spec in [r['source_commit']+':'+file,':'+file]:
 cp=subprocess.run(['git','show',spec],cwd=repo,stdout=subprocess.PIPE,check=True);assert cp.stdout==old;joins.append({'spec':spec,'sha256':hashlib.sha256(cp.stdout).hexdigest()})
assert (repo/file).read_bytes()==old
for row in json.loads((A/'dependencies.json').read_text()):
 assert sha(repo/row['path'])==row['sha256'];cp=subprocess.run(['git','show',r['source_commit']+':'+row['path']],cwd=repo,stdout=subprocess.PIPE,check=True);assert hashlib.sha256(cp.stdout).hexdigest()==row['sha256']
a=old.decode();b=new.decode();marker='\nhelpers.describe("diagnostics bridge (linux): sharing preview admission", function()';assert b.count(marker)==1;prefix=b[:b.index(marker)]
pattern=re.compile(r'\thelpers\.it\("([^"\n]+)", function\(\)\n')
def cases(source):
 ms=list(pattern.finditer(source));return [(m.group(1),source[m.start():ms[i+1].start() if i+1<len(ms) else len(source)]) for i,m in enumerate(ms)]
oldcases=cases(a);newcases=cases(prefix);assert len(oldcases)==14;assert [x[0] for x in oldcases]==[x[0] for x in newcases]
changed={'copies the redacted report','answers a refused clipboard as a failure'}
for before,after in zip(oldcases,newcases):
 if before[0] not in changed:assert before==after,before[0]
assert len(cases(b))==16
retarget='\t\t\thelpers.assert_eq(context.copied, { "at ~/x by <user>" })'
assert a.count(retarget)==1
oldasserts=collections.Counter(line for line in a.splitlines() if 'helpers.assert' in line);newasserts=collections.Counter(line for line in b.splitlines() if 'helpers.assert' in line);oldasserts[retarget]-=1;assert not (oldasserts-newasserts)
assert 'require("diagnostics.redact").apply("at /home/jdoe/x by jdoe",\n\t\t\t\tready.config.redaction, ready.config.context)' in b
assert 'helpers.assert_eq({ redacted }, { "at ~/x by <user>" })' in b
assert 'helpers.assert_eq(context.copied, { exported.share_text }, "Clipboard refusal follows the actual adapter call")' in b
schema=json.loads((repo/'static/ergopti_plus/_shared/modules/diagnostics/schema.json').read_text());assert schema['share_policy']['projection']['fields']['sections']['fields']['input']['fields']['paused']=={'kind':'boolean'}
assert 'current.share_text ~= exported.share_text' in b and 'refreshed.snapshot.sections.input.paused, true' in b
D=B/'roundtrip';out=D/file;out.parent.mkdir(parents=True);out.write_bytes(old);ops=[]
for reverse in [False,True]:
 for check in [True,False]:
  cmd=['git','apply','--whitespace=error']+(['-R'] if reverse else [])+(['--check'] if check else [])+[str(A/'source.patch')];cp=subprocess.run(cmd,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert cp.returncode==0,cp.stderr;ops.append({'reverse':reverse,'check':check,'exit':0})
 assert out.read_bytes()==(old if reverse else new)
for row in pins:assert sha(A/row['path'])==row['sha256']
for origin,name in [(A/'receipt.json','author-receipt.json'),(A/'dependencies.json','dependencies.json'),(A/'results.json','author-results.json'),(A/'source.patch','source.patch'),(A/'candidate'/file,'candidate.lua'),(A/'preimages'/file,'preimage.lua')]:shutil.copyfile(origin,B/name)
results={'classification':'INDEPENDENT_SOURCE_REVIEW_NO_SUITES_OR_NATIVE','preimage_joins':joins,'all17_author_pins':'UNCHANGED','twelve_other_original_case_bodies':'BYTE_EXACT','all14_original_cases':'RETAINED_IN_ORDER','two_new_cases':True,'one_original_literal_assertion':'RETARGETED_TO_GENUINE_REDACT_ORIGINAL_EXPECTATION','all_other_original_assertion_lines':'RETAINED_VERBATIM','deterministic_paused_share_projection':True,'seven_production_helper_policy_dependencies':'CURRENT_AND_GIT_EXACT','roundtrip':ops,'reviewer_runtime_suite_executed':False,'native_gui_clipboard':'UNRUN'}
(B/'source-review-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
