from pathlib import Path
import argparse, datetime, hashlib, json, subprocess
from zoneinfo import ZoneInfo

parser = argparse.ArgumentParser(description='Archive owned Git refs without changing them.')
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--expected-fix-sha', required=True)
parser.add_argument('--prerequisite', default='42acb5cdcf2c027925a672b94b30bcbc79bccc34')
args = parser.parse_args()
out = Path(__file__).resolve().parent
refs = ['refs/heads/fix/macos', 'refs/heads/macos/oct28-carrier-staleness-owner']
def git(*values):
    return subprocess.check_output(['git', *values], cwd=args.repo, text=True).strip()
heads = {ref: git('rev-parse', ref) for ref in refs}
assert heads[refs[0]] == args.expected_fix_sha
assert heads[refs[1]] == 'f699073f0d9fe66a23cfb2f2e45a71a28c4ec785'
assert subprocess.run(['git', 'merge-base', '--is-ancestor', heads[refs[1]], heads[refs[0]]], cwd=args.repo).returncode == 1
index_before = git('ls-files', '--stage')
bundle = out / 'owned-work.bundle'
pending = out / 'owned-work.pending.bundle'
with (out / 'bundle-create-final.log').open('wb') as log:
    create = subprocess.run(['git', 'bundle', 'create', str(pending), *refs, '^' + args.prerequisite], cwd=args.repo, stdout=log, stderr=subprocess.STDOUT).returncode
assert create == 0
with (out / 'bundle-verify-final.log').open('wb') as log:
    verify = subprocess.run(['git', 'bundle', 'verify', str(pending)], cwd=args.repo, stdout=log, stderr=subprocess.STDOUT).returncode
assert verify == 0
listed = git('bundle', 'list-heads', str(pending))
for ref, head in heads.items():
    assert f'{head} {ref}' in listed
assert heads == {ref: git('rev-parse', ref) for ref in refs}
assert index_before == git('ls-files', '--stage')
pending.replace(bundle)
metadata = {
    'state': 'FINAL_CODE_REF_SNAPSHOT',
    'at_paris': datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),
    'prerequisite_revision': args.prerequisite,
    'included_heads': heads,
    'actual_create_exit': create,
    'actual_verify_exit': verify,
    'list_heads': listed,
    'bytes': bundle.stat().st_size,
    'sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
    'repo_index_and_refs_unchanged': True,
    'superseded_ref_policy': 'DO_NOT_CHERRY_PICK: f699 is private recovery data, superseded by dev42ac; not integrated or counted as a delivered fix.'
}
(out / 'bundle-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
