﻿; Private bounded producer observation; every GUI and process is owned.
_R6AppId_NativeIdentity(Name) {
	OutputDir := EnvGet("ERGOPTI_R6_APP_ID_DIR")
	AssertTrue(OutputDir != "" && DirExist(OutputDir))
	Image := OutputDir . "\" . Name
	Actor := OutputDir . "\actor.ahk"
	Handle := 0
	ThreadHandle := 0
	Hwnd := 0
	try {
		AssertFalse(FileExist(Image), "the probe image path must be unowned before creation")
		FileCopy(A_AhkPath, Image)
		Command := '"' . Image . '" /ErrorStdOut=UTF-8 "' . Actor . '"'
		CommandBuffer := Buffer((StrLen(Command) + 1) * 2, 0)
		StrPut(Command, CommandBuffer, "UTF-16")
		Startup := Buffer(104, 0)
		NumPut("UInt", Startup.Size, Startup)
		ProcessInfo := Buffer(24, 0)
		AssertTrue(DllCall("Kernel32\CreateProcessW", "WStr", Image, "Ptr", CommandBuffer,
			"Ptr", 0, "Ptr", 0, "Int", false, "UInt", 0, "Ptr", 0,
			"WStr", OutputDir, "Ptr", Startup, "Ptr", ProcessInfo, "Int"),
			"Win32 must launch the exact extensionless owned PE image")
		Handle := NumGet(ProcessInfo, 0, "Ptr")
		ThreadHandle := NumGet(ProcessInfo, 8, "Ptr")
		Pid := NumGet(ProcessInfo, 16, "UInt")
		DllCall("Kernel32\CloseHandle", "Ptr", ThreadHandle)
		ThreadHandle := 0
		Hwnd := WinWait("ahk_pid " . Pid . " ahk_class AutoHotkeyGUI", , 8)
		AssertTrue(Hwnd != 0, "the exact owned process must create its own native GUI")
		WinActivate("ahk_id " . Hwnd)
		AssertTrue(WinWaitActive("ahk_id " . Hwnd, , 5) != 0)
		Info := WIGetFocused()
		Foreground := PLC_GetForegroundApp()
		Bounded := WICaptureBoundedFocusSnapshot()
		AssertTrue(Bounded.ok, "the resident metrics acquisition must admit the owned foreground")
		AssertEqual(Name, Bounded.process_name, "the canonical metrics focus producer preserves extensionless identity")
		AssertEqual(Name, WinGetProcessName("ahk_id " . Hwnd), "native Windows process-name API preserves extensionless identity")
		AssertEqual(Name, Info["appId"], "actual WindowInfo ingress retains the native app ID")
		AssertEqual(Name, Foreground["appId"], "actual lifecycle ingress retains the native app ID")
		FileAppend("NATIVE_EXTENSIONLESS_APP " . Name . " pid=" . Pid
			. " window_info=" . Info["appId"] . " lifecycle=" . Foreground["appId"] . "`n", "*")
	} finally {
		AssertTrue(_WIResetFocusProcessCache(), "retire the canonical focus process handle")
		if Hwnd && WinExist("ahk_id " . Hwnd)
			WinClose("ahk_id " . Hwnd)
		if Handle {
			if DllCall("Kernel32\WaitForSingleObject", "Ptr", Handle, "UInt", 3000, "UInt") != 0 {
				AssertTrue(DllCall("Kernel32\TerminateProcess", "Ptr", Handle, "UInt", 0))
				AssertEqual(0, DllCall("Kernel32\WaitForSingleObject", "Ptr", Handle, "UInt", 3000, "UInt"))
			}
			AssertTrue(DllCall("Kernel32\CloseHandle", "Ptr", Handle))
		}
		if ThreadHandle
			DllCall("Kernel32\CloseHandle", "Ptr", ThreadHandle)
		if FileExist(Image)
			FileDelete(Image)
	}
}
for _R6AppIdName in ["__proto__", "constructor", "toString", "hasOwnProperty"]
	Test("audit: native extensionless app " . _R6AppIdName . " (r6-native-app-id)",
		_R6AppId_NativeIdentity.Bind(_R6AppIdName))
