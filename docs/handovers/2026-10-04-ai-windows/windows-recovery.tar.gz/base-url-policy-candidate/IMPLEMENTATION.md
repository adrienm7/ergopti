# Scratch implementation receipt

Status: prepared, unexecuted and not adopted. No checkout, frozen orchestration,
private publication, panel actor source or existing test was edited. Shared Lua
policy was extracted from the current Mac function; expectations were authored
independently beforehand. AHK source files have a UTF-8 BOM and LF.

Promote only after review, ownership coordination and the parent's test slot:

| Scratch file | Proposed production destination |
| --- | --- |
| `shared/lua/llm/base_url.lua` | `static/ergopti_plus/_shared/lua/llm/base_url.lua` |
| `shared/modules/llm/base_url.ahk` | `static/ergopti_plus/_shared/modules/llm/base_url.ahk` |
| `url-vectors.json` | `static/ergopti_plus/_shared/tests/corpus/llm/base_url_vectors.json` |
| `tests/test_base_url_policy.lua` | Both driver `tests/unit/modules/llm/test_base_url_policy.lua` |
| `tests/test_base_url_policy.ahk` | Windows `tests/unit/test_base_url_policy.ahk` |
| `tests/test_base_url_models_admission.ahk` | Windows `tests/unit/test_base_url_models_admission.ahk` |

Eight tiny wiring proposals in `wiring/` have independent original-file hashes
in `PREIMAGES.json`. Mac/Linux existing public normalizers delegate to shared
policy. The existing Mac normalizer body and trim primitive are copied unchanged
apart from the exported function name. Mac's private trim primitive remains for
other actual callers. Linux now shares bracketed IPv6/port/zone admission.

Windows models admission obtains a normalized transport copy before any native
request, child or curl artifact. Its original configured `Target.base_url` is
unchanged, retaining exact source and model-cache provenance. Existing Windows
C1/scalar checks remain in the original native gate. Panel input uses the strict
normalizer rather than trimming invalid outer spaces; exact empty input still
chooses the server default. Orchestration Apply's proposed hunk clones supplied
Fields and normalizes only the clone's address, preserving the caller's Map and
all prior source/model/write ownership checks. These are patches only, not edits
to frozen actor sources. The final panel destination is its existing menu folder.

General cloud resolver/readiness/catalogue, `_LLMRemoteBuildUrl`, G6 proxy hunks
and existing `test_llm_api_remote.ahk` are unchanged. A new independent native
case pins exact decisions complete-endpoint routing including the final slash.
The new native acquisition cases use the existing `_LSM_Fixture` actual curl and
models owner with controlled child receipts. They assert all twenty invalid
corpus cases acquire zero requests/children/private configurations, valid IPv6
uses its exact independently specified normalized transport URI while retaining
the raw target snapshot, and C1 controls still refuse. This is unit composition,
not actual network E2E or physical input evidence.

The corpus has exactly 35 independently authored cases. Its native pure-policy
tests register three cases and native models-boundary tests three more; the
portable Lua wrapper registers two in each driver. Mac discovers its new file;
Linux's separate manifest patch registers it explicitly. Windows runner patch
includes the shared counterpart before consumers and both new tests after the
existing actual models fixture. No existing expectations were regenerated.

Validation not executed: syntax, encoding/conventions, focused Lua/AHK tests,
causal removal controls, verify-change, native E2E, loopback HTTP, packaging,
installation and final CI. No success or integration claim is made.
