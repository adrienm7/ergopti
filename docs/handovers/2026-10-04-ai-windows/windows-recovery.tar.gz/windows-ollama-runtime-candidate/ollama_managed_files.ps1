# modules/llm/ollama_managed_files.ps1
# Native Windows files only: no download, installer execution, daemon or AI toggle.
# The caller owns consent/source admission, the helper job and all returned debts.

[CmdletBinding()]
param(
	[ValidateSet('', 'prepare', 'publish', 'cleanup')][string]$Action = '',
	[string]$ManagedRoot = '',
	[string]$CataloguePath = '',
	[string]$CatalogueSha256 = '',
	[string]$AssetId = '',
	[string]$ArchivePath = '',
	[string]$TicketId = '',
	[string]$StageIdentity = '',
	[string]$ManifestSha256 = '',
	[long]$MaxExpandedBytes = 0,
	[int]$MaxEntries = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Initialize-OllamaManagedNative {
	if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
		throw 'Managed Ollama files require native Windows.'
	}
	if ('Ergopti.Ollama.ManagedNative' -as [type]) { return }
	Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
namespace Ergopti.Ollama {
 public static class ManagedNative {
  [StructLayout(LayoutKind.Sequential)] struct SecurityAttributes {
   public int Length; public IntPtr Descriptor;
   [MarshalAs(UnmanagedType.Bool)] public bool Inherit;
  }
  [StructLayout(LayoutKind.Sequential)] struct FileInfo {
   public uint Attributes, CreationLow, CreationHigh, AccessLow, AccessHigh,
    WriteLow, WriteHigh, Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
  }
  [StructLayout(LayoutKind.Sequential)] struct IoStatus { public IntPtr Status, Information; }
  [DllImport("kernel32", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern bool CreateDirectory(string path, ref SecurityAttributes security);
  [DllImport("kernel32", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern IntPtr CreateFile(string path, uint access, uint share, IntPtr security,
   uint disposition, uint flags, IntPtr template);
  [DllImport("kernel32", SetLastError=true)] static extern bool GetFileInformationByHandle(IntPtr handle, out FileInfo info);
  [DllImport("kernel32", SetLastError=true)] public static extern bool CloseHandle(IntPtr handle);
  [DllImport("ntdll")] static extern int NtSetInformationFile(IntPtr handle, out IoStatus status,
   IntPtr info, uint bytes, int informationClass);
  [DllImport("ntdll")] static extern uint RtlNtStatusToDosError(int status);
  [DllImport("kernel32", CharSet=CharSet.Unicode, SetLastError=true)] static extern uint GetFileAttributes(string path);
  public static bool PathIsAbsent(string path) {
   if(GetFileAttributes(path)!=0xffffffffu) return false;
   int error=Marshal.GetLastWin32Error();
   if(error==2 || error==3) return true;
   throw new Win32Exception(error);
  }
  public static void DeleteExactDirectory(IntPtr handle) {
   var memory=Marshal.AllocHGlobal(1);
   try {
    Marshal.WriteByte(memory,1);
    IoStatus status;
    int result=NtSetInformationFile(handle,out status,memory,1,13);
    if(result<0) throw new Win32Exception((int)RtlNtStatusToDosError(result));
   } finally { Marshal.FreeHGlobal(memory); }
  }
  public static System.IO.FileStream OpenRegularFile(string path, bool retire) {
   var handle=CreateFile(path, 0x80000000u | (retire ? 0x10000u : 0u), 1,
    IntPtr.Zero, 3, 0x00200000u, IntPtr.Zero);
   if(handle==new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error());
   FileInfo info;
   if(!GetFileInformationByHandle(handle,out info) || (info.Attributes & 0x410)!=0) {
    int error=Marshal.GetLastWin32Error(); CloseHandle(handle);
    throw new Win32Exception(error==0 ? 4390 : error,"Source is not a regular non-reparse file.");
   }
   var owned=new SafeFileHandle(handle,true);
   try { return new System.IO.FileStream(owned,System.IO.FileAccess.Read); }
   catch { owned.Dispose(); throw; }
  }
  public static void CreateProtectedDirectory(string path, byte[] descriptor) {
   var pinned=GCHandle.Alloc(descriptor, GCHandleType.Pinned);
   try {
    var security=new SecurityAttributes { Length=Marshal.SizeOf(typeof(SecurityAttributes)),
     Descriptor=pinned.AddrOfPinnedObject(), Inherit=false };
    if (!CreateDirectory(path, ref security)) throw new Win32Exception(Marshal.GetLastWin32Error());
   } finally { pinned.Free(); }
  }
  public static IntPtr OpenDirectory(string path, bool rename) {
   uint access=0x80u | (rename ? 0x10000u : 0u);
   var handle=CreateFile(path, access, 3, IntPtr.Zero, 3, 0x02200000u, IntPtr.Zero);
   if (handle==new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error());
   FileInfo info;
   if (!GetFileInformationByHandle(handle, out info) || (info.Attributes & 0x10)==0 || (info.Attributes & 0x400)!=0) {
    int error=Marshal.GetLastWin32Error(); CloseHandle(handle);
    throw new Win32Exception(error==0 ? 4390 : error, "Untrusted managed directory shape.");
   }
   return handle;
  }
  public static string Identity(IntPtr handle) {
   FileInfo info;
   if (!GetFileInformationByHandle(handle, out info)) throw new Win32Exception(Marshal.GetLastWin32Error());
   return info.Volume.ToString("x8")+":"+info.IndexHigh.ToString("x8")+info.IndexLow.ToString("x8");
  }
  public static void RenameCreate(IntPtr source, string destination) {
   // Rename through the exact DELETE-capable source handle, which never shares
   // DELETE. A path-based MoveFileEx would require releasing that identity fence.
   string absolute=System.IO.Path.GetFullPath(destination);
   string native=absolute.StartsWith(@"\\?\") ? @"\??\"+absolute.Substring(4) : @"\??\"+absolute;
   byte[] name=System.Text.Encoding.Unicode.GetBytes(native);
   int rootOffset=IntPtr.Size==8 ? 8 : 4;
   int lengthOffset=rootOffset+IntPtr.Size, nameOffset=lengthOffset+4;
   var memory=Marshal.AllocHGlobal(nameOffset+name.Length);
   try {
    for(int n=0;n<nameOffset+name.Length;n++) Marshal.WriteByte(memory,n,0);
    Marshal.WriteIntPtr(memory,rootOffset,IntPtr.Zero);
    Marshal.WriteInt32(memory,lengthOffset,name.Length);
    Marshal.Copy(name,0,IntPtr.Add(memory,nameOffset),name.Length);
    IoStatus status;
    int result=NtSetInformationFile(source,out status,memory,(uint)(nameOffset+name.Length),10);
    if(result<0) throw new Win32Exception((int)RtlNtStatusToDosError(result));
   } finally { Marshal.FreeHGlobal(memory); }
  }
 }
}
'@ | Out-Null
	Add-Type -AssemblyName System.IO.Compression | Out-Null
}

function Get-OllamaSid {
	return [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
}

function New-OllamaPrivateSecurity {
	$security = New-Object Security.AccessControl.DirectorySecurity
	$sid = Get-OllamaSid
	$security.SetSecurityDescriptorSddlForm("O:${sid}D:P(A;OICI;FA;;;SY)(A;OICI;FA;;;${sid})")
	return $security
}

function Assert-OllamaPrivateSecurity([string]$Path) {
	$security = Get-Acl -LiteralPath $Path
	$sid = Get-OllamaSid
	if (-not $security.AreAccessRulesProtected -or -not $security.AreAccessRulesCanonical -or
		$security.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne $sid) {
		throw 'The managed directory has untrusted owner or inheritance.'
	}
	$rules = @($security.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier]))
	if ($rules.Count -ne 2) { throw 'The managed directory has unexpected access grants.' }
	$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
	foreach ($rule in $rules) {
		if ($rule.IsInherited -or $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or
			$rule.FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl -or
			$rule.InheritanceFlags -ne ([Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit) -or
			$rule.PropagationFlags -ne [Security.AccessControl.PropagationFlags]::None -or
			$rule.IdentityReference.Value -notin @($sid, 'S-1-5-18') -or -not $seen.Add($rule.IdentityReference.Value)) {
			throw 'The managed directory grants an unexpected principal or right.'
		}
	}
}

function Assert-OllamaLocalPath([string]$Path) {
	if ($Path -notmatch '^[A-Za-z]:\\' -or $Path.Contains("`r") -or $Path.Contains("`n")) {
		throw 'Managed paths must be absolute local Windows paths.'
	}
	foreach ($component in $Path.Substring(3).Split('\')) {
		if ($component -eq '' -or $component -in @('.', '..') -or
			$component.EndsWith('.') -or $component.EndsWith(' ') -or
			$component.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0) {
			throw 'The managed path has an ambiguous native component.'
		}
	}
	return [IO.Path]::GetFullPath($Path)
}

function Open-OllamaReadFile([string]$Path, [bool]$Retire = $false) {
	return [Ergopti.Ollama.ManagedNative]::OpenRegularFile($Path, $Retire)
}

function Remove-OllamaExactFile([IO.FileStream]$Stream) {
	[Ergopti.Ollama.ManagedNative]::DeleteExactDirectory($Stream.SafeFileHandle.DangerousGetHandle())
	$Stream.Dispose()
}

function Hold-OllamaStageDirectories([string]$Stage, $Directories, [bool]$Create = $false,
	[bool]$Retiring = $false) {
	$held = [ordered]@{}
	try {
		foreach ($relative in @($Directories | Sort-Object { $_.Length })) {
			$path = [IO.Path]::Combine($Stage, $relative.Replace('/', '\'))
			if ([Ergopti.Ollama.ManagedNative]::PathIsAbsent($path)) {
				if ($Create) {
					[Ergopti.Ollama.ManagedNative]::CreateProtectedDirectory($path, (New-OllamaPrivateSecurity).GetSecurityDescriptorBinaryForm())
				} elseif ($Retiring) { continue }
				else { throw 'An expected prepared directory is absent.' }
			}
			$handle = [Ergopti.Ollama.ManagedNative]::OpenDirectory($path, $true)
			$held[$relative] = $handle
			Assert-OllamaPrivateSecurity $path
		}
		return ,$held
	} catch {
		foreach ($handle in $held.Values) {
			if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($handle)) {
				[Console]::Error.WriteLine('Nested directory refusal retains exact native close debt.')
			}
		}
		throw
	}
}

function Get-OllamaStreamHash([IO.Stream]$Stream) {
	$position = $Stream.Position
	$hasher = [Security.Cryptography.SHA256]::Create()
	try {
		$Stream.Position = 0
		return ([BitConverter]::ToString($hasher.ComputeHash($Stream))).Replace('-', '').ToLowerInvariant()
	} finally {
		$Stream.Position = $position
		$hasher.Dispose()
	}
}

function Read-OllamaJsonStream([IO.Stream]$Stream) {
	$reader = [IO.StreamReader]::new($Stream, [Text.UTF8Encoding]::new($false, $true), $true, 1024, $true)
	try { return $reader.ReadToEnd() | ConvertFrom-Json }
	finally { $reader.Dispose(); $Stream.Position = 0 }
}

function Write-OllamaOwnedJson([string]$Path, $Value) {
	$bytes = [Text.UTF8Encoding]::new($false, $true).GetBytes(($Value | ConvertTo-Json -Depth 12 -Compress) + "`n")
	$stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
	try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) }
	finally { $stream.Dispose() }
}

function Open-OllamaManagedRoot([string]$Root, [bool]$AllowCreate = $true) {
	Initialize-OllamaManagedNative
	$rootPath = Assert-OllamaLocalPath $Root
	$base = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals([IO.Path]::GetDirectoryName($rootPath), $base)) {
		throw 'The managed root must be one explicitly selected child of the current user LocalApplicationData.'
	}
	$handles = [Collections.Generic.List[IntPtr]]::new()
	try {
		# Hold every existing ancestor without DELETE sharing before creation.
		$ancestor = [IO.DirectoryInfo]::new($base)
		while ($null -ne $ancestor) {
			$handles.Add([Ergopti.Ollama.ManagedNative]::OpenDirectory($ancestor.FullName, $false))
			$ancestor = $ancestor.Parent
		}
		$created = -not [IO.Directory]::Exists($rootPath)
		if ($created -and -not $AllowCreate) { throw 'Cleanup and publication cannot create a replacement managed root.' }
		if ($created) {
			[Ergopti.Ollama.ManagedNative]::CreateProtectedDirectory($rootPath, (New-OllamaPrivateSecurity).GetSecurityDescriptorBinaryForm())
		}
		$rootHandle = [Ergopti.Ollama.ManagedNative]::OpenDirectory($rootPath, $false)
		$handles.Add($rootHandle)
		Assert-OllamaPrivateSecurity $rootPath
		$identity = [Ergopti.Ollama.ManagedNative]::Identity($rootHandle)
		$markerPath = [IO.Path]::Combine($rootPath, 'root-owner.json')
		if ($created) {
			Write-OllamaOwnedJson $markerPath ([ordered]@{ kind = 'ollama-managed-root'; owner_sid = (Get-OllamaSid); identity = $identity })
		}
		$markerStream = Open-OllamaReadFile $markerPath
		try {
			$marker = Read-OllamaJsonStream $markerStream
			if ($marker.kind -ne 'ollama-managed-root' -or $marker.owner_sid -ne (Get-OllamaSid) -or $marker.identity -ne $identity) {
				throw 'An existing managed root has no exact ownership receipt.'
			}
		} finally { $markerStream.Dispose() }
		$versions = [IO.Path]::Combine($rootPath, 'versions')
		if (-not [IO.Directory]::Exists($versions)) {
			if (-not $AllowCreate) { throw 'Cleanup and publication cannot create a replacement versions directory.' }
			[Ergopti.Ollama.ManagedNative]::CreateProtectedDirectory($versions, (New-OllamaPrivateSecurity).GetSecurityDescriptorBinaryForm())
		}
		$versionsHandle = [Ergopti.Ollama.ManagedNative]::OpenDirectory($versions, $false)
		$handles.Add($versionsHandle)
		Assert-OllamaPrivateSecurity $versions
		return @{ path = $rootPath; identity = $identity; versions = $versions; handles = $handles }
	} catch {
		foreach ($handle in $handles) {
			if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($handle)) {
				[Console]::Error.WriteLine('Managed root failure retained a native close debt.')
			}
		}
		throw
	}
}

function Close-OllamaManagedRoot($Root) {
	$remaining = [Collections.Generic.List[IntPtr]]::new()
	foreach ($handle in $Root.handles) {
		if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($handle)) { $remaining.Add($handle) }
	}
	$Root.handles = $remaining
	if ($remaining.Count -ne 0) { throw 'The exact managed directory handles retain close debt.' }
}

function Get-OllamaEntryPath([IO.Compression.ZipArchiveEntry]$Entry) {
	$name = $Entry.FullName.Replace('\', '/')
	if ($name -eq '' -or $name.StartsWith('/') -or $name.Contains(':') -or $name.Contains([char]0)) {
		throw 'The archive has a rooted, empty, control-bearing or alternate-stream path.'
	}
	$directory = $name.EndsWith('/')
	$name = $name.TrimEnd('/')
	foreach ($part in $name.Split('/')) {
		if ($part -eq '' -or $part -in @('.', '..') -or $part.EndsWith('.') -or $part.EndsWith(' ') -or
			$part.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or
			$part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|\z)') {
			throw 'The archive contains traversal, an ambiguous path or a reserved device.'
		}
	}
	if ($name -in @('stage-owner.json', 'prepared.json')) { throw 'The archive collides with native ownership receipts.' }
	$attributes = [uint32]([long]$Entry.ExternalAttributes -band 0xffffffffL)
	$unixKind = ($attributes -shr 16) -band 0xf000
	if (($attributes -band 0x400) -ne 0 -or $unixKind -notin @(0, 0x8000, 0x4000) -or
		($unixKind -eq 0x4000 -and -not $directory) -or ($unixKind -eq 0x8000 -and $directory)) {
		throw 'The archive contains a link, reparse point or nonregular native entry.'
	}
	if ($directory -and $Entry.Length -ne 0) { throw 'An archive directory carries unexpected payload.' }
	return @{ path = $name; directory = $directory; bytes = [long]$Entry.Length }
}

function Read-OllamaPinnedArchive([string]$Catalogue, [string]$ExpectedCatalogueHash, [string]$Asset,
	[string]$Archive, [long]$ExpandedBudget, [int]$EntryBudget) {
	if ($ExpectedCatalogueHash -notmatch '^[0-9a-f]{64}\z' -or $Asset -notin @('windows-amd64', 'windows-arm64') -or
		$ExpandedBudget -lt 0 -or $EntryBudget -lt 0) { throw 'The captured release source or archive bounds are invalid.' }
	$catalogueStream = Open-OllamaReadFile (Assert-OllamaLocalPath $Catalogue)
	$archiveStream = $null
	$zip = $null
	try {
		if ((Get-OllamaStreamHash $catalogueStream) -ne $ExpectedCatalogueHash) { throw 'The exact canonical release source changed.' }
		$data = Read-OllamaJsonStream $catalogueStream
		$pin = $data.assets.PSObject.Properties[$Asset].Value
		if ($data.schema_version -ne 1 -or $data.version -notmatch '^[0-9]+\.[0-9]+\.[0-9]+\z' -or
			$pin.sha256 -notmatch '^[0-9a-f]{64}\z' -or
			-not ($pin.bytes -is [int] -or $pin.bytes -is [long]) -or $pin.bytes -le 0) {
			throw 'The selected canonical release receipt is unreadable.'
		}
		$archiveStream = Open-OllamaReadFile (Assert-OllamaLocalPath $Archive)
		if ($archiveStream.Length -ne $pin.bytes -or (Get-OllamaStreamHash $archiveStream) -ne $pin.sha256) {
			throw 'The exact pinned archive bytes or SHA-256 do not match.'
		}
		# Inspection occurs only after the complete pinned digest is admitted.
		$zip = [IO.Compression.ZipArchive]::new($archiveStream, [IO.Compression.ZipArchiveMode]::Read, $true)
		if ($zip.Entries.Count -eq 0 -or ($EntryBudget -gt 0 -and $zip.Entries.Count -gt $EntryBudget)) {
			throw 'The archive exceeds its admitted entry budget or contains nothing.'
		}
		$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
		$entries = [Collections.Generic.List[object]]::new()
		[long]$total = 0
		foreach ($entry in $zip.Entries) {
			$item = Get-OllamaEntryPath $entry
			if (-not $seen.Add($item.path)) { throw 'The archive has colliding native paths.' }
			if ($item.bytes -lt 0 -or $item.bytes -gt ([long]::MaxValue - $total)) { throw 'The archive length sum overflowed.' }
			$total += $item.bytes
			if ($ExpandedBudget -gt 0 -and $total -gt $ExpandedBudget) { throw 'The archive exceeds its admitted expanded byte budget.' }
			$item.entry = $entry
			$entries.Add($item)
		}
		$cli = @($entries | Where-Object { $_.path -eq 'ollama.exe' -and -not $_.directory -and $_.bytes -gt 0 })
		if ($cli.Count -ne 1) { throw 'The complete portable archive lacks one regular CLI.' }
		return @{ version = $data.version; pin = $pin; asset = $Asset; entries = $entries; total = $total;
			zip = $zip; archive_stream = $archiveStream; catalogue_stream = $catalogueStream; catalogue_sha256 = $ExpectedCatalogueHash }
	} catch {
		if ($null -ne $zip) { $zip.Dispose() }
		if ($null -ne $archiveStream) { $archiveStream.Dispose() }
		$catalogueStream.Dispose()
		throw
	}
}

function Close-OllamaPinnedArchive($Archive) {
	$Archive.zip.Dispose(); $Archive.archive_stream.Dispose(); $Archive.catalogue_stream.Dispose()
}

function Prepare-OllamaManagedStage($Root, $Archive, [string]$Ticket) {
	if ($Ticket -notmatch '^[0-9a-f]{32}\z') { throw 'A stage needs its originating private ticket.' }
	$stage = [IO.Path]::Combine($Root.path, '.stage-' + $Ticket)
	$drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($stage))
	if ($drive.AvailableFreeSpace -lt $Archive.total) { throw 'The complete portable archive will not fit on the target volume.' }
	[Ergopti.Ollama.ManagedNative]::CreateProtectedDirectory($stage, (New-OllamaPrivateSecurity).GetSecurityDescriptorBinaryForm())
	$handle = [Ergopti.Ollama.ManagedNative]::OpenDirectory($stage, $true)
	$directoryHandles = [ordered]@{}
	try {
		$identity = [Ergopti.Ollama.ManagedNative]::Identity($handle)
		$owner = [ordered]@{ kind = 'ollama-stage'; ticket = $Ticket; root_identity = $Root.identity; identity = $identity }
		Write-OllamaOwnedJson ([IO.Path]::Combine($stage, 'stage-owner.json')) $owner
		$files = [Collections.Generic.List[object]]::new()
		$directories = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
		foreach ($item in $Archive.entries) {
			$parts = $item.path.Split('/')
			$parentCount = $parts.Length - 1
			if ($item.directory) { $parentCount = $parts.Length }
			for ($index = 1; $index -le $parentCount; $index++) {
				[void]$directories.Add(($parts[0..($index - 1)] -join '/'))
			}
		}
		$directoryHandles = Hold-OllamaStageDirectories $stage $directories $true
		foreach ($item in $Archive.entries) {
			$destination = [IO.Path]::Combine($stage, $item.path.Replace('/', '\'))
			if ($item.directory) { continue }
			$input = $item.entry.Open()
			$output = [IO.File]::Open($destination, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
			try {
				$buffer = New-Object byte[] 65536
				[long]$written = 0
				while (($count = $input.Read($buffer, 0, $buffer.Length)) -gt 0) {
					if ($count -gt ($item.bytes - $written)) { throw 'An extracted stream exceeded its verified declared length.' }
					$output.Write($buffer, 0, $count); $written += $count
				}
				if ($written -ne $item.bytes) { throw 'An extracted stream ended before its verified declared length.' }
				$output.Flush($true)
			} finally { $output.Dispose(); $input.Dispose() }
			$read = Open-OllamaReadFile $destination
			try { $files.Add([ordered]@{ path = $item.path; bytes = $item.bytes; sha256 = (Get-OllamaStreamHash $read) }) }
			finally { $read.Dispose() }
		}
		$manifest = [ordered]@{ kind = 'ollama-prepared'; ticket = $Ticket; root_identity = $Root.identity;
			identity = $identity; version = $Archive.version; asset = $Archive.asset;
			archive_sha256 = $Archive.pin.sha256; catalogue_sha256 = $Archive.catalogue_sha256;
			directories = @($directories | Sort-Object); files = @($files.ToArray()) }
		$manifestPath = [IO.Path]::Combine($stage, 'prepared.json')
		Write-OllamaOwnedJson $manifestPath $manifest
		$read = Open-OllamaReadFile $manifestPath
		try { $manifestHash = Get-OllamaStreamHash $read } finally { $read.Dispose() }
		return [ordered]@{ ok = $true; phase = 'prepared'; stage = $stage; ticket = $Ticket;
			root_identity = $Root.identity; stage_identity = $identity; manifest_sha256 = $manifestHash;
			version = $Archive.version; asset = $Archive.asset; expanded_bytes = $Archive.total; files = $files.Count }
	} finally {
		foreach ($nestedHandle in $directoryHandles.Values) {
			if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($nestedHandle)) { throw 'The exact prepared child directory retains close debt.' }
		}
		if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($handle)) { throw 'The exact prepared directory retains handle close debt.' }
	}
}

function Open-OllamaPreparedStage($Root, [string]$Ticket, [string]$ExpectedIdentity, [string]$ExpectedManifestHash,
	[bool]$AllowRetiring = $false) {
	if ($Ticket -notmatch '^[0-9a-f]{32}\z' -or $ExpectedManifestHash -notmatch '^[0-9a-f]{64}\z') {
		throw 'Prepared stage admission needs exact originating receipts.'
	}
	$stage = [IO.Path]::Combine($Root.path, '.stage-' + $Ticket)
	$handle = [Ergopti.Ollama.ManagedNative]::OpenDirectory($stage, $true)
	$streams = [Collections.Generic.List[object]]::new()
	$ownedFiles = [ordered]@{}
	$directoryHandles = [ordered]@{}
	$cleanupStream = $null
	try {
		Assert-OllamaPrivateSecurity $stage
		if ([Ergopti.Ollama.ManagedNative]::Identity($handle) -ne $ExpectedIdentity) { throw 'The exact prepared directory was replaced.' }
		$cleanupPath = [IO.Path]::Combine($Root.path, '.cleanup-' + $Ticket + '.json')
		$retiring = $false
		$cleanup = $null
		if (-not [Ergopti.Ollama.ManagedNative]::PathIsAbsent($cleanupPath)) {
			if (-not $AllowRetiring) { throw 'A retiring stage cannot be published.' }
			$cleanupStream = Open-OllamaReadFile $cleanupPath $true
			$cleanup = Read-OllamaJsonStream $cleanupStream
			if ($cleanup.kind -ne 'ollama-cleanup' -or $cleanup.ticket -ne $Ticket -or
				$cleanup.identity -ne $ExpectedIdentity -or $cleanup.root_identity -ne $Root.identity -or
				$cleanup.manifest_sha256 -ne $ExpectedManifestHash) { throw 'The exact root cleanup journal changed.' }
			$retiring = $true
		}
		$manifestPath = [IO.Path]::Combine($stage, 'prepared.json')
		if ($retiring -and [Ergopti.Ollama.ManagedNative]::PathIsAbsent($manifestPath)) {
			$manifestStream = [IO.MemoryStream]::new([Convert]::FromBase64String($cleanup.manifest_bytes), $false)
		} else {
			$manifestStream = Open-OllamaReadFile $manifestPath $true
			$ownedFiles['prepared.json'] = $manifestStream
		}
		$streams.Add($manifestStream)
		if ((Get-OllamaStreamHash $manifestStream) -ne $ExpectedManifestHash) { throw 'The exact prepared receipt changed.' }
		$manifest = Read-OllamaJsonStream $manifestStream
		$memory = [IO.MemoryStream]::new()
		try {
			$manifestStream.CopyTo($memory); $manifestBytes = $memory.ToArray(); $manifestStream.Position = 0
		} finally { $memory.Dispose() }
		if ($manifest.kind -ne 'ollama-prepared' -or $manifest.ticket -ne $Ticket -or
			$manifest.identity -ne $ExpectedIdentity -or $manifest.root_identity -ne $Root.identity -or
			$manifest.version -notmatch '^[0-9]+\.[0-9]+\.[0-9]+\z' -or
			$manifest.asset -notin @('windows-amd64', 'windows-arm64') -or $manifest.archive_sha256 -notmatch '^[0-9a-f]{64}\z') {
			throw 'The prepared receipt does not own this stage.'
		}
		$expected = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
		[void]$expected.Add('prepared.json'); [void]$expected.Add('stage-owner.json')
		$ownerPath = [IO.Path]::Combine($stage, 'stage-owner.json')
		if (-not ($retiring -and [Ergopti.Ollama.ManagedNative]::PathIsAbsent($ownerPath))) {
			$ownerStream = Open-OllamaReadFile $ownerPath $true
			$ownedFiles['stage-owner.json'] = $ownerStream
			$streams.Add($ownerStream)
			$owner = Read-OllamaJsonStream $ownerStream
			if ($owner.kind -ne 'ollama-stage' -or $owner.ticket -ne $Ticket -or
				$owner.identity -ne $ExpectedIdentity -or $owner.root_identity -ne $Root.identity) {
				throw 'The exact stage creation receipt changed.'
			}
		}
		$expectedDirectories = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
		foreach ($directory in $manifest.directories) {
			if (-not $expectedDirectories.Add($directory)) { throw 'The prepared receipt contains colliding directories.' }
		}
		$directoryHandles = Hold-OllamaStageDirectories $stage $expectedDirectories $false $retiring
		foreach ($file in $manifest.files) {
			if (-not $expected.Add($file.path)) { throw 'The prepared receipt contains colliding files.' }
			$path = [IO.Path]::Combine($stage, $file.path.Replace('/', '\'))
			if ($retiring -and [Ergopti.Ollama.ManagedNative]::PathIsAbsent($path)) { continue }
			$stream = Open-OllamaReadFile $path $true
			$ownedFiles[$file.path] = $stream
			$streams.Add($stream)
			if ($stream.Length -ne $file.bytes -or (Get-OllamaStreamHash $stream) -ne $file.sha256) {
				throw 'A prepared runtime file changed before publication.'
			}
		}
		foreach ($entry in Get-ChildItem -LiteralPath $stage -Force -Recurse) {
			if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'A prepared entry became a reparse point.' }
			$relative = $entry.FullName.Substring($stage.Length + 1).Replace('\', '/')
			if ($entry.PSIsContainer -and -not $expectedDirectories.Contains($relative)) {
				throw 'A foreign directory entered the prepared stage.'
			}
			if (-not $entry.PSIsContainer) {
				if (-not $expected.Contains($relative)) { throw 'A foreign file entered the prepared stage.' }
			}
		}
		return @{ path = $stage; handle = $handle; streams = $streams; manifest = $manifest;
			manifest_bytes = $manifestBytes; cleanup_path = $cleanupPath;
			owned_files = $ownedFiles; directory_handles = $directoryHandles; cleanup_stream = $cleanupStream }
	} catch {
		if ($null -ne $cleanupStream) { $cleanupStream.Dispose() }
		foreach ($stream in $streams) { $stream.Dispose() }
		foreach ($nestedHandle in $directoryHandles.Values) {
			if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($nestedHandle)) {
				[Console]::Error.WriteLine('Prepared child directory refusal retains close debt.')
			}
		}
		if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($handle)) {
			[Console]::Error.WriteLine('Prepared stage refusal retains a directory close debt.')
		}
		throw
	}
}

function Close-OllamaPreparedStage($Stage) {
	if ($null -ne $Stage.cleanup_stream) { $Stage.cleanup_stream.Dispose(); $Stage.cleanup_stream = $null }
	foreach ($stream in $Stage.streams) { $stream.Dispose() }
	$Stage.streams.Clear()
	foreach ($relative in @($Stage.directory_handles.Keys)) {
		if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($Stage.directory_handles[$relative])) { throw 'An exact prepared child directory retains close debt.' }
		$Stage.directory_handles.Remove($relative)
	}
	if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($Stage.handle)) { throw 'The exact prepared stage handle retains close debt.' }
	$Stage.handle = [IntPtr]::Zero
}

function Publish-OllamaPreparedStage($Root, $Stage) {
	$manifest = $Stage.manifest
	$leaf = $manifest.version + '-' + $manifest.asset + '-' + $manifest.archive_sha256
	$target = [IO.Path]::Combine($Root.versions, $leaf)
	[Ergopti.Ollama.ManagedNative]::RenameCreate($Stage.handle, $target)
	return [ordered]@{ ok = $true; phase = 'published'; version_path = $target;
		version_identity = ([Ergopti.Ollama.ManagedNative]::Identity($Stage.handle)); ticket = $manifest.ticket;
		archive_sha256 = $manifest.archive_sha256; executable = [IO.Path]::Combine($target, 'ollama.exe') }
}

function Remove-OllamaPreparedStage($Root, [string]$Ticket, [string]$ExpectedIdentity, [string]$ExpectedManifestHash) {
	if ($Ticket -notmatch '^[0-9a-f]{32}\z') { throw 'Cleanup requires the exact originating private ticket.' }
	$path = [IO.Path]::Combine($Root.path, '.stage-' + $Ticket)
	if ([Ergopti.Ollama.ManagedNative]::PathIsAbsent($path)) {
		$cleanupPath = [IO.Path]::Combine($Root.path, '.cleanup-' + $Ticket + '.json')
		if (-not [Ergopti.Ollama.ManagedNative]::PathIsAbsent($cleanupPath)) {
			$read = Open-OllamaReadFile $cleanupPath $true
			try {
				$receipt = Read-OllamaJsonStream $read
				if ($receipt.kind -ne 'ollama-cleanup' -or $receipt.ticket -ne $Ticket -or
					$receipt.identity -ne $ExpectedIdentity -or $receipt.root_identity -ne $Root.identity -or
					$receipt.manifest_sha256 -ne $ExpectedManifestHash) { throw 'A foreign cleanup journal cannot be removed.' }
				Remove-OllamaExactFile $read
			} finally { $read.Dispose() }
		}
		return [ordered]@{ ok = $true; phase = 'retired'; ticket = $Ticket }
	}
	$stage = Open-OllamaPreparedStage $Root $Ticket $ExpectedIdentity $ExpectedManifestHash $true
	$journal = $stage.cleanup_stream
	$stage.cleanup_stream = $null
	try {
		# Retire through exact DELETE-capable handles. Never drop the identity
		# fence to reopen a pathname that foreign content can replace.
		$cleanupPath = $stage.cleanup_path
		if ([Ergopti.Ollama.ManagedNative]::PathIsAbsent($cleanupPath)) {
			Write-OllamaOwnedJson $cleanupPath ([ordered]@{ kind = 'ollama-cleanup'; ticket = $Ticket;
				identity = $ExpectedIdentity; root_identity = $Root.identity; manifest_sha256 = $ExpectedManifestHash;
				manifest_bytes = [Convert]::ToBase64String($stage.manifest_bytes) })
			$journal = Open-OllamaReadFile $cleanupPath $true
		}
		foreach ($stream in $stage.owned_files.Values) { Remove-OllamaExactFile $stream }
		foreach ($stream in $stage.streams) { $stream.Dispose() }
		$stage.streams.Clear()
		$directories = @($stage.manifest.directories | Sort-Object { $_.Length } -Descending)
		foreach ($directory in $directories) {
			if (-not $stage.directory_handles.Contains($directory)) { continue }
			$nestedHandle = $stage.directory_handles[$directory]
			[Ergopti.Ollama.ManagedNative]::DeleteExactDirectory($nestedHandle)
			if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($nestedHandle)) { throw 'An exact retired child directory retains close debt.' }
			$stage.directory_handles.Remove($directory)
		}
		# Mark only the exact retained directory for deletion. Never drop the
		# identity fence to reopen a pathname that a foreign directory can replace.
		[Ergopti.Ollama.ManagedNative]::DeleteExactDirectory($stage.handle)
		Close-OllamaPreparedStage $stage
		if (-not [Ergopti.Ollama.ManagedNative]::PathIsAbsent($stage.path)) { throw 'The exact marked directory still retains physical cleanup debt.' }
		Remove-OllamaExactFile $journal
		$journal = $null
		return [ordered]@{ ok = $true; phase = 'retired'; ticket = $Ticket }
	} finally {
		if ($null -ne $journal) { $journal.Dispose() }
		if ($stage.handle -ne [IntPtr]::Zero) { Close-OllamaPreparedStage $stage }
	}
}

if ($MyInvocation.InvocationName -ne '.') {
	$root = $null; $archive = $null; $stage = $null
	try {
		if ($Action -eq '') { throw 'An explicit native file operation is required.' }
		$root = Open-OllamaManagedRoot $ManagedRoot ($Action -eq 'prepare')
		switch ($Action) {
			'prepare' {
				$archive = Read-OllamaPinnedArchive $CataloguePath $CatalogueSha256 $AssetId $ArchivePath $MaxExpandedBytes $MaxEntries
				$result = Prepare-OllamaManagedStage $root $archive $TicketId
			}
			'publish' {
				$stage = Open-OllamaPreparedStage $root $TicketId $StageIdentity $ManifestSha256
				$result = Publish-OllamaPreparedStage $root $stage
			}
			'cleanup' { $result = Remove-OllamaPreparedStage $root $TicketId $StageIdentity $ManifestSha256 }
		}
		if ($null -ne $stage) { Close-OllamaPreparedStage $stage; $stage = $null }
		if ($null -ne $archive) { Close-OllamaPinnedArchive $archive; $archive = $null }
		Close-OllamaManagedRoot $root; $root = $null
		$result | ConvertTo-Json -Depth 12 -Compress
	} catch {
		[ordered]@{ ok = $false; phase = 'refused'; cleanup_pending = $true; ticket = $TicketId;
			error = $_.Exception.Message } | ConvertTo-Json -Compress
		exit 1
	} finally {
		if ($null -ne $stage) { Close-OllamaPreparedStage $stage }
		if ($null -ne $archive) { Close-OllamaPinnedArchive $archive }
		if ($null -ne $root) { Close-OllamaManagedRoot $root }
	}
}
