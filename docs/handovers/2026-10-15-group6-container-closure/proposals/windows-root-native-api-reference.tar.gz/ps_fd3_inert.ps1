# Inert original CRT fd3 receiving endpoint; no AHK, driver or network activity.
$ErrorActionPreference = 'Stop'
if (-not $IsWindows -or -not [Environment]::Is64BitProcess -or $PSVersionTable.PSVersion.Major -ne 7) {
    exit 1
}
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class InertFd3 {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct Startup {
        public uint Size; public IntPtr Reserved, Desktop, Title;
        public uint X, Y, Width, Height, XChars, YChars, Fill, Flags;
        public ushort Show, ReservedSize;
        public IntPtr ReservedData, Input, Output, Error;
    }
    [DllImport("kernel32.dll")] static extern void GetStartupInfoW(out Startup value);
    [DllImport("kernel32.dll", SetLastError = true)] static extern uint GetFileType(IntPtr handle);
    [DllImport("kernel32.dll")] static extern IntPtr GetStdHandle(int value);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool ReadFile(IntPtr handle, [Out] byte[] buffer, uint length, out uint count, IntPtr overlapped);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool WriteFile(IntPtr handle, byte[] buffer, uint length, out uint count, IntPtr overlapped);
    static byte[] Read(IntPtr handle, int length) {
        var output = new byte[length]; int offset = 0;
        while (offset < length) {
            var block = new byte[length - offset]; uint count;
            if (!ReadFile(handle, block, (uint)block.Length, out count, IntPtr.Zero) || count == 0 || count > block.Length)
                throw new InvalidOperationException("Inert channel read refused");
            Buffer.BlockCopy(block, 0, output, offset, (int)count); offset += (int)count;
        }
        return output;
    }
    static void Write(IntPtr handle, byte[] bytes) {
        int offset = 0;
        while (offset < bytes.Length) {
            var block = new byte[bytes.Length - offset]; uint count;
            Buffer.BlockCopy(bytes, offset, block, 0, block.Length);
            if (!WriteFile(handle, block, (uint)block.Length, out count, IntPtr.Zero) || count == 0 || count > block.Length)
                throw new InvalidOperationException("Inert channel write refused");
            offset += (int)count;
        }
    }
    public static void Receive() {
        Startup startup; GetStartupInfoW(out startup);
        if (IntPtr.Size != 8 || startup.ReservedData == IntPtr.Zero || startup.ReservedSize != 40 ||
            Marshal.ReadInt32(startup.ReservedData) != 4 || (Marshal.ReadByte(startup.ReservedData, 7) & 9) != 9)
            throw new InvalidOperationException("Inert CRT table refused");
        IntPtr channel = Marshal.ReadIntPtr(startup.ReservedData, 32);
        if (channel == IntPtr.Zero || channel == new IntPtr(-1) || GetFileType(channel) != 3)
            throw new InvalidOperationException("Inert pipe handle refused");
        byte[] header = Read(channel, 4); uint length = BitConverter.ToUInt32(header, 0);
        if (length < 1 || length > 4096) throw new InvalidOperationException("Inert frame bound refused");
        byte[] payload = Read(channel, (int)length);
        Write(channel, header); Write(channel, payload);
        Write(GetStdHandle(-11), Encoding.UTF8.GetBytes("INERT_FD3_COMPLETE é ☃\n"));
        Write(GetStdHandle(-12), Encoding.UTF8.GetBytes("INERT_FD3_STDERR α\n"));
    }
}
'@
try {
    [InertFd3]::Receive()
} catch {
    [Console]::Error.WriteLine('INERT_FD3_REFUSAL')
    exit 1
}
exit 0
