// tools/test/test-windows-ollama-guardian-artifacts.cjs

/**
 * ============================================================================
 * MODULE: Windows Managed Ollama Artifact Regression
 * DESCRIPTION:
 * Exercises the actual artifact contract with owned regular-byte fixtures.
 * Modeled PE headers test admission; they never qualify a native executable.
 * ============================================================================
 */

'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const contract = require('../build/guardian-artifact-contract.cjs');

const ROOT = path.resolve(__dirname, '..', '..');
const recipe = JSON.parse(fs.readFileSync(path.join(ROOT, contract.RECIPE)));
const rows = [];

function test(name, callback) {
	try {
		callback();
		rows.push({ name, ok: true });
	} catch (error) {
		rows.push({ name, ok: false, error: error.message });
	}
}

function clone(value) {
	return JSON.parse(JSON.stringify(value));
}

function header(dll = false, managed = false) {
	const bytes = Buffer.alloc(512);
	bytes.writeUInt16LE(0x5a4d, 0);
	bytes.writeUInt32LE(64, 0x3c);
	bytes.writeUInt32LE(0x4550, 64);
	bytes.writeUInt16LE(0x8664, 68);
	bytes.writeUInt16LE(dll ? 0x2000 : 0, 86);
	bytes.writeUInt16LE(0x20b, 88);
	bytes.writeUInt16LE(2, 156);
	bytes.writeUInt16LE(0x4140, 158);
	if (managed) {
		bytes.writeUInt32LE(16, 196);
		bytes.writeUInt32LE(4096, 312);
		bytes.writeUInt32LE(72, 316);
	}
	return bytes;
}

function owned(callback) {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ergopti-guardian-artifacts-'));
	try {
		for (const [index, name] of recipe.inputs.entries()) {
			const file = path.join(root, name);
			fs.mkdirSync(path.dirname(file), { recursive: true });
			fs.writeFileSync(file, name === contract.RECIPE ? JSON.stringify(recipe) : `owned-input-${index}\n`);
		}
		const output = path.join(root, 'owned-output');
		fs.mkdirSync(output);
		for (const [role, image] of Object.entries(recipe.roles)) {
			const bytes = image.source ? fs.readFileSync(path.join(root, image.source))
				: header(role !== 'Guardian', role === 'ManagedBridge');
			fs.writeFileSync(path.join(output, image.file), bytes);
		}
		callback(root, output, contract.sourceState(root, recipe));
	} finally {
		// This function creates and exclusively owns this exact temporary tree.
		fs.rmSync(root, { recursive: true });
	}
}

test('the canonical strict recipe retains all nine code image roles and five recording suites', () => {
	assert.equal(contract.validateRecipe(recipe), recipe);
	assert.deepEqual(Object.keys(recipe.roles), ['NativeModule', 'Guardian', 'ManagedBridge', 'FilesHelper',
		'PublicationHelper', 'ProducerHelper', 'SourceWorker', 'Launcher', 'InstallWorker']);
	assert.deepEqual(recipe.tests.slice(0, 5).map((row) => row.name), ['guardian_core_test', 'guardian_import_test',
		'guardian_retirement_test', 'guardian_service_test', 'guardian_inheritance_test']);
	assert.equal(recipe.tests.length, 6);
	assert.deepEqual(recipe.tests[5], { name: 'archive_intake_test', sources: ['archive_intake_test.c'], expected_cases: 21 });
});
test('intake bridge source and included late binder cannot escape the build fingerprint', () => {
	assert.deepEqual(recipe.bridge_sources, ['archive_intake.c']);
	assert.ok(recipe.inputs.includes('native/ollama_guardian/archive_intake_late.inc'));
	const omitted = clone(recipe);
	omitted.inputs = omitted.inputs.filter((name) => name !== 'native/ollama_guardian/archive_intake.c');
	assert.throws(() => contract.validateRecipe(omitted), /compiled guardian input/);
	const bypass = clone(recipe);
	bypass.bridge_sources = [];
	assert.throws(() => contract.validateRecipe(bypass), /bridge compilation/);
});

test('an omitted code role cannot produce a pin map', () => {
	const changed = clone(recipe);
	delete changed.roles.SourceWorker;
	assert.throws(() => contract.validateRecipe(changed), /code role/);
});
test('warning suppression cannot be appended to the strict compiler recipe', () => {
	const changed = clone(recipe);
	changed.compiler_flags.push('/W0');
	assert.throws(() => contract.validateRecipe(changed), /compiler flags/);
});
test('the console host cannot replace the qualified GUI CRT contract', () => {
	const changed = clone(recipe);
	changed.host_link_flags = ['/SUBSYSTEM:CONSOLE'];
	assert.throws(() => contract.validateRecipe(changed), /GUI CRT/);
});
test('source traversal and duplicate fingerprint inputs are refused', () => {
	assert.throws(() => contract.relative('native/../foreign.c'), /relative source/);
	const changed = clone(recipe);
	changed.inputs.push(changed.inputs[0]);
	assert.throws(() => contract.validateRecipe(changed), /listed twice/);
});
test('every admitted source byte contributes to the build fingerprint', () => owned((root, _output, before) => {
	fs.appendFileSync(path.join(root, recipe.inputs[0]), 'changed');
	assert.notEqual(contract.sourceState(root, recipe).fingerprint, before.fingerprint);
}));
test('a directory cannot substitute for an admitted source image', () => owned((root) => {
	const file = path.join(root, recipe.inputs[0]);
	fs.unlinkSync(file);
	fs.mkdirSync(file);
	assert.throws(() => contract.sourceState(root, recipe), /regular file/);
}));
test('the host requires native AMD64 PE32 plus GUI and all mitigations', () => {
	const valid = header();
	contract.peContract(valid, false);
	const changed = Buffer.from(valid);
	changed.writeUInt16LE(3, 156);
	assert.throws(() => contract.peContract(changed, false), /GUI subsystem/);
	changed.writeUInt16LE(2, 156);
	changed.writeUInt16LE(0xaa64, 68);
	assert.throws(() => contract.peContract(changed, false), /AMD64/);
});
test('a bridge without CFG or DLL identity is refused', () => {
	const changed = header(true);
	contract.peContract(changed, true);
	changed.writeUInt16LE(0x140, 158);
	assert.throws(() => contract.peContract(changed, true), /ASLR, DEP and CFG/);
	assert.throws(() => contract.peContract(header(), true), /module type/);
});
test('the managed producer requires an actual CLR directory in an AMD64 library', () => {
	contract.managedContract(header(true, true));
	assert.throws(() => contract.managedContract(header(true)), /managed library/);
});
test('changed build inputs refuse before metadata publication', () => owned((root, output, plan) => {
	fs.appendFileSync(path.join(root, recipe.inputs[0]), 'drift');
	assert.throws(() => contract.seal(root, output, plan), /changed before publication/);
	assert.equal(fs.existsSync(path.join(output, 'guardian.manifest.json')), false);
}));
test('substituted packaged worker bytes refuse before metadata publication', () => owned((root, output, plan) => {
	fs.appendFileSync(path.join(output, recipe.roles.SourceWorker.file), 'different');
	assert.throws(() => contract.seal(root, output, plan), /differs from its admitted/);
	assert.equal(fs.existsSync(path.join(output, 'guardian.manifest.json')), false);
}));
test('all image pins carry their independent exact byte digest', () => owned((root, output, plan) => {
	const manifest = contract.seal(root, output, plan);
	for (const image of Object.values(manifest.images)) {
		const bytes = fs.readFileSync(path.join(output, image.file));
		assert.equal(image.bytes, bytes.length);
		assert.equal(image.sha256, require('node:crypto').createHash('sha256').update(bytes).digest('hex'));
	}
	const generated = fs.readFileSync(path.join(output, 'ollama_guardian_images.ahk'));
	assert.deepEqual([...generated.subarray(0, 3)], [239, 187, 191]);
	assert.equal(generated.includes(13), false);
	assert.match(generated.toString('utf8'), /OllamaGuardianCodePins\(\)/);
	assert.equal((generated.toString('utf8').match(/Map\("path"/g) || []).length, 9);
}));
test('malformed generated pin names cannot inject an AutoHotkey expression', () => owned((root, output, plan) => {
	const manifest = contract.seal(root, output, plan);
	manifest.images.NativeModule.file = 'bad"), Run("bad';
	assert.throws(() => contract.renderPins(manifest), /pin is malformed/);
}));
test('metadata publication cannot replace an existing build receipt', () => owned((root, output, plan) => {
	contract.seal(root, output, plan);
	const before = fs.readFileSync(path.join(output, 'guardian.manifest.json'));
	assert.throws(() => contract.seal(root, output, plan), /EEXIST/);
	assert.deepEqual(fs.readFileSync(path.join(output, 'guardian.manifest.json')), before);
}));
test('zero exit with an omitted or unordered recording case stays red', () => {
	contract.recordingComplete('1..2\nok 1 - first\nok 2 - second\n', 0, 2);
	assert.throws(() => contract.recordingComplete('ok 1 - first\n', 0, 2), /incomplete/);
	assert.throws(() => contract.recordingComplete('ok 2 - second\nok 1 - first\n', 0, 2), /incomplete/);
});
test('recording warnings and nonzero native status cannot publish success', () => {
	assert.throws(() => contract.recordingComplete('warning\nok 1 - first\n', 0, 1), /diagnostic/);
	assert.throws(() => contract.recordingComplete('ok 1 - first\n', 1, 1), /did not succeed/);
	assert.throws(() => contract.recordingComplete('ok 1 - first', 0, 1), /truncated/);
});

test('the host and managed producer cannot compile outside the fingerprint', () => {
	for (const name of ['guardian_host.c', 'guardian_service.c', 'guardian_service.def', 'SourceProducerNative.cs']) {
		const changed = clone(recipe);
		changed.inputs = changed.inputs.filter((input) => input !== 'native/ollama_guardian/' + name);
		assert.throws(() => contract.validateRecipe(changed), /compiled guardian input/);
	}
});
test('local include dependencies must be fingerprinted before reading them', () => owned((root) => {
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), '#include "not-admitted.h"\n');
	// The deliberately absent file makes read-before-admission fail for a
	// different reason. Only the actual closure refusal satisfies this oracle.
	assert.throws(() => contract.sourceState(root, recipe), /local guardian dependency is outside/);
}));

test('local include closure cannot depend on filename extension', () => owned((root) => {
	const header = 'native/ollama_guardian/owned.inc';
	const changed = clone(recipe);
	changed.inputs.push(header);
	fs.writeFileSync(path.join(root, header), '#include "not-admitted.h"\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), '#include "owned.inc"\n');
	assert.throws(() => contract.sourceState(root, changed), /local guardian dependency is outside/);
}));

test('an unlisted local angle include refuses before contents are read', () => owned((root) => {
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/owned.inc'), 'unfingerprinted-local-angle\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), '#include <owned.inc>\n');
	assert.throws(() => contract.sourceState(root, recipe), /local guardian dependency is outside/);
}));

test('Windows case-insensitive local angle resolution cannot escape admission', () => owned((root) => {
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/Owned.INC'), 'case-shadow\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), '#include <owned.inc>\n');
	assert.throws(() => contract.sourceState(root, recipe), /local guardian dependency is outside/);
	const admitted = clone(recipe);
	admitted.inputs.push('native/ollama_guardian/Owned.INC');
	assert.equal(contract.sourceState(root, admitted).sources.length, admitted.inputs.length);
}));

test('a local SDK-name shadow is fingerprinted before the compiler can load it', () => owned((root) => {
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/Windows.H'), 'unlisted-sdk-shadow\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), '#include <windows.h>\n');
	assert.throws(() => contract.sourceState(root, recipe), /local guardian dependency is outside/);
}));

test('an admitted local angle dependency retains recursive whole-byte closure', () => owned((root) => {
	const admitted = clone(recipe);
	admitted.inputs.push('native/ollama_guardian/owned.inc');
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/owned.inc'), '#include <unlisted.inc>\n');
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/unlisted.inc'), 'unlisted-nested-body\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), '#include <owned.inc>\n');
	assert.throws(() => contract.sourceState(root, admitted), /local guardian dependency is outside/);
}));

test('case aliases cannot fingerprint two Windows spellings of one source', () => {
	const changed = clone(recipe);
	changed.inputs.push(changed.inputs[0].toUpperCase());
	assert.throws(() => contract.validateRecipe(changed), /listed twice/);
});

test('a quoted ancestor shadow cannot be substituted by an admitted source-root file', () => owned((root) => {
	const changed = clone(recipe);
	for (const name of ['parent/first.inc', 'parent/deep/second.inc', 'shared.inc']) {
		const input = 'native/ollama_guardian/' + name;
		changed.inputs.push(input);
		fs.mkdirSync(path.dirname(path.join(root, input)), {recursive: true});
	}
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/parent/first.inc'), '#include <parent/deep/second.inc>\n');
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/parent/deep/second.inc'), '#include "shared.inc"\n');
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/shared.inc'), 'admitted-root-body\n');
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/parent/shared.inc'), 'unlisted-ancestor-body\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), '#include <parent/first.inc>\n');
	assert.throws(() => contract.sourceState(root, changed), /local guardian dependency is outside/);
}));

// Each form runs both a positive recursive closure and a present-but-unlisted
// dependency refusal. These are filesystem/contract controls, not C execution.
const lexicalForms = [
	['no-space angle', (name) => `#include<${name}>\n`],
	['no-space quoted', (name) => `#include"${name}"\n`],
	['comment before keyword', (name) => `#/**/include <${name}>\n`],
	['comment after keyword', (name) => `#include/**/<${name}>\n`],
	['spliced keyword', (name) => `#inc\\\nlude<${name}>\n`],
	['spliced operand', (name) => `#include\\\n<${name}>\n`],
	['spliced header name', (name) => `#include<${name.slice(0, 2)}\\\n${name.slice(2)}>\n`],
	['CRLF splice', (name) => `#inc\\\r\nlude<${name}>\n`],
	['leading block comment', (name) => `/* owned comment */#include<${name}>\n`]
];

for (const [form, directive] of lexicalForms) {
	test(`literal includes retain recursive byte closure: ${form}`, () => owned((root) => {
		const admitted = clone(recipe);
		const first = 'native/ollama_guardian/owned.inc', leaf = 'native/ollama_guardian/leaf.inc';
		admitted.inputs.push(first, leaf);
		fs.writeFileSync(path.join(root, first), directive('leaf.inc'));
		fs.writeFileSync(path.join(root, leaf), 'owned-leaf-bytes\n');
		fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), directive('owned.inc'));
		const closure = contract.sourceClosure(root, admitted);
		assert(closure.includes(first), 'The actual first dependency must be visited');
		assert(closure.includes(leaf), 'The actual nested dependency must be visited');
		const before = contract.sourceState(root, admitted).fingerprint;
		fs.appendFileSync(path.join(root, leaf), '// changed admitted bytes\n');
		assert.notEqual(contract.sourceState(root, admitted).fingerprint, before);
	}));
	test(`literal includes refuse an unread unlisted local dependency: ${form}`, () => owned((root) => {
		const unlisted = path.join(root, 'native/ollama_guardian/owned.inc');
		fs.writeFileSync(unlisted, 'present-but-unadmitted-bytes\n');
		fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'), directive('owned.inc'));
		const read = fs.readFileSync;
		let unlistedReads = 0;
		fs.readFileSync = function (file, ...args) {
			if ((typeof file === 'string' || Buffer.isBuffer(file)) && path.resolve(String(file)) === unlisted) {
				unlistedReads += 1;
				throw new Error('The control observed an unadmitted contents read.');
			}
			return read.call(this, file, ...args);
		};
		try {
			assert.throws(() => contract.sourceState(root, recipe), /local guardian dependency is outside/);
			assert.equal(unlistedReads, 0, 'Closure must refuse before loading unadmitted contents');
		} finally {
			fs.readFileSync = read;
		}
	}));
}

test('line splicing occurs before continued line comments hide directive text', () => owned((root) => {
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/owned.inc'), 'unlisted-comment-target\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'),
		'// continued comment\\\n#include<owned.inc>\n');
	assert.doesNotThrow(() => contract.sourceState(root, recipe));
}));

test('a leading UTF-8 BOM preserves a recursive literal include closure', () => owned((root) => {
	const admitted = clone(recipe);
	const first = 'native/ollama_guardian/owned.inc', leaf = 'native/ollama_guardian/leaf.inc';
	admitted.inputs.push(first, leaf);
	fs.writeFileSync(path.join(root, first), '\ufeff#include<leaf.inc>\n');
	fs.writeFileSync(path.join(root, leaf), 'owned-bom-leaf\n');
	const host = path.join(root, 'native/ollama_guardian/guardian_host.c');
	fs.writeFileSync(host, '\ufeff#include<owned.inc>\n' + fs.readFileSync(host, 'utf8'));
	const closure = contract.sourceClosure(root, admitted);
	assert(closure.includes(first), 'The initial BOM cannot hide the first dependency');
	assert(closure.includes(leaf), 'The nested BOM cannot hide the recursive dependency');
}));

test('a leading UTF-8 BOM cannot exempt a present unlisted include from admission', () => owned((root) => {
	const host = path.join(root, 'native/ollama_guardian/guardian_host.c');
	const unlisted = path.join(root, 'native/ollama_guardian/owned.inc');
	fs.writeFileSync(unlisted, 'present-bom-target\n');
	fs.writeFileSync(host, '\ufeff#include<owned.inc>\n' + fs.readFileSync(host, 'utf8'));
	const read = fs.readFileSync;
	let unlistedReads = 0;
	fs.readFileSync = function (file, ...args) {
		if ((typeof file === 'string' || Buffer.isBuffer(file)) && path.resolve(String(file)) === unlisted) {
			unlistedReads += 1;
			throw new Error('The control observed an unadmitted BOM contents read.');
		}
		return read.call(this, file, ...args);
	};
	try {
		assert.throws(() => contract.sourceState(root, recipe), /local guardian dependency is outside/);
		assert.equal(unlistedReads, 0);
	} finally {
		fs.readFileSync = read;
	}
}));

test('literal and commented directive text cannot invent a compiler dependency', () => owned((root) => {
	fs.writeFileSync(path.join(root, 'native/ollama_guardian/owned.inc'), 'unlisted-decoy\n');
	fs.appendFileSync(path.join(root, 'native/ollama_guardian/guardian_host.c'),
		'const char *decoy = "#include<owned.inc>";\n/* #include<owned.inc> */\n');
	assert.doesNotThrow(() => contract.sourceState(root, recipe));
	assert.equal(contract.sourceClosure(root, recipe).includes('native/ollama_guardian/owned.inc'), false);
}));

test('ambiguous split directives and trigraphs refuse before dependency resolution', () => owned((root) => {
	const host = path.join(root, 'native/ollama_guardian/guardian_host.c');
	const before = fs.readFileSync(host);
	for (const spelling of ['#/* split\n*/include<owned.inc>\n', '#inc\\ \nlude<owned.inc>\n', '??=include<owned.inc>\n', '%:include<owned.inc>\n']) {
		fs.writeFileSync(host, Buffer.concat([before, Buffer.from(spelling)]));
		assert.throws(() => contract.sourceState(root, recipe), /unsupported (split directive|preprocessor trigraphs|preprocessor digraphs)/);
	}
}));

test('unsupported source encodings cannot hide a literal compiler dependency', () => owned((root) => {
	const host = path.join(root, 'native/ollama_guardian/guardian_host.c');
	const content = '#include<owned.inc>\n';
	const little = Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(content, 'utf16le')]);
	const big = Buffer.from(little);
	big.swap16();
	const specimens = [little, big, Buffer.concat([Buffer.from([0xff]), Buffer.from(content)]),
		Buffer.from('\0' + content)];
	for (const specimen of specimens) {
		fs.writeFileSync(host, specimen);
		assert.throws(() => contract.sourceState(root, recipe), /requires exact UTF-8 without raw NUL/);
	}
}));


const nativeInspectionName = 'Windows PS5 inspects the actual host and exact bridge export arguments';
if (process.platform === 'win32') {
	test(nativeInspectionName, () => {
		const systemRoot = process.env.SystemRoot;
		assert.equal(typeof systemRoot, 'string', 'Windows PS5 system root must be present');
		assert(systemRoot.length > 0);
		const executable = path.join(systemRoot, 'System32/WindowsPowerShell/v1.0/powershell.exe');
		const { spawnSync } = require('node:child_process');
		const result = spawnSync(executable, ['-NoLogo', '-NoProfile', '-NonInteractive', '-File',
			path.join(ROOT, 'tools/test/test_guardian_image_inspection.ps1'), '-Repository', ROOT],
		{ encoding: 'utf8', windowsHide: true, timeout: 30000 });
		assert.ifError(result.error);
		assert.equal(result.signal, null, result.stderr);
		assert.equal(result.status, 0, result.stdout + result.stderr);
		assert.equal(result.stderr, '');
		const lines = result.stdout.trim().split(/\r?\n/);
		assert.equal(lines[0], '1..8');
		assert.equal(lines.length, 9, 'Only the eight actual inspection control rows may be emitted');
		for (let index = 1; index <= 8; index++) assert.match(lines[index], new RegExp('^ok ' + index + ' - '));
	});
} else {
	rows.push({ name: nativeInspectionName, ok: true, skipped: 'Windows PS5 actual function controls' });
}

const managedCompileName = 'Windows PS5 compiles the actual managed branch with exact options and fatal diagnostics';
if (process.platform === 'win32') {
	test(managedCompileName, () => owned((directory) => {
		assert.equal(typeof process.env.SystemRoot, 'string');
		assert(process.env.SystemRoot.length > 0);
		const { spawnSync } = require('node:child_process');
		const executable = path.join(process.env.SystemRoot, 'System32/WindowsPowerShell/v1.0/powershell.exe');
		const result = spawnSync(executable, ['-NoLogo', '-NoProfile', '-NonInteractive', '-File',
			path.join(ROOT, 'tools/test/test_guardian_managed_compile.ps1'), '-Repository', ROOT,
			'-Namespace', directory], { encoding: 'utf8', windowsHide: true });
		assert.ifError(result.error);
		assert.equal(result.signal, null, result.stderr);
		assert.equal(result.status, 0, result.stdout + result.stderr);
		assert.equal(result.stderr, '');
		const lines = result.stdout.trim().split(/\r?\n/);
		assert.equal(lines[0], '1..3');
		assert.equal(lines.length, 4);
		for (let index = 1; index <= 3; index++) assert.match(lines[index], new RegExp('^ok ' + index + ' - '));
	}));
} else {
	rows.push({ name: managedCompileName, ok: true, skipped: 'Windows PS5 native managed compiler controls' });
}

console.log('TAP version 14');
console.log(`1..${rows.length}`);
for (const [index, row] of rows.entries()) {
	console.log(`${row.ok ? 'ok' : 'not ok'} ${index + 1} - ${row.name}${row.skipped ? ' # SKIP ' + row.skipped : ''}`);
	if (!row.ok) console.log(`  # ${row.error}`);
}
console.log(`# passed: ${rows.filter((row) => row.ok).length}/${rows.length}`);
process.exitCode = rows.every((row) => row.ok) ? 0 : 1;
