from pathlib import Path
import subprocess,os,json,time,hashlib,stat,concurrent.futures,re,datetime
from zoneinfo import ZoneInfo
R=Path('/workspace/ergopti-macos-field-admission');O=Path('/workspace/scratch/oct28-field-admission');F=json.loads((O/'source-freeze.json').read_text());TREE=F['tree']
def now():return datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def physical(label):
 mismatches=[];n=total=0;digest=hashlib.sha256()
 for entry in git('ls-files','--stage','-z').split(b'\0'):
  if not entry:continue
  head,path=entry.split(b'\t',1);mode,oid,stage=head.split();p=R/os.fsdecode(path);st=p.lstat();data=os.fsencode(os.readlink(p))if stat.S_ISLNK(st.st_mode)else p.read_bytes();observed=b'120000'if stat.S_ISLNK(st.st_mode)else b'100755'if st.st_mode&0o111 else b'100644';actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()
  if observed!=mode or actual!=oid:mismatches.append(os.fsdecode(path))
  digest.update(entry+b'\0');n+=1;total+=len(data)
 d={'at_paris':now(),'tree':git('write-tree').decode().strip(),'files':n,'bytes':total,'digest':digest.hexdigest(),'mismatches':mismatches,'unstaged':git('diff','--name-only').decode(),'untracked':git('ls-files','--others','--exclude-standard').decode()};(O/('physical-'+label+'.json')).write_text(json.dumps(d,indent=2)+'\n');assert d['tree']==TREE and not mismatches and not d['unstaged'] and not d['untracked'];return d
def environment(zone):
 env=dict(os.environ);env['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH'];env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';env['USER']=env['LOGNAME']='agent'
 for key,leaf in [('TMPDIR','tmpdir'),('XDG_RUNTIME_DIR','xdg_runtime_dir'),('XDG_CACHE_HOME','xdg_cache_home'),('XDG_CONFIG_HOME','xdg_config_home'),('XDG_DATA_HOME','xdg_data_home'),('XDG_STATE_HOME','xdg_state_home')]:
  p=O/zone/leaf;p.mkdir(parents=True,exist_ok=True,mode=0o700);env[key]=str(p)
 return env
D={'state':'RUNNING','pid':os.getpid(),'at_paris':now(),'source':F,'gates':[]};lock=__import__('threading').Lock()
def save():
 p=O/'gates.pending.json';p.write_text(json.dumps(D,indent=2)+'\n');p.replace(O/'gates.json')
def run(name,command,env):
 assert git('write-tree').decode().strip()==TREE
 for path,sha in F['paths'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==sha
 start=time.monotonic();log=O/(name+'.log')
 with log.open('wb')as f:p=subprocess.run(command,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'actual_exit':p.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 with lock:D['gates'].append(row);save()
 print(json.dumps(row),flush=True);return p.returncode
assert os.getuid()!=0;D['physical_initial']=physical('initial');save()
def hs():
 env=environment('hs');old=json.loads(Path('/workspace/scratch/oct28-final32-hs/receipt.json').read_text())
 for g in old['gates']:
  if g['name'].startswith('hs-'):
   if run(g['name'],g['command'],env)!=0:return False
 return True
def quick():
 env=environment('quick');commands=[('field-contract',['node','tools/test/test-macos-field-run-contract.cjs']),('strict',['npm','run','-s','lint:conventions:strict']),('format',['npm','run','-s','format:check']),('gen-check',['npm','run','-s','gen:check']),('ahk-locals',['npm','run','-s','test:ahk-local-same-as-global']),('windows-source',['node','tools/test/test-windows-updater-original-source.cjs']),('source-encoding',['node','tools/test/test-source-encoding.cjs']),('ahk-encoding',['npm','run','-s','test:ahk-encoding']),('undefined-lua',['node','tools/test/test-lua-undefined-globals.cjs']),('false-green',['node','tools/test/find-false-greens.cjs']),('pinned-source',['node','tools/test/test-no-pinned-source-reads-lua.cjs']),('verify-plan',['node','tools/test/verify-change.cjs','--plan'])]
 return all([run(n,c,env)==0 for n,c in commands])
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(lambda f:f(),[hs,quick]))
D['physical_final']=physical('final');D['state']='ALL_GATES_ACTUAL0'if all(results)else'FAILED';D['finished_paris']=now();save();raise SystemExit(0 if all(results)else 1)
