package.path = "./?.lua;./?/init.lua;../_shared/lua/?.lua;../_shared/lua/?/init.lua;./tests/stubs/?.lua;" .. package.path
local hs = require("tests.stubs.hs")
local Json = require("json")
local f = assert(io.open("../_shared/tests/corpus/updater/release_parser_vectors.json", "rb"))
local raw = assert(f:read("*a")); assert(f:close())
local function row(root)
 for _, value in ipairs(root.vectors) do if value.id == "notes_control_escapes" then return value end end
 error("control vector missing")
end
local function bytes(value)
 local out = {}; for index = 1, #value do out[index] = tostring(value:byte(index)) end
 return table.concat(out, ",")
end
local native_row = row(Json.decode(raw))
local stub_row = row(hs.json.decode(raw))
local expected = "Back" .. string.char(8) .. "form" .. string.char(12)
assert(native_row.expected == expected)
assert(native_row.input.body == stub_row.input.body)
print("shared-decoded expected bytes=" .. bytes(native_row.expected))
print("stub-decoded expected bytes=" .. bytes(stub_row.expected))
for _, mode in ipairs({ "cold_json", "warm_json" }) do
 package.loaded["updater.release_parser"] = nil
 package.loaded["json"] = mode == "warm_json" and Json or nil
 local Parser = require("updater.release_parser")
 local actual = Parser.parse_notes(stub_row.input.body)
 assert(actual == expected, "parser changed valid control bytes under " .. mode)
 print(mode .. " actual bytes=" .. bytes(actual) .. " matches independent expected=" .. tostring(actual == expected)
   .. " matches stub corpus expected=" .. tostring(actual == stub_row.expected))
end
