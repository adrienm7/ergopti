# Scoped native publication qualification

PASS on actual unprivileged Linux kernel6.18.44, UID/eUID1000 and zero
inherited/permitted/effective/ambient capabilities. Six serial command exits0.
Original11 scenarios, revision2 13 native +2 explicitly injected refusal/retry
scenarios, canonical generated sharedlib and256 actual luv/native clock brackets
completed. No skips. Candidate source/header/control hashes equal before/after.

The original11 deliberately retains named/directory debt until its native process
exit. The revision2 cleanup assertions acknowledge its descriptors/names and new
readers. This is port qualification, not whole updater/install retirement proof.
The frozen source packet and main checkout are unchanged. Lower supported kernels,
Ubuntu distributions/installed packaging, predecessor/mutation causal controls,
opaque registry joins, actual checksum+old-timer retirement and tar/install
acceptance remain UNEXECUTED. See RESULT.json and logs for exact commands/exits.

Exclusive local test slot was released immediately after terminal clock control.
