﻿#Requires AutoHotkey v2.0+
#SingleInstance Off
#Warn All, StdOut
#Warn VarUnset, Off
#Warn LocalSameAsGlobal, Off
SetWorkingDir(A_ScriptDir)
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\tests\test_framework.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\infra\wall_clock.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\infra\json.ahk
#Include Z:\workspace\scratch\windows-audit-round6\delivery-review\restore-publication-identity\private-isolated-filesystem.ahk
#Include Z:\workspace\scratch\windows-audit-round6\delivery-review\restore-publication-identity\private-isolated-backup.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\infra\redact.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\_generated\app_dirs.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\_generated\logger_sub_files.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\infra\logger.ahk
global _SharedDir := "Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\_shared"
global _R7HP_LogRoot := A_Temp . "\ergopti_r7_config_proposal_logs_" . DllCall("kernel32\GetCurrentProcessId", "UInt") . "_" . A_TickCount
global _LogsDir := _R7HP_LogRoot . "\", _DefaultLogsDir := _LogsDir
_RIT_WriteFile(Path, Text) {
 SplitPath(Path, , &Directory)
 DirCreate(Directory)
 FileAppend(Text, Path, "UTF-8-RAW")
}
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\tests\fixtures\r7_isolated_config_proposal.ahk
FSCreateDirectoryExclusiveStrict(_R7HP_LogRoot)
LoggerInit()
if !FSWriteCreateDurable("Z:\workspace\scratch\windows-audit-round6\delivery-review\restore-publication-identity\473-isolated-runtime.json", "{" . Chr(34) . "logs" . Chr(34) . ":" . JsonStringLiteral(_R7HP_LogRoot) . "}")
 throw Error("The isolated LoggerInit ownership receipt was not created.")
RunTests()
