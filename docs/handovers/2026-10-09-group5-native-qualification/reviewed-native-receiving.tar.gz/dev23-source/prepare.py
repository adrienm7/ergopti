from pathlib import Path
import subprocess,json,hashlib,difflib,re
R=Path('/workspace/ergopti');OUT=Path(__file__).parent
B='56cbdc4ecf8a0659a4d57483508f478445297043';H='6e67c5da3a9e91edbd6a9d692c71a557a7d7c567';D='9652afc3d121b19851e02d93446d91e4c1fcc877';T='e07ba5bcb33c1110784e0797515dcfea12b7d355'
L=Path('/workspace/ergopti-group5-work/publications/merge-locales-d824-source-d_ffaf6e');HC=Path('/workspace/ergopti-group5-work/publications/merge-healthcheck-d824-source-djigbhp0');M=Path('/tmp/main-dev-d824-merge-proposal-e50z40nb')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def optional_oid(ref,path):
 q=subprocess.run(['git','-C',str(R),'rev-parse','--verify',ref+':'+path],capture_output=True);return q.stdout.decode().strip() if q.returncode==0 else None
def blob(ref,path):return git('show',ref+':'+path)
def write(path,b):
 p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def js(path,x):write(path,(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode())
def no_dups(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,k;d[k]=v
 return d
def parse(b):return json.loads(b,object_pairs_hook=no_dups)
def inverse_delta(base,ours,merged):
 # Only exact uniquely occurring changed spans of the known original delta are undone.
 a=base.splitlines(True);b=ours.splitlines(True);c=merged
 edits=[]
 for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if op=='equal':continue
  old=b''.join(a[i:j]);new=b''.join(b[k:l]);assert new and c.count(new)==1,(op,new[:80]);c=c.replace(new,old,1)
  edits.append({'operation':op,'old_sha256':sha(old),'new_sha256':sha(new),'new_lines':l-k,'old_lines':j-i})
 return c,edits
def inverse_context(base,ours,merged):
 a=base.splitlines(True);b=ours.splitlines(True);edits=[];ranges=[]
 for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if op=='equal':continue
  before=b''.join(b[max(0,k-3):k]);after=b''.join(b[l:l+3])
  old=b''.join(a[i:j]);new=b''.join(b[k:l]);target=before+new+after
  assert new and merged.count(target)==1,(op,new[:80])
  pos=merged.index(target)+len(before);assert merged[pos:pos+len(new)]==new
  ranges.append((pos,pos+len(new),old))
  edits.append({'operation':op,'old_sha256':sha(old),'new_sha256':sha(new),'surrounding_context_sha256':sha(before+after),'new_lines':l-k,'old_lines':j-i})
 c=merged
 for start,end,old in sorted(ranges,reverse=True):c=c[:start]+old+c[end:]
 return c,edits
# Authenticate original sealed locale census (all subjects, no execution of author scripts).
for p,dig in json.loads((L/'CENSUS.json').read_text()).items():assert sha((L/p).read_bytes())==dig,p
keys={'menu.global.karabiner_runtime','menu.global.karabiner_runtime.owned','menu.global.karabiner_runtime.shared','menu.global.karabiner_runtime_unavailable','menu.metrics.physical_source','menu.metrics.physical_source.ledger','menu.metrics.physical_source.stream','menu.metrics.physical_source_unavailable','platform_reason.physical_stream_macos_only'}
entries=[];patch_h=[];patch_d=[]
for lang in 'ar cs da de en es fr he hi it ja ko nl no pl pt ru sv tr uk zh'.split():
 p=f'static/ergopti_plus/_shared/data/locales/{lang}.json';base=blob(B,p);ours=blob(H,p);dev=blob(D,p);post=(L/'proposed'/p).read_bytes()
 for label,data in [('base',base),('group5',ours),('latestDev',dev)]:assert data==(L/'preimages'/label/p).read_bytes(),(p,label)
 bd,hd,dd,pd=map(parse,[base,ours,dev,post]);assert set(hd)-set(bd)==keys;assert all(hd[k]==bd[k] for k in bd);assert all(pd[k]==dd[k] for k in dd);assert list(pd)==list(dd)+[k for k in pd if k not in dd];assert set(pd)-set(dd)==keys;assert all(pd[k]==hd[k] for k in keys)
 kept=[];removed=[]
 for line in post.splitlines(True):
  m=re.match(rb'\s*"([^"]+)"\s*:',line)
  if m and m.group(1).decode() in keys:removed.append(line)
  else:kept.append(line)
 assert len(removed)==9
 assert kept[-2].endswith(b',\n');kept[-2]=kept[-2][:-2]+b'\n';assert b''.join(kept)==dev
 # Original language-specific line values are preserved even where final separator differs.
 old_lines=ours.splitlines(True)
 for line in removed:assert any(line.rstrip(b'\n,')==x.rstrip(b'\n,') for x in old_lines)
 entries.append((p,base,ours,dev,post,{'dev_exact_inverse':True,'borrowed_keys':sorted(keys),'borrowed_line_bytes_except_separator_whole':True,'old_proposal_identical':True}))
for p,files in [('static/ergopti_plus/macos/ui/healthcheck/core.lua',(HC/'core.lua.base',HC/'core.lua.ours',HC/'core.lua.dev',HC/'core.lua.proposed')),('static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/main.swift',(M/'base.swift',M/'ours.swift',M/'theirs.swift',M/'proposed-main.swift'))]:
 base,ours,dev=[blob(ref,p) for ref in [B,H,D]];post=files[3].read_bytes()
 for data,file in zip([base,ours,dev],files[:3]):assert data==file.read_bytes(),p
 recovered,edits=inverse_delta(base,ours,post);assert recovered==dev,p
 if p.endswith('core.lua'):
  scope=post[post.index(b'local ADAPTER_SPECS'):post.index(b'local function check_modules')];ids=re.findall(rb'id\s*=\s*"([^"]+)"',scope);assert len(ids)==len(set(ids))==59
 entries.append((p,base,ours,dev,post,{'dev_exact_inverse':True,'original_group5_delta':edits,'old_proposal_identical':True}))
records=[]
for p,base,ours,dev,post,proof in entries:
 assert b'\r' not in post;post.decode('utf8');assert b'<<<<<<<' not in post
 rec={'path':p,'preimages':{},'postimage':{'sha256':sha(post),'bytes':len(post)},'preservation':proof}
 for label,ref,data in [('base',B,base),('group5',H,ours),('dev',D,dev)]:
  write('preimages/'+label+'/'+p,data);rec['preimages'][label]={'commit':ref,'Git_blob':git('rev-parse',ref+':'+p).decode().strip(),'sha256':sha(data),'bytes':len(data)}
 write('proposed/'+p,post);records.append(rec)
 patch_h.extend(difflib.unified_diff(ours.decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 patch_d.extend(difflib.unified_diff(dev.decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
assert len(records)==23
write('GROUP5-TO-RESOLVED.patch',''.join(patch_h).encode());write('DEV-TO-RESOLVED.patch',''.join(patch_d).encode())
# Genuine auto-merged source ownership; no generator is executed.
auto=[]
paths=['static/ergopti_plus/_shared/modules/features/manifest.toml','tools/build/build-menu-manifest.js','tools/build/build-features-manifest.js','tools/lib/configuration-scopes.cjs','tools/lib/karabiner-runtime-setting.cjs','tools/codegen/codegen-locale-tables.cjs','static/ergopti_plus/_shared/data/locale_order.json','static/ergopti_plus/_shared/data/locale_names.json','tools/build/generators.cjs','tools/build/build-domain.cjs','package.json','tools/codegen/gen-architecture-diagram.cjs']
for p in paths:
 data=blob(T,p);assert b'<<<<<<<' not in data;write('merged-generator-inputs/'+p,data)
 rec={'path':p,'merged_Git_blob':git('rev-parse',T+':'+p).decode().strip(),'merged_sha256':sha(data),'bytes':len(data),'parent_blobs':{ref:optional_oid(ref,p) for ref in [H,D]}}
 if p in paths[:2]:
  recovered,delta=inverse_context(blob(B,p),blob(H,p),data);assert recovered==blob(D,p);rec.update({'entire_dev_after_original_group5_inverse':True,'group5_delta':delta})
 auto.append(rec)
js('PREIMAGES-AND-PRESERVATION.json',{'base':B,'group5':H,'dev':D,'merge_preview_tree':T,'source_paths':23,'locale_additions':189,'new_source_changes_to_old_proposals':0,'entries':records,'auto_merged_inputs':auto,'qualification':'SOURCE_ONLY; generators/tests/native/CI not executed; canonical/index/refs untouched'})
print(json.dumps({'packet':str(OUT),'paths':len(records),'auto_inputs':len(auto),'patch_sha256':sha((''.join(patch_h)).encode()),'post_main':records[-1]['postimage'],'post_health':records[-2]['postimage']}))
