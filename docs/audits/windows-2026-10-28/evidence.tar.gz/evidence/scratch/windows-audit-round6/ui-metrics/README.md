# Windows metrics calendar audit

The confirmed DST streak bug is fixed in commit9e3335dee838310d587b9c7d81e2f79fe1c8bcdc. See streak-proof.json and the before/after full test logs. Both Windows streak KPIs incorrectly showed two days for three adjacent local dates spanning the Paris autumn fallback. The fix compares local calendar predecessors instead of elapsed milliseconds.

The actual loaded page, its own renderDashboard and the realhostpublication handlers run for Windows, macOS and Linux. Only browserports are controlled. Thirty new page controls cover timezone transitions, leap/year boundaries, missing/ineligible days and unordered data. All45 controls pass; prior27loaded category cases and identifier matrices also pass. NormalHusky installation and the actual commit hook succeeded. FullcommonCI is still required; no native OSqualification is claimed by this JS VM coverage.

Other calendar/drilldown findings remain hypotheses until separately reproduced and fixed. This worktree stays active for further auditing.

The accepted-date drilldown bug is fixed separately in commita17cb9b500456ff79df9e55dc497eb520da024f1. Its proof is drilldown-proof.json. Monday-only aggregation contained23characters while the actual modal chart showed77 and exposedSunday/Tuesdaylayouts. The fix makes both detail families consume the alreadyaccepted aggregate date projection. The fullfocused suite now passes69/69, including24new loadedpage modality cases across all3hosttransports. Normalhooks and allfocused gates passed; fullcommonCI remains pending.

The inclusive calendar-period bug is fixed separately in commit2ed5e329986dfa3a48ca5169bab345cb7e49c9b4. See period-proof.json. The actual Windows page showed8dates under its7-daylabel,31underits30-daylabel,andoneoverlappingdateacrossweeklycomparisons. The fix shares existing period lengths and local-date shifts. All117focused cases pass, including48new period/comparator page cases, alongside category/manifest/publication neighbor gates. Normalhooks passed.

The repeated-goal prompt bug is fixed separately in commit60f5eccbcc9ce950ddb128f977b548874ecb1193. See goal-proof.json. The actual Windows click sequence changed the goal from120to60, then Enter on the reopened prompt reset it to120 because its single listener captured the first value. The current window owner now supplies each proposal. All126focused cases pass, including9new all-host click/prompt/cache cases. Normalhooks passed; fullCI is pending.
