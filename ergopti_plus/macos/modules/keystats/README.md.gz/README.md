# keystats

## Purpose

Low-level event tap daemon that intercepts, timestamps, and stores every human keystroke globally across the operating system. Drives context tracking (app focus, secure-field guard), hardware telemetry (battery, WiFi, mouse distance, system load), and persists everything to an SQLite database and a hot-path JSONL log.

## Ports used (`_shared/core/ports/`)

| Port                  | Usage                                                 |
| --------------------- | ----------------------------------------------------- |
| `KeyboardHook`        | Global keystroke interception                         |
| `WindowInfo`          | Active app and window title for context tracking      |
| `SecureFieldDetector` | AX observer that marks password fields                |
| `FileSystem`          | Writing `today.log` (JSONL) and reading state         |
| `Storage`             | SQLite writes via `sqlite_writer` and `sqlite_reader` |
| `TimerScheduler`      | Idle check, maintenance, and flush timers             |

## Domain module (`_shared/core/domain/`)

No domain spec directly — the keystats implements the on-disk schema described in `_shared/data/KEYSTATS_SPEC.md`. The `kc_bridge` sub-module exposes keycode translation consumed by `karabiner`.

## Public API

| Function               | Description                                                                      |
| ---------------------- | -------------------------------------------------------------------------------- |
| `M.start(control)`     | Arm the eventtap and daemons with the runtime pause-state provider               |
| `M.stop()`             | Disarm the eventtap, stop maintenance, and flush pending buffers                 |
| `M.resync_context()`   | Drop transient modifier/application context after an observation gap             |
| `M.notify_synthetic()` | Record a replacement's logical result; the optional privacy flag redacts content |

## Init pattern

```lua
local Keystats = require("modules.keystats")
local ScriptControl = require("modules.shortcuts.script_control")
Keystats.start(ScriptControl)
```

The module classifies synthetic input only through the immutable
`eventSourceUserData` tags issued by `adapters.synthetic_input`; timing,
characters, modifiers, and source PID are not identity. `M.notify_synthetic()`
records logical replacement content but does not arm physical-event heuristics.
The `kc_bridge` sub-module must be initialized before `karabiner` calls into it.

## Physical-key accounting

`physical_accounting_mode.lua` decides which source may credit a physical key.
By default the legacy sources do: the event tap credits the keycode Quartz
reports (keyDown `kc`, flagsChanged `modifier_press`/`modifier_hold`) and
`kc_bridge` credits the Karabiner ledger. A managed tap-hold is therefore still
counted twice (HS-274), once as its physical key and once as its output. Once a
producer stream owner selects the stream, neither legacy source credits
anything: an admitted complete capture credits `physical_press`, and without
one, the source is an explicit gap, never a fallback. The output keycode is
never suppressed instead, because it is also a real key.

The stream credits the macOS keycode Quartz would report for the same key:
`physical_key_identity.lua` resolves a raw HID usage through the generated
`_generated/hid_key_identity.lua` (from the shared registry and
`_shared/data/keycodes/hid_usages.json`), using the device's
keyboard type only for the ISO swap pair, and maps fn/globe to the fn keycode.
`physical_delivery.lua` tallies a press it cannot attribute in `uncounted()`
instead of retiring the capture, and `physical_baseline.lua` admits only the
version-2 baseline, whose device rows carry the keyboard type and whose key rows
carry their usage page.
