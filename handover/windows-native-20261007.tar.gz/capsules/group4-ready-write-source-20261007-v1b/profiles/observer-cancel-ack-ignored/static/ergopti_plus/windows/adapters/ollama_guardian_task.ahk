﻿; adapters/ollama_guardian_task.ahk
#Requires AutoHotkey v2.0

global _OllamaGuardianTasks := Map()

/** Composite source/daemon/native owner. Consent stays with the runtime caller. */
class OllamaGuardianTask {
	__New(NativeProvider, SourceSpec, Executable, Arguments, OnDone, IsCurrent,
			Deadline, PollMilliseconds, SourceCaptureBytes,
			TaskFactory := ShellRunner_StageTreeOwned, TimerFn := TimerSetCallback, DirectDaemon := 0) {
		if !HasMethod(NativeProvider, "Call") || !HasMethod(OnDone, "Call") || !HasMethod(IsCurrent, "Call")
				|| !(SourceSpec is Map) || !(Arguments is Array)
				|| !(Deadline is Integer) || Deadline <= 0
				|| !(PollMilliseconds is Integer) || PollMilliseconds <= 0
				|| !(SourceCaptureBytes is Integer) || SourceCaptureBytes <= 0
				|| !HasMethod(TaskFactory, "Call") || !HasMethod(TimerFn, "Call")
			throw TypeError("Guardian construction requires captured source and lifecycle policies.")
		this.Provider := NativeProvider
		this.SourceSpec := SourceSpec.Clone()
		this.Executable := Executable
		this.Arguments := Arguments.Clone()
		if DirectDaemon != 0 && (!(DirectDaemon is Map) || !(DirectDaemon.Get("executable", 0) is String)
				|| !(DirectDaemon.Get("port", 0) is Integer) || DirectDaemon["port"] < 1 || DirectDaemon["port"] > 65535
				|| !(DirectDaemon.Get("models_dir", 0) is String))
			throw TypeError("Direct daemon construction requires its captured native target.")
		this.DirectDaemon := DirectDaemon is Map ? DirectDaemon.Clone() : 0
		this.Callback := OnDone
		this.Current := IsCurrent
		this.Deadline := Deadline
		this.PollMilliseconds := PollMilliseconds
		this.CaptureBytes := SourceCaptureBytes
		this.Native := 0
		this.Id := 0
		this.Source := 0
		this.Daemon := 0
		this.SourceDone := false
		this.DaemonDone := false
		this.SourceExit := 0
		this.DaemonExit := 0
		this.FactoryAttempted := false
		this.ActivationAttempted := false
		this.StopIssued := false
		this.Cancelled := false
		this.Started := false
		this.Building := false
		this.Busy := false
		this.IsRetired := false
		this.Notified := false
		this.FirstError := ""
		this.Timer := ObjBindMethod(this, "_Tick")
		this.TaskFactory := TaskFactory
		this.TimerFn := TimerFn
		this.ReadyWriteHold := 0
	}

	start() {
		global _OllamaGuardianTasks
		local publication_critical := Critical("On")
		try {
			if this.Started || this.Cancelled || this.IsRetired
				return false
			this.Started := true
			this.Building := true
			_OllamaGuardianTasks[ObjPtr(this)] := this
		} finally Critical(publication_critical)
		local caller_critical := Critical("Off")
		try {
			; Publish before loading code, acquiring native rows or creating tasks.
			if !this._Admitted()
				throw Error("Runtime source admission expired before construction.")
			this.Native := this.Provider.Call()
			this.Id := this.Native.CreateChannel(this.SourceSpec["RecordCapacity"],
				this.SourceSpec["PathCapacity"], this.SourceSpec["ManifestHash"])
			_SR_LogAt("Info", "Guardian runtime native owner " . this.Id . " acquired.")
			local handles := this.Native.Inherited(this.Id)
			local source_args := this._SourceArguments(handles)
			this.Source := this.TaskFactory.Call(this.Executable, source_args,
				ObjBindMethod(this, "_SourceTerminal"), this.CaptureBytes, true)
			local daemon_executable := this.DirectDaemon is Map ? this.DirectDaemon["executable"] : this.Executable
			local daemon_arguments := this.DirectDaemon is Map ? ["serve"] : this.Arguments
			this.Daemon := this.TaskFactory.Call(daemon_executable, daemon_arguments,
				ObjBindMethod(this, "_DaemonTerminal"))
			if this.DirectDaemon is Map
				_SR_GuardianConfigureDirectDaemon(this.Daemon, _SR_DaemonEnvironmentCapture(
					"127.0.0.1:" . this.DirectDaemon["port"], this.DirectDaemon["models_dir"]))
			_SR_GuardianConfigureSource(this.Source, handles, this.Native.InheritanceLease(this.Id, handles))
			_SR_GuardianConfigureDaemon(this.Daemon, ObjBindMethod(this.Native, "Claim", this.Id))
			if !this._Admitted() || !this.Daemon.stage() || !this._Admitted() || !this.Source.stage()
				throw Error("Runtime source or daemon staging refused.")
			if !_SR_GuardianBindSource(this.Source, ObjBindMethod(this.Native, "Bind", this.Id))
					|| !this._Admitted() || !this.Source.start()
				throw Error("The exact bound source worker could not activate.")
			this._Schedule()
			return true
		} catch as Err {
			this._Error(Err.Message)
			this.Cancelled := true
			return false
		} finally {
			this.Building := false
			try {
				if this.Cancelled
					this._Tick()
			} finally Critical(caller_critical)
		}
	}

	/** Temporarily stops only this exact ready observer before an owned write. */
	HoldReadyWrite(Ticket) {
		if !(Ticket is OllamaManagedReadyWriteTicket) || IsObject(this.ReadyWriteHold)
				|| this.Cancelled || this.IsRetired || this.Busy || this.Building || !this.ActivationAttempted
			return false
		this.ReadyWriteHold := Ticket
		local accepted := this.TimerFn.Call(this.Timer, 0)
		return this.ReadyWriteHold == Ticket
			&& !this.Cancelled && !this.IsRetired && !this.Busy && !this.Building
	}

	ReleaseReadyWrite(Ticket, Resume) {
		local previous := Critical("On")
		try {
			if this.ReadyWriteHold != Ticket
				return false
			local accepted := this.TimerFn.Call(this.Timer, Resume ? -Abs(this.PollMilliseconds) : 0)
			if !(accepted is Integer) || accepted != true || this.ReadyWriteHold != Ticket
				return false
			this.ReadyWriteHold := 0
			return true
		} finally Critical(previous)
	}

	_Admitted() {
		return this._Current() && A_TickCount <= this.Deadline
	}

	_Current() {
		if this.Cancelled || A_IsSuspended
			return false
		local current := this.Current.Call()
		return current is Integer && current == true && !this.Cancelled && !A_IsSuspended
	}

	_SourceArguments(Handles) {
		local pins := this.Native.Pins
		local args := ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
			"-File", pins["SourceWorker"]["path"]]
		for name in ["RootPath", "RootIdentity", "Ticket", "StageIdentity", "ManifestHash",
			"DescriptorIdentity", "DescriptorHash"]
			args.Push("-" . name, String(this.SourceSpec[name]))
		if this.SourceSpec.Has("ModelsDirectory")
			for name in ["ModelsDirectory", "ModelsFolderName", "ModelsIdentity"]
				args.Push("-" . name, this.SourceSpec[name])
		for name in ["ManagedBridge", "FilesHelper", "PublicationHelper", "ProducerHelper", "NativeModule", "Guardian", "Launcher"] {
			args.Push("-" . name . "Path", pins[name]["path"])
			args.Push("-" . name . "Hash", pins[name]["sha256"])
		}
		for index, name in ["MappingHandle", "ReadyHandle", "ReleaseHandle", "ParentHandle"]
			args.Push("-" . name, String(Handles[index]))
		return args
	}

	_Error(Message) {
		if this.FirstError == "" {
			this.FirstError := Message
			_SR_LogError("Guardian runtime owner {1} failed: {2}.", this.Id, Message)
		}
	}

	_SourceTerminal(ExitCode, Stdout, Stderr) {
		this.SourceDone := true
		this.SourceExit := ExitCode
		if ExitCode != 0 && !this.Cancelled {
			this._Error("The verified source worker refused (exit " . ExitCode . ").")
			this.Cancelled := true
		}
		this._Schedule()
	}

	_DaemonTerminal(ExitCode, Stdout, Stderr) {
		this.DaemonDone := true
		this.DaemonExit := ExitCode
		this._Schedule()
	}

	_Schedule() {
		if !this.IsRetired && (!IsObject(this.ReadyWriteHold) || this.Cancelled)
			this.TimerFn.Call(this.Timer, -Abs(this.PollMilliseconds))
	}

	_Tick() {
		global _OllamaGuardianTasks
		local admission_critical := Critical("On")
		try {
			if this.IsRetired || this.Busy || this.Building
					|| (IsObject(this.ReadyWriteHold) && !this.Cancelled)
				return
			this.Busy := true
		} finally Critical(admission_critical)
		local caller_critical := Critical("Off")
		try {
			if !this.Cancelled && (!this._Current() || (!this.ActivationAttempted && A_TickCount > this.Deadline))
				this.Cancelled := true
			local status := this.Id ? this.Native.Poll(this.Id) : Map("phase", 6, "error", 0)
			if status["error"] != 0 || status["phase"] == 7 {
				this._Error("Native guardian ownership failed (Win32 " . status["error"] . ").")
				this.Cancelled := true
			}
			if !this.Cancelled && status["phase"] == 2 && !this.FactoryAttempted {
				this.FactoryAttempted := true
				if !_SR_TreeWithGuardianCapabilities(this.Daemon, this.Source,
					ObjBindMethod(this.Native, "Begin", this.Id))
					throw Error("The authentic native guardian construction refused.")
				status := this.Native.Poll(this.Id)
			}
			if !this.Cancelled && status["phase"] == 4 && !this.ActivationAttempted {
				if !this._Admitted()
					this.Cancelled := true
				else {
					this.ActivationAttempted := true
					if !this.Daemon.start()
						throw Error("Native READY did not activate the exact staged daemon.")
					_SR_LogAt("Info", "Guardian runtime native owner " . this.Id . " activated its exact daemon.")
				}
			}
			if this.Cancelled {
				if this.Id && !this.StopIssued {
					this.StopIssued := true
					this.Native.Stop(this.Id)
				}
				if IsObject(this.Daemon) && !this.DaemonDone
					this.DaemonDone := this.Daemon.terminate() == true
				if IsObject(this.Source) && !this.SourceDone
					this.SourceDone := this.Source.terminate() == true
			}
			if !IsObject(this.Daemon)
				this.DaemonDone := true
			if !IsObject(this.Source)
				this.SourceDone := true
			if this.Id
				status := this.Native.Poll(this.Id)
			if status["phase"] == 6 && this.SourceDone && this.DaemonDone {
				this.IsRetired := true
				_SR_LogAt("Info", "Guardian runtime native owner " . this.Id . " physically retired.")
				this.TimerFn.Call(this.Timer, 0)
				if _OllamaGuardianTasks.Has(ObjPtr(this))
					_OllamaGuardianTasks.Delete(ObjPtr(this))
				if !this.Notified {
					this.Notified := true
					local callback := this.Callback
					this.Callback := 0
					callback.Call(this.FirstError == "" ? this.DaemonExit : 1, "", "")
				}
			}
		} catch as Err {
			this._Error(Err.Message)
			this.Cancelled := true
		} finally {
			this.Busy := false
			try this._Schedule()
			finally Critical(caller_critical)
		}
	}

	terminate() {
		this.Cancelled := true
		this._Tick()
		return this.IsRetired
	}

	requestTerminate() {
		return this.terminate()
	}

	processId() {
		return IsObject(this.Daemon) ? this.Daemon.processId() : 0
	}

	retired() {
		this._Tick()
		return this.IsRetired
	}
}
