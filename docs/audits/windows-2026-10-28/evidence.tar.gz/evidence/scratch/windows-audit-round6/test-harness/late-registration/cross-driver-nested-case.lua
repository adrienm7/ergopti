local root = "/workspace/ergopti-windows-r6-tests/static/ergopti_plus/"
local original_path = package.path
for _, os_name in ipairs({"linux", "macos"}) do
  for name in pairs(package.loaded) do
    if name:match("^tests%.") then package.loaded[name] = nil end
  end
  package.path = root .. os_name .. "/?.lua;" .. root .. os_name .. "/?/init.lua;"
    .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. original_path
  local helpers = require("tests.helpers")
  local observed = false
  helpers.it("outer registration control", function()
    helpers.it("nested failing control", function()
      observed = true
      error("intentional nested failure")
    end)
  end)
  local results = helpers.get_results()
  assert(observed and results.passed == 1 and results.failed == 1,
    os_name .. " unexpectedly concealed the nested failure")
  print("OBSERVED " .. os_name .. " genuine nested callback counted: 1 passed, 1 failed")
end
