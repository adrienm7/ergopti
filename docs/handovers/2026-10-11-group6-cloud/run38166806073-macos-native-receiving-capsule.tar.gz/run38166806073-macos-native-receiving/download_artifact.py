from pathlib import Path
import subprocess,json,sys,hashlib,re,urllib.parse,zipfile,stat
P=Path(__file__).resolve().parent;ident=sys.argv[1];name=sys.argv[2]
metadata=P/(name+'.api.json');error=P/(name+'.api.stderr')
with metadata.open('wb') as out,error.open('wb') as err:r=subprocess.run(['gh','api','repos/adrienm7/ergopti/actions/artifacts/'+ident],stdout=out,stderr=err)
record={'artifact_id':int(ident),'label':name,'metadata_command_status':r.returncode,'native_acceptance':False}
if r.returncode!=0:print(json.dumps(record));raise SystemExit(1)
a=json.loads(metadata.read_text());record.update({'artifact_name':a['name'],'API_digest':a.get('digest'),'API_source':a.get('workflow_run'),'expired':a['expired']})
archive=P/(name+'.zip');stderr=P/(name+'.download.stderr')
with archive.open('wb') as out,stderr.open('wb') as err:r=subprocess.run(['gh','api','repos/adrienm7/ergopti/actions/artifacts/'+ident+'/zip'],stdout=out,stderr=err)
s=stderr.read_text();actual=hashlib.sha256(archive.read_bytes()).hexdigest();record.update({'download_command_status':r.returncode,'download_bytes':archive.stat().st_size,'sha256':actual,'digest_matches':a.get('digest')=='sha256:'+actual,'error_hosts':sorted({urllib.parse.urlsplit(v).hostname for v in re.findall(r'https?://[^\s)]+',s)}),'Forbidden':'Forbidden' in s})
if r.returncode==0:
 assert record['digest_matches'] and not a['expired']
 rows=[]
 with zipfile.ZipFile(archive) as z:
  names=z.namelist();assert len(names)==len(set(names)) and len(names)<=100
  for entry in z.infolist():
   p=Path(entry.filename);assert not p.is_absolute() and '..' not in p.parts
   mode=entry.external_attr>>16;assert not stat.S_ISLNK(mode)
   if entry.is_dir():continue
   assert entry.file_size<=8_388_608
   raw=z.read(entry);rows.append({'path':entry.filename,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
  assert sum(r['bytes'] for r in rows)<=16_777_216
  target=P/(name+'-extracted');target.mkdir()
  for row in rows:
   out=target/row['path'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(z.read(row['path']))
 record.update({'safe_inventory':rows,'safe_extracted':True})
(P/(name+'.receiving.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
