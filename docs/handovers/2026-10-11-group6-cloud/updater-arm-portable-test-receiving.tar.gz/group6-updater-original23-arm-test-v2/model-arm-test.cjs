'use strict';
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const file = path.join(__dirname, 'physical-source/tools/test/test-windows-updater-original-source.cjs');
// A lexical private process keeps ordinary Object/Error identity; the production API models
// inside the actual test still use their own x64/arm64 VM realms. No global process mutation.
const compiled = new Module(file, module);
compiled.filename=file; compiled.paths=Module._nodeModulePaths(path.dirname(file));
compiled._compile("const privateProcess = {...process, arch:'arm64'};\n(function(process){\n" + fs.readFileSync(file,'utf8') + "\n})(privateProcess);\nprocess.on('beforeExit',()=>{process.exitCode=privateProcess.exitCode||0;});", file);
