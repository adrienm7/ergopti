-- UNEXECUTED semantic models. Real userdata only admits the handle class;
-- injected pipe/process callbacks here do NOT prove native retirement.
local driver, candidate = assert(arg[1]), assert(arg[2])
package.path = driver .. "/?.lua;" .. driver .. "/../_shared/lua/?.lua;" .. package.path
local actual_uv = require("luv")
require("adapters.shell_runner") -- Capture unchanged real argument validation.
local passed = 0
local function fixture()
	local state = { handles = {}, callbacks = {}, kills = {}, absent = false,
		worker_done = false, worker_ready = false, worker_ok = true, cancels = 0 }
	local pipe = actual_uv.new_pipe(false)
	local closed, close_issued = false, false
	local function cleanup()
		assert(not close_issued, "test-owned pipe close already attempted")
		close_issued = true
		actual_uv.close(pipe, function() closed = true end)
		actual_uv.run()
		assert(closed, "test-owned native pipe close ACK unavailable")
	end
	local native = {}
	local function handle(kind)
		local value = { kind = kind }; state.handles[value] = { closing = false }; return value
	end
	state.handles[pipe] = { closing = false }
	function native.new_pipe() return handle("pipe") end
	function native.new_timer() return handle("timer") end
	function native.is_closing(value) return state.handles[value].closing end
	function native.read_start(value, callback) value.read = callback; return 0 end
	function native.read_stop() return 0 end
	function native.timer_start(value, _, _, callback) value.timer = callback; return 0 end
	function native.timer_stop() return 0 end
	function native.close(value, callback)
		state.handles[value].closing = true; state.callbacks[value] = callback; return 0
	end
	function native.spawn(_, options, callback)
		state.options, state.exit = options, callback
		state.child = handle("process"); return state.child, 28001
	end
	function native.kill(pid, signal)
		state.kills[#state.kills + 1] = { pid, signal }
		if state.absent then return nil, "ESRCH", "ESRCH" end
		return 0
	end
	local input = { handle = pipe }
	function input:cancel() state.cancels = state.cancels + 1; return true end
	function input:can_close() return state.worker_ready end
	function input:is_settled() return state.worker_done end
	function input:result() return { ok = state.worker_ok } end
	function input:on_settled(listener) state.listener = listener; return true end
	function state.ack(include_stdin)
		local ready = {}
		for value, callback in pairs(state.callbacks) do
			if include_stdin or value ~= pipe then ready[#ready + 1] = { value, callback } end
		end
		for _, item in ipairs(ready) do state.callbacks[item[1]] = nil; item[2]() end
	end
	function state.exit_normally()
		state.options.stdio[2].read(nil, nil); state.options.stdio[3].read(nil, nil)
		state.absent = true; state.exit(0, 0)
	end
	function state.finish_worker(ok)
		state.worker_ready, state.worker_done, state.worker_ok = true, true, ok
		state.listener()
	end
	local previous = package.loaded.luv; package.loaded.luv = native
	local loaded, owner = pcall(function() return assert(loadfile(candidate .. "/owned_process.lua"))() end)
	package.loaded.luv = previous
	if not loaded then pcall(cleanup); error(owner, 0) end
	return owner, input, state, cleanup
end
local function test(name, check)
	local owner, input, state, cleanup = fixture()
	local ok, error = pcall(check, owner, input, state)
	local cleaned, cleanup_error = pcall(cleanup)
	assert(ok, error); assert(cleaned, cleanup_error); passed = passed + 1; print("MODEL PASS " .. name)
end

test("child success waits for worker and original stdin close ACK", function(owner, input, state)
	local result
	local operation = owner.start("tar", { "-tzf", "-" }, { owner = "bridge", stdin_owner = input },
		function(value) result = value end)
	assert(operation.started and state.options.stdio[1] == input.handle)
	state.exit_normally(); state.ack(false)
	assert(not operation:is_settled() and result == nil and state.callbacks[input.handle] == nil)
	state.finish_worker(true); state.ack(false)
	assert(not operation:is_settled() and result == nil and state.callbacks[input.handle] ~= nil)
	state.ack(true)
	assert(operation:is_settled() and result and result.ok)
end)

test("cancel does not manufacture worker settlement or delivery", function(owner, input, state)
	local callbacks = 0
	local operation = owner.start("tar", { "-tzf", "-" }, { owner = "cancel", stdin_owner = input },
		function() callbacks = callbacks + 1 end)
	assert(operation:cancel() == false and state.cancels == 1)
	state.exit_normally(); state.ack(true)
	assert(not operation:is_settled() and state.callbacks[input.handle] == nil)
	state.finish_worker(false); state.ack(true)
	assert(operation:is_settled() and callbacks == 0 and state.cancels == 1)
end)

test("method mutation cannot replace captured worker receipts", function(owner, input, state)
	local result
	local operation = owner.start("tar", { "-tzf", "-" }, { owner = "captured", stdin_owner = input },
		function(value) result = value end)
	input.can_close = function() error("foreign getter must not run") end
	input.is_settled = function() return true end
	input.result = function() return { ok = true } end
	state.exit_normally(); state.ack(true)
	assert(not operation:is_settled() and result == nil)
	state.finish_worker(false); state.ack(true)
	assert(operation:is_settled() and result and not result.ok and result.error == "native stdin feed failed")
end)

test("wake notification alone is not physical worker authority", function(owner, input, state)
	local result
	local operation = owner.start("tar", { "-tzf", "-" }, { owner = "wake", stdin_owner = input },
		function(value) result = value end)
	state.listener(); state.exit_normally(); state.ack(true)
	assert(not operation:is_settled() and result == nil and state.callbacks[input.handle] == nil)
	state.finish_worker(true); state.ack(true)
	assert(operation:is_settled() and result.ok)
end)

test("source withdrawal fences even successful late worker receipts", function(owner, input, state)
	local current, callbacks = true, 0
	local operation = owner.start("tar", { "-tzf", "-" }, {
		owner = "source", stdin_owner = input, authorized = function() return current end,
	}, function() callbacks = callbacks + 1 end)
	current = false; state.options.stdio[2].read(nil, "late")
	state.exit_normally(); state.ack(true)
	assert(not operation:is_settled() and callbacks == 0)
	state.finish_worker(true); state.ack(true)
	assert(operation:is_settled() and callbacks == 0)
end)

test("normal dispatch refusal still owns original pipe close", function(owner, input, state)
	-- Independent source refusal occurs after captured ownership, before spawn.
	state.worker_done, state.worker_ready = true, true
	local result
	local operation = owner.start("tar", { "-tzf", "-" }, {
		owner = "refused", stdin_owner = input, authorized = function() return false end,
	}, function(value) result = value end)
	assert(not operation.started and not operation:is_settled() and result == nil)
	assert(state.callbacks[input.handle] ~= nil)
	state.ack(true)
	assert(operation:is_settled() and result == nil and operation.result and not operation.result.ok)
end)

print(string.format("stdin bridge semantic models: %d completed,0 skipped; no native process proof", passed))
