// Three private focused commands; existing ownPhase remains the sole physical owner.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const packet = __dirname;
const root = '/workspace/ergopti';
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const bindings = JSON.parse(fs.readFileSync(path.join(packet, 'SOURCE-BINDINGS.json')));
const pinned = new Map();
for (const name of ['run-receiving.cjs','receiving_launcher.py']) pinned.set(path.join(packet,name),sha(path.join(packet,name)));
for (const row of bindings.originals) {
  pinned.set(path.join(packet,'original-inputs',row.path),row.sha256);
  if (row.path.startsWith('tools/') && !['tools/test/macos_managed_ollama_catalogue_refusal_test.py','tools/test/test-managed-ollama-protocol.cjs'].includes(row.path)) pinned.set(path.join(packet,'owner',row.path),row.sha256);
  if (row.path.startsWith('static/')) for (const variant of ['before','after']) pinned.set(path.join(packet,'cohorts',variant,row.path),row.sha256);
}
const test='tools/test/macos_managed_ollama_catalogue_refusal_test.py';
for (const [variant,base] of [['before','preimages'],['after','candidate']]) {
  pinned.set(path.join(packet,base,test),sha(path.join(packet,base,test)));
  pinned.set(path.join(packet,'cohorts',variant,test),sha(path.join(packet,base,test)));
}
function refence() {
  for (const row of bindings.originals) if (sha(path.join(root,row.path))!==row.sha256) throw Error('Original source changed');
  for (const [file,digest] of pinned) {
    const fact=fs.lstatSync(file); if (!fact.isFile() || fact.isSymbolicLink() || sha(file)!==digest) throw Error('Private source changed');
  }
}
refence();
const owner=require(path.join(packet,'owner/tools/test/run-linux-managed-http-native.cjs'));
refence();
const work=fs.mkdtempSync('/tmp/group6-catalogue-alias-receiving-');
const realTmp=path.join(work,'real-tmp'), alias=path.join(work,'alias-tmp');
fs.mkdirSync(realTmp,{mode:0o700}); fs.symlinkSync('real-tmp',alias,'dir');
const fact=filename=>{const s=fs.lstatSync(filename,{bigint:true});return {dev:String(s.dev),ino:String(s.ino),mode:String(s.mode),uid:String(s.uid)};};
const directory=fact(realTmp),link=fact(alias);
function aliasFence() {
  if (JSON.stringify(fact(realTmp))!==JSON.stringify(directory) || JSON.stringify(fact(alias))!==JSON.stringify(link) || fs.readlinkSync(alias)!=='real-tmp' || fs.realpathSync(alias)!==realTmp || fs.readdirSync(realTmp).length!==0) throw Error('Owned alias identity/debt refused');
}
const deadline=process.hrtime.bigint()+120000000000n;
let cancelled=false;
const cancel=()=>{cancelled=true;owner.requestActiveCancellation();};
process.on('SIGTERM',cancel);process.on('SIGINT',cancel);
(async()=>{
 const results=[];
 for (const item of [
   {label:'before-alias',variant:'before',tmp:alias,status:1,pass:6,fail:6},
   {label:'after-alias',variant:'after',tmp:alias,status:0,pass:12,fail:0},
   {label:'after-ordinary',variant:'after',tmp:realTmp,status:0,pass:12,fail:0}
 ]) {
  refence();aliasFence();
  if(cancelled||process.hrtime.bigint()>=deadline)throw Error('Original private deadline refused');
  const cohort=path.join(packet,'cohorts',item.variant);
  const result=await owner.ownPhase({command:'python3',args:['-B',path.join(packet,'receiving_launcher.py'),path.join(cohort,test),path.join(work,item.label+'.json')],
   env:{...process.env,TMPDIR:item.tmp,PYTHONDONTWRITEBYTECODE:'1'},cwd:cohort,work,label:item.label,
   worker:path.join(packet,'owner/tools/test/run-linux-managed-http-phase.py'),owner:path.join(packet,'owner/tools/build/stage-linux-network-runtime.py'),
   ownerSha:'ac48a4e9755fb2b9e9cbe35c81b097942bf7be76d14466e03b891b4c78f302f5',kind:'command',budgetMs:30000,gateDeadline:deadline});
  refence();aliasFence();
  const closed=JSON.parse(fs.readFileSync(path.join(work,item.label+'.owner/closed.json')));
  const summary=JSON.parse(fs.readFileSync(path.join(work,item.label+'.json')));
  const ok=result.status===item.status&&result.signal===null&&result.error===null&&!cancelled&&!owner.hasRetainedPhases()&&!closed.cancelled
    &&owner.phaseReceipt(closed,closed.pid,'command',item.status)&&summary.total===12&&summary.pass===item.pass&&summary.fail===item.fail&&summary.errors===0&&summary.skip===0;
  results.push({label:item.label,variant:item.variant,symlink_alias:item.tmp===alias,ok,status:result.status,signal:result.signal,error:result.error,retained:owner.hasRetainedPhases(),closed,summary});
  fs.writeFileSync(path.join(work,'RESULTS.json'),JSON.stringify({results,alias:{target:'real-tmp',directory_identity:directory,symlink_identity:link,empty_after_each_phase:true,fixture_owned:true},native_macos_credit:false},null,2)+'\n');
  console.log(JSON.stringify({label:item.label,ok,pass:summary.pass,fail:summary.fail,errors:summary.errors,status:result.status,retained:owner.hasRetainedPhases()}));
  if(!ok)throw Error('Focused receiving refused');
 }
 refence();aliasFence();
 if(cancelled||process.hrtime.bigint()>=deadline||owner.hasRetainedPhases())throw Error('Final source/clock/debt refused');
 // Only the exact fixture-owned alias and now-empty target are removed.
 fs.unlinkSync(alias);fs.rmdirSync(realTmp);
 const receipt=JSON.parse(fs.readFileSync(path.join(work,'RESULTS.json')));
 receipt.alias.cleanup_acknowledged=!fs.existsSync(alias)&&!fs.existsSync(realTmp);
 fs.writeFileSync(path.join(work,'RESULTS.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log('RESULT_DIRECTORY='+work);
})().catch(()=>{console.error('FOCUSED_RECEIVING_REFUSED work='+work);process.exitCode=1;}).finally(()=>{
 if(!owner.hasRetainedPhases()){process.removeListener('SIGTERM',cancel);process.removeListener('SIGINT',cancel);}
});
