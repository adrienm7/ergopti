from pathlib import Path
import hashlib,json,subprocess
root=Path('/workspace/ergopti-cloud/group6-ruby'); release=(root/'apt/Release.authenticated').read_text(); records={}
section=False
for line in release.splitlines():
    if line=='SHA256:': section=True;continue
    if section and not line.startswith(' '): break
    if section:
        sha,size,name=line.split();records[name]=(sha,int(size))
index=root/'apt/lists/deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages';data=index.read_bytes();want=records['main/binary-amd64/Packages'];assert (hashlib.sha256(data).hexdigest(),len(data))==want
stanzas={}
for part in data.decode().split('\n\n'):
    fields={}
    for line in part.splitlines():
        if line and not line.startswith(' ') and ': ' in line:
            key,value=line.split(': ',1);fields[key]=value
    if {'Package','Version','Architecture','SHA256','Size'}<=fields.keys():stanzas[(fields['Package'],fields['Version'],fields['Architecture'])]=fields
packages=[]
for archive in sorted((root/'apt/archives').glob('*.deb')):
    identity=subprocess.check_output(['/usr/bin/dpkg-deb','-f',str(archive),'Package','Version','Architecture'],text=True)
    fields=dict(line.split(': ',1) for line in identity.splitlines()); key=(fields['Package'],fields['Version'],fields['Architecture']); want=stanzas[key];body=archive.read_bytes();actual=hashlib.sha256(body).hexdigest();assert actual==want['SHA256'] and len(body)==int(want['Size'])
    packages.append(dict(fields,filename=archive.name,sha256=actual,bytes=len(body)))
assert len(packages)==13
for archive in sorted((root/'apt/archives').glob('*.deb')):subprocess.run(['/usr/bin/dpkg-deb','-x',str(archive),str(root/'runtime')],check=True)
(root/'package-verification.json').write_text(json.dumps({'inrelease_signature':'sqv PASS against system Debian archive keyring','packages_index_sha256':hashlib.sha256(data).hexdigest(),'packages':packages,'package_count':len(packages),'system_install':False},indent=2)+'\n')
print('Authenticated Packages index and 13 package SHA256/size bindings PASS; extracted only to isolated runtime')
