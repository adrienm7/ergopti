# Independent native SDK permission observation

This private four-path successor starts from actual `origin/dev`
`81f365c09976f8e38821f1d9216e422508ca9167` and the already published `02ae39716`
production-process SDK test. It does not change that test, its worker, the G5
child environment, a signing builder, an existing deadline or a workflow ref.
The workflow and deferral-admission paths remain ownership pending; this packet
is not permission to adopt them. Coordination issue: `6079986252`.

The package job depends on both Hammerspoon E2E and managed Ollama native
qualification. A preceding PAC failure skips packaging, and the independent
existing XCTest filters do not select the SDK observation case. Discovering or
compiling the case does not execute its SDK API. The proposed software correction
runs only `OwnedAutomationQueryWorkerTests.testActualNoPromptPermissionAPIOnlyPublishesRetiredMetadata`
inside the independent manual `item36-native` job, after its unchanged original
25-case archive cohort. Its explicit `!cancelled()` step runs after an archive
failure while retaining that failure in the job and lane verdict.

The step reuses the original SwiftPM target, scratch directory and dependency
cache. It never uses `--skip-build`, changes consent, launches a target or runs a
shortcut. It requires the real compiled production worker entrypoint through
the published test's original process owner, HELD/ACTIVATE exchange, exact
retirement, normal exit and strict metadata grammar. The fixed test-product
caller is distinct from a signed installed application or osascript.

The new pure diagnostic validator binds clean Git HEAD and all original native
input roots using the unchanged item36 source-receipt authority. It also binds
the tracked owning workflow and both registered guards, requires the published
SDK method and original native-retirement source contract, binds the actual workflow run and attempt, and compares the
begin receipt with source after receiving. Stable bounded regular-file reads
reject symlinks, malformed UTF-8 and excess capture sizes. An exclusive verdict
records only this metadata scope.

The transcript must contain one exact selected XCTest, three completed one-case
summaries, no failure or skip, zero original script and capture statuses, and
exactly one canonical Int32 `SDK_PERMISSION_OBSERVATION` marker inside the active
case. The marker fixes the target, event, no-prompt value, nonce and native
test-product caller. Every actually returned Int32 code is metadata; there is no
accepted-status whitelist. Catalogue, signed-app and osascript qualifications
remain false. A native-platform refusal prevents the CLI from presenting Linux
fixture receipts as real macOS receiving.

The existing registered Swift launcher guard owns all new constructed transcript,
source-authority and native-source omission controls. The deferral guard adds
only an exact admission for this one additional step and selector. The original
selector chain's final return delegates to that admission; peeling the three
new declarations and this single wrapper recovers its complete original AST.
Peeling the Swift guard's one additive block recovers its complete original AST.
Removing the new workflow step and two artifact paths recovers the original
workflow byte-exact, including the 25-case cohort, original timeouts, release
conditions and all previous native gates. No registry or suite lease changes.

## Frozen checks

Both complete focused guards pass in the private source overlay. The deferral
guard retains its original 52 controls, item36 65 controls and PAC/WPAD 45
controls. All original AST and workflow inverses pass. The old workflow fails
both successor guards. Eight independent producer omissions each fail the
whole registered Swift guard with an assertion, covering original pipeline
statuses, marker timing and uniqueness, canonical OSStatus, source receipt
equality, native retirement, real no-prompt SDK dispatch and a nonempty census.
Formatting checks and four-path patch forward/reverse pass.

These are constructed transcript, real temporary Git/file and source controls.
They do not compile Swift, execute AppleEvents, observe SDK OSStatus, qualify
current catalogue contents or qualify installation/packaging. No native compiler
is available here. Native execution remains pending a future authorized macOS
workflow run after G6/G5 ownership coordination and adoption. Existing archive
failures remain failures even if this independent diagnostic passes.

The source overlay is a small dependency projection, not a checkout. The scripts
and evidence are immutable after freeze; do not rerun packet writers or mutate
its inputs. Review hashes and index records are in `manifest.json`, `receipt.json`
and `checksums.sha256`.
