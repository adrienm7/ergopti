<!-- docs/audits/windows-2026-10-28/POST_VALIDATION.md -->

# Post-validation Windows corrections

The first hosted qualification of `3b33225970415794481337525e4cc23cb15f2922`
exposed a fixture dependency failure in Windows unit group
`hotstrings-shortcuts`: 1,679 tests passed and one failed. The failed job is
[123111092749 in run 40771445154](https://github.com/adrienm7/ergopti/actions/runs/40771445154/job/123111092749).
The same run also found a developer-CLI test receipt failure in
[core job 123111092631](https://github.com/adrienm7/ergopti/actions/runs/40771445154/job/123111092631):
1,941 tests passed and one failed. Exact annotations and source heads are
preserved; these failed qualifications are not results for the corrected source.

The isolated user-program shutdown fixture extracts and executes the genuine
shutdown handler. It omitted the newly mandatory
`LayoutRegistry_PrepareShutdown` dependency, so the actual handler caught an
undefined dependency and refused before program retirement. The correction
supplies that dependency in the isolated include graph without changing the
program-retirement assertion. The original failure was reproduced under the
real AutoHotkey interpreter before correction; the unchanged focused case then
passed 1/1 after repair.

Review of the same shutdown flow also identified a production refusal path:
the registry shutdown guard returned after navigation preparation but before
entering the compensation `finally` block. A refused registry shutdown could
therefore leave navigation prepared after exit was vetoed. The correction and
its exact before/after controls are documented below once the integration
receipts are complete.

The second hosted failure came from PowerShell 5.1 test serialization: the
explicit-missing interpreter case reported a correct refusal, but serialized
its selected-null receipt as `{}`. The JavaScript assertion correctly rejected
`{} !== null`. The correction uses one canonical JSON null receipt producer
across PowerShell versions; it changes no interpreter-selection policy, adds no
version branch, and keeps the strict-null and all eight complete entry checks.
Four direct value controls supplement the original 17 host checks: literal
null, an actual empty pipeline, `AutomationNull.Value`, and a nonnull path. The
exact wrapper type on the first Windows runner was not captured; the controls
do not assert that AutomationNull was its independently diagnosed type. Actual host
PowerShell 7.5.2 controls passed 21/21. Corrected-head native PowerShell 5.1
qualification remains pending.

The complete original 160-commit index, initial evidence archive, and initial
Windows branch bundle remain unchanged. `post-validation-evidence.tar.gz`
supplements them with both failed hosted jobs, the first batch's actual 531/531
shared-test receipt, the three bounded corrections and regression results, and their
integration receipts. Raw packets retain their original bytes; the readable
summary uses Europe/Paris timestamps.

The corrected batch still requires its own complete shared test run and hosted
Windows qualification. Focused AutoHotkey evidence under Wine does not claim
native Windows qualification. The delivery response supplies the final run ID
and conclusion; the branch's GitHub Actions history remains authoritative.
