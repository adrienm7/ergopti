"""Verify the compact supplement and retain truthful qualification boundaries."""
from pathlib import Path
import hashlib,json,re,subprocess,tarfile

OUT=Path('/workspace/scratch/windows-post-ci-portable')
ROOT=Path('/workspace/ergopti-windows-integration')
DOCS=ROOT/'docs/audits/windows-2026-10-28'
PREFIX='post-validation-evidence/'
EXPECTED={'evidence.tar.gz':'519cc2ac9c2fcde16effda1fb3abd4fe5a2bfbc15fef7c4aa48944a8e7adb0c7','owned-windows.bundle':'04fc656ca60e1387d76a0a3d7e8b2b94ba53c1596a8d9680b7b23bd022e66212'}

def sha(data):return hashlib.sha256(data).hexdigest()
report=json.loads((OUT/'report.json').read_text())
historical=json.loads((DOCS/'report.json').read_text())
assert report['commits']==historical['commits'] and len(report['commits'])==160
follow=report['post_validation_followup'];assert len(follow['fixes'])>=3
current=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
assert follow['source_head']==current
for name,digest in EXPECTED.items():assert sha((DOCS/name).read_bytes())==digest
receipt=json.loads((OUT/'post-validation-receipt.json').read_text())
assert sha((OUT/'post-validation-evidence.tar.gz').read_bytes())==receipt['archive_sha256']
with tarfile.open(OUT/'post-validation-evidence.tar.gz') as ar:
 names=set(ar.getnames())
 assert all(n.startswith(PREFIX) and '..' not in Path(n).parts for n in names)
 manifest=ar.extractfile(PREFIX+'SHA256SUMS').read().decode().splitlines()
 for line in manifest:
  digest,name=line.split('  ',1);assert sha(ar.extractfile(PREFIX+name).read())==digest,name
 for row in follow['fixes']:
  for path in row['proof_packets']+[row['integration_receipt']]:assert path in names,path
  for key in ['sha','original_sha']:assert PREFIX+'commits/'+row[key]+'/source.patch' in names
 patterns={
  'github-token':rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,})',
  'openai-token':rb'sk-(?:proj-)?[A-Za-z0-9_-]{32,}',
  'jwt':rb'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{12,}',
  'authorization':rb'(?i)(?:authorization[\x22\x27]?\s*[:=]\s*[\x22\x27]?bearer\s+|authorization:\s*basic\s+)([A-Za-z0-9_+/=.-]{20,})',
  'url-userinfo':rb'https?://[^\s/<>\x22\x27]{2,}:[^\s/<>\x22\x27]{3,}@',
  'private-key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 }
 hits=[]
 for name in names:
  member=ar.getmember(name);assert member.isfile(),name
  data=ar.extractfile(name).read()
  for label,pattern in patterns.items():
   if re.search(pattern,data):hits.append({'path':name,'pattern':label})
 assert not hits,hits
summary={'source_head':current,'historical_commits_preserved':160,'new_integrated_fix_count':len(follow['fixes']),'manifest_files_verified':len(manifest),'credential_pattern_hits':hits,'initial_artifact_bytes_unchanged':True,'native_windows_ci_for_corrected_head':'not run; explicit urgent stop'}
(OUT/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
