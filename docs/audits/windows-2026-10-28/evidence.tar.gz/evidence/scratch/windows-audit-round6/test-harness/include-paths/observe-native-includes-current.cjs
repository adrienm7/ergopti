const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const root = '/workspace/ergopti-windows-r6-tests';
const packet = __dirname;
const {includeClosure} = require(path.join(root, 'tools/test/test-ahk-test-coverage.cjs'));
const owned = fs.mkdtempSync(path.join(packet, "native fixture's é-"));
const nested = path.join(owned, 'nested');
fs.mkdirSync(nested);
const child = path.join(nested, 'case.ahk');
const tail = path.join(owned, 'second.ahk');
const entries = [path.join(owned, 'macro.ahk'), path.join(owned, 'relative.ahk')];
const marker = 'NATIVE_WINDOWS_INCLUDE_CHAIN_OK|';
const put = (file, text) => fs.writeFileSync(file, '\ufeff' + text);
let allNativeQuiesced = false;
try {
 put(child, '#Include ..\\second.ahk\n');
 put(tail, 'FileAppend("' + marker + '" . A_AhkVersion, "*", "UTF-8-RAW")\nExitApp(0)\n');
 for (let i = 0; i < entries.length; i++) put(entries[i], '#Requires AutoHotkey v2.0\n#SingleInstance Off\n#NoTrayIcon\n#Include ' + (i === 0 ? '%A_LineFile%\\..\\nested\\case.ahk' : '.\\nested\\case.ahk') + '\n');
 const native = entries.map(entry => {
  const argv = ['--kill-after=5s','45s','xvfb-run','-a','wine','/workspace/toolchain/ahk/AutoHotkey64.exe','/ErrorStdOut','Z:' + entry.replace(/\//g,'\\')];
  const result = cp.spawnSync('timeout', argv, {encoding:'utf8',env:{...process.env,WINEPREFIX:'/workspace/toolchain/wine-r3-metrics-owned',LC_ALL:'C.UTF-8'}});
  return {entry, argv, status:result.status, signal:result.signal, error:result.error?.message, stdout:result.stdout, stderr:result.stderr};
 });
 allNativeQuiesced = native.every(result => result.status === 0 && result.signal === null && !result.error && result.stdout.startsWith(marker));
 assert(allNativeQuiesced, JSON.stringify(native));
 const observations = entries.map(entry => {
  const actual = [...includeClosure(entry)];
  const expected = [entry, child, tail].map(file => path.normalize(file).replace(/\\/g,'/'));
  return {entry, actual, expected, missing:expected.filter(file => !actual.includes(file))};
 });
 const result = {helper_sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'tools/test/test-ahk-test-coverage.cjs'))).digest('hex'),native,observations};
 fs.writeFileSync(path.join(packet,'native-current-observation.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({native:native.map(r => ({status:r.status,stdout:r.stdout})),missing:observations.map(r => r.missing)}));
 assert.deepEqual(observations.map(result => result.missing), [[],[]], 'valid native Windows include chains must have canonical reachable identities');
} finally {
 if (allNativeQuiesced) fs.rmSync(owned,{recursive:true});
}
