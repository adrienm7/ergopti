# Confirmed RPM native LuaJIT binding TODO

Source: `55a50835be9e027ec9cbe43ac5d1c693c6ff711f`. No source edits or commits were made for this item. Times use Europe/Paris.

## Actual failure and root cause

CI run [40766890057](https://github.com/adrienm7/ergopti/actions/runs/40766890057), attempt 1, job `123113887312` (`Linux / Install and launch (.rpm package)`) failed in **The installed shared data tree resolves and opens (rpm)**. The actual installed-tree call to `i18n.list_locales()` raised:

```text
native_directory: luv with fs_opendir, fs_readdir, fs_closedir, fs_lstat and fs_stat is required
```

The source packager copies the driver bundle but does not publish an owned LuaJIT luv binding. Its spec only recommends generic `lua-luv`; the generated mandatory RPM requirements contain no admitted LuaJIT binding. Fedora generic Lua modules cannot be assumed to satisfy LuaJIT's 5.1 ABI. The native-runtime catalogue explicitly records no verified `dnf` repair provider and instead owns a pinned source-build recipe.

The installed RPM wrapper sets `LUA_PATH` and invokes `install/launch.sh`. Neither sets `LUA_CPATH` for an owned native binding. The standalone installer does publish `native_modules/luv.so` and its separate launcher admits that path, but the RPM does not execute that standalone launcher. The driver-bundle build generates its archive backend, not an owned luv module.

This is an actual RPM packaging dependency/publication gap. The failing data-tree probe itself does not prove that every real RPM daemon launch path has been exercised. The successful RPM `--help` smoke is not a native-directory check.

## Concrete next implementation

1. Publish an actual LuaJIT-ABI native luv binding in the RPM. Prefer the canonical pinned `build_native_luv.sh` recipe and catalogue options, or factor the existing trusted-build-host module admission used by AppImage into a shared staging owner. Validate genuine C entry points and native directory enumeration; do not substitute a fake `luv` table.
2. Put owned native-module admission in one shared launcher/environment owner. Reuse that owner from the standalone and RPM launchers rather than hand-maintaining two CPATH policies. A published native-module directory with a missing, symlinked or unusable module must fail.
3. Keep the package offline-capable. Source compilation needs declared build-host prerequisites (`cmake`, LuaJIT development metadata and the pinned source), not a download/compile during user installation. Existing build-host packaging does not currently declare these source-build prerequisites.
4. Reproduce the old refusal and prove the staged/installed native binding works through the actual RPM launch environment, including a missing-module negative control and path-byte controls. Then perform the full packaging/integration CI lot.
5. If the fix publishes an owned CPATH rather than a module in the recipient VM's standard native directory, the protected CI data-tree receiver must replay the production environment owner. Its current command extracts only `LUA_PATH`. Do not work around this by making the production i18n module search unrelated runtime directories.

## Scope and evidence

`diagnosis.json` records the exact source-owner blob IDs, SHA-256 hashes, CI job and decoded-log provenance. `rpm-failure-excerpt.txt` preserves the relevant decoded diagnostic. The original job log is in the parent CI evidence directory; it is decoded UTF-8 from the GitHub connector, not a claim of original runner bytes.

The AppImage failure is separate: its actual AppRun sources the canonical portable environment, but the CI data-tree command bypasses AppRun and sets only `LUA_PATH`. Its native tray startup and distribution sweep succeeded earlier. Do not conflate that receiver bug with the RPM's missing published LuaJIT binding.

The final user instruction requests finishing the current work, saving remaining items at worst as TODO, then stopping before container deletion. This issue is therefore preserved with its actual proof and implementation requirements. No speculative package change, compatibility fallback, test weakening or protected CI edit was introduced.
