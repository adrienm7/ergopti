"""Repair only R2 test setup; never change a production allocator slot."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')
REL = 'tools/test/macos_native_http_receiving_facts_test.py'
expected = '956a06a034010f22bb8e6fe5c96f8947818c48fcca79c6fe18766a8de9975212'
preimage = BASE / 'preimage' / REL
preimage.parent.mkdir(parents=True, exist_ok=True)
if not preimage.exists():
    preimage.write_bytes((ROOT / REL).read_bytes())
before = preimage.read_text()
assert hashlib.sha256(before.encode()).hexdigest() == expected
old = '''def r2_guard_constructor_literal_setup(self):
    # These two retained R2 classes deliberately bypass native construction.
    # Supply its new exact literal only; no ACK, owner, policy or result is mocked.
    def allocate(cls):
        value = object.__new__(cls)
        value.command_group_debt = []
        return value

    owner = mock.patch.object(WIRE.WireFixture, "__new__", staticmethod(allocate))
    owner.start()
    self.addCleanup(owner.stop)
'''
new = '''def r2_guard_constructor_literal_setup(self):
    # These two retained R2 classes deliberately bypass native construction.
    # Supply its new exact literal in a fresh subclass, without touching the
    # original type's allocator slot or any ACK, owner, policy or result.
    original = WIRE.WireFixture

    class R2AllocatedFixture(original):
        def __new__(cls):
            value = object.__new__(cls)
            value.command_group_debt = []
            return value

    owner = mock.patch.object(WIRE, "WireFixture", R2AllocatedFixture)
    owner.start()
    self.addCleanup(owner.stop)
'''
assert before.count(old) == 1
after = before.replace(old, new, 1)
assert after.replace(new, old, 1) == before
path = BASE / 'candidate' / REL
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(after)

def functions(source):
    result = {}
    def visit(node, prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                name = prefix + child.name
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    result[name] = ast.get_source_segment(source, child)
                visit(child, name + '.')
            else:
                visit(child, prefix)
    visit(ast.parse(source))
    return result

old_functions = functions(before)
new_functions = functions(after)
assert all(new_functions[name] == body for name, body in old_functions.items() if not name.startswith('r2_guard_constructor_literal_setup'))
assert sum(node.name.startswith('test') for node in ast.walk(ast.parse(after)) if isinstance(node, ast.FunctionDef)) == 103
assert 'patch.object(WIRE.WireFixture, "__new__"' not in after
(BASE / 'proposal.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile='a/' + REL, tofile='b/' + REL)))
(BASE / 'exact-inverse.json').write_text(json.dumps({'before_setup': old, 'after_setup': new}, indent=2) + '\n')
(BASE / 'manifest.json').write_text(json.dumps({'state': 'SOURCE_ONLY_UNRUN_NO_ADOPTION_NO_NATIVE_CREDIT', 'path': REL,
    'preimage_sha256': expected, 'candidate_sha256': hashlib.sha256(after.encode()).hexdigest(),
    'original90_and_retained12_and_newtechnical_method_bodies': 'BYTE_EXACT',
    'production_files': 'UNTOUCHED', 'registry': 'UNCHANGED_103', 'sole_changed_helper': 'r2_guard_constructor_literal_setup',
    'whole_source_inverse': True, 'base_type_allocator_mutation': 'ABSENT',
    'new_owned_subclass': 'R2-only constructor literal; original module reference restored by test cleanup',
    'original_function_hashes': {name: hashlib.sha256(body.encode()).hexdigest() for name, body in old_functions.items()},
}, indent=2) + '\n')
