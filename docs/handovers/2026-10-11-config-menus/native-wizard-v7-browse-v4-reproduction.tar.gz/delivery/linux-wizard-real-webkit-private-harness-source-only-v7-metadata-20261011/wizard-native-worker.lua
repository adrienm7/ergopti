-- Private native receiving scenario. Production modules and file authorities
-- remain intact; this is an X11/WebKit UI subject, not an installed daemon.
local mode, target, receipt_path = assert(arg[1]), assert(arg[2]), assert(arg[3])
local report = { mode = mode, status = "running", assertions = {}, cleanup = {},
	limitations = { "no physical input", "no native Browse picker", "no daemon restart" } }
local Json = require("json")
local Manager, Gtk, GLib

local function check(value, name)
	report.assertions[#report.assertions + 1] = { name = name, passed = value == true }
	print((value == true and "PASS " or "FAIL ") .. name)
	assert(value == true, name)
end

local function read(path)
	local file, detail, errno = io.open(path, "rb")
	if not file then return nil, detail, errno end
	local read_ok, bytes, read_error = pcall(file.read, file, "*a")
	local close_ok, closed, close_error = pcall(file.close, file)
	if not close_ok or closed ~= true then
		report.cleanup.stream_errors = report.cleanup.stream_errors or {}
		report.cleanup.stream_errors[#report.cleanup.stream_errors + 1] = tostring(close_ok and close_error or closed)
	end
	-- The original read failure remains primary even if its held stream also
	-- refuses close. A successful read needs the actual close acknowledgement.
	if not read_ok then error(bytes, 0) end
	if type(bytes) ~= "string" then error(tostring(read_error or "native file read failed"), 0) end
	if not close_ok or closed ~= true then error(tostring(close_ok and close_error or closed), 0) end
	return bytes
end

local function pump()
	-- Bound each dispatch batch; a recurring source must not monopolize the probe.
	for _ = 1, 100 do
		if not Gtk.events_pending() then break end
		Gtk.main_iteration_do(false)
	end
	GLib.usleep(20000)
end

local function wait(predicate, seconds)
	local deadline = GLib.get_monotonic_time() + (seconds or 15) * 1000000
	repeat
		pump()
		if predicate() then return true end
	until GLib.get_monotonic_time() >= deadline
	return false
end

local function evaluate(source)
	local view = assert(Manager.webview_for("onboarding"), "actual onboarding WebView missing")
	local done, answer, failure = false, nil, nil
	view:run_javascript(source, nil, function(_, result)
		local called, value = pcall(function()
			return view:run_javascript_finish(result):get_js_value():to_string()
		end)
		if called then answer = value else failure = tostring(value) end
		done = true
	end, nil)
	assert(wait(function() return done end, 10), "actual WebKit evaluation deadline")
	assert(not failure, failure)
	return answer
end

local function page_ready()
	return wait(function()
		return evaluate("String(typeof _platform==='string' && _platform==='linux' && document.querySelectorAll('#lang-list .lang-item').length===21)") == "true"
	end)
end

local function step()
	return evaluate("String(_steps[_stepIndex])")
end

local function click_next(expected)
	check(evaluate("String(!document.getElementById('btn-next').disabled)") == "true", "Next admitted at " .. expected)
	evaluate("document.getElementById('btn-next').click(); 'clicked'")
	check(wait(function() return step() == expected end), "actual navigation to " .. expected)
end

local function english()
	evaluate("document.querySelector('#lang-list .lang-item[data-code=\"en\"]').click(); 'clicked'")
	check(wait(function()
		return evaluate("String(_selectedLocale==='en' && document.title==='ErgoptiPlus — Setup')") == "true"
	end), "actual English locale preview arrives")
end

local function close_native()
	local view = assert(Manager.webview_for("onboarding"))
	view:get_toplevel():close()
	check(wait(function() return not Manager.is_visible("onboarding") end), "native GTK close retires wizard")
end

local environment_ok, environment_error = pcall(function()
	assert(os.getenv("DISPLAY") or os.getenv("WAYLAND_DISPLAY"), "no genuine display")
	local lgi = require("lgi")
	Gtk, GLib = lgi.require("Gtk", "3.0"), lgi.GLib
	lgi.require("WebKit2", "4.1")
end)

local passed, failure = false, environment_error
if environment_ok then
	passed, failure = xpcall(function()
		local Paths = require("infra.config_paths")
		local I18n = require("infra.i18n")
		I18n.init()
		Manager = require("ui.webview_manager")
		-- No injected persistence/prepare/input/restart callbacks or mocked capabilities.
		Manager.set_daemon_state({})
		local Startup = require("ui.onboarding.startup")
		local startup_error
		local shown = Startup.run({ graphical = true, path = Paths.config("config.toml"),
			show = function(app) return Manager.show(app) == true end,
			fail = function(detail) startup_error = detail end })
		check(shown == true and startup_error == nil, "genuine first-use startup is admitted")
		if mode == "locales" or mode == "recommended" then
			local oracle = assert(Json.decode(assert(read(assert(arg[4], "original oracle path missing")))))
			check(not Manager.is_visible("onboarding"), mode .. " configured startup remains hidden")
			check(Manager.show("onboarding") == true, mode .. " explicit native wizard opens")
			check(page_ready(), mode .. " genuine host data reaches native page")
			if mode == "locales" then
				local original = assert(read(target .. "/config.toml"))
				local original_locale = I18n.get_locale()
				check(evaluate("JSON.stringify(Array.from(document.querySelectorAll('#lang-list .lang-item')).map(function(row){return row.dataset.code;}))") == assert(Json.encode(oracle.locale_order)), "all original 21 ordered locale rows received")
				for _, code in ipairs(oracle.locale_order) do
					local expected = assert(oracle.locales[code])
					evaluate("document.querySelector('#lang-list .lang-item[data-code=' + " .. assert(Json.encode(code)) .. " + ']').click(); 'clicked'")
					check(wait(function()
						return evaluate("String(document.title)") == expected.document_title
							and Manager.webview_for("onboarding"):get_toplevel():get_title() == expected.native_title
					end), "original DOM and actual GTK title " .. code)
					check(evaluate("String(_selectedLocale)") == code, "actual selected locale " .. code)
					check(evaluate("String(document.getElementById('language-title').textContent)") == expected["language-title"], "original visible language heading " .. code)
					click_next("config")
					for _, id in ipairs({ "config-title", "config-desc", "config-hint", "config-browse" }) do
						check(evaluate("String(document.getElementById(" .. assert(Json.encode(id)) .. ").textContent)") == expected[id], "original visible " .. id .. " " .. code)
					end
					click_next("tap_holds")
					check(wait(function() return evaluate("String(!_configPending)") == "true" end), "locale chosen-folder read " .. code)
					for index, page in ipairs(oracle.pages) do
						check(step() == page, "locale original page order " .. code .. " " .. page)
						for _, id in ipairs({ "page-title", "page-desc", "page-question-label", "page-yes-label", "page-no-label" }) do
							check(evaluate("String(document.getElementById(" .. assert(Json.encode(id)) .. ").textContent)") == expected.pages[page][id], "original rendered " .. code .. " " .. page .. " " .. id)
						end
						evaluate("var n=document.getElementById('page-no'); n.checked=true; n.dispatchEvent(new Event('change',{bubbles:true})); 'chosen'")
						if index < #oracle.pages then click_next(oracle.pages[index + 1]) end
					end
					for _ = 1, 8 do evaluate("document.getElementById('btn-back').click(); 'clicked'") end
					check(step() == "language", "real Back returns to language " .. code)
					check(I18n.get_locale() == original_locale, "preview does not publish runtime locale " .. code)
				end
				close_native()
				check(read(target .. "/config.toml") == original, "all locale previews preserve actual config bytes")
			else
				english()
				click_next("config")
				evaluate("document.getElementById('config-input').value=" .. assert(Json.encode(target)) .. "; 'entered'")
				click_next("tap_holds")
				check(wait(function() return evaluate("String(!_configPending)") == "true" end), "recommended actual chosen-folder read acknowledged")
				evaluate("var y=document.getElementById('page-yes'); y.checked=true; y.dispatchEvent(new Event('change',{bubbles:true})); 'chosen'")
				if evaluate("String(document.getElementById('page-checklist').open)") ~= "true" then
					evaluate("document.getElementById('page-checklist-summary').click(); 'opened'")
				end
				check(evaluate("String(document.getElementById('page-checklist').open)") == "true", "actual recommended checklist expanded")
				local trigger = assert(Json.encode(oracle.recommended.visible_trigger))
				-- Genuine user change handlers redraw the checklist each time: requery,
				-- never mutate pageState, operation payloads, or native writer inputs.
				for _ = 1, 16 do
					local changed = evaluate("(function(){var spans=Array.from(document.querySelectorAll('#page-checklist .item-trigger')); var s=spans.find(function(s){return s.textContent!==" .. trigger .. " && s.closest('label').querySelector('input').checked;}); if(!s)return 'done'; var b=s.closest('label').querySelector('input'); if(b.disabled)throw Error('actual other-key checkbox locked'); b.checked=false;b.dispatchEvent(new Event('change',{bubbles:true}));return 'changed';})()")
					if changed == "done" then break end
					check(changed == "changed", "actual recommended other-key deselection")
				end
				evaluate("(function(){var s=Array.from(document.querySelectorAll('#page-checklist .item-trigger')).find(function(s){return s.textContent===" .. trigger .. ";}); if(!s)throw Error('original left Alt visible row absent');var b=s.closest('label').querySelector('input');if(b.disabled)throw Error('left Alt row locked');b.checked=true;b.dispatchEvent(new Event('change',{bubbles:true}));return 'chosen';})()")
				check(evaluate("JSON.stringify(Array.from(document.querySelectorAll('#page-checklist .item-trigger')).filter(function(s){return s.closest('label').querySelector('input').checked;}).map(function(s){return s.textContent;}))") == assert(Json.encode({ oracle.recommended.visible_trigger })), "only original left Alt leaf visibly selected")
				for index = 2, #oracle.pages do
					click_next(oracle.pages[index])
					evaluate("var n=document.getElementById('page-no');n.checked=true;n.dispatchEvent(new Event('change',{bubbles:true}));'chosen'")
				end
				check(evaluate("String(!document.getElementById('btn-next').disabled)") == "true", "recommended actual Finish admitted")
				Manager.webview_for("onboarding"):run_javascript("document.getElementById('btn-next').click()", nil, nil, nil)
				check(wait(function() return not Manager.is_visible("onboarding") end, 25), "recommended real Finish commits and retires")
				check(type(read(target .. "/tap_hold.toml")) == "string", "real recommended writer created chosen-folder TapHold file")
				check(type(read(target .. "/layers.toml")) == "string", "real recommended navigation writer created chosen-folder layer file")
				check(Paths.get_config_dir() == target, "recommended folder genuinely published")
			end
		elseif mode == "reopen" then
			check(Paths.get_config_dir() == target, "new process reads persisted moved folder")
			check(I18n.get_locale() == "en", "new process reads persisted English locale")
			check(not Manager.is_visible("onboarding"), "configured startup does not reopen wizard")
			local original = assert(read(target .. "/config.toml"))
			check(Manager.show("onboarding") == true, "explicit real rerun opens wizard")
			check(page_ready(), "rerun page receives genuine host data")
			check(evaluate("String(_configDir)") == target, "rerun DOM has persisted folder")
			click_next("config")
			click_next("tap_holds")
			check(wait(function() return evaluate("String(!_configPending)") == "true" end), "rerun chosen-folder read acknowledged")
			local Manifest = require("infra.manifest_reader")
			local master_pages = { shortcuts = "shortcuts.enabled", gestures = "gestures.enabled",
				llm = "llm.enabled", metrics = "metrics.enabled" }
			for _, path in ipairs({ "shortcuts.enabled", "gestures.enabled", "llm.enabled", "metrics.enabled" }) do
				check(Manifest.default_for(path) == false, "actual native declared off default " .. path)
				local quoted = assert(Json.encode(path))
				check(evaluate("String(!Object.prototype.hasOwnProperty.call(_current," .. quoted .. ") || _current[" .. quoted .. "]===false)") == "true", "rerun current value " .. path)
			end
			check(Manifest.default_for("category_enabled.key_combinations") == true,
				"actual native key-combinations default is on")
			check(evaluate("String(_current['category_enabled.key_combinations']===false)") == "true",
				"rerun receives explicit key-combinations off value")
			local pages = { "tap_holds", "shortcuts", "gestures", "keyboard_layout", "hotstrings", "llm", "metrics" }
			for index, page in ipairs(pages) do
				check(step() == page, "rerun real page order " .. page)
				if master_pages[page] then
					local quoted_page = assert(Json.encode(page))
					check(evaluate("String(_pageState[" .. quoted_page .. "].answer===false && document.getElementById('page-no').checked && !document.getElementById('page-yes').checked)") == "true",
						"fresh-process visible native off state " .. master_pages[page])
				end
				if index < #pages then click_next(pages[index + 1]) end
			end
			close_native()
			check(read(target .. "/config.toml") == original, "rerun cancellation preserves exact config bytes")
		else
			check(Manager.is_visible("onboarding"), "absent config offers actual wizard")
			check(page_ready(), "real page owns ready and receives 21 locale rows")
			english()
			if mode == "cancel" then
				click_next("config")
				close_native()
				local bytes, _, errno = read(Paths.config("config.toml"))
				check(bytes == nil and errno == 2, "fresh cancellation does not create config")
			elseif mode == "finish" then
				-- Reaching this mode in a fresh process proves cancellation was not completion.
				click_next("config")
				evaluate("document.getElementById('config-input').value=" .. assert(Json.encode(target)) .. "; 'entered'")
				click_next("tap_holds")
				check(wait(function() return evaluate("String(!_configPending)") == "true" end), "real moved-folder read acknowledged")
				local metrics_path = os.getenv("XDG_DATA_HOME") .. "/ergopti/metrics.sqlite"
				check(wait(function() return evaluate("String(_metricsPath)") == metrics_path end), "metrics store remains in actual XDG data folder")
				local pages = { "tap_holds", "shortcuts", "gestures", "keyboard_layout", "hotstrings", "llm", "metrics" }
				check(evaluate("String(_steps.length)") == "9", "seven declared pages after two opening steps")
				for index, page in ipairs(pages) do
					check(step() == page, "genuine page order " .. page)
					evaluate("var n=document.getElementById('page-no'); n.checked=true; n.dispatchEvent(new Event('change',{bubbles:true})); 'chosen'")
					check(evaluate("String(document.getElementById('page-no').checked)") == "true", "explicit No choice " .. page)
					if index < #pages then click_next(pages[index + 1]) end
				end
				check(evaluate("String(!document.getElementById('btn-next').disabled)") == "true", "actual Finish is admitted")
				-- Finish may destroy the view before JavaScript completion; do not require
				-- an artificial reply or suppress the actual native retirement.
				Manager.webview_for("onboarding"):run_javascript("document.getElementById('btn-next').click()", nil, nil, nil)
				check(wait(function() return not Manager.is_visible("onboarding") end, 25), "genuine Finish commits and retires native window")
				check(type(read(target .. "/config.toml")) == "string", "actual moved-folder config exists after Finish")
				check(Paths.get_config_dir() == target, "current resolver confirms actual folder publication")
				check(I18n.get_locale() == "en", "current locale confirms actual persistence acknowledgement")
			else error("unsupported private scenario: " .. mode) end
		end
	end, debug.traceback)
end

-- Attempt independent cleanup even after any assertion or native callback failure.
if Manager then
	local called, retired = pcall(Manager.shutdown)
	report.cleanup.manager_called, report.cleanup.manager_retired = called, called and retired == true
	if not called or retired ~= true then
		passed = false
		report.cleanup.error = tostring(retired)
		if failure == nil then failure = "actual manager cleanup refused: " .. tostring(retired) end
	end
end
report.status = environment_ok and (passed and "PASS" or "FAIL") or "ENVIRONMENT_UNRUN"
report.failure = not passed and tostring(failure) or nil
if not passed then io.stderr:write(tostring(failure), "\n") end
local receipt, open_error = io.open(receipt_path, "wb")
local receipt_ok = false
if receipt then
	local write_ok, written, write_error = pcall(function()
		return receipt:write(assert(Json.encode(report)), "\n")
	end)
	local close_ok, closed, close_error = pcall(receipt.close, receipt)
	receipt_ok = write_ok and written ~= nil and close_ok and closed == true
	if not receipt_ok then
		io.stderr:write("Native receipt write/close refused: ", tostring(write_ok and write_error or written),
			" / ", tostring(close_ok and close_error or closed), "\n")
	end
else io.stderr:write("Native receipt open refused: ", tostring(open_error), "\n") end
if not receipt_ok then os.exit(1) end
os.exit(environment_ok and (passed and 0 or 1) or 2)
