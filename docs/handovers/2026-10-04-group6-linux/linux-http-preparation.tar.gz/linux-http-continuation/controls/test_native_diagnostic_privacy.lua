--- tests/unit/meta/test_public_preflight.lua

--- ==============================================================================
--- MODULE: Actual Public HTTP Preflight Comparison Controls
--- DESCRIPTION:
--- Exercises the actual public wrapper and isolated native curl engine
--- with independent native admission/closure acknowledgements. Expectations
--- require serializer-only NUL refusal without owner replacement. Original
--- historical and failed public-comparison assertions remain untouched.
--- ==============================================================================

local helpers = require("tests.helpers")
local Logger = require("logger.shim")
Logger.error = function() end
local stage = assert(os.getenv("ERGOPTI_HTTP_STAGE"), "complete staged driver required")

--- Loads an actual public adapter against independent native port receipts.
--- @param kind string Managed public adapter or native production engine.
--- @return table client, table state
local function fresh(kind)
	local state = { handles = {}, closes = {}, kills = {}, spawns = 0 }
	local uv = {}
	local function handle(role)
		local value = { role = role, closing = false, closed = false }
		state.handles[#state.handles + 1] = value
		return value
	end
	function uv.hrtime() return 0 end
	function uv.new_pipe() return handle("pipe") end
	function uv.new_timer() state.timer = handle("timer"); return state.timer end
	function uv.timer_start(timer, timeout, _, callback)
		if timeout < 0 then return nil, "EINVAL" end
		timer.timeout, timer.callback = timeout, callback
		return 0
	end
	function uv.timer_stop() return 0 end
	function uv.read_start(pipe, callback) pipe.callback = callback; return 0 end
	function uv.read_stop() return 0 end
	function uv.is_closing(value) return value.closing or value.closed end
	function uv.close(value, callback)
		value.closing = true
		state.closes[#state.closes + 1] = { handle = value, callback = callback }
		return 0
	end
	function uv.kill(pid, signal) state.kills[#state.kills + 1] = { pid, signal }; return 0 end
	function uv.write(_, config, callback) state.config = config; callback(nil); return 0 end
	function uv.spawn(command, options, callback)
		state.spawns = state.spawns + 1
		state.command, state.options, state.exit = command, options, callback
		return handle("process"), 9173
	end
	function state.ack_closes()
		while #state.closes > 0 do
			local receipt = table.remove(state.closes, 1)
			receipt.handle.closing, receipt.handle.closed = false, true
			if receipt.callback then receipt.callback() end
		end
	end
	function state.complete_failure(diagnostic, code, buffered)
		state.options.stdio[2].callback(nil, buffered and "\nERGOPTI_HTTP_STATUS:000\n" or "")
		state.options.stdio[2].callback(nil, nil)
		state.options.stdio[3].callback(nil, diagnostic .. "\nERGOPTI_PROXY_RECEIPT:000:?\n" .. (buffered and "" or "\nERGOPTI_HTTP_STATUS:000\n"))
		state.options.stdio[3].callback(nil, nil)
		state.exit(code, 0)
		state.ack_closes()
	end
	local names = { "luv", "adapters.curl_http_client", "adapters.system_proxy", "infra.monotonic", "infra.proxy_policy" }
	local saved = {}
	for _, name in ipairs(names) do saved[name] = package.loaded[name]; package.loaded[name] = nil end
	package.loaded.luv = uv
	local client = dofile(stage .. "/adapters/" .. (kind == "native" and "curl_http_client.lua" or "http_client.lua"))
	for _, name in ipairs(names) do package.loaded[name] = saved[name] end
	return client, state
end


local vectors = {
 { name = "URI-bearing unsupported diagnostic", code = 7, text = "curl: unsupported http://dummy-user62:dummy-password62@private.invalid\n", fixed = true },
 { name = "truncated schemeless proxy diagnostic", code = 5, text = "curl: could not parse proxy dummy-user62:dummy-password62" .. string.rep("x", 65536) .. "@private.invalid\n", fixed = true },
 { name = "ordinary connection diagnostic", code = 7, text = "curl: (7) Failed to connect to host", fixed = false },
 { name = "ordinary TLS diagnostic", code = 60, text = "curl: (60) SSL certificate problem: unable to get local issuer certificate", fixed = false },
}
helpers.describe("native diagnostic privacy admission", function()
 for _, buffered in ipairs({true, false}) do
  for _, vector in ipairs(vectors) do
   local selected, current_buffered = vector, buffered
   helpers.it((buffered and "buffered " or "stream ") .. vector.name, function()
    local client, state = fresh("native")
    local results = {}
    local options = { owner = "diagnostic-owner", timeout_ms = 1000, method = "GET", buffered = current_buffered, proxy_selection = { mode = "environment" } }
    local operation = client.dispatch_owned("http://127.0.0.1:9173/control", {}, nil, options, nil, function(result) results[#results + 1] = result end)
    helpers.assert_true(operation.started)
    state.complete_failure(selected.text, selected.code, current_buffered)
    helpers.assert_eq(#results, 1)
    local result = results[1]
    local expected = selected.fixed and ("curl exited with code " .. selected.code) or selected.text
    helpers.assert_true(result.error == expected, "independent native diagnostic expectation")
    helpers.assert_true(not result.ok and result.status == 0 and result.body == "")
    helpers.assert_eq(result.failure_receipt.curl_exit, selected.code)
    helpers.assert_eq(result.failure_receipt.http_status, 0)
    helpers.assert_eq(result.failure_receipt.proxy_connect_status, 0)
    helpers.assert_eq(result.failure_receipt.stage, selected.code == 5 and "proxy_resolve" or (selected.code == 60 and "tls" or "connect"))
    helpers.assert_true(operation:is_settled())
    helpers.assert_true(not client.isActive("diagnostic-owner"))
    for _, value in ipairs(state.handles) do helpers.assert_true(value.closed, "exact native close acknowledgement") end
   end)
  end
 end
end)
return helpers
