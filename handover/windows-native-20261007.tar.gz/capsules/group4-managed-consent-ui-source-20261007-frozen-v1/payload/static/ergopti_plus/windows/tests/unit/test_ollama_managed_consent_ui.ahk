﻿; tests/unit/test_ollama_managed_consent_ui.ahk

; ==============================================================================
; MODULE: Managed Consent Modal Recording Controls
; DESCRIPTION:
; Runs actual consent/source functions through explicit recorded modal ports.
; No GUI, network, configuration writer or native runtime starts in these models.
; ==============================================================================

_OMUI_World() {
	local captured := _OMC_Snapshot()
	return Map("captured", captured, "live", OllamaManagedCopySnapshot(captured), "calls", [], "nested", 0)
}

_OMUI_Confirm(World, Body, Title, Options) {
	global _OllamaManagedConsentOwner, _LLM_LocalModelAsking
	AssertTrue(_OllamaManagedConsentOwner is Map)
	AssertTrue(_LLM_LocalModelAsking)
	AssertEqual(Options, "YesNo Default2 Icon?")
	World["calls"].Push(Map("body", Body, "title", Title))
	return "Yes"
}

_OMUI_Port(World, Confirm := 0) {
	return Map("snapshot", (*) => World["live"], "confirm", HasMethod(Confirm, "Call") ? Confirm : _OMUI_Confirm.Bind(World))
}

_OMUI_ExactArchiveConsentRestoresOwner() {
	global _OllamaManagedConsentOwner, _LLM_LocalModelAsking
	local world := _OMUI_World()
	AssertFalse(IsObject(_OllamaManagedConsentOwner))
	AssertFalse(_LLM_LocalModelAsking)
	AssertTrue(OllamaManagedArchiveConsent(world["captured"], OllamaReleaseWindowsAsset("windows-amd64"), _OMUI_Port(world)))
	AssertEqual(world["calls"].Length, 1)
	AssertEqual(world["calls"][1]["body"], t("ollama.offer_body"))
	AssertFalse(IsObject(_OllamaManagedConsentOwner))
	AssertFalse(_LLM_LocalModelAsking)
}

_OMUI_ForeignAssetBeforeModal() {
	local world := _OMUI_World(), asset := OllamaReleaseWindowsAsset("windows-amd64")
	asset["bytes"] += 1
	AssertFalse(OllamaManagedArchiveConsent(world["captured"], asset, _OMUI_Port(world)))
	AssertEqual(world["calls"].Length, 0)
}

_OMUI_SelectionAfterModalRefuses() {
	global _OllamaManagedConsentOwner, _LLM_LocalModelAsking
	local world := _OMUI_World()
	Confirm(Body, Title, Options) {
		_OMUI_Confirm(world, Body, Title, Options)
		world["live"]["generation"] += 1
		return "Yes"
	}
	AssertFalse(OllamaManagedArchiveConsent(world["captured"], OllamaReleaseWindowsAsset("windows-amd64"), _OMUI_Port(world, Confirm)))
	AssertEqual(world["calls"].Length, 1)
	AssertFalse(IsObject(_OllamaManagedConsentOwner))
	AssertFalse(_LLM_LocalModelAsking)
}

_OMUI_NestedConsentCannotAcquire() {
	local world := _OMUI_World(), asset := OllamaReleaseWindowsAsset("windows-amd64")
	Confirm(Body, Title, Options) {
		_OMUI_Confirm(world, Body, Title, Options)
		AssertFalse(OllamaManagedArchiveConsent(world["captured"], asset, _OMUI_Port(world)))
		world["nested"] += 1
		return "Yes"
	}
	AssertTrue(OllamaManagedArchiveConsent(world["captured"], asset, _OMUI_Port(world, Confirm)))
	AssertEqual(world["calls"].Length, 1)
	AssertEqual(world["nested"], 1)
}

_OMUI_ModelUsesSeparateSelectedPrompt() {
	local world := _OMUI_World()
	AssertTrue(OllamaManagedModelConsent(world["captured"], _OMUI_Port(world)))
	AssertEqual(world["calls"].Length, 1)
	AssertEqual(world["calls"][1]["body"], StrReplace(t("llm.local_model.missing_body"), "{1}", world["captured"]["model"]))
	AssertEqual(world["calls"][1]["title"], t("llm.local_model.missing_title"))
}

_OMUI_RefusalAndExceptionRestoreOwner() {
	global _OllamaManagedConsentOwner, _LLM_LocalModelAsking
	local world := _OMUI_World(), asset := OllamaReleaseWindowsAsset("windows-amd64")
	AssertFalse(OllamaManagedArchiveConsent(world["captured"], asset, _OMUI_Port(world, (*) => "No")))
	AssertFalse(IsObject(_OllamaManagedConsentOwner))
	AssertFalse(_LLM_LocalModelAsking)
	Refuse(*) {
		throw Error("Recorded modal exception.")
	}
	AssertThrows(() => OllamaManagedArchiveConsent(world["captured"], asset, _OMUI_Port(world, Refuse)))
	AssertFalse(IsObject(_OllamaManagedConsentOwner))
	AssertFalse(_LLM_LocalModelAsking)
}

Test("managed-consent-exact-archive", _OMUI_ExactArchiveConsentRestoresOwner)
Test("managed-consent-foreign-asset", _OMUI_ForeignAssetBeforeModal)
Test("managed-consent-post-modal-current", _OMUI_SelectionAfterModalRefuses)
Test("managed-consent-nested-owner", _OMUI_NestedConsentCannotAcquire)
Test("managed-consent-separate-model", _OMUI_ModelUsesSeparateSelectedPrompt)
Test("managed-consent-refusal-exception-handback", _OMUI_RefusalAndExceptionRestoreOwner)
