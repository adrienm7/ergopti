class NativeTimedAddCancellationTests(unittest.TestCase):
    receive = NativeTimedAddCaptureObservationTests.receive
    installed_fact = NativeTimedAddCaptureObservationTests.installed_fact

    @staticmethod
    def actual_signal_handler():
        # Acquire the exact existing worker handler without running its main role.
        import ast
        source = (SUPPORT / "native_http_wire_fixture.py").read_text()
        main = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == "main")
        handler = next(node for node in main.body if isinstance(node, ast.FunctionDef) and node.name == "interrupted")
        namespace = {"FixtureFailure": WIRE.FixtureFailure}
        exec(compile(ast.Module(body=[handler], type_ignores=[]), "existing-wire-signal-handler", "exec"), namespace)
        return namespace["interrupted"]

    def signal_control(self, signum, actor, timeout):
        import signal
        prior = signal.getsignal(signum)
        signal.signal(signum, self.actual_signal_handler())
        interrupted = []
        original_print = print

        def dispatch(*args):
            try:
                os.kill(os.getpid(), signum)
            except BaseException as failure:
                interrupted.append(failure)
                raise

        def publish(value, **options):
            if value.startswith("# native_http_trust_install "):
                dispatch()
            else:
                original_print(value, **options)

        try:
            port = (mock.patch.object(WIRE.WireFixture, "_trust_install_stream", side_effect=dispatch)
                    if actor == "capture" else mock.patch("builtins.print", side_effect=publish))
            with port:
                result = self.receive(timeout=timeout)
        finally:
            signal.signal(signum, prior)
        self.assertEqual(len(interrupted), 1)
        self.assertEqual(type(interrupted[0]), WIRE.FixtureFailure)
        self.assertEqual(interrupted[0].args, ("Native fixture cancelled",))
        return interrupted[0], result

    def test69ActualSIGINTAndSIGTERMCaptureCancellationCannotReturnSuccess(self):
        import signal
        for signum in (signal.SIGINT, signal.SIGTERM):
            with self.subTest(signum=int(signum)):
                interruption, result = self.signal_control(signum, "capture", False)
                _, owner, _, _, refusal, returned, _, captures, _ = result
                self.assertIs(refusal, interruption)
                self.assertIsNone(returned)
                self.assertTrue(owner.reaped)
                self.assertTrue(all(value.closed for value in captures))

    def test70ActualSIGINTAndSIGTERMPublicationCancellationCannotReturnSuccess(self):
        import signal
        for signum in (signal.SIGINT, signal.SIGTERM):
            with self.subTest(signum=int(signum)):
                interruption, result = self.signal_control(signum, "publication", False)
                _, owner, _, _, refusal, returned, _, captures, _ = result
                self.assertIs(refusal, interruption)
                self.assertIsNone(returned)
                self.assertTrue(owner.reaped)
                self.assertTrue(all(value.closed for value in captures))

    def test71ExistingTimeoutPrimarySurvivesActualSignalDuringBothObservers(self):
        import signal
        for actor in ("capture", "publication"):
            with self.subTest(actor=actor):
                interruption, result = self.signal_control(signal.SIGTERM, actor, True)
                fixture, _, _, primary, refusal, returned, _, captures, _ = result
                self.assertIsNot(refusal, interruption)
                self.assertIs(refusal, primary)
                self.assertIsNone(returned)
                self.assertEqual(fixture.command_fact, {"phase": "deadline", "status": None})
                self.assertTrue(all(value.closed for value in captures))

    def test72KeyboardInterruptSystemExitAndBaseExceptionCannotBecomeSuccess(self):
        for actor in ("capture", "publication"):
            for failure in (KeyboardInterrupt(), SystemExit(75), BaseException("controlled stop")):
                with self.subTest(actor=actor, category=type(failure).__name__):
                    original_print = print

                    def publish(value, **options):
                        if value.startswith("# native_http_trust_install "):
                            raise failure
                        original_print(value, **options)

                    port = (mock.patch.object(WIRE.WireFixture, "_trust_install_stream", side_effect=failure)
                            if actor == "capture" else mock.patch("builtins.print", side_effect=publish))
                    with port:
                        _, _, _, _, refusal, returned, _, captures, _ = self.receive(timeout=False)
                    self.assertIs(refusal, failure)
                    self.assertIsNone(returned)
                    self.assertTrue(all(value.closed for value in captures))

    def test73ControlInterruptionCannotReplaceAnAlreadyFailedCommand(self):
        for failure in (KeyboardInterrupt(), SystemExit(75), WIRE.FixtureFailure("Native fixture cancelled")):
            with self.subTest(category=type(failure).__name__):
                with mock.patch.object(WIRE.WireFixture, "_trust_install_stream", side_effect=failure):
                    fixture, _, _, primary, refusal, returned, _, captures, _ = self.receive()
                self.assertIs(refusal, primary)
                self.assertIsNone(returned)
                self.assertEqual(fixture.command_fact, {"phase": "deadline", "status": None})
                self.assertTrue(all(value.closed for value in captures))

    def test74ThrowingNativeObservationGuardIsOptionalAndStillClosesCaptures(self):
        original = getattr

        def observe(owner, name, default=None):
            if name == "reaped":
                raise RuntimeError("controlled passive field refusal")
            return original(owner, name, default)

        with mock.patch.object(WIRE, "getattr", side_effect=observe, create=True):
            _, _, _, _, refusal, returned, _, captures, _ = self.receive(timeout=False)
        self.assertIsNone(refusal)
        self.assertEqual(returned, (0, b"original output"))
        self.assertTrue(all(value.closed for value in captures))
