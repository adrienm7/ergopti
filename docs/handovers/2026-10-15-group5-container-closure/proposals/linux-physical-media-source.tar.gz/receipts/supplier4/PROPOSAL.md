# Private Linux media producer source proposal

No supplier/product implementation is modified. G3 still owns both native supplier
files. These exact additive seams require span coordination before adoption.

## Native supplier seams

1. `static/ergopti_plus/linux/adapters/evdev_reader.lua`
   - In `build_ffi_backend`, retain the real `luv.fs_fstat` C function at native
     construction, with its original module/export identity. Add one backend
     `device_identity(fd)` port; no second open/read/grab.
   - Observe the already-acquired exact descriptor once during `open`, while the
     Reader's existing busy guard is held. Require synchronous success with no
     secondary error/status, `stat.type == "char"`, and positive exact integer
     `stat.rdev <= 9007199254740991`. Convert only this admitted number with
     `string.format("%.0f", value)`. The luv source forwards uint64 st_rdev via
     lua_pushinteger; out-of-exact-range or signed overflow is refused. Never
     substitute fd, path, inode, collector ID or a random/generation integer.
   - Retain that immutable device string on the original descriptor/session and
     event record; expose it only in the existing detached `event_view` as
     `device`. Existing raw event fields/capabilities and first-order input
     admission remain unchanged. Missing luv/fstat/device identity refuses media
     credit while preserving the old keyboard reader; it must be reported as a
     media prerequisite failure, not synthesized.
   - Include `device_identity` in original native-port currency snapshots. Preserve
     all existing read_epoch, original_row, source_owner observer and close-debt
     invariants; custom backends cannot mint native device/event authority.
2. `static/ergopti_plus/linux/adapters/keyboard_hook.lua`
   - Only append the fifth callback argument: the existing original Reader
     capability `_event_receipts[ev]` when this exact row is genuine/current.
     The original code/name/character/value arguments and delivery stay intact.
   - Before invoking the existing callback, retain a weak private receipt keyed
     by that exact capability, bound to original source path/slot/session/origin
     generation, `_physical_sources[source] == true`, no SYN loss and the actual
     retained source owner/observer. A remapped/transformed detached row acquires
     no receipt. No new hook, device reader, output or suppression is created.
   - Add `physical_event_view(capability)` for detached current original facts
     only, and `physical_source_current(capability)` for retained same-session
     continuity after later reads. Both authenticate the private issued record,
     original captured Reader ports, original Hook module/session/source arrays,
     physical classification, no reconciliation and exact native source currency.
     The source predicate never accepts a caller-provided positive lambda.
     `capture_input_owner` cannot substitute: it is intentionally restricted to
     active logical one-shot/CapsWord frames.

## Producer and persistence joins

3. New `static/ergopti_plus/linux/modules/keylogger/physical_media_capture.lua`:
   join the original frozen Hook/Reader ports; resolve only through committed
   shared `MediaStore.policy`/MediaIdentity, retain press identity by native device
   and semantic ID, count no autorepeat, and match release only within the same
   original source and unchanged existing keylogger privacy/hold token. Duration
   crosses any pause/private/secure/focus exclusion => cancel the entire interval.
   Use the existing shared physical-release arithmetic and shared tap threshold.
4. `static/ergopti_plus/linux/modules/keylogger/keylogger.lua`: own this consumer
   and exact pending admitted media events; use current `may_record`, password/app
   filter, `hold_accounting_token`, and original captured app/date. Flush only via
   existing `SqliteWriter.insert_media_events(_device_id, exact_queue, threshold)`;
   retain the exact queue on refusal. Collector partition is not physical device
   identity. No JSON fallback may pretend durable semantic media acknowledgment.
5. `static/ergopti_plus/linux/ergopti_hotstrings.lua`: pass only actual callback
   fifth argument into this joined receiver. Preserve numeric keyboard/volume
   behavior; the five admitted semantic media identities must not also become
   numeric keyboard geometry/WPM credit. Existing desync/capture-gate exclusions
   cancel pending intervals; no silent capture-policy relaxation.

## Focused tests / registration

- Existing `linux/tests/unit/adapters/test_evdev_reader.lua`: additive native
  descriptor identity and original object/currentness rejection schedules.
- Existing hook safety/native-source module: exact first4 callback preservation,
  fifth current original capability and rejection of synthetic/remapped/stale,
  physical-classification/source-replacement/SYN-loss schedules.
- Existing `linux/tests/unit/modules/keylogger/test_hold_durations.lua` and
  `test_sqlite_first_open.lua`: privacy cancellation, queue-retention and genuine
  SQLite rows through the real producer-to-writer join where feasible.
- Add one consumer unit file only if existing module cannot enroll its contract;
  coordinate actual inventory/runner registration with Root, never edit runner.
- Freeze independent expected five IDs and original/cut/restored behavioral
  assertions. Never regenerate expectations from the implementation.

## Authentic ABI source evidence and actual checks

- Official luv tag 1.48.0-2 resolves to commit
  `7233e6dea92498a244feb51b790c1ba51e8abbff` (fresh `git ls-remote`).
  Retained immutable `src/fs.c` download matches tag bytes exactly, SHA256
  `f8177f3dfddfa762561255b5a1f825d11a530f7065f59625efdd887b305689f1`.
  Lines 57-71 forward uv_stat_t.st_rdev to `rdev`; 681-687 call uv_fs_fstat
  on the given native descriptor. The FS_CALL synchronous success and error
  branches clean their same native request before returning (451-500).
- Installed lua-luv package 1.48.0-2-3 SHA256
  `259450ee9f1c3b5dbd1b1cae7c4a485f76adf176f7a16fb6ddbd48eedc0d9b05`.
- Retained Node public uv.h SHA256
  `fddec8c096616675b4578d85222663c8624dce3ee67f5be1c33ba83eb02a827c`
  declares st_rdev uint64 in uv_stat_t and descriptor-taking uv_fs_fstat. No
  platform-specific libc struct stat layout is guessed in LuaJIT FFI.
- Actual LuaJIT C `luv.fs_fstat`/libuv1.50.0 observes `/dev/null` rdev259 and
  `/dev/zero` rdev261, type char; after actual acknowledged same-fd close,
  fs_fstat refuses with EBADF. This proves the descriptor binding API only.
- `/dev/input/event0` and `/dev/uinput` are unavailable here. No evdev grab,
  hardware input, compositor or physical delivery is proved. A genuine owned
  pipe can test read framing and identity refusal but cannot manufacture the
  missing native EVIOCGRAB/device authority; portable models stay distinct.
