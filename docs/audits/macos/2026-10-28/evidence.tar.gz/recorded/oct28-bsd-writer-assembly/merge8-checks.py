import os,json,subprocess,concurrent.futures,hashlib
from pathlib import Path
p=Path('/workspace/scratch/oct28-merge8-verification');p.mkdir(mode=0o700)
m=json.loads(Path('/workspace/scratch/oct28-bsd-writer-assembly/manifest-go.json').read_text());env=dict(os.environ);env['PATH']=m['toolchain']['path_prefix']+':'+env['PATH'];env['LD_LIBRARY_PATH']=m['toolchain']['ld_library_path']
def run(row):
 n,c=row;e=dict(env);private=p/n;private.mkdir(mode=0o700)
 for key in ('TMPDIR','XDG_RUNTIME_DIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_STATE_HOME'):
  d=private/key.lower();d.mkdir(mode=0o700);e[key]=str(d)
 e.update(TMP=e['TMPDIR'],TEMP=e['TMPDIR'],RUNNER_TEMP=e['TMPDIR'])
 with (private/'output.log').open('wb') as f:r=subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,env=e)
 result={'name':n,'command':c,'actual_exit':r.returncode,'log':str(private/'output.log')};(private/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(n,r.returncode,flush=True);return result
assert run(('generate',['npm','run','-s','gen']))['actual_exit']==0
rows=[('gen-check',['npm','run','-s','gen:check']),('format',['npm','run','-s','format:check']),('strict',['npm','run','-s','lint:conventions:strict']),('ahk-locals',['npm','run','-s','test:ahk-local-same-as-global']),('windows-source',['node','tools/test/test-windows-updater-original-source.cjs']),('source-encoding',['npm','run','-s','test:source-encoding']),('ahk-encoding',['npm','run','-s','test:ahk-encoding']),('lua-undefined',['npm','run','-s','test:lua-undefined-globals']),('plan',['node','tools/test/verify-change.cjs','--plan']),('menu-parity',['node','tools/test/test-menu-parity.cjs']),('menu-manifest',['node','tools/test/test-menu-manifest.cjs']),('recommended',['node','tools/test/test-recommended-defaults-rule.cjs']),('menu-handlers',['node','tools/test/test-menu-action-handler-bijection.cjs']),('menu-categories',['node','tools/test/test-menu-category-coverage.cjs']),('hs-defaults',['npm','run','test:hs','--','--module=test_default_gestures_are_manifest']),('hs-gesture-menu',['npm','run','test:hs','--','--module=test_menu_gestures_handlers_match_manifest']),('linux-menu',['npm','run','test:linux','--','--module=test_menu_matches_manifest'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
(p/'receipts.json').write_text(json.dumps(results,indent=2)+'\n');assert all(r['actual_exit']==0 for r in results)
