# Publication library only. The native test/lease host owns initialization.
Set-StrictMode -Version Latest

function Initialize-OllamaPublicationOwner {
	if (Get-Variable -Name OP_Rows -Scope Script -ErrorAction SilentlyContinue) {
		throw 'Publication owner initialization is exclusive.'
	}
	if ('Ergopti.Ollama.PublicationNative' -as [type]) {
		throw 'A preloaded publication native type cannot be adopted.'
	}
	Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
namespace Ergopti.Ollama {
    public static class PublicationNative {
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        private static extern uint GetFinalPathNameByHandleW(IntPtr h, StringBuilder b, uint n, uint flags);
        public static string FinalPath(IntPtr handle) {
            StringBuilder buffer = new StringBuilder(32768);
            uint length = GetFinalPathNameByHandleW(handle, buffer, (uint)buffer.Capacity, 0);
            if (length == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
            if (length >= (uint)buffer.Capacity) throw new InvalidOperationException("Native final path is not complete.");
            string value = buffer.ToString();
            if (!value.StartsWith(@"\\?\", StringComparison.Ordinal)) throw new InvalidOperationException("Native final path is not local DOS form.");
            return value.Substring(4);
        }
    }
}
'@
	$script:OP_Rows = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal)
}

function Get-OllamaPublicationRow([string]$Id) {
	if (-not $script:OP_Rows.ContainsKey($Id)) { throw 'Unknown native publication owner.' }
	return $script:OP_Rows[$Id]
}

function Get-OllamaPublicationNativeRoot($Root) {
	if ($Root.root_handle -eq [IntPtr]::Zero -or $Root.versions_handle -eq [IntPtr]::Zero -or
		-not $Root.handles.Contains($Root.root_handle) -or -not $Root.handles.Contains($Root.versions_handle)) {
		throw 'Publication root and versions handles are not exact members of this root owner.'
	}
	if ([Ergopti.Ollama.ManagedNative]::Identity($Root.root_handle) -ne $Root.identity -or
		[Ergopti.Ollama.ManagedNative]::Identity($Root.versions_handle) -ne $Root.versions_identity) {
		throw 'Publication root or versions native identity changed.'
	}
	$nativeRoot = [Ergopti.Ollama.PublicationNative]::FinalPath($Root.root_handle)
	$nativeVersions = [Ergopti.Ollama.PublicationNative]::FinalPath($Root.versions_handle)
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals($nativeVersions, [IO.Path]::Combine($nativeRoot, 'versions'))) {
		throw 'Publication versions is not the exact held native root child.'
	}
	return [ordered]@{ root_native_path = $nativeRoot; versions_native_path = $nativeVersions;
		versions_identity = $Root.versions_identity }
}

function Assert-OllamaPublicationLocation($Row) {
	$captured = Get-OllamaPublicationNativeRoot $Row.root
	$expected = [IO.Path]::Combine($captured.versions_native_path, $Row.final_leaf)
	$actual = [Ergopti.Ollama.PublicationNative]::FinalPath($Row.descriptor.SafeFileHandle.DangerousGetHandle())
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals($Row.destination, $expected) -or
		-not [StringComparer]::OrdinalIgnoreCase.Equals($actual, $expected) -or
		-not [StringComparer]::OrdinalIgnoreCase.Equals([IO.Path]::GetDirectoryName($actual), $captured.versions_native_path) -or
		-not [StringComparer]::Ordinal.Equals([IO.Path]::GetFileName($actual), $Row.final_leaf)) {
		throw 'The exact descriptor is outside its owned advertised location.'
	}
}

function Add-OllamaPublicationRecord($Row, [string]$Kind, $Fields) {
	$record = [ordered]@{ sequence = $Row.sequence + 1; kind = $Kind }
	foreach ($key in $Fields.Keys) { $record[$key] = $Fields[$key] }
	$bytes = [Text.UTF8Encoding]::new($false).GetBytes(($record | ConvertTo-Json -Compress -Depth 10) + "`n")
	$Row.wal.Write($bytes, 0, $bytes.Length)
	$Row.wal.Flush($true)
	$Row.sequence = $record.sequence
}

function Set-OllamaPublicationDebt($Row, [string]$Reason) {
	if ($Row.first_error -eq '') { $Row.first_error = $Reason }
	$Row.phase = 'retained-debt'
}

function New-OllamaPublicationOwner($Root, [string]$Ticket, [string]$Identity, [string]$ManifestHash) {
	if ($Ticket -notmatch '\A[0-9a-f]{32}\z') { throw 'Publication needs an exact private ticket.' }
	$id = [Guid]::NewGuid().ToString('N')
	$row = [ordered]@{ id = $id; root = $Root; ticket = $Ticket; stage = $null;
		wal = $null; wal_path = [IO.Path]::Combine($Root.path, '.publication-' + $Ticket + '.jsonl');
		wal_identity = ''; sequence = 0; descriptor = $null; descriptor_identity = '';
		descriptor_bytes = $null; descriptor_hash = ''; temporary = ''; destination = '';
		native_root = ''; native_versions = ''; native_container = ''; versions_identity = ''; final_leaf = '';
		phase = 'acquiring'; rename_attempted = $false; first_error = ''; consumers = 0;
		manifest_hash = $ManifestHash;
		close_debt = [Collections.Generic.List[object]]::new(); closed = $false }
	# Publish the row before any native acquisition. Constructor failure is owned.
	$script:OP_Rows.Add($id, $row)
	try {
		$captured = Get-OllamaPublicationNativeRoot $Root
		$row.native_root = $captured.root_native_path
		$row.native_versions = $captured.versions_native_path
		$row.versions_identity = $captured.versions_identity
		$row.wal_path = [IO.Path]::Combine($row.native_root, '.publication-' + $Ticket + '.jsonl')
		$row.stage = Open-OllamaPreparedStage $Root $Ticket $Identity $ManifestHash
		$row.native_container = [Ergopti.Ollama.PublicationNative]::FinalPath($row.stage.handle)
		if (-not [StringComparer]::OrdinalIgnoreCase.Equals($row.native_container, [IO.Path]::Combine($row.native_root, '.stage-' + $Ticket))) {
			throw 'Publication container is outside the exact held native root.'
		}
		$m = $row.stage.manifest
		$leaf = $m.version + '-' + $m.asset + '-' + $m.archive_sha256 + '.json'
		[void](Assert-OllamaRelativePath $leaf)
		$row.final_leaf = $leaf
		$row.destination = [IO.Path]::Combine($row.native_versions, $leaf)
		$row.temporary = [IO.Path]::Combine($row.native_versions, '.publish-' + $Ticket + '.json')
		$row.wal = [Ergopti.Ollama.ManagedNative]::CreateOwnedFile($row.wal_path)
		$row.wal_identity = [Ergopti.Ollama.ManagedNative]::Identity($row.wal.SafeFileHandle.DangerousGetHandle())
		Add-OllamaPublicationRecord $row 'publication-owner' ([ordered]@{
			owner_id = $id; ticket = $Ticket; root_identity = $Root.identity;
			container_identity = $Identity; manifest_sha256 = $ManifestHash;
			wal_identity = $row.wal_identity; final_leaf = $leaf; root_native_path = $row.native_root; versions_identity = $row.versions_identity })
		$row.phase = 'prepared'
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		# A typed owner ID remains available even when construction is partial.
		$_.Exception.Data['ollama_publication_owner'] = $id
		throw
	}
	return $id
}

function Assert-OllamaPublicationImage($Row) {
	$captured = Get-OllamaPublicationNativeRoot $Row.root
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals($captured.root_native_path, $Row.native_root) -or
		-not [StringComparer]::OrdinalIgnoreCase.Equals($captured.versions_native_path, $Row.native_versions) -or
		$captured.versions_identity -ne $Row.versions_identity) { throw 'Publication native root bindings changed.' }
	$handle = $Row.descriptor.SafeFileHandle.DangerousGetHandle()
	if ([Ergopti.Ollama.ManagedNative]::Identity($handle) -ne $Row.descriptor_identity) {
		throw 'Publication descriptor identity changed.'
	}
	if ((Get-OllamaStreamHash $Row.descriptor) -ne $Row.descriptor_hash) {
		throw 'Publication descriptor image changed.'
	}
	if ([Ergopti.Ollama.ManagedNative]::Identity($Row.stage.handle) -ne $Row.stage.manifest.identity) {
		throw 'Publication container identity changed.'
	}
}

function Publish-OllamaVersionDescriptor([string]$Id, [scriptblock]$AfterNativeRename = $null) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.phase -ne 'prepared' -or $row.closed) { throw 'Publication is a one-shot prepared operation.' }
	try {
		$m = $row.stage.manifest
		$image = [ordered]@{ kind = 'ollama-immutable-container-reference'; schema = 1;
			root_identity = $row.root.identity; root_native_path = $row.native_root; versions_identity = $row.versions_identity; container = '.stage-' + $row.ticket;
			container_identity = $m.identity; ticket = $row.ticket;
			manifest_sha256 = $row.manifest_hash;
			catalogue_sha256 = $m.catalogue_sha256; archive_sha256 = $m.archive_sha256;
			version = $m.version; asset = $m.asset }
		$row.descriptor_bytes = [Text.UTF8Encoding]::new($false).GetBytes(($image | ConvertTo-Json -Compress -Depth 10) + "`n")
		Add-OllamaPublicationRecord $row 'descriptor-intent' ([ordered]@{ name = [IO.Path]::GetFileName($row.temporary) })
		$row.descriptor = [Ergopti.Ollama.ManagedNative]::CreateOwnedFile($row.temporary)
		$row.descriptor_identity = [Ergopti.Ollama.ManagedNative]::Identity($row.descriptor.SafeFileHandle.DangerousGetHandle())
		Add-OllamaPublicationRecord $row 'descriptor-owned' ([ordered]@{ identity = $row.descriptor_identity })
		$row.descriptor.Write($row.descriptor_bytes, 0, $row.descriptor_bytes.Length)
		$row.descriptor.Flush($true)
		$hasher = [Security.Cryptography.SHA256]::Create()
		try { $row.descriptor_hash = [BitConverter]::ToString($hasher.ComputeHash($row.descriptor_bytes)).Replace('-', '').ToLowerInvariant() }
		finally { $hasher.Dispose() }
		Add-OllamaPublicationRecord $row 'descriptor-complete' ([ordered]@{
			sha256 = $row.descriptor_hash; bytes = $row.descriptor_bytes.Length })
		Assert-OllamaPublicationImage $row
		Add-OllamaPublicationRecord $row 'rename-intent' ([ordered]@{ final_leaf = [IO.Path]::GetFileName($row.destination) })
		$row.rename_attempted = $true
		$row.phase = 'publication-indeterminate'
		# Rename only the small file. Never rename or release its content container.
		[Ergopti.Ollama.ManagedNative]::RenameCreate($row.descriptor.SafeFileHandle.DangerousGetHandle(), $row.destination)
		if ($null -ne $AfterNativeRename) { & $AfterNativeRename $Id }
		return Confirm-OllamaVersionDescriptor $Id
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		throw
	}
}

function Confirm-OllamaVersionDescriptor([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	if (-not $row.rename_attempted -or $row.closed -or $null -eq $row.descriptor) {
		throw 'Publication confirmation requires its retained native file owner.'
	}
	# Published observations still revalidate exact native identity and location.
	try {
		Assert-OllamaPublicationImage $row
		Assert-OllamaPublicationLocation $row
		if ($row.phase -ne 'published') {
			Add-OllamaPublicationRecord $row 'published' ([ordered]@{ identity = $row.descriptor_identity; sha256 = $row.descriptor_hash })
		}
		$row.phase = 'published'
		return Get-OllamaPublicationObservation $Id
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		throw
	}
}

function Get-OllamaPublicationObservation([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	return [ordered]@{ owner_id = $Id; phase = $row.phase; closed = $row.closed;
		container_path = $row.native_container; logical_container_path = if ($null -ne $row.stage) { $row.stage.path } else { '' };
		container_identity = if ($null -ne $row.stage) { $row.stage.manifest.identity } else { '' };
		descriptor_path = $row.destination; descriptor_identity = $row.descriptor_identity;
		descriptor_sha256 = $row.descriptor_hash; rename_attempted = $row.rename_attempted;
		consumers = $row.consumers; first_error = $row.first_error; close_debt = $row.close_debt.Count;
		executable = if ($row.native_container -ne '') { [IO.Path]::Combine($row.native_container, 'ollama.exe') } else { '' } }
}

function Reserve-OllamaPublicationLeaseHost([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.phase -ne 'published' -or $row.closed -or $row.consumers -ne 0) {
		throw 'A lease host requires one retained published container.'
	}
	Assert-OllamaPublicationImage $row
	$row.consumers = 1
	# No release API accepts a caller Boolean. Actual daemon/job attachment and
	# terminal receipt binding are the next host slice; reservation retains debt.
	return Get-OllamaPublicationObservation $Id
}

function Close-OllamaPublicationFileOnce($Row, [string]$Name) {
	$stream = $Row[$Name]
	if ($null -eq $stream) { return }
	$Row[$Name] = $null
	try { $stream.Dispose() }
	catch {
		$Row.close_debt.Add([ordered]@{ kind = 'stream'; name = $Name; resource = $stream; state = 'uncertain' })
		Set-OllamaPublicationDebt $Row $_.Exception.Message
	}
}

function Close-OllamaPublicationOwner([string]$Id) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.closed) { return $true }
	if ($row.consumers -ne 0 -or $row.phase -ne 'published' -or $row.close_debt.Count -ne 0) {
		return $false
	}
	# This release is allowed only before any runtime host reservation. Durable
	# reference/WAL files remain; ordinary stage cleanup stays forbidden.
	foreach ($stream in $row.stage.streams) {
		try { $stream.Dispose() }
		catch {
			$row.close_debt.Add([ordered]@{ kind = 'stage-stream'; resource = $stream; state = 'uncertain' })
			Set-OllamaPublicationDebt $row $_.Exception.Message
		}
	}
	$row.stage.streams.Clear()
	foreach ($name in @($row.stage.directory_handles.Keys)) {
		$handle = $row.stage.directory_handles[$name]
		$row.stage.directory_handles[$name] = [IntPtr]::Zero
		if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($handle)) {
			$row.close_debt.Add([ordered]@{ kind = 'directory'; resource = $handle; state = 'uncertain' })
		}
	}
	$parent = $row.stage.handle
	$row.stage.handle = [IntPtr]::Zero
	if (-not [Ergopti.Ollama.ManagedNative]::CloseHandle($parent)) {
		$row.close_debt.Add([ordered]@{ kind = 'container'; resource = $parent; state = 'uncertain' })
	}
	Close-OllamaPublicationFileOnce $row 'descriptor'
	Close-OllamaPublicationFileOnce $row 'wal'
	if ($row.close_debt.Count -ne 0) {
		Set-OllamaPublicationDebt $row 'Publication resource close was not acknowledged.'
		return $false
	}
	$row.closed = $true
	$row.phase = 'published-no-host'
	[void]$script:OP_Rows.Remove($Id)
	return $true
}


# Produces allocation/lookup hints, never a lease or native READY authority.
function Open-OllamaPublishedPublicationOwner($Root, [string]$Ticket, [string]$StageIdentity,
	[string]$ManifestHash, [string]$DescriptorIdentity, [string]$DescriptorHash, $AcquisitionOwner) {
	if ($Ticket -notmatch '\A[0-9a-f]{32}\z' -or $ManifestHash -notmatch '\A[0-9a-f]{64}\z' -or
		$DescriptorHash -notmatch '\A[0-9a-f]{64}\z') { throw 'Published source requires its exact captured install receipts.' }
	$id = [Guid]::NewGuid().ToString('N')
	$row = [ordered]@{ id = $id; root = $Root; ticket = $Ticket; stage = $null;
		wal = $null; descriptor = $null; descriptor_identity = $DescriptorIdentity; descriptor_hash = $DescriptorHash;
		manifest_hash = $ManifestHash; phase = 'acquiring'; first_error = ''; consumers = 0; closed = $false;
		rename_attempted = $false; destination = ''; final_leaf = ''; native_container = ''; native_root = '';
		native_versions = ''; versions_identity = ''; close_debt = [Collections.Generic.List[object]]::new() }
	$script:OP_Rows.Add($id, $row)
	try {
		$native = Get-OllamaPublicationNativeRoot $Root
		$row.native_root = $native.root_native_path
		$row.native_versions = $native.versions_native_path
		$row.versions_identity = $native.versions_identity
		$row.stage = Open-OllamaPreparedStage $Root $Ticket $StageIdentity $ManifestHash $false $AcquisitionOwner
		$row.native_container = [Ergopti.Ollama.PublicationNative]::FinalPath($row.stage.handle)
		if (-not [StringComparer]::OrdinalIgnoreCase.Equals($row.native_container, [IO.Path]::Combine($row.native_root, '.stage-' + $Ticket))) {
			throw 'Source container is outside its retained native root.'
		}
		$m = $row.stage.manifest
		$row.final_leaf = $m.version + '-' + $m.asset + '-' + $m.archive_sha256 + '.json'
		[void](Assert-OllamaRelativePath $row.final_leaf)
		$row.destination = [IO.Path]::Combine($row.native_versions, $row.final_leaf)
		$row.descriptor = Open-OllamaReadFile $row.destination
		Assert-OllamaPublicationImage $row
		Assert-OllamaPublicationLocation $row
		$image = Read-OllamaJsonStream $row.descriptor
		if ($image.kind -ne 'ollama-immutable-container-reference' -or $image.schema -ne 1 -or
			$image.root_identity -ne $Root.identity -or $image.container_identity -ne $StageIdentity -or
			$image.ticket -ne $Ticket -or $image.manifest_sha256 -ne $ManifestHash -or
			$image.catalogue_sha256 -ne $m.catalogue_sha256 -or $image.archive_sha256 -ne $m.archive_sha256 -or
			$image.version -ne $m.version -or $image.asset -ne $m.asset -or
			$image.container -ne ('.stage-' + $Ticket) -or $image.versions_identity -ne $row.versions_identity -or
			-not [StringComparer]::OrdinalIgnoreCase.Equals($image.root_native_path, $row.native_root)) {
			throw 'Published descriptor does not advertise the admitted immutable container.'
		}
		# This adopts an existing verified publication, not another rename attempt.
		# Published confirmation still revalidates its native identity/path/hash.
		$row.rename_attempted = $true
		$row.phase = 'published'
	} catch {
		Set-OllamaPublicationDebt $row $_.Exception.Message
		$_.Exception.Data['ollama_publication_owner'] = $id
		throw
	}
	return $id
}

function Get-OllamaExistingRuntimeExpectation($Root, [string]$Catalogue, [string]$CatalogueHash,
	[string]$Asset, [string]$GuardianPath, [string]$LauncherPath, [int]$MetadataBudget, $AcquisitionOwner) {
	if ($MetadataBudget -le 0 -or $Root.ContainsKey('inspection')) { throw 'Runtime inspection requires one explicit bounded owner.' }
	$row = [ordered]@{ source = $null; source_stream = $null; descriptor = $null; publication = ''; phase = 'acquiring';
		first_error = ''; close_debt = [Collections.Generic.List[object]]::new() }
	$Root.inspection = $row
	try {
		$row.source = Open-OllamaReleaseSource $Catalogue $CatalogueHash $Asset $row
		$native = Get-OllamaPublicationNativeRoot $Root
		$leaf = $row.source.version + '-' + $Asset + '-' + $row.source.pin.sha256 + '.json'
		[void](Assert-OllamaRelativePath $leaf)
		$path = [IO.Path]::Combine($native.versions_native_path, $leaf)
		if ([Ergopti.Ollama.ManagedNative]::PathIsAbsent($path)) {
			$row.phase = 'missing'
			$result = [ordered]@{ ok = $true; phase = 'missing'; asset = $Asset; catalogue_sha256 = $CatalogueHash }
		} else {
			$row.descriptor = Open-OllamaReadFile $path
			if ($false -and $row.descriptor.Length -gt $MetadataBudget) { throw 'Published metadata exceeds its captured bound.' }
			$identity = [Ergopti.Ollama.ManagedNative]::Identity($row.descriptor.SafeFileHandle.DangerousGetHandle())
			$hash = Get-OllamaStreamHash $row.descriptor
			$image = Read-OllamaJsonStream $row.descriptor
			Assert-OllamaExistingDescriptorShape $image
			if ($image.asset -cne $Asset -or $image.version -cne $row.source.version -or
				$image.archive_sha256 -cne $row.source.pin.sha256 -or $image.catalogue_sha256 -cne $CatalogueHash -or
				$image.root_identity -cne $Root.identity -or $image.versions_identity -cne $native.versions_identity -or
				-not [StringComparer]::OrdinalIgnoreCase.Equals($image.root_native_path, $native.root_native_path)) {
				throw 'Published metadata differs from the captured canonical release and native root.'
			}
			# The first descriptor stays deny-writer/delete held while the existing
			# publication owner independently acquires the exact known runtime tree.
			$row.publication = Open-OllamaPublishedPublicationOwner $Root $image.ticket $image.container_identity `
				$image.manifest_sha256 $identity $hash $AcquisitionOwner
			$publication = Get-OllamaPublicationRow $row.publication
			if ([Ergopti.Ollama.ManagedNative]::Identity($publication.descriptor.SafeFileHandle.DangerousGetHandle()) -cne $identity) {
				throw 'The existing descriptor identity changed during retained acquisition.'
			}
			$result = Get-OllamaRuntimeSourceExpectation $row.publication $GuardianPath $LauncherPath
			if ($result.Version -cne $row.source.version -or $result.Asset -cne $Asset -or
				$result.CatalogueHash -cne $CatalogueHash -or $result.ArchiveHash -cne $row.source.pin.sha256) {
				throw 'Runtime expectation differs from its continuously held canonical release.'
			}
			if (-not (Close-OllamaPublicationOwner $row.publication)) { throw 'Runtime inspection retains publication close debt.' }
			$row.publication = ''
			$row.phase = 'published'
		}
		Close-OllamaRuntimeInspectionReaders $row
		if ($row.close_debt.Count -ne 0) { throw 'Runtime inspection retains reader close debt.' }
		return $result
	} catch {
		if ($row.first_error -eq '') { $row.first_error = $_.Exception.Message }
		$row.phase = 'retained-inspection'
		throw
	}
}

function Assert-OllamaExistingDescriptorShape($Image) {
	$strings = @('kind', 'root_identity', 'container_identity', 'ticket', 'manifest_sha256',
		'catalogue_sha256', 'archive_sha256', 'version', 'asset', 'container', 'versions_identity', 'root_native_path')
	$fields = @($Image.PSObject.Properties.Name)
	if ($fields.Count -ne $strings.Count + 1 -or $fields -notcontains 'schema') { throw 'Existing descriptor shape is not closed.' }
	foreach ($name in $strings) {
		if ($fields -notcontains $name -or -not ($Image.$name -is [string])) { throw 'Existing descriptor fields require scalar Strings.' }
	}
	if (-not ($Image.schema -is [int] -or $Image.schema -is [long]) -or $Image.schema -ne 1 -or
		$Image.kind -cne 'ollama-immutable-container-reference' -or $Image.ticket -notmatch '\A[0-9a-f]{32}\z' -or
		$Image.manifest_sha256 -notmatch '\A[0-9a-f]{64}\z' -or $Image.catalogue_sha256 -notmatch '\A[0-9a-f]{64}\z' -or
		$Image.archive_sha256 -notmatch '\A[0-9a-f]{64}\z' -or $Image.version -notmatch '\A[0-9]+\.[0-9]+\.[0-9]+\z' -or
		$Image.asset -notin @('windows-amd64', 'windows-arm64') -or $Image.container -cne ('.stage-' + $Image.ticket)) {
		throw 'Existing descriptor contains unsupported scalar values.'
	}
	foreach ($name in @('root_identity', 'container_identity', 'versions_identity')) {
		if ($Image.$name -notmatch '\A[0-9a-f]{8}:[0-9a-f]{16}\z') { throw 'Existing descriptor native identity is malformed.' }
	}
}

function Close-OllamaRuntimeInspectionReaders($Row) {
	foreach ($name in @('descriptor', 'source_stream')) {
		$resource = $Row[$name]
		if ($null -eq $resource) { continue }
		$stream = $resource
		$Row[$name] = $null
		try { $stream.Dispose() }
		catch { $Row.close_debt.Add([ordered]@{ name = $name; resource = $stream; phase = 'uncertain' }) }
	}
}

function Get-OllamaRuntimeSourceExpectation([string]$Id, [string]$GuardianPath, [string]$LauncherPath) {
	$row = Get-OllamaPublicationRow $Id
	if ($row.phase -ne 'published' -or $row.closed -or $row.consumers -ne 0 -or $row.close_debt.Count -ne 0) {
		throw 'Source expectations require one unreserved live publication.'
	}
	Assert-OllamaPublicationImage $row
	Assert-OllamaPublicationLocation $row
	[void](Assert-OllamaLocalPath $GuardianPath)
	[void](Assert-OllamaLocalPath $LauncherPath)
	$paths = [Collections.Generic.List[string]]::new()
	foreach ($handle in $row.root.handles) { $paths.Add([Ergopti.Ollama.PublicationNative]::FinalPath($handle)) }
	$paths.Add($row.native_container)
	foreach ($handle in $row.stage.directory_handles.Values) { $paths.Add([Ergopti.Ollama.PublicationNative]::FinalPath($handle)) }
	foreach ($relative in @('prepared.json', 'stage-owner.json')) { $paths.Add([IO.Path]::Combine($row.native_container, $relative)) }
	$paths.Add($row.destination)
	foreach ($file in $row.stage.manifest.files) { $paths.Add([IO.Path]::Combine($row.native_container, $file.path.Replace('/', '\'))) }
	if ($row.root.ContainsKey('models')) {
		if ($row.root.models.phase -ne 'held') { throw 'Models capacity requires its retained native acquisition.' }
		$paths.Add([Ergopti.Ollama.PublicationNative]::FinalPath($row.root.models.marker.SafeFileHandle.DangerousGetHandle()))
	}
	# Code paths remain hints and are authenticated by the later source worker.
	# Its native FinalPath port rejects paths >=32768 UTF-16 units. Reserve that
	# documented port capacity per image, including its terminator, so MSIX path
	# virtualization cannot silently underallocate the otherwise exact channel.
	[uint64]$units = 0
	foreach ($path in $paths) { $units += [uint64]$path.Length + 1 }
	$units += [uint64]2 * 32768
	[uint64]$records = [uint64]$paths.Count + 2
	[uint64]$bytes = 80 + $records * 72 + $units * 2
	if ($records -eq 0 -or $units -eq 0 -or $bytes -gt [uint32]::MaxValue) { throw 'Source channel capacity exceeds its native wire.' }
	$expectation = [ordered]@{ ok = $true; phase = 'published'; schema = 1;
		RootPath = $row.native_root; RootIdentity = $row.root.identity; Ticket = $row.ticket;
		StageIdentity = $row.stage.manifest.identity; ManifestHash = $row.manifest_hash;
		DescriptorIdentity = $row.descriptor_identity; DescriptorHash = $row.descriptor_hash;
		RecordCapacity = $records; PathCapacity = $units;
		Executable = [IO.Path]::Combine($row.native_container, 'ollama.exe');
		Version = $row.stage.manifest.version; Asset = $row.stage.manifest.asset;
		CatalogueHash = $row.stage.manifest.catalogue_sha256; ArchiveHash = $row.stage.manifest.archive_sha256 }
	if ($row.root.ContainsKey('models')) {
		$expectation.ModelsDirectory = $row.root.models.requested_path
		$expectation.ModelsFolderName = $row.root.models.leaf
		$expectation.ModelsIdentity = $row.root.models.identity
	}
	return $expectation
}
