#!/bin/bash
# Download authenticated Debian packages and extract them without system install.
set -euo pipefail
ruby_setup_root=/workspace/ergopti-cloud/group6-ruby
test "$(uname -s)" = Linux
test "$(uname -m)" = x86_64
mkdir -p "$ruby_setup_root/apt/lists/partial" "$ruby_setup_root/apt/archives/partial" \
    "$ruby_setup_root/apt/empty" "$ruby_setup_root/runtime" "$ruby_setup_root/casks"
# apt.conf/sources.list are the supplied isolated configuration, retaining
# signed-by=/usr/share/keyrings/debian-archive-keyring.gpg and authenticated-only admission.
export APT_CONFIG="$ruby_setup_root/apt/apt.conf"
/usr/bin/apt-get update > "$ruby_setup_root/apt-update.log" 2>&1
/usr/bin/apt-get --download-only --no-install-recommends -y install \
    ruby3.3=3.3.8-2 libruby3.3=3.3.8-2 > "$ruby_setup_root/apt-download.log" 2>&1
ruby_signature_directory=$(mktemp -d "$ruby_setup_root/apt/signature.XXXXXX")
ruby_verified_release="$ruby_signature_directory/Release"
trap 'rm -f "$ruby_verified_release"; rmdir "$ruby_signature_directory"' EXIT
/usr/bin/sqv --keyring /usr/share/keyrings/debian-archive-keyring.gpg \
    --cleartext --output "$ruby_verified_release" \
    "$ruby_setup_root/apt/lists/deb.debian.org_debian_dists_trixie_InRelease" \
    > "$ruby_setup_root/apt/signature.stdout" 2> "$ruby_setup_root/apt/signature.stderr"
mv "$ruby_verified_release" "$ruby_setup_root/apt/Release.authenticated"
python3 "$ruby_setup_root/verify-and-extract.py"
"$ruby_setup_root/bin/ruby" --version
