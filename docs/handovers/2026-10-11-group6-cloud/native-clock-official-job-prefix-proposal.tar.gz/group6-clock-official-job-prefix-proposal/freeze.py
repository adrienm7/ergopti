from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,tempfile,os,tarfile
P=Path(__file__).resolve().parent
rels=['tools/ci/native_http_clock_evidence.cjs','tools/test/test-native-http-clock-evidence.cjs']
h=lambda raw:hashlib.sha256(raw).hexdigest()
# The durable reproduction must receive the actual loader dependency too.
r=P/'receive.py'; s=r.read_text(); assert s.count("'tools/lib/git-bash.cjs'])")==1
r.write_text(s.replace("'tools/lib/git-bash.cjs'])", "'tools/lib/git-bash.cjs','tools/lib/python.cjs'])"))
forward='';inverse='';pins={}
for rel in rels:
 a=(P/'preimages'/rel).read_bytes();b=(P/'candidate'/rel).read_bytes();assert b'\r' not in a+b
 pins[rel]={'preimage':h(a),'candidate':h(b)}
 forward+=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 inverse+=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'candidate.patch').write_text(forward);(P/'candidate.inverse.patch').write_text(inverse)
checkroot=Path(tempfile.mkdtemp(prefix='whole-inverse-',dir=P));env=os.environ.copy();env['GIT_CEILING_DIRECTORIES']=str(P)
for rel in rels:
 dst=checkroot/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((P/'preimages'/rel).read_bytes())
operations=[]
for args in [['--check',str(P/'candidate.patch')],[str(P/'candidate.patch')],['--check',str(P/'candidate.inverse.patch')],[str(P/'candidate.inverse.patch')]]:
 result=subprocess.run(['git','apply',*args],cwd=checkroot,env=env,capture_output=True,check=True);operations.append({'argv':args,'exit':result.returncode})
 if len(operations)==2:
  for rel in rels:assert (checkroot/rel).read_bytes()==(P/'candidate'/rel).read_bytes()
for rel in rels:assert (checkroot/rel).read_bytes()==(P/'preimages'/rel).read_bytes()
shutil.rmtree(checkroot)
(P/'whole-inverse.json').write_text(json.dumps({'source_only':True,'paths':pins,'operations':operations,'whole_forward_inverse_exact':True},indent=2)+'\n')
records=json.loads((P/'first-receipts.json').read_text());out=(P/'candidate-physical32.stdout').read_bytes();err=(P/'candidate-physical32.stderr').read_bytes()
assert sum(line.startswith(b'PASS ') for line in out.splitlines())==32
assert out.rstrip().endswith(b'CLOCK_RECEIVER controls=32 native=false official=false')
inventory=json.loads((P/'source-inventory.json').read_text());assert len(inventory)==536
assert 'tools/lib/python.cjs' in inventory
final={'name':'candidate-physical32-final-loader-closure','exit':0,'exit_evidence':'Actual terminal tools.write_stdin session77561 returned exit0 and structured final receipt {exit:0,source_count:536,PASS_lines:32,source_fence:true}.','PASS_lines':32,'failed':0,'skipped':0,'source_count':536,'canonical_source_fence':True,'stdout_sha256':h(out),'stderr_sha256':h(err),'native':False,'official_authentication':False,'node_version':'v22.22.2','dependency_correction':'Add exact tools/lib/python.cjs bytes to private physical source; no candidate source changes.'}
(P/'final-receipts.json').write_text(json.dumps({'first_records_retained':records,'final':final},indent=2)+'\n')
E=Path('/workspace/ergopti-cloud/run38166806073-macos-native-receiving');prov=P/'provenance';prov.mkdir(exist_ok=True)
for file in ['run.initial.json','jobs.snapshot02.json']:(prov/file).write_bytes((E/file).read_bytes())
repo=Path('/workspace/ergopti'); snippets={}
for rel in ['.github/workflows/ci.yml','.github/workflows/ci-macos.yml']:
 raw=(repo/rel).read_bytes();lines=raw.decode().splitlines(); selected=[]
 for i,line in enumerate(lines):
  if "name: 'macOS'" in line or 'name: Managed Ollama native' in line or 'uses: ./.github/workflows/ci-macos.yml' in line:
   selected.append({'line':i+1,'source':lines[max(0,i-2):i+3]})
 snippets[rel]={'sha256':h(raw),'selected_source':selected}
(prov/'workflow-name-sources.json').write_text(json.dumps({'head':'5173d4fbb1565ea6252dbc74551e3260a818f3c5','sources':snippets},indent=2)+'\n')
(P/'source-pins.json').write_text(json.dumps({'paths':pins,'source_inventory':{'files':536,'sha256':h((P/'source-inventory.json').read_bytes())},'canonical_ref_mutations':False,'source_custody':'Parent must receive exact function/callback scope before canonical adoption.'},indent=2)+'\n')
print(json.dumps({'paths':pins,'whole_inverse':True,'source_files':536}))
