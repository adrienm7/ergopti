from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/unit/modules/llm/servers/test_ollama_runtime_terminal_delivery.ahk')
s=p.read_text(encoding='utf-8-sig')
old='this.TimerFailure := ""';assert s.count(old)==1;s=s.replace(old,'this.TimerFailure := ""\n\t\tthis.TimerFailed := false')
old='catch as Err\n\t\t\tthis.TimerFailure := Err.Message';assert s.count(old)==1;s=s.replace(old,'catch as Err {\n\t\t\tthis.TimerFailed := true\n\t\t\tthis.TimerFailure := Err.Message\n\t\t}')
old='AssertEqual("", F.TimerFailure, "the real revocation timer must finish normally")';assert s.count(old)==1;s=s.replace(old,'AssertFalse(F.TimerFailed, "the real revocation timer must finish normally: " . F.TimerFailure)')
p.write_text(s,encoding='utf-8-sig',newline='\n')
