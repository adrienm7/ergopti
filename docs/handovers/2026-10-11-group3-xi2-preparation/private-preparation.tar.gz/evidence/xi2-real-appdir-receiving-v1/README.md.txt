# Actual Xi staging and export receiving

This is private receiving evidence, not canonical adoption or device qualification.
The frozen V2 proposal and its 271 seals remain unchanged. No product, test,
workflow, index, or ref was edited for this receiving.

The original production stager completed with exit 0 and its exact admission
acknowledgement on a minimal genuine installed source graph. The graph contains
`runtime_probe.lua`, `native_proxy_runtime.lua`, generated `native_runtime.lua`,
shared `json.lua`, and its real `compat/utf8.lua` dependency. These are byte copies
of the production sources that the actual builder normally includes through its
Linux/shared tree copies. This does not prove that builder, AppRun, image creation,
or package installation.

The retained first staging attempt exited 1 on an incomplete four-file source
layout. Its generic CLI refusal remains unchanged. A separate read-only diagnostic
of that old layout returns `proxy-runtime-unavailable`. Early helper failures
(argument count, missing UTF-8 source, incomplete XDefaultRootWindow declaration)
remain recorded; they are not product defects or successful load observations.

Default activation lacked Xi/GIO pkg-config metadata. Existing ignored Xi
metadata resolves the actual system library. GIO metadata was downloaded into this
task's directory using the existing signed APT configuration, checked against its
SHA256, and extracted locally. It reports real system modules, schemas, and the
installed gio-querymodules executable. The new dev metadata Debian revision is
2.84.4-3~deb13u5; the host GLib is 2.84.4-3~deb13u3. This is not a matching-package
rebuild claim. No sudo, global install, activation change, or metadata rewrite was
used. Patchelf is absent and is not called by this production staging path.

The selected LuaJIT and curl are actual ELF executables, with the ignored real
runtime binary directory before cloud shell wrappers. The unchanged stager owns
its subprocess deadlines, FD-bound writes, ELF closure, and cleanup. Its original
preallocation process census passed; it differs from the unavailable hardware
fixture `/proc/self/task/PID/children` precondition. The outer generic reaper is not
an independent full-family qualification.

The separate load-only helper uses both current production FFI declaration blocks
and the exact production `required_port` function. It resolves XIQueryVersion,
XISelectEvents, XQueryExtension, XDefaultRootWindow, XGetEventData, and
XFreeEventData without invoking them. All six have genuine callable FFI types;
`dladdr` identifies the exact staged Xi/X11 objects. Seven installed dependency
mappings and their hashes are retained. The staged Xi ELF is byte-identical to
`/usr/lib/x86_64-linux-gnu/libXi.so.6.1.0`, SHA256
`8ca60a4e6a90bba494e601e03e792b2d440cced9985deca64431abbd78613adb`.
No X server, Display, GUI, input, device, cookie, or output owner was allocated.

Commands and raw exits/stdout/stderr are in the result JSON files. Run helpers only
in a fresh receiving directory with the pinned sources and recorded dependencies;
the staging helper deliberately refuses existing source destinations. Verify
this retained directory with `sha256sum --check files.sha256`. Existing source
proposal checksums are referenced rather than copied. Current AppDirs are retained
actual outputs; their byte hashes are part of the receipt and checksum file.

Full builder/AppRun assembly, AppImage creation, installation, other distributions,
and actual Xi event/input/output receiving remain unrun. Shared ownership and
canonical admission remain pending.
