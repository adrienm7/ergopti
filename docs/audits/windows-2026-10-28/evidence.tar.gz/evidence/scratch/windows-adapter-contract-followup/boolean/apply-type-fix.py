from pathlib import Path
root=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/unit/adapters')
p=root/'test_adapter_contract_vectors_system.ahk';s=p.read_text(encoding='utf-8-sig')
union='Out = true || Out = false || Out = 1 || Out = 0'
assert s.count(union)==6;s=s.replace(union,'Out is Integer && (Out == true || Out == false)')
for name in ['Out','HasAfter','HasGone']:
 for value,alias in [('true','1'),('false','0')]:
  s=s.replace(name+' = '+value+' || '+name+' = '+alias,name+' is Integer && '+name+' == '+value)
old='Assert(CB_Write("test") = true || CB_Write("test") = 1, "CB_Write must return true")';assert s.count(old)==1
s=s.replace(old,'ContractWriteOk := CB_Write("test")\n\t\t\tAssert(ContractWriteOk is Integer && ContractWriteOk == true, "CB_Write must return true")')
old='Assert(CB_Restore("") = true || CB_Restore("") = 1, "CB_Restore(null) must return true")';assert s.count(old)==1
s=s.replace(old,'ContractRestoreOk := CB_Restore("")\n\t\t\tAssert(ContractRestoreOk is Integer && ContractRestoreOk == true, "CB_Restore(null) must return true")')
s=s.replace('Assert(Running, "KHIsRunning() must be truthy after KHStart(); got " . Running)','Assert(Running is Integer && Running == true, "KHIsRunning() must be Boolean true after KHStart(); got " . Running)')
s=s.replace('Assert(!Running, "KHIsRunning() must be falsy after KHStop(); got " . Running)','Assert(Running is Integer && Running == false, "KHIsRunning() must be Boolean false after KHStop(); got " . Running)')
assert 'Out = true ||' not in s and 'Out = false ||' not in s
p.write_text(s,encoding='utf-8-sig',newline='\n')
p=root/'test_adapter_contract_vectors.ahk';s=p.read_text(encoding='utf-8-sig');old='Assert(Result = false or Result = 0,';assert s.count(old)==1;s=s.replace(old,'Assert(Result is Integer && Result == false,');p.write_text(s,encoding='utf-8-sig',newline='\n')
