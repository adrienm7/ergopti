# group3-linux93-public-join-v1/verify_packet.py
"""Verify exact source proposal bytes and a private patch roundtrip only."""

from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import tempfile
import shutil

base = Path(__file__).resolve().parent
root = Path("/workspace/ergopti")
receipt = json.loads((base / "receipt.json").read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for name, expected in receipt["artifacts"].items():
    path = base / name
    assert path.is_file() and not path.is_symlink(), name
    assert digest(path) == expected, name
pairs = receipt["source_pairs"]
assert len(pairs) == 19
for row in pairs:
    path = row["path"]
    post = base / "candidate" / path
    assert digest(post) == row["post_sha256"], path
    if row["pre_sha256"] is None:
        result = subprocess.run(
            ["git", "cat-file", "-e", receipt["source"] + ":" + path], cwd=root, capture_output=True
        )
        assert result.returncode != 0, path
    else:
        pre = base / "preimages" / path
        assert digest(pre) == row["pre_sha256"], path
        original = subprocess.check_output(
            ["git", "show", receipt["source"] + ":" + path], cwd=root
        )
        assert hashlib.sha256(original).hexdigest() == row["pre_sha256"], path
with tarfile.open(base / "source-pair.tar") as archive:
    members = archive.getmembers()
    assert len(members) == 37
    for member in members:
        assert member.isfile() and not member.issym() and not member.islnk()
        relative = Path(member.name)
        assert not relative.is_absolute() and ".." not in relative.parts
        assert archive.extractfile(member).read() == (base / relative).read_bytes()
with tempfile.TemporaryDirectory(prefix="public93-patch-") as folder:
    scratch = Path(folder)
    for row in pairs:
        if row["pre_sha256"] is not None:
            target = scratch / row["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(base / "preimages" / row["path"], target)
    patch = str(base / "candidate.patch")
    for arguments in [["--check"], [], ["--reverse", "--check"], ["--reverse"]]:
        subprocess.run(
            ["git", "apply", *arguments, patch], cwd=scratch, check=True, capture_output=True
        )
        if arguments == []:
            for row in pairs:
                assert digest(scratch / row["path"]) == row["post_sha256"]
    for row in pairs:
        restored = scratch / row["path"]
        assert (
            (not restored.exists())
            if row["pre_sha256"] is None
            else digest(restored) == row["pre_sha256"]
        )
print("PUBLIC93_SOURCE_PAIRS_19_ARCHIVE_37_PATCH_ROUNDTRIP_PASS")
