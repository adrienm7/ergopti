"""Outside-only unchanged60s observation; no assertion/timeout weakening."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,signal
base=Path(__file__).resolve().parent;label=sys.argv[1];root=base/('source-env1' if label=='env1' else 'source-candidate' if label=='candidate' else 'source');work=base/label;work.mkdir(mode=0o700);tmp=work/'tmp';tmp.mkdir(mode=0o700)
env=os.environ.copy();env['TMPDIR']=str(tmp)
if label=='env1':env['PYTHONDONTWRITEBYTECODE']='1'
else:env.pop('PYTHONDONTWRITEBYTECODE',None)
start=time.monotonic();error=None;status=None
with (work/'stdout').open('wb') as out,(work/'stderr').open('wb') as err:
 process=subprocess.Popen([sys.executable,str(base/'passive_timing.py'),str(root),str(work/'timing.jsonl')],cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
 try:status=process.wait(timeout=60)
 except subprocess.TimeoutExpired as failure:
  error='OUTER_UNCHANGED_60000MS_TIMEOUT';os.killpg(process.pid,signal.SIGKILL);status=process.wait(timeout=10)
receipt={'label':label,'pid':process.pid,'elapsed':time.monotonic()-start,'status':status,'error':error,'timeout_seconds':60,'python_executable':sys.executable,'python_version':sys.version,'python_image_sha256':hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),'pythondontwritebytecode':env.get('PYTHONDONTWRITEBYTECODE'),'tmpdir':str(tmp),'stdout_sha256':hashlib.sha256((work/'stdout').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((work/'stderr').read_bytes()).hexdigest(),'qualification':'PORTABLE_POSIX_ONLY_NO_MAC_NATIVE_CREDIT'}
(work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,sort_keys=True));sys.exit(0 if status==0 and error is None else 1)
