[CmdletBinding()]
param(
	[Parameter(Mandatory = $true)][string]$RootPath,
	[Parameter(Mandatory = $true)][string]$RootIdentity,
	[Parameter(Mandatory = $true)][string]$Ticket,
	[Parameter(Mandatory = $true)][string]$StageIdentity,
	[Parameter(Mandatory = $true)][string]$ManifestHash,
	[Parameter(Mandatory = $true)][string]$DescriptorIdentity,
	[Parameter(Mandatory = $true)][string]$DescriptorHash,
	[Parameter(Mandatory = $true)][string]$ManagedBridgePath,
	[Parameter(Mandatory = $true)][string]$ManagedBridgeHash,
	[Parameter(Mandatory = $true)][string]$FilesHelperPath,
	[Parameter(Mandatory = $true)][string]$FilesHelperHash,
	[Parameter(Mandatory = $true)][string]$PublicationHelperPath,
	[Parameter(Mandatory = $true)][string]$PublicationHelperHash,
	[Parameter(Mandatory = $true)][string]$ProducerHelperPath,
	[Parameter(Mandatory = $true)][string]$ProducerHelperHash,
	[Parameter(Mandatory = $true)][string]$NativeModulePath,
	[Parameter(Mandatory = $true)][string]$NativeModuleHash,
	[Parameter(Mandatory = $true)][string]$GuardianPath,
	[Parameter(Mandatory = $true)][string]$GuardianHash,
	[Parameter(Mandatory = $true)][string]$LauncherPath,
	[Parameter(Mandatory = $true)][string]$LauncherHash,
	[Parameter(Mandatory = $true)][uint64]$MappingHandle,
	[Parameter(Mandatory = $true)][uint64]$ReadyHandle,
	[Parameter(Mandatory = $true)][uint64]$ReleaseHandle,
	[Parameter(Mandatory = $true)][uint64]$ParentHandle,
	[ValidateSet('published', 'intake')][string]$Mode = 'published',
	[string]$CataloguePath = '', [string]$AssetId = '',
	[long]$MaxExpandedBytes = 0, [int]$MaxEntries = 0,
	[long]$OriginalDeadline = 0, [int]$PollMilliseconds = 0
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$sourceOwner = [ordered]@{ streams = [Collections.Generic.List[object]]::new(); assembly = $null;
	root = $null; offer = ''; phase = 'acquiring'; first_error = ''; acquisition = [ordered]@{
		root_handles = $null; stage_handle = [IntPtr]::Zero; streams = $null; directory_handles = $null;
		phase = 'acquiring'; first_error = '' } }

function Open-PinnedSourceCode([string]$Path, [string]$Hash) {
	if ($Path -notmatch '\A[A-Za-z]:\\' -or $Path.Contains([char]0) -or
		$Path.Contains("`r") -or $Path.Contains("`n") -or $Hash -notmatch '\A[0-9a-f]{64}\z') {
		throw 'Source code pin requires an absolute native path and exact digest.'
	}
	# Record the stream before hashing/loading. FileShare.Read excludes both
	# writers and rename/replacement throughout the later helper execution.
	$stream = [IO.FileStream]::new($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
	$sourceOwner.streams.Add($stream)
	$hasher = [Security.Cryptography.SHA256]::Create()
	try { $actual = [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
	finally { $hasher.Dispose(); $stream.Position = 0 }
	if ($actual -ne $Hash) { throw 'The exact source helper stream differs from its captured code pin.' }
	return $stream
}

try {
	if ($PSVersionTable.PSVersion.Major -ne 5 -or [IntPtr]::Size -ne 8) { throw 'The verified source worker requires Windows PowerShell 5.1 x64.' }
	# This is child-only: inherited PowerShell7 module directories cannot control
	# the native PS5 Security/ExtendedTypeData perimeter required by this helper.
	$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
	if ('Ergopti.Ollama.SourceProducerNative' -as [type]) { throw 'A preloaded managed channel producer cannot be adopted.' }
	[void](Open-PinnedSourceCode $ManagedBridgePath $ManagedBridgeHash)
	$sourceOwner.assembly = [Reflection.Assembly]::LoadFrom($ManagedBridgePath)
	if (-not [StringComparer]::OrdinalIgnoreCase.Equals($sourceOwner.assembly.Location, [IO.Path]::GetFullPath($ManagedBridgePath))) {
		throw 'The managed source bridge resolved to a foreign assembly.'
	}
	if ($Mode -eq 'published') {
		[Ergopti.Ollama.SourceProducerNative]::AdmitInherited([IntPtr]::new([long]$MappingHandle),
			[IntPtr]::new([long]$ReadyHandle), [IntPtr]::new([long]$ReleaseHandle), [IntPtr]::new([long]$ParentHandle))
	} elseif ($MappingHandle -ne 0 -or $ReadyHandle -ne 0 -or $ReleaseHandle -ne 0 -or $ParentHandle -ne 0) {
		throw 'Late intake source cannot adopt inherited caller channel handles.'
	}
	# No Add-Type/compiler/utility child occurs before the channel flags are
	# cleared. Every dot-sourced script remains protected by its verified stream.
	[void](Open-PinnedSourceCode $FilesHelperPath $FilesHelperHash)
	[void](Open-PinnedSourceCode $PublicationHelperPath $PublicationHelperHash)
	[void](Open-PinnedSourceCode $ProducerHelperPath $ProducerHelperHash)
	# Dot-sourced library defaults run in this worker scope. Retain the exact
	# captured stage identity when its real parameter block binds.
	$sourceLibraryArguments = @{ StageIdentity = $StageIdentity; CataloguePath = $CataloguePath;
		AssetId = $AssetId; MaxExpandedBytes = $MaxExpandedBytes; MaxEntries = $MaxEntries }
	. $FilesHelperPath @sourceLibraryArguments
	. $PublicationHelperPath
	. $ProducerHelperPath
	Initialize-OllamaPublicationOwner
	Initialize-OllamaSourceProducer $sourceOwner.assembly
	if ($Mode -eq 'intake') {
		if ($OriginalDeadline -le 0 -or $PollMilliseconds -le 0) { throw 'Intake requires its original deadline and polling policy.' }
		[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false, $true)
		Initialize-OllamaIntakeSource
		$intakeArguments = @($RootPath, $CataloguePath, $ManifestHash, $AssetId, $Ticket,
			$MaxExpandedBytes, $MaxEntries, $NativeModulePath, $NativeModuleHash,
			$GuardianPath, $GuardianHash, $LauncherPath, $LauncherHash)
		$sourceOwner.offer = New-OllamaIntakeSource @intakeArguments
		$inventory = Get-OllamaIntakeInventory $sourceOwner.offer
		[Console]::Out.WriteLine(($inventory | ConvertTo-Json -Depth 12 -Compress))
		$intake = $script:OIA_Rows[$sourceOwner.offer]
		$commandPath = [IO.Path]::Combine($intake.directory_path, 'channel.json')
		while (-not [IO.File]::Exists($commandPath)) {
			if ([Ergopti.Ollama.SourceProducerNative]::Tick64() -ge [uint64]$OriginalDeadline) {
				throw 'Intake channel admission expired without a native handoff.'
			}
			[Threading.Thread]::Sleep($PollMilliseconds)
		}
		$commandStream = Open-OllamaReadFile $commandPath $true
		$sourceOwner.streams.Add($commandStream)
		if ($commandStream.Length -le 0 -or $commandStream.Length -gt 512) { throw 'Intake channel command length refused.' }
		$command = Read-OllamaJsonStream $commandStream
		$names = @($command.PSObject.Properties.Name)
		if ($names.Count -ne 7 -or @($names | Where-Object { $_ -notin @('channel', 'source_pid', 'source_creation', 'mapping', 'ready', 'release', 'parent') }).Count -ne 0 -or
			$command.source_pid -ne [Ergopti.Ollama.SourceProducerNative]::CurrentPid() -or
			$command.source_creation -cne [Ergopti.Ollama.SourceProducerNative]::CurrentCreation().ToString([Globalization.CultureInfo]::InvariantCulture)) {
			throw 'Intake channel command does not describe this exact live native source.'
		}
		foreach ($name in @('channel', 'mapping', 'ready', 'release', 'parent')) {
			if ($command.$name -isnot [string] -or $command.$name -notmatch '\A[1-9][0-9]{0,18}\z' -or [uint64]$command.$name -gt [long]::MaxValue) {
				throw 'Intake native channel scalar shape refused.'
			}
		}
		[Ergopti.Ollama.SourceProducerNative]::ExpectIntakeChannel([uint64]$command.channel)
		$MappingHandle = [uint64]$command.mapping; $ReadyHandle = [uint64]$command.ready
		$ReleaseHandle = [uint64]$command.release; $ParentHandle = [uint64]$command.parent
		[Ergopti.Ollama.SourceProducerNative]::AdmitInherited([IntPtr]::new([long]$MappingHandle),
			[IntPtr]::new([long]$ReadyHandle), [IntPtr]::new([long]$ReleaseHandle), [IntPtr]::new([long]$ParentHandle))
		$channelArguments = @($sourceOwner.offer, [IntPtr]::new([long]$MappingHandle), [IntPtr]::new([long]$ReadyHandle),
			[IntPtr]::new([long]$ReleaseHandle), [IntPtr]::new([long]$ParentHandle))
		Send-OllamaIntakeOffer @channelArguments
		$prepared = Prepare-OllamaIntakeAfterNativeSeal $sourceOwner.offer ([IntPtr]::new([long]$ReleaseHandle)) ([IntPtr]::new([long]$ParentHandle))
		Close-OllamaIntakeScratch $sourceOwner.offer $commandStream
		$prepared['ok'] = $true
		$prepared['phase'] = 'prepared'
		[Console]::Out.WriteLine(($prepared | ConvertTo-Json -Depth 12 -Compress))
		exit 0
	}
	$sourceOwner.root = Open-OllamaManagedRoot $RootPath $false $sourceOwner.acquisition
	if ($sourceOwner.root.identity -ne $RootIdentity) { throw 'The source worker opened a foreign root identity.' }
	$publication = Open-OllamaPublishedSourceOwner $sourceOwner.root $Ticket $StageIdentity $ManifestHash $DescriptorIdentity $DescriptorHash $sourceOwner.acquisition
	$sourceOwner.offer = New-OllamaVerifiedSourceOffer $publication $NativeModulePath $NativeModuleHash $GuardianPath $GuardianHash $LauncherPath $LauncherHash
	$offerArguments = @{ Id = $sourceOwner.offer; Mapping = [IntPtr]::new([long]$MappingHandle);
		Ready = [IntPtr]::new([long]$ReadyHandle); Release = [IntPtr]::new([long]$ReleaseHandle);
		Parent = [IntPtr]::new([long]$ParentHandle) }
	Send-OllamaVerifiedSourceOffer @offerArguments
	$sourceOwner.phase = 'offered'
	[void](Wait-OllamaSourceHandoff $sourceOwner.offer ([IntPtr]::new([long]$ReleaseHandle)) ([IntPtr]::new([long]$ParentHandle)))
	$sourceOwner.phase = 'handoff-observed'
	# This exact helper process owns the originals, native module and any partial
	# acquisition. Kernel terminal retires its copies; guardian copies remain
	# independently protected until actual daemon job zero. No Boolean release.
	exit 0
} catch {
	if ($sourceOwner.first_error -eq '') { $sourceOwner.first_error = $_.Exception.Message }
	$sourceOwner.phase = 'refused'
	[Console]::Error.WriteLine('Verified source worker refused: ' + $sourceOwner.first_error)
	# There are no source-side async sends/workers. Before native READY the daemon
	# cannot activate; after a successful handoff the parent/guardian own copied
	# leases. Preserve failed source acquisition in the retained exact source job
	# until its natural terminal, which parent verifies before channel retirement.
	exit 1
}
