# Inactive Wrap continuation preparations

Base: `88909124461a3dbdfe5b745453fe50333eb64adc`. No repository checkout, index, references, generators or CI were changed by this preparation. All source publication remains with the parent coordinator. The user's rapid partial merge request stopped further boot and native validation work.

## Reconstructible source packets

Apply only after independently reviewing exact preimages and prerequisite receipts. Prepared patches are not integrated features.

- `full-group1-wrap-refusal-packet`: five paths, patch SHA `cce6479e560382a9407d986786ced8b291b81b70b9de828c5a493cca453668da`. Depends on the original inactive Wrap packet `f962e0c00565bfc2b4a2f9872cc41d59fa0b8cd402fb04dd07cb43c1444b9c5a` and its shared section/template publication. Shared detached field claim, actual native mutation callbacks and acknowledged input view. Independent review remains pending.
- `full-group1-wrap-refusal-test-v2-packet`: one test-only successor, SHA `781bcfe0de268b1a400a05042040e79879c6fda6d4001866f69d904bda9ffa0a`. Moves the existing exact nested receipt assertion outside protected mutation/save callbacks; the predicate and 15 original cases remain. Wrong nested literal true mutation produces 13 passed / 2 failed.
- `full-group1-shape-forwarder-packet`: two sources and one regression module, SHA `03630024f875feabd4bcb94af1dce628b3f537bce5756cd61cd837f689b4bd51`. Shared cleanup scanner decodes once with the source-bound shape receipt, passing it as optional third argument; Mac cleanup forwards it. Historical two-argument readers retain behavior. Independently review this narrow API separately.
- `full-group1-wrap-persistence-packet`: four paths, SHA `6d7b11be980c98e1796b29b2e96d724d7cf8d20b79896f62972fe61ceaa04172`. Depends on the refusal and forwarding prerequisites plus root-owned canonical schema publication. BLOCKED and unapproved: see the concrete metadata failure below.

## Verified local behavior

Lua 5.4 over repository macOS native-port stubs executed the actual menu callbacks, preference parser, writer and Linux host filesystem. It did not run Hammerspoon/AppKit or physical macOS input.

- Actual Wrap callbacks: 88 passed / 0 failed. Seven actions cover false, nil, truthy and throwing persistence refusal, strict retries, nested sibling callbacks, rebuilt-menu ownership and replacement successors. Single original native provider inverse: 41 passed / 47 failed; restored provider: 88 passed / 0 failed.
- Shared claim suite: 15 passed / 0 failed; original Unicode menu suite: 9 passed / 0 failed. Original prepared test prefix remains exact except one new pure dependency cache owner; all original assertions remain.
- Actual-file preference suite: 12 passed / 0 failed. It restores quoted Unicode/dot/quote symbol keys, ordered custom pairs and nonempty future metadata; retains obsolete neighbors; separates source-bound empty maps/arrays; refuses five obsolete collisions without source or receipt changes; refuses a changed physical source and retries after exact adoption.
- Shape forwarding: 3 passed / 0 failed. Existing cleanup: 57 / 0; existing nested array roundtrip: 15 / 0; sparse preferences: 3 / 0; existing delay roundtrip: 2 / 0; existing preference output ownership: 2 / 0.
- Initial actual-file old source control fails: save acknowledges true and load says ok, but both Wrap preference fields return nil. The same independent physical probe succeeds after the preliminary mapping.
- All 13 frozen postimage Lua files contain LF only and end with LF. Canonical formatter does not own Lua indentation. No native AHK bytes were changed by these new packets.

## Concrete source blocker

`evidence/physical-wrap-future-empty-kind-probe.lua` fails on the proposed persistence source (exit 1). Starting from a real physical source with `future=[]` both beside Wrap fields and inside a custom pair, an ordinary built-in symbol toggle writes both future values as `{}`. The existing leaf-row clone and writer lose the source-bound empty-array receipt when replacing the enclosing inline table. This is a source durability defect, not a device limitation. Preserve this independent failing probe; do not derive its expected kind from the implementation or approve the packet until exact metadata kind is preserved or publication safely refuses.

## Remaining source and validation work

1. Correct the empty-array metadata durability defect through actual owning writer/clone interfaces while preserving exact future source receipts and outdated entries. Re-run the retained physical failure and all affected refusal controls.
2. Publish canonical schema for `shortcuts.wrap_symbols.states` (strict Boolean dictionary) and `.custom` (ordered Unicode scalar left/right records with additional future metadata). The shared location policy is in the packet. Existing Windows `wrap_symbols.toml` remains its native authority; no duplicate compatibility path was added. Linux has no existing config namespace or custom-pair persistence consumer. Do not claim either has the new Mac persistence behavior.
3. Independently review all source packets and register shared tests through actual owning test manifests/runners as required. Full verify-change selection is retained in evidence and requests JS, macOS and Linux units/E2E plus Windows unit/meta qualification. Those full gates were not executed for these inactive preparations.
4. Prove actual eager `ui.menu.start` getter wiring after physical reload and during refusal. The source now delegates to the shared acknowledged view, but the eager boot fixture and native boot were not exercised; no new boot fixture was added before the user's stop request.
5. Compose original Wrap shared sections/templates and generated artifacts through their real owners, preserving the independent original corpus. The isolated focused menu input is the exact historical owner-generated Wrap manifest, not a newly regenerated or integrated artifact. Current-source manifest generators were not run for this tranche.
6. Compose Guidance only after the current Delay and Wrap dependencies are implemented, reviewed and validated. The original inactive nine-path Guidance packet `6a60a0efb648d47507782fc794f11f94c1be3686a58faec12cdfaf0965b5e581` remains preserved elsewhere; it has not been recomposed on these unfinished successors.
7. Native Windows/macOS CI, packaging, installation and physical menu/input checks remain unexecuted. User-device checks cannot substitute for the feasible source and CI work above. TODO 54/81 are not complete and must not be deleted on this evidence.

## Reproduce

Activate the prepared container tooling with `source /workspace/tooling/activate-ergopti.sh`. Reconstruct a source archive from the exact base and required original packet, apply the bounded source packets only in that isolated archive, and retain the failed metadata probe. `evidence/focused.lua` takes source root, OS name and actual module name. For example, `lua5.4 evidence/focused.lua /path/to/archive macos tests.unit.ui.menu.test_wrap_preferences_round_trip`. Physical probes take the source root as their sole argument. Logs and per-path pre/post hashes accompany the patches; native qualification is explicitly absent.
