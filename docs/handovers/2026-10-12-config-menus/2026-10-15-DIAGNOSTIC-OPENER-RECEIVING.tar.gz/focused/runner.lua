local root = "/workspace/.ergopti-cloud/config-healthcheck-opener-view/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local helpers = require("tests.helpers")
if arg[1] then helpers.set_only_filter(arg[1]) end
for _, module in ipairs({ "test_healthcheck_report_issue", "test_healthcheck_bridge_actions", "test_error_dialog_bridge", "test_update_check_bridge" }) do require("tests.unit.ui." .. module) end
dofile(root .. "macos/tests/unit/modules/updater/test_update_check_session.lua")
local result = helpers.get_results()
print(require("json").encode(result))
os.exit(result.failed == 0 and 0 or 1)
