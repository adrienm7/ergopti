-- Uses the actual registered module selector; it never applies a case filter.
local mode = assert(arg[1], "candidate or original mode required")
assert(mode == "candidate" or mode == "original")
assert(#arg == 1, "no partial subject filter permitted")
arg = { "--only=tests.unit.ui.menu.test_configured_shortcut_labels" }
if mode == "original" then
 table.insert(package.searchers, 1, function(name)
  if name ~= "ui.menu.menu_shortcuts" then return "\nNo genuine original provider override" end
  local file = "/workspace/ergopti-delivery/group1-complete-resume-20261007/menu-private-peer-oct10/macos-script-action-dead-boundary-genuine-export-source-successor-20261010/preimages/static/ergopti_plus/macos/ui/menu/menu_shortcuts.lua"
  return assert(loadfile(file)), file
 end)
end
dofile("/workspace/ergopti/static/ergopti_plus/macos/tests/run.lua")
