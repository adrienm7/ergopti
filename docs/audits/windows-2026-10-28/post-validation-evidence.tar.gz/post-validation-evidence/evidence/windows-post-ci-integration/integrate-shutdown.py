import subprocess,json,datetime,re,os
from pathlib import Path
from zoneinfo import ZoneInfo
root=Path('/workspace/ergopti-windows-integration');out=Path('/workspace/scratch/windows-post-ci-integration')
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
def now():return datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()
assert git('rev-parse','HEAD')=='3b33225970415794481337525e4cc23cb15f2922' and not git('status','--porcelain')
items=[('program-fixture','5ce0e246954ef3d150d9eb19a720fa9b2b0f4e6d','--only=exact native shutdown and reload preserve refusal ownership',1),('registry-compensation','c8e977a8fb138082967a02a2531bf771fcbc6326','--list=Z:'+str(Path('/workspace/scratch/windows-final-shutdown-proof/selected17.txt')).replace('/',chr(92)),17)]
quick=json.loads(Path('/workspace/scratch/windows-changelog-qualified-delivery/qualification.json').read_text())['stages'];receipts=[]
env=dict(os.environ,WINEPREFIX='/workspace/toolchain/wine-r3-metrics-owned',WINEPATH=r'Z:\workspace\toolchain\node-v22.22.2-win-x64;Z:\workspace\toolchain\mingit-2.56.0.4-x64\cmd')
for name,sha,selection,count in items:
 p=out/name;p.mkdir(exist_ok=True);assert not git('status','--porcelain')
 with (p/'cherry-pick.log').open('w') as log:subprocess.run(['git','cherry-pick','--no-commit',sha],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 checks=[]
 for q in quick:
  if q['name'].startswith('native-') or q['name']=='full-js':continue
  with (p/(q['name']+'.log')).open('w') as log:r=subprocess.run(q['argv'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  checks.append(dict(name=q['name'],argv=q['argv'],exit_code=r.returncode));(p/'quick-gates.json').write_text(json.dumps(checks,indent=2)+'\n');assert r.returncode==0,q['name']
 native=None
 if selection:
  selection=selection.replace(chr(92)+chr(92),chr(92))
  argv=['timeout','--kill-after=5s','900s','xvfb-run','-a','bash','tools/test/run-ahk-under-wine.sh','--ahk','/workspace/toolchain/ahk/AutoHotkey64.exe','--runner','run_all.ahk','--results',str(p/'native.tap'),'--',selection]
  with (p/'native.log').open('w') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  text=(p/'native.tap').read_text(encoding='utf-8-sig',errors='replace') if (p/'native.tap').exists() else '';plan=re.search(r'^1\.\.(\d+)',text,re.M)
  native=dict(argv=argv,exit_code=r.returncode,planned=int(plan.group(1)) if plan else 0,passed=len(re.findall(r'^ok \d+ - (?!.* # SKIP )',text,re.M)),failed=re.findall(r'^not ok .*',text,re.M),skipped=re.findall(r'^ok .* # SKIP .*',text,re.M),native_windows_qualified=False)
  (p/'native.json').write_text(json.dumps(native,indent=2)+'\n');assert r.returncode==0 and native['passed']==native['planned']==count and not native['failed'] and not native['skipped'],native
 else:
  subprocess.run(['node','tools/test/test-recommended-defaults-rule.cjs'],cwd=root,check=True)
 with (p/'commit.log').open('w') as log:subprocess.run(['git','commit','-C',sha],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 row=dict(label=name,original_sha=sha,integrated_sha=git('rev-parse','HEAD'),quick_gates=checks,native_fast_integration=native,normal_hooks=True,at_paris=now());receipts.append(row);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,row['integrated_sha'],flush=True)
assert not git('status','--porcelain')
(out/'shutdown-completed.json').write_text(json.dumps(dict(head=git('rev-parse','HEAD'),at_paris=now()),indent=2)+'\n')
