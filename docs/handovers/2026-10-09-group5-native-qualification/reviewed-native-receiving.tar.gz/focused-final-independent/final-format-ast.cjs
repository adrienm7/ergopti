const fs = require('node:fs'), assert=require('node:assert/strict');
const acorn=require('/workspace/ergopti/node_modules/acorn/dist/acorn.js');
const old='/workspace/ergopti-group5-work/publications/lease-g6-focused-successor-uly1hlr5/postimages';
const current='/workspace/ergopti-group5-work/publications/lease-g6-focused-final-w2y63rs0/postimages';
function parse(base,path){return acorn.parse(fs.readFileSync(base+'/'+path,'utf8'),{ecmaVersion:'latest',sourceType:'script'});}
function norm(node){const clean=JSON.parse(JSON.stringify(node,(k,v)=>['start','end','raw'].includes(k)?undefined:v));
 function keys(n){if(!n||typeof n!=='object')return;if(n.type==='Property'&&!n.computed&&!n.method&&!n.shorthand&&n.key.type==='Literal'&&typeof n.key.value==='string'&&/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(n.key.value)){n.key={type:'Identifier',name:n.key.value};}for(const v of Object.values(n))if(v&&typeof v==='object'){if(Array.isArray(v))v.forEach(keys);else keys(v);}}
 keys(clean);return clean;}
const results=[];
for(const path of ['tools/test/ci-full-default.cjs','tools/test/test-ci-full-default.cjs','tools/test/test-ci-pipeline-wiring.cjs']){
 assert.deepEqual(norm(parse(old,path)),norm(parse(current,path)),path);results.push({path,wholeASTequal:true});
}
const path='tools/test/test-macos-dev-qualification-deferral.cjs';const before=parse(old,path),after=parse(current,path);
const blocks=after.body.filter(n=>n.type==='BlockStatement'&&n.body.some(s=>s.type==='VariableDeclaration'&&s.declarations.some(d=>d.id.name==='focusedLeaseResults')));assert.equal(blocks.length,1);
after.body=after.body.flatMap(n=>n===blocks[0]?n.body:[n]);assert.deepEqual(norm(before),norm(after));results.push({path,wholeASTequalAfterFlatteningOneExplicitFrozenControlBlock:true});
const receiver='tools/diagnostics/lease_xctest_evidence.cjs';let a=parse(old,receiver),b=parse(current,receiver);
const remove=new Set(['evaluate','readBoundedRegular']);a.body=a.body.filter(n=>!(n.type==='FunctionDeclaration'&&remove.has(n.id.name)));b.body=b.body.filter(n=>!(n.type==='FunctionDeclaration'&&remove.has(n.id.name)));assert.deepEqual(norm(a),norm(b));results.push({path:receiver,wholeASTequalExceptTwoReviewedFunctionalFunctions:[...remove]});
const tests='tools/test/test-lease-xctest-evidence.cjs';a=parse(old,tests);b=parse(current,tests);b.body=b.body.slice(0,a.body.length);assert.deepEqual(norm(a),norm(b));results.push({path:tests,entireOriginal44CorpusTestASTPrefixWhole:true});
console.log(JSON.stringify(results,null,2));
