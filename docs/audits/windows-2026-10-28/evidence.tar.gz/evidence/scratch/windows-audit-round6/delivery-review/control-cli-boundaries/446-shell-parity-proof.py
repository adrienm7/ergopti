from pathlib import Path
import os,sys,subprocess,tempfile,time,json,shutil,datetime
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-windows-r7-installer');p=Path('/workspace/scratch/windows-audit-round6/delivery-review/control-cli-boundaries');spec=json.loads((w/'static/ergopti_plus/_shared/modules/control/driver_control.json').read_text());root=Path(tempfile.mkdtemp(prefix='ergopti-control-sh-parity-'));rows=[]
try:
 for mode in ['healthy','boolean-schema','broken-json']:
  base=root/mode;folder=base/'ergopti_plus/control';folder.mkdir(parents=True);ready=folder/'fixture-ready'
  child=subprocess.Popen([sys.executable,str(p/'shell-private-responder.py'),str(folder/spec['files']['request']),str(folder/spec['files']['result']),str(ready),mode],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   deadline=time.monotonic()+5
   while not ready.exists() and time.monotonic()<deadline:
    assert child.poll() is None,'owned responder exited before registering its signal'
    time.sleep(.01)
   assert ready.exists(),'owned signal responder must be ready'
   (folder/spec['files']['session']).write_text(json.dumps({'schema':spec['schema'],'driver':'linux','pid':child.pid,'token':'a'*spec['token_hex_length']},separators=(',',':'))+'\n')
   env=dict(os.environ,XDG_RUNTIME_DIR=str(base))
   result=subprocess.run(['sh',str(w/'tools/control/request_driver_reload.sh'),'3'],cwd=w,env=env,capture_output=True,text=True,timeout=10)
   rows.append({'case':mode,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'actual_native_signal_recipient':'owned private fixture process','completed':result.returncode==0})
   print(mode,result.returncode,result.stdout.strip(),flush=True)
  finally:
   child.terminate()
   try:child.communicate(timeout=3)
   except subprocess.TimeoutExpired:child.kill();child.communicate()
finally:
 shutil.rmtree(root)
 (p/'446-shell-parity-receipt.json').write_text(json.dumps({'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'scope':'Entire real shared macOS/Linux shell CLI on Linux, real private files and actual SIGUSR1 to owned fixture only. No real Ergopti driver, Mac execution or other-OS fix.','controls':rows},indent=2)+'\n')
assert len(rows)==3 and rows[0]['completed']
assert not any(r['completed'] for r in rows[1:]),'malformed result records must never report completion'
