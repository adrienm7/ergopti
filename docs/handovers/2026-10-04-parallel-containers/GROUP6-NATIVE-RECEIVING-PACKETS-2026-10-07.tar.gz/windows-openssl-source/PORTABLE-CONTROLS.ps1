# Scratch-only controls call actual pure C# helpers; no native TLS or DLL admission credit.
param([Parameter(Mandatory = $true)][string]$FragmentPath)
$ErrorActionPreference = 'Stop'
$Prefix = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
'@
Add-Type -TypeDefinition ($Prefix + "`n" + [IO.File]::ReadAllText($FragmentPath))
$script:Count = 0
function Require([bool]$Condition, [string]$Name) {
    if (-not $Condition) { throw $Name }
    $script:Count++
}
# Fixed peer-alert constants are independently specified OpenSSL3 SSL errors.
foreach ($Code in [uint32[]]@(0x0A000412, 0x0A000414, 0x0A000415, 0x0A000416, 0x0A000418)) {
    Require ([ErgoptiFixtureOpenSsl]::IsExpectedClientTrustRefusal($false, $Code)) 'Original untrusted phase must recognize an actual certificate alert.'
    Require (-not [ErgoptiFixtureOpenSsl]::IsExpectedClientTrustRefusal($true, $Code)) 'Trusted phase cannot conceal a certificate alert.'
}
foreach ($Code in [uint32[]]@(0, 0x0A000126, 0x0A000410, 0x04000418)) {
    Require (-not [ErgoptiFixtureOpenSsl]::IsExpectedClientTrustRefusal($false, $Code)) 'Non-certificate/native-library errors must remain unexpected.'
}
$Private = [byte[]]@(19, 37, 59)
Require ([ErgoptiFixtureOpenSsl]::ClearPrivateDer($Private)) 'Bounded private DER clearing must acknowledge.'
Require (($Private | Where-Object { $_ -ne 0 }).Count -eq 0) 'Observe actual private DER bytes after clearing.'
Require (-not [ErgoptiFixtureOpenSsl]::ClearPrivateDer($null)) 'Absent DER cannot acknowledge a private-key handoff.'
$Oversized = [byte[]]::new(65537)
$Oversized[0] = 91; $Oversized[65536] = 93
Require (-not [ErgoptiFixtureOpenSsl]::ClearPrivateDer($Oversized)) 'Oversized DER remains rejected.'
Require (($Oversized | Where-Object { $_ -ne 0 }).Count -eq 0) 'Rejection still clears every exported private byte.'
# Independent minimal PE32+ metadata vector; never loaded as a library.
function Put16([byte[]]$Bytes, [int]$Offset, [uint16]$Value) {
    [Buffer]::BlockCopy([BitConverter]::GetBytes($Value), 0, $Bytes, $Offset, 2)
}
function Put32([byte[]]$Bytes, [int]$Offset, [uint32]$Value) {
    [Buffer]::BlockCopy([BitConverter]::GetBytes($Value), 0, $Bytes, $Offset, 4)
}
$Image = [byte[]]::new(1024)
$Image[0] = 0x4D; $Image[1] = 0x5A
Put32 $Image 60 128; Put32 $Image 128 0x4550
Put16 $Image 132 0x8664; Put16 $Image 134 1
Put16 $Image 148 240; Put16 $Image 150 0x2000
Put16 $Image 152 0x20B; Put32 $Image 260 16
Put32 $Image 272 0x1000; Put32 $Image 276 40
Put32 $Image 404 0x1000; Put32 $Image 408 512; Put32 $Image 412 512
Put32 $Image 524 0x1040
$Name = [Text.Encoding]::ASCII.GetBytes('KERNEL32.dll')
[Buffer]::BlockCopy($Name, 0, $Image, 576, $Name.Length)
$Names = @([ErgoptiFixtureOpenSsl]::InspectNativeImage($Image))
Require ($Names.Count -eq 1 -and $Names[0] -ceq 'KERNEL32.dll') 'Literal AMD64 metadata imports preserve exact names.'
foreach ($Mutation in @('dos', 'signature', 'x86', 'notdll', 'pe32', 'msys', 'path', 'noimports', 'unterminated')) {
    $Invalid = [byte[]]$Image.Clone()
    switch ($Mutation) {
        'dos' { $Invalid[0] = 0 }
        'signature' { $Invalid[128] = 0 }
        'x86' { Put16 $Invalid 132 0x14C }
        'notdll' { Put16 $Invalid 150 0 }
        'pe32' { Put16 $Invalid 152 0x10B }
        'msys' { [Array]::Clear($Invalid, 576, 128); $Text = [Text.Encoding]::ASCII.GetBytes('msys-2.0.dll'); [Buffer]::BlockCopy($Text, 0, $Invalid, 576, $Text.Length) }
        'path' { $Invalid[576] = 0x2F }
        'noimports' { Put32 $Invalid 272 0 }
        'unterminated' { Put32 $Invalid 276 20 }
    }
    $Rejected = $false
    try { $null = [ErgoptiFixtureOpenSsl]::InspectNativeImage($Invalid) }
    catch { $Rejected = $true }
    Require $Rejected ('Reject independent native metadata mutant: ' + $Mutation)
}
[Console]::Out.WriteLine(('PORTABLE_HELPERS_PASS assertions={0}; native_library_loads=0; native_tls_acceptance=UNRUN' -f $script:Count))
