#!/usr/bin/env bash
set -euo pipefail
source /workspace/.ergopti-cloud/activate.sh
source /workspace/.ergopti-cloud/activate-gtk.sh
exec /usr/bin/bwrap --unshare-user --unshare-pid --die-with-parent --new-session \
 --ro-bind / / --tmpfs /run \
 --ro-bind /usr/lib/x86_64-linux-gnu /run/gtk-system-libs \
 --ro-bind /usr/bin /run/gtk-system-bin \
 --ro-bind /workspace/.ergopti-cloud/gtk-overlay/libs /usr/lib/x86_64-linux-gnu \
 --ro-bind /workspace/.ergopti-cloud/gtk-overlay/bin /usr/bin \
 --bind /workspace /workspace --bind /tmp /tmp --proc /proc --dev /dev --tmpfs /dev/shm -- "$@"
