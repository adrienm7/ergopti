"""Replay physical canonical discovery order against isolated source subjects."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import types
import unittest

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')
parser = argparse.ArgumentParser()
parser.add_argument('subject', choices=('preimage', 'candidate'))
options = parser.parse_args()
REL = 'tools/test/macos_native_http_receiving_facts_test.py'
module = types.ModuleType('isolated_actual_canonical_order')
module.__file__ = str(ROOT / REL)
exec(compile((BASE / options.subject / REL).read_bytes(), str(ROOT / REL), 'exec'), module.__dict__)
spec = importlib.util.spec_from_file_location('isolated_wire_for_canonical_order', ROOT / 'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py')
wire = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wire)
module.WIRE = wire
base_type = wire.WireFixture
before_keys = tuple(base_type.__dict__)
before_new = base_type.__new__
suite = unittest.defaultTestLoader.loadTestsFromModule(module)
result = unittest.TextTestRunner(verbosity=2).run(suite)
facts = {'subject': options.subject, 'discovery': 'actual unittest.defaultTestLoader.loadTestsFromModule alphabetical class ordering',
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped),
    'original_type_restored': wire.WireFixture is base_type,
    'original_type_dictionary_keys_exact': tuple(base_type.__dict__) == before_keys,
    'original_allocator_identity_exact': base_type.__new__ is before_new,
    'all_guard_outer_children_reaped': all(value['all_exact_outer_children_reaped'] for value in module.NATIVE_GUARD_CLEANUP),
    'qualification': 'PORTABLE_SOFTWARE_ONLY_NATIVE_ACK_SECURITY_MODELED'}
print(json.dumps(facts, sort_keys=True))
assert result.testsRun == 103
assert facts['all_guard_outer_children_reaped']
if options.subject == 'candidate':
    assert facts['original_type_restored'] and facts['original_type_dictionary_keys_exact'] and facts['original_allocator_identity_exact']
sys.exit(0 if result.wasSuccessful() else 1)
