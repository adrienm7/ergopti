# Independent Linux menu certification correction review

Verdict: CLEAR. Frozen single-file patch SHA256 `40d562e736f13f4e7a4fffa65de1afab8bafe6a3a809b3dd52173151e363bcb2`.

The fixture explicitly supplies empty keys and hold options containing none. Expected native tap/absent hold captions are handwritten from that controlled input, not extracted from the implementation or observed menu. Only the expected formatted label is added to the existing all-row certification comparison. Unknown caption getters fail an added independent string assertion. Every old predicate, row-type declaration, visibility branch, floor and missing-row assertion is unchanged: removing exactly the two new blocks produces the complete original file bytes.

Independent focused module: Lua5.4 5 passed/0 failed; LuaJIT 5/0. Exact original fixture remains 4/1. Independently replacing the actual native hold-caption getter with `return 123` leaves the certification module red, 4/1. No root files, index, refs or suite artifacts were mutated. The independent isolated head review source was restored after these controls.

This correction covers the existing head-only fixture. The forthcoming delay declaration will need a separately authored expected delay caption based on this fixture's explicit empty key state; unknown new getters must remain strict rather than exempted. Root owns the full failed Linux-gate rerun and covering format/JS checks.
