# Exact final-fixture causal join

This separate supplement runs the exact final CI-capable test source 2340 against the literal published producer c080, then restores reviewed producer ce210 and reruns identical children. Neither source assertions nor fixture code were edited. All eight processes run the complete owning module from a separate external source capture and receive independently created TMPDIR and TEMP roots. Each naturally terminates and its owned root is empty and removed before the next process starts.

The exact test SHA256 is `2340d5e638fbf0660839991d3f96de74d55908e805c53028f5b3e9552d276658`. The complete original 49 prefix remains byte-identical at 38,693 bytes, SHA256 `7538539f52f671d0bf9503fabede610fedfafd45fe85b44cc902898b9369ff38`. The literal producer is `c0809fe78b188fa84afa2cba16bf557b081131a9d43d1f28b754881131ccfdb4`; restored producer is `ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768`.

| Producer | POSIX mode | Runtime | Passed | Failed | Exit | Added subjects executed | Original optional unavailable |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| literal | available | lua | 55 | 28 | 1 | 34 | 0 |
| literal | global-absent | lua | 54 | 28 | 1 | 34 | 1 |
| literal | available | luajit | 55 | 28 | 1 | 34 | 0 |
| literal | global-absent | luajit | 54 | 28 | 1 | 34 | 1 |
| restored | available | lua | 83 | 0 | 0 | 34 | 0 |
| restored | global-absent | lua | 82 | 0 | 0 | 34 | 1 |
| restored | available | luajit | 83 | 0 | 0 | 34 | 0 |
| restored | global-absent | luajit | 82 | 0 | 0 | 34 | 1 |

All counts above are observed terminal results. The exact 28 literal failed subject names match the earlier D146 reference on all four literal children; the preserved reference receipt is included. The literal children actually fail runtime expectations, rather than merely failing a subject-count guard. All 34 topology subjects execute in each child and all original prefix subjects that are available remain passing. Global no-POSIX mode has 82 executed subjects and exactly one preserved original optional integration subject UNRUN: `file_watchers subsecond polling: detects same-second edits with installed posix`. It is not reported as 83 global-no-POSIX successes.

The same source 2340 fixture supplies an explicitly controlled, real-luv-backed scan/stat port when lua-posix is absent. That is fixture portability, not an assertion that the missing POSIX library executed. Existing explicit s.no_posix cases still remove the injected port and use actual production native-stat/checked-shell branches. Native filesystem operations, native handles and their private cleanup remain real; selected source-boundary faults, callback replay, generation reentry and debounce clock advancement remain controlled models.

`exact-causal-matrix.json` and per-child statuses record exact commands, source/test hashes, temporary environment overrides, names, failures, child exit codes and stdout/stderr hashes. `receiving-receipt.json` independently rechecks all eight children and original-prefix passing names. This supplement does not repeat the 11 individual safeguard withdrawals from the original packet and does not promote early old-producer failures into specific injected-fault causal proof.

`runner.lua` and `run-exact-causal.py` target the external source root in `/workspace/.ergopti-cloud/resume-personal-topology-exact-causal`; recovery elsewhere requires adjusting that path. Dependencies are identified by the Git baseline b666a22f72cf3b27e55bef08720f7064348d1d40 and the 2,361-file `source-manifest.json`. Recover the Linux/shared tracked files from Git, validate the manifest, and overlay only the declared producer/test images. The duplicate captured source tree is omitted; all nonowned files are checked unchanged, with no missing or extra files.

Both prior archives are independently rehashed and remain byte-identical: original topology packet ef732a0a888d5f7c5724f9e6b42e3c5b25286b815e60ec28fdd992a3cb2d37a3 and portability supplement 0bf4806c00308c64bb08be84352ef77e10be3a95b3a10885507c4b619e034a4f. This separate compact packet adds the exact adopted-test-source causal join without overwriting their evidence.

No canonical checkout, CI workflow or expectation changed. The parent owns canonical full-gate, CI and publication receipts; this external owning-module result does not qualify packaging, installed daemon, actual keyboard expansion or device acceptance. SHA256SUMS covers every other member; the archive is reopened and all member bytes compared before handoff.
