# Windows metrics CI follow-up

The native meta job 121782282134 in run 40382326264 rejected the current sampler because its source guard required an inline native Suspend literal. The sampler already delegates to the real `KL_CaptureHeld`, which holds on either native Suspend or the independent metrics pause. No production change is needed.

The proposed single-file patch preserves the original case identity and every other recurring tick check. It verifies the sensor gate before privacy filtering, native reads and publication; requires the real helper to own both pause causes; and adds one executable four-state test of that real helper while restoring both states in `finally`.

The existing two genuine sampler child tests remain unchanged. They exercise public pause/resume, actual native sampling, the real log/append queue, event identities and native counter baselines. Their CI results should be received independently rather than inferred from a source check.

`source-review.json` records native red provenance and every local gate result. No AHK run has been launched in this worktree; no green runtime claim or commit is made. `change.patch` is exact owned output and can be reviewed or integrated once validation is available.
