from pathlib import Path
import subprocess,os,json,time,hashlib,datetime
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-picker-observer');d=Path('/workspace/scratch/oct28-cloner/uuid-atom/round3');paths=json.loads((d/'paths.json').read_text());subprocess.run(['git','add','--',*paths],cwd=w,check=True)
e=dict(os.environ);e.update(USER='agent',LOGNAME='agent',HUSKY='1');e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';rows=[]
commands=[('hook',['sh','.husky/pre-commit']),('registered',['node','tools/test/test-app-cloner-generated-literals.cjs']),('maximize',['node','tools/test/test-app-cloner-shortcut-maximize.cjs']),('dock',['node','tools/test/test-app-cloner-dock-url.cjs']),('falsegreen',['node','tools/test/find-false-greens.cjs']),('plan',['node','./tools/test/verify-change.cjs','--plan']),('source-encoding',['npm','run','-s','test:source-encoding']),('AHK-encoding',['npm','run','-s','test:ahk-encoding'])]
for label,cmd in commands:
 start=time.monotonic()
 with (d/('final-'+label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT)
 row={'label':label,'command':cmd,'actual_exit':r.returncode,'seconds':time.monotonic()-start,'log':str(d/('final-'+label+'.log'))};rows.append(row);print(json.dumps(row),flush=True)
 (d/'final-gates.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode:raise RuntimeError((d/('final-'+label+'.log')).read_text()[-2500:])
for shell in ['bash','zsh']:
 cmd=['python3','tools/test/lib/app-cloner-identity-probe.py','--resources','static/ergopti_plus/macos/apps/App Cloner.app/Contents/Resources','--shell','/usr/bin/'+shell,'--fixture',str(d/('final-'+shell)),'--palette','static/ergopti_plus/_shared/data/native_theme.toml'];start=time.monotonic()
 with (d/('final-'+shell+'.json')).open('w') as f:r=subprocess.run(cmd,cwd=w,env=e,stdout=f,stderr=subprocess.PIPE,text=True)
 assert r.returncode==0,(r.stderr,(d/('final-'+shell+'.json')).read_text())
 print(json.dumps({'identity_probe':shell,'actual_exit':r.returncode,'seconds':time.monotonic()-start}),flush=True)
patch=subprocess.check_output(['git','diff','--cached','--binary','--full-index','dc082b855e7906cea872ae863ee10c5632294fa9'],cwd=w);(d/'uuid-delta.patch').write_bytes(patch);print(json.dumps({'tree':subprocess.check_output(['git','write-tree'],cwd=w,text=True).strip(),'delta_sha256':hashlib.sha256(patch).hexdigest()}),flush=True)
