#!/usr/bin/env python3
"""Verify and archive the exact source/control payload; never execute tests."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    output = args.output.resolve()
    if output == root or root in output.parents:
        raise SystemExit("Archive output must be outside the immutable payload")
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    expected = {item["path"]: item for item in manifest["files"]}
    actual = {str(path.relative_to(root)): path for path in root.rglob("*") if path.is_file()}
    if set(actual) != set(expected) | {"MANIFEST.json"}:
        raise SystemExit("Unexpected or missing payload member")
    for relative, item in expected.items():
        path = actual[relative]
        if path.is_symlink() or path.stat().st_size != item["bytes"]:
            raise SystemExit("Payload type/length mismatch: " + relative)
        if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
            raise SystemExit("Payload hash mismatch: " + relative)
    if any(path.is_symlink() for path in root.rglob("*")):
        raise SystemExit("Symlinks are excluded")
    tar_data = io.BytesIO()
    with tarfile.open(fileobj=tar_data, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for relative, path in sorted(actual.items()):
            data = path.read_bytes()
            info = tarfile.TarInfo("linux-six-blockers/" + relative)
            info.size = len(data)
            info.mode = 0o755 if relative == "generate-archive.py" else 0o644
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(data))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as target:
        with gzip.GzipFile(filename="", fileobj=target, mode="wb", mtime=0) as compressed:
            compressed.write(tar_data.getvalue())
    print(json.dumps({"archive": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
                      "bytes": output.stat().st_size, "members": len(actual)}, sort_keys=True))


if __name__ == "__main__":
    main()
