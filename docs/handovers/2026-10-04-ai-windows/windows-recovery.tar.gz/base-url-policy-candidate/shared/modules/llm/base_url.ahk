﻿; _shared/modules/llm/base_url.ahk

; ==============================================================================
; MODULE: Remote Base URL Policy
; DESCRIPTION:
; Pure counterpart of the shared Lua base URL normalizer. Native callers retain
; provider defaults, transport scalar admission, exact source and child ownership.
; ==============================================================================

#Requires AutoHotkey v2.0





; ===============================================
; ===============================================
; ======= 1/ Address Admission ==================
; ===============================================
; ===============================================

/**
 * Normalizes an HTTP(S) base without logging the rejected input.
 * @param {Any} Raw Candidate address.
 * @param {String} Reason Privacy-safe refusal category.
 * @returns {String} Normalized address, or an empty refusal.
 */
RemoteBaseUrlNormalize(Raw, &Reason := "") {
	Reason := "base URL is empty"
	if !(Raw is String) || Raw == ""
		return ""
	if RegExMatch(Raw, "[\x00-\x20\x7F]") {
		Reason := "base URL contains whitespace or control characters"
		return ""
	}
	if InStr(Raw, "\") {
		Reason := "base URL contains a backslash"
		return ""
	}
	if !RegExMatch(Raw, "^([A-Za-z][A-Za-z0-9+.-]*)://([^/?#]+)(.*)$", &Found) {
		Reason := "base URL must include a scheme and host"
		return ""
	}
	Scheme := StrLower(Found[1]), Authority := Found[2], Suffix := Found[3]
	if !(Scheme == "http") && !(Scheme == "https") {
		Reason := "base URL scheme must be http or https"
		return ""
	}
	if InStr(Authority, "@") {
		Reason := "base URL authority must not contain userinfo"
		return ""
	}
	if InStr(Suffix, "?") || InStr(Suffix, "#") {
		Reason := "base URL must not contain a query or fragment"
		return ""
	}
	Host := Authority, Port := ""
	if SubStr(Authority, 1, 1) == "[" {
		Reason := "base URL host is invalid"
		if !RegExMatch(Authority, "^(\[[^\]]+\])(.*)$", &Bracket)
			return ""
		BracketValue := SubStr(Bracket[1], 2, -1)
		if BracketValue == "" || !RegExMatch(BracketValue, "^[A-Za-z0-9:.%\-]+$")
				|| !InStr(BracketValue, ":") || !RegExMatch(BracketValue, "[A-Fa-f0-9]")
			return ""
		Host := Bracket[1]
		if Bracket[2] != "" {
			if !RegExMatch(Bracket[2], "^:([0-9]+)$", &PortMatch) {
				Reason := "base URL port is invalid"
				return ""
			}
			Port := PortMatch[1]
		}
	} else {
		if RegExMatch(Authority, "^([^:]+):([0-9]+)$", &PortMatch)
			Host := PortMatch[1], Port := PortMatch[2]
		else if InStr(Authority, ":") {
			Reason := "base URL port is invalid"
			return ""
		}
		if !RegExMatch(Host, "^[A-Za-z0-9._-]+$") || !RegExMatch(Host, "[A-Za-z0-9]") {
			Reason := "base URL host is invalid"
			return ""
		}
	}
	if Port != "" {
		; Strip zeros only for bounded numeric admission. The original authority
		; keeps every character, including a valid decimal port's leading zeros.
		Significant := LTrim(Port, "0")
		if Significant == "" || StrLen(Significant) > 5 || Integer(Significant) > 65535 {
			Reason := "base URL port is outside 1..65535"
			return ""
		}
	}
	Reason := "ok"
	return RTrim(Scheme . "://" . Authority . Suffix, "/")
}
