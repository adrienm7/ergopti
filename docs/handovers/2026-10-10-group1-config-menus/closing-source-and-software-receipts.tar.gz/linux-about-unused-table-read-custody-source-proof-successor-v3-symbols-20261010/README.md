# Unused constructor direct reads: V3 source proposal

This distinct source-only successor addresses two blockers found before Root
received either earlier packet. The immutable V1 proposal incorrectly admitted
a fresh `_ENV` local, which changes Lua's implicit global resolution even when
its name has no later explicit read. V2 excludes that local, but value-only
punctuation checks still mistook Lua's valid string-argument calls for data:
`{ ctx "," }` invokes `ctx(",")`; the comma string is not a field separator.
The prior packets and actual independent blocked receipts remain preserved.

V3 keeps the explicit `_ENV` exclusion and requires the symbol token kind for
assignment, opening/closing braces, named-field assignment, field separators,
and the optional statement semicolon. The leading `local` must be an actual
identifier token. String-token values cannot act as punctuation, and neither
calls nor quoted delimiters qualify as inert direct reads.

The bounded predicate admits only one leading fresh local plain table containing
direct reads of the existing `separator_render`, `ManifestMenu`, or `ctx`
bindings, with no subsequent occurrence of the new variable in executable
tokens. Only that unused direct-data declaration is excluded from the proof's
view. The existing closed module export, sibling renderer custody, complete
guarded header algorithm, full public root, and original rendering/result
requirements remain mandatory. Unsupported expressions remain untouched and
must satisfy the existing whole protocol, so this change supplies no generic
Lua-expression or alternate-renderer credit.

Only two proof/control files differ from the exact Root preimages. The native
builder is pinned read-only as the third receiving input. The test target diff
only adds controls; its original positive assertion and all original negative
assertions remain byte-unchanged. V3 adds the actual implicit `_ENV` and valid
string-argument-call negatives alongside the existing alias/callback/shadow
controls and the independent direct-data positive shape.

This packet is prepared SOURCE only. Independent review, formatter, actual
manifest target, broader JS/native gates, generators and CI are UNRUN here.
Root owns adoption and runtime execution. No Root/index/ref/CI mutations were
performed; no earlier blocked packet is represented as validated.
