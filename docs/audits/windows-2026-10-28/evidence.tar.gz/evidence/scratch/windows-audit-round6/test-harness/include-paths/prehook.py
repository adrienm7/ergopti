from pathlib import Path
import subprocess,json,hashlib
root=Path('/workspace/ergopti-windows-r6-tests');packet=Path(__file__).parent
name='tools/test/test-ahk-test-coverage.cjs'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')=='ef682c5913409dd2df716352c577a9017a4eb83a'
assert not git('diff','--cached','--name-only')
assert git('diff','--name-only')==name
subprocess.run(['git','add','--',name],cwd=root,check=True)
subprocess.run(['sh','.husky/pre-commit'],cwd=root,check=True)
(packet/'candidate-hashes.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest()},indent=2)+'\n')
