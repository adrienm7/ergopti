﻿; Candidate-only native HMENU cases; include after the real production owners
; and the existing test framework. NOT EXECUTED. No renderer/Win32 substitutes.
#Requires AutoHotkey v2.0

_DMC_Label(MenuObj, Position) {
	Length := DllCall("GetMenuStringW", "ptr", MenuObj.Handle, "uint", Position,
		"ptr", 0, "int", 0, "uint", 0x400, "int")
	Assert(Length > 0, "native label must be present")
	Text := Buffer((Length + 1) * 2, 0)
	Read := DllCall("GetMenuStringW", "ptr", MenuObj.Handle, "uint", Position,
		"ptr", Text, "int", Length + 1, "uint", 0x400, "int")
	AssertEqual(Length, Read)
	return StrGet(Text, "UTF-16")
}

_DMC_State(MenuObj, Position) {
	State := DllCall("GetMenuState", "ptr", MenuObj.Handle, "uint", Position, "uint", 0x400, "uint")
	Assert(State != 0xFFFFFFFF, "native state must exist")
	return State
}

_DMC_Bitmap(MenuObj, Position) {
	; MENUITEMINFOW pointer layout, MIIM_BITMAP: actual AHK SetIcon writes hbmpItem.
	Info := Buffer(A_PtrSize == 8 ? 80 : 48, 0)
	NumPut("uint", Info.Size, "uint", 0x80, Info)
	Assert(DllCall("GetMenuItemInfoW", "ptr", MenuObj.Handle, "uint", Position,
		"int", true, "ptr", Info, "int") != 0, "native bitmap query must succeed")
	return NumGet(Info, A_PtrSize == 8 ? 72 : 44, "ptr")
}

_DMC_ReleaseHandle(Handle) {
	global _MenuDispatchCallbacks, _MenuDispatchTokens, _MenuDispatchLastFire
	global _MenuDispatchClickSequences, _MenuDispatchOwnerHandles
	Count := DllCall("GetMenuItemCount", "ptr", Handle, "int")
	loop Max(0, Count) {
		Index := A_Index - 1
		Child := DllCall("GetSubMenu", "ptr", Handle, "int", Index, "ptr")
		if Child
			_DMC_ReleaseHandle(Child)
		Id := DllCall("GetMenuItemID", "ptr", Handle, "int", Index, "uint")
		if Id && Id != 0xFFFFFFFF {
			for Table in [_MenuDispatchCallbacks, _MenuDispatchTokens, _MenuDispatchLastFire, _MenuDispatchClickSequences]
				if Table.Has(Id)
					Table.Delete(Id)
		}
	}
	if _MenuDispatchOwnerHandles.Has(Handle)
		_MenuDispatchOwnerHandles.Delete(Handle)
}

_DMC_Release(MenuObj) {
	_DMC_ReleaseHandle(MenuObj.Handle)
	MenuObj.Delete()
}

_DMC_InsertPrerequisite() {
	Native := Menu()
	try {
		Native.Insert("", "model:A", (*) => 0)
		FirstId := _MenuItemIdAtPosition(Native, 0)
		Native.Insert("", "model:A", (*) => 0)
		Native.Insert("", "MODEL:a", (*) => 0)
		AssertEqual(3, TrayMenuItemCount(Native), "blank Insert creates distinct rows")
		Assert(FirstId != 0 && FirstId == _MenuItemIdAtPosition(Native, 0))
		Assert(FirstId != _MenuItemIdAtPosition(Native, 1))
		Assert(_DMC_Label(Native, 0) == "model:A")
		Assert(_DMC_Label(Native, 1) == "model:A")
		Assert(_DMC_Label(Native, 2) == "MODEL:a", "native text preserves exact case")
	} finally _DMC_Release(Native)
}
Test("menu duplicate rows: actual blank Insert native prerequisite", _DMC_InsertPrerequisite)

_DMC_BlankRegistration() {
	global _MenuDispatchTokens, _MenuDispatchCallbacks
	Native := Menu(), Fired := []
	try {
		AssertEqual(1, RegisterMenuItemInsert(Native, "", "same", (*) => Fired.Push("first")))
		FirstId := _MenuItemIdAtPosition(Native, 0), FirstToken := _MenuDispatchTokens[FirstId]
		AssertEqual(1, RegisterMenuItemInsert(Native, "", "same", (*) => Fired.Push("second")))
		SecondId := _MenuItemIdAtPosition(Native, 1)
		AssertEqual(2, TrayMenuItemCount(Native))
		Assert(FirstId != SecondId && SecondId != 0)
		AssertEqual(FirstToken, _MenuDispatchTokens[FirstId], "old row registration is retained")
		Assert(_MenuDispatchTokens[SecondId] != FirstToken)
		_MenuDispatchCallbacks[FirstId].Call()
		_MenuDispatchCallbacks[SecondId].Call()
		AssertEqual(2, Fired.Length)
		Assert(Fired[1] == "first" && Fired[2] == "second")
	} finally _DMC_Release(Native)
}
Test("menu duplicate rows: blank Insert retains separate native callbacks and tokens", _DMC_BlankRegistration)

_DMC_RenderState() {
	global _MenuDispatchCallbacks
	for FirstActive in [true, false] {
		Native := Menu(), Fired := []
		try {
			Rows := [Map("label", "model:A", "checked", FirstActive, "disabled", !FirstActive,
				"action", (*) => Fired.Push("first")), Map("label", "model:A", "checked", !FirstActive,
				"disabled", FirstActive, "action", (*) => Fired.Push("second")),
				Map("label", "MODEL:a", "action", (*) => Fired.Push("case"))]
			AssertEqual(3, _MR_RenderRows(Native, Rows, "duplicate-case", 1, 0, true))
			AssertEqual(3, TrayMenuItemCount(Native))
			Assert(_DMC_Label(Native, 0) == "model:A" && _DMC_Label(Native, 1) == "model:A")
			Assert(_DMC_Label(Native, 2) == "MODEL:a")
			AssertEqual(FirstActive, (_DMC_State(Native, 0) & 8) != 0)
			AssertEqual(!FirstActive, (_DMC_State(Native, 1) & 8) != 0)
			AssertEqual(!FirstActive, (_DMC_State(Native, 0) & 3) != 0)
			AssertEqual(FirstActive, (_DMC_State(Native, 1) & 3) != 0)
			Seen := Map()
			loop 3 {
				Id := _MenuItemIdAtPosition(Native, A_Index - 1)
				Assert(Id != 0 && !Seen.Has(Id))
				Seen[Id] := true
				Assert(_MenuDispatchCallbacks.Has(Id))
				_MenuDispatchCallbacks[Id].Call()
			}
			AssertEqual(3, Fired.Length)
			Assert(Fired[1] == "first" && Fired[2] == "second" && Fired[3] == "case")
		} finally _DMC_Release(Native)
	}
}
Test("menu duplicate rows: exact text callback identity and positional check disable", _DMC_RenderState)

_DMC_RenderIcon() {
	Control := Menu(), Native := Menu()
	try {
		Control.Insert("", "same", (*) => 0)
		Control.Insert("", "same", (*) => 0)
		Control.SetIcon("2&", A_AhkPath)
		AssertEqual(0, _DMC_Bitmap(Control, 0))
		Assert(_DMC_Bitmap(Control, 1) != 0, "actual executable icon is a required probe prerequisite")
		_MR_RenderRows(Native, [Map("label", "same", "action", (*) => 0),
			Map("separator", true), Map("label", "same", "icon", A_AhkPath, "action", (*) => 0)],
			"duplicate-icon", 1, 0, true)
		AssertEqual(3, TrayMenuItemCount(Native))
		AssertEqual(0, _DMC_Bitmap(Native, 0), "first equal-label row receives no icon")
		Assert(_DMC_Bitmap(Native, 2) != 0, "the icon belongs to the appended row after a separator")
	} finally {
		_DMC_Release(Control)
		_DMC_Release(Native)
	}
}
Test("menu duplicate rows: icon belongs to actual appended position", _DMC_RenderIcon)

_DMC_MixedRows() {
	Native := Menu(), Child := Menu()
	Child.Add("native child", (*) => 0)
	try {
		_MR_RenderRows(Native, [Map("label", "same", "action", (*) => 0),
			Map("label", "same"), Map("label", "same", "items", [Map("label", "nested")]),
			Map("label", "same", "submenu", Child)], "mixed-duplicates", 1, 0, true)
		AssertEqual(4, TrayMenuItemCount(Native))
		AssertEqual(0, _DMC_State(Native, 0) & 3)
		Assert((_DMC_State(Native, 1) & 3) != 0, "only inert row is disabled")
		loop 2 {
			Assert(DllCall("GetSubMenu", "ptr", Native.Handle, "int", A_Index + 1, "ptr") != 0)
			AssertEqual(0, _DMC_State(Native, A_Index + 1) & 3)
		}
	} finally _DMC_Release(Native)
}
Test("menu duplicate rows: action inert and both native submenu forms keep distinct rows", _DMC_MixedRows)

_DMC_LazyBatches() {
	global _MenuDispatchTokens, _MenuDispatchCallbacks
	Owner := MenuPopulation(), Rows := [], Fired := []
	loop 34 {
		Index := A_Index
		Rows.Push(Map("label", "same", "checked", Index == 34, "disabled", Index == 18,
			"action", _DMC_Record.Bind(Fired, Index)))
	}
	Leaf := Owner.Create(Rows, "duplicate-lazy", 1)
	try {
		AssertEqual(1, TrayMenuItemCount(Leaf))
		FirstId := _MenuItemIdAtPosition(Leaf, 0), FirstToken := _MenuDispatchTokens[FirstId]
		Owner.Complete(Leaf.Handle, "candidate batch", 0, 16)
		AssertEqual(17, TrayMenuItemCount(Leaf))
		Owner.Complete(Leaf.Handle, "candidate batch", 0, 16)
		AssertEqual(33, TrayMenuItemCount(Leaf))
		Owner.Complete(Leaf.Handle, "candidate navigation")
		AssertEqual(34, TrayMenuItemCount(Leaf))
		AssertEqual(FirstId, _MenuItemIdAtPosition(Leaf, 0))
		AssertEqual(FirstToken, _MenuDispatchTokens[FirstId])
		AssertEqual(0, Owner.Pending.Count)
		Seen := Map()
		loop 34 {
			Position := A_Index - 1
			Assert(_DMC_Label(Leaf, Position) == "same")
			Id := _MenuItemIdAtPosition(Leaf, Position)
			Assert(Id != 0 && !Seen.Has(Id))
			Seen[Id] := true
			AssertEqual(A_Index == 34, (_DMC_State(Leaf, Position) & 8) != 0)
			AssertEqual(A_Index == 18, (_DMC_State(Leaf, Position) & 3) != 0)
			_MenuDispatchCallbacks[Id].Call()
		}
		AssertEqual(34, Fired.Length)
		loop 34
			AssertEqual(A_Index, Fired[A_Index])
	} finally {
		Owner.Stop()
		_DMC_Release(Leaf)
	}
}
_DMC_Record(Fired, Index, *) {
	Fired.Push(Index)
}
Test("menu duplicate rows: lazy seed and sixteen row batches retain identity", _DMC_LazyBatches)

_DMC_DirectAddUpdate() {
	global _MenuDispatchCallbacks, _MenuDispatchTokens
	Native := Menu(), Fired := []
	try {
		AssertEqual(1, RegisterMenuItem(Native, "same", (*) => Fired.Push("obsolete")))
		FirstId := _MenuItemIdAtPosition(Native, 0), OldToken := _MenuDispatchTokens[FirstId]
		AssertEqual(1, RegisterMenuItem(Native, "tail", (*) => Fired.Push("tail")))
		TailId := _MenuItemIdAtPosition(Native, 1), TailToken := _MenuDispatchTokens[TailId]
		AssertEqual(1, RegisterMenuItem(Native, "same", (*) => Fired.Push("replacement")))
		AssertEqual(2, TrayMenuItemCount(Native), "direct RegisterMenuItem retains add/update semantics")
		AssertEqual(FirstId, _MenuItemIdAtPosition(Native, 0))
		Assert(_MenuDispatchTokens[FirstId] != OldToken)
		AssertEqual(TailToken, _MenuDispatchTokens[TailId])
		_MenuDispatchCallbacks[FirstId].Call()
		_MenuDispatchCallbacks[TailId].Call()
		Assert(Fired[1] == "replacement" && Fired[2] == "tail")
	} finally _DMC_Release(Native)
}
Test("menu duplicate rows: direct Add update semantics stay unchanged", _DMC_DirectAddUpdate)

; Explicit adverse object ports only for failure admission. Success cases above
; use genuine Menu objects. These ports expose actual HMENUs/counts/invalid-ID
; receipts and never fabricate a successful renderer/Win32 response.
class _DMC_RefusedMenuPort {
	__New(Mode) {
		this.Native := Menu(), this.Mode := Mode, this.Reads := 0, this.InsertCalls := 0
		this.Child := Menu()
		if Mode == "item-id"
			this.Native.Insert("", "refused", (*) => 0)
	}
	Handle {
		get {
			this.Reads += 1
			if this.Mode == "before-count" || (this.Mode == "after-count" && this.Reads > 1)
				return 0
			return this.Native.Handle
		}
	}
	Insert(Before, Label, Callback) {
		this.InsertCalls += 1
		if this.Mode == "item-id" {
			this.Native.Insert("", Label, this.Child)
		} else {
			this.Native.Insert(Before, Label, Callback)
			if this.Mode == "count-growth"
				this.Native.Insert("", Label, Callback)
		}
	}
}

_DMC_Refusal(Mode) {
	global _MenuDispatchCallbacks, _MenuDispatchTokens, _MenuDispatchTokenCounter
	Port := _DMC_RefusedMenuPort(Mode), Fired := []
	CallbacksBefore := _MenuDispatchCallbacks.Count, TokensBefore := _MenuDispatchTokens.Count
	CounterBefore := _MenuDispatchTokenCounter
	try {
		AssertEqual(0, RegisterMenuItemInsert(Port, "", "refused", (*) => Fired.Push("bad")))
		AssertEqual(CallbacksBefore, _MenuDispatchCallbacks.Count)
		AssertEqual(TokensBefore, _MenuDispatchTokens.Count)
		AssertEqual(CounterBefore, _MenuDispatchTokenCounter)
		AssertEqual(0, Fired.Length)
		AssertEqual(Mode == "before-count" ? 0 : 1, Port.InsertCalls)
		AssertEqual(Mode == "before-count" ? 0 : (Mode == "count-growth" || Mode == "item-id") ? 2 : 1,
			TrayMenuItemCount(Port.Native))
		if Mode == "item-id"
			AssertEqual(0xFFFFFFFF, DllCall("GetMenuItemID", "ptr", Port.Native.Handle, "int", 1, "uint"),
				"actual popup entry has no leaf command ID; unique-name fallback could misbind its same-label sibling")
	} finally _DMC_Release(Port.Native)
}
Test("menu duplicate rows: unreadable initial count refuses before insertion", _DMC_Refusal.Bind("before-count"))
Test("menu duplicate rows: unreadable post insertion count refuses tracking", _DMC_Refusal.Bind("after-count"))
Test("menu duplicate rows: unexpected native growth refuses tracking", _DMC_Refusal.Bind("count-growth"))
Test("menu duplicate rows: native popup invalid leaf ID refuses tracking", _DMC_Refusal.Bind("item-id"))
