"""Parse TODO.md into sections and checkbox items (shared by apply.py and the review dump)."""
import re

BOX = re.compile(r'^(\s*)- \[([ xX])\] ?')


def indent(line):
    return len(line) - len(line.lstrip(' '))


def item_end(lines, i):
    """Index past the item starting at lines[i]: its more-indented continuation lines."""
    ind = indent(lines[i])
    j = i + 1
    while j < len(lines):
        line = lines[j]
        if not line.strip():
            # A blank line ends the item unless the next non-blank line is still indented deeper.
            k = j
            while k < len(lines) and not lines[k].strip():
                k += 1
            if k < len(lines) and indent(lines[k]) > ind and not lines[k].lstrip().startswith('#'):
                j = k
                continue
            break
        if indent(line) <= ind:
            break
        j += 1
    return j


def done_items(lines):
    """Yield (start, end, section, key) for every [x] item; key is its first line stripped."""
    sec = ''
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith('## '):
            sec = line
        m = BOX.match(line)
        if m and m.group(2) in 'xX':
            j = item_end(lines, i)
            yield i, j, sec, line.strip()
            i = j
            continue
        i += 1


def sections(lines):
    """Split into [(heading or None, [lines])] on '## ' headings."""
    out = [(None, [])]
    for line in lines:
        if line.startswith('## '):
            out.append((line, [line]))
        else:
            out[-1][1].append(line)
    return out
