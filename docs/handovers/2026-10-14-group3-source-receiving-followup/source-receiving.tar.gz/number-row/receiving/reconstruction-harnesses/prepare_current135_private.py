from pathlib import Path
import json,hashlib,shutil
r=Path('/workspace/ergopti'); b=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g5-number-row-source-basis-received-v1/members/source-review-basis');prior=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-receiving-proposal-v1');o=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');o.mkdir(exist_ok=True)
h=lambda x:hashlib.sha256(x).hexdigest();canonical=lambda d:json.dumps(d,sort_keys=True,separators=(',',':')).encode()
files=['tools/diagnostics/number_row_native_causal.py','tools/diagnostics/prepare_number_row_native_causal.py','tools/diagnostics/generate_number_row_source_composition.py','tools/diagnostics/test_number_row_source_composition.py']
for p in files:
 target=o/'preimages'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/p,target)
 target=o/'postimages'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/p,target)
shutil.copyfile(prior/'CONTROL-INPUTS.json',o/'FROZEN-INDEPENDENT15-INPUTS.json')
proposal=json.loads((prior/'source-join-proposal.json').read_text()); rows=[]
for entry in proposal['rows']:
 source=entry['source'];p=source['path'];basis=entry['review_basis'];category=entry['category'];original=None;bindings=[]
 if category=='87 immutable historical entries':
  original=basis['unchanged_historical_tuple'];bindings=[{'path':'tools/diagnostics/fixtures/number-row-native-causal/projection-manifest.original-c15.json.raw','sha256':proposal['historical_recipe_sha256'],'scope':'immutable historical tuple'}]
 elif category=='existing independently approved69 lease replacement':
  record=basis['record'];original={'git_blob':record['original_git_blob'],'sha256':record['original_sha256']};bindings=[{'path':basis['existing_approval_path'],'sha256':basis['existing_approval_sha256'],'scope':'original strict69 supplier source approval'},{'path':'independent strict69 source review','sha256':record['source_review_sha256'],'scope':'original strict69 supplier source approval'}]
 elif category=='ten scoped current historical deltas':
  originals=json.loads((b/'ORIGINAL99-CURRENT-CENSUS.json').read_text())['rows'];original=next(x['original'] for x in originals if x['current']['path']==p); name=basis['review_basis'];bindings=[{'path':name,'sha256':h((b/name).read_bytes()),'scope':'exact scoped current historical source delta'}]
 elif category=='34 supplemental project compiler inputs':
  refs=basis.get('review_basis',[basis['review']] if 'review' in basis else [])
  for ref in refs:
   name=ref['path'] if isinstance(ref,dict) else ref;bindings.append({'path':name,'sha256':h((b/name).read_bytes()),'scope':'default NumberRow filter noninterference and source dependency closure only'})
 else:
  assert category=='whole workflow identity only';bindings=[{'path':'CURRENT135-SOURCE-CENSUS.json','sha256':h((b/'CURRENT135-SOURCE-CENSUS.json').read_bytes()),'scope':'workflow source identity only; no execution policy approval'}]
 rows.append({'path':p,'git_mode':source['git_mode'],'git_blob':source['git_blob'],'sha256':source['sha256'],'historical_git_blob':None if original is None else original['git_blob'],'historical_sha256':None if original is None else original['sha256'],'review_role':category,'review_bindings':bindings})
rows.sort(key=lambda x:x['path'])
lease_path='tools/diagnostics/fixtures/number-row-native-causal/g5-source-approvals.json.raw';lease_sha=h((r/lease_path).read_bytes());input_sha=h(canonical(rows));metadata_sha=h((b.parent.parent/'independent-metadata-review.json.raw').read_bytes())
# A concrete private draft envelope. It is explicitly PROVISIONAL in the
# receiving receipt, not represented as independently approved/adopted source.
envelope={'schema':1,'role':'independently-reviewed-current-build-inputs','published_source_commit':proposal['basis_head'],'strict_lease_ancestor':'69fcb820ee5062ad445b93927cc536c543a3a878','historical_recipe_sha256':proposal['historical_recipe_sha256'],'source_basis_manifest_sha256':h((b/'MANIFEST.json').read_bytes()),'source_basis_census_sha256':h((b/'CENSUS.json').read_bytes()),'source_basis_metadata_review_sha256':metadata_sha,'source_review_sha256':h((prior/'HANDOFF.md').read_bytes()),'historical_lease_approval_sha256':lease_sha,'review_scope':'current compiler-source closure and NumberRow filter noninterference only; not native qualification','sources':rows}
(o/'provisional-current135-envelope.json').write_text(json.dumps(envelope,indent=2,sort_keys=True)+'\n')
(o/'PROVISIONAL-STATUS.json').write_text(json.dumps({'role':'PRIVATE SOURCE PROTOTYPE TEST INPUT ONLY','independent_current135_admission_review':'PENDING','source_review_sha256_field':'The genuine frozen author handoff hash is a provisional test input, not an independent approval claim; replace only through independently reviewed final receiving.','canonical_adoption':False,'native_authority':False,'frozen15_original_sha256':h((o/'FROZEN-INDEPENDENT15-INPUTS.json').read_bytes())},indent=2)+'\n')
(o/'contract-constants.json').write_text(json.dumps({'inputs_sha256':input_sha,'lease_sha256':lease_sha,'metadata_sha256':metadata_sha,'manifest_sha256':envelope['source_basis_manifest_sha256'],'census_sha256':envelope['source_basis_census_sha256']},indent=2)+'\n')
print(json.dumps({'directory':str(o),'envelope_bytes':(o/'provisional-current135-envelope.json').stat().st_size,'constants':json.loads((o/'contract-constants.json').read_text())},indent=2))
