# Native conflict fixture path spelling

SOURCE ONLY; runtime/parser/formatter/test/generator/Git/CI execution UNRUN.

Windows may enumerate the owned temporary directory using a different long/short spelling and case. The actual filename control must preserve the fixture-provided root rather than assert identity of an unrelated native enumeration spelling. This one-line successor appends actual A_LoopFileName to the exact owned Fixture.directory.

The genuine top-level file enumeration remains unchanged. Its count must still be exactly one and every actual filename must still yield the expected config.toml path. Any stage, backup, replacement or WAL file still fails the unchanged count/name/absence requirements. Exact foreign bytes, stale native expected_old_conflict, native authority, actual retry/compensation and resolved cleanup assertions remain byte-exact. The change does not claim actual Windows execution or widen the original enumeration scope.

Root may receive the bounded one-line hunk only after its active gate is terminal and canonical preimage is rechecked. Prior V3 review/holds/runtime-UNRUN limits remain.
