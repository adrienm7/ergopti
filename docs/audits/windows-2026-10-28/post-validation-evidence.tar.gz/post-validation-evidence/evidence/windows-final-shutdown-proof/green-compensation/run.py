from pathlib import Path
import subprocess,os,json,re,datetime,hashlib
from zoneinfo import ZoneInfo
root=Path('/workspace/ergopti-windows-final-shutdown');out=Path('/workspace/scratch/windows-final-shutdown-proof/green-compensation')
def freeze():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=root)).hexdigest(),'untracked':subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True)}
before=freeze();env=dict(os.environ,WINEPREFIX='/workspace/toolchain/wine-r3-metrics-owned',WINEPATH=r'Z:\workspace\toolchain\node-v22.22.2-win-x64;Z:\workspace\toolchain\mingit-2.56.0.4-x64\cmd')
argv=['timeout','--kill-after=5s','300s','xvfb-run','-a','bash','tools/test/run-ahk-under-wine.sh','--ahk','/workspace/toolchain/ahk/AutoHotkey64.exe','--runner','run_all.ahk','--results',str(out/'native.tap'),'--','--list=Z:\\workspace\\scratch\\windows-final-shutdown-proof\\selected5.txt']
with (out/'native.log').open('w') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
t=(out/'native.tap').read_text(encoding='utf-8-sig') if (out/'native.tap').exists() else '';plans=re.findall(r'^1\.\.(\d+)\s*$',t,re.M);failures=re.findall(r'^not ok .*',t,re.M)
row={'argv':argv,'exit_code':r.returncode,'plans':plans,'passed':len(re.findall(r'^ok \d+ - ',t,re.M)),'failed':failures,'warnings':[x for x in (out/'native.log').read_text(errors='replace').splitlines() if 'Warning:' in x],'source_before':before,'source_after':freeze(),'at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'native_windows_qualified':False};(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2));assert row['source_before']==row['source_after'];assert r.returncode==0 and plans==['5'] and row['passed']==5 and not failures and not row['warnings']
