'use strict';
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const root = '/workspace/ergopti-macos-integration';
const scratch = '/workspace/scratch/oct28-fresh-tis-menu-oracle';
const version = process.argv[2];
const entry = process.argv[3];
if (!['before', 'after'].includes(version)) throw new Error('Unknown proof version');
const names = ['tools/lib/menu-native-layout-binding.cjs', 'tools/test/test-menu-action-handler-bijection.cjs', 'tools/test/test-menu-category-coverage.cjs'];
const overrides = new Map(names.map((name) => [path.join(root, name), path.join(scratch, version, path.basename(name))]));
const originalLoad = Module._load;
const cache = new Map();
Module._load = function(request, parent, isMain) {
 const filename = Module._resolveFilename(request, parent, isMain);
 if (!overrides.has(filename)) return originalLoad.call(this, request, parent, isMain);
 if (cache.has(filename)) return cache.get(filename).exports;
 const subject = new Module(filename, parent);
 subject.filename = filename;
 subject.paths = Module._nodeModulePaths(path.dirname(filename));
 cache.set(filename, subject);
 if (isMain) { process.mainModule = subject; process.argv[1] = filename; }
 subject._compile(fs.readFileSync(overrides.get(filename), 'utf8'), filename);
 subject.loaded = true;
 return subject.exports;
};
Module._load(path.join(root, 'tools/test', entry), null, true);
