Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$taskRoot = '/workspace/ergopti-validation/windows-ollama-runtime-candidate/versions/file-port-v2'
$results = @()
foreach ($taskName in @('ollama_managed_files.ps1', 'test_ollama_install_files.ps1', 'ollama-runtime-launch.ps1')) {
	$taskPath = [IO.Path]::Combine($taskRoot, $taskName)
	$before = (Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant()
	$tokens = $null
	$diagnostics = $null
	$ast = [Management.Automation.Language.Parser]::ParseFile($taskPath, [ref]$tokens, [ref]$diagnostics)
	$after = (Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant()
	$results += [ordered]@{
		file = $taskPath; sha256_before = $before; sha256_after = $after;
		ast_obtained = ($null -ne $ast); diagnostic_count = @($diagnostics).Count;
		diagnostics = @($diagnostics | ForEach-Object { [ordered]@{
			line = $_.Extent.StartLineNumber; column = $_.Extent.StartColumnNumber;
			id = $_.ErrorId; message = $_.Message; text = $_.Extent.Text
		} })
	}
}
[ordered]@{ version = $PSVersionTable.PSVersion.ToString(); edition = $PSVersionTable.PSEdition;
	platform = [Environment]::OSVersion.Platform.ToString(); mode = 'Parser.ParseFile AST only';
	implementation_executed = $false; results = $results } | ConvertTo-Json -Depth 8
if (@($results | Where-Object { $_.diagnostic_count -ne 0 -or $_.sha256_before -ne $_.sha256_after }).Count -ne 0) { exit 1 }
