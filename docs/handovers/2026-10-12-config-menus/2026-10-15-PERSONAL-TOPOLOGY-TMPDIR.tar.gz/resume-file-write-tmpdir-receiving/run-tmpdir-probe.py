from pathlib import Path
import hashlib,json,os,subprocess,tempfile,time,re,shutil
b=Path('/workspace/.ergopti-cloud/resume-file-write-tmpdir-receiving');source=b/'source';linux=source/'static/ergopti_plus/linux';helper=linux/'tests/hardware/run_file_write_special_receipts.py'
sha=lambda data:hashlib.sha256(data).hexdigest()
long_root=Path('/var/tmp/ergopti-cloud-validation/ergopti-personal-gate-rx8edn1r')
created_long=not long_root.exists();long_root.mkdir(parents=True,exist_ok=True)
short_root=Path(tempfile.mkdtemp(prefix='eg-',dir='/var/tmp'))
rows=[]
for label,root in [('long',long_root),('short',short_root)]:
 env=os.environ.copy();env.update(TMPDIR=str(root),TEMP=str(root),ERGOPTI_WRITE_BACKEND='ffi',ERGOPTI_FILE_WRITE_TEST_LUA='luajit')
 command=['python3',str(helper)];start=time.monotonic()
 with(b/(label+'.stdout.log')).open('wb')as out,(b/(label+'.stderr.log')).open('wb')as err:
  result=subprocess.run(command,cwd=linux,env=env,stdout=out,stderr=err,check=False)
 stdout=(b/(label+'.stdout.log')).read_text();stderr=(b/(label+'.stderr.log')).read_text()
 row={'label':label,'command':command,'cwd':str(linux),'environment_overrides':{key:env[key]for key in('TMPDIR','TEMP','ERGOPTI_WRITE_BACKEND','ERGOPTI_FILE_WRITE_TEST_LUA')},'interpreter_binary':shutil.which('luajit'),'child_exit_code':result.returncode,'completed_pass_receipts':len(re.findall(r'^PASS ',stdout,re.M)),'completed_fail_receipts':len(re.findall(r'^FAIL ',stdout,re.M)),'terminal_24_check_summary':'Native special file write receipts (ffi): 24 checks, 0 failures'in stdout,'af_unix_path_too_long':'OSError: AF_UNIX path too long'in stderr,'tmpdir_bytes':len(os.fsencode(str(root))),'socket_fixture_path_bytes':len(os.fsencode(str(root)+'/ergopti-native-file-write-'+'X'*8+'/14/source')),'remaining_owned_helper_directories':[str(p)for p in root.glob('ergopti-native-file-write-*')],'elapsed_seconds':round(time.monotonic()-start,3),'stdout_sha256':sha((b/(label+'.stdout.log')).read_bytes()),'stderr_sha256':sha((b/(label+'.stderr.log')).read_bytes())}
 (b/(label+'-status.json')).write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print(json.dumps(row),flush=True)
 assert not row['remaining_owned_helper_directories']
 if label=='long':assert result.returncode==1 and row['af_unix_path_too_long']and row['completed_pass_receipts']==14 and not row['terminal_24_check_summary']
 else:assert result.returncode==0 and row['completed_pass_receipts']==24 and row['completed_fail_receipts']==0 and row['terminal_24_check_summary']
assert not list(short_root.iterdir());short_root.rmdir()
if created_long and not list(long_root.iterdir()):long_root.rmdir()
files=['static/ergopti_plus/linux/tests/hardware/run_file_write_special_receipts.py','static/ergopti_plus/linux/adapters/file_system.lua','static/ergopti_plus/linux/infra/regular_file_writer.lua','static/ergopti_plus/_shared/lua/logger/shim.lua']
(b/'tmpdir-probe.json').write_text(json.dumps({'state':'COMPLETE','source_hashes':{name:sha((source/name).read_bytes())for name in files},'watcher_source_sha256':sha((linux/'infra/file_watchers.lua').read_bytes()),'rows':rows,'short_owned_root_removed':not short_root.exists(),'long_root_created_by_probe':created_long},indent=2)+'\n')
