from pathlib import Path
import subprocess,json,os
p=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');records=json.loads((p/'sparse-fixtures.json').read_text());env=os.environ.copy();env.update({'GIT_AUTHOR_NAME':'Ergopti private source controls','GIT_AUTHOR_EMAIL':'source-controls@invalid','GIT_COMMITTER_NAME':'Ergopti private source controls','GIT_COMMITTER_EMAIL':'source-controls@invalid'})
for record in records:
 r=Path(record['root']);parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
 for f in record['controller_postimages']:
  data=(p/'postimages'/f).read_bytes();(r/f).write_bytes(data);blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=r,input=data).decode().strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+f],cwd=r,check=True)
 tree=subprocess.check_output(['git','write-tree'],cwd=r,text=True).strip();head=subprocess.check_output(['git','commit-tree',tree,'-p',parent],cwd=r,env=env,input='test: strengthen provisional genuine source receiving controls\n',text=True).strip();subprocess.run(['git','update-ref','--no-deref','HEAD',head],cwd=r,check=True);record.setdefault('previous_controller_revisions',[]).append(parent);record['actual_private_controller_commit']=head
(p/'sparse-fixtures.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({x['fixture']:x['actual_private_controller_commit'] for x in records},indent=2))
