[CmdletBinding()]
param(
	[Parameter(Mandatory = $true)][ValidateSet('prepare', 'publish', 'cleanup', 'cleanup_partial', 'inspect')][string]$Action,
	[Parameter(Mandatory = $true)][string]$FilesHelperPath,
	[Parameter(Mandatory = $true)][string]$FilesHelperHash,
	[Parameter(Mandatory = $true)][string]$PublicationHelperPath,
	[Parameter(Mandatory = $true)][string]$PublicationHelperHash,
	[Parameter(Mandatory = $true)][string]$ManagedRoot,
	[string]$CataloguePath = '', [string]$CatalogueSha256 = '', [string]$AssetId = '',
	[string]$ArchivePath = '', [string]$TicketId = '', [string]$StageIdentity = '',
	[string]$ManifestSha256 = '', [string]$CreationWalIdentity = '', [string]$CreationWalSha256 = '',
	[long]$MaxExpandedBytes = 0, [int]$MaxEntries = 0,
	[string]$GuardianPath = '', [string]$LauncherPath = '',
	[string]$ModelsDirectory = '', [string]$ModelsFolderName = '', [int]$InspectMetadataBytes = 0
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$installOwner = [ordered]@{ streams = [Collections.Generic.List[object]]::new(); root = $null;
	archive = $null; publication = ''; first_error = ''; phase = 'acquiring'; acquisition = [ordered]@{
		root_handles = $null; stage_handle = [IntPtr]::Zero; streams = $null; directory_handles = $null;
		phase = 'acquiring'; first_error = '' } }

$installRequest = @{ Action = $Action; ManagedRoot = $ManagedRoot; CataloguePath = $CataloguePath;
	CatalogueSha256 = $CatalogueSha256; AssetId = $AssetId; ArchivePath = $ArchivePath; TicketId = $TicketId;
	StageIdentity = $StageIdentity; ManifestSha256 = $ManifestSha256; CreationWalIdentity = $CreationWalIdentity;
	CreationWalSha256 = $CreationWalSha256; MaxExpandedBytes = $MaxExpandedBytes; MaxEntries = $MaxEntries }
# The dot-sourced library has its own param block. Supply the captured values
# explicitly so its defaults cannot reset this worker's operation/source fields.
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
function Write-InstallFrame($Value) {
	# ShellRunner FileRead recognizes this UTF-8 BOM independently of A_FileEncoding.
	[Console]::Out.Write([char]0xfeff)
	[Console]::Out.WriteLine(($Value | ConvertTo-Json -Depth 16 -Compress))
}

function Open-InstallCodePin([string]$Path, [string]$Hash) {
	if ($Path -notmatch '\A[A-Za-z]:\\' -or $Path.Contains([char]0) -or $Path.Contains("`r") -or
		$Path.Contains("`n") -or $Hash -notmatch '\A[0-9a-f]{64}\z') { throw 'Installation code pin is malformed.' }
	$stream = [IO.FileStream]::new($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
	$installOwner.streams.Add($stream)
	$hasher = [Security.Cryptography.SHA256]::Create()
	try { $actual = [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
	finally { $hasher.Dispose(); $stream.Position = 0 }
	if ($actual -ne $Hash) { throw 'Installation code image differs from its captured pin.' }
}

try {
	if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1 -or [IntPtr]::Size -ne 8) {
		throw 'Managed installation requires Windows PowerShell 5.1 x64.'
	}
	$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
	Open-InstallCodePin $FilesHelperPath $FilesHelperHash
	Open-InstallCodePin $PublicationHelperPath $PublicationHelperHash
	. $FilesHelperPath @installRequest
	. $PublicationHelperPath
	Initialize-OllamaPublicationOwner
	$installOwner.root = Open-OllamaManagedRoot $ManagedRoot ($Action -eq 'prepare') $installOwner.acquisition
	switch ($Action) {
		'prepare' {
			$installOwner.archive = Read-OllamaPinnedArchive $CataloguePath $CatalogueSha256 $AssetId $ArchivePath $MaxExpandedBytes $MaxEntries
			$result = Prepare-OllamaManagedStage $installOwner.root $installOwner.archive $TicketId $true
			Close-OllamaPinnedArchive $installOwner.archive
			$installOwner.archive = $null
		}
		'publish' {
			if ($ModelsDirectory -ne '' -or $ModelsFolderName -ne '') {
				[void](Open-OllamaManagedModels $installOwner.root $ModelsDirectory $ModelsFolderName $false $null)
			}
			$installOwner.publication = New-OllamaPublicationOwner $installOwner.root $TicketId $StageIdentity $ManifestSha256
			[void](Publish-OllamaVersionDescriptor $installOwner.publication)
			$result = Get-OllamaRuntimeSourceExpectation $installOwner.publication $GuardianPath $LauncherPath
			# This is no host reservation. The later source worker must independently
			# reacquire and validate every native identity/digest before READY.
			if (-not (Close-OllamaPublicationOwner $installOwner.publication)) { throw 'Publication retains close debt.' }
		}
		'inspect' {
			if ($ModelsDirectory -ne '' -or $ModelsFolderName -ne '') {
				[void](Open-OllamaManagedModels $installOwner.root $ModelsDirectory $ModelsFolderName $false $null)
			}
			$result = Get-OllamaExistingRuntimeExpectation $installOwner.root $CataloguePath $CatalogueSha256 $AssetId `
				$GuardianPath $LauncherPath $InspectMetadataBytes $installOwner.acquisition
		}
		'cleanup' { $result = Remove-OllamaPreparedStage $installOwner.root $TicketId $StageIdentity $ManifestSha256 }
		'cleanup_partial' { $result = Remove-OllamaPartialStage $installOwner.root $TicketId $CreationWalIdentity $CreationWalSha256 }
	}
	Close-OllamaManagedRoot $installOwner.root
	$installOwner.root = $null
	$installOwner.phase = 'terminal'
	Write-InstallFrame $result
	exit 0
} catch {
	if ($installOwner.first_error -eq '') { $installOwner.first_error = $_.Exception.Message }
	$failure = [ordered]@{ ok = $false; phase = 'refused'; cleanup_pending = ($Action -ne 'inspect'); ticket = $TicketId;
		error = $installOwner.first_error; publication_owner = $installOwner.publication }
	if ($_.Exception.Data.Contains('ollama_creation_receipt')) { $failure.creation_receipt = $_.Exception.Data['ollama_creation_receipt'] }
	if ($_.Exception.Data.Contains('ollama_publication_owner')) { $failure.publication_owner = $_.Exception.Data['ollama_publication_owner'] }
	Write-InstallFrame $failure
	# No asynchronous native work exists here. Partial raw resources stay under
	# this exact retained process/job until terminal, never an early Boolean ACK.
	exit 1
}
