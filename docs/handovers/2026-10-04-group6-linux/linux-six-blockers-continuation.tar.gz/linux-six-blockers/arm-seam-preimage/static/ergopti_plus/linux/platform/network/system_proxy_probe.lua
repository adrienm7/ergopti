--- platform/network/system_proxy_probe.lua

--- ==============================================================================
--- MODULE: Native GIO Proxy Lookup Child (Linux)
--- DESCRIPTION:
--- Reads one private destination from stdin and returns the operating system's
--- ordered proxy selection. The parent owns this blocking child, its deadline
--- and its retirement; the grabbed-keyboard process never calls GIO directly.
--- GIO/libproxy acknowledges selection, not successful PAC retrieval or
--- evaluation: a native DIRECT selection preserves that explicit limitation.
--- ==============================================================================

local shared_root = arg[1]
if type(shared_root) ~= "string" or shared_root == "" then os.exit(2) end
package.path = shared_root .. "/lua/?.lua;" .. package.path
local Json = require("json")

--- Emits one machine receipt without native diagnostic text or request bytes.
--- @param receipt table
local function emit(receipt)
	io.stdout:write(Json.encode(receipt), "\n")
	io.stdout:flush()
end

--- Loads the native ABI without requiring a development package or lgi.
--- @return table|nil
local function native_backend()
	local loaded, ffi = pcall(require, "ffi")
	if not loaded then return nil end
	local declared = pcall(ffi.cdef, [[
		typedef struct { unsigned int domain; int code; char *message; } ErgoptiProxyError;
		void *g_proxy_resolver_get_default(void);
		int g_proxy_resolver_is_supported(void *resolver);
		char **g_proxy_resolver_lookup(void *resolver, const char *uri,
			void *cancellable, ErgoptiProxyError **error);
		const char *g_type_name_from_instance(void *instance);
		void g_strfreev(char **strings);
		void g_error_free(ErgoptiProxyError *error);
		int unsetenv(const char *name);
	]])
	if not declared then return nil end
	local ok, gio, gobject, glib = pcall(function()
		return ffi.load("libgio-2.0.so.0"), ffi.load("libgobject-2.0.so.0"), ffi.load("libglib-2.0.so.0")
	end)
	if not ok then return nil end
	return { ffi = ffi, gio = gio, gobject = gobject, glib = glib }
end

--- Performs the actual system lookup and frees every native result allocation.
--- @param url string
--- @return table
local function lookup(url, exclusions)
	local native = native_backend()
	if not native then return { ok = false, error = "proxy-native-unavailable" } end
	local ffi = native.ffi
	if exclusions ~= nil then
		if type(exclusions) ~= "table" or #exclusions > 32 then return { ok = false, error = "proxy-request-invalid" } end
		for key, name in pairs(exclusions) do
			if type(key) ~= "number" or key % 1 ~= 0 or key < 1 or key > #exclusions
				or type(name) ~= "string" or not name:match("^[%a_][%w_]*$") then
				return { ok = false, error = "proxy-request-invalid" }
			end
			if ffi.C.unsetenv(name) ~= 0 then return { ok = false, error = "proxy-native-failed" } end
		end
	end
	local resolver = native.gio.g_proxy_resolver_get_default()
	if resolver == nil or native.gio.g_proxy_resolver_is_supported(resolver) ~= 1 then
		return { ok = false, error = "proxy-backend-unavailable" }
	end
	local type_name = native.gobject.g_type_name_from_instance(resolver)
	local backend = type_name ~= nil and ffi.string(type_name) or "unknown"
	-- GDummyProxyResolver always returns DIRECT and is not desktop configuration.
	if backend == "GDummyProxyResolver" then
		return { ok = false, error = "proxy-backend-unavailable", backend = backend }
	end
	local error_slot = ffi.new("ErgoptiProxyError *[1]")
	local proxies = native.gio.g_proxy_resolver_lookup(resolver, url, nil, error_slot)
	local native_error = error_slot[0]
	local receipt = { ok = false, error = "proxy-lookup-failed", backend = backend }
	if native_error ~= nil then
		receipt.native_error_code = tonumber(native_error.code)
		native.glib.g_error_free(native_error)
	end
	if proxies ~= nil then
		local values = {}
		local valid = native_error == nil
		local index = 0
		while proxies[index] ~= nil do
			local value = ffi.string(proxies[index])
			if #values >= 128 or #value > 65536 or value:find("[%z\r\n]") then
				valid = false
				break
			end
			values[#values + 1] = value
			index = index + 1
		end
		native.glib.g_strfreev(proxies)
		if valid and #values > 0 then
			receipt = {
				ok = true, proxies = values, backend = backend,
				acknowledgement = "native-selection",
				failure_provenance = "unavailable",
			}
		end
	end
	return receipt
end

--- Observes the actual curl executable's version in an owned shell-free child.
--- The outer helper deadline owns this process group. The native event loop
--- retains the child until exit and its captured pipes/handles have closed.
--- @return table
local function curl_capabilities()
	local loaded, uv = pcall(require, "luv")
	if not loaded then return { proxy_used = false } end
	local stdout, stderr = uv.new_pipe(false), uv.new_pipe(false)
	if not stdout or not stderr then
		if stdout then uv.close(stdout) end
		if stderr then uv.close(stderr) end
		uv.run()
		return { proxy_used = false }
	end
	local output, bytes, code, exited = "", 0, nil, false
	local process, pid
	local function close(handle)
		if handle and not uv.is_closing(handle) then uv.close(handle) end
	end
	local function refuse()
		if pid and not exited then uv.kill(pid, "sigkill") end
		close(stdout)
		close(stderr)
	end
	process, pid = uv.spawn("curl", {
		args = { "--disable", "--version" }, stdio = { nil, stdout, stderr },
	}, function(exit_code, signal)
		exited, code = true, signal == 0 and exit_code or -1
		close(process)
	end)
	if not process or not pid then close(stdout); close(stderr); uv.run(); return { proxy_used = false } end
	for _, stream in ipairs({ { stdout, true }, { stderr, false } }) do
		local pipe = stream[1]
		local is_output = stream[2]
		local accepted, err = uv.read_start(pipe, function(native_error, chunk)
			if native_error then refuse(); return end
			if not chunk then close(pipe); return end
			bytes = bytes + #chunk
			if bytes > 8192 then refuse(); return end
			if is_output then output = output .. chunk end
		end)
		if accepted == nil or accepted == false or err ~= nil then refuse() end
	end
	uv.run()
	local major, minor, patch = output:match("^curl (%d+)%.(%d+)%.(%d+) ")
	if code ~= 0 or not major then return { proxy_used = false } end
	major, minor, patch = tonumber(major), tonumber(minor), tonumber(patch)
	return {
		version = string.format("%d.%d.%d", major, minor, patch),
		proxy_used = major > 8 or (major == 8 and minor >= 7),
	}
end

-- Bounded stdin keeps the destination and any signed query out of argv, logs
-- and temporary files. The HTTP owner admits schemes before this native seam.
local bytes = io.stdin:read(65537)
local decoded, request = pcall(Json.decode, bytes or "")
if not decoded or type(request) ~= "table" or type(request.url) ~= "string"
	or request.url == "" or #bytes > 65536 or request.url:find("[%z\r\n]") then
	emit({ ok = false, error = "proxy-request-invalid" })
	os.exit(0)
end
local succeeded, receipt = pcall(lookup, request.url, request.environment_exclusions)
if succeeded and request.probe_curl == true then
	local probed, capabilities = pcall(curl_capabilities)
	receipt.curl_capabilities = probed and capabilities or { proxy_used = false }
end
emit(succeeded and receipt or { ok = false, error = "proxy-native-failed" })
