local base = assert(os.getenv("ERGOPTI_PROBE_REPO")) .. "/static/ergopti_plus/"
package.path = base .. "linux/?.lua;" .. base .. "linux/?/init.lua;" .. base .. "_shared/lua/?.lua;" .. base .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local uv, json = require("luv"), require("json")
local Helpers = require("tests.helpers")
local results = {}
for _, scenario in ipairs({ "directory-positive", "single-file", "initially-missing-directory" }) do
 local parent = assert(uv.fs_mkdtemp("/var/tmp/eg-start-XXXXXX"))
 local target = parent .. "/personal"
 local file = target .. "/rules.toml"
 if scenario == "single-file" then target = parent .. "/rules.toml"; file = target
 elseif scenario == "directory-positive" then assert(uv.fs_mkdir(target, 448)) end
 local function write(content)
  local fh = assert(io.open(file, "w")); assert(fh:write(content)); assert(fh:close())
 end
 if scenario ~= "initially-missing-directory" then write('[personal]\nvalue = "before"\n') end
 local watcher = Helpers.load_module_with_dependency("infra.file_watchers", "luv", uv)
 local now, reloads = 0, 0
 watcher.start({ hotstrings_dir = target, personal_dir = target,
  now_ms = function() return now end,
  on_reload = function() reloads = reloads + 1 end })
 local paths = {}
 uv.walk(function(handle)
  if uv.handle_get_type(handle) == "fs_event" and uv.is_active(handle) then
   paths[#paths + 1] = assert(uv.fs_event_getpath(handle))
  end
 end)
 table.sort(paths)
 local function step()
  local end_time = uv.hrtime() + 70000000
  repeat uv.run("nowait"); uv.sleep(1) until uv.hrtime() >= end_time
  watcher.pump(); now = now + 600; watcher.pump(); uv.run("nowait")
 end
 if scenario == "initially-missing-directory" then assert(uv.fs_mkdir(target, 448)) end
 write('[personal]\nvalue = "after"\n'); step(); step(); step()
 local after_creation = reloads
 write('[personal]\nvalue = "edited"\n'); step(); step(); step()
 local after_edit = reloads
 local sibling = parent .. "/unrelated.toml"
 local other = assert(io.open(sibling, "w")); assert(other:write('[unrelated]\nvalue = "must not reload"\n')); assert(other:close())
 step(); step(); step()
 results[#results + 1] = { scenario = scenario, path = target, active_paths_at_start = paths,
  after_creation = after_creation, after_edit = after_edit, after_sibling = reloads }
 watcher.stop(); uv.run("nowait"); assert(watcher.stop()); uv.run("nowait")
 assert(uv.fs_unlink(sibling))
 assert(uv.fs_unlink(file))
 if scenario ~= "single-file" then assert(uv.fs_rmdir(target)) end
 assert(uv.fs_rmdir(parent))
 assert(not uv.loop_alive(), "probe leaked native handles")
end
print("PROBE_RECEIPT " .. json.encode(results))
