from pathlib import Path
import hashlib,json,os,subprocess,sys,time
b=Path('/workspace/.ergopti-cloud/resume-personal-watch-topology');source=b/'source';producer=source/'static/ergopti_plus/linux/infra/file_watchers.lua';tests=source/'static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua';candidate=(b/'candidate3-prepared.lua').read_text();corpus=(b/'tests-83.lua').read_bytes();assert tests.read_bytes()==corpus
sha=lambda data:hashlib.sha256(data).hexdigest()
def once(text,old,new):
 assert text.count(old)==1,(old,text.count(old));return text.replace(old,new,1)
mutations=[]
mutations.append(('scan-empty','unacknowledged directory scan',2,once(candidate,'if not called or type(result) ~= "table" then return nil, "personal directory enumeration refused: " .. path end','if not called or type(result) ~= "table" then return {} end')))
mutations.append(('duplicate-admission','duplicate native directory result',1,once(candidate,' or seen[name]','')))
mutations.append(('accepted-burst-gate','pending Personal refusal preserves',1,once(candidate,'if reconciled then _personal_retry_at = nil else _personal_retry_at = _now_ms() + _debounce_sec * 1000 end','if reconciled then _personal_retry_at = nil else _personal_retry_at = _now_ms() + _debounce_sec * 1000; return end')))
mutations.append(('repair-notification','repaired unobserved coverage',1,once(candidate,'_schedule_reload("personal coverage repaired", { _personal_root })','-- Controlled withdrawal of the repaired-coverage consumer notification.')))
mutations.append(('close-ack-ledger','actual retirement ACK',1,once(candidate,'return entry.retired == true','_personal_retiring[entry] = nil\n\treturn entry.retired == true')))
mutations.append(('retirement-retry','native retains owned retirement after',2,once(candidate,'for entry in pairs(_personal_retiring) do _retire_personal(entry) end','-- Controlled withdrawal of retained retirement repair.')))
a=candidate.index('\n\tif entry.epoch ~= _personal_epoch',candidate.index('local function _personal_event'));z=candidate.index('\n\tif err then',a)
mutations.append(('retired-admission','obsolete callback after removal',1,candidate[:a]+candidate[z:]))
# Runtime guard is the first of the three explicit generation checks.
mutations.append(('runtime-generation','old reconciliation cannot rearm',1,candidate.replace('if epoch ~= _personal_epoch then return end','-- Controlled withdrawal of the runtime generation check.',1)))
mutations.append(('constructor-generation','retired initial construction',1,once(candidate,'if epoch ~= _personal_epoch then return false end','-- Controlled withdrawal of the initial-construction generation check.')))
mutations.append(('staging-debounce','file created while a new directory census',1,once(candidate,'_schedule_reload("personal staging activity: " .. changed, { changed })','-- Controlled withdrawal of staging activity from the debounce owner.')))
mutations.append(('nul-census','LF sibling',2,once(candidate,'ls -1A --zero -- ','ls -1A -- ')))
phases=[]
for name,pattern,expected_fail,image in mutations:
 (b/f'withdraw-{name}.lua').write_text(image)
def run(name,runtime,image,pattern=None,expected_fail=0,total=None):
 assert tests.read_bytes()==corpus,'test corpus changed during receiving'
 producer.write_text(image)
 before=sha(producer.read_bytes());start=time.monotonic();cmd=[runtime,str(b/'runner.lua')]+([pattern]if pattern else [])
 with (b/f'{name}-{runtime}.stdout.log').open('wb')as out,(b/f'{name}-{runtime}.stderr.log').open('wb')as err:
  completed=subprocess.run(cmd,cwd=source/'static/ergopti_plus/linux',stdout=out,stderr=err,check=False)
 lines=(b/f'{name}-{runtime}.stdout.log').read_text().splitlines();result=json.loads(lines[-1]);assert sha(producer.read_bytes())==before;assert tests.read_bytes()==corpus
 row={'name':name,'runtime':runtime,'command':cmd,'producer_sha256':before,'test_sha256':sha(corpus),'exit_code':completed.returncode,'passed':result['passed'],'failed':result['failed'],'failures':result['failures'],'elapsed_seconds':round(time.monotonic()-start,3),'stdout_sha256':sha((b/f'{name}-{runtime}.stdout.log').read_bytes()),'stderr_sha256':sha((b/f'{name}-{runtime}.stderr.log').read_bytes()),'expected_failed_for_control':expected_fail}
 (b/f'{name}-{runtime}-status.json').write_text(json.dumps(row,indent=2)+'\n');phases.append(row)
 print(json.dumps({key:row[key]for key in('name','runtime','exit_code','passed','failed')}),flush=True)
 good=result['failed']==expected_fail and completed.returncode==(1 if expected_fail else 0)
 if total is not None:good=good and result['passed']+result['failed']==total
 if expected_fail:good=good and result['passed']==0
 if not good:raise RuntimeError('unexpected native result: '+name+' '+runtime)
try:
 for runtime in('lua','luajit'):run('final-candidate',runtime,candidate,total=83)
 for name,pattern,expected_fail,image in mutations:
  for runtime in('lua','luajit'):run('withdraw-'+name,runtime,image,pattern,expected_fail)
 for runtime in('lua','luajit'):run('final-restored',runtime,candidate,total=83)
finally:
 producer.write_text(candidate)
 (b/'final-matrix.json').write_text(json.dumps({'source_commit':'b666a22f72cf3b27e55bef08720f7064348d1d40','candidate_sha256':sha(candidate.encode()),'test_sha256':sha(corpus),'phases':phases,'restoration_sha256':sha(producer.read_bytes()),'state':'COMPLETE'if len(phases)==26 else'INCOMPLETE'},indent=2)+'\n')
