from pathlib import Path
import subprocess,json,os
r=Path('/workspace/ergopti-macos-cloner-i18n');s=Path('/workspace/scratch/oct28-input-source-contracts');rows=[];env=os.environ.copy();env['PATH']='/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH'];env['USER']='agent';env['LOGNAME']='agent'
for p in sorted((r/'static/ergopti_plus/macos/tests/unit/modules/keymap/layout').glob('test_input_sources*.lua')):
 name=p.stem;target='tests.unit.modules.keymap.layout.'+name;q=subprocess.run(['lua','tests/run.lua','--only',target],cwd=r/'static/ergopti_plus/macos',env=env,capture_output=True,text=True);(s/(name+'.log')).write_text(q.stdout+q.stderr);rows.append(dict(module=target,exit=q.returncode,summary=[l for l in q.stdout.splitlines() if l.startswith(('Passed tests:','Failed tests:'))]));print(name,q.returncode,rows[-1]['summary'],flush=True)
(s/'input-unit-results.json').write_text(json.dumps(rows,indent=2)+'\n')
