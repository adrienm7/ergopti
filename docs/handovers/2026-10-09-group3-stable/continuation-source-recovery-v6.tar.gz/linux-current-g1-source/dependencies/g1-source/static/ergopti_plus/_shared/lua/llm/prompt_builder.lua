--- _shared/lua/llm/prompt_builder.lua

--- ==============================================================================
--- MODULE: PromptBuilder — Shared Lua Implementation
--- DESCRIPTION:
--- Canonical Lua implementation of the LLM request parameter builder, shared
--- between the Hammerspoon driver and any future Lua-based driver (Linux, etc.).
--- Derives all backend request parameters from the current buffer and a
--- configuration object. No OS calls; fully deterministic and unit-testable.
---
--- This module is the Lua counterpart of _shared/core/domain/PromptBuilder.js.
--- All constants and algorithms MUST stay in sync with the JS reference.
---
--- CONSTANTS (canonical — all drivers MUST use these exact values):
---   CONTEXT_TAIL_WORDS      = 5
---   DEFAULT_MAX_TOKENS      = 150
---   MIN_MAX_TOKENS          = 15
---   WORDS_TO_TOKENS_RATIO   = 6
---   TOKEN_BUDGET_OVERHEAD   = 10
---   TEMP_DIVERSITY_CAP      = 1.0
---   TEMP_INCREMENT_PER_PRED = 0.1
---   GREEDY_TEMP_THRESHOLD   = 0.15
---   CONTEXT_CHARS_PER_WORD  = 40
---   CONTEXT_MIN_CHARS       = 100
--- ==============================================================================

local M = {}

local text_utils = require("text_utils")




-- =============================================
-- =============================================
-- ======= 1/ Module Constants =================
-- =============================================
-- =============================================

-- Number of words from the buffer tail kept as rolling context window
M.CONTEXT_TAIL_WORDS = 5

-- Token budget when max_words is uncapped (= 0)
M.DEFAULT_MAX_TOKENS = 150

-- Hard floor on the token budget regardless of word settings
M.MIN_MAX_TOKENS = 15

-- Conservative words-to-tokens multiplier for token budget estimation
M.WORDS_TO_TOKENS_RATIO = 6

-- Fixed overhead appended to the computed token budget
M.TOKEN_BUDGET_OVERHEAD = 10

-- Upper bound when auto_raise_temperature is active
M.TEMP_DIVERSITY_CAP = 1.0

-- Temperature step per extra prediction requested beyond 1
M.TEMP_INCREMENT_PER_PRED = 0.1

-- Greedy threshold: snap temperature to 0 when single prediction and temp <= this
M.GREEDY_TEMP_THRESHOLD = 0.15

-- Chars of context allocated per predicted output word
M.CONTEXT_CHARS_PER_WORD = 40

-- Hard floor: always forward at least this many context characters
M.CONTEXT_MIN_CHARS = 100




-- =============================================
-- =============================================
-- ======= 2/ Internal Helpers =================
-- =============================================
-- =============================================

--- Extracts the last CONTEXT_TAIL_WORDS words from the buffer.
--- Returns both the ordered word list and the concatenated tail string.
--- @param buffer string The current typing buffer.
--- @return table words Ordered list of whitespace-delimited tokens.
--- @return string tail Concatenated last-N-words string.
local function extract_tail(buffer)
	if not buffer or buffer:match("^%s*$") then
		return {}, ""
	end
	local words = {}
	for w in buffer:gmatch("%S+") do
		table.insert(words, w)
	end
	local start = math.max(1, #words - M.CONTEXT_TAIL_WORDS + 1)
	local tail_words = {}
	for i = start, #words do
		table.insert(tail_words, words[i])
	end
	return words, table.concat(tail_words, " ")
end

--- Computes the token budget from the max_words setting.
--- Returns DEFAULT_MAX_TOKENS when max_words is 0 (unlimited).
--- @param max_words number Maximum predicted words (0 = unlimited).
--- @return number max_tokens The computed token budget.
local function compute_max_tokens(max_words)
	if not max_words or max_words <= 0 then
		return M.DEFAULT_MAX_TOKENS
	end
	return math.max(M.MIN_MAX_TOKENS, max_words * M.WORDS_TO_TOKENS_RATIO + M.TOKEN_BUDGET_OVERHEAD)
end

--- Computes the effective temperature for a request.
--- Optionally raises temperature per extra prediction for diversity,
--- then snaps to 0 for single-prediction greedy decoding.
--- @param base_temperature number User-configured base temperature.
--- @param num_predictions number Number of predictions requested (1+).
--- @param auto_raise boolean True = raise temperature for diversity.
--- @return number The effective temperature to send to the backend.
local function compute_temperature(base_temperature, num_predictions, auto_raise)
	local t = base_temperature

	if auto_raise and num_predictions > 1 then
		t = math.min(
			M.TEMP_DIVERSITY_CAP,
			t + M.TEMP_INCREMENT_PER_PRED * (num_predictions - 1)
		)
	end

	-- Greedy decoding for single prediction and low temperature
	if num_predictions == 1 and t <= M.GREEDY_TEMP_THRESHOLD then
		t = 0
	end

	return t
end

--- Truncates the context to a character limit.
--- context_window_chars, when positive, is an AUTHORITATIVE user override (from
--- the LLM menu's "context length" setting) and takes priority over the
--- max_words heuristic — it was previously accepted as a parameter throughout
--- the call chain (HS shim -> Shared.build_params) but silently dropped here,
--- so setting llm_context_length in the menu had zero effect (F-HIGH-24).
--- With no override (context_window_chars nil/0), falls back to the
--- max_words-proportional heuristic so short prediction budgets keep getting
--- a smaller prefill, unchanged from the pre-fix behaviour.
--- @param buffer string The full context buffer.
--- @param max_words number Max predicted words (0 = unlimited, returns buffer unchanged when context_window_chars is also unset).
--- @param context_window_chars number|nil User-configured hard char cap (0/nil = no override).
--- @return string The possibly truncated context.
local function cap_context(buffer, max_words, context_window_chars)
	if context_window_chars and context_window_chars > 0 then
		if #buffer <= context_window_chars then return buffer end
		return text_utils.utf8_sub(buffer, -context_window_chars)
	end
	if not max_words or max_words <= 0 then return buffer end
	local char_limit = math.max(M.CONTEXT_MIN_CHARS, max_words * M.CONTEXT_CHARS_PER_WORD)
	if #buffer <= char_limit then return buffer end
	return text_utils.utf8_sub(buffer, -char_limit)
end




-- =============================================
-- =============================================
-- ======= 3/ Public API =======================
-- =============================================
-- =============================================

--- Derives all LLM request parameters from the buffer and configuration.
--- This is the Lua equivalent of PromptBuilder.js:buildParams().
---
--- @param buffer string The current typing buffer.
--- @param config table Fields: max_words, min_words, num_predictions, temperature,
---        auto_raise_temp, language, context_window_chars.
--- @return table params Keys: context, context_tail, max_tokens, temperature,
---         min_words, max_words, language, num_predictions.
function M.build_params(buffer, config)
	config = config or {}
	local max_words            = config.max_words            or 0
	local min_words            = config.min_words            or 1
	local num_predictions      = config.num_predictions      or 1
	local temperature          = config.temperature          or 0.1
	local auto_raise           = config.auto_raise_temp      or false
	local language             = config.language             or "fr"
	local context_window_chars = config.context_window_chars or 0

	if temperature == nil then temperature = 0.1 end

	local _, tail   = extract_tail(buffer)
	local context   = cap_context(buffer, max_words, context_window_chars)

	return {
		context          = context,
		context_tail     = tail,
		max_tokens       = compute_max_tokens(max_words),
		temperature      = compute_temperature(temperature, num_predictions, auto_raise),
		min_words        = min_words,
		max_words        = max_words,
		language         = language,
		num_predictions  = num_predictions,
	}
end

--- Composes the chat messages for one request from a resolved system prompt.
---
--- The context goes in exactly one place. Profiles that describe a PREFIX and
--- a TAIL receive them as the user turn, in the shape their examples show;
--- every other profile receives the typed text as the user turn. The system
--- prompt must therefore be resolved with an EMPTY {context}, as macOS does:
--- substituting it there as well sent the text twice. An empty system prompt
--- (the raw profile) is omitted.
---
--- @param system_prompt string|nil Resolved system prompt.
--- @param full_text string The capped context.
--- @param tail_text string|nil The last words of the context.
--- @return table messages Array of { role, content }.
function M.build_messages(system_prompt, full_text, tail_text)
	local system = type(system_prompt) == "string" and system_prompt or ""
	local context = type(full_text) == "string" and full_text or ""
	local user = context
	if system:find("PREFIX", 1, true) and system:find("TAIL", 1, true) then
		user = string.format('PREFIX: "%s"\nTAIL: "%s"', context, type(tail_text) == "string" and tail_text or "")
	end
	local messages = {}
	if system:find("%S") then messages[#messages + 1] = { role = "system", content = system } end
	messages[#messages + 1] = { role = "user", content = user }
	return messages
end

--- Returns cross-driver test vectors matching PromptBuilder.js:promptBuilderTestVectors().
--- Every assertion in the JS reference must hold when executed against M.build_params().
--- @return table vectors Array of test vector objects.
function M.test_vectors()
	return {
		{
			id = "default_config",
			description = "Default config: budget = DEFAULT_MAX_TOKENS, temperature = 0.",
			buffer = "hello world",
			config = { max_words = 0, num_predictions = 1, temperature = 0.1 },
			expected = {
				max_tokens      = M.DEFAULT_MAX_TOKENS,
				temperature     = 0,
				context_tail    = "hello world",
				min_words       = 1,
				num_predictions = 1,
			},
		},
		{
			id = "token_budget_from_max_words",
			description = "max_words=5: budget = max(15, 5*6+10) = 40.",
			buffer = "some context",
			config = { max_words = 5, num_predictions = 1, temperature = 0.5 },
			expected = { max_tokens = 40, temperature = 0.5 },
		},
		{
			id = "min_token_floor",
			description = "max_words=1: budget = max(15, 1*6+10) = 16.",
			buffer = "context",
			config = { max_words = 1, num_predictions = 1, temperature = 0.1 },
			expected = { max_tokens = 16 },
		},
		{
			id = "auto_raise_temperature",
			description = "auto_raise_temp with 3 predictions: t = min(1.0, 0.2 + 0.1*2) = 0.4.",
			buffer = "le chat",
			config = { max_words = 3, num_predictions = 3, temperature = 0.2, auto_raise_temp = true },
			expected = { temperature = 0.4 },
		},
		{
			id = "temperature_diversity_cap",
			description = "auto_raise_temp with high base: capped at TEMP_DIVERSITY_CAP = 1.0.",
			buffer = "le chat",
			config = { max_words = 5, num_predictions = 10, temperature = 0.9, auto_raise_temp = true },
			expected = { temperature = M.TEMP_DIVERSITY_CAP },
		},
		{
			id = "context_truncation",
			description = "Long buffer truncated to max(100, max_words*40) chars.",
			buffer = ("a "):rep(200),
			config = { max_words = 2, num_predictions = 1, temperature = 0.1 },
			expected = { context_length_max = 100 },
		},
		{
			id = "tail_extraction",
			description = "context_tail contains the last 5 words of the buffer.",
			buffer = "word1 word2 word3 word4 word5 word6 word7",
			config = { max_words = 0, num_predictions = 1, temperature = 0.1 },
			expected = { context_tail = "word3 word4 word5 word6 word7" },
		},
		{
			id = "language_passthrough",
			description = "Language from config is passed through unchanged.",
			buffer = "some text",
			config = { language = "en" },
			expected = { language = "en" },
		},
	}
end

return M
