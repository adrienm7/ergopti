"""Finite reviewed source inverse, not a test suite."""
from pathlib import Path
import difflib
import hashlib
import json
base=Path(__file__).resolve().parent
relative='tools/test/test-native-http-clock-evidence.cjs'
before=(base/'preimage'/relative).read_text()
after=(base/'candidate'/relative).read_text()
facts=json.loads((base/'source-inverse.json').read_text())
assert after.count(facts['early_guard'])==1
assert after.count(facts['shared_resolver_import'])==1
assert after.count(facts['two_call_replacements']['after'])==2
inverse=after.replace(facts['early_guard'],'',1).replace(facts['shared_resolver_import'],'',1).replace(facts['two_call_replacements']['after'],facts['two_call_replacements']['before'])
assert inverse==before
(base/'proposal.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative)))
files={p.relative_to(base).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for root in ('preimage','candidate') for p in (base/root).rglob('*') if p.is_file()}
(base/'source-manifest.json').write_text(json.dumps({'state':'SOURCE_ONLY_UNRUN','whole_literal_inverse':True,'original_32_controls_and_assertions_preserved':True,'files':files,'shared_resolver':{'path':'tools/lib/git-bash.cjs','sha256':hashlib.sha256(Path('/workspace/ergopti/tools/lib/git-bash.cjs').read_bytes()).hexdigest()}},indent=2)+'\n')
print(json.dumps({'whole_literal_inverse':True,'original_32_controls_preserved':True,'candidate_sha256':files['candidate/'+relative]['sha256']}))
