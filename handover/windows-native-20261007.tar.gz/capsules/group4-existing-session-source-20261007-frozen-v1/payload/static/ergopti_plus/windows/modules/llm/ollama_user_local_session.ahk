﻿; modules/llm/ollama_user_local_session.ahk
#Requires AutoHotkey v2.0

/** Copies scalar expectations; the native source worker still authenticates. */
OllamaManagedCopyExistingReceipt(Receipt) {
	local source := OllamaRuntimeSourceSpec(Receipt)
	local result := Map("ok", true, "schema", 1, "phase", "published")
	for name, value in source.Spec {
		if !(value is String) && !(value is Integer)
			throw TypeError("Existing runtime expectations require independent scalar values.")
		result[name] := value
	}
	for name in ["Version", "Asset", "CatalogueHash", "ArchiveHash"] {
		if !(Receipt.Get(name, 0) is String)
			throw TypeError("Existing runtime release expectations require scalar strings.")
		result[name] := Receipt[name]
	}
	if !RegExMatch(result["Version"], "\A[0-9]+\.[0-9]+\.[0-9]+\z")
			|| !(result["Asset"] == "windows-amd64" || result["Asset"] == "windows-arm64")
			|| !RegExMatch(result["CatalogueHash"], "\A[0-9a-f]{64}\z")
			|| !RegExMatch(result["ArchiveHash"], "\A[0-9a-f]{64}\z")
		throw ValueError("Existing runtime release expectations are malformed.")
	return result
}

/** Connects verified archive/file phases to the actual managed runtime owner. */
class OllamaUserLocalSession {
	__New(Files, RuntimeOptions, CurrentFn, ConsentFn, OnDispatched, PollMilliseconds, TimerFn := TimerSetCallback) {
		if !(Files is OllamaManagedFilesDefault) || !(RuntimeOptions is Map)
				|| !HasMethod(CurrentFn, "Call") || !HasMethod(ConsentFn, "Call") || !HasMethod(OnDispatched, "Call")
				|| !(PollMilliseconds is Integer) || PollMilliseconds <= 0
				|| !HasMethod(TimerFn, "Call")
			throw TypeError("Local session requires genuine default owners and shared admission callbacks.")
		this.RuntimeOptions := RuntimeOptions.Clone()
		this.Files := Files
		this.CurrentFn := CurrentFn
		this.ConsentFn := ConsentFn
		this.Dispatched := OnDispatched
		this.PollMilliseconds := PollMilliseconds
		this.Record := 0
		this.Generation := 0
		this.Busy := false
		this.Timer := ObjBindMethod(this, "Poll")
		this.TimerFn := TimerFn
		this.Runtime := OllamaManagedRuntime(RuntimeOptions, ObjBindMethod(this, "_RuntimeCurrent"),
			ObjBindMethod(this, "_RuntimeConsent"))
	}

	/** Archive acquisition/HTTP settlement and release data remain shared-owned. */
	Start(Plan, ArchiveFactory := 0) {
		if ArchiveFactory != 0 && (!HasMethod(ArchiveFactory, "Call") || !(Plan is Map)
				|| !(Plan.Get("deadline", 0) is Integer) || Plan["deadline"] <= 0)
			throw TypeError("Official archive acquisition requires its genuine factory and original deadline.")
		if !(Plan is Map) || !(Plan.Get("prepare", 0) is Map) || !(Plan.Get("target", 0) is Map)
				|| !RegExMatch(Plan.Get("version", ""), "\A[0-9]+\.[0-9]+\.[0-9]+\z")
			throw TypeError("Local session requires captured archive and target plans.")
		local previous_critical := Critical("On")
		try {
			if this.Record is Map || this.Files.HasOwner() || this.Files.HasFileDebt() || this.Runtime.HasOwner()
				return false
			if this.Generation == 0x7fffffffffffffff
				throw Error("Local session generation identities are exhausted.")
			local record := Map("generation", ++this.Generation, "prepare", Plan["prepare"].Clone(),
				"target", Plan["target"].Clone(), "version", Plan["version"], "phase", "consent",
				"consented", false, "cancelled", false, "stop_issued", false, "first_error", "", "archive", 0, "archive_building", false)
			this.Record := record
		} finally Critical(previous_critical)
		try {
			if !this._Current(record)
				return false
			local accepted := this.ConsentFn.Call(record["prepare"].Clone(), record["target"].Clone())
			if !(accepted is Integer) || accepted != true || !this._Current(record)
				return false
			record["consented"] := true
			record["phase"] := "preparing"
			if HasMethod(ArchiveFactory, "Call") {
				record["archive_building"] := true
				try record["archive"] := ArchiveFactory.Call(this.Files, this.RuntimeOptions.Clone(),
					ObjBindMethod(this, "_ArchiveCurrent", record), ObjBindMethod(this, "_ArchivePrepared", record),
					this.PollMilliseconds, Plan["deadline"], Plan["version"], record["prepare"]["AssetId"])
				finally record["archive_building"] := false
				if !(record["archive"] is OllamaOfficialArchiveProvider) || !this._Current(record)
						|| !record["archive"].Start(record["prepare"], record["target"],
							OllamaReleaseWindowsAsset(record["prepare"]["AssetId"]), Plan["deadline"])
					return false
			} else if !this.Files.Dispatch("prepare", record["prepare"], this._FileAuthority(record), ObjBindMethod(this, "_Prepared", record))
				return false
			this.TimerFn.Call(this.Timer, -this.PollMilliseconds)
			return true
		} finally {
			if this._Owns(record) && (record["phase"] == "consent" || !this.Files.HasOwner() && !this.ArchiveOwned && record["phase"] == "preparing")
				this._Fault(record, "The source-owned archive preparation refused before dispatch.")
		}
	}

	/** Consumes an issued same-owner prepared ticket through normal publication. */
	StartPrepared(Plan, Ticket) {
		if !(Plan is Map) || !(Plan.Get("prepare", 0) is Map) || !(Plan.Get("target", 0) is Map)
				|| !(Ticket is OllamaIntakePreparedTicket)
				|| !RegExMatch(Plan.Get("version", ""), "\A[0-9]+\.[0-9]+\.[0-9]+\z")
			throw TypeError("Prepared session requires an issued exact intake ticket.")
		local previous := Critical("On")
		try {
			if this.Record is Map || this.Files.HasOwner() || this.Files.HasFileDebt() || this.Runtime.HasOwner()
				return false
			if this.Generation == 0x7fffffffffffffff
				throw Error("Local session generation identities are exhausted.")
			local record := Map("generation", ++this.Generation, "prepare", Plan["prepare"].Clone(),
				"target", Plan["target"].Clone(), "version", Plan["version"], "phase", "consent",
				"consented", false, "cancelled", false, "stop_issued", false, "first_error", "", "archive", 0, "archive_building", false)
			this.Record := record
		} finally Critical(previous)
		try {
			if !this._Current(record)
				return false
			local accepted := this.ConsentFn.Call(record["prepare"].Clone(), record["target"].Clone())
			if !(accepted is Integer) || accepted != true || !this._Current(record)
				return false
			record["consented"] := true
			local receipt := this.Files.ConsumeIntake(Ticket, record["prepare"], record["target"])
			this._Prepared(record, receipt)
			return this._Owns(record) && !record["cancelled"] && record["phase"] == "publishing"
		} finally {
			if this._Owns(record) && record["phase"] == "consent"
				this._Fault(record, "Prepared intake consent or source refused.")
		}
	}

	/** Reuses a freshly inspected published expectation; never prepares/downloads. */
	StartExisting(Plan, Receipt) {
		if !(Plan is Map) || !(Plan.Get("prepare", 0) is Map) || !(Plan.Get("target", 0) is Map)
			throw TypeError("Existing runtime requires a captured source and target plan.")
		local copy := OllamaManagedCopyExistingReceipt(Receipt)
		if copy["Version"] != Plan.Get("version", "") || copy["Asset"] != Plan["prepare"].Get("AssetId", "")
				|| copy["CatalogueHash"] != Plan["prepare"].Get("CatalogueSha256", "")
			throw ValueError("Existing runtime belongs to a different captured canonical release.")
		local target := Plan["target"].Clone()
		target["executable"] := copy["Executable"]
		OllamaRuntimeSourceSpec(copy).ForTarget(target)
		local previous := Critical("On")
		try {
			if this.Record is Map || this.Files.HasOwner() || this.Files.HasFileDebt() || this.Runtime.HasOwner()
				return false
			if this.Generation == 0x7fffffffffffffff
				throw Error("Local session generation identities are exhausted.")
			local record := Map("generation", ++this.Generation, "prepare", Plan["prepare"].Clone(),
				"target", Plan["target"].Clone(), "version", Plan["version"], "phase", "consent",
				"consented", false, "cancelled", false, "stop_issued", false, "first_error", "",
				"archive", 0, "archive_building", false)
			this.Record := record
		} finally Critical(previous)
		local admitted := false
		try {
			if !this._Current(record)
				return false
			local accepted := this.ConsentFn.Call(record["prepare"].Clone(), record["target"].Clone())
			if !(accepted is Integer) || accepted != true || !this._Current(record)
				return false
			record["consented"] := true
			this._Published(record, copy)
			admitted := this._Owns(record) && !record["cancelled"] && this._Current(record)
				&& record["phase"] == "runtime-dispatched"
			return admitted
		} finally {
			if this._Owns(record) && !admitted
				this._Fault(record, "Existing runtime consent or source refused.")
		}
	}

	/** Includes proxy/download/prepare handback, not just the install worker slot. */
	ArchiveOwned {
		get => this.Record is Map && (this.Record.Get("archive_building", false)
			|| IsObject(this.Record.Get("archive", 0)) && this.Record["archive"].HasOwner())
	}
	_ArchiveCurrent(Record, Prepare, Target) {
		if !Record["consented"] || !this._Current(Record)
			return false
		for name in ["ManagedRoot", "CataloguePath", "CatalogueSha256", "AssetId", "TicketId", "MaxExpandedBytes", "MaxEntries"]
			if Type(Prepare.Get(name, 0)) != Type(Record["prepare"].Get(name, 0))
					|| !(Prepare.Get(name, 0) == Record["prepare"].Get(name, 0))
				return false
		for name in ["models_dir", "origin", "port"]
			if Type(Target.Get(name, 0)) != Type(Record["target"].Get(name, 0))
					|| !(Target.Get(name, 0) == Record["target"].Get(name, 0))
				return false
		return this._Current(Record)
	}
	_ArchivePrepared(Record, Ticket) {
		if !this._Owns(Record) || Record["archive_building"] || !Record["consented"]
				|| Record["phase"] != "preparing" || !(Record["archive"] is OllamaOfficialArchiveProvider)
				|| !(Ticket is OllamaIntakePreparedTicket) || Ticket.Row["owner"] != Record["archive"].Intake
				|| !this._Current(Record)
			throw ValueError("Prepared archive callback is early, duplicate, foreign or stale.")
		local receipt := this.Files.ConsumeIntake(Ticket, Record["prepare"], Record["target"])
		this._Prepared(Record, receipt)
		if !this._Owns(Record) || Record["cancelled"] || Record["phase"] != "publishing"
			throw Error("Prepared archive publication was refused.")
	}
	_Owns(Record) {
		return this.Record is Map && this.Record == Record && this.Generation == Record["generation"]
	}

	_Current(Record) {
		if !this._Owns(Record) || Record["cancelled"] || A_IsSuspended
			return false
		local current := this.CurrentFn.Call(Record["prepare"].Clone(), Record["target"].Clone())
		return current is Integer && current == true && this._Owns(Record) && !Record["cancelled"] && !A_IsSuspended
	}

	_FileAllowed(Record, Action, Request) {
		return Record["consented"] && this._Current(Record)
	}

	_FileAuthority(Record) {
		local allowed := ObjBindMethod(this, "_FileAllowed", Record)
		return Map("authorize", allowed, "is_current", allowed)
	}

	_RuntimeCurrent(Target) {
		local record := this.Record
		if !(record is Map) || !this._Current(record)
			return false
		for name in ["executable", "models_dir", "origin", "port"]
			if Target.Get(name, 0) != record["target"].Get(name, 0)
				return false
		return this._Current(record)
	}

	_RuntimeConsent(Target) {
		return this.Record is Map && this.Record["consented"] && this._RuntimeCurrent(Target)
	}

	_Prepared(Record, Receipt) {
		try {
			if !this._Current(Record)
				return this._Fault(Record, "Prepared source became stale.")
			if !(Receipt is Map) || !(Receipt.Get("ok", false) is Integer) || Receipt["ok"] != true
					|| Receipt.Get("phase", "") != "prepared" || Receipt.Get("ticket", "") != Record["prepare"].Get("TicketId", "")
					|| Receipt.Get("version", "") != Record["version"]
					|| Receipt.Get("asset", "") != Record["prepare"].Get("AssetId", "")
					|| !RegExMatch(Receipt.Get("stage_identity", ""), "\A[0-9a-f]{8}:[0-9a-f]{16}\z")
					|| !RegExMatch(Receipt.Get("manifest_sha256", ""), "\A[0-9a-f]{64}\z")
				throw Error("Native archive preparation did not return its complete exact source receipt.")
			local request := Map("ManagedRoot", Record["prepare"]["ManagedRoot"], "TicketId", Receipt["ticket"],
				"StageIdentity", Receipt["stage_identity"], "ManifestSha256", Receipt["manifest_sha256"])
			if Record["target"].Has("models_folder_name") {
				request["ModelsDirectory"] := Record["target"]["models_dir"]
				request["ModelsFolderName"] := Record["target"]["models_folder_name"]
			}
			Record["phase"] := "publishing"
			if !this.Files.Dispatch("publish", request, this._FileAuthority(Record), ObjBindMethod(this, "_Published", Record))
				throw Error("The source-owned logical publication dispatch refused.")
		} catch as Failure {
			; The physical owner already adopted the raw result. Incomplete prepared
			; metadata cannot become unowned installation data merely because the
			; async process ended successfully.
			this.Files.RetainFileDebt(this.Files.CurrentRecord["id"], Failure.Message)
			this._Fault(Record, Failure.Message)
		}
	}

	_Published(Record, Receipt) {
		try {
			if !this._Current(Record)
				return this._Fault(Record, "Published source became stale.")
			local source := OllamaRuntimeSourceSpec(Receipt)
			if Receipt.Get("Version", "") != Record["version"] || Receipt.Get("Asset", "") != Record["prepare"].Get("AssetId", "")
				throw Error("Logical publication belongs to a different captured release.")
			Record["target"]["executable"] := Receipt["Executable"]
			Record["phase"] := "runtime-dispatching"
			if !this.Runtime.Start(Receipt, Record["target"], ObjBindMethod(this, "_RuntimeExit", Record))
				throw Error("The authenticated default runtime dispatch refused.")
			Record["phase"] := "runtime-dispatched"
			; This reports dispatch only. Shared HTTP/model/configuration owners
			; must validate readiness and commit against their original ticket.
			if this._Current(Record)
				this.Dispatched.Call(Record["target"].Clone(), Receipt.Clone())
		} catch as Failure {
			this._Fault(Record, Failure.Message)
		}
	}

	_RuntimeExit(Record, ExitCode, Target) {
		this._Fault(Record, "The exact runtime naturally terminated (exit " . ExitCode . ").")
	}

	_Fault(Record, Message) {
		if !this._Owns(Record)
			return false
		if Record["first_error"] == ""
			Record["first_error"] := Message
		Record["cancelled"] := true
		Record["phase"] := "retiring"
		this.TimerFn.Call(this.Timer, -this.PollMilliseconds)
		return false
	}

	/** Disable/reload revoke logical publication before requesting exact stop. */
	Stop() {
		local record := this.Record
		if !(record is Map)
			return true
		this._Fault(record, "Local runtime lifecycle revoked.")
		this.Poll()
		return !(this.Record is Map)
	}

	Poll() {
		local previous_critical := Critical("On")
		local record := this.Record
		try {
			if !(record is Map) || this.Busy
				return
			this.Busy := true
		} finally Critical(previous_critical)
		local caller_critical := Critical("Off")
		try {
			if !record["cancelled"] && !this._Current(record)
				this._Fault(record, "Local runtime source or pause admission changed.")
			if record["cancelled"] {
				if !record["stop_issued"] {
					record["stop_issued"] := true
					this.Runtime.Invalidate()
				}
				if IsObject(record.Get("archive", 0))
					record["archive"].Stop()
				this.Files.Cancel()
				local physical := this.Files.CurrentRecord
				if physical is Map && physical["phase"] == "prepared"
					this.Files.RetainFileDebt(physical["id"], "Prepared data outlived its cancelled source.")
				if IsObject(this.Runtime.Owner)
					this.Runtime.Owner.Stop()
				if !this.Files.HasOwner() && !this.Runtime.HasOwner() && !this.Files.HasFileDebt() && !this.ArchiveOwned {
					this.Record := 0
					this.TimerFn.Call(this.Timer, 0)
					return
				}
			}
		} finally {
			this.Busy := false
			try {
				if this.Record is Map
					this.TimerFn.Call(this.Timer, -this.PollMilliseconds)
			} finally Critical(caller_critical)
		}
	}
}
