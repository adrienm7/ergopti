﻿; tests/unit/test_archive_intake_ticket.ahk

; ==============================================================================
; MODULE: Intake Prepared-Ticket Recording Controls
; DESCRIPTION:
; Exercises real FilesDefault adoption/consumption with explicit recorded native
; facts. These models do not create a process or establish kernel settlement.
; ==============================================================================

class _AIT_Native extends OllamaIntakeNativePort {
	__New() {
		this.Status := Map("id", 7, "phase", 7, "error", 0, "source_terminal", 1, "source_exit", 0,
			"download_terminal", 1, "download_exit", 0, "download_members", 0, "composite_members", 0,
			"guardian_phase", 6, "activation_claimed", 1, "seal_claimed", 1)
	}
	PollIntake(Id) {
		AssertEqual(Id, 7)
		return this.Status.Clone()
	}
}

class _AIT_Files extends OllamaManagedFilesDefault {
	__New() {
		this.Port := {HasOwner: (*) => false}
		this.NextId := 0
		this.Receipts := []
		this.CurrentRecord := 0
		this.IntakeRows := []
		this.IntakeTickets := Map()
	}
}

class _AIT_Owner extends OllamaArchiveIntake {
	__New() {
		this.Files := _AIT_Files()
		this.Native := _AIT_Native()
		this.Generation := 1
		this.Revoked := false
		this.Current := true
		this.Owned := false
		this.CurrentFn := (*) => this.Current
		this.Record := Map("generation", 1, "native_id", 7, "source_done", true, "cancelled", false,
			"deadline", A_TickCount + 10000, "target", Map("models_dir", "C:\synthetic\models", "origin", "http://127.0.0.1:11434", "port", 11434))
		this.Request := Map("ManagedRoot", "C:\synthetic\root", "CataloguePath", "C:\synthetic\catalogue.json",
			"CatalogueSha256", Format("{:064}", 0), "AssetId", "windows-amd64",
			"TicketId", "0123456789abcdef0123456789abcdef", "MaxExpandedBytes", 1000, "MaxEntries", 10)
		this.Record["request"] := this.Request.Clone()
		this.Record["files_row"] := this.Files.ReserveIntake(this, this.Request, 1)
		this.Record["terminal"] := Map("exit", 0, "stderr", "", "stdout",
			'{"kind":"ollama-intake-inventory","ticket":"0123456789abcdef0123456789abcdef"}' . "`n"
			. '{"ok":true,"phase":"prepared","ticket":"0123456789abcdef0123456789abcdef","asset":"windows-amd64",'
			. '"version":"0.24.0","stage_identity":"12345678:0000000000000001","manifest_sha256":"'
			. Format("{:064}", 0) . '"}' . "`n")
	}
	HasOwner() {
		return this.Owned
	}
	_Current(Record) {
		return this.Current && !Record["cancelled"] && !this.Revoked
	}
	Adopt() {
		return this.Files.AdoptIntake(this, this.Record["files_row"], this.Record["terminal"])
	}
}

_AIT_OnceOnlyConsumption() {
	local owner := _AIT_Owner(), row := owner.Record["files_row"], target := owner.Record["target"].Clone()
	local ticket := owner.Adopt()
	AssertTrue(ticket is OllamaIntakePreparedTicket)
	owner.Record := 0
	AssertEqual(owner.Files.ConsumeIntake(ticket, owner.Request, target)["phase"], "prepared")
	AssertTrue(ticket.Consumed)
	AssertThrows(() => owner.Files.ConsumeIntake(ticket, owner.Request, target))
}

_AIT_ForgedIdentity() {
	local owner := _AIT_Owner(), row := owner.Record["files_row"], target := owner.Record["target"].Clone()
	local genuine := owner.Adopt(), forged := OllamaIntakePreparedTicket(owner.Files, row)
	owner.Record := 0
	AssertThrows(() => owner.Files.ConsumeIntake(forged, owner.Request, target))
	AssertFalse(genuine.Consumed)
}

_AIT_ActualNativePendingCannotIssue() {
	local owner := _AIT_Owner()
	owner.Native.Status["phase"] := 6
	AssertFalse(owner.Adopt())
	AssertEqual(owner.Record["files_row"]["phase"], "retained-file-debt")
	AssertEqual(owner.Files.IntakeTickets.Count, 0)
}

_AIT_ActualSourceFailureCannotIssue() {
	local owner := _AIT_Owner()
	owner.Native.Status["source_exit"] := 1
	AssertFalse(owner.Adopt())
	AssertTrue(owner.Files.HasFileDebt())
	AssertEqual(owner.Files.IntakeTickets.Count, 0)
}

_AIT_CancelledAfterPhysicalCompletion() {
	local owner := _AIT_Owner()
	owner.Record["cancelled"] := true
	AssertFalse(owner.Adopt())
	AssertTrue(owner.Files.HasFileDebt())
}

_AIT_CurrentReentryCannotConsumeOldGeneration() {
	local owner := _AIT_Owner(), target := owner.Record["target"].Clone(), ticket := owner.Adopt()
	owner.Record := 0
	owner.CurrentFn := (*) => (++owner.Generation, true)
	AssertThrows(() => owner.Files.ConsumeIntake(ticket, owner.Request, target))
	AssertFalse(ticket.Consumed)
}

_AIT_ForeignRuntimeTarget() {
	local owner := _AIT_Owner(), target := owner.Record["target"].Clone(), ticket := owner.Adopt()
	owner.Record := 0
	target["origin"] := "http://127.0.0.1:9999"
	AssertThrows(() => owner.Files.ConsumeIntake(ticket, owner.Request, target))
	AssertFalse(ticket.Consumed)
}

_AIT_NoRecordStopRevokesIssuedTicket() {
	local owner := _AIT_Owner(), target := owner.Record["target"].Clone(), ticket := owner.Adopt()
	owner.Record := 0
	AssertTrue(owner.Stop())
	AssertTrue(owner.Revoked)
	AssertThrows(() => owner.Files.ConsumeIntake(ticket, owner.Request, target))
	AssertFalse(ticket.Consumed)
}

Test("archive-intake-ticket-once", _AIT_OnceOnlyConsumption)
Test("archive-intake-ticket-forged-identity", _AIT_ForgedIdentity)
Test("archive-intake-ticket-kernel-pending", _AIT_ActualNativePendingCannotIssue)
Test("archive-intake-ticket-source-failure", _AIT_ActualSourceFailureCannotIssue)
Test("archive-intake-ticket-cancelled", _AIT_CancelledAfterPhysicalCompletion)
Test("archive-intake-ticket-current-reentry", _AIT_CurrentReentryCannotConsumeOldGeneration)
Test("archive-intake-ticket-target", _AIT_ForeignRuntimeTarget)
Test("archive-intake-ticket-revoked-after-handback", _AIT_NoRecordStopRevokesIssuedTicket)

_AIT_TypedSuccessCannotAcceptString() {
	local owner := _AIT_Owner()
	owner.Record["terminal"]["stdout"] := StrReplace(owner.Record["terminal"]["stdout"], '"ok":true', '"ok":"1"')
	AssertFalse(owner.Adopt())
	AssertTrue(owner.Files.HasFileDebt())
	AssertEqual(owner.Files.IntakeTickets.Count, 0)
}

_AIT_QuiescenceSurvivesRegistryRetirement() {
	global _SR_TreeHandleOwners
	local task := {}, key := ObjPtr(task), state := Map("Started", false, "Starting", false,
		"TerminalClaimed", false, "TreeQuiesced", false, "HandleKey", key)
	local critical_before := A_IsCritical
	try {
		AssertFalse(_SR_TreeHandleOwners.Has(key))
		_SR_TreeHandleOwners[key] := Map("Handle", task, "State", state)
		local probe := _SR_IntakeCaptureQuiescence(task)
		AssertEqual(A_IsCritical, critical_before)
		AssertFalse(probe.Call())
		_SR_TreeRecordQuiesced(state, Map("TreeQuiesced", false))
		AssertFalse(probe.Call())
		AssertTrue(_SR_TreeHandleOwners.Has(key))
		_SR_TreeRecordQuiesced(state, Map("TreeQuiesced", true, "OwnerState", state))
		AssertFalse(_SR_TreeHandleOwners.Has(key))
		AssertTrue(probe.Call())
		AssertThrows(() => _SR_IntakeCaptureQuiescence(task))
	} finally {
		if _SR_TreeHandleOwners.Has(key) && _SR_TreeHandleOwners[key]["Handle"] == task
			_SR_TreeHandleOwners.Delete(key)
	}
}

Test("archive-intake-ticket-typed-success", _AIT_TypedSuccessCannotAcceptString)
Test("archive-intake-quiescence-exact-state-after-retirement", _AIT_QuiescenceSurvivesRegistryRetirement)

_AIT_IssuedRowCannotBeReplaced() {
	local first := _AIT_Owner(), ticket := first.Adopt(), second := _AIT_Owner()
	second.Files := first.Files
	second.Record["files_row"] := second.Files.ReserveIntake(second, second.Request, 1)
	local other_ticket := second.Adopt(), other_row := other_ticket.Row, target := first.Record["target"].Clone()
	ticket.Row := other_row
	other_row["ticket"] := ticket
	first.Record := 0
	second.Record := 0
	AssertThrows(() => first.Files.ConsumeIntake(ticket, first.Request, target))
	AssertFalse(ticket.Consumed)
	AssertFalse(other_ticket.Consumed)
}

Test("archive-intake-ticket-issued-row-cannot-change", _AIT_IssuedRowCannotBeReplaced)

class _AIT_Http extends CurlAsyncRequest {
	__New() {
		this.Completed := true
		this.Aborted := false
		this.Status := 200
		this.CleanupPending := false
		this.Handle := 0
		this.ResponseText := ""
		this.OutputPath := "C:\synthetic\archive.zip"
		this.CleanupCalls := 0
	}
	_Cleanup() {
		this.CleanupCalls += 1
	}
}

_AIT_HttpAdmissionFixture() {
	local owner := _AIT_Owner(), request := _AIT_Http()
	owner.FirstError := ""
	owner.Record["request_http"] := request
	owner.Record["output"] := request.OutputPath
	return Map("owner", owner, "request", request)
}

_AIT_ActualHttpStatusBeforeNativeSeal() {
	for status in [404, 302, 0, "200"] {
		local fixture := _AIT_HttpAdmissionFixture(), owner := fixture["owner"]
		fixture["request"].Status := status
		AssertFalse(owner._CurlSettled(owner.Record))
		AssertTrue(owner.Record["cancelled"])
		AssertEqual(owner.FirstError, "intake_http_status_refused")
	}
}

_AIT_HttpCleanupCannotBecomeNativeSeal() {
	local fixture := _AIT_HttpAdmissionFixture(), owner := fixture["owner"], request := fixture["request"]
	request.CleanupPending := true
	AssertFalse(owner._CurlSettled(owner.Record))
	AssertEqual(request.CleanupCalls, 1)
	AssertFalse(owner.Record["cancelled"])
	request.CleanupPending := false
	AssertTrue(owner._CurlSettled(owner.Record))
	request.OutputPath := "C:\synthetic\foreign.zip"
	AssertFalse(owner._CurlSettled(owner.Record))
}

Test("archive-intake-http-status-before-seal", _AIT_ActualHttpStatusBeforeNativeSeal)
Test("archive-intake-http-cleanup-before-seal", _AIT_HttpCleanupCannotBecomeNativeSeal)


_AIT_ClosedResultFixture() {
	local owner := _AIT_Owner()
	owner.Record["terminal"]["stdout"] := StrReplace(owner.Record["terminal"]["stdout"],
		'"version":', '"metadata":{"members":[{"identity":"synthetic-a"}]},"version":')
	local target := owner.Record["target"].Clone(), ticket := owner.Adopt()
	AssertTrue(ticket is OllamaIntakePreparedTicket)
	owner.Record := 0
	return Map("owner", owner, "target", target, "ticket", ticket)
}

_AIT_IssuedScalarCannotMutate() {
	for name in ["manifest_sha256", "stage_identity"] {
		local fixture := _AIT_ClosedResultFixture(), owner := fixture["owner"], ticket := fixture["ticket"]
		ticket.Row["result"][name] := "foreign-issued-value"
		AssertThrows(() => owner.Files.ConsumeIntake(ticket, owner.Request, fixture["target"]))
		AssertFalse(ticket.Consumed)
		AssertTrue(owner.Files.IntakeTickets.Has(ObjPtr(ticket)))
	}
}

_AIT_IssuedNestedCannotMutate() {
	local fixture := _AIT_ClosedResultFixture(), owner := fixture["owner"], ticket := fixture["ticket"]
	ticket.Row["result"]["metadata"]["members"][1]["identity"] := "foreign-member"
	AssertThrows(() => owner.Files.ConsumeIntake(ticket, owner.Request, fixture["target"]))
	AssertFalse(ticket.Consumed)
	AssertTrue(owner.Files.IntakeTickets.Has(ObjPtr(ticket)))
}

_AIT_CurrentCannotRewriteIssuedData() {
	local fixture := _AIT_ClosedResultFixture(), owner := fixture["owner"], ticket := fixture["ticket"]
	owner.CurrentFn := (*) => (ticket.Row["result"]["metadata"]["members"][1]["identity"] := "reentrant-member", true)
	AssertThrows(() => owner.Files.ConsumeIntake(ticket, owner.Request, fixture["target"]))
	AssertFalse(ticket.Consumed)
}

_AIT_ConsumedDataIsDetached() {
	local fixture := _AIT_ClosedResultFixture(), owner := fixture["owner"], ticket := fixture["ticket"]
	local result := owner.Files.ConsumeIntake(ticket, owner.Request, fixture["target"])
	AssertEqual(result["metadata"]["members"][1]["identity"], "synthetic-a")
	AssertTrue(result != ticket.Row["result"])
	AssertTrue(result["metadata"] != ticket.Row["result"]["metadata"])
	result["metadata"]["members"][1]["identity"] := "caller-edit"
	AssertEqual(ticket.Row["result"]["metadata"]["members"][1]["identity"], "synthetic-a")
	AssertTrue(ticket.Consumed)
}

class _AIT_RetirementNative extends _AIT_Native {
	StopIntake(Id) {
		AssertEqual(Id, 7)
		return true
	}
}

class _AIT_RetirementOwner extends _AIT_Owner {
	__New() {
		super.__New()
		this.Native := _AIT_RetirementNative()
		this.Schedules := 0
		this.TimerStops := 0
	}
	_Schedule() {
		this.Schedules += 1
	}
	_StopTimer() {
		this.TimerStops += 1
		return true
	}
}

_AIT_PhysicalQuiescenceCannotDiscardPendingCapture() {
	local owner := _AIT_RetirementOwner(), record := owner.Record
	local output := record["terminal"]["stdout"], observed := Map("cut", false, "first_error", "")
	record["terminal"] := 0
	record["source_started"] := true
	record["source_done"] := false
	record["source_handback"] := false
	record["curl_handback"] := false
	record["source"] := {requestTerminate: (*) => true}
	record["source_quiescence"] := (*) => true
	record["curl_task"] := 0
	record["request_http"] := 0
	record["native_stop_attempted"] := false
	record["source_stop_attempted"] := false
	record["curl_stop_attempted"] := false
	local capture_dir := _SR_AcquireCaptureDirectory(), claim := 0
	ReadAtQuiescence(Path) {
		try {
			record["cancelled"] := true
			AssertFalse(owner._Retire(record), "Physical quiescence does not deliver source capture.")
			AssertTrue(owner.Record == record)
			AssertFalse(record["source_done"])
			AssertEqual(record["terminal"], 0)
			AssertEqual(record["files_row"]["phase"], "reserved")
			observed["cut"] := true
		} catch Any as Err {
			observed["first_error"] := Err.Message
			throw Err
		}
		return FileRead(Path)
	}
	try {
		FileAppend(output, capture_dir . "output.tmp", "UTF-8-RAW")
		claim := Map("TreeQuiesced", true, "NativeErrors", [], "TaskId", "intake-capture-model",
			"TmpFile", capture_dir . "output.tmp", "CaptureDir", capture_dir, "MaxOutputBytes", 0,
			"ExitCode", 0, "PrivateDiagnostics", true)
		_SR_CompletionInitClaim(claim, _SR_CompletionNewToken(ObjBindMethod(owner, "_SourceDone", record)))
		AssertTrue(_SR_TreeFinishClaim(claim, ReadAtQuiescence))
		AssertEqual(observed["first_error"], "")
		AssertTrue(observed["cut"])
		AssertTrue(owner.Record == record)
		AssertTrue(record["source_done"] && record["source_handback"])
		AssertTrue(record["terminal"] is Map)
		AssertEqual(record["terminal"]["stdout"], Trim(output, Chr(13) . Chr(10)))
		AssertEqual(owner.Schedules, 1)
		AssertTrue(owner._Retire(record))
		AssertEqual(owner.Record, 0)
		AssertTrue(owner.Files.HasFileDebt(), "Cancellation retains the prepared source data.")
		AssertEqual(owner.Files.IntakeTickets.Count, 0)
	} finally {
		if claim is Map {
			claim["CallbackToken"]["Detached"] := true
			_SR_CompletionDispatch(claim)
		}
		if DirExist(capture_dir)
			DirDelete(capture_dir, true)
	}
}

Test("archive-intake-ticket-issued-scalar-immutable", _AIT_IssuedScalarCannotMutate)
Test("archive-intake-ticket-issued-nested-immutable", _AIT_IssuedNestedCannotMutate)
Test("archive-intake-ticket-current-result-reentry", _AIT_CurrentCannotRewriteIssuedData)
Test("archive-intake-ticket-consumed-data-detached", _AIT_ConsumedDataIsDetached)
Test("archive-intake-capture-handback-after-quiescence", _AIT_PhysicalQuiescenceCannotDiscardPendingCapture)


_AIT_StagedTerminalDelivery(FireDone) {
	global _SR_TreeHandleOwners
	local owner := _AIT_RetirementOwner(), record := owner.Record, output := record["terminal"]["stdout"]
	local capture_dir := _SR_AcquireCaptureDirectory(), task := {requestTerminate: (*) => true}, key := ObjPtr(task)
	local state := Map("Started", false, "Starting", false, "Staged", true, "TerminalClaimed", false,
		"TreeQuiesced", false, "HandleKey", key, "TaskId", "intake-staged-" . key,
		"PendingTerminationCallback", 0, "Detached", false, "OnDone", ObjBindMethod(owner, "_SourceDone", record),
		"RootReaped", true, "Executable", "recording-only", "TmpFile", capture_dir . "output.tmp",
		"CaptureDir", capture_dir, "MaxOutputBytes", 0, "ProcessHandle", 0, "ThreadHandle", 0,
		"JobHandle", 0, "Pid", 0, "ExitCode", 0, "PrivateDiagnostics", true)
	local claim := 0, observed := Map("cut", false, "first_error", "")
	record["terminal"] := 0
	record["source"] := task
	record["source_started"] := false
	record["source_done"] := false
	record["source_handback"] := false
	record["curl_handback"] := false
	record["curl_task"] := 0
	record["request_http"] := 0
	record["native_stop_attempted"] := false
	record["source_stop_attempted"] := false
	record["curl_stop_attempted"] := false
	ReadAtQuiescence(Path) {
		try {
			record["cancelled"] := true
			AssertEqual(owner._Retire(record), !FireDone)
			if FireDone {
				AssertTrue(owner.Record == record)
				AssertFalse(record["source_done"])
				AssertEqual(record["terminal"], 0)
			} else {
				AssertEqual(owner.Record, 0)
				AssertFalse(record["source_done"])
			}
			observed["cut"] := true
		} catch Any as Err {
			observed["first_error"] := Err.Message
			throw Err
		}
		return FileRead(Path)
	}
	try {
		AssertFalse(_SR_TreeHandleOwners.Has(key))
		_SR_TreeHandleOwners[key] := Map("Handle", task, "State", state)
		record["source_quiescence"] := _SR_IntakeCaptureQuiescence(task)
		record["source_delivery"] := _SR_IntakeCaptureSourceDelivery(task)
		AssertTrue(record["source_delivery"].Call())
		FileAppend(output, capture_dir . "output.tmp", "UTF-8-RAW")
		claim := _SR_TreeClaimTask(state, FireDone, true)
		claim["TreeQuiesced"] := true
		_SR_TreeRecordQuiesced(state, claim)
		AssertFalse(_SR_TreeHandleOwners.Has(key))
		AssertTrue(record["source_quiescence"].Call())
		AssertEqual(record["source_delivery"].Call(), FireDone)
		AssertTrue(_SR_TreeFinishClaim(claim, ReadAtQuiescence))
		AssertEqual(observed["first_error"], "")
		AssertTrue(observed["cut"])
		if FireDone {
			AssertTrue(owner.Record == record && record["source_done"])
			AssertTrue(record["terminal"] is Map)
			AssertEqual(record["terminal"]["stdout"], Trim(output, Chr(13) . Chr(10)))
			AssertTrue(owner._Retire(record))
			AssertEqual(owner.Record, 0)
		} else {
			AssertFalse(record["source_done"])
			AssertEqual(owner.Schedules, 0)
		}
		AssertTrue(owner.Files.HasFileDebt())
		AssertEqual(owner.Files.IntakeTickets.Count, 0)
	} finally {
		if claim is Map {
			claim["CallbackToken"]["Detached"] := true
			_SR_CompletionDispatch(claim)
		}
		if _SR_TreeHandleOwners.Has(key) && _SR_TreeHandleOwners[key]["Handle"] == task
			_SR_TreeHandleOwners.Delete(key)
		if DirExist(capture_dir)
			DirDelete(capture_dir, true)
	}
}

Test("archive-intake-staged-cancel-keeps-source-delivery", _AIT_StagedTerminalDelivery.Bind(true))
Test("archive-intake-failed-activation-suppresses-delivery", _AIT_StagedTerminalDelivery.Bind(false))
