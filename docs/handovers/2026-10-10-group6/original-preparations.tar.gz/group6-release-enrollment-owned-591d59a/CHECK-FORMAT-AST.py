# Source-only AST guard for root-owned formatter rebind, not a receiving run.
import ast, hashlib, pathlib, sys
expected = pathlib.Path(__file__).with_name("FROZEN-PYTHON-AST.sha256").read_text().strip()
actual = hashlib.sha256(ast.dump(ast.parse(pathlib.Path(sys.argv[1]).read_text()), include_attributes=False).encode()).hexdigest()
if actual != expected:
    raise SystemExit("Formatter changed the frozen Python AST")
print("Frozen Python AST preserved; no receiving execution")
