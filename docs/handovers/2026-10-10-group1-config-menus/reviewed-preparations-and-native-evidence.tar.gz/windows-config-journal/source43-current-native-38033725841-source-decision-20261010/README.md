# Current Windows manual run decision

Manual all-OS run38033725841 / Windows job114159896889 tests `de96b36e8cb51bdd30aec54d7f556e1e21b307a6`, source tree `a591a7b46f902f010c9df31ca9637ff4b08fc234`, equal to feature35b4d125. Root now includes later Dev fixes atf3195538; this CI cannot qualify that entire later source tree. The companion JSON pins the five currently received fixture/guard32 paths and actual tested production/control sources independently.

The eleven old failures map to four fixture premise corrections: obsolete-source expectation includes preserved stamp; script chords author current input before genuine Boot; personal configuration gets one stamp before fresh admission; pack source avoids duplicate stamp. The fifth path inserts genuine captured guard32 timing immediately before the unchanged34-store capacity subject. All original effect/refusal/repair assertions remain required. Exact ordinal positions must come from this run's actual execution manifest.

Previous qualification remains FAILED_INCOMPLETE:10908planned,1905executed,1894passed,11failed,9003unexecuted. Genuine34-store capacity passed in266275.142ms (Apply142033.737 / refusal123130.867); nine acquired-read temporal controls were UNRUN. None of these counts can be transplanted into this run. The22-minute budget and blocked Count/key-index proposals remain unchanged.

## Terminal evidence and receiving decisions

Fetch check annotations only after the Windows job is terminal. Preserve exact API job/run/annotation JSON. Annotation names identify observed failures; they cannot establish executed counts, successful subjects, duration, native temporal overlap, one complete footer, startup/E2E/package/install success or full-suite completion. If logs/artifacts remain Forbidden, state those native results UNOBSERVED rather than asserting zero failures or PASS from a summary.

Once transport becomes available, preserve the raw log and exact execution manifest; use the repository's pinned `validate-ahk-suite-manifest.cjs` on the canonical TAP, not deduplicated console replay. The supplied read-only parser emits diagnostic names/phases/duplicate counts only and always refuses to label that extraction full qualification. Require actual passed/failed/skipped/unexecuted distinctions.

If an old owned failure recurs, first compare the exact tested source pin and annotation name to its unchanged subject; inspect actual fresh schema/publication receipt from retained logs. A SOURCE fixture premise correction is not proof of a native pass. Request a bounded receiving correction only for the observed cause; retain assertions and real side effects. If guard32 or a temporal control fails, retain observed report/Win32activity/observer/repair facts and ask the journal owner to diagnose that precise boundary. If only the watchdog repeats, preserve partial manifest and guard32/34-store phases; request a proven source performance correction and rerun complete native validation, without budget/filter/shard/Count/prototype shortcuts.

The genuine guard32 and temporal controls can run on a real Windows runner. Physical Windows/macOS checks remain for interactions or installation/session permissions absent from the runner, not as a blanket substitute for unresolved CI. No Root/source/index/ref/runtime changes are made by this packet.
