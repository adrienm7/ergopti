﻿; tests/unit/test_ollama_managed_http.ahk

; ==============================================================================
; MODULE: Managed HTTP Handback Recording Controls
; DESCRIPTION:
; Calls the actual owner with a curl-derived request model. No network, process
; or file effect is executed; native loopback/guardian receiving remains separate.
; ==============================================================================

class _OMH_Request extends CurlAsyncRequest {
	__New(World) {
		this.World := World
		this.Method := ""
		this.Url := ""
		this.DispatchPort := Map()
		this.Proxy := ""
		this.ProxySelected := false
		this.Completed := false
		this.Aborted := false
		this.CleanupPending := false
		this.Handle := 0
		this.Status := 0
		this.ResponseText := ""
		this.Sends := 0
		this.Aborts := 0
		this.AllowStop := true
		this.AllowCleanup := true
		this.AutoComplete := false
	}
	Send(Body := "") {
		local boundary := this._DispatchPortFn("before_launch")
		if HasMethod(boundary, "Call")
			boundary.Call(this)
		if this.Aborted
			return false
		this.Sends += 1
		this.Handle := Map("recording_only", true)
		if this.AutoComplete
			this.Complete()
		return true
	}
	Complete() {
		this.Completed := true
		this.Handle := 0
		this.Status := 200
		this.ResponseText := '{"version":"0.24.0"}'
	}
	Abort() {
		this.Aborts += 1
		this.Aborted := true
		if !this.AllowStop
			return false
		this.Completed := true
		this.Handle := 0
		return true
	}
	WaitForResponse(Timeout := 0) {
		AssertEqual(Timeout, 0)
		return this.Completed
	}
	_Cleanup() {
		if this.AllowCleanup
			this.CleanupPending := false
		return !this.CleanupPending
	}
}

class _OMH_World {
	__New() {
		this.Now := 10
		this.Current := true
		this.Done := 0
		this.StopTimer := true
		this.Request := _OMH_Request(this)
		this.Owner := OllamaManagedHttp(Map("poll_ms", 5, "request", ObjBindMethod(this, "Factory"),
			"clock", ObjBindMethod(this, "Clock"), "timer", ObjBindMethod(this, "Timer")))
	}
	Factory() {
		return this.Request
	}
	Clock() {
		return this.Now
	}
	Timer(Callback, Period) {
		AssertTrue(Period <= 0)
		return Period != 0 || this.StopTimer
	}
	IsCurrent() {
		return this.Current
	}
	Result(Receipt) {
		AssertEqual(Receipt["origin"], "http://localhost:11434")
		AssertEqual(Receipt["kind"], "version")
		AssertFalse(this.Owner.HasOwner(), "Exact request handback precedes delivery.")
		this.Done += 1
	}
	Start() {
		return this.Owner.Query("http://localhost:11434", "version", 100,
			ObjBindMethod(this, "IsCurrent"), ObjBindMethod(this, "Result"))
	}
}

_OMH_ActualHandbackDeliversOnce() {
	local world := _OMH_World()
	world.Request.AutoComplete := true
	AssertTrue(world.Start())
	AssertEqual(world.Done, 1)
	world.Owner.Poll()
	AssertEqual(world.Done, 1)
	AssertEqual(world.Request.Sends, 1)
	AssertEqual(world.Request.Url, "http://localhost:11434" . LLM_EnableVersionPath())
}

_OMH_CleanupDebtBlocksDataUntilAck() {
	local world := _OMH_World()
	world.Request.AutoComplete := true
	world.Request.CleanupPending := true
	world.Request.AllowCleanup := false
	AssertTrue(world.Start())
	AssertEqual(world.Done, 0)
	AssertTrue(world.Owner.HasOwner())
	world.Owner.Poll()
	AssertEqual(world.Done, 0)
	world.Request.AllowCleanup := true
	world.Owner.Poll()
	AssertEqual(world.Done, 1)
	AssertFalse(world.Owner.HasOwner())
	AssertEqual(world.Request.Sends, 1)
}

_OMH_CancelRetainsUntilPhysicalAck() {
	local world := _OMH_World()
	AssertTrue(world.Start())
	world.Request.AllowStop := false
	AssertFalse(world.Owner.Cancel())
	AssertTrue(world.Owner.HasOwner())
	AssertEqual(world.Done, 0)
	world.Request.AllowStop := true
	AssertTrue(world.Owner.Cancel())
	AssertFalse(world.Owner.HasOwner())
	AssertEqual(world.Done, 0)
}

_OMH_DeadlineCannotBecomeLateSuccess() {
	local world := _OMH_World()
	AssertTrue(world.Start())
	world.Request.AllowStop := false
	world.Now := 100
	world.Owner.Poll()
	AssertTrue(world.Owner.HasOwner())
	AssertEqual(world.Done, 0)
	world.Request.Complete()
	world.Owner.Poll()
	AssertEqual(world.Done, 0)
	AssertFalse(world.Owner.HasOwner())
}

_OMH_TimerStopRefusalNeverBlessesData() {
	local world := _OMH_World()
	world.Request.AutoComplete := true
	world.StopTimer := false
	AssertTrue(world.Start())
	AssertTrue(world.Owner.HasOwner())
	AssertEqual(world.Done, 0)
	world.StopTimer := true
	world.Owner.Poll()
	AssertEqual(world.Done, 0)
	AssertEqual(world.Owner.LastError, "http_timer_refused")
	AssertFalse(world.Owner.HasOwner())
}

_OMH_OldTimerCannotCancelReplacement() {
	local world := _OMH_World()
	AssertTrue(world.Start())
	local old_timer := world.Owner.Record["timer"]
	AssertTrue(world.Owner.Cancel())
	world.Request := _OMH_Request(world)
	AssertTrue(world.Start())
	old_timer.Call()
	AssertEqual(world.Request.Aborts, 0)
	AssertTrue(world.Owner.HasOwner())
	AssertTrue(world.Owner.Cancel())
}

_OMH_ActualDispatchBoundaryRefusesStale() {
	local world := _OMH_World()
	world.Request.DispatchPort["before_launch"] := (*) => world.Current := false
	AssertFalse(world.Start())
	AssertEqual(world.Request.Sends, 0)
	AssertEqual(world.Done, 0)
	AssertFalse(world.Owner.HasOwner())
}

Test("ollama-managed-http-handback-delivery-once", _OMH_ActualHandbackDeliversOnce)
Test("ollama-managed-http-cleanup-debt-until-ack", _OMH_CleanupDebtBlocksDataUntilAck)
Test("ollama-managed-http-cancel-retains-native", _OMH_CancelRetainsUntilPhysicalAck)
Test("ollama-managed-http-deadline-refuses-late", _OMH_DeadlineCannotBecomeLateSuccess)
Test("ollama-managed-http-timer-stop-refusal", _OMH_TimerStopRefusalNeverBlessesData)
Test("ollama-managed-http-old-timer-no-replacement", _OMH_OldTimerCannotCancelReplacement)
Test("ollama-managed-http-before-launch-current", _OMH_ActualDispatchBoundaryRefusesStale)

_OMH_LastClockCannotAdmitCancelledTicket() {
	local world := _OMH_World(), calls := 0
	try {
		AssertTrue(world.Start())
		local record := world.Owner.Record
		world.Owner.Options["clock"] := () => (++calls == 2 ? world.Owner.Cancel() : 0, world.Now)
		AssertFalse(world.Owner._Current(record))
		AssertEqual(calls, 2)
		AssertTrue(record["cancelled"])
		AssertEqual(world.Done, 0)
	} finally world.Owner.Cancel()
}

_OMH_DeliveryClockCannotLeakAcrossReplacement() {
	local world := _OMH_World(), replace_on_delivery := true, old_done := 0, new_done := 0
	try {
		AssertTrue(world.Owner.Query("http://localhost:11434", "version", 100,
			ObjBindMethod(world, "IsCurrent"), (*) => old_done += 1))
		world.Request.Complete()
		world.Owner.Options["clock"] := () => (
			!(world.Owner.Record is Map) && replace_on_delivery ? (
				replace_on_delivery := false, world.Request := _OMH_Request(world),
				world.Owner.Query("http://localhost:11434", "version", 100,
					ObjBindMethod(world, "IsCurrent"), (*) => new_done += 1)) : 0, world.Now)
		world.Owner.Poll()
		AssertFalse(replace_on_delivery)
		AssertEqual(world.Owner.Generation, 2)
		AssertTrue(world.Owner.HasOwner())
		AssertEqual(world.Request.Sends, 1)
		AssertEqual(old_done, 0)
		AssertEqual(new_done, 0)
	} finally world.Owner.Cancel()
}

Test("ollama-managed-http-last-clock-cancellation", _OMH_LastClockCannotAdmitCancelledTicket)
Test("ollama-managed-http-delivery-generation-fence", _OMH_DeliveryClockCannotLeakAcrossReplacement)
