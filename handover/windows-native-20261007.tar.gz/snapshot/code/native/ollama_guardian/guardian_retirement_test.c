#include "guardian_retirement.h"
#include <stdio.h>
#include <string.h>

typedef struct {
    int host,job,release;
    uint32_t host_calls,job_calls,release_calls;
    char order[32];
    uint32_t used;
} Fixture;
static void Mark(Fixture *f,char value) { if(f->used<sizeof(f->order)-1u)f->order[f->used++]=value; }
static int Host(void *context) { Fixture *f=context;f->host_calls++;Mark(f,'H');return f->host; }
static int Job(void *context) { Fixture *f=context;f->job_calls++;Mark(f,'J');return f->job; }
static int Release(void *context) { Fixture *f=context;f->release_calls++;Mark(f,'R');return f->release; }
static int Init(GFR_Owner *owner,Fixture *f) { GFR_Port p={f,Host,Job,Release};return GFR_Init(owner,p); }
#define CHECK(expression) do { if(!(expression)){fprintf(stderr,"FAIL %s:%d: %s\n",name,__LINE__,#expression);return 0;} } while(0)
static int Live(void) {
    const char *name="live retained host blocks parent release";
    Fixture f={0};GFR_Owner row={0};f.job=1;f.release=1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==0 && f.release_calls==0u && f.job_calls==0u && !row.retired);
    return 1;
}
static int Members(void) {
    const char *name="live job members block parent release";
    Fixture f={0};GFR_Owner row={0};f.host=1;f.release=1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==0 && f.release_calls==0u && !row.retired);
    return 1;
}
static int Query(void) {
    const char *name="query refusal preserves first diagnostic";
    Fixture f={0};GFR_Owner row={0};f.host=1;f.job=-1;f.release=1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==-1 && row.first_error==2u && !row.retired && f.release_calls==0u);
    f.job=1;CHECK(GFR_Poll(&row)==1 && row.first_error==2u && row.retired && f.host_calls==1u);
    return 1;
}
static int Uncertain(void) {
    const char *name="uncertain close is never repeated";
    Fixture f={0};GFR_Owner row={0};f.host=1;f.job=1;f.release=-1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==-1 && row.uncertain && row.first_error==3u);
    f.release=1;CHECK(GFR_Poll(&row)==-1 && f.release_calls==1u && !row.retired);
    return 1;
}
static int Pending(void) {
    const char *name="pending source exit retains parent retirement";
    Fixture f={0};GFR_Owner row={0};f.host=1;f.job=1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==0 && !row.retired && f.release_calls==1u);
    f.host=-1;f.job=-1;f.release=1;
    CHECK(GFR_Poll(&row)==1 && row.retired && f.host_calls==1u && f.job_calls==1u && f.release_calls==2u);
    return 1;
}
static int Once(void) {
    const char *name="retired owner has no repeated effects";
    Fixture f={0};GFR_Owner row={0};f.host=1;f.job=1;f.release=1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==1);CHECK(GFR_Poll(&row)==1 && f.release_calls==1u);
    return 1;
}
static int Initialization(void) {
    const char *name="initialization ownership is explicit";
    Fixture f={0};GFR_Owner row={0};GFR_Port bad={0};
    CHECK(!GFR_Init(&row,bad) && !row.initialized);CHECK(Init(&row,&f));CHECK(!Init(&row,&f));
    return 1;
}
static int Wait(void) {
    const char *name="native wait refusal has no release";
    Fixture f={0};GFR_Owner row={0};f.host=-1;f.job=1;f.release=1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==-1 && row.first_error==1u && !row.host_done && f.release_calls==0u);
    return 1;
}
static int Order(void) {
    const char *name="terminal job-zero and release order is exact";
    Fixture f={0};GFR_Owner row={0};f.host=1;f.job=1;f.release=1;
    CHECK(Init(&row,&f));CHECK(GFR_Poll(&row)==1 && strcmp(f.order,"HJR")==0 && row.host_done && row.job_done);
    return 1;
}
int main(void) {
    int (*tests[])(void)={Live,Members,Query,Uncertain,Pending,Once,Initialization,Wait,Order};
    const char *names[]={"live retained host blocks parent release","live job members block parent release",
        "query refusal preserves first diagnostic","uncertain close is never repeated",
        "pending source exit retains parent retirement","retired owner has no repeated effects",
        "initialization ownership is explicit","native wait refusal has no release",
        "terminal job-zero and release order is exact"};
    size_t i;printf("1..9\n");
    for(i=0u;i<9u;++i){int ok=tests[i]();printf("%s %zu - %s\n",ok?"ok":"not ok",i+1u,names[i]);if(!ok)return 1;}
    return 0;
}
