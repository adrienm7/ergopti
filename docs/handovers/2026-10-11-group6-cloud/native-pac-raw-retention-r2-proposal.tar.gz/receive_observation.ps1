param([Parameter(Mandatory = $true)][string]$SourcePath, [Parameter(Mandatory = $true)][string]$OriginalPath, [switch]$OrderOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Demand([bool]$Condition, [string]$Message) { if (-not $Condition) { throw ('CONTROL_ASSERTION: ' + $Message) } }
function Parse-Source([string]$Path) {
    $Tokens = $null; $Errors = $null
    $Ast = [Management.Automation.Language.Parser]::ParseFile($Path, [ref]$Tokens, [ref]$Errors)
    Demand ($Errors.Count -eq 0) 'Actual source must parse.'
    return $Ast
}
$Ast = Parse-Source $SourcePath
$Original = Parse-Source $OriginalPath
$Assertions = @(
    'Actual compiled PAC identity refused.',
    'Native PAC DOS header refused.',
    'Native PAC x64 PE32+ identity refused.',
    'Native PAC executable, ASLR, high-entropy ASLR, DEP or CFG contract refused.',
    'Native PAC dependency inspector failed.',
    'Native PAC static-runtime system dependency closure refused.'
)
$NativeThrows = @()
foreach ($Message in $Assertions) {
    $Match = @($Ast.FindAll({ param($Node)
        $Node -is [Management.Automation.Language.ThrowStatementAst] -and
        $Node.Extent.Text -ceq ('throw ''' + $Message + '''')
    }, $true))
    Demand ($Match.Count -eq 1) ('Unique original native assertion: ' + $Message)
    $NativeThrows += $Match[0]
}
$CaptureThrows = @($Ast.FindAll({ param($Node)
    $Node -is [Management.Automation.Language.ThrowStatementAst] -and
    $Node.Extent.Text -cin @('throw $IdentityCaptureFailure', 'throw $DependencyCaptureFailure')
}, $true))
Demand ($CaptureThrows.Count -eq 2) 'Both optional capture refusals must remain.'
$Artifact = @($Ast.FindAll({ param($Node)
    $Node -is [Management.Automation.Language.AssignmentStatementAst] -and $Node.Left.Extent.Text -ceq '$Artifact'
}, $true))
Demand ($Artifact.Count -eq 1) 'Original artifact boundary exists once.'
foreach ($Capture in $CaptureThrows) {
    foreach ($Native in $NativeThrows) {
        Demand ($Capture.Extent.StartOffset -gt $Native.Extent.EndOffset) 'Capture refusal must follow EVERY original native output assertion.'
    }
    Demand ($Capture.Extent.EndOffset -lt $Artifact[0].Extent.StartOffset) 'Capture refusal is before artifact/publication IO.'
}
function Native-Commands($Tree) {
    return @($Tree.FindAll({ param($Node)
        $Node -is [Management.Automation.Language.CommandAst] -and (
            $Node.GetCommandName() -cin @('Invoke-PacBuildCommand', 'dumpbin.exe') -or
            $Node.Extent.Text -cin @('& $Executable @Arguments', '& $Executable --identity')
        )
    }, $true) | ForEach-Object { $_.Extent.Text })
}
Demand (((Native-Commands $Ast) | ConvertTo-Json -Compress) -ceq ((Native-Commands $Original) | ConvertTo-Json -Compress)) 'Original native/compiler commands and arguments must be exact, with no replay.'
Write-Output 'PASS source parses; six original native assertions precede both capture refusals; original command census exact'
if ($OrderOnly) { exit 0 }
$Definitions = @($Ast.FindAll({ param($Node)
    $Node -is [Management.Automation.Language.FunctionDefinitionAst] -and $Node.Name -ceq 'Write-PacCommandObservation'
}, $true))
Demand ($Definitions.Count -eq 1) 'Only the reviewed observation helper is loaded.'
. ([ScriptBlock]::Create($Definitions[0].Extent.Text))
$BuildRoot = Join-Path ([IO.Path]::GetTempPath()) ('g6-observation-' + [Guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($BuildRoot) | Out-Null
$Previous = @{}
foreach ($Name in @('GITHUB_SHA', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT', 'GITHUB_JOB')) { $Previous[$Name] = [Environment]::GetEnvironmentVariable($Name) }
try {
    $env:GITHUB_SHA = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'; $env:GITHUB_RUN_ID = '1'; $env:GITHUB_RUN_ATTEMPT = '1'; $env:GITHUB_JOB = 'portable-observation-control'
    $Lines = @('identity decoded stdout', 'Unicode é 🙂', "embedded`r`nstdout line")
    $Failure = Write-PacCommandObservation 'identity-command.json' @('fixed-image', '--identity') 7 $Lines
    Demand ($null -eq $Failure) 'An actual successful observation write returns no failure.'
    $Bytes = [IO.File]::ReadAllBytes((Join-Path $BuildRoot 'identity-command.json'))
    Demand (-not ($Bytes.Length -ge 3 -and $Bytes[0] -eq 239 -and $Bytes[1] -eq 187 -and $Bytes[2] -eq 191)) 'UTF8 output has no BOM.'
    $Text = [Text.UTF8Encoding]::new($false, $true).GetString($Bytes)
    Demand (-not $Text.Contains("`r") -and $Text.EndsWith("`n")) 'Serialized output is LF, with final LF.'
    $Observation = $Text | ConvertFrom-Json -AsHashtable
    Demand (($Observation.Keys | Sort-Object | ConvertTo-Json -Compress) -ceq (@('ci', 'command', 'exit_code', 'stdout_lines', 'stdout_scope') | ConvertTo-Json -Compress)) 'Actual observation schema remains exact.'
    Demand (($Observation.command | ConvertTo-Json -Compress) -ceq (@('fixed-image', '--identity') | ConvertTo-Json -Compress)) 'Existing command arguments are retained.'
    Demand ($Observation.exit_code -eq 7) 'Actual supplied native exit remains 7, without claiming success.'
    Demand (($Observation.stdout_lines | ConvertTo-Json -Compress) -ceq ($Lines | ConvertTo-Json -Compress)) 'Decoded stdout lines retain their exact Unicode and embedded CRLF content.'
    Demand ($Observation.ci.sha -ceq $env:GITHUB_SHA -and $Observation.ci.job -ceq $env:GITHUB_JOB) 'Portable CI field observations remain explicit.'
    Write-Output 'PASS actual helper UTF8/LF/schema; stdout and exit retained; no native execution'
    $Collision = Join-Path $BuildRoot 'blocked.json'
    [IO.Directory]::CreateDirectory($Collision) | Out-Null
    $Failure = Write-PacCommandObservation 'blocked.json' @('fixed-image', '--identity') 0 @('already observed output')
    Demand ($Failure -is [Management.Automation.ErrorRecord]) 'A genuine directory/file IO collision returns its refusal.'
    Demand ([IO.Directory]::Exists($Collision)) 'The foreign directory collision is not removed.'
    Write-Output 'PASS actual observation IO refusal retained without native execution or directory deletion'
} finally {
    foreach ($Name in $Previous.Keys) { [Environment]::SetEnvironmentVariable($Name, $Previous[$Name]) }
    [IO.Directory]::Delete($BuildRoot, $true)
}
Demand (-not [IO.Directory]::Exists($BuildRoot)) 'The exact private helper tree is retired.'
Write-Output 'OBSERVATION_CONTROLS selected=3 passed=3 failed=0 native=false Windows=false'
