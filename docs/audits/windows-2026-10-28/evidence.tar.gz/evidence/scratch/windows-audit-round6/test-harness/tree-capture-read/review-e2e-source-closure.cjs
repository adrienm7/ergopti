const path = require('node:path');
const fs = require('node:fs');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const root = '/workspace/ergopti-windows-r6-tests';
const packet = __dirname;
const {includeClosure} = require(path.join(root, 'tools/test/test-ahk-test-coverage.cjs'));
// Admit canonical physical paths before expanding each include frontier. The
// borrowed helper emits slash-converted A_LineFile targets that can still contain
// file.ahk/../ components on POSIX; Win32 itself resolves those lexically.
const pending = [path.join(root, 'static/ergopti_plus/windows/tests/e2e/run_e2e.ahk')];
const admitted = new Set();
let normalizedTargets = 0;
while (pending.length) {
 const file = path.resolve(pending.pop());
 if (admitted.has(file)) continue;
 assert(fs.statSync(file).isFile(), file);
 admitted.add(file);
 for (const target of includeClosure(file)) {
  const physical = path.resolve(target);
  if (physical !== target) normalizedTargets++;
  if (!admitted.has(physical)) pending.push(physical);
 }
}
const files = [...admitted];
assert(files.length > 20);
assert(!files.some(p => p.endsWith('/adapters/shell_runner.ahk')));
const hashes = {};
for (const file of files) {
 const name = path.relative(root, file).split(path.sep).join('/');
 const actual = fs.readFileSync(file);
 const baseline = cp.execFileSync('git', ['show', '396d825de05a2415a7c1d33980190629b4afdd47:' + name], {cwd:root});
 assert.deepEqual(actual, baseline, name);
 hashes[name] = crypto.createHash('sha256').update(actual).digest('hex');
}
const result = {baseline:'396d825de05a2415a7c1d33980190629b4afdd47', closure_count:files.length, canonicalized_helper_targets:normalizedTargets, shell_runner_loaded:false, every_loaded_file_byte_identical_to_pre_fix_baseline:true, hashes, actual_e2e_receipt:'396-harness-tree-read-e2e:89PASS/1FAIL supplementary native-edit unicode-erase', disposition:'No hotstring source or test changed; this exact E2E code closure was already the pre-fix source. Native Windows qualification is separate.'};
fs.writeFileSync(path.join(packet,'e2e-source-closure-proof.json'), JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({closure_count:files.length,baseline_identical:true,shell_runner_loaded:false}));
