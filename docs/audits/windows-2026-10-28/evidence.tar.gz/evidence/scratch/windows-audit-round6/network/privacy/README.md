# Private Ollama response diagnostics

Commit: `491acb6a7900e4900866b8c023b604c93b7375b6`.

Bug: screen/agent responses already opt into diagnostic redaction, but the actual parser and failed/empty branches admitted private body snippets before consulting that owner. Provider-error results could expose private text again through the later vision failure logger.

Actual AHK2.0.26/Wine: old 034 had one passing successful-response control and four privacy failures. New 048 passed all five. Existing 049–052 passed 15 canonical ownership, 5 provider prefix, 2 ordinary chat parser and 1 structural parser contract cases (28/28 total). Real JSON decoder, formatted logger sink, actual origin custody admission and vision failure-result formatting ran; no network/capture/user data.

Correction: carry existing redaction policy through the parser and all diagnostic branches, retaining safe size diagnostics and typed generic failures. Ordinary unredacted parser behavior remains covered by existing neighbors.

Worker 110 passed proportional static gates and genuine commit hooks at 27 October 2026 00:45:13–00:45:22 Paris. Full Windows native suite and CI remain integration qualification, not claimed locally.

See checkpoint.json for hash-bound actual receipts and production/test snapshots. Format-patch is 491acb6a79.patch. No push by this agent.
