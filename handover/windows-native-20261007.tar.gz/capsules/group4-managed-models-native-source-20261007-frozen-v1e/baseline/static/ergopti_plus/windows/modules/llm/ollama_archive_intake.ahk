﻿; modules/llm/ollama_archive_intake.ahk
#Requires AutoHotkey v2.0

/** Owns the exact root source, staged curl, native composite and preparation. */
class OllamaArchiveIntake {
	__New(Files, Native, Options, Current, OnPrepared) {
		if !(Files is OllamaManagedFilesDefault) || !(Native is OllamaIntakeNativePort)
				|| !(Options is Map) || !HasMethod(Current, "Call") || !HasMethod(OnPrepared, "Call")
				|| !(Options.Get("poll_ms", 0) is Integer) || Options["poll_ms"] <= 0
				|| !(Options.Get("capture_bytes", 0) is Integer) || Options["capture_bytes"] <= 0
				|| !(Options.Get("archive_bytes", 0) is Integer) || Options["archive_bytes"] <= 0
				|| !RegExMatch(Options.Get("powershell", ""), "\A[A-Za-z]:\\")
			throw TypeError("Intake needs its actual pinned owners and explicit policies.")
		this.Files := Files
		this.Native := Native
		this.Options := Options.Clone()
		this.CurrentFn := Current
		this.PreparedFn := OnPrepared
		this.Record := 0
		this.Generation := 0
		this.Timer := ObjBindMethod(this, "Poll")
		this.TimerOwned := false
		this.FirstError := ""
		this.Revoked := false
	}

	Start(Prepare, Target, Deadline) {
		if !(Prepare is Map) || !(Target is Map) || !(Deadline is Integer) || Deadline <= 0
			throw TypeError("Intake requires the captured exact source request.")
		local previous := Critical("On")
		try {
			if this.Record is Map || this.Files.HasOwner() || this.Files.HasFileDebt()
				return false
			if this.Generation == 0x7fffffffffffffff
				throw Error("Intake generation identities are exhausted.")
			local record := Map("generation", ++this.Generation, "request", Prepare.Clone(), "target", Target.Clone(),
				"deadline", Deadline, "native_id", 0, "source", 0, "curl_task", 0, "request_http", 0,
				"source_started", false, "source_done", false, "source_handback", false,
				"source_quiescence", 0, "curl_quiescence", 0, "source_delivery", 0,
				"curl_handback", false, "source_stop_attempted", false, "curl_stop_attempted", false,
				"native_stop_attempted", false, "cancelled", false, "building", true, "busy", false,
				"inventory", 0, "output", "", "terminal", 0, "files_row", 0, "phase", "reserved")
			this.Record := record
			this.Revoked := false
		} finally Critical(previous)
		local accepted := false
		try {
			record["files_row"] := this.Files.ReserveIntake(this, record["request"], record["generation"])
			record["native_id"] := this.Native.Reserve(Prepare["TicketId"], Prepare["CatalogueSha256"])
			if !this._Current(record)
				return false
			local args := this._SourceArguments(record)
			record["source"] := ShellRunner_StageTreeOwned(this.Options["powershell"], args,
				ObjBindMethod(this, "_SourceDone", record), this.Options["capture_bytes"], true, true)
			record["source_quiescence"] := _SR_IntakeCaptureQuiescence(record["source"])
			record["source_delivery"] := _SR_IntakeCaptureSourceDelivery(record["source"])
			_SR_IntakeConfigureTask(record["source"], ObjBindMethod(this.Native, "AttachSource", record["native_id"]),
				ObjBindMethod(this.Native, "BindSource", record["native_id"]))
			_SR_GuardianConfigureDaemon(record["source"], ObjBindMethod(this, "_ClaimSource", record))
			if !record["source"].stage() || !this._Current(record)
				return false
			accepted := record["source"].start() == true
			record["source_started"] := accepted
			if !accepted || !this._Current(record)
				return false
			record["phase"] := "inventory-pending"
			return true
		} catch Any as Err {
			this._Fault(record, "intake_source_dispatch_refused")
			return false
		} finally {
			record["building"] := false
			try {
				if !accepted || !this._Current(record)
					this._Fault(record, "intake_source_start_refused")
			} catch Any as Err {
				this._Fault(record, "intake_source_admission_refused")
			} finally this._Schedule()
		}
	}

	_SourceArguments(Record) {
		local pin := this.Native.Pins, request := Record["request"]
		local args := ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
			"-File", pin["SourceWorker"]["path"], "-Mode", "intake", "-RootPath", request["ManagedRoot"],
			"-RootIdentity", "pending", "-Ticket", request["TicketId"], "-StageIdentity", "pending",
			"-ManifestHash", request["CatalogueSha256"], "-DescriptorIdentity", "pending",
			"-DescriptorHash", request["CatalogueSha256"], "-MappingHandle", "0", "-ReadyHandle", "0",
			"-ReleaseHandle", "0", "-ParentHandle", "0", "-CataloguePath", request["CataloguePath"],
			"-AssetId", request["AssetId"], "-MaxExpandedBytes", String(request["MaxExpandedBytes"]),
			"-MaxEntries", String(request["MaxEntries"]), "-OriginalDeadline", String(Record["deadline"]),
			"-PollMilliseconds", String(this.Options["poll_ms"])]
		for name in ["ManagedBridge", "FilesHelper", "PublicationHelper", "ProducerHelper", "NativeModule", "Guardian", "Launcher"]
			args.Push("-" . name . "Path", pin[name]["path"], "-" . name . "Hash", pin[name]["sha256"])
		return args
	}

	_Owns(Record) {
		return this.Record is Map && this.Record == Record && this.Generation == Record["generation"]
	}
	_Current(Record) {
		local current := this.CurrentFn.Call(Record["request"].Clone(), Record["target"].Clone())
		return current is Integer && current == true && this._Owns(Record) && !Record["cancelled"] && !this.Revoked
			&& !A_IsSuspended && A_TickCount < Record["deadline"]
	}
	_ClaimSource(Record) {
		return this._Current(Record) && this.Native.ClaimSource(Record["native_id"])
	}
	_Fault(Record, Reason) {
		if !this._Owns(Record)
			return false
		if this.FirstError == ""
			this.FirstError := Reason
		Record["cancelled"] := true
		Record["phase"] := "retiring"
		return false
	}

	/** Provider passes a genuine configured curl request; no completion test port. */
	BeginDownload(Request) {
		local record := this.Record
		if !(record is Map) || record["phase"] != "namespace-ready" || !(Request is CurlAsyncRequest)
				|| !this._Current(record) || Request.Handle || Request.Completed
			return false
		if Request.DispatchPort is Map && Request.DispatchPort.Count != 0
			throw ValueError("Intake cannot adopt a foreign curl dispatcher.")
		record["request_http"] := Request
		Request.SetOutputFile(record["output"], this.Options["archive_bytes"])
		Request.DispatchPort := Map("before_launch", ObjBindMethod(this, "_BeforeCurl", record),
			"spawn", ObjBindMethod(this, "_SpawnCurl", record))
		record["phase"] := "download-building"
		try {
			local accepted := Request.Send()
			if !(accepted is Integer) || accepted != true
				return this._Fault(record, "intake_curl_dispatch_refused")
			return true
		} catch Any as Err
			return this._Fault(record, "intake_curl_dispatch_refused")
	}
	_BeforeCurl(Record, Request) {
		if !this._Current(Record)
			Request.Abort()
	}
	_SpawnCurl(Record, Executable, Arguments, Done, UnusedBefore, UnusedAfter, CaptureBytes) {
		if !this._Current(Record) || IsObject(Record["curl_task"])
			throw Error("Intake curl construction has no exact new source request.")
		Record["curl_task"] := ShellRunner_StageTreeOwned(Executable, Arguments,
			ObjBindMethod(this, "_CurlDone", Record, Done), CaptureBytes, true, true)
		local task := Record["curl_task"]
		Record["curl_quiescence"] := _SR_IntakeCaptureQuiescence(task)
		_SR_IntakeConfigureTask(task, ObjBindMethod(this.Native, "AttachDownload", Record["native_id"]),
			ObjBindMethod(this.Native, "BindDownload", Record["native_id"]))
		_SR_GuardianConfigureDaemon(task, ObjBindMethod(this, "_ClaimDownload", Record))
		if !task.stage() || !this._Current(Record) || !this.Native.BeginIntakeGuardian(Record["native_id"])
			throw Error("Intake guardian construction refused.")
		loop {
			local status := this.Native.PollIntake(Record["native_id"])
			if status["error"] || !this._Current(Record)
				throw Error("Intake native READY observation refused.")
			if status["guardian_phase"] == 4
				break
			Sleep(this.Options["poll_ms"])
		}
		Record["phase"] := "downloading"
		return task
	}
	_ClaimDownload(Record) {
		return this._Current(Record) && this.Native.ConfirmOutput(Record["native_id"], Record["output"])
			&& this._Current(Record) && this.Native.ClaimDownload(Record["native_id"])
	}

	_CurlDone(Record, Callback, ExitCode, Stdout, Stderr) {
		Record["curl_handback"] := true
		Callback.Call(ExitCode, Stdout, Stderr)
	}

	_SourceDone(Record, ExitCode, Stdout, Stderr) {
		; Physical data is adopted independently of cancellation/current generation.
		Record["source_done"] := true
		Record["source_handback"] := true
		Record["terminal"] := Map("exit", ExitCode, "stdout", Stdout, "stderr", Stderr)
		if !this._Owns(Record)
			throw Error("Intake source terminal has lost its strong owning record.")
		this._Schedule()
	}

	Poll() {
		local record := this.Record
		if !(record is Map) || record["building"] || record["busy"]
			return
		record["busy"] := true
		try {
			if !record["cancelled"] && !this._Current(record)
				this._Fault(record, "intake_source_or_deadline_changed")
			local status := this.Native.PollIntake(record["native_id"])
			if status["error"]
				this._Fault(record, "intake_native_refused")
			if record["phase"] == "inventory-pending" {
				if record["source_done"]
					throw Error("Source terminated without its held namespace inventory.")
				local output := _SR_IntakeReadOwnedOutput(record["source"]), end_line := InStr(output, "`n")
				if end_line {
					local inventory := JsonParse(SubStr(output, 1, end_line - 1))
					if !this.Native.BindInventory(record["native_id"], inventory, record["request"]["TicketId"])
							|| !this._Current(record) || !this.Native.TransferAndPublish(record["native_id"])
						throw Error("Intake actual namespace/channel admission refused.")
					record["inventory"] := inventory
					record["output"] := this.Native.OutputIntent(record["native_id"])
					record["phase"] := "channel-pending"
				}
			} else if record["phase"] == "channel-pending" && status["phase"] == 2
				record["phase"] := "namespace-ready"
			else if record["phase"] == "downloading" {
				if this._CurlSettled(record) && this.Native.Seal(record["native_id"])
					record["phase"] := "preparing"
			} else if record["phase"] == "preparing" && record["source_done"] {
				record["phase"] := "handback"
				this._RequestRetirement(record)
			}
			if record["cancelled"] || record["phase"] == "handback"
				this._Retire(record)
		} catch Any as Err {
			this._Fault(record, "intake_observation_refused")
			this._RequestRetirement(record)
		} finally {
			record["busy"] := false
			this._Schedule()
		}
	}

	/** Logical HTTP admission cannot replace the separate native curl seal. */
	_CurlSettled(Record) {
		local request := Record["request_http"]
		if !(request is CurlAsyncRequest)
			return this._Fault(Record, "intake_http_owner_refused")
		if !request.Completed
			return false
		if request.Aborted || !(request.Status is Integer) || request.Status != 200
			return this._Fault(Record, "intake_http_status_refused")
		if request.CleanupPending
			request._Cleanup()
		local current := this._Current(Record)
		return current && this._Owns(Record) && Record["request_http"] == request && !Record["cancelled"]
			&& request.Completed && !request.Aborted && request.Status is Integer && request.Status == 200
			&& !IsObject(request.Handle) && !request.CleanupPending && request.ResponseText == ""
			&& request.OutputPath == Record["output"]
	}

	_RequestRetirement(Record) {
		if Record["native_id"] <= 0
			return
		if !Record["native_stop_attempted"] {
			Record["native_stop_attempted"] := true
			this.Native.StopIntake(Record["native_id"])
		}
	}
	_StopTask(Record, Name) {
		local task := Record[Name], key := Name == "source" ? "source" : "curl"
		if !IsObject(task) {
			Record[key . "_handback"] := true
			return true
		}
		local probe := Record[key . "_quiescence"]
		if HasMethod(probe, "Call") && probe.Call()
			Record[key . "_handback"] := true
		if Record[key . "_handback"]
			return true
		if !Record[key . "_stop_attempted"] {
			Record[key . "_stop_attempted"] := true
			if task.requestTerminate()
				Record[key . "_handback"] := true
		}
		return Record[key . "_handback"]
	}
	_SourceCapturePending(Record) {
		if !IsObject(Record["source"]) || (Record["source_done"] && Record["terminal"] is Map)
			return false
		if Record["source_started"]
			return true
		local probe := Record.Get("source_delivery", 0)
		; Failed creation/activation may suppress OnDone. Only the exact captured
		; terminal token can distinguish that path from staged cancellation.
		if !HasMethod(probe, "Call")
			return true
		local pending := probe.Call()
		return !(pending is Integer) || pending != false
	}
	_Retire(Record) {
		if Record["native_id"] <= 0 && !IsObject(Record["source"]) && !IsObject(Record["curl_task"]) {
			this.Files.RefuseIntakeBeforeAcquisition(this, Record["files_row"])
			if !this._StopTimer() || !this._Owns(Record)
				return false
			this.Record := 0
			return true
		}
		this._RequestRetirement(Record)
		this._StopTask(Record, "source")
		this._StopTask(Record, "curl_task")
		local request := Record["request_http"]
		if request is CurlAsyncRequest {
			if !request.Completed
				request.Abort()
			if request.CleanupPending
				request._Cleanup()
			if !request.WaitForResponse(0) || IsObject(request.Handle) || request.CleanupPending
				return false
		}
		local status := this.Native.PollIntake(Record["native_id"])
		if status["phase"] != 7 || !Record["source_handback"] || !Record["curl_handback"]
				|| this._SourceCapturePending(Record)
			return false
		local adopted := this.Files.AdoptIntake(this, Record["files_row"], Record["terminal"])
		if !this._StopTimer() || !this._Owns(Record)
			return false
		this.Record := 0
		if !Record["cancelled"] && adopted is OllamaIntakePreparedTicket
			this.PreparedFn.Call(adopted)
		return true
	}
	Stop() {
		this.Revoked := true
		if this.Record is Map {
			this._Fault(this.Record, "intake_lifecycle_revoked")
			this.Poll()
		}
		return !this.HasOwner()
	}
	HasOwner() {
		return this.Record is Map || this.TimerOwned
	}
	_Schedule() {
		if this.Record is Map {
			this.TimerOwned := true
			try SetTimer(this.Timer, -this.Options["poll_ms"])
			catch Any as Err {
				this._Fault(this.Record, "intake_timer_refused")
				this._RequestRetirement(this.Record)
			}
		}
	}
	_StopTimer() {
		try SetTimer(this.Timer, 0)
		catch Any as Err
			return false
		this.TimerOwned := false
		return true
	}
}
