# Corrected group 6 source joins

Status: bounded source review only. No imports, parser tests, builds, native requests, repository mutations or application performed by this reviewer.

Reviewed immutable manifests:

- Production updater revision 3: `3c167b53a5a6e7db3edd22c5f26d0549ba35fb03254249f7da0326cb8b016378`; patch `e16c72741fb60d231483c8cf8b210bfdcadb6a3f29dd6dc809a9677b80d004d6`.
- Private registry revision 6: `e2f75eb1d7f6948fef7c9c5b8d9e2cfc9300f0fba655b89d87e050674cb5f27f`; patch `26e41e4efdc4eba956da7a3c0f890e1b2ad2a24f213d9cb55d1e9ed2c5090b62`.
- Dual-curl setup proposal 2: `98d8dfc10833d5d02282a613e8c4841558b1efcacd6401a171ccd2ba5323eca7`; setup source `f73fc5a639589acf86b19260f4919bb776c68e4ac25a1ac2769d321f91eab097`.
- Body retirement followup: `830e1b91762fdb3d16e77eacb27bde80e4ccdadd4dd67a325bbf3e589ae7ed0b`; patch `fba6b778c68a53081c28e197f2b84298ce159a6e621537b480a404940b4cc0c7`.

All declared source, preimage, control and patch hashes match. No additional concrete blocker found within the bounded corrections.

Production transfer publication reserves delivery through external physical/source probes, refences exact transaction/work/result, and consumes delivery before callbacks. Manager delivery similarly reserves, rechecks native source after physical acknowledgement, and keeps revoked artifact brands until distinct namespace disposal. Admission precedes predecessor retirement; channel cleanup precedes persistence, with no automatic later commit. Original receiving controls remain unchanged. The fixed installer known-pre-reader refusal is a complementary Archive peer review, not a physical qualification from this review.

Registry source differs from the reviewed revision 5 only by the filepath header and exact single replacement of feeder `ade35` with qualified `08f69`. Private captured lease/reader methods, raw brands, original install deadline, physical acknowledgement conjunction and lexical C pointer authority remain. Standalone feeder qualification does not qualify the composite chain.

Dual-curl changes require exact `libcurl/version` token membership and the original maintained owner's deadline at all namespace checkpoints, including before and after writing the admission receipt. Separate modern official-release and signed Debian legacy authority, isolated loader/library scope and process owner remain unchanged. Consumers require successful setup exit; a retained failed receipt alone is not admission.

Body cancellation returns the fixed descriptor-retirement cause only after existing cleanup when a terminal, never-spawned request still retains its exact descriptor fields. Parent revocation preservation requires curl/pre-start-refusal/started-false plus that exact cause. Generic failed-signal delivery and handle-only acceptance remain. Ordinary and output-hop source additions match. Original actual assertions and success predicates retain order; the additional temporal probe observes real close-pending debt before replacement, then requires full physical retirement, sentinel survival and recovery.

Remaining qualification: production 22 models, registry 29 models and actual full updater chain; dual-curl download/build/loader/native use; modified body 14 actual cases and 14 new model controls. None were executed by this reviewer.
