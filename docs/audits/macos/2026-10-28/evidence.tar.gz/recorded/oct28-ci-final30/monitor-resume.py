import collections,datetime,hashlib,json,subprocess,time
from pathlib import Path
from zoneinfo import ZoneInfo
root=Path('/workspace/scratch/oct28-ci-final30')
for i in range(8):
 p=subprocess.run(['gh','run','view','40727519951','--repo','adrienm7/ergopti','--json','status,conclusion,headSha,jobs'],capture_output=True,text=True)
 if p.returncode:
  print(json.dumps({'exit':p.returncode,'stderr':p.stderr}),flush=True); break
 x=json.loads(p.stdout); assert x['headSha']=='c80cf8dddb3e04df4849ac501cec1ca92b9e1c71'
 now=datetime.datetime.now(ZoneInfo('Europe/Paris'));x['observed_paris']=now.isoformat()
 out=root/('resumed-snapshot-'+now.strftime('%H%M%S')+'.json');out.write_text(json.dumps(x,indent=2)+'\n');(root/'resumed-latest.json').write_text(out.read_text())
 print(json.dumps({'at':now.isoformat(),'status':x['status'],'conclusion':x['conclusion'],'census':dict(collections.Counter(j['conclusion'] or j['status'] for j in x['jobs'])),'native':[{'id':j['databaseId'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'failed_steps':[s['name'] for s in j['steps'] if s['conclusion'] in ['failure','cancelled']]} for j in x['jobs'] if 'E2E tests' in j['name']]}),flush=True)
 if x['status']=='completed': break
 if i<7: time.sleep(45)
