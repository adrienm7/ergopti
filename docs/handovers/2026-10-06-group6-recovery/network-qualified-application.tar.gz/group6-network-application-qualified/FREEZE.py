"""Freeze finite authored payload without copying private captures or stage trees."""
from pathlib import Path
import hashlib,json,tarfile,io,gzip,stat
root=Path(__file__).parent
def sha(data):return hashlib.sha256(data).hexdigest()
paths=sorted(p for p in root.rglob('*') if p.is_file() and 'generated' not in p.relative_to(root).parts and p.name!='SOURCE-INVENTORY.json')
artifacts=[]
for p in paths:
 assert stat.S_ISREG(p.lstat().st_mode)
 data=p.read_bytes();artifacts.append({'path':p.relative_to(root).as_posix(),'sha256':sha(data),'bytes':len(data)})
inventory={'status':'SOURCE_ONLY_APPLICATION_PROPOSAL_WITH_PRIOR_TYPED_QUALIFICATION','artifacts':artifacts}
raw=(json.dumps(inventory,indent=2)+'\n').encode();(root/'SOURCE-INVENTORY.json').write_bytes(raw)
paths.append(root/'SOURCE-INVENTORY.json');paths.sort()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as out:
 for p in paths:
  data=p.read_bytes();item=tarfile.TarInfo('group6-network-application-qualified/'+p.relative_to(root).as_posix());item.size=len(data);item.mode=0o644;item.mtime=0;out.addfile(item,io.BytesIO(data))
output=root/'generated';output.mkdir(exist_ok=True)
target=output/'group6-network-application-qualified.tar.gz'
with target.open('wb') as handle:
 with gzip.GzipFile(filename='',mode='wb',fileobj=handle,mtime=0) as archive:archive.write(stream.getvalue())
print(json.dumps({'inventory_sha256':sha(raw),'members':len(paths),'archive_bytes':target.stat().st_size,'archive_sha256':sha(target.read_bytes()),'archive':str(target)}))
