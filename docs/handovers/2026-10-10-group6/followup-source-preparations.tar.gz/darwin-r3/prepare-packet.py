from pathlib import Path
import difflib,hashlib,json,subprocess
p=Path('/tmp/group6-release-darwin-enrollment-ec170e2d6-r2-deadline'); repo=Path('/workspace/ergopti')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
workflow='.github/workflows/ci-macos.yml'
old=(p/'preimage'/workflow).read_text();assert old==(repo/workflow).read_text()
needle="      - uses: actions/setup-python@v5\n        with:\n          python-version: '3.13'\n      - name: Admit the canonical native toolchain and public inputs"
assert old.count(needle)==1
block='''      # This independent Darwin job executes the frozen portable corpus through
      # the original native guardian even when another archive/PAC step fails.
      - name: Receive selected-release shell corpus and native guardian cancellation
        shell: bash
        run: |
          set -euo pipefail
          node tools/diagnostics/macos_release_stage_native_receiving.cjs \\
            --output "$RUNNER_TEMP/native-selected-release-$ERGOPTI_OLLAMA_EXPECTED_ARCHITECTURE"

      - name: Retain selected-release native ownership receiving
        if: ${{ always() }}
        uses: actions/upload-artifact@v4
        with:
          name: selected-release-native-ownership-${{ matrix.architecture }}-${{ github.run_id }}-${{ github.run_attempt }}
          retention-days: 7
          if-no-files-found: error
          path: ${{ runner.temp }}/native-selected-release-${{ matrix.architecture }}

'''
pre=needle[:needle.index('      - name: Admit')]
new=old.replace(needle,pre+block+'      - name: Admit the canonical native toolchain and public inputs')
q=p/'candidate'/workflow;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(new)
(p/'WORKFLOW-ADDITIVE-BLOCK.txt').write_text(block)
assert new.replace(block,'',1)==old
helper='tools/diagnostics/macos_release_stage_native_receiving.cjs'
assert not (repo/helper).exists()
paths=[workflow,helper]
patch=''
for name in paths:
 before=old if name==workflow else ''
 after=(p/'candidate'/name).read_text()
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name if before else '/dev/null',tofile='b/'+name))
(p/'darwin-enrollment.patch').write_text(patch)
def bind(path):
 b=path.read_bytes();return {'path':str(path),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}
contexts=['tools/diagnostics/macos_owned_process.py','tools/diagnostics/macos_release_stage_route_test.py','static/ergopti_plus/macos/adapters/release_stage.sh','tools/test/test-macos-opaque-network-admission.cjs','tools/lib/python.cjs','.github/workflows/ci.yml']
metadata={'version':1,'kind':'source-only-Darwin-native-owner-enrollment-CODE','head':head,'intended_baseline':'ec170e2d642c5724076fbcd6bb3c48bc39e4a619','candidate_paths':paths,'new_path_absent':helper,'preimage':bind(p/'preimage'/workflow),'postimages':[bind(p/'candidate'/x) for x in paths],'patch':bind(p/'darwin-enrollment.patch'),'workflow_fragment':bind(p/'WORKFLOW-ADDITIVE-BLOCK.txt'),'location':'managed-ollama-native, after Python3.13 setup before first canonical toolchain/public-input step; no needs dependencies; existing arm64/amd64 runner matrix','workflow_adoption':'root/Group5 coordination mandatory; all other workflow bytes exact; no applied changes','contexts':[bind(repo/x) for x in contexts],'contract':bind(p/'CONTRACT.md'),'source_proofs':{'whole_workflow_addition_inverse_exact':True,'original_registered_CJS_controls_unchanged':True,'frozen_python_corpus_unchanged':True,'expected_50_literals_regenerated':False,'shared_owner_edits':0,'product_edits':0,'workflow_existing_budgets_changed':False,'single_receiver_deadline_seconds':120,'direct_child_timeout_supervisor_added':False},'receiving_expected':{'portable_frozen_case_count':50,'skipped_case_count':0,'corpus_native_owner_exit':0,'cancellation_signals':['TERM','INT'],'cancel_native_owner_exit':124,'all_child_close_signals':None,'original_guardian_closed_packet_required':True,'helper_native_os_kill_returned_packet_required':True,'all_inputs_retained':True},'author_execution':{'targets':0,'native':0,'suites':0,'formatters':0,'main_index_ref_edits':0},'qualification':'UNRUN; actual Darwin capabilities, both matrix lanes, actual50/TERM/INT/closure and root format rebind required','limits':['portable shell expectations do not grant genuine native routing/archive/package acceptance','Darwin inherited-PGID only, no escaped-session owner claim','no immediate parent-death monitor','no ABA guarantee','existing workflow45/60minute deadlines untouched; owner original settlement remains unchanged','existing61 source controls remain mandatory Core Ubuntu; this independent step executes50 and native ownership on Darwin']}
(p/'MANIFEST.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'manifest':bind(p/'MANIFEST.json'),'patch':bind(p/'darwin-enrollment.patch'),'postimages':metadata['postimages']}))
