local base = assert(arg[1])
package.preload['infra.shortcuts_scope'] = function()
 return dofile(base .. '/shortcut-preimages/static/ergopti_plus/linux/infra/shortcuts_scope.lua')
end
arg = { 'tests.unit.infra.test_shortcuts_scope' }
dofile(base .. '/focused.lua')
