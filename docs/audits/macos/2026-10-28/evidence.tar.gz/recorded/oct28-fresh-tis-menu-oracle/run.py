from pathlib import Path
import subprocess,json
s=Path('/workspace/scratch/oct28-fresh-tis-menu-oracle');rows=[]
for version in ['before','after']:
 for name in ['test-menu-action-handler-bijection.cjs','test-menu-category-coverage.cjs']:
  p=subprocess.run(['/workspace/toolchain/node-v22.22.2-linux-x64/bin/node',str(s/'run-gate.cjs'),version,name],capture_output=True,text=True,cwd='/workspace/ergopti-macos-integration');(s/(version+'-'+name+'.log')).write_text(p.stdout+p.stderr);rows.append(dict(version=version,gate=name,exit=p.returncode,stdout=p.stdout,stderr=p.stderr));print(version,name,p.returncode,(p.stdout+p.stderr)[-450:])
(s/'gate-results.json').write_text(json.dumps(rows,indent=2)+'\n')
