#include "archive_intake.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

typedef struct {
    HANDLE process,job;
    DWORD pid;
    FILETIME creation;
    uint32_t attached,bound,terminal,exit,process_close_attempted,job_close_attempted;
} GAI_Task;
typedef struct GAI_Row {
    uint64_t id,guardian;
    HANDLE composite;
    uint32_t first_error,stop_attempted,composite_close_attempted,seal_attempted,factory_owned;
    GAI_Phase phase;
    GAI_Task source,download;
    uint32_t late_mode,inventory_attempted,transfer_attempted,remote_count,source_claimed;
    uint32_t shadow_source_close_attempted,shadow_close_uncertain;
    wchar_t ticket[33];
    uint8_t manifest_digest[32],guardian_digest[32];
    GI_Expected *expected;
    uint16_t *paths;
    size_t expected_count,intake_index,root_index;
    GI_Win32Context shadow_context;
    GI_Row shadow;
    HANDLE remote[4];
    HANDLE command_stage;
    uint32_t command_close_attempted,command_published;
    uint32_t last_composite_members,last_download_members;
    GB_Status guardian_status;
    struct GAI_Row *next;
} GAI_Row;
static GAI_Row *GAI_rows;
static uint64_t GAI_last;
static volatile LONG GAI_busy;
_Static_assert(sizeof(GAI_Status)==56u,"Archive intake status ABI");

static int GAI_Enter(void) {
    if(InterlockedCompareExchange(&GAI_busy,1,0)!=0){SetLastError(ERROR_BUSY);return 0;}
    return 1;
}
static void GAI_Leave(void) { InterlockedExchange(&GAI_busy,0); }
static GAI_Row *GAI_Find(uint64_t id) {
    GAI_Row *row;
    for(row=GAI_rows;row!=NULL;row=row->next)if(row->id==id)return row;
    SetLastError(ERROR_INVALID_HANDLE);return NULL;
}
static int GAI_Error(GAI_Row *row,DWORD error) {
    if(error==ERROR_SUCCESS)error=ERROR_INVALID_DATA;
    if(row->first_error==0u)row->first_error=error;
    if(row->phase!=GAI_RETIRED)row->phase=GAI_DEBT;
    SetLastError(row->first_error);return 0;
}
static int GAI_Duplicate(GAI_Row *row,HANDLE source,HANDLE *slot,DWORD access) {
    if(!DuplicateHandle(GetCurrentProcess(),source,GetCurrentProcess(),slot,access,FALSE,0u))
        return GAI_Error(row,GetLastError());
    return 1;
}
static int GAI_Exact(GAI_Row *row,GAI_Task *task,HANDLE process) {
    FILETIME creation,exit,kernel,user;
    if(process==NULL || process==INVALID_HANDLE_VALUE || GetProcessId(process)!=task->pid)
        return GAI_Error(row,ERROR_INVALID_DATA);
    if(!GetProcessTimes(process,&creation,&exit,&kernel,&user))return GAI_Error(row,GetLastError());
    if(CompareFileTime(&creation,&task->creation)!=0)return GAI_Error(row,ERROR_INVALID_DATA);
    return 1;
}
static int GAI_Attach(GAI_Row *row,GAI_Task *task,HANDLE process) {
    FILETIME exit,kernel,user;
    BOOL member=FALSE;
    if(task->process!=NULL || task->attached || row->stop_attempted || row->first_error!=0u)
        return GAI_Error(row,ERROR_INVALID_STATE);
    /* The slot receives every acquired capability before any later failure. */
    if(!GAI_Duplicate(row,process,&task->process,SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION|
        (task==&row->source?PROCESS_DUP_HANDLE:0u)))return 0;
    task->pid=GetProcessId(task->process);
    if(task->pid==0u || !GetProcessTimes(task->process,&task->creation,&exit,&kernel,&user))
        return GAI_Error(row,GetLastError());
    if(WaitForSingleObject(task->process,0u)!=WAIT_TIMEOUT)return GAI_Error(row,ERROR_INVALID_DATA);
    if(!AssignProcessToJobObject(row->composite,process))return GAI_Error(row,GetLastError());
    task->attached=1u;
    if(!IsProcessInJob(task->process,row->composite,&member))return GAI_Error(row,GetLastError());
    return member?1:GAI_Error(row,ERROR_INVALID_DATA);
}
static int GAI_Bind(GAI_Row *row,GAI_Task *task,HANDLE process,HANDLE job) {
    BOOL member=FALSE;
    if(!task->attached || task->bound || task->job!=NULL || row->stop_attempted || row->first_error!=0u)
        return GAI_Error(row,ERROR_INVALID_STATE);
    if(!GAI_Exact(row,task,process))return 0;
    if(!GAI_Duplicate(row,job,&task->job,JOB_OBJECT_QUERY))return 0;
    if(!IsProcessInJob(task->process,task->job,&member))return GAI_Error(row,GetLastError());
    if(!member)return GAI_Error(row,ERROR_INVALID_DATA);
    task->bound=1u;return 1;
}
static int GAI_Close(GAI_Row *row,HANDLE *slot,uint32_t *attempted) {
    if(*slot==NULL)return 1;
    if(*attempted)return GAI_Error(row,ERROR_INVALID_STATE);
    *attempted=1u;
    if(!CloseHandle(*slot))return GAI_Error(row,GetLastError());
    *slot=NULL;return 1;
}
static int GAI_Terminal(GAI_Row *row,GAI_Task *task) {
    DWORD waited,exit;
    if(task->terminal)return 1;
    if(task->process==NULL)return 0;
    waited=WaitForSingleObject(task->process,0u);
    if(waited==WAIT_TIMEOUT)return 0;
    if(waited!=WAIT_OBJECT_0){GAI_Error(row,waited==WAIT_FAILED?GetLastError():ERROR_INVALID_DATA);return -1;}
    if(!GetExitCodeProcess(task->process,&exit)){GAI_Error(row,GetLastError());return -1;}
    task->terminal=1u;task->exit=exit;
    /* Retained process references must not hold private/composite accounting
       above zero after exact terminal/exit observation. Never retry a close. */
    return GAI_Close(row,&task->process,&task->process_close_attempted)?1:-1;
}
static int GAI_Members(GAI_Row *row,HANDLE job,uint32_t *count) {
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION info;
    if(job==NULL)return GAI_Error(row,ERROR_INVALID_HANDLE);
    if(!QueryInformationJobObject(job,JobObjectBasicAccountingInformation,&info,(DWORD)sizeof(info),NULL))
        return GAI_Error(row,GetLastError());
    *count=info.ActiveProcesses;return 1;
}
int GAI_Create(uint32_t records,uint32_t paths,const uint8_t manifest[32],const uint8_t guardian[32],uint64_t *id) {
    GAI_Row *row;
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits;
    if(id==NULL || manifest==NULL || guardian==NULL || records==0u || paths==0u){SetLastError(ERROR_INVALID_PARAMETER);return 0;}
    *id=0u;if(!GAI_Enter())return 0;
    if(GAI_last==(uint64_t)INT64_MAX){GAI_Leave();SetLastError(ERROR_ARITHMETIC_OVERFLOW);return 0;}
    row=calloc(1u,sizeof(*row));
    if(row==NULL){GAI_Leave();SetLastError(ERROR_NOT_ENOUGH_MEMORY);return 0;}
    row->id=++GAI_last;row->next=GAI_rows;GAI_rows=row;*id=row->id;
    /* Reserved row remains discoverable even when channel/job acquisition fails. */
    if(!GB_CreateIntake(records,paths,manifest,guardian,&row->guardian))GAI_Error(row,GetLastError());
    if(row->first_error==0u){
        row->composite=CreateJobObjectW(NULL,NULL);
        if(row->composite==NULL)GAI_Error(row,GetLastError());
        else {
            memset(&limits,0,sizeof(limits));
            limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
            if(!SetInformationJobObject(row->composite,JobObjectExtendedLimitInformation,&limits,(DWORD)sizeof(limits)))
                GAI_Error(row,GetLastError());
        }
    }
    GAI_Leave();return 1;
}
int GAI_Inherited(uint64_t id,HANDLE *map,HANDLE *ready,HANDLE *release,HANDLE *parent) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->first_error==0u && !row->stop_attempted)result=GB_Inherited(row->guardian,map,ready,release,parent);
    GAI_Leave();return result;
}
int GAI_AcquireInheritance(uint64_t id,uint64_t *token) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->first_error==0u && !row->stop_attempted)result=GB_AcquireInheritance(row->guardian,token);
    GAI_Leave();return result;
}
int GAI_ReleaseInheritance(uint64_t id,uint64_t token) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL)result=GB_ReleaseInheritance(row->guardian,token);
    GAI_Leave();return result;
}
int GAI_AttachSource(uint64_t id,HANDLE process) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase==GAI_RESERVED)result=GAI_Attach(row,&row->source,process);
    GAI_Leave();return result;
}
int GAI_BindSource(uint64_t id,HANDLE process,HANDLE job) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase==GAI_RESERVED && GAI_Bind(row,&row->source,process,job)){
        result=row->late_mode?1:GB_Bind(row->guardian,process);
        if(result)row->phase=GAI_SOURCE_BOUND;else GAI_Error(row,GetLastError());
    }
    GAI_Leave();return result;
}
int GAI_AttachDownload(uint64_t id,HANDLE process) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase==GAI_NAMESPACE_READY)result=GAI_Attach(row,&row->download,process);
    GAI_Leave();return result;
}
int GAI_BindDownload(uint64_t id,HANDLE process,HANDLE job) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase==GAI_NAMESPACE_READY && GAI_Bind(row,&row->download,process,job)){
        row->phase=GAI_DOWNLOAD_BOUND;result=1;
    }
    GAI_Leave();return result;
}
int GAI_BeginGuardian(uint64_t id) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase==GAI_DOWNLOAD_BOUND && row->first_error==0u && !row->stop_attempted){
        if(row->late_mode && !GB_IntakeMatchInventory(row->guardian,row->expected,row->expected_count)){
            GAI_Error(row,ERROR_INVALID_DATA);GAI_Leave();return 0;
        }
        result=GB_BeginGuardian(row->guardian,row->composite,row->download.process,row->source.process);
        row->factory_owned=result?1u:0u;
        if(!result)GAI_Error(row,GetLastError());
    }
    GAI_Leave();return result;
}
int GAI_ClaimDownload(uint64_t id) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase==GAI_DOWNLOAD_BOUND && row->first_error==0u && !row->stop_attempted){
        /* Every caller must confirm the intended argv against the validated
           retained namespace before it reaches the once-only activation API. */
        if(!row->late_mode || row->inventory_attempted==2u)
            result=GB_ClaimActivation(row->guardian);
        if(result)row->phase=GAI_DOWNLOADING;
    }
    GAI_Leave();return result;
}
int GAI_RequestSeal(uint64_t id) {
    GAI_Row *row;uint32_t members;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase==GAI_DOWNLOADING && row->first_error==0u && !row->stop_attempted && !row->seal_attempted){
        int terminal=GAI_Terminal(row,&row->download);
        /* Pending is not an attempt, receipt completion, or permission to send
           again. The native observation is polled without any second dispatch. */
        if(terminal==1 && GAI_Members(row,row->download.job,&members) && members==0u){
            row->seal_attempted=1u;
            if(row->download.exit!=0u)GAI_Error(row,ERROR_PROCESS_ABORTED);
            else if(GB_IntakeReleaseSource(row->guardian)){
                row->phase=GAI_SEAL_GRANTED;result=1;
            } else GAI_Error(row,GetLastError());
        }
    }
    GAI_Leave();return result;
}
int GAI_Stop(uint64_t id) {
    GAI_Row *row;int result=0;
    if(!GAI_Enter())return 0;row=GAI_Find(id);
    if(row!=NULL && row->phase!=GAI_RETIRED && !row->stop_attempted){
        row->stop_attempted=1u;
        /* Guardian owns the established content leases. Before its launch,
           terminate only this already retained composite job. */
        int factory_containment=row->guardian!=0u?GB_IntakeHasContainment(row->guardian):0;
        result=row->guardian!=0u?GB_Stop(row->guardian):1;
        if(!factory_containment && row->composite!=NULL){
            uint32_t remaining=UINT32_MAX;
            int observed=GAI_Members(row,row->composite,&remaining);
            if((!observed || remaining!=0u) && !TerminateJobObject(row->composite,125u))
                GAI_Error(row,GetLastError());
        }
        if(row->first_error==0u)row->phase=GAI_STOPPING;
    }
    GAI_Leave();return result;
}
int GAI_Poll(uint64_t id,GAI_Status *status) {
    GAI_Row *row;uint32_t members=UINT32_MAX,download_members=UINT32_MAX;int composite_observed=0;
    if(status==NULL || !GAI_Enter())return 0;row=GAI_Find(id);
    if(row==NULL){GAI_Leave();return 0;}
    if(row->phase!=GAI_RETIRED){
        if(row->guardian==0u)memset(&row->guardian_status,0,sizeof(row->guardian_status));
        else if(!GB_Poll(row->guardian,&row->guardian_status))GAI_Error(row,GetLastError());
        else if(row->guardian_status.first_error!=0u)GAI_Error(row,row->guardian_status.first_error);
        else if(row->phase==GAI_SOURCE_BOUND && row->guardian_status.phase==GB_OFFERED)row->phase=GAI_NAMESPACE_READY;
        if(row->source.process!=NULL)(void)GAI_Terminal(row,&row->source);
        if(row->source.terminal && row->shadow.source!=0u){
            HANDLE value=(HANDLE)row->shadow.source;
            if(GAI_Close(row,&value,&row->shadow_source_close_attempted))row->shadow.source=0u;
            else row->shadow_close_uncertain=1u;
        }
        if(row->download.process!=NULL)(void)GAI_Terminal(row,&row->download);
        if(row->download.job!=NULL)(void)GAI_Members(row,row->download.job,&download_members);
        if(row->composite!=NULL)composite_observed=GAI_Members(row,row->composite,&members);
        else {members=0u;composite_observed=1;}
        row->last_composite_members=members;row->last_download_members=download_members;
        if(row->stop_attempted && (row->guardian==0u || row->guardian_status.phase==GB_RETIRED) && composite_observed && members==0u &&
            row->source.process==NULL && row->download.process==NULL &&
            row->shadow.source==0u && !row->shadow_close_uncertain &&
            (!row->source.attached || row->source.terminal) && (!row->download.attached || row->download.terminal)){
            size_t i;int closed=1;
            if(!GAI_Close(row,&row->command_stage,&row->command_close_attempted))closed=0;
            for(i=0u;i<row->shadow.acquired;++i){
                if(!closed)break;
                GI_Imported *item=&row->shadow.contents[i];
                if(item->handle==0u)continue;
                if(item->attempted){closed=0;break;}
                item->attempted=1u;
                if(row->shadow.port.close(row->shadow.port.context,item->handle)!=1){
                    item->uncertain=1u;row->shadow_close_uncertain=1u;
                    GAI_Error(row,row->shadow_context.first_os_error);closed=0;break;
                }
                item->handle=0u;
            }
            if(closed && GAI_Close(row,&row->source.job,&row->source.job_close_attempted) &&
                GAI_Close(row,&row->download.job,&row->download.job_close_attempted) &&
                GAI_Close(row,&row->composite,&row->composite_close_attempted))row->phase=GAI_RETIRED;
        }
    }
    memset(status,0,sizeof(*status));status->id=row->id;status->phase=(uint32_t)row->phase;
    status->first_error=row->first_error;status->guardian_phase=row->guardian_status.phase;
    status->activation_claimed=row->guardian_status.activation_claimed;
    status->download_terminal=row->download.terminal;status->download_exit=row->download.exit;
    status->download_members=row->last_download_members;status->source_terminal=row->source.terminal;
    status->source_exit=row->source.exit;status->composite_members=row->last_composite_members;status->seal_claimed=row->seal_attempted;
    GAI_Leave();return 1;
}

#include "archive_intake_late.inc"
