# Native head test consumer contract correction

Pinned parent:a550193ebc31aa819c369f701a61ebed72d86216.
Patch:windows-head-test-contracts-v2.patch.
SHA256:d1db59f6bb7e0ba8fe292a9839bb461c7f5ce5bd0ae4643def83efd950deae8f.
Only two Windows test files change; production source, manifest, generated artifacts
and independent corpus bytes are unchanged. Exact preimages/postimages are included.

Actual Windows CI reported two Item-has-no-value exceptions, a head receipt expected4/
actual3, and the HIGH07 literal-action-map source predicate failure. The first two
exceptions come from reading an optional disabled map member directly. Existing native
command row data deliberately omits disabled when false; the tests now explicitly
read the optional member with false as default, retaining both enabled and disabled
behavioral assertions and disabled retained callback refusal.

_MR_RenderRows has always returned its labelled row count: its separator branch adds
a native separator then continues before Added++. The test now checks this existing
receipt3 AND independently calls native GetMenuItemCount to require all four physical
head rows. The original four-row provider count, first command, native separator,
selected captions, exact native positions and picker payload shape assertions remain.
No renderer return contract was changed.

HIGH07 still rejects native Menu construction and registration in the provider. Its
callback requirement now follows each actual command identity through the reachable
shared include/declaration, template materializer, canonical action data and real
RegisterMenuItem dispatch owner. The old literal action map shape was retired by the
shared template migration. Three existing raw-Menu regex strings contained literal U+0008 backspaces instead
of the intended word boundary. V2 replaces those bytes with actual backslash+b.
Original whitespace and parenthesis patterns already contained correct single
backslashes; V1's double-backslash explanation was inaccurate. V1 retained the
backspaces and is rejected; its portable proof substituted intended boundaries.
V2's proof reads the actual frozen patterns, rejects raw Menu() and records how
all three original backspace patterns incorrectly accepted that source mutation.

Portable encoding/BOM, static syntax antipatterns, manifest, action-handler bijection
and AHK registration checks passed. source-guard-probe.py evaluates the actual source
predicate chain:11 normal predicates pass, six causal source mutations are rejected,
and both old literal action predicates reproduce red on actual current source.
This portable probe is not native AHK execution. Independent V2 source review is CLEAR; see /workspace/ergopti-delivery/review-windows-head-contracts/REVIEW.md.
Native Windows tests must be rerun on this exact successor SHA through parent CI.

No physical-device, E2E, packaging or installation qualification is claimed here.
Initial mistyped encoding/static script paths produced module-not-found; the correct
repository checks were subsequently executed and their final logs are retained.
No root checkout/index/ref/CI changes were made by this worker.
