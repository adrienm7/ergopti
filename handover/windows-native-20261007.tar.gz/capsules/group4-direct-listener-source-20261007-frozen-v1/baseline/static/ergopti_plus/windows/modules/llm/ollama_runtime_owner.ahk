﻿; modules/llm/ollama_runtime_owner.ahk

; ==============================================================================
; MODULE: Exact Windows Ollama Runtime Owner Candidate
; DESCRIPTION:
; Owns only one foreground server task through the existing ShellRunner Job
; Object. Shared consent, source identity, immutable version leases, HTTP
; readiness and configuration publication remain with their respective owners.
; This scratch candidate is not registered, parsed or executed on Windows.
; ==============================================================================

#Requires AutoHotkey v2.0

/** Holds one exact server task; accepted launch never means AI is enabled. */
class OllamaRuntimeOwner {
	/**
	 * @param {Map} Options Trusted launcher path is required. Optional native
	 * spawn and error ports are narrow regression boundaries, not new owners.
	 */
	__New(Options) {
		if !(Options is Map) || !this._LocalPath(Options.Get("launcher", ""))
			throw TypeError("Runtime ownership requires a trusted launcher path.")
		if Options.Has("spawn") && !HasMethod(Options.Get("on_retired", 0), "Call")
			throw TypeError("Runtime ownership requires an independent physical retirement observer.")
		for Name in ["spawn", "on_error", "on_retired"]
			if Options.Has(Name) && !HasMethod(Options[Name], "Call")
				throw TypeError("Runtime native port must be callable.", -1, Name)
		this.Options := Options.Clone()
		this.Record := 0
		this.Generation := 0
		if !Options.Has("spawn") {
			if !(Options.Get("native_pins", 0) is Map) || !HasMethod(Options.Get("source_spec", 0), "Call")
					|| !(Options.Get("startup_ms", 0) is Integer) || Options["startup_ms"] <= 0
					|| !(Options.Get("poll_ms", 0) is Integer) || Options["poll_ms"] <= 0
					|| !(Options.Get("source_capture_bytes", 0) is Integer) || Options["source_capture_bytes"] <= 0
				throw TypeError("The default runtime requires genuine source pins and captured lifecycle budgets.")
			local pins := Map()
			for name, pin in Options["native_pins"] {
				if !(pin is Map)
					throw TypeError("Every compiled native image must have its own captured pin.")
				pins[name] := pin.Clone()
			}
			this.Options["native_pins"] := pins
		}
	}

	/**
	 * @param {Map} Target Captured executable, models_dir, origin and port.
	 * @param {Map} Authority Shared owner exposing one-shot authorize and
	 * is_current callbacks. These cover explicit consent, source/pause revisions,
	 * verified immutable-version lease and managed directory authority.
	 * @param {Func} OnExit Optional exact-source native terminal observer.
	 * @returns {Boolean} Launch accepted; HTTP readiness is a separate receipt.
	 */
	Start(Target, Authority, OnExit := 0) {
		PreviousCritical := Critical("Off")
		try return this._StartNonCritical(Target, Authority, OnExit)
		finally Critical(PreviousCritical)
	}

	_StartNonCritical(Target, Authority, OnExit) {
		if !this._ValidTarget(Target) || !(Authority is Map)
				|| !HasMethod(Authority.Get("authorize", 0), "Call")
				|| !HasMethod(Authority.Get("is_current", 0), "Call")
				|| (IsObject(OnExit) && !HasMethod(OnExit, "Call"))
			throw TypeError("Runtime start requires a captured target and source-owned consent.")
		PreviousCritical := Critical("On")
		try {
			; Starting and retained cancellation records block every successor.
			if (this.Record is Map) || A_IsSuspended
				return false
			Record := Map("generation", ++this.Generation,
				"target", Target.Clone(), "authority", Authority.Clone(),
				"on_exit", OnExit, "task", 0, "guardian", 0, "created_at", A_TickCount, "building", true,
				"cancelled", false, "terminal", false, "accepted", false,
				"retirement_busy", false, "retirement_acked", false)
			this.Record := Record
		} finally Critical(PreviousCritical)
		Accepted := false
		try {
			if !this._Current(Record)
				return false
			Permission := Record["authority"]["authorize"].Call(Record["target"].Clone())
			if !this._True(Permission) || !this._Current(Record)
				return false
			Target := Record["target"]
			PowerShell := this.Options.Get("powershell",
				A_WinDir . "\System32\WindowsPowerShell\v1.0\powershell.exe")
			if !this._LocalPath(PowerShell)
				throw ValueError("The native PowerShell executable must be local and absolute.")
			Arguments := ["-NoLogo", "-NoProfile", "-NonInteractive",
				"-ExecutionPolicy", "Bypass", "-File", this.Options["launcher"],
				"-Executable", Target["executable"], "-Port", String(Target["port"]),
				"-ModelsDirectory", Target["models_dir"]]
			Spawn := this.Options.Get("spawn", ObjBindMethod(this, "_NativeSpawn", Record))
			Task := Spawn.Call(PowerShell, Arguments, ObjBindMethod(this, "_OnTerminal", Record))
			if !IsObject(Task) || !HasMethod(Task, "start") || !HasMethod(Task, "terminate")
				throw TypeError("Runtime launch requires an exact tree-owned task.")
			; Construction may pump cancellation. Its returned exact handle still
			; belongs to this old record and must never be assigned to a successor.
			Record["task"] := Task
			if Task is OllamaGuardianTask
				Record["guardian"] := Task
			if !this._Current(Record)
				return false
			Started := Task.start()
			if !this._True(Started) || !this._Current(Record)
				return false
			Record["accepted"] := true
			Accepted := true
			return true
		} catch as Err {
			this._Report("start", Err)
			return false
		} finally {
			Record["building"] := false
			if !Accepted
				this._CancelRecord(Record)
			else if Record["terminal"]
				this._Release(Record)
		}
	}

	/**
	 * Invalidates publication before retiring only the exact retained task.
	 * @returns {Boolean} No runtime task or interrupted construction remains.
	 */
	Stop() {
		PreviousCritical := Critical("Off")
		try {
			Record := this.Record
			return !(Record is Map) || this._CancelRecord(Record)
		} finally Critical(PreviousCritical)
	}

	/** @returns {Boolean} Includes stable ownership and unacknowledged cleanup. */
	HasOwner() {
		return this.Record is Map
	}

	_Current(Record) {
		if !this._Owns(Record) || Record["cancelled"] || Record["terminal"] || A_IsSuspended
			return false
		Valid := Record["authority"]["is_current"].Call(Record["target"].Clone())
		return this._True(Valid) && this._Owns(Record)
			&& !Record["cancelled"] && !Record["terminal"] && !A_IsSuspended
	}

	_Owns(Record) {
		return this.Record is Map && this.Record == Record
			&& this.Generation == Record["generation"]
	}

	_CancelRecord(Record) {
		if !this._Owns(Record)
			return !(this.Record is Map)
		PreviousCritical := Critical("On")
		try {
			Record["cancelled"] := true
			Record["on_exit"] := 0
			Task := Record["task"]
		} finally Critical(PreviousCritical)
		Stopped := !IsObject(Task)
		if IsObject(Task) {
			try Stopped := this._True(Task.terminate())
			catch as Err {
				this._Report("termination", Err)
				Stopped := false
			}
		}
		if Stopped && this._Owns(Record)
			Record["task"] := 0
		if !Stopped || Record["building"]
			return false
		return this._Owns(Record) ? this._Release(Record) : !(this.Record is Map)
	}

	_OnTerminal(Record, ExitCode, Stdout, Stderr) {
		PreviousCritical := Critical("Off")
		try this._OnTerminalNonCritical(Record, ExitCode)
		finally Critical(PreviousCritical)
	}

	_OnTerminalNonCritical(Record, ExitCode) {
		; ShellRunner calls this only after its exact job is quiescent. This
		; callback never reopens a numeric PID or inspects another runtime task.
		if !this._Owns(Record)
			return
		Current := false
		try Current := !Record["cancelled"] && this._Current(Record)
		catch as Err {
			this._Report("terminal authority", Err)
		}
		PreviousCritical := Critical("On")
		try {
			if !this._Owns(Record)
				return
			Callback := Current && !Record["cancelled"] && !A_IsSuspended
				? Record["on_exit"] : 0
			Record["terminal"] := true
			Record["task"] := 0
			Record["on_exit"] := 0
		} finally Critical(PreviousCritical)
		try {
			if HasMethod(Callback, "Call")
				Callback.Call(ExitCode, Record["target"].Clone())
		} finally {
			if !Record["building"]
				this._Release(Record)
		}
	}

	_Release(Record) {
		; Physical retirement is independent of logical source/pause admission.
		; Its refusal retains this exact owner and immutable-version lease debt.
		if !this._Owns(Record) || Record["building"] || IsObject(Record["task"])
				|| Record["retirement_busy"]
			return false
		if !Record["retirement_acked"] {
			Record["retirement_busy"] := true
			try Record["retirement_acked"] := Record["guardian"] is OllamaGuardianTask
				? Record["guardian"].retired()
				: !this.Options.Has("spawn")
					? true ; Default construction is lazy: no composite means no native/task acquisition.
					: this._True(this.Options["on_retired"].Call(Record["target"].Clone()))
			catch as Err {
				this._Report("physical retirement", Err)
				Record["retirement_acked"] := false
			} finally Record["retirement_busy"] := false
			if !Record["retirement_acked"] || !this._Owns(Record)
				return false
		}
		PreviousCritical := Critical("On")
		try {
			if !this._Owns(Record) || Record["building"] || IsObject(Record["task"])
				return false
			this.Record := 0
			Record["on_exit"] := 0
			return true
		} finally Critical(PreviousCritical)
	}

	_ValidTarget(Target) {
		if !(Target is Map) || !(Target.Get("port", 0) is Integer)
				|| Target["port"] < 1 || Target["port"] > 65535
			return false
		return this._LocalPath(Target.Get("executable", ""))
			&& this._LocalPath(Target.Get("models_dir", ""))
			&& Target.Get("origin", "") == ("http://127.0.0.1:" . Target["port"])
	}

	_LocalPath(Path) {
		return Path is String && RegExMatch(Path, "^[A-Za-z]:\\")
			&& !InStr(Path, "`r") && !InStr(Path, "`n")
	}

	_True(Value) {
		return Value is Integer && Value == true
	}

	_Report(Kind, Err) {
		Report := this.Options.Get("on_error", 0)
		if HasMethod(Report, "Call")
			Report.Call(Kind, Err)
		else
			LoggerWarn("LLM.runtime", "Owned Ollama {1} failed: {2}.", Kind, Err.Message)
	}

	_NativeSpawn(Record, Executable, Arguments, OnDone) {
		local spec := this.Options["source_spec"].Call(Record["target"].Clone())
		return OllamaGuardianTask(ObjBindMethod(this, "_NativePort"), spec, Executable,
			Arguments, OnDone, ObjBindMethod(this, "_Current", Record),
			Record["created_at"] + this.Options["startup_ms"], this.Options["poll_ms"],
			this.Options["source_capture_bytes"])
	}

	_NativePort() {
		global _OllamaGuardianNativeOwners
		local pins := this.Options["native_pins"]
		local key := pins["NativeModule"]["path"]
		if _OllamaGuardianNativeOwners.Has(key) {
			local port := _OllamaGuardianNativeOwners[key]
			if port.Phase != "ready"
				throw Error("The existing native guardian module retains initialization debt.")
			for name, pin in pins {
				if !port.Pins.Has(name) || port.Pins[name]["path"] != pin["path"]
						|| port.Pins[name]["sha256"] != pin["sha256"] || port.Pins[name]["bytes"] != pin["bytes"]
					throw Error("The runtime cannot replace an active guardian code image.")
			}
			return port
		}
		return OllamaGuardianNativePort(pins)
	}
}
