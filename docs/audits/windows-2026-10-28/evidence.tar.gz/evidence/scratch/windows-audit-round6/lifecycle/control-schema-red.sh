#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import json,hashlib
root=Path.cwd(); out=Path('/workspace/scratch/windows-audit-round6/lifecycle'); w=out.parent/'verification-worker'
r=json.loads((w/'receipts/321-lifecycle-host-construction-proof-exit.json').read_text()); assert r['exit_code']==0,r
p=root/'static/ergopti_plus/windows/tests/meta/ui/webview/test_webview_shared_env_reentrancy_guard.ahk'
original=(out/'host-construction-pre-test.ahk').read_bytes(); fragment=(out/'warmup-host-construction-probe.ahk').read_text(encoding='utf-8-sig').encode()
assert p.read_bytes()==original+fragment
(out/'host-construction-refuted-source.ahk').write_bytes(p.read_bytes());p.write_bytes(original)
p=root/'static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk'
original=p.read_bytes(); (out/'control-schema-pre-test.ahk').write_bytes(original);p.write_bytes(original+(out/'control-schema-token-regression.ahk').read_bytes())
prod=root/'static/ergopti_plus/windows/infra/driver_control.ahk'; (out/'control-schema-old-production.ahk').write_bytes(prod.read_bytes())
(out/'control-schema-old-hashes.json').write_text(json.dumps({str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [p,prod]},indent=2)+'\n')
CHECK
exec env WINEPREFIX=/workspace/toolchain/wine-r3-metrics-owned WINEPATH='Z:\workspace\toolchain\node-v22.22.2-win-x64' timeout --kill-after=5s 300s xvfb-run -a bash tools/test/run-ahk-under-wine.sh --ahk /workspace/toolchain/ahk/AutoHotkey64.exe --runner run_all.ahk --results /workspace/scratch/windows-audit-round6/verification-worker/322-lifecycle-schema-identity-old-red.tap -- --only driver-control-schema-token-identity
