from pathlib import Path
import ast,difflib,hashlib,json,re,os
root=Path('/tmp/group6-brew-timeout-stage-20261010-r2');main=Path('/workspace/ergopti')
paths=['tools/diagnostics/macos_brew_archive_acceptance.py','tools/diagnostics/macos_brew_archive_acceptance_test.py','tools/test/test-homebrew-cask.cjs']
pre=[]
for name in paths:
 data=(main/name).read_bytes()
 for side in ('preimage','candidate'):
  p=root/side/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 pre.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(root/'PREIMAGES.json').write_text(json.dumps({'base':'Applied reviewed R1, atop dev591d59a; not a clean Git preimage','files':pre},indent=2)+'\n')
p=root/'candidate'/paths[0];s=p.read_text()
old='''            else:
                deadline = time.monotonic() + timeout
                timeout_stage = "ui-observer"
                after_start(process, deadline)
                timeout_stage = "exit-wait"
                self.groups[process].wait_for_exit(max(0, deadline - time.monotonic()))
'''
new='''            else:
                original_after_start = after_start

                def after_start(callback_process, callback_deadline):
                    nonlocal timeout_stage
                    timeout_stage = "ui-observer"
                    result = original_after_start(callback_process, callback_deadline)
                    timeout_stage = "exit-wait"
                    return result

                deadline = time.monotonic() + timeout
                after_start(process, deadline)
                self.groups[process].wait_for_exit(max(0, deadline - time.monotonic()))
'''
assert s.count(old)==1;s=s.replace(old,new,1);p.write_text(s)
assert s.replace(new,old,1)==(root/'preimage'/paths[0]).read_text()
addition='''class GenericCallbackTimeoutStageControls(FirstCommandTimeoutControls):
    """Keep the literal existing deadline/callback/wait sequence and its stage facts."""

    def test_generic_callback_failure_preserves_callback_arguments_and_ui_stage(self):
        with self.world() as (owner, writer, _, _, acquired, retired, waits, _):
            callback = Mock(side_effect=subprocess.TimeoutExpired("PRIVATE_CALLBACK", 3))
            with patch.object(probe.time, "monotonic", return_value=20):
                with self.assertRaisesRegex(
                    probe.AdmissionError, "^Owned native command exceeded deadline$"
                ):
                    owner.run(["owned"], timeout=3, after_start=callback)
            callback.assert_called_once_with(acquired[0], 23)
            self.assertEqual(waits, [])
            self.assertEqual(retired, acquired)
            self.assertEqual(owner.active, [])
            self.assertEqual(owner.debt, [])
            self.assertEqual(writer.first_timeout["command"], "other")
            self.assertEqual(writer.first_timeout["stage"], "ui-observer")
            self.assertEqual(writer.first_timeout["budget_seconds"], 3)
            self.assertIsNone(writer.first_timeout["request_deadline_ns"])
            self.assertEqual(writer.first_timeout["spent_ns"], 0)


'''
# Avoid inherited registered methods: reuse only the already owned factory.
addition=addition.replace('class GenericCallbackTimeoutStageControls(FirstCommandTimeoutControls):','class GenericCallbackTimeoutStageControls(unittest.TestCase):').replace('    def test_generic_callback_failure', '    world = FirstCommandTimeoutControls.world\n\n    def test_generic_callback_failure')
(root/'new-test.py.inc').write_text(addition)
p=root/'candidate'/paths[1];oldt=p.read_text();assert oldt.count('if __name__ == "__main__":')==1
newt=oldt.replace('if __name__ == "__main__":',addition+'if __name__ == "__main__":',1);p.write_text(newt)
assert newt.replace(addition,'',1)==oldt
p=root/'candidate'/paths[2];oldc=p.read_text();assert oldc.count('Ran 188 tests in ')==1;p.write_text(oldc.replace('Ran 188 tests in ','Ran 189 tests in ',1))
def methods(source):
 lines=source.splitlines(keepends=True)
 return {n.name+'.'+f.name:''.join(lines[f.lineno-1:f.end_lineno]) for n in ast.parse(source).body if isinstance(n,ast.ClassDef) for f in n.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
a,b=methods(oldt),methods(newt);assert len(a)==188 and len(b)==189 and all(b[k]==v for k,v in a.items())
# Verify the original assertion pattern without loading or running the JS suite.
guard=r'deadline = time\.monotonic\(\) \+ timeout\s*after_start\(process, deadline\)\s*self\.groups\[process\]\.wait_for_exit\(max\(0, deadline - time\.monotonic\(\)\)\)'
assert re.search(guard,s)
old591=Path('/tmp/group6-brew-timeout-diagnostic-20261010-r1/preimage/tools/diagnostics/macos_brew_archive_acceptance_test.py').read_text();old178=methods(old591);assert len(old178)==178 and all(b[k]==v for k,v in old178.items())
def run_node(source):
 return next(f for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='Children' for f in n.body if isinstance(f,ast.FunctionDef) and f.name=='run')
ra,rb=run_node((root/'preimage'/paths[0]).read_text()),run_node(s)
def scheduling(node):
 return sorted(ast.dump(n,include_attributes=False) for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('wait_for_exit','remaining','wait','settle','monotonic','monotonic_ns'))
assert scheduling(ra)==scheduling(rb)
a_final=next(n.finalbody for n in ra.body if isinstance(n,ast.Try) and n.finalbody)
b_final=next(n.finalbody for n in rb.body if isinstance(n,ast.Try) and n.finalbody)
assert ast.dump(ast.Module(body=a_final,type_ignores=[]))==ast.dump(ast.Module(body=b_final,type_ignores=[]))
patch='';inverse=''
for name in paths:
 a=(root/'preimage'/name).read_text().splitlines(keepends=True);b=(root/'candidate'/name).read_text().splitlines(keepends=True)
 patch+=''.join(difflib.unified_diff(a,b,fromfile='a/'+name,tofile='b/'+name));inverse+=''.join(difflib.unified_diff(b,a,fromfile='a/'+name,tofile='b/'+name))
(root/'application.patch').write_text(patch);(root/'whole-file-inverse.patch').write_text(inverse)
(root/'CONSERVATION.json').write_text(json.dumps({'checks':'source parsing/comparison only, no product imports or suites','preimage_registered_methods':188,'candidate_registered_methods':189,'all188_current_method_bodies_byte_exact':True,'all178_original591_method_bodies_byte_exact':True,'original_CJS_scoped_consent_guard_byte_exact':True,'original_literal_contiguous_deadline_callback_wait_present':True,'run_scheduling_and_clock_call_AST_multiset_exact':True,'run_retirement_finally_AST_exact':True,'helper_whole_inverse_exact':True,'test_module_whole_inverse_exact':True,'census_only188_to189':True,'execution':'UNRUN'},indent=2)+'\n')
(root/'README.md').write_text('''# Generic callback stage: narrow private R2

This revision applies to the current reviewed R1 diagnostic postimage, not clean dev591. It changes only the ordinary non-request callback branch: a local transparent after_start wrapper calls the captured original callback with the same process/deadline, marks ui-observer immediately before that call, and marks exit-wait only on successful return. A callback TimeoutExpired therefore retains its correct UI stage. The exact original contiguous deadline = time.monotonic() + timeout / after_start(process, deadline) / self.groups[process].wait_for_exit(max(0, deadline - time.monotonic())) sequence is restored. The original CJS assertion stays byte exact; only its strict registered census188->189 changes.

The wrapper creates no new scheduling deadline or clock observation. Source checks preserve every scheduling/clock call expression, the entire retirement finally AST, every current188 registered method body and all178 original591 bodies. One additive portable control asserts the original callback argument identity/deadline, no exit wait on its failure, exact primary and same reservation cleanup, plus ui-observer fact. It reuses only the existing private world factory, without inheriting registered methods.

All suites/imports/native executions and Ruff formatting remain UNRUN; root alone performs canonical formatting and serial validation after source review. Main/index/refs are unchanged by this agent. Full exact preimages/postimages/application and inverse patches are pinned in MANIFEST.json. The original R1 causal receiving proof remains intact.
''')
sha=lambda b:hashlib.sha256(b).hexdigest();files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json':continue
 data=p.read_bytes();assert b'\r' not in data;os.chmod(p,0o400);files.append({'path':str(p.relative_to(root)),'sha256':sha(data),'bytes':len(data)})
for x in pre:assert sha((main/x['path']).read_bytes())==x['sha256']
manifest={'schema':1,'base':'Exact current reviewed R1 applied sources atop dev591','main_sources_match_preimages':True,'application_paths':paths,'preimage_tests':188,'candidate_tests':189,'patch_sha256':sha(patch.encode()),'all_execution':'UNRUN','files':files}
(root/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');os.chmod(root/'MANIFEST.json',0o400)
print(json.dumps({'manifest':str(root/'MANIFEST.json'),'sha256':sha((root/'MANIFEST.json').read_bytes()),'patch_sha256':sha(patch.encode()),'methods188_to189':True,'old178_and_current188_body_exact':True,'guard_exact_and_matches':True,'execution':'UNRUN'}))
