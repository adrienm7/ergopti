from pathlib import Path
import hashlib,json,subprocess,shutil,os
A=Path('/workspace/.ergopti-cloud/preparations/shortcuts-sdk-current-dev-forward/freeze');C=A.parent/'candidate';B=Path('/workspace/.ergopti-cloud/reviews/sdk-current-dev-forward-independent');B.mkdir(mode=0o700)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
seals=[]
for line in (A/'SHA256SUMS').read_text().splitlines():
 value,name=line.split('  ',1);assert not Path(name).is_absolute() and '..' not in Path(name).parts;assert sha(A/name)==value;seals.append({'path':name,'sha256':value})
assert len(seals)==103;assert sha(A/'candidate.patch')=='4d52aa15f96e2adc986d32c4083a14c0faa9ec2902f20f5286b0a16f84daa895';assert sha(A/'receipt.json')=='f0675fce5942be51d40e4db3d8a625ea2d121e52f743a8937f20394cdd7a3488'
r=json.loads((A/'receipt.json').read_text());pairs=r['source_pairs'];source=r['source'];repo=Path('/workspace/ergopti');gitrows=[]
for row in pairs:
 file=row['path'];post=A/'postimages'/file;assert sha(post)==row['post_sha256'];assert (C/file).read_bytes()==post.read_bytes()
 cp=subprocess.run(['git','show',source+':'+file],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if row['pre_sha256'] is None:assert cp.returncode!=0
 else:assert cp.returncode==0 and hashlib.sha256(cp.stdout).hexdigest()==row['pre_sha256'];assert (A/'preimages'/file).read_bytes()==cp.stdout
 gitrows.append({'path':file,'source':source,'pre_exact':True})
helper='tools/test/ci-full-default.cjs';cp=subprocess.run(['git','show',r['g6_publication']+':'+helper],cwd=repo,stdout=subprocess.PIPE,check=True);assert cp.stdout==(A/'preimages'/helper).read_bytes()
control='tools/test/test-ci-full-default.cjs';cp=subprocess.run(['git','show',source+':'+control],cwd=repo,stdout=subprocess.PIPE,check=True);assert cp.stdout==(C/control).read_bytes();assert hashlib.sha256(cp.stdout).hexdigest()==r['helper_original44_test_sha256']
reader='tools/diagnostics/sdk_permission_xctest_evidence.cjs';assert (A/'postimages'/reader).read_bytes()==(A.parent.parent/'shortcuts-sdk-independent-ci-enrollment-v10/candidate'/reader).read_bytes();assert (A/'postimages'/reader).read_bytes()==(A.parent.parent/'shortcuts-sdk-ci-condition-owner-v11/candidate'/reader).read_bytes()
row="\t[MAC, 'item36-native', 'Observe the actual no-prompt SDK permission API independently', 7, 8],\n";new=(A/'postimages'/helper).read_text();assert new.count(row)==1;assert new.replace(row,'')==(A/'preimages'/helper).read_text()
# All reused sparse dependency images are checked before and after read-only gates.
dep=json.loads((A/'dependencies.json').read_text());pairmap={p['path']:p['post_sha256'] for p in pairs};pins=[]
for item in dep['files']:
 expected=pairmap.get(item['path'],item['sha256']);assert sha(C/item['path'])==expected,item['path'];pins.append({'path':item['path'],'sha256':expected})
shutil.copytree(A/'postimages',B/'candidate');shutil.copytree(A/'preimages',B/'preimages')
for name in ['observation-step.yml','validate-original-mac-ast.cjs','validate-original-pipeline-ast.cjs','candidate.patch','g6-named-wrapper.patch','receipt.json']:
 shutil.copyfile(A/name,B/name)
env=dict(os.environ,TMPDIR='/tmp');outputs=[]
def run(label,cmd):
 cp=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45);(B/(label+'.log')).write_bytes(cp.stdout);print(label,cp.returncode,cp.stdout.decode(errors='replace')[-800:],flush=True);assert cp.returncode==0;outputs.append({'case':label,'exit':0,'command':cmd,'log_sha256':hashlib.sha256(cp.stdout).hexdigest()})
for name in ['validate-original-mac-ast.cjs','validate-original-pipeline-ast.cjs']:run(name,['node',str(B/name)])
for name in ['test-macos-swift-launcher-ci.cjs','test-macos-dev-qualification-deferral.cjs','test-ci-pipeline-wiring.cjs','test-ci-full-default.cjs']:run(name,['node',str(C/'tools/test'/name)])
(B/'source-preimages.json').write_text(json.dumps(gitrows,indent=2)+'\n');(B/'sparse-readonly-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(B/'original103seals.json').write_text(json.dumps(seals,indent=2)+'\n');(B/'focused-results.json').write_text(json.dumps(outputs,indent=2)+'\n')
for item in pins:assert sha(C/item['path'])==item['sha256']
for item in seals:assert sha(A/item['path'])==item['sha256']
print('PASS: six proposed paths/e896/b454 preimages, whole ASTs,950 read-only images,103 frozen seals, unchanged original44 controls')
