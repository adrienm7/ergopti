/* Literal native controls. UNCOMPILED/UNEXECUTED; no simulated native success. */
#define _GNU_SOURCE
#include "../candidate/archive_publication.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static double now_ms(void) {
    struct timespec now;
    assert(clock_gettime(CLOCK_MONOTONIC, &now) == 0);
    return (double)now.tv_sec * 1000.0 + (double)now.tv_nsec / 1000000.0;
}

static int anonymous_archive(int directory) {
    int fd = openat(directory, ".", O_TMPFILE | O_RDWR | O_CLOEXEC, 0600);
    assert(fd >= 0); /* Actual filesystem capability absence is failure. */
    assert(write(fd, "abc", 3) == 3);
    return fd;
}

static struct ergopti_archive_publication *reserve(int directory) {
    struct ergopti_archive_publication *owner = NULL;
    assert(ergopti_archive_publication_reserve(directory, &owner) == 0);
    assert(owner != NULL);
    return owner;
}

static void unpublished_close(struct ergopti_archive_publication *owner) {
    assert(ergopti_archive_publication_retire(owner) == 0);
    assert(ergopti_archive_publication_descriptors_closed(owner) == 1);
    assert(ergopti_archive_publication_named_remaining(owner) == 0);
    assert(ergopti_archive_publication_dispose_unpublished(owner) == 0);
}

int main(void) {
    /* A root run cannot qualify the required unprivileged link mechanism. */
    if (geteuid() == 0) {
        fprintf(stderr, "Unprivileged native publication prerequisite unavailable\n");
        return 1;
    }
    char directory_name[] = "/tmp/ergopti-publication-control.XXXXXX";
    assert(mkdtemp(directory_name) != NULL);
    int directory = open(directory_name, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    assert(directory >= 0);

    /* Capture actual private directory before any network dispatch. */
    struct ergopti_archive_publication *captured = NULL;
    assert(ergopti_archive_publication_capture_directory(directory_name,
        now_ms() + 1000, &captured) == 0 && captured != NULL);
    unpublished_close(captured);
    assert(symlinkat(".", directory, "alias") == 0);
    char alias[sizeof(directory_name) + 16];
    assert(snprintf(alias, sizeof(alias), "%s/alias", directory_name) > 0);
    captured = NULL;
    assert(ergopti_archive_publication_capture_directory(alias,
        now_ms() + 1000, &captured) == -1 && captured != NULL);
    unpublished_close(captured);
    assert(unlinkat(directory, "alias", 0) == 0);

    /* Exact original inode and bytes, not a copied/reopened source archive. */
    int archive = anonymous_archive(directory);
    struct stat original, linked;
    assert(fstat(archive, &original) == 0 && original.st_nlink == 0);
    struct ergopti_archive_publication *owner = reserve(directory);
    assert(ergopti_archive_publication_stage(owner, archive, 3, "archive", now_ms() + 1000) == 0);
    assert(fstatat(directory, "archive", &linked, AT_SYMLINK_NOFOLLOW) == 0);
    assert(original.st_dev == linked.st_dev && original.st_ino == linked.st_ino);
    assert(linked.st_size == 3 && S_ISREG(linked.st_mode));
    char bytes[4] = {0};
    assert(pread(archive, bytes, 3, 0) == 3 && !memcmp(bytes, "abc", 3));
    assert(ergopti_archive_publication_commit(owner) == 0);
    assert(ergopti_archive_publication_stage(owner, archive, 3, "second", now_ms() + 1000) == -1);
    assert(ergopti_archive_publication_retire(owner) == -1 && errno == EBUSY);
    assert(ergopti_archive_publication_descriptors_closed(owner) == 0);
    assert(ergopti_archive_publication_named_remaining(owner) == 1);
    assert(ergopti_archive_publication_dispose_unpublished(owner) == -1);
    assert(close(archive) == 0);
    assert(unlinkat(directory, "archive", 0) == 0); /* Exclusive control fixture. */

    /* Occupied symlink is preserved; EEXIST never authorizes unlink/retry. */
    assert(symlinkat("foreign", directory, "occupied") == 0);
    archive = anonymous_archive(directory); owner = reserve(directory);
    assert(ergopti_archive_publication_stage(owner, archive, 3, "occupied", now_ms() + 1000) == -1);
    assert(errno == EEXIST);
    assert(fstatat(directory, "occupied", &linked, AT_SYMLINK_NOFOLLOW) == 0 && S_ISLNK(linked.st_mode));
    assert(ergopti_archive_publication_retire(owner) == -1 && errno == EBUSY);
    assert(ergopti_archive_publication_descriptors_closed(owner) == 0);
    assert(ergopti_archive_publication_named_remaining(owner) == 2);
    assert(ergopti_archive_publication_dispose_unpublished(owner) == -1);
    assert(close(archive) == 0 && unlinkat(directory, "occupied", 0) == 0);

    /* Cancellation and native deadline refusal publish no archive. */
    archive = anonymous_archive(directory); owner = reserve(directory);
    assert(ergopti_archive_publication_retire(owner) == 0);
    assert(ergopti_archive_publication_stage(owner, archive, 3, "cancelled", now_ms() + 1000) == -1);
    assert(fstatat(directory, "cancelled", &linked, AT_SYMLINK_NOFOLLOW) == -1 && errno == ENOENT);
    assert(ergopti_archive_publication_dispose_unpublished(owner) == 0);
    owner = reserve(directory);
    assert(ergopti_archive_publication_stage(owner, archive, 3, "expired", now_ms() - 1) == -1 && errno == ETIMEDOUT);
    assert(fstatat(directory, "expired", &linked, AT_SYMLINK_NOFOLLOW) == -1 && errno == ENOENT);
    unpublished_close(owner); assert(close(archive) == 0);

    /* A named/foreign source and incorrect acknowledged length both refuse. */
    int named = openat(directory, "foreign", O_CREAT | O_EXCL | O_RDWR | O_CLOEXEC, 0600);
    assert(named >= 0 && write(named, "abc", 3) == 3);
    owner = reserve(directory);
    assert(ergopti_archive_publication_stage(owner, named, 3, "borrowed", now_ms() + 1000) == -1 && errno == EPERM);
    unpublished_close(owner); assert(close(named) == 0);
    archive = anonymous_archive(directory); owner = reserve(directory);
    assert(ergopti_archive_publication_stage(owner, archive, 4, "wrong-size", now_ms() + 1000) == -1 && errno == EPERM);
    unpublished_close(owner); assert(close(archive) == 0);

    /* Group-writable destination authority is refused at reservation. */
    assert(fchmod(directory, 0770) == 0);
    owner = NULL;
    assert(ergopti_archive_publication_reserve(directory, &owner) == -1 && errno == EPERM);
    assert(owner != NULL); unpublished_close(owner);
    assert(fchmod(directory, 0700) == 0);

    /* Reuse of the retired duplicate's integer must not authorize another call
     * or destructive close. Fill the lowest available FD with a foreign file. */
    owner = reserve(directory);
    assert(ergopti_archive_publication_retire(owner) == 0);
    named = openat(directory, "foreign", O_RDONLY | O_CLOEXEC);
    assert(named >= 0);
    archive = anonymous_archive(directory);
    assert(ergopti_archive_publication_stage(owner, archive, 3, "reused", now_ms() + 1000) == -1);
    assert(ergopti_archive_publication_retire(owner) == 0);
    assert(fcntl(named, F_GETFD) >= 0);
    assert(ergopti_archive_publication_dispose_unpublished(owner) == 0);
    assert(close(named) == 0 && close(archive) == 0);

    /* Rebinding the original display pathname cannot redirect publication:
     * the selected directory is the still-retained exact native descriptor. */
    char displaced[sizeof(directory_name) + 16];
    assert(snprintf(displaced, sizeof(displaced), "%s.retained", directory_name) > 0);
    owner = reserve(directory);
    assert(rename(directory_name, displaced) == 0);
    assert(mkdir(directory_name, 0700) == 0);
    int replacement = open(directory_name, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    assert(replacement >= 0);
    archive = anonymous_archive(directory);
    assert(ergopti_archive_publication_stage(owner, archive, 3, "held", now_ms() + 1000) == 0);
    assert(fstatat(directory, "held", &linked, AT_SYMLINK_NOFOLLOW) == 0);
    assert(fstatat(replacement, "held", &linked, AT_SYMLINK_NOFOLLOW) == -1 && errno == ENOENT);
    assert(ergopti_archive_publication_retire(owner) == -1 && errno == EBUSY);
    assert(ergopti_archive_publication_named_remaining(owner) == 1);
    assert(close(archive) == 0 && unlinkat(directory, "held", 0) == 0);
    assert(close(replacement) == 0 && rmdir(directory_name) == 0);
    assert(rename(displaced, directory_name) == 0);

    assert(unlinkat(directory, "foreign", 0) == 0 && close(directory) == 0);
    assert(rmdir(directory_name) == 0);
    puts("11 native publication scenarios completed; published-name/directory debt intentionally retained until process exit");
    return 0;
}
