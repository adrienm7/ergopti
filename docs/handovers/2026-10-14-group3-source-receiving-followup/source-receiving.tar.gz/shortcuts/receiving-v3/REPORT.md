# Controlled refusal-phase receiving

Final frozen V3 candidate: Node40/0 (original35 plus5) and genuine unittest discovery56/0 (original51 plus5), both exit0. Four explicit private-file format/check commands were received separately with exit0. No JXA/SDK/native execution occurred.

Original discover/run_probe source with the unchanged appended tests: Node completed its35 original cases, then refused the newly unsupported opt-in phase expectation (exit1; new enrollment absence). Python executed56:53pass,2failure,1error; the51 old tests remained green and three added phase-admission controls rejected. These results do not diagnose the actual native call cause.

A separate exact original-source legacy witness retained the complete original35 Node controls, reused the exact strengthened added legacy case, and passed1 additional case (36 completed, exit0). Before-return call exception and descriptor getter exception after the expression returned produce the same independently literal full legacy stream. Their controlled native-return event counts differ0/1. This establishes the original diagnostic ambiguity without claiming C entry or a native failure cause.

The single-span omission of optional marker IO containment completed39 Node cases then failed the fifth added control: original catalogue calls0 instead of2. V3 passes that same control with exact original refusal stream and both catalogue reads. The optional marker cannot replace the original outcome. No assertion, budget, ABI, permission or catalogue-admission predicate was weakened.

Source/index/HEAD, every canonical dependency and all projected sources were stable through each row and the final legacy witness; V3 source seal remains unchanged. V1/V2 source epochs and all expected failures are retained. Root metadata56/40 and installed-target source-SHA custody/enrollment are separate pending spans; existing workflows do not opt in. Actual integrated3f59 bridge refusal/native_returned=false remains historical absent-valid-return-marker evidence, with native cause UNKNOWN.
