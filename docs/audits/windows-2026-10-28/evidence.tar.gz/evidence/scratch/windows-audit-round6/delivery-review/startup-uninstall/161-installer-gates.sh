set -euo pipefail
cd /workspace/ergopti-windows-r7-installer
pwd
node --check tools/test/test-windows-uninstall.cjs
pwsh -NoProfile -NonInteractive -File /workspace/scratch/windows-audit-round6/delivery-review/startup-uninstall/observe-production-unregister.ps1 -WorkerPath /workspace/ergopti-windows-r7-installer/static/ergopti_plus/windows/vendor/ergopti_uninstall.ps1 -EvidencePath /workspace/scratch/windows-audit-round6/delivery-review/startup-uninstall/worktree-green-receipt.json -TraceOnly
node tools/test/test-windows-uninstall.cjs
node tools/test/find-false-greens.cjs
node tools/test/test-ahk-encoding.cjs
npm run lint:conventions:strict
