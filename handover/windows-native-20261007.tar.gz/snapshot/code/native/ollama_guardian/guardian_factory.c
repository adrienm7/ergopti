#include "guardian_factory.h"
#include "guardian_retirement.h"
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

_Static_assert(sizeof(uintptr_t)==8u,"Guardian factory wire requires x64");
_Static_assert(sizeof(wchar_t)==2u,"Guardian paths require UTF-16");

struct GF_Owner {
    uint64_t id;
    GF_Phase phase;
    DWORD first_error;
    GSC_Owner *channel;
    GI_Row imported;
    GI_Win32Context import_context;
    HANDLE job,parent,setup,stop,ready,config,notice;
    HANDLE host,host_thread,image_lease;
    GH_Notice *notice_view;
    DWORD host_pid;
    FILETIME host_creation;
    uint32_t close_attempted;
    uint32_t close_uncertain;
    uint32_t termination_attempted;
    uint32_t job_bound;
    uint32_t stop_requested;
    uint32_t source_release_requested;
    uint32_t intake_mode;
    uint32_t host_created;
    uint32_t config_unmap_attempted;
    uint32_t notice_unmap_attempted;
    GFR_Owner retirement;
    uint32_t setup_close_attempted;
    uint32_t inherited_flags;
    void *config_view;
    HANDLE *inherit_list;
    wchar_t *command;
    LPPROC_THREAD_ATTRIBUTE_LIST attributes;
    uint32_t attributes_initialized;
    HANDLE nul;
    PROCESS_INFORMATION creating;
};

static int GF_ResetInheritance(GF_Owner *owner) {
    uint32_t i;
    int good=1;
    for(i=0u;i<owner->inherited_flags;++i){
        if(!SetHandleInformation(owner->inherit_list[i],HANDLE_FLAG_INHERIT,0u)){
            if(owner->first_error==ERROR_SUCCESS)owner->first_error=GetLastError();
            good=0;
        }
    }
    if(good)owner->inherited_flags=0u;
    return good;
}

static int GF_Error(GF_Owner *owner,DWORD error) {
    if(owner->first_error==ERROR_SUCCESS)
        owner->first_error=error!=ERROR_SUCCESS?error:ERROR_INVALID_DATA;
    (void)GF_ResetInheritance(owner);
    owner->phase=GF_RETAINED_DEBT;
    return 0;
}
static int GF_Duplicate(GF_Owner *owner,HANDLE source,HANDLE *slot,DWORD access) {
    HANDLE acquired=NULL;
    if(!DuplicateHandle(GetCurrentProcess(),source,GetCurrentProcess(),&acquired,access,FALSE,0u))
        return GF_Error(owner,GetLastError());
    *slot=acquired;
    return 1;
}
static int GF_Time(GF_Owner *owner,HANDLE process,FILETIME *creation) {
    FILETIME exit_time,kernel,user;
    if(!GetProcessTimes(process,creation,&exit_time,&kernel,&user))return GF_Error(owner,GetLastError());
    return 1;
}

/* Each owning slot is zeroed only after affirmative retirement. A failed close
   may have consumed the kernel value, so neither retry nor reuse is allowed. */
static int GF_Close(GF_Owner *owner,HANDLE *slot,uint32_t bit) {
    DWORD error;
    if(*slot==NULL)return 1;
    if((owner->close_attempted&bit)!=0u)return 0;
    owner->close_attempted|=bit;
    if(!CloseHandle(*slot)){
        error=GetLastError();owner->close_uncertain|=bit;
        GF_Error(owner,error);return 0;
    }
    *slot=NULL;return 1;
}

static void GF_FreeLaunchBuffers(GF_Owner *owner) {
    if(owner->attributes_initialized){DeleteProcThreadAttributeList(owner->attributes);owner->attributes_initialized=0u;}
    free(owner->attributes);owner->attributes=NULL;
    free(owner->command);owner->command=NULL;
    free(owner->inherit_list);owner->inherit_list=NULL;
}

static int GF_HostTerminal(void *context) {
    GF_Owner *owner=context;
    DWORD waited,code;
    if(!owner->host_created)return 1;
    waited=WaitForSingleObject(owner->host,0u);
    if(waited==WAIT_TIMEOUT)return 0;
    if(waited!=WAIT_OBJECT_0){GF_Error(owner,waited==WAIT_FAILED?GetLastError():ERROR_INVALID_DATA);return -1;}
    if(!GetExitCodeProcess(owner->host,&code)){GF_Error(owner,GetLastError());return -1;}
    /* Exact process termination retires its inherited copies even on a crash.
       The notice reports successful cooperation; it is not the job-zero proof. */
    if(code!=0u || owner->notice_view==NULL || owner->notice_view->id!=owner->id ||
        owner->notice_view->retired!=1){
        if(owner->first_error==ERROR_SUCCESS)owner->first_error=ERROR_PROCESS_ABORTED;
    }
    return 1;
}

static int GF_JobEmpty(void *context) {
    GF_Owner *owner=context;
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION accounting;
    if(!owner->job_bound)return 1; /* No content acquisition occurred. */
    if(!GF_ResetInheritance(owner))return -1;
    if(owner->setup!=NULL && !GF_Close(owner,&owner->setup,1u))return -1;
    if(!owner->host_created){
        /* Never-launched staged daemon is contained by its exact retained job.
           Drop this process reference before asking kernel process accounting. */
        if(!owner->termination_attempted){
            owner->termination_attempted=1u;
            if(!TerminateJobObject(owner->job,125u)){GF_Error(owner,GetLastError());return -1;}
        }
    }
    if(owner->intake_mode){
        int dropped=GSC_DropSourceReference(owner->channel);
        if(dropped<0){GF_Error(owner,GSC_FirstError(owner->channel));return -1;}
        if(dropped==0)return 0;
        if(owner->imported.source!=0u){
            if(owner->imported.source_close_attempted)return -1;
            owner->imported.source_close_attempted=1u;
            if(owner->imported.port.close(owner->imported.port.context,owner->imported.source)!=1){
                owner->imported.source_close_uncertain=1u;GF_Error(owner,owner->import_context.first_os_error);return -1;
            }
            owner->imported.source=0u;
        }
    }
    if(!QueryInformationJobObject(owner->job,JobObjectBasicAccountingInformation,
        &accounting,(DWORD)sizeof(accounting),NULL)){GF_Error(owner,GetLastError());return -1;}
    return accounting.ActiveProcesses==0u?1:0;
}

static int GF_ReleaseCopies(void *context) {
    GF_Owner *owner=context;
    size_t i;
    HANDLE *slots[10]={&owner->setup,&owner->host_thread,&owner->host,&owner->nul,
        &owner->config,&owner->notice,&owner->ready,&owner->stop,&owner->parent,&owner->job};
    if(owner->close_uncertain)return -1;
    if(!owner->host_created && (owner->creating.hProcess!=NULL || owner->creating.hThread!=NULL))
        return -1; /* Failed CreateProcess outputs are not adopted as capabilities. */
    if(!GF_ResetInheritance(owner))return -1;
    if(owner->config_view!=NULL){
        if(owner->config_unmap_attempted)return -1;
        owner->config_unmap_attempted=1u;
        if(!UnmapViewOfFile(owner->config_view)){GF_Error(owner,GetLastError());return -1;}
        owner->config_view=NULL;
    }
    if(owner->notice_view!=NULL){
        if(owner->notice_unmap_attempted)return -1;
        owner->notice_unmap_attempted=1u;
        if(!UnmapViewOfFile(owner->notice_view)){GF_Error(owner,GetLastError());return -1;}
        owner->notice_view=NULL;
    }
    /* This is the parent-copy finalizer, not GI_Abort on an exported row.
       Host terminal and actual job zero have both been observed above. */
    for(i=0u;i<owner->imported.count;++i){
        GI_Imported *item=&owner->imported.contents[i];
        if(!item->handle)continue;
        if(item->attempted)return -1;
        item->attempted=1u;
        if(owner->imported.port.close(owner->imported.port.context,item->handle)!=1){
            item->uncertain=1u;GF_Error(owner,owner->import_context.first_os_error);return -1;
        }
        item->handle=0u;
    }
    if(owner->imported.source!=0u){
        if(owner->imported.source_close_attempted)return -1;
        owner->imported.source_close_attempted=1u;
        if(owner->imported.port.close(owner->imported.port.context,owner->imported.source)!=1){
            owner->imported.source_close_uncertain=1u;GF_Error(owner,owner->import_context.first_os_error);return -1;
        }
        owner->imported.source=0u;
    }
    for(i=0u;i<10u;++i)if(!GF_Close(owner,slots[i],1u<<(uint32_t)i))return -1;
    GF_FreeLaunchBuffers(owner);
    if(!owner->source_release_requested && !owner->intake_mode){
        owner->source_release_requested=1u;
        if(!GSC_RequestSourceRelease(owner->channel)){GF_Error(owner,GSC_FirstError(owner->channel));return -1;}
    }
    { int retired=GSC_TryRetire(owner->channel);
      if(retired<0){GF_Error(owner,GSC_FirstError(owner->channel));return -1;}
      if(retired==0)return 0; }
    if(owner->imported.contents!=NULL){
        owner->imported.port.release(owner->imported.port.context,owner->imported.contents);
        owner->imported.contents=NULL;owner->imported.count=0u;owner->imported.acquired=0u;
    }
    owner->image_lease=NULL;
    return 1;
}

static GF_Owner *GF_BeginMode(uint32_t intake_mode,uint64_t id,GSC_Owner *channel,HANDLE job,HANDLE daemon,
                    DWORD daemon_pid,const FILETIME *daemon_creation,const wchar_t *image) {
    GF_Owner *owner;
    const GI_Expected *expected;
    size_t count,i,units=0u,bytes;
    GH_Config *config;
    GH_Record *records;
    uint16_t *paths;
    HANDLE *handles;
    SIZE_T attribute_bytes=0u;
    STARTUPINFOEXW startup={0};
    PROCESS_INFORMATION process={0};
    wchar_t *command;
    SECURITY_ATTRIBUTES security={(DWORD)sizeof(security),NULL,TRUE};
    HANDLE nul;
    BOOL member=FALSE;
    uint32_t actor_found=0u;
    if(id==0u || channel==NULL || job==NULL || daemon==NULL || daemon_creation==NULL || image==NULL)return NULL;
    owner=calloc(1u,sizeof(*owner));if(owner==NULL)return NULL;
    owner->id=id;owner->intake_mode=intake_mode;owner->channel=channel;owner->phase=GF_ACQUIRING;
    { GFR_Port port={owner,GF_HostTerminal,GF_JobEmpty,GF_ReleaseCopies};
      if(!GFR_Init(&owner->retirement,port)){GF_Error(owner,ERROR_INVALID_DATA);return owner;} }
    /* Acquire the exact containment before any file import. Every later abort
       retains this capability and queries actual zero before releasing leases. */
    if(!GF_Duplicate(owner,job,&owner->job,JOB_OBJECT_QUERY|JOB_OBJECT_TERMINATE))return owner;
    if(owner->intake_mode)owner->job_bound=1u;
    if(!GF_Duplicate(owner,daemon,&owner->setup,SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION) ||
        !GF_Duplicate(owner,GetCurrentProcess(),&owner->parent,SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION))return owner;
    if(GetProcessId(owner->setup)!=daemon_pid || !IsProcessInJob(owner->setup,owner->job,&member) || !member){
        GF_Error(owner,ERROR_INVALID_DATA);return owner;
    }
    { FILETIME creation;if(!GF_Time(owner,owner->setup,&creation) || CompareFileTime(&creation,daemon_creation)!=0){GF_Error(owner,ERROR_INVALID_DATA);return owner;} }
    owner->job_bound=1u;
    if(!GSC_Poll(channel) || !GI_Win32ContextInit(&owner->import_context,channel)){
        GF_Error(owner,GSC_FirstError(channel));return owner;
    }
    expected=GSC_Records(channel,&count);
    if(expected==NULL || !GI_Begin(&owner->imported,id,(uintptr_t)GSC_Source(channel),
        expected,count,GI_Win32ImportPort(&owner->import_context))){
        GF_Error(owner,owner->import_context.first_os_error);return owner;
    }
    for(i=0u;i<count;++i){
        if(expected[i].kind==0u && _wcsicmp((const wchar_t *)expected[i].native_path,image)==0){
            owner->image_lease=(HANDLE)owner->imported.contents[i].handle;actor_found+=1u;
        }
        if(expected[i].path_units>SIZE_MAX-units-1u){GF_Error(owner,ERROR_ARITHMETIC_OVERFLOW);return owner;}
        units+=expected[i].path_units+1u;
    }
    if(actor_found!=1u || units>UINT32_MAX || count>UINT32_MAX){GF_Error(owner,ERROR_INVALID_DATA);return owner;}
    owner->stop=CreateEventW(NULL,TRUE,FALSE,NULL);if(owner->stop==NULL){GF_Error(owner,GetLastError());return owner;}
    owner->ready=CreateEventW(NULL,TRUE,FALSE,NULL);if(owner->ready==NULL){GF_Error(owner,GetLastError());return owner;}
    owner->notice=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0u,(DWORD)sizeof(GH_Notice),NULL);
    if(owner->notice==NULL){GF_Error(owner,GetLastError());return owner;}
    owner->notice_view=MapViewOfFile(owner->notice,FILE_MAP_WRITE,0u,0u,sizeof(GH_Notice));
    if(owner->notice_view==NULL){GF_Error(owner,GetLastError());return owner;}
    bytes=sizeof(GH_Config);
    if(count>(SIZE_MAX-bytes)/sizeof(GH_Record)){GF_Error(owner,ERROR_ARITHMETIC_OVERFLOW);return owner;}
    bytes+=count*sizeof(GH_Record);
    if(units>(SIZE_MAX-bytes)/sizeof(uint16_t)){GF_Error(owner,ERROR_ARITHMETIC_OVERFLOW);return owner;}
    bytes+=units*sizeof(uint16_t);
    if(bytes>UINT32_MAX || count>SIZE_MAX/sizeof(HANDLE)-8u){GF_Error(owner,ERROR_ARITHMETIC_OVERFLOW);return owner;}
    owner->config=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0u,(DWORD)bytes,NULL);
    if(owner->config==NULL){GF_Error(owner,GetLastError());return owner;}
    config=MapViewOfFile(owner->config,FILE_MAP_WRITE,0u,0u,bytes);
    owner->config_view=config;
    if(config==NULL){GF_Error(owner,GetLastError());return owner;}
    config->magic=GH_CONFIG_MAGIC;config->bytes=(uint32_t)bytes;config->id=id;
    config->job=(uintptr_t)owner->job;config->parent=(uintptr_t)owner->parent;
    config->setup=(uintptr_t)owner->setup;config->stop=(uintptr_t)owner->stop;
    config->ready=(uintptr_t)owner->ready;config->notice=(uintptr_t)owner->notice;
    config->parent_pid=GetCurrentProcessId();config->daemon_pid=daemon_pid;
    config->record_count=(uint32_t)count;config->path_units=(uint32_t)units;
    config->daemon_creation=*daemon_creation;
    if(!GF_Time(owner,owner->parent,&config->parent_creation))return owner;
    records=(GH_Record *)((uint8_t *)config+sizeof(*config));
    paths=(uint16_t *)((uint8_t *)records+count*sizeof(*records));
    units=0u;
    for(i=0u;i<count;++i){
        records[i].handle=owner->imported.contents[i].handle;
        records[i].volume=(uint32_t)expected[i].volume;
        records[i].index_high=(uint32_t)(expected[i].index>>32);records[i].index_low=(uint32_t)expected[i].index;
        records[i].kind=expected[i].kind;records[i].path_offset=(uint32_t)units;
        records[i].path_units=(uint32_t)expected[i].path_units;
        memcpy(paths+units,expected[i].native_path,expected[i].path_units*sizeof(*paths));
        units+=expected[i].path_units;paths[units++]=0u;
    }
    owner->config_unmap_attempted=1u;
    if(!UnmapViewOfFile(config)){GF_Error(owner,GetLastError());return owner;}
    owner->config_view=NULL;
    if(count>UINT32_MAX-8u || wcslen(image)>SIZE_MAX/sizeof(wchar_t)-80u || wcschr(image,L'"')!=NULL){
        GF_Error(owner,ERROR_ARITHMETIC_OVERFLOW);return owner;
    }
    handles=calloc(count+8u,sizeof(*handles));owner->inherit_list=handles;
    command=calloc(wcslen(image)+80u,sizeof(*command));owner->command=command;
    if(handles==NULL || command==NULL){GF_Error(owner,ERROR_NOT_ENOUGH_MEMORY);return owner;}
    handles[0]=owner->config;handles[1]=owner->job;handles[2]=owner->parent;handles[3]=owner->setup;
    handles[4]=owner->stop;handles[5]=owner->ready;handles[6]=owner->notice;
    for(i=0u;i<count;++i)handles[i+7u]=(HANDLE)owner->imported.contents[i].handle;
    nul=CreateFileW(L"NUL",GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,
        &security,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(nul==INVALID_HANDLE_VALUE){GF_Error(owner,GetLastError());return owner;}
    owner->nul=nul;handles[count+7u]=nul;
    for(i=0u;i<count+8u;++i){
        if(!SetHandleInformation(handles[i],HANDLE_FLAG_INHERIT,HANDLE_FLAG_INHERIT)){GF_Error(owner,GetLastError());return owner;}
        owner->inherited_flags=(uint32_t)i+1u;
    }
    (void)InitializeProcThreadAttributeList(NULL,1u,0u,&attribute_bytes);
    startup.lpAttributeList=calloc(1u,attribute_bytes);
    owner->attributes=startup.lpAttributeList;
    if(startup.lpAttributeList==NULL){GF_Error(owner,ERROR_NOT_ENOUGH_MEMORY);return owner;}
    if(!InitializeProcThreadAttributeList(startup.lpAttributeList,1u,0u,&attribute_bytes)){GF_Error(owner,GetLastError());return owner;}
    owner->attributes_initialized=1u;
    if(!UpdateProcThreadAttribute(startup.lpAttributeList,0u,PROC_THREAD_ATTRIBUTE_HANDLE_LIST,
        handles,(count+8u)*sizeof(*handles),NULL,NULL)){GF_Error(owner,GetLastError());return owner;}
    /* GUI subsystem and NUL streams avoid a console-host/pipe lifetime. */
    startup.StartupInfo.cb=(DWORD)sizeof(startup);
    startup.StartupInfo.dwFlags=STARTF_USESTDHANDLES;
    startup.StartupInfo.hStdInput=nul;startup.StartupInfo.hStdOutput=nul;startup.StartupInfo.hStdError=nul;
    if(_snwprintf_s(command,wcslen(image)+80u,_TRUNCATE,L"\"%ls\" --guardian-owned-config %llx",image,
        (unsigned long long)(uintptr_t)owner->config)<0){GF_Error(owner,ERROR_INVALID_DATA);return owner;}
    if(!CreateProcessW(image,command,NULL,NULL,TRUE,EXTENDED_STARTUPINFO_PRESENT|CREATE_NO_WINDOW,
        NULL,NULL,&startup.StartupInfo,&owner->creating)){GF_Error(owner,GetLastError());return owner;}
    process=owner->creating;
    owner->host=process.hProcess;owner->host_thread=process.hThread;owner->host_pid=process.dwProcessId;
    memset(&owner->creating,0,sizeof(owner->creating));
    owner->host_created=1u;
    /* Export must precede every post-CreateProcess failure path. The child has
       inherited the capabilities even before its READY message is published. */
    if(!GI_MarkExported(&owner->imported)){GF_Error(owner,ERROR_INVALID_DATA);return owner;}
    if(!GF_ResetInheritance(owner)){GF_Error(owner,owner->first_error);return owner;}
    /* The child owns its inherited setup copy now. Keeping this parent copy
       after daemon exit can prevent the job's process accounting reaching zero. */
    owner->setup_close_attempted=1u;
    if(!GF_Close(owner,&owner->setup,1u))return owner;
    if(!GF_Time(owner,owner->host,&owner->host_creation))return owner;
    GF_FreeLaunchBuffers(owner);
    if(!GF_Close(owner,&owner->nul,8u))return owner;
    owner->phase=GF_HOST_STARTING;
    return owner;
}

GF_Owner *GF_Begin(uint64_t id,GSC_Owner *channel,HANDLE job,HANDLE daemon,DWORD pid,const FILETIME *creation,const wchar_t *image) {
    return GF_BeginMode(0u,id,channel,job,daemon,pid,creation,image);
}
GF_Owner *GF_BeginIntake(uint64_t id,GSC_Owner *channel,HANDLE job,HANDLE daemon,DWORD pid,const FILETIME *creation,const wchar_t *image) {
    return GF_BeginMode(1u,id,channel,job,daemon,pid,creation,image);
}
int GF_HasIntakeContainment(const GF_Owner *owner) {
    return owner!=NULL && owner->intake_mode && owner->job!=NULL;
}
int GF_ConfirmIntakeDirectory(GF_Owner *owner,const GI_Expected *root,const GI_Expected *intake) {
    const GI_Expected *members;size_t count,i,found_root=0u,found_intake=0u;
    if(owner==NULL || !owner->intake_mode || owner->phase!=GF_READY || owner->first_error!=0u ||
        owner->stop_requested || root==NULL || intake==NULL)return 0;
    members=GSC_Records(owner->channel,&count);
    if(members==NULL || count!=owner->imported.count)return GF_Error(owner,ERROR_INVALID_DATA);
    for(i=0u;i<count;++i){
        const GI_Expected *actual=&members[i];
        if(actual->kind!=1u)continue;
        if(actual->volume==root->volume && actual->index==root->index){
            if(actual->path_units!=root->path_units || memcmp(actual->native_path,root->native_path,root->path_units*sizeof(uint16_t))!=0 ||
                owner->imported.port.validate_content(owner->imported.port.context,owner->imported.contents[i].handle,actual)!=1)
                return GF_Error(owner,owner->import_context.first_os_error);
            ++found_root;
        }
        if(actual->volume==intake->volume && actual->index==intake->index){
            if(actual->path_units!=intake->path_units || memcmp(actual->native_path,intake->native_path,intake->path_units*sizeof(uint16_t))!=0 ||
                owner->imported.port.validate_content(owner->imported.port.context,owner->imported.contents[i].handle,actual)!=1)
                return GF_Error(owner,owner->import_context.first_os_error);
            ++found_intake;
        }
    }
    return found_root==1u && found_intake==1u;
}
int GF_ReleaseIntakeSource(GF_Owner *owner) {
    if(owner==NULL || !owner->intake_mode || owner->phase!=GF_READY || owner->source_release_requested || owner->stop_requested || owner->first_error!=0u)return 0;
    owner->source_release_requested=1u;
    if(!GSC_RequestSourceRelease(owner->channel))return GF_Error(owner,GSC_FirstError(owner->channel));
    return 1;
}

GF_Phase GF_Poll(GF_Owner *owner) {
    DWORD ready,alive;
    int result;
    if(owner==NULL)return GF_RETAINED_DEBT;
    if(owner->phase==GF_RETIRED)return owner->phase;
    if(owner->retirement.uncertain)return GF_RETAINED_DEBT;
    if(owner->source_release_requested && GSC_DropSourceReference(owner->channel)<0){
        GF_Error(owner,GSC_FirstError(owner->channel));return owner->phase;
    }
    if(owner->stop_requested || owner->first_error!=ERROR_SUCCESS || owner->retirement.host_done){
        if(owner->host_created && owner->stop!=NULL && !owner->stop_requested){
            owner->stop_requested=1u;
            if(!SetEvent(owner->stop)){GF_Error(owner,GetLastError());return owner->phase;}
        }
        result=GFR_Poll(&owner->retirement);
        if(result==1)owner->phase=GF_RETIRED;
        else if(result<0)owner->phase=GF_RETAINED_DEBT;
        else if(owner->first_error==ERROR_SUCCESS)owner->phase=GF_STOPPING;
        return owner->phase;
    }
    if(!owner->host_created){GF_Error(owner,ERROR_INVALID_DATA);return owner->phase;}
    alive=WaitForSingleObject(owner->host,0u);
    if(alive==WAIT_FAILED){GF_Error(owner,GetLastError());return owner->phase;}
    if(alive==WAIT_OBJECT_0){
        result=GFR_Poll(&owner->retirement);
        if(result==1)owner->phase=GF_RETIRED;
        else if(result<0)owner->phase=GF_RETAINED_DEBT;
        else if(owner->first_error==ERROR_SUCCESS)owner->phase=GF_STOPPING;
        return owner->phase;
    }
    ready=WaitForSingleObject(owner->ready,0u);
    if(ready==WAIT_FAILED){GF_Error(owner,GetLastError());return owner->phase;}
    if(ready==WAIT_OBJECT_0){
        if(owner->notice_view->magic!=GH_CONFIG_MAGIC || owner->notice_view->id!=owner->id ||
            owner->notice_view->pid!=owner->host_pid || CompareFileTime(&owner->notice_view->creation,&owner->host_creation)!=0 ||
            owner->notice_view->ready!=1 || owner->notice_view->first_error!=0u || owner->notice_view->first_os_error!=0u){
            GF_Error(owner,ERROR_INVALID_DATA);return owner->phase;
        }
        if(owner->phase==GF_HOST_STARTING){
            if(!owner->intake_mode){
                owner->source_release_requested=1u;
                if(!GSC_RequestSourceRelease(owner->channel)){
                    GF_Error(owner,GSC_FirstError(owner->channel));return owner->phase;
                }
            }
            owner->phase=GF_READY;
        }
    }
    return owner->phase;
}
int GF_RequestStop(GF_Owner *owner) {
    if(owner==NULL || owner->phase==GF_RETIRED || owner->stop_requested)return 0;
    owner->stop_requested=1u;
    if(owner->host_created && owner->stop!=NULL && !SetEvent(owner->stop))
        return GF_Error(owner,GetLastError());
    if(owner->phase!=GF_RETAINED_DEBT)owner->phase=GF_STOPPING;
    return 1;
}
DWORD GF_FirstError(const GF_Owner *owner) {
    return owner!=NULL?owner->first_error:ERROR_INVALID_PARAMETER;
}
