"""Actual main-handler signals at unchanged stderr publication; native modeled."""
import builtins
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
from unittest import mock

P=Path(__file__).resolve().parent;source=P/'native_http_wire_fixture.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='6c37993b0895b169197748eb8812fcce8c1648f1824654e38519d95f92f5efe1'
spec=importlib.util.spec_from_file_location('canonical72_publication_closure',source);W=importlib.util.module_from_spec(spec);spec.loader.exec_module(W)
QUERY='EXPLICIT-PORTABLE-PUBLICATION-QUERY-NOT-NATIVE'
RECEIPT={'version':1,'export_status':0,'entry_count':1,'owned_status':0,'owned_present':1}

class Model:
 def __init__(self,primary):self.primary=primary;self.children=[];self.queries=0
 def acquire_owned(self,arguments,native,register,**options):
  if arguments==[QUERY,'--fixture-admin-trust-query']:
   self.queries+=1;body='import sys,json; sys.stdin.buffer.read(); sys.stdout.write(json.dumps('+repr(RECEIPT)+'))'
  else:
   assert arguments[:3]==['/usr/bin/sudo','-n','/usr/bin/security']
   assert arguments[3] in ('add-trusted-cert','remove-trusted-cert')
   code=7 if arguments[3]=='add-trusted-cert' and self.primary else 0
   body='import sys; sys.stdin.buffer.read(); sys.exit('+str(code)+')'
  process=subprocess.Popen([sys.executable,'-I','-B','-c',body],start_new_session=True,**options)
  process.output_capture=options['stdout'];process.error_capture=options['stderr']
  class Owner:
   reaped=False
   def __init__(self):self.process=process;self.settle_calls=0
   def wait_for_exit(self,timeout):self.process.wait(timeout=timeout)
   def settle(self):
    self.settle_calls+=1
    if self.process.poll() is None:self.process.terminate()
    self.process.wait(timeout=5);self.reaped=True;return True
  owner=Owner();self.children.append(owner);register(owner);return owner

def handlers():
 previous={sig:signal.getsignal(sig) for sig in (signal.SIGINT,signal.SIGTERM)};captured={}
 class Stop(Exception):pass
 def stop(*args,**kwargs):captured.update({sig:signal.getsignal(sig) for sig in previous});raise Stop()
 try:
  with mock.patch.object(W,'WireFixture',side_effect=stop),contextlib.redirect_stdout(io.StringIO()):
   try:W.main()
   except Stop:pass
 finally:
  for sig,handler in previous.items():signal.signal(sig,handler)
 assert len(captured)==2 and all(callable(handler) for handler in captured.values())
 return captured

captured=handlers();results=[];real_print=print
for primary,kind in [(False,signal.SIGINT),(False,signal.SIGTERM),(True,signal.SIGINT),(True,signal.SIGTERM),(False,'technical'),(True,'technical')]:
 fixture=None;model=Model(primary);events=[];caught=None;previous=None;out,err=io.StringIO(),io.StringIO()
 try:
  fixture=W.WireFixture(native=False);fixture.native=True;fixture.groups=model;fixture.native_groups=object();fixture.trust_query_executable=QUERY
  if kind!='technical':previous=signal.signal(kind,captured[kind])
  def publication(*args,**kwargs):
   if len(args)==1 and isinstance(args[0],str) and args[0].startswith('# native_http_trust_outcome '):
    fields=json.loads(args[0].removeprefix('# native_http_trust_outcome '))
    if fields['operation']=='add':
     child=model.children[-1].process
     assert child.returncode==(7 if primary else 0) and child.stdin.closed and child.output_capture.closed and child.error_capture.closed
     events.append('all-original-child-and-captures-closed')
     if kind=='technical':raise RuntimeError('EXPLICIT optional technical sink refusal')
     os.kill(os.getpid(),kind)
   return real_print(*args,**kwargs)
  with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err),mock.patch.object(builtins,'print',side_effect=publication):
   try:fixture.trust(True)
   except BaseException as error:caught=error
  record={'case':('existing-primary-' if primary else 'settled-add-success-')+(kind if kind=='technical' else signal.Signals(kind).name),'publications':len(events),'all_original_child_and_captures_closed_at_sink':bool(events),'query_count_before_close':model.queries,'caught_type':type(caught).__name__ if caught else None,'caught_args':list(caught.args) if caught else None}
  if primary:assert type(caught) is W.FixtureFailure and caught.args==('Native fixture command refused',) and model.queries==0
  else:assert caught is None and model.queries==1
  record['genuine_cancellation_swallowed']=not primary and kind!='technical' and caught is None
  record['original_primary_preserved']=primary and type(caught) is W.FixtureFailure and caught.args==('Native fixture command refused',)
  record['technical_optional_failure_remains_optional']=kind=='technical' and not primary and caught is None
  results.append(record)
 finally:
  if previous is not None:signal.signal(kind,previous)
  if fixture is not None:
   with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):fixture.close()
  for owned in model.children:
   child=owned.process
   if child.poll() is None:child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
   if child.stdin is not None and not child.stdin.closed:child.stdin.close()
  if results:results[-1]['all_exact_outer_children_reaped']=all(owned.process.returncode is not None for owned in model.children)
assert sum(result['genuine_cancellation_swallowed'] for result in results)==2
print(json.dumps({'qualification':'REAL_POSIX_CHILD_AND_REAL_MAIN_SIGNALS_MODELED_NATIVE_SECURITY_ONLY','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cases':results},sort_keys=True))
