local root = "/workspace/.ergopti-cloud/config-healthcheck-opener-view/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local Report = require("ui.healthcheck.report")
local outcome = Report.perform({ action = "open_path", id = "log_today" }, { log_today = assert(os.getenv("OPENER_FIXTURE_TARGET")) }, {}, {})
print("PRODUCTION_OUTCOME", require("json").encode(outcome))
