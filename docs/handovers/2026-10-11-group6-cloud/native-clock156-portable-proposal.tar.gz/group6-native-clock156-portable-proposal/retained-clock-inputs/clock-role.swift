// Fixed fixture-only clock observation. This role never touches native trust,
// proxy settings, requests or a release entrypoint.
private func fixtureClockProof() -> Int32 {
	var samples = [TimeInterval]()
	for index in 0..<16 {
		if index > 0 { usleep(10_000) }
		let sample = ProcessInfo.processInfo.systemUptime
		guard sample.isFinite, sample > 0 else { return 74 }
		samples.append(sample)
	}
	let fact: [String: Any] = [
		"version": 1, "system_uptime": samples,
	]
	guard let encoded = try? JSONSerialization.data(withJSONObject: fact,
		options: [.sortedKeys]), encoded.count <= 4_095 else { return 74 }
	let output = encoded + Data([10])
	var offset = 0
	while offset < output.count {
		let count = output.withUnsafeBytes {
			Darwin.write(STDOUT_FILENO, $0.baseAddress!.advanced(by: offset), output.count - offset)
		}
		if count < 0 && errno == EINTR { continue }
		guard count > 0 else { return 74 }
		offset += count
	}
	return 0
}
