# Bounded group6 validation-tool recovery

This is an immutable SOURCE-ONLY recovery packet outside the repository. It
contains reviewed proposals, exact preimages/deltas/registrations/pins and
prospective commands. It does not contain whole dependency snapshots, caches,
private native logs, downloaded source/package binaries or signed artifact URLs.

Dual-curl proposal2 supplies authentic checksum-pinned curl8.14.1 source and
separately labeled signed Debian7.88.1 distribution packages; no invented old
upstream source checksum, global curl/library replacement or TLS weakening.
Its actual setup/download/build/loader/admission and all eight receiving
controls are UNRUN. The setup references the pinned canonical build command
owner and requires a real authorized repository checkout, local OpenSSL SDK,
trusted Debian keyring and actual compatible host loader dependencies. A
failed/late private receipt is never sufficient admission.

Managed GET base5998 plus follow-up77947 keeps the actual public30/output18
fixtures and independent original oracle bodies. Its16 protocol models and
actual normal native30/native18 execution are UNRUN. Native fixture registration
retains exact old preimages and PRESERVATION.json; this source packet does not
claim a final immutable production dependency snapshot or CI wiring. Parent
owns mandatory aliases/planner/workflow integration and exclusive qualification.

Historical qualified component evidence is not carried forward as a new joined
feature pass. Resume only after reviewing current upstream/source preimages,
regenerating through their owner when needed, and acquiring the exclusive test
slot. Keep original assertions and physical retirement/refusal contracts;
preserve all actual failures and retained inputs. Stop at the first failure and
report pass/fail/skip/unexecuted separately. Do not claim TODO36/62 completion
or merge qualification from this recovery archive.
