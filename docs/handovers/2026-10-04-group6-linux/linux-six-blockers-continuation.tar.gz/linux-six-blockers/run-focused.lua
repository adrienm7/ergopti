local root = assert(os.getenv("ERGOPTI_SIX_ROOT"))
local stage = assert(os.getenv("ERGOPTI_SIX_STAGE"))
local repository = assert(os.getenv("ERGOPTI_HTTP_REPOSITORY"))
local phase = assert(os.getenv("ERGOPTI_SIX_PHASE"))
local driver = stage .. "/static/ergopti_plus/linux"
package.path = root .. "/support/?.lua;" .. driver .. "/?.lua;" .. driver .. "/?/init.lua;"
	.. stage .. "/static/ergopti_plus/_shared/lua/?.lua;" .. repository .. "/static/ergopti_plus/linux/?.lua;"
	.. repository .. "/static/ergopti_plus/_shared/lua/?.lua;" .. package.path
if phase == "public" then
	dofile(root .. "/controls/test_public_six_blockers.lua")
elseif phase == "aggregate" then
	dofile(root .. "/controls/test_aggregate_cancel_refusal.lua")
elseif phase == "arming" then
	dofile(root .. "/controls/test_failed_deadline_arm.lua")
elseif phase == "reentry" then
	dofile(root .. "/controls/test_cancelled_admission.lua")
elseif phase == "queue" then
	dofile(root .. "/controls/test_queued_deadline_debt.lua")
elseif phase == "preserved" then
	dofile(root .. "/controls/test_managed_http_port_migrated.lua")
	dofile(root .. "/controls/test_system_proxy_port_migrated.lua")
	dofile(root .. "/controls/test_system_proxy_callbacks_port_migrated.lua")
	dofile(root .. "/controls/test_runtime_executable_port_migrated.lua")
	dofile(root .. "/preserved-controls/test_proxy_policy.lua")
elseif phase == "deadline" then
	dofile(root .. "/controls/test_deadline_owner.lua")
else error("Unknown focused phase") end
local results = require("tests.helpers").get_results()
print(string.format("SIX BLOCKERS %s: %d passed, %d failed", phase, results.passed, results.failed))
os.exit(results.failed == 0 and 0 or 1)
