"""Root-owned genuine Linux cancellation observation; no corpus mutation."""
from pathlib import Path
import json
import os
import signal
import subprocess
import sys
import tempfile
import time

root = Path(tempfile.mkdtemp(prefix="group6-enrollment-cancel-receiving-"))
root.chmod(0o700)
environment = dict(os.environ, TMPDIR=str(root), PYTHONDONTWRITEBYTECODE="1")


def processes():
    result = {}
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            text = (entry / "stat").read_text()
            fields = text[text.rfind(") ") + 2:].split()
            result[int(entry.name)] = (int(fields[1]), fields[19])
        except (FileNotFoundError, ProcessLookupError):
            continue
    return result


action = getattr(signal, sys.argv[1])
with (root / "stdout.log").open("xb") as stdout, (root / "stderr.log").open("xb") as stderr:
    child = subprocess.Popen(
        ["node", "tools/test/test-macos-opaque-network-admission.cjs"],
        cwd="/workspace/ergopti", env=environment, stdout=stdout, stderr=stderr,
    )
    child_birth = processes()[child.pid][1]
    observed = None
    start = time.monotonic()
    while child.poll() is None:
        view = processes()
        for pid, (parent, birth) in view.items():
            cursor = parent
            chain = []
            while cursor in view and cursor != child.pid and len(chain) < 8:
                chain.append(cursor)
                cursor = view[cursor][0]
            if cursor != child.pid or len(chain) < 3:
                continue
            try:
                arguments = (Path("/proc") / str(pid) / "cmdline").read_bytes().split(b"\0")
            except (FileNotFoundError, ProcessLookupError):
                continue
            if not any(str(root).encode() in part and b"/cases/" in part and b"/tools/" in part for part in arguments):
                continue
            fresh = processes()
            if fresh.get(pid) != (parent, birth) or fresh.get(child.pid) != (os.getpid(), child_birth):
                continue
            if child.poll() is not None:
                break
            observed = {"helper_pid": pid, "helper_birth": birth, "ancestor_depth": len(chain), "node_pid": child.pid}
            (root / "LIVE-OBSERVATION.json").write_text(json.dumps(observed) + "\n")
            child.send_signal(action)
            break
        if observed is not None:
            break
        if time.monotonic() - start > 20:
            raise RuntimeError("Live original owned helper was not observed; no cancellation credit")
        time.sleep(0.002)
    status = child.wait()
assert observed is not None, "No active-helper cancellation was executed"
assert status == 1, "Cancelled cohort must refuse"
cohorts = list(root.glob("ergopti-release-owned-ci-*"))
assert len(cohorts) == 1 and (cohorts[0] / "cases").is_dir(), "Cancelled inputs must remain"
receipts = list((cohorts[0] / "corpus.owner").glob("closed.json"))
closed = []
for path in receipts:
    packet = json.loads(path.read_text())
    if packet.get("phase") == "command" and packet.get("state") == "closed":
        assert packet.get("cancelled") is True and packet.get("status") == 1
        closed.append(packet)
assert len(closed) == 1, "Original native owner must publish exact cancelled closed receipt"
assert observed["helper_pid"] not in processes(), "Observed helper must be physically retired"
assert not (cohorts[0] / "corpus.json").exists(), "Interrupted corpus cannot claim a passing receipt"
report = {"signal": sys.argv[1], "node_status": status, "live_helper_observed": True,
          "helper_retired": True, "inputs_retained": True, "native_closed": closed[0],
          "passing_corpus_absent": True, "no_macos_native_credit": True}
(root / "RECEIVING.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"root": str(root), "signal": sys.argv[1], "verdict": "passed"}))
