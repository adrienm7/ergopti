"""Read-only candidate preservation and strict forward/inverse checks in a private tree."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil
import subprocess
import tempfile

P = Path(__file__).resolve().parent
REL = 'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
PRE = P / 'preimage' / REL
POST = P / 'candidate' / REL
source, candidate = PRE.read_bytes(), POST.read_bytes()
assert hashlib.sha256(source).hexdigest() == '6c37993b0895b169197748eb8812fcce8c1648f1824654e38519d95f92f5efe1'
assert b'\r' not in source + candidate
assert (Path('/workspace/ergopti') / REL).read_bytes() == source

def functions(data):
    text = data.decode()
    tree = ast.parse(text)
    return {f'{getattr(parent, "name", "module")}.{node.name}': ast.get_source_segment(text, node)
            for parent in [tree, *ast.walk(tree)] if isinstance(parent, (ast.Module, ast.ClassDef))
            for node in parent.body if isinstance(node, ast.FunctionDef)}

before, after = functions(source), functions(candidate)
assert before.keys() == after.keys()
changed = [name for name in before if before[name] != after[name]]
assert set(changed) == {'WireFixture.__init__', 'WireFixture._command', 'WireFixture.close'}
command = ast.parse(after['WireFixture._command'])
settles = [node for node in ast.walk(command) if isinstance(node, ast.Call)
           and isinstance(node.func, ast.Attribute) and node.func.attr == 'settle']
assert len(settles) == 1
assert 'group_settled is not True' in after['WireFixture._command']
assert 'if group_settled is True:' in after['WireFixture._command']
assert 'not hasattr(self, "command_group_debt")' not in after['WireFixture._command']
patch = ''.join(difflib.unified_diff(source.decode().splitlines(True), candidate.decode().splitlines(True), fromfile='a/' + REL, tofile='b/' + REL))
inverse = ''.join(difflib.unified_diff(candidate.decode().splitlines(True), source.decode().splitlines(True), fromfile='a/' + REL, tofile='b/' + REL))
(P / 'proposal.patch').write_text(patch)
(P / 'inverse.patch').write_text(inverse)
private = Path(tempfile.mkdtemp(prefix='g6-guard-inverse-', dir='/tmp'))
private.chmod(0o700)
try:
    target = private / REL
    target.parent.mkdir(parents=True)
    target.write_bytes(source)
    for name, expected in [('proposal.patch', candidate), ('inverse.patch', source)]:
        for arguments in [['--check'], []]:
            result = subprocess.run(['git', 'apply', *arguments, str(P / name)], cwd=private, capture_output=True)
            assert result.returncode == 0, result.stderr
        assert target.read_bytes() == expected
    assert [str(path.relative_to(private)) for path in private.rglob('*') if path.is_file()] == [REL]
finally:
    shutil.rmtree(private)
manifest = {
    'qualification': 'PORTABLE_CONTROLLED_SOFTWARE_CORRECTION_ONLY_NO_DARWIN_NATIVE_CREDIT_NO_ADOPTION',
    'path': REL, 'preimage_sha256': hashlib.sha256(source).hexdigest(),
    'candidate_sha256': hashlib.sha256(candidate).hexdigest(),
    'frozen_prototype_sha256': hashlib.sha256((P / 'frozen_guard.py').read_bytes()).hexdigest(),
    'changed_functions': changed, 'exact_unchanged_functions': [name for name in before if before[name] == after[name]],
    'original_settle_calls_in_command': len(settles),
    'forward_inverse_private_apply': 'PASS_EXACT_SOURCE_BYTES_AND_SINGLE_PATH_RESTORED',
    'ownership': 'Exact same owner retained at registration and bounded original-finally recovery; original settle once; retire only identity True ACK; no proxy/new child owner/second settle/new clocks',
    'corpus': 'Original72 unchanged; additive guard18 separately authored; first new test assumption error retained in receiving-attempt1',
    'files': {name: hashlib.sha256((P / name).read_bytes()).hexdigest() for name in ['proposal.patch', 'inverse.patch', 'portable_guard_tests.py', 'receive72.py', 'reproduce.py']},
}
if (P / 'portable-receiving.json').exists():
    manifest['receiving_sha256'] = hashlib.sha256((P / 'portable-receiving.json').read_bytes()).hexdigest()
(P / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, sort_keys=True))
