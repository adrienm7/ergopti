﻿; ui/menu/menu_llm/managed_runtime_consent.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Source-Owned Managed Runtime Consent
; DESCRIPTION:
; Presents the existing localized install/model offers through the real modal
; owner. A returned Yes is intent only; selection/source is checked again.
; ==============================================================================

global _OllamaManagedConsentOwner := 0

/** Confirms official acquisition; no website or installer fallback is started. */
OllamaManagedArchiveConsent(Captured, Asset, Port := 0) {
	if !(Asset is Map) || !(Asset.Get("asset_id", 0) is String)
		return false
	local canonical := OllamaReleaseWindowsAsset(Asset["asset_id"])
	for name in ["asset_id", "version", "filename", "sha256", "bytes", "url"]
		if Type(Asset.Get(name, 0)) != Type(canonical[name]) || !(Asset.Get(name, 0) == canonical[name])
			return false
	return _OllamaManagedConfirm(Captured, "ollama.offer_download", "ollama.offer_body", "", Port)
}

/** Model transfer retains a distinct explicit consent and originating selection. */
OllamaManagedModelConsent(Captured, Port := 0) {
	if !(Captured is Map) || !(Captured.Get("model", 0) is String) || Captured["model"] == ""
		return false
	return _OllamaManagedConfirm(Captured, "llm.local_model.missing_title", "llm.local_model.missing_body", Captured["model"], Port)
}

_OllamaManagedConsentPort(Port, Name, Default) {
	if !(Port is Map) || !Port.Has(Name)
		return Default
	if !HasMethod(Port[Name], "Call")
		throw TypeError("Managed consent port must be callable.")
	return Port[Name]
}

_OllamaManagedConfirm(Captured, TitleKey, BodyKey, Model, Port) {
	global _OllamaManagedConsentOwner, _LLM_LocalModelAsking
	if !IsSet(_LLM_LocalModelAsking)
		throw Error("Managed consent requires the initialized local-model modal owner.")
	local copy := OllamaManagedCopySnapshot(Captured)
	local read := _OllamaManagedConsentPort(Port, "snapshot", OllamaManagedSnapshot)
	if !OllamaManagedSelectionCurrent(copy, read.Call())
		return false
	local previous := Critical("On")
	try {
		if IsObject(_OllamaManagedConsentOwner) && !_LLM_LocalModelAsking
			return false
		local owner := Map("captured", copy)
		_OllamaManagedConsentOwner := owner
		_LLM_LocalModelAsking := true
	} finally Critical(previous)
	local accepted := false
	try {
		local title := t(TitleKey), body := t(BodyKey)
		if Model != ""
			body := StrReplace(body, "{1}", Model)
		local confirm := _OllamaManagedConsentPort(Port, "confirm", Ui_MsgBox)
		local answer := confirm.Call(body, title, "YesNo Default2 Icon?")
		accepted := answer is String && answer == "Yes"
		local current := read.Call()
		return accepted && _OllamaManagedConsentOwner == owner && !A_IsSuspended
			&& OllamaManagedSelectionCurrent(copy, current)
	} finally {
		previous := Critical("On")
		try {
			if _OllamaManagedConsentOwner == owner {
				_OllamaManagedConsentOwner := 0
				_LLM_LocalModelAsking := false
			}
		} finally Critical(previous)
	}
}
