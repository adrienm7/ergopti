CURRENT: Query debt successor80c/fac1 is included. Original81e4 and968 review are historical after the discovered source HOLD. No genuine new behavioral regression was authored; all native execution remains UNRUN. Read CURRENT-SOURCE-STATUS.json before receiving.

Future VHD source custody handover — INERT, NOT ADOPTED

This archive carries actual reviewed source/fixture/patch/manifest/review bodies, stored once by SHA256 in BLOBS. INDEX.json maps every exact original supplier path/reference to its included bytes; original review/manifests are unchanged, including their historical absolute paths. FINAL-SOURCE-INDEX.json selects65 future source/test/locale paths. SOURCE-VERSIONS records prior declared bodies; they are history, not additional active code. COMPOSITION/FUTURE-SOURCE-vs-PUBLIC538.patch is itself found through INDEX and compares exact final bodies against genuine public538 Git preimages.

Read a body without executing source: python3 body.py EXACT_INDEX_KEY. Verify archive payload: python3 verify.py. Neither tool imports application modules or writes to a checkout. Public538 unchanged helper compiler suppliers are included as real bodies in a separate index; host SDK/toolchain/HSP dependencies and frozen SDK receiving are not manufactured. This is source custody, not a standalone qualified build environment.

Read OVERLAP-ORDER-AND-LIMITS.json before any composition. In particular, defaultSDK5 preserves actual SDK4f397 test lineage and must replace the historical private d770 branch only through the reviewed explicit join. The new coexistence purpose/typed private consent leaves active stock refusal intact. Whole-package scripts must never execute. One exact original pkg/plist/raw frame copy is included only as inert source resources; metadata code uses public descriptor UNPACK/PACK, actual Darwin outcomes remain UNRUN.

Independent reviews are full bodies under INDEX, not inferred grants. Original6/scoped7/roster3/defaultSDK5 source/portable receipts do not grant current full-source/profile/native approval. No frozen9caa/53/99/SDK32 count, signature or recipe is changed here. Native source test methods in NATIVE-TEST-ROSTER-UNRUN are all unexecuted; portable Python23/23-O,19,35/35-O remain separate saved controls, not native qualification.

Excluded: drafts, unrelated Linux work, complete source views, Git object stores, user logs, environment values, PAC/tokens/credentials. Canonical files/refs/index, CI/workflows and remote publication were untouched. Parent owns independent receiving and any later inert publication.
