"""Build only after explicit parent GO; never writes a project checkout.

This prepared program performs no API request, Git mutation or test execution.
Every publication and gate must have closed before it reads any source log.
"""

import argparse
import collections
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


ROOT = Path('/workspace/.ergopti-cloud')
ORIGINAL_TREE = '9835c0d63617f156a3c272e46019690b2249aaf6'
ORIGINAL_CI = '66df66373b18f362efdc440b8400eb00f0a0a989'
EXPECTED_TREE = 'e7992152329049e0953ca8de057e7d33ba6ed55a'
EXPECTED_CI = 'ee2bba32802b64a4189195eb11ada3e7dd76ebd4'
REPAIRED_PATH = 'static/ergopti_plus/macos/tests/unit/ui/test_healthcheck_report_issue.lua'
REPAIRED_SHA256 = 'd7c986c7c9fcb4fb6748c0f2cbf83d1247b221b10fdee757476a8e3785c6ee1f'
ARCHIVE_NAME = '2026-10-15-RELOAD-AND-DIAGNOSTICS-RECEIVING.tar.gz'
PREFIX = 'reload-and-diagnostics/'
FORBIDDEN_FILES = {'resume18-ci-archive-job.stderr'}
SECRET = re.compile(
    rb'(?:https?://[^\s\"\'<>]*[?&](?:sig|signature|x-amz-signature|x-goog-signature)=)'
    rb'|(?:[?&](?:sig|signature)%3[dD])'
    rb'|(?:Authorization\s*:\s*(?:Bearer|Basic)\s+\S+)'
    rb'|(?:\bgh[pousr]_[A-Za-z0-9]{20,})'
    rb'|(?:\bgithub_pat_[A-Za-z0-9_]{30,})',
    re.I,
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def read_json(path):
    return json.loads(Path(path).read_text())


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, stderr=subprocess.PIPE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--go', required=True, choices=['seal-closed-resume18-receipts'])
    parser.add_argument('--repo', default='/workspace/ergopti')
    parser.add_argument('--inputs', default=str(ROOT / 'resume18-proof-inputs.json'))
    parser.add_argument('--publication', required=True,
                        help='Closed two-atom publication receipt; state must be PUBLISHED')
    parser.add_argument('--feature-sha', required=True,
                        help='Actual second atomic feature commit; its whole tree must match CI')
    parser.add_argument('--ci-prefix', default=str(ROOT / 'resume18-ci-terminal'))
    parser.add_argument('--ci2-prefix', default=str(ROOT / 'resume18-ci2-terminal'))
    parser.add_argument('--output', required=True,
                        help='New external archive path under .ergopti-cloud; parent owns repository copy')
    args = parser.parse_args()
    repo = Path(args.repo).resolve()
    output = Path(args.output).resolve()
    assert output.is_relative_to(ROOT) and output.name == ARCHIVE_NAME
    assert output.parent in {ROOT, ROOT / 'resume18-proof-sealed'}, 'Archive output must stay outside every source view'
    assert not output.exists(), 'Refuse to overwrite an existing evidence archive'
    assert re.fullmatch('[0-9a-f]{40}', args.feature_sha)
    inputs = read_json(args.inputs)
    publication = read_json(args.publication)
    assert publication['state'] == 'PUBLISHED'
    assert publication['final_sha'] == args.feature_sha
    assert publication['final_tree'] == EXPECTED_TREE
    assert publication['final_tree_matches_ci_candidate'] is True
    atoms = publication['commits']
    assert len(atoms) == 2 and [atom['label'] for atom in atoms] == ['mac', 'tail']
    assert all(atom['state'] == 'PUBLISHED' and atom['automatic_census_closed'] is True for atom in atoms)
    assert atoms[-1]['sha'] == args.feature_sha and atoms[-1]['parent'] == atoms[0]['sha']
    source = read_json(ROOT / 'resume18-ci-source.json')
    corrected_source = read_json(ROOT / 'resume18-ci2-source.json')
    repaired = read_json(ROOT / 'resume18-repaired-candidate.json')
    composition = read_json(ROOT / 'resume18-mac-composition.json')
    assert source['ci_sha'] == ORIGINAL_CI and source['candidate_tree'] == ORIGINAL_TREE
    assert source['os_lanes'] == 'macos+linux' and source['release_guard'] == 'push-only'
    assert composition['tree'] == ORIGINAL_TREE
    assert source['source_sha256'] == composition['source_sha256']
    assert repaired['previous_tree'] == ORIGINAL_TREE and repaired['tree'] == EXPECTED_TREE
    assert repaired['previous_ci_sha'] == ORIGINAL_CI and repaired['ci_sha'] == EXPECTED_CI
    assert repaired['delta_paths'] == [REPAIRED_PATH] and repaired['delta_selected_gates'] == ['hs']
    assert corrected_source['ci_sha'] == EXPECTED_CI
    assert corrected_source.get('candidate_tree', corrected_source.get('tree')) == EXPECTED_TREE
    assert corrected_source['os_lanes'] == 'macos' and corrected_source['release_guard'] == 'push-only'
    final_sources = repaired['source_sha256']
    assert final_sources[REPAIRED_PATH] == REPAIRED_SHA256
    assert set(final_sources) == set(source['source_sha256'])
    assert [path for path in final_sources if final_sources[path] != source['source_sha256'][path]] == [REPAIRED_PATH]
    if 'source_sha256' in corrected_source:
        assert corrected_source['source_sha256'] == final_sources
    assert git(repo, 'rev-parse', args.feature_sha + '^{tree}').decode().strip() == EXPECTED_TREE
    assert git(repo, 'rev-parse', EXPECTED_CI + '^{tree}').decode().strip() == EXPECTED_TREE
    assert git(repo, 'rev-parse', ORIGINAL_CI + '^{tree}').decode().strip() == ORIGINAL_TREE
    assert git(repo, 'diff', '--name-only', ORIGINAL_CI, EXPECTED_CI).decode().splitlines() == [REPAIRED_PATH]
    assert git(repo, 'rev-parse', atoms[0]['sha'] + '^').decode().strip() == source['feature_base']
    assert git(repo, 'rev-parse', args.feature_sha + '^').decode().strip() == atoms[0]['sha']
    assert set(atoms[0]['paths']).isdisjoint(atoms[1]['paths'])
    assert set(atoms[0]['paths'] + atoms[1]['paths']) == set(final_sources)

    # All three logical and physical brackets must close before reading raw logs.
    expected_commands = {
        'js': ['plan', 'format', 'js'],
        'linux': ['plan', 'linux-e2e', 'linux', 'strict'],
        'mac': ['plan', 'hs', 'hs-e2e', 'strict'],
    }
    gates = {}
    for lane, commands in expected_commands.items():
        receipt = ROOT / ('resume18-composed-' + lane + '.json')
        gate = read_json(receipt)
        assert gate['state'] == ('FAILED' if lane == 'mac' else 'PASSED')
        assert gate['inputs_unchanged'] is True
        assert gate['before'] == gate['after'] and gate.get('finished_utc')
        assert gate['before']['head'] == source['feature_base']
        assert gate['before']['index'] == ORIGINAL_TREE
        assert gate['before']['paths_sha256'] == source['source_sha256']
        assert [item['name'] for item in gate['commands']] == commands
        assert all(item['exit_code'] == (1 if lane == 'mac' and item['name'] == 'hs' else 0)
                   for item in gate['commands'])
        log = receipt.with_suffix('.log')
        assert digest(log.read_bytes()) == gate['log_sha256']
        gates[lane] = gate
    assert len({gate['repo'] for gate in gates.values()}) == 3
    repaired_gate = read_json(ROOT / 'resume18-repaired-hs.json')
    assert repaired_gate['state'] == 'PASSED' and repaired_gate['inputs_unchanged'] is True
    assert repaired_gate['before'] == repaired_gate['after'] and repaired_gate.get('finished_utc')
    assert repaired_gate['before']['head'] == source['feature_base']
    assert repaired_gate['before']['index'] == EXPECTED_TREE
    assert repaired_gate['before']['paths_sha256'] == final_sources
    assert repaired_gate['selected'] == ['hs'] and repaired_gate['delta'] == ORIGINAL_CI + '..' + EXPECTED_CI
    assert [item['name'] for item in repaired_gate['commands']] == ['delta-plan', 'hs', 'strict']
    assert all(item['exit_code'] == 0 for item in repaired_gate['commands'])
    assert repaired_gate['commands'][0]['command'] == ['node', 'tools/test/verify-change.cjs', '--range=' + repaired_gate['delta'], '--plan']
    assert repaired_gate['commands'][1]['command'] == ['node', 'tools/test/verify-change.cjs', '--range=' + repaired_gate['delta']]
    assert digest((ROOT / 'resume18-repaired-hs.log').read_bytes()) == repaired_gate['log_sha256']
    older_linux = read_json(ROOT / 'resume18-linux-gate.json')
    assert older_linux['state'] == 'PASSED' and older_linux['inputs_unchanged'] is True
    assert older_linux['before'] == older_linux['after'] and older_linux.get('finished_utc')
    assert digest((ROOT / 'resume18-linux-gate.log').read_bytes()) == older_linux['log_sha256']

    # API outcomes can be failed, successful or skipped; never invent a green CI.
    ci_paths, ci2_paths = ({key: Path(prefix + '-' + key + '.json')
                           for key in ['run', 'jobs', 'artifacts', 'receipt']}
                          for prefix in [args.ci_prefix, args.ci2_prefix])

    def receive_ci(paths, descriptor, sha, tree):
        run, jobs = read_json(paths['run']), read_json(paths['jobs'])
        terminal = read_json(paths['receipt'])
        assert run['status'] == 'completed' and run['head_sha'] == sha
        assert run['event'] == 'workflow_dispatch'
        assert all(job['status'] == 'completed' for job in jobs)
        assert terminal['status'] == 'completed' and terminal['actual_sha'] == sha
        assert terminal['tree'] == tree and terminal['run_id'] == run['id'] == descriptor['run_id']
        assert terminal['conclusion'] == run['conclusion']
        outcomes = dict(collections.Counter(job['conclusion'] for job in jobs))
        assert terminal['outcomes'] == outcomes and terminal['total_jobs'] == len(jobs)
        assert not any(job['conclusion'] == 'cancelled' for job in jobs)
        return run, jobs, terminal, outcomes

    original_run, original_jobs, original_terminal, original_outcomes = receive_ci(ci_paths, source, ORIGINAL_CI, ORIGINAL_TREE)
    assert original_run['conclusion'] == 'failure', 'Original owned fixture failure must remain failed'
    run, jobs, terminal, outcomes = receive_ci(ci2_paths, corrected_source, EXPECTED_CI, EXPECTED_TREE)

    members, excluded = {}, []
    closed_reads = []

    def add(name, data):
        assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
        assert not SECRET.search(data), 'Sensitive or signed-URL content in approved member: ' + name
        members[name] = data

    def copy_file(relative, required=True, actual=None):
        path = Path(actual) if actual else ROOT / relative
        assert path.is_relative_to(ROOT)
        if not path.exists():
            assert not required, 'Required closed input is absent: ' + relative
            return
        assert path.is_file() and not path.is_symlink()
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        if path.name in FORBIDDEN_FILES or path.suffix == '.stderr' or SECRET.search(data):
            assert not required, 'Required input needs explicit safe receiving/redaction: ' + relative
            excluded.append({'path': relative, 'bytes': len(data), 'sha256': digest(data),
                             'reason': 'Excluded sensitive or signed-URL raw content; no raw content copied'})
            return
        add('receipts/' + relative, data)
        closed_reads.append((path, digest(data)))

    # Explicit allowlist only; there is no recursive discovery at seal time.
    for relative in inputs['required_root_files']:
        if relative.startswith('resume18-ci2-terminal-'):
            suffix = relative.removeprefix('resume18-ci2-terminal-').removesuffix('.json')
            copy_file(relative, actual=ci2_paths[suffix])
        elif relative.startswith('resume18-ci-terminal-'):
            suffix = relative.removeprefix('resume18-ci-terminal-').removesuffix('.json')
            copy_file(relative, actual=ci_paths[suffix])
        elif relative == 'resume18-diagnostics-publication.json':
            copy_file(relative, actual=Path(args.publication).resolve())
        else:
            copy_file(relative)
    for relative in inputs['optional_root_files'] + inputs['author_files']:
        copy_file(relative, required=False)
    for entry in inputs['excluded']:
        if isinstance(entry, str):
            relative = entry
            reason = 'Explicit parent exclusion: signed redirect URL; raw content never copied'
        else:
            assert isinstance(entry, dict) and set(entry) == {'path', 'reason'}, 'Invalid explicit exclusion record'
            relative, reason = entry['path'], entry['reason']
        assert isinstance(relative, str) and relative and not Path(relative).is_absolute()
        assert '..' not in Path(relative).parts, 'Exclusion path must stay in the cloud root'
        assert isinstance(reason, str) and reason and not SECRET.search(reason.encode())
        path = ROOT / relative
        if path.exists():
            assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT.resolve())
            before = path.stat()
            data = path.read_bytes()
            after = path.stat()
            assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
            actual_digest = digest(data)
            excluded.append({'path': relative, 'bytes': len(data),
                             'sha256': actual_digest, 'reason': reason})
            closed_reads.append((path, actual_digest))

    # Immutable Git object reads make the packet independent of future worktrees.
    for path, expected in final_sources.items():
        postimage = git(repo, 'show', args.feature_sha + ':' + path)
        assert digest(postimage) == expected
        add('source/final/' + path, postimage)
        probe = subprocess.run(['git', 'cat-file', '-e', source['feature_base'] + ':' + path],
                               cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if probe.returncode == 0:
            add('source/preimage/' + path, git(repo, 'show', source['feature_base'] + ':' + path))
        else:
            assert path.endswith('2026-10-15-SELECTED-FILE-AND-MAC-OPENER.md')
    linux_pub = read_json(ROOT / 'resume18-linux-publication.json')
    assert linux_pub['state'] == 'PUBLISHED' and linux_pub['commit'] == source['feature_base']
    for path, expected in linux_pub['source_sha256'].items():
        postimage = git(repo, 'show', args.feature_sha + ':' + path)
        assert digest(postimage) == expected
        add('source/final/' + path, postimage)
        add('source/linux-preimage/' + path, git(repo, 'show', linux_pub['parent'] + ':' + path))
    for sha in [linux_pub['commit'], atoms[0]['sha'], args.feature_sha, EXPECTED_CI]:
        add('git/' + sha + '.txt', git(repo, 'show', '--no-patch', '--format=raw', sha))
    add('git/' + ORIGINAL_CI + '.txt', git(repo, 'show', '--no-patch', '--format=raw', ORIGINAL_CI))
    add('source/original-ci/' + REPAIRED_PATH, git(repo, 'show', ORIGINAL_CI + ':' + REPAIRED_PATH))
    add('git/owned-fixture-repair.patch', git(repo, 'diff', '--binary', ORIGINAL_CI, EXPECTED_CI, '--', REPAIRED_PATH))
    add('git/diagnostics.patch', git(repo, 'diff', '--binary', source['feature_base'], args.feature_sha, '--', *final_sources))
    add('git/linux-watcher.patch', git(repo, 'diff', '--binary', linux_pub['parent'], linux_pub['commit'], '--', *linux_pub['paths']))
    add('input-allowlist.json', Path(args.inputs).read_bytes())
    add('builder.py', Path(__file__).read_bytes())
    add('excluded-inputs.json', encoded(excluded))
    summary = {
        'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_feature_sha': args.feature_sha,
        'source_feature_tree': EXPECTED_TREE,
        'ci_sha': EXPECTED_CI,
        'ci_run': corrected_source['run_url'],
        'ci_conclusion': run['conclusion'],
        'ci_outcomes': outcomes,
        'original_ci': {'sha': ORIGINAL_CI, 'tree': ORIGINAL_TREE, 'run': source['run_url'],
                        'conclusion': original_run['conclusion'], 'outcomes': original_outcomes},
        'original_local_brackets': {'tree': ORIGINAL_TREE, 'js': 'PASSED', 'linux': 'PASSED',
                                    'mac': 'FAILED: hs only; E2E and strict passed'},
        'repaired_local_bracket': {'tree': EXPECTED_TREE, 'selected_by_actual_delta_mapper': ['hs'], 'state': 'PASSED'},
        'reuse_boundary': 'Actual whole-tree Git diff T1..T2 is exactly one Mac unit fixture. Production, shared/data/tools/E2E and all other unit sources are identical. Original T1 outcomes remain unchanged.',
        'feature_commits': [linux_pub['commit'], *[atom['sha'] for atom in atoms]],
        'limitations': [
            'Original T1 Mac units and original C1 CI remain FAILED; the fixture correction does not retroactively change those runs.',
            'Source-specific frozen T1 gates plus exact one-path T2 repaired HS/CI receiving only; no future archive commit qualification.',
            'Failed and unqualified causal/fixture attempts remain dated, separate raw author records.',
            'API job outcomes and permitted annotations do not establish unreceived raw hosted assertions or artifact contents.',
            'Native URL request admission does not qualify rendered GitHub fields or installed browser/window acceptance.',
            'Complete daily-log collection and installed cross-platform acceptance remain open; no TODO item closed.',
            'Feature publication does not establish Dev/Main integration or Root handback.',
        ],
    }
    add('RECEIVING.json', encoded(summary))
    add('README.md', (
        '# Reload and diagnostics receiving\n\n'
        'RECEIVING.json records the exact published source and CI boundary. '
        'The original T1 Mac gate and original C1 CI remain FAILED. The T2 fixture repair is '
        'joined through its actual one-path Git delta, delta-mapper selection, full HS follow-up '
        'and separate C2 CI. Frozen local logs and their before/after brackets qualify their capture only. '
        'Author records preserve intermediate failed and unqualified attempts; consult their receipts '
        'before interpreting a raw count. No success is inferred from file presence.\n\n'
        'MANIFEST.json hashes every payload member. SHA256SUMS additionally hashes MANIFEST.json. '
        'SHA256SUMS is the checksum carrier and therefore does not claim a self hash. '
        'The builder independently reopens every regular tar member and verifies the complete name set '
        'and all payload/manifest checksums. No links or directory entries are admitted.\n\n'
        'Sensitive signed-redirect stderr is excluded. Only hashes, byte sizes and reasons identify '
        'excluded inputs; no signed URL, authorization header or session history is published.\n'
    ).encode())
    manifest = {name: {'sha256': digest(data), 'bytes': len(data)}
                for name, data in sorted(members.items())}
    add('MANIFEST.json', encoded({'schema': 1, 'payload_members': manifest}))
    checksums = ''.join(digest(data) + '  ' + name + '\n' for name, data in sorted(members.items())).encode()
    add('SHA256SUMS', checksums)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation preserves any prior packet, including a failed attempt.
    with output.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, data in sorted(members.items()):
                    entry = tarfile.TarInfo(PREFIX + name)
                    entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
                    archive.addfile(entry, io.BytesIO(data))

    # Independent archive reopen: verify all names, regular types and actual bytes.
    with tarfile.open(output, 'r:gz') as archive:
        actual = archive.getmembers()
        assert len(actual) == len(members)
        assert len({entry.name for entry in actual}) == len(actual)
        assert {entry.name for entry in actual} == {PREFIX + name for name in members}
        received = {}
        for entry in actual:
            assert entry.isfile() and not entry.issym() and not entry.islnk()
            data = archive.extractfile(entry).read()
            name = entry.name.removeprefix(PREFIX)
            assert len(data) == len(members[name]) and digest(data) == digest(members[name])
            assert not SECRET.search(data)
            received[name] = data
        reopened_manifest = json.loads(received['MANIFEST.json'])['payload_members']
        assert reopened_manifest == manifest
        assert received['SHA256SUMS'] == checksums
        for name, record in reopened_manifest.items():
            assert digest(received[name]) == record['sha256'] and len(received[name]) == record['bytes']
    for path, expected in closed_reads:
        assert digest(path.read_bytes()) == expected, 'Closed input changed during sealing: ' + path.name
    receipt = {
        'state': 'SEALED_AND_INDEPENDENTLY_REOPENED', 'archive': str(output),
        'sha256': digest(output.read_bytes()), 'bytes': output.stat().st_size,
        'regular_members_checked': len(members), 'payload_manifest_entries': len(manifest),
        'source_feature_sha': args.feature_sha, 'source_tree': EXPECTED_TREE,
        'ci_sha': EXPECTED_CI, 'ci_conclusion': run['conclusion'], 'ci_outcomes': outcomes,
        'excluded_inputs': excluded, 'repository_write_stage_commit': 'NOT PERFORMED; parent owns publication',
    }
    receipt_path = output.with_suffix(output.suffix + '.receiving.json')
    assert not receipt_path.exists()
    receipt_path.write_bytes(encoded(receipt))
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
