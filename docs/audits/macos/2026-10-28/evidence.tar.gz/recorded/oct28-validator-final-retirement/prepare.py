from pathlib import Path
import os,subprocess,json,hashlib,tarfile,datetime,stat
S=Path('/workspace/scratch/oct28-validator-final-retirement'); ROOT=Path('/workspace/ergopti-macos-integration'); ORIG=Path('/workspace/ergopti')
def git(p,*a,check=True):
 r=subprocess.run(['git','-C',str(p),*a],capture_output=True)
 if check and r.returncode:raise RuntimeError((a,r.returncode,r.stderr.decode(errors='replace')))
 return r

def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot(p):
 gd=Path(git(p,'rev-parse','--absolute-git-dir').stdout.decode().strip())
 return dict(head=git(p,'rev-parse','HEAD').stdout.decode().strip(),index_sha=sha((gd/'index').read_bytes()),HEAD_sha=sha((gd/'HEAD').read_bytes()),deps_inode=(p/'node_modules').stat().st_ino)
def process_refs(p):
 refs=[];unknown=[];zombies=[];needle=os.fsencode(p)
 for d in Path('/proc').iterdir():
  if not d.name.isdigit() or int(d.name)==os.getpid():continue
  try:
   if d.stat().st_uid!=os.getuid():continue
   procstat=(d/'stat').read_text(); state=procstat[procstat.rindex(')')+2:].split()[0]
   if state=='Z':
    zombies.append(int(d.name));continue
   hits=[]
   for name in ['cwd','exe']:
    try:
     v=os.readlink(d/name)
     if v==str(p) or v.startswith(str(p)+'/'):hits.append(name)
    except FileNotFoundError:pass
   for f in (d/'fd').iterdir():
    try:
     v=os.readlink(f)
     if v==str(p) or v.startswith(str(p)+'/'):hits.append('fd:'+f.name)
    except FileNotFoundError:pass
   for name in ['environ','maps','cmdline']:
    try:
     if needle in (d/name).read_bytes():hits.append(name)
    except FileNotFoundError:pass
   if hits:refs.append({'pid':int(d.name),'hits':hits,'cmdline':(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')[:400]})
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:unknown.append(int(d.name))
 return dict(refs=refs,unknown=unknown,zombie_count=len(zombies),zombie_scope='Z processes have no live userspace or retained cwd/fd; none reaped or signalled')

def inventory(p):
 rows=[];total=blocks=0
 for root,dirs,files in os.walk(p,followlinks=False):
  for name in dirs+files:
   f=Path(root)/name;t=f.lstat();total+=t.st_size;blocks+=t.st_blocks*512
 return {'logical_bytes':total,'allocated_bytes':blocks}

def physical(p):
 raw=git(p,'ls-files','--stage','-z').stdout;count=0;h=hashlib.sha256()
 for item in raw.split(b'\0'):
  if not item:continue
  meta,name=item.split(b'\t',1);mode,oid,stage=meta.split();assert stage==b'0';f=p/os.fsdecode(name)
  if mode==b'120000':body=os.fsencode(os.readlink(f))
  else:
   assert f.is_file() and not f.is_symlink(),str(f)
   body=f.read_bytes();actual=b'100755' if f.stat().st_mode&0o111 else b'100644';assert actual==mode,(str(f),actual,mode)
  actual=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest().encode();assert actual==oid,(str(f),actual,oid)
  h.update(item+b'\0');count+=1
 return {'tracked_entries':count,'census_sha256':h.hexdigest(),'physical_matches_index':True}

TARGETS=[('common','ergopti-macos-dock','4c6c8a8f03fe284a0dbe5a869366630eed18c03b'),('hs','ergopti-macos-verify-batch18-hs','4c6c8a8f03fe284a0dbe5a869366630eed18c03b')]
report={'started_paris':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).isoformat(),'state':'PREPARATION','targets':[],'before':{'root':snapshot(ROOT),'original':snapshot(ORIG)},'free_before':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize}
for zone,name,expected in TARGETS:
 p=Path('/workspace')/name;row={'zone':zone,'path':str(p),'expected_head':expected};report['targets'].append(row)
 try:
  assert git(p,'rev-parse','HEAD').stdout.decode().strip()==expected
  row['branch']=git(p,'symbolic-ref','--short','HEAD').stdout.decode().strip();row['tree']=git(p,'write-tree').stdout.decode().strip();row['process']=process_refs(p)
  assert not row['process']['refs'] and not row['process']['unknown'],row['process']
  assert git(p,'diff','--exit-code',check=False).returncode==0
  assert git(p,'ls-files','--others','--exclude-standard','-z').stdout==b''
  if zone in ('common','hs'):
   assert row['tree']=='2aa61ec29cebd49834e27ee751ad5121d95b7dd0'
   patch=git(p,'diff','--cached','--binary','--full-index').stdout;assert sha(patch)=='1ff8e48eb8a0e647bae485bd1ebca6d427654adb61ff787a7523aed508750bbe'
  else:assert git(p,'diff','--cached','--exit-code',check=False).returncode==0
  row['physical']=physical(p);row['size_before']=inventory(p)
  gd=Path(git(p,'rev-parse','--absolute-git-dir').stdout.decode().strip());(S/(zone+'-index.raw')).write_bytes((gd/'index').read_bytes())
  row['ignored']=git(p,'ls-files','--others','--ignored','--exclude-standard','-z').stdout.split(b'\0');row['ignored']=[os.fsdecode(v) for v in row['ignored'] if v]
  row['ready']=True
 except Exception as e:row['ready']=False;row['blocked']=str(e)
(S/'preparation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'ready':[(r['zone'],r['ready'],str(r.get('blocked',''))[:100],len(r.get('ignored',[])),r.get('size_before'))for r in report['targets']]}))
