from pathlib import Path
import subprocess,json,hashlib
root=Path('/workspace/ergopti-windows-r6-tests');packet=Path(__file__).parent
paths=json.loads((packet/'owned-paths.json').read_text());before=json.loads((packet/'candidate-hashes.json').read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')=='e4565ae0e6162d8da099ca6222f709652cc00b8e'
assert set(git('diff','--cached','--name-only').splitlines())==set(before)
assert set(git('diff','HEAD','--name-only').splitlines())==set(paths)
for name,value in before.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==value
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
subprocess.run(['sh','.husky/pre-commit'],cwd=root,check=True)
after={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths}
for name,value in before.items():assert after[name]==value
(packet/'native-sut-preservation.json').write_text(json.dumps({'previous_seven_hashes':before,'all_previous_sut_bytes_unchanged':True,'added_consumers':['tools/lib/menu-native-personal-shortcuts-binding.cjs','tools/test/test-menu-parity.cjs']},indent=2)+'\n')
(packet/'candidate-hashes.json').write_text(json.dumps(after,indent=2)+'\n')
