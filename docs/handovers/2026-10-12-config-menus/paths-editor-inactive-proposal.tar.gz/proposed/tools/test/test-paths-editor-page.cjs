// tools/test/test-paths-editor-page.cjs

/**
 * ==============================================================================
 * MODULE: Paths Editor Page Regression
 * DESCRIPTION:
 * Executes the actual shared page and host bridge for Windows, macOS and Linux.
 * Independent folder values and native messages pin user intent across the two
 * initialization signals the hosts can deliver to one document.
 * ==============================================================================
 */

'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '../..');
const SHARED = path.join(ROOT, 'static/ergopti_plus/_shared');
const PAGE = path.join(SHARED, 'ui/paths_editor');
const html = fs.readFileSync(path.join(PAGE, 'index.html'), 'utf8');
const script = fs.readFileSync(path.join(PAGE, 'script.js'), 'utf8');
const bridge = fs.readFileSync(path.join(SHARED, 'ui/host_bridge.js'), 'utf8');
const LOCALES = [
	'ar',
	'cs',
	'da',
	'de',
	'en',
	'es',
	'fr',
	'he',
	'hi',
	'it',
	'ja',
	'ko',
	'nl',
	'no',
	'pl',
	'pt',
	'ru',
	'sv',
	'tr',
	'uk',
	'zh'
];
const PLATFORM = ['windows', 'macos', 'linux'];
const EXPECTED = Object.freeze({
	initial: Object.freeze({ config: '/config-B/', logs: '/logs-L/' }),
	next: Object.freeze({ config: '/config-C/', logs: '/logs-M/' }),
	defaults: Object.freeze({ config: '/default-A/', logs: '/default-logs/' }),
	nextDefaults: Object.freeze({
		config: '/new-default-A/',
		logs: '/new-default-logs/'
	}),
	typed: '  /typed-D/  ',
	picked: '/picked-P/'
});

/** Creates one document from the actual HTML, with isolated host ports and timers. */
function loadPage(platform) {
	const elements = new Map();
	const translated = [];
	const timers = [];
	const messages = [];
	const errors = [];
	for (const match of html.matchAll(/<([a-z][a-z0-9]*)\b([^>]*)>/gi)) {
		const attributes = new Map();
		for (const attr of match[2].matchAll(/([\w-]+)="([^"]*)"/g)) attributes.set(attr[1], attr[2]);
		const listeners = new Map();
		const classes = new Set();
		const element = {
			tagName: match[1].toUpperCase(),
			value: attributes.get('value') || '',
			textContent: '',
			className: attributes.get('class') || '',
			getAttribute: (name) => attributes.get(name) ?? null,
			addEventListener(name, callback) {
				listeners.set(name, callback);
			},
			dispatch(name) {
				assert.ok(listeners.has(name), `actual ${name} listener exists`);
				listeners.get(name)({ target: element });
			},
			classList: {
				toggle(name, enabled) {
					if (enabled) classes.add(name);
					else classes.delete(name);
				},
				contains: (name) => classes.has(name)
			}
		};
		if (attributes.has('id')) elements.set(attributes.get('id'), element);
		if (attributes.has('data-i18n')) translated.push(element);
	}
	const document = {
		title: '',
		getElementById(id) {
			assert.ok(elements.has(id), `actual HTML declares ${id}`);
			return elements.get(id);
		},
		querySelectorAll(selector) {
			assert.equal(selector, '[data-i18n]');
			return translated;
		}
	};
	const window = { __ergopti_host: platform === 'linux' ? 'linux' : platform };
	if (platform === 'windows')
		window.chrome = {
			webview: {
				postMessage(value) {
					assert.equal(typeof value, 'string', 'real WebView2 bridge emits JSON text');
					messages.push(JSON.parse(value));
				}
			}
		};
	else
		window.webkit = {
			messageHandlers: {
				hsPaths: {
					postMessage(value) {
						assert.equal(typeof value, 'object', 'real WebKit bridge emits structured payload');
						messages.push(JSON.parse(JSON.stringify(value)));
					}
				}
			}
		};
	const context = vm.createContext({
		window,
		document,
		setTimeout(callback) {
			timers.push(callback);
		},
		console: {
			error(...args) {
				errors.push(args);
			}
		}
	});
	vm.runInContext(bridge, context, { filename: 'host_bridge.js' });
	vm.runInContext(script, context, { filename: 'paths_editor/script.js' });
	function flush() {
		let count = 0;
		while (timers.length) {
			assert.ok(++count < 20, 'bounded page timer queue');
			timers.shift()();
		}
		assert.deepEqual(errors, [], 'host bridge has no swallowed submission failure');
	}
	flush();
	assert.deepEqual(messages, [{ action: 'ready' }], 'actual ready transport is unchanged');
	return {
		window,
		document,
		elements,
		translated,
		messages,
		init(data) {
			window.initData(data);
		},
		type(name, value) {
			const element = elements.get(`input-${name}-dir`);
			element.value = value;
			element.dispatch('input');
		},
		click(id) {
			elements.get(id).dispatch('click');
			flush();
		},
		pick(name, value) {
			this.click(name === 'logs' ? 'btn-browse-logs' : 'btn-browse');
			assert.deepEqual(
				messages.at(-1),
				{ action: 'browse', target: name },
				'native picker target remains exact'
			);
			window.applyBrowseResult(value, name);
		},
		save() {
			this.click('btn-save');
			return messages.at(-1);
		}
	};
}

/** Creates an independent host payload; directory expectations never come from page state. */
function payload(code, current = EXPECTED.initial, defaults = EXPECTED.defaults) {
	const strings = JSON.parse(
		fs.readFileSync(path.join(SHARED, 'data/locales', `${code}.json`), 'utf8')
	);
	return {
		configDir: current.config,
		logsDir: current.logs,
		defaultConfigDir: defaults.config,
		defaultLogsDir: defaults.logs,
		strings
	};
}

/** Asserts visible values, tags and the exact two-field native save payload. */
function expectFolders(page, folders, data) {
	for (const name of ['config', 'logs']) {
		const value = folders[name];
		assert.equal(
			page.elements.get(`input-${name}-dir`).value,
			value,
			`${name}: raw user intent remains visible`
		);
		assert.equal(
			page.elements.get(`default-${name}-dir`).textContent,
			data[name === 'config' ? 'defaultConfigDir' : 'defaultLogsDir']
		);
		const isDefault = value === data[name === 'config' ? 'defaultConfigDir' : 'defaultLogsDir'];
		assert.equal(
			page.elements.get(`tag-${name}-dir`).textContent,
			data.strings[isDefault ? 'paths_editor.tag_default' : 'paths_editor.tag_modified'],
			`${name}: translated tag reflects live intent`
		);
		assert.equal(
			page.elements.get(`tag-${name}-dir`).className,
			isDefault ? 'tag-default' : 'tag-modified'
		);
		assert.equal(
			page.elements.get(`input-${name}-dir`).classList.contains('is-default'),
			isDefault
		);
	}
	assert.deepEqual(
		page.save(),
		{ action: 'save', configDir: folders.config, logsDir: folders.logs },
		'saved native payload retains exact raw folders'
	);
}

let passed = 0;
const failures = [];
function check(name, run) {
	try {
		run();
		passed++;
	} catch (error) {
		failures.push({ name, message: error.message });
	}
}

check('Windows retrieves the changed page script through a versioned asset URL', () => {
	const actual = [...html.matchAll(/<script\b[^>]*src="([^"]+)"/g)].map((entry) => entry[1]);
	const pageAssets = actual.filter((src) => src.startsWith('script.js'));
	assert.equal(pageAssets.length, 1);
	assert.match(pageAssets[0], /^script\.js\?v=[1-9]\d*$/);
	assert.ok(
		actual.indexOf('../host_bridge.js') >= 0 &&
			actual.indexOf('../host_bridge.js') < actual.indexOf(pageAssets[0]),
		'actual HTML loads the host bridge before the page'
	);
});

for (const platform of PLATFORM) {
	check(`${platform}: initialization and unchanged controls retain the original protocol`, () => {
		const page = loadPage(platform);
		const data = payload('en');
		page.init(data);
		expectFolders(page, EXPECTED.initial, data);
		page.window.applyBrowseResult('', 'logs');
		expectFolders(page, EXPECTED.initial, data);
		page.click('btn-cancel');
		assert.deepEqual(page.messages.at(-1), { action: 'cancel' });
	});
	for (const name of ['config', 'logs']) {
		for (const mode of ['typed', 'cleared', 'picked']) {
			check(
				`${platform}: duplicate initialization retains ${name} ${mode} intent and refreshes its untouched sibling`,
				() => {
					const page = loadPage(platform);
					page.init(payload('en'));
					const intended =
						mode === 'typed' ? EXPECTED.typed : mode === 'picked' ? EXPECTED.picked : '';
					if (mode === 'picked') page.pick(name, intended);
					else page.type(name, intended);
					const next = payload('fr', EXPECTED.next, EXPECTED.nextDefaults);
					page.init(next);
					expectFolders(page, { ...EXPECTED.next, [name]: intended }, next);
					page.init(next);
					expectFolders(page, { ...EXPECTED.next, [name]: intended }, next);
				}
			);
			check(`${platform}: delayed first initialization retains ${name} ${mode} intent`, () => {
				const page = loadPage(platform);
				const intended =
					mode === 'typed' ? EXPECTED.typed : mode === 'picked' ? EXPECTED.picked : '';
				if (mode === 'cleared') page.type(name, EXPECTED.typed);
				if (mode === 'picked') page.pick(name, intended);
				else page.type(name, intended);
				const first = payload('en');
				page.init(first);
				expectFolders(page, { ...EXPECTED.initial, [name]: intended }, first);
			});
		}
	}
	check(
		`${platform}: reset retains the user-selected defaults across duplicate initialization`,
		() => {
			const page = loadPage(platform);
			page.init(payload('en'));
			page.type('config', EXPECTED.typed);
			page.click('btn-reset');
			const next = payload('fr', EXPECTED.next, EXPECTED.nextDefaults);
			page.init(next);
			expectFolders(page, EXPECTED.defaults, next);
		}
	);
	check(
		`${platform}: reset before initialization is inert and a new document initializes freshly`,
		() => {
			const page = loadPage(platform);
			page.click('btn-reset');
			const data = payload('en');
			page.init(data);
			expectFolders(page, EXPECTED.initial, data);
			page.type('config', EXPECTED.typed);
			const replacement = loadPage(platform);
			const next = payload('fr', EXPECTED.next, EXPECTED.nextDefaults);
			replacement.init(next);
			expectFolders(replacement, EXPECTED.next, next);
		}
	);
	for (const code of LOCALES) {
		check(
			`${platform}: ${code} labels, defaults and tags refresh without changing either edited folder`,
			() => {
				const page = loadPage(platform);
				page.init(payload('en'));
				page.type('config', EXPECTED.typed);
				page.pick('logs', EXPECTED.picked);
				const next = payload(code, EXPECTED.next, {
					config: EXPECTED.typed,
					logs: EXPECTED.nextDefaults.logs
				});
				page.init(next);
				expectFolders(page, { config: EXPECTED.typed, logs: EXPECTED.picked }, next);
				for (const element of page.translated) {
					const key = element.getAttribute('data-i18n');
					assert.equal(
						typeof next.strings[key],
						'string',
						`${code}: declared translation exists for ${key}`
					);
					if (
						element === page.elements.get('tag-config-dir') ||
						element === page.elements.get('tag-logs-dir')
					)
						continue;
					assert.equal(
						element.tagName === 'TITLE' ? page.document.title : element.textContent,
						next.strings[key]
					);
				}
			}
		);
	}
}

console.log(JSON.stringify({ passed, failed: failures.length, failures }, null, 2));
if (failures.length) process.exitCode = 1;
