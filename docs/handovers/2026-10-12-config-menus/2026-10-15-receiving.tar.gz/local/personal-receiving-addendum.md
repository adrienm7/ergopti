## Personal proposal custody and native follow-up

Fresh preimage comparisons on Dev `f1b1d0b208bf6d24f5cd923718c7b0ca6f2fcaf7`
confirm seven exact patch preimages and two changed consumers:
`tools/test/test-menu-manifest.cjs` and `tools/test/test-menu-parity.cjs`.
All three protected dependency pins match, including the independent
`hotstring_personal_frames.json` corpus. The inactive archive retains SHA-256
`d363f5f18be730371977064c72fccafecc17de774ab780337397eca07f610302`;
all 27 sealed members were authenticated. No patch is adopted.

Root must compose the shared helper/schema and JS consumer changes while
preserving the invocation-local target and explicit native-target grammar
from `f89c9fb60` and `6818cd94e`. The three archived parity hunks retain unique
contexts; the manifest patch's terminal three-line context occurs six times,
so its addition belongs only at the actual EOF. The cleanup71 helper still
requires owner receiving; its historical receipt does not supply the absent
`receive-personal-default-v4-source.cjs` script. Independent enumeration
confirms 31 prepared behavioral controls and 12 source witnesses, all native
UNRUN. The historical 71 source results qualify neither cohort.

The packet covers only the default child. Current Windows source still has
four append sites in `ui/menu/menu_hotstrings.ahk`: default at line 945,
file at 1109, folder children at 1301 and tree parent at 1323. Published
census remains 16/2/1; older folder line offsets are not current source
coordinates. Fresh owning-generator receiving remains required after
composition; no ceiling or TODO item is reduced from this audit.

Receive these four boundaries on an isolated Windows source/installation:

1. Default child: use two identically described sections, a separator and an
   empty inventory. Verify native order, disambiguated captions, None/selected
   checkmarks and retained selection/close-on-add repaint without rebuilding
   or borrowing a successor's menus.
2. File child: use an admitted file and an unavailable file. Verify original
   open/control/section order, active counts, inert unavailable sections,
   UTF-16 captions and the exact finished child retained by its parent.
3. Folder children: use nested folders with sorted files, folders-only,
   files-only and empty nodes. Verify the conditional boundary, positive and
   nonpositive captions, count-before-name coercion and recursive child custody.
4. Tree parent: call the append route with a borrowed menu containing a
   sentinel row, and the row-return route separately. Verify sorted publication;
   inject declaration withdrawal, foreign-child and primary/cleanup failures.
   Refusal must retire only newly owned descendants and dispatcher entries,
   preserve the borrowed sentinel and foreign detached owners, and retain the
   primary error. Exact repair must permit a fresh construction.

Record the source SHA, interpreter identity, complete warning/stdout/stderr,
original callback results and owned-handle retirement. Root owns principal
registration and receiving; preserve `#Warn` and every assertion. Then qualify
complete units, E2E, packaging, installation and installed tray behavior.
Historical file-caption receiving remains separate. Items 54/81 and
transversal 16/38 remain partial.
