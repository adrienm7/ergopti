# V2 source correction and future independent CI ownership request

SOURCE-ONLY FUTURE EPOCH. No helper, workflow, guard, current approval contract,
compiler, formatter, test runner, native process, archive download or extraction
was implemented/executed. V1 and its f38d982c blocked review remain immutable.

## Minimal test correction

Only the new active-cancellation method changes. It snapshots the exact clean
HELD/ACTIVE prefix before CANCEL. After original wait/finish it requires that
prefix, exactly one final canonical RETIRED, and accepts zero or one canonical
V1 PENDING nonnegative-int32 receipt in between. At most one is the unchanged
native producer's actual pendingSent contract, not a widened arbitrary protocol.
Original session limits remain128 bytes, five-second waits and validReceipt;
PENDING is never settlement. The exact prior identity/group/physical retirement,
helper exit0, stream privacy and post-image checks remain. No new deadline or
progress polling is added. Entire original19188-byte file/session/14 tests stay
byte-exact. The literal37 method stays byte-exact with V1.

## Correction1: closed acquisition failure must not hide the old14

A new setup command must distinguish THREE outcomes, bound to the same fresh
source SHA/nonce/acquisition owner:

- READY: exact authenticated private runtime and all known resources retired;
  publish its explicit bindings, then execute all14+2 native methods.
- CLOSED_PREREQUISITE_FAILED: actual metadata/download/inspection refusal with
  positive proof of no allocated child OR exact registered retirement and all
  owned readers closed. Publish a closed FAILED/unqualified prerequisite receipt,
  clear every runtime binding, and still execute the all14+2 selected test cohort.
  The new two methods then refuse at their missing-environment entry BEFORE any
  OwnedProgramTestSession/child acquisition; no XCTest skip/default omission.
  Old14 remain selected/reachable. The late own receiving MUST exit nonzero,
  report prerequisite_failed/two real payloads UNEXECUTED, and never treat a
  transport step's continued control flow as a native pass.
- CLEANUP_UNKNOWN: absent capability is not proof of no allocation. An exception
  after native allocation, failed exact settlement, lost reader-close receipt or
  ambiguous construction retains uncertainty. It must prohibit the following
  program cohort, keep evidence, and fail late receiving. Do not convert it to
  CLOSED_PREREQUISITE_FAILED merely because a generic exception was caught.

Implementation needs a retained observer of the SAME registered native owner
before acquisition returns (existing macos_owned_process capability), plus exact
reader ownership. This is not a second cleanup owner or PID-based retry. The
existing owned_tool already keeps protected cleanup locally; an outer observed
registration may record its exact capabilities for outcome classification but
cannot fabricate retirement from an exception class/return code/string.

Shell/control-flow design must validate the closed typed outcome, not append
`|| true`, continue-on-error, an anonymous fallback or a generic success receipt.
Known closed refusal may continue toward original tests only to collect truthful
results; the later fatal receiver guarantees job failure. UNKNOWN forbids any
new native allocation; only pure receiving/artifact collection follows.

READY runtime native-test failures remain failures with raw script/tee statuses;
unknown test cleanup cannot authorize subsequent overlapping native work.
The own two-case receipt cannot override old14 or any earlier archive/SDK error.

## Correction2: package-only CI is not reachable now

Actual committed job graph d316:

- package-macos has needs[e2e-hs,managed-ollama-native]. Current independent
  managed-native failures skip the package job. Enrolling only there cannot
  produce new native evidence in the presently failing CI graph.
- item36-native has NO needs, runs macos-latest, manual/nonrelease-only condition,
  job budget25minutes, existing archive filter four original classes at step117
  with20-minute budget, and independent no-prompt SDK filter at139 with3minutes.
- managed-ollama-native also has no needs and both actual native architecture
  matrix hosts, but contains G5/G6 producer/SDK/PAC/component custody. It is not
  permission to borrow a component source epoch or duplicate the separately
  reserved G5 core-sdk-operational proposal.

Recommended finite future route: item36-native, append the new prerequisite,
program capture, late own receiver and closed-artifact steps AFTER the existing
no-prompt SDK observation and BEFORE/adjacent the existing diagnostic upload.
Keep the existing archive and SDK filters, commands, receipts, source checks,
conditions and budgets untouched. This placement means a new prerequisite cannot
suppress the already-existing archive/SDK steps; an unknown new helper cannot
leave later foreign native steps running in this job. Parent must coordinate
this exact item36/G6 workflow cut; this is NOT an existing lease or implementation.

New setup/program steps use explicit !cancelled() plus exact own-closed-outcome
admission for program allocation; the late receiving/artifact run always. A
closed failed prerequisite still admits the old14+new2 cohort with cleared
bindings and a fatal own verdict. An unknown setup outcome withholds that cohort
and records it UNEXECUTED for safety, never skipped/passed as qualification.
Use a separate bounded selected receiver for the exact old14/new2 classes. The
original14 notice and full-package collector remain unchanged: their generic
All-tests/PAC-bound semantics cannot be relabeled Selected tests or handed a
fabricated PAC receipt for this component run.

Important limit: existing25-minute overall/20-minute archive/3-minute SDK budgets
are unchanged. If they consume the job before the new cohort, it is UNEXECUTED;
this plan does not guarantee spare time, move an old filter, remove a case or
widen a budget. Hosted timing observation is still required. If no useful finite
window remains, a separately coordinated independent component executor is
required. Do not silently add a new job/exit or appropriate G5's reserved job.

A package receiving row may later consume the same exact successful component
receipt only under an explicit source/run/host join; component PASS is not package,
installed app, HS discovery-to-consumer or all-architecture PASS.

## Future source approval barrier (mandatory)

Appending this test source changes an actual original source image OUTSIDE the
current NumberRow99/100/SDK112 permitted replacements. Whole-prefix preservation,
self-hash, archive pinning and a peer SOURCE_CLEAR do not grant admission. This
packet must have a SEPARATE future source admission/qualification epoch with
explicit Group5 coordination for OwnedProgramWorkerTests.swift. Never edit or
stretch the existing SDK112/G5-source-approvals/NumberRow schema, claim current
projections accept it, regenerate historical53/51/18/native12/TIS7 expectations,
or overwrite any currently executing subject to include it.

After explicit approval, item36's existing fresh begin/judge source receipts can
bind the NEW canonical source epoch without rewriting historical receipts. Its
archive/SDK method filters remain unchanged. Other jobs that use older exact
source approval sets remain unqualified until their owners authorize a separate
composition; this proposal does not repair that by inference.

## Revised prospective exact seven-path cuts

1. OwnedProgramWorkerTests.swift: this append-only V2 class, separate future G5
   source admission; old entire file/session/14 bodies unchanged.
2. NEW tools/diagnostics/native_powershell_program/prepare_runtime.py: fixed
   Microsoft selector, existing token/TLS/native ownership reuse, exact three-way
   outcome and separate Selected16 receiver, all design-only.
3. NEW tools/diagnostics/native_powershell_program/test_prepare_runtime.py:
   meaningful independent controls including closed403->old14 reachable/final
   fatal, unknown retirement->no new native allocation, both native archives,
   malformed/missing source/case/status/closure, real original protocol progress.
4. ci-macos.yml: ONLY future item36-native four new step spans. Names proposed:
   Prepare genuine PowerShell 7.5.4 native runtime;
   Capture original program corpus and actual PowerShell native execution;
   Receive actual PowerShell native program receipts;
   Retain actual PowerShell native program evidence.
   No package-only enrollment, existing jobs/needs/filter/body/budget mutation,
   G5 core-sdk-operational or managed-ollama-native overlap.
5. test-ci-pipeline-wiring.cjs: additive exact new names/conditions/source/outcome/
   ordering/artifact rows and meaningful negative mutations, no old row weakening.
6. ci-full-default.cjs: ONLY four corresponding literal FULL_STEPS entries for
   item36-native and exact conditions; no blanket alternative/exception.
7. test-ci-full-default.cjs: additive new enrollment/closed-outcome/late-fatal
   reachability controls and mutations preserving every old test/roster row.

The helper's existing token/TLS/owned-tool/Mach-O reuse and official native asset
pins remain as detailed in the immutable V1 design/plan. No .NET apphost-only
copy, quarantining/signing/TCC bypass, PATH/Rosetta assumption or new default
product timing is added. Receipt source fields are preparation, not approval.

All compiler/portable/native qualification remains UNRUN during Parent59328.
The author requests the original reviewer to rejoin V2 source/design only.
