"""Freeze terminal portable receipts; never grant native clock acceptance."""
from pathlib import Path
import hashlib
import json
import tarfile

BASE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
physical=next(BASE.glob('future-clock156-*'))
controls=next(BASE.glob('clock-parser-controls-*'))
physical_receipt=json.loads((physical/'receipt.json').read_text())
control_receipt=json.loads((controls/'receipt.json').read_text())
assert physical_receipt['exit']==0
raw=(physical/'physical156.stderr').read_text()
assert 'Ran 156 tests in 45.131s' in raw and '\nOK\n' in raw
facts=control_receipt['facts']
assert len(facts)==6
assert all(f['tests']==13 and f['errors']==0 and f['skips']==0 for f in facts)
assert facts[0]['exit']==0 and facts[0]['failures']==0
assert [(f['label'],f['failures']) for f in facts[1:]]==[('endpoint_only',85),('missing_exact_sixteen',4),('missing_original_cap',1),('unbounded_run_attempt',2),('partial_epoch_optional',3)]
assert all(f['exit']==1 for f in facts[1:])
summary={'qualification':'PORTABLE_PHYSICAL_DEFAULT156_AND_INDEPENDENT13_OMISSIONS_PASS_NO_ADOPTION_NO_NATIVE_CREDIT','physical_default156':{'tests':156,'failures':0,'errors':0,'skips':0,'seconds':45.131,'exit':0,'receipt':str((physical/'receipt.json').relative_to(BASE)),'raw_stdout_sha256':sha(physical/'physical156.stdout'),'raw_stderr_sha256':sha(physical/'physical156.stderr')},'parser_context':facts,'failure_count_unit':'unittest assertion/subtest records, not failed-method count','native_probe_execution':'NONE','post_run_source_fence_sha256':sha(BASE/'post-run-source-fence.json'),'exact_143_source_body_vector_proof':sha(BASE/'preservation-proof.json'),'source_only78_archive_sha256':'b94d3465ec9cba43647f16af9cb1921540acc3828a7c42690bc83cd820be2663','all_receiving_rounds':'TERMINAL','unexecuted':['Darwin native Swift compile','actual signed16 Foundation/Python common-epoch calibration','official run/job/attempt/source/Git cleanliness joining','SDK49','PAC14 ARM/AMD','E2E','packaging','installation','Actions','Swift factory/startup45 activation']}
(BASE/'qualification.json').write_text(json.dumps(summary,indent=2)+'\n')
manifest=json.loads((BASE/'composition-manifest.json').read_text());manifest['qualification']=summary['qualification'];manifest['new_fixed13_helper']['unit']='PASS_PHYSICAL_FIXED_PATH13';manifest['unexecuted']=[v for v in manifest['unexecuted'] if v!='portable156'];(BASE/'composition-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Each round's copied physical source stays on disk for audit. The capsule carries
# one exact finite runtime closure and exact mutant images, not eight duplicates.
files=[]
for path in sorted(BASE.rglob('*')):
    if not path.is_file() or path.name=='capsule-inventory.json':continue
    rel=path.relative_to(BASE)
    if rel.parts[0].startswith('future-clock156-') and len(rel.parts)>1 and rel.parts[1]=='source':continue
    if rel.parts[0].startswith('clock-parser-controls-') and len(rel.parts)>1 and rel.parts[1] in ['candidate']+[f['label'] for f in facts[1:]]:continue
    assert not path.is_symlink() and '__pycache__' not in path.parts and path.suffix!='.pyc'
    files.append(path)
inventory={str(path.relative_to(BASE)):{'bytes':path.stat().st_size,'sha256':sha(path)} for path in files}
(BASE/'capsule-inventory.json').write_text(json.dumps({'qualification':summary['qualification'],'files':inventory,'omitted_duplicate_physical_sources':'received and retained outside archive; exactly reconstructible from finite25 runtime closure and pinned five mutant images'},indent=2)+'\n')
archive=BASE.parent/'group6-native-clock156-portable-proposal.tar.gz'
with tarfile.open(archive,'w:gz') as capsule:
    for path in files+[BASE/'capsule-inventory.json']:
        capsule.add(path,arcname=str(Path(BASE.name)/path.relative_to(BASE)),recursive=False)
print(json.dumps({'capsule':str(archive),'bytes':archive.stat().st_size,'members':len(files)+1,'sha256':sha(archive),'inventory_sha256':sha(BASE/'capsule-inventory.json'),'qualification_sha256':sha(BASE/'qualification.json')},sort_keys=True))
