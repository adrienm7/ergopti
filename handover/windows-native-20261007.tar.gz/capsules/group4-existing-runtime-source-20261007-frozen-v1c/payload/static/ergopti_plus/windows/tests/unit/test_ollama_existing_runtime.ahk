﻿; tests/unit/test_ollama_existing_runtime.ahk

; ==============================================================================
; MODULE: Existing Managed Runtime Inspection Recording Controls
; DESCRIPTION:
; Exercises actual dispatch and physical-result policy with recorded transport.
; Native process, descriptor and restart receiving remain separate gates.
; ==============================================================================

class _OMI_Port {
	__New() {
		this.Owned := false
		this.Action := ""
	}
	HasOwner() {
		return this.Owned
	}
	Dispatch(Action, Request, Authority, Callback) {
		this.Action := Action
		this.Owned := true
		return true
	}
}

class _OMI_Files extends OllamaManagedFilesDefault {
	__New() {
		this.Port := _OMI_Port()
		this.Receipts := []
		this.IntakeRows := []
		this.NextId := 0
		this.CurrentRecord := 0
	}
}

_OMI_Request() {
	return Map("ManagedRoot", "C:\owned-inspection-model", "AssetId", "windows-amd64",
		"CatalogueSha256", Format("{:064}", 0), "InspectMetadataBytes", 8192)
}

_OMI_Frame(Asset) {
	return '{"ok":1,"phase":"missing","asset":' . JsonStringLiteral(Asset)
		. ',"catalogue_sha256":' . JsonStringLiteral(_OMI_Request()["CatalogueSha256"]) . '}'
}

_OMI_Begin(Files) {
	AssertTrue(Files.Dispatch("inspect", _OMI_Request(), Map(), (*) => 0))
	AssertEqual(Files.Port.Action, "inspect")
	AssertTrue(Files.HasOwner(), "An unfinished inspection must retain its actual task slot.")
	return Files.CurrentRecord
}

_OMI_MissingIsExactReadOnlyResult() {
	local files := _OMI_Files(), row := _OMI_Begin(files)
	AssertTrue(files._Physical("inspect", _OMI_Request(), Map("exit", 0, "stdout", _OMI_Frame("windows-amd64"), "stderr", "")))
	AssertEqual(row["phase"], "missing")
	AssertFalse(files.HasFileDebt())
	AssertTrue(files.HasOwner(), "Physical result adoption cannot manufacture the port callback ACK.")
}

_OMI_RefusalIsNotInstallationDebt() {
	local files := _OMI_Files(), row := _OMI_Begin(files)
	AssertTrue(files._Physical("inspect", _OMI_Request(), Map("exit", 1, "stdout", "", "stderr", "")))
	AssertEqual(row["phase"], "inspection-refused")
	AssertFalse(files.HasFileDebt(), "The read-only worker cannot create a durable install cleanup obligation.")
	AssertTrue(row["first_error"] != "")
	AssertTrue(files.HasOwner(), "A refused result must still await its real port handback.")
	local result := 0
	files._Logical(row, (Value) => result := Value, Map())
	AssertFalse(result["ok"])
}

_OMI_ForeignMissingRefuses() {
	local files := _OMI_Files(), row := _OMI_Begin(files)
	AssertTrue(files._Physical("inspect", _OMI_Request(), Map("exit", 0, "stdout", _OMI_Frame("windows-arm64"), "stderr", "")))
	AssertEqual(row["phase"], "inspection-refused")
	AssertTrue(row["first_error"] != "")
	AssertFalse(files.HasFileDebt())
}

_OMI_InstallRefusalStillRetainsDebt() {
	local files := _OMI_Files()
	AssertTrue(files.Dispatch("prepare", _OMI_Request(), Map(), (*) => 0))
	AssertTrue(files._Physical("prepare", _OMI_Request(), Map("exit", 1, "stdout", "", "stderr", "")))
	AssertEqual(files.CurrentRecord["phase"], "retained-file-debt")
	AssertTrue(files.HasFileDebt(), "Inspection policy must not waive a real mutating installation's debt.")
}

Test("Ollama inspection exact missing result", _OMI_MissingIsExactReadOnlyResult)
Test("Ollama inspection refusal physical handback", _OMI_RefusalIsNotInstallationDebt)
Test("Ollama inspection foreign source refusal", _OMI_ForeignMissingRefuses)
Test("Ollama inspection mutating debt unchanged", _OMI_InstallRefusalStillRetainsDebt)
