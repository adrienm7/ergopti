"""Copy bounded exact original sources; no target import or checkout writes."""
from pathlib import Path
import hashlib
import json
import os
import stat

PACKET = Path(__file__).parent
ROOT = Path('/workspace/ergopti')
DIAGNOSTIC = Path('/tmp/group6-http-debug-certificate-code-4e9-tb831oxi')
TEST = 'tools/test/macos_native_http_receiving_facts_test.py'
WORKER = 'static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/ManagedHTTPWorker.swift'
SOURCES = [TEST, WORKER,
    'static/ergopti_plus/macos/tests/support/native_http_fixture_main.swift',
    'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py',
    'static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py']
OWNERS = ['tools/test/run-linux-managed-http-native.cjs',
    'tools/test/run-linux-managed-http-phase.py',
    'tools/build/stage-linux-network-runtime.py', 'tools/lib/git_bash.py']

def fact(path):
    observed = path.lstat()
    if not stat.S_ISREG(observed.st_mode):
        raise RuntimeError('Exact regular source required')
    return {'path': str(path), 'dev': str(observed.st_dev), 'ino': str(observed.st_ino),
            'uid': str(observed.st_uid), 'mode': str(observed.st_mode),
            'bytes': observed.st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def copy(path, raw):
    path.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    path.chmod(0o600)
    return fact(path)

manifest = json.loads((PACKET / 'SOURCE-PACKET.json').read_text())
native = json.loads((DIAGNOSTIC / 'SOURCE-ACK.json').read_text())
assert fact(ROOT / TEST)['sha256'] == manifest['preimage_sha256']
assert fact(ROOT / WORKER)['sha256'] == native['preimage_sha256']
originals = [fact(ROOT / name) for name in SOURCES + OWNERS]
originals.append(fact(Path('/workspace/ergopti-subreaper.py')))
originals.append(fact(Path('/workspace/.tools/node/node_modules/node/bin/node')))
originals.append(fact(Path('/workspace/.tools/python/bin/python3').resolve()))
assert fact(ROOT / OWNERS[2])['sha256'] == 'ac48a4e9755fb2b9e9cbe35c81b097942bf7be76d14466e03b891b4c78f302f5'
old_test = (ROOT / TEST).read_bytes()
new_test = (PACKET / 'payload' / TEST).read_bytes()
old_worker = (ROOT / WORKER).read_bytes()
new_worker = (DIAGNOSTIC / 'payload' / WORKER).read_bytes()
assert hashlib.sha256(new_test).hexdigest() == manifest['candidate_sha256']
assert hashlib.sha256(new_worker).hexdigest() == native['candidate_sha256']
assert [x for x in old_test.splitlines() if b'self.assert' in x] == [x for x in new_test.splitlines() if b'self.assert' in x]
function = (PACKET / 'function.candidate.swift').read_bytes()
assert new_worker.count(function) == 1
altered_return = function.replace(b'return "certificate"', b'return "complete"', 1)
raw_echo = function.replace(b'code=\\(code)', b'code=\\(error.localizedDescription)', 1)
assert altered_return != function and raw_echo != function
variants = {
    'before': (old_test, old_worker),
    'unadmitted': (old_test, new_worker),
    'admitted': (new_test, new_worker),
    'inverse': (new_test, old_worker),
    'altered-return': (new_test, new_worker.replace(function, altered_return, 1)),
    'raw-error-echo': (new_test, new_worker.replace(function, raw_echo, 1)),
    'duplicate-function': (new_test, new_worker + b'\n' + function),
    'partial-diagnostic': (new_test, new_worker.replace(b'\t\t#if DEBUG\n', b'\t\t#if DEBUG_PARTIAL\n', 1)),
}
private = []
for name in OWNERS:
    private.append(copy(PACKET / 'owner' / name, (ROOT / name).read_bytes()))
for label, (test, worker) in variants.items():
    for name in SOURCES:
        raw = test if name == TEST else worker if name == WORKER else (ROOT / name).read_bytes()
        private.append(copy(PACKET / 'cohorts' / label / name, raw))
bound = {'schema': 1, 'originals': originals, 'private': private,
         'original_assertions_exact': True, 'historical_full_source_pin_unchanged': manifest['historical_source_sha256_unchanged'],
         'native_compile_or_certificate_cause_credit': False,
         'variants': list(variants), 'selected_original_cases': 9}
(PACKET / 'RECEIVING-SOURCE-BINDINGS.json').write_text(json.dumps(bound, indent=2) + '\n')
os.chmod(PACKET / 'RECEIVING-SOURCE-BINDINGS.json', 0o600)
print(json.dumps({'private_files': len(private), 'bytes': sum(x['bytes'] for x in private), 'source_bindings_sha256': hashlib.sha256((PACKET / 'RECEIVING-SOURCE-BINDINGS.json').read_bytes()).hexdigest()}))
