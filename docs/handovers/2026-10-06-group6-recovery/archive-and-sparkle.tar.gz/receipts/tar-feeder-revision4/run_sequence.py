from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

q = Path(__file__).resolve().parent
lua = Path(shutil.which('luajit')).resolve()
python = Path(sys.executable).resolve()
commands = [
    ('bridge6', 6, [str(lua), str(q/'controls/test_stdin_owner_bridge.lua'), str(q/'linux'), str(q/'candidate')]),
    ('io17', 17, [str(lua), str(q/'controls/test_retained_tar_io.lua'), str(q/'candidate/native_tar_feeder.part.lua')]),
    ('diagnostic7', 7, [str(lua), str(q/'controls/test_private_tar_diagnostics.lua'), str(q/'candidate/private_tar_diagnostics.lua')]),
    ('native8', 8, [str(python), str(q/'controls/run_retained_tar_native.py'), str(q/'controls/run_native_subreaper.py'),
                   str(lua), str(q/'linux'), str(q/'candidate'), str(q/'libergopti_archive_publication.so'), str(q/'native-session')]),
]
results = []
for name, expected, command in commands:
    start = time.monotonic()
    with (q/'logs'/f'{name}.stdout').open('wb') as out, (q/'logs'/f'{name}.stderr').open('wb') as err:
        child = subprocess.Popen(command, cwd=q, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
        raw = Path(f'/proc/{child.pid}/stat').read_bytes().rsplit(b')', 1)[1].split()
        facts = {'name':name, 'expected_scopes':expected, 'command':command, 'child_pid':child.pid,
                 'child_birth_ticks':int(raw[19]), 'child_group_id':int(raw[2]), 'uid':os.geteuid(), 'status':'RUNNING'}
        (q/'logs'/f'{name}.json').write_text(json.dumps(facts,indent=2)+'\n')
        # Never kill the native guardian or create a competing native-child reaper.
        status = child.wait()
    facts.update({'status':'TERMINAL','exit_code':status,'elapsed_seconds':time.monotonic()-start})
    (q/'logs'/f'{name}.json').write_text(json.dumps(facts,indent=2)+'\n')
    results.append(facts)
    print(json.dumps({'name':name,'exit_code':status,'elapsed_seconds':facts['elapsed_seconds']}), flush=True)
    print((q/'logs'/f'{name}.stdout').read_text(), end='', flush=True)
    print((q/'logs'/f'{name}.stderr').read_text(), end='', flush=True)
    if status != 0:
        break
cohort = json.loads((q/'COHORT.json').read_text())
unchanged = all(hashlib.sha256((q/rel).read_bytes()).hexdigest()==digest for rel,digest in cohort['files'].items())
result = {'status':'PASS' if len(results)==4 and all(x['exit_code']==0 for x in results) else 'FAIL',
          'commands':results,'cohort_before_after_identical':unchanged,'not_executed':[x[0] for x in commands[len(results):]],
          'native_retirement':'qualify only from exact existing guardian terminal closure; rescue or missing closure remains FAIL'}
(q/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'result':result['status'],'cohort_identical':unchanged,'not_executed':result['not_executed']}),flush=True)
sys.exit(0 if result['status']=='PASS' and unchanged else 1)
