﻿; adapters/ollama_platform.ahk

; ==============================================================================
; MODULE: Native Windows Ollama Release Selection
; DESCRIPTION:
; Selects the canonical archive using the host machine returned by the actual
; native query. An emulated process architecture cannot select the host asset.
; This stateless boundary acquires no runtime, file, network or process owner.
; ==============================================================================

#Requires AutoHotkey v2.0
#Include ../_generated/ollama_release.ahk

_OllamaWindowsMachineReceipt() {
	ProcessMachine := 0
	NativeMachine := 0
	Succeeded := DllCall("Kernel32\IsWow64Process2", "Ptr", -1,
		"UShort*", &ProcessMachine, "UShort*", &NativeMachine, "Int")
	NativeError := A_LastError
	return Map("ok", Succeeded != 0, "process_machine", ProcessMachine,
		"native_machine", NativeMachine, "error", NativeError)
}

/** Returns the exact official archive record for the observed native host. */
OllamaWindowsRelease(Probe := 0) {
	if Probe is Integer && Probe == 0
		Probe := _OllamaWindowsMachineReceipt
	if !HasMethod(Probe, "Call")
		throw TypeError("The native Ollama architecture probe must be callable.")
	Receipt := Probe.Call()
	if !(Receipt is Map) || Receipt.Count != 4
		throw TypeError("The native Ollama architecture receipt is unavailable.")
	for Key in ["ok", "process_machine", "native_machine", "error"] {
		if !Receipt.Has(Key) || !(Receipt[Key] is Integer)
			throw TypeError("The native Ollama architecture receipt is unavailable.")
	}
	if Receipt["process_machine"] < 0 || Receipt["process_machine"] > 0xFFFF
			|| Receipt["native_machine"] < 0 || Receipt["native_machine"] > 0xFFFF
			|| Receipt["error"] < 0 || Receipt["error"] > 0xFFFFFFFF
		throw ValueError("The native Ollama architecture receipt has invalid field widths.")
	if Receipt["ok"] != true
		throw Error("The native Ollama architecture query failed (Win32 " . Receipt["error"] . ").")
	NativeMachine := Receipt["native_machine"]
	if NativeMachine == 0x8664
		AssetId := "windows-amd64"
	else if NativeMachine == 0xAA64
		AssetId := "windows-arm64"
	else
		throw ValueError("The native host has no supported pinned Windows Ollama archive.")
	return OllamaReleaseWindowsAsset(AssetId)
}
