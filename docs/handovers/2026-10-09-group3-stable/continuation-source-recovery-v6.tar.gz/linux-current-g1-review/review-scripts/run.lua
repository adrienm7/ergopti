local root=assert(arg[1])
package.path=root..'/static/ergopti_plus/linux/?.lua;'..root..'/static/ergopti_plus/linux/?/init.lua;'..root..'/static/ergopti_plus/_shared/lua/?.lua;'..root..'/static/ergopti_plus/_shared/lua/?/init.lua;'..package.path
if arg[3] then
 local names={['ui.menu.menu_builder']=true}
 local searchers=package.searchers or package.loaders;local original=searchers[2]
 searchers[2]=function(name)
  if names[name] then
   local rel=name:gsub('%.','/')..'.lua';local stream=io.open(arg[3]..'/'..rel,'rb')
   if stream then local bytes=assert(stream:read('*a'));stream:close();local label='@'..root..'/static/ergopti_plus/linux/'..rel;return assert((loadstring or load)(bytes,label)),label:sub(2) end
  end
  return original(name)
 end
end
require('compat.utf8').install()
local native_loop=require('luv')
if arg[2]:match('%.lua$') then assert(loadfile(arg[2]))() else require(arg[2]) end
local results=require('tests.helpers').get_results();assert(require('luv')==native_loop)
print('INDEPENDENT_CONTROLLED '..results.passed..'/'..results.failed)
os.exit(results.failed>0 and 1 or 0)
