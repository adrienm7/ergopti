from pathlib import Path
import subprocess,os,json,time,hashlib,datetime
from zoneinfo import ZoneInfo
R=Path('/workspace/ergopti-macos-field-admission');O=Path('/workspace/scratch/oct28-field-admission');F=json.loads((O/'source-freeze.json').read_text());initial=json.loads((O/'physical-initial.json').read_text());rows=[]
env=dict(os.environ);env['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH'];env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';env['USER']=env['LOGNAME']='agent'
for key,leaf in [('TMPDIR','tmpdir'),('XDG_RUNTIME_DIR','xdg_runtime_dir'),('XDG_CACHE_HOME','xdg_cache_home'),('XDG_CONFIG_HOME','xdg_config_home'),('XDG_DATA_HOME','xdg_data_home'),('XDG_STATE_HOME','xdg_state_home')]:
 p=O/'quick-followup'/leaf;p.mkdir(parents=True,exist_ok=True,mode=0o700);env[key]=str(p)
def stable():
 raw=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R);assert hashlib.sha256(raw).hexdigest()==initial['digest']
 for path,sha in F['paths'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==sha
commands=[('field-contract',['node','tools/test/test-macos-field-run-contract.cjs']),('strict',['npm','run','-s','lint:conventions:strict']),('format',['npm','run','-s','format:check']),('gen-check',['npm','run','-s','gen:check']),('ahk-locals',['npm','run','-s','test:ahk-local-same-as-global']),('windows-source',['node','tools/test/test-windows-updater-original-source.cjs']),('source-encoding',['node','tools/test/test-source-encoding.cjs']),('ahk-encoding',['npm','run','-s','test:ahk-encoding']),('undefined-lua',['node','tools/test/test-lua-undefined-globals.cjs']),('false-green',['node','tools/test/find-false-greens.cjs']),('pinned-source',['node','tools/test/test-no-pinned-source-reads-lua.cjs']),('verify-plan',['node','tools/test/verify-change.cjs','--plan'])]
assert json.loads((O/'tool-exit.json').read_text())['actual_child_wait_exit']==1
assert not (O/'field-contract.log').exists(), 'original quick gate must never have started'
for name,cmd in commands:
 stable();start=time.monotonic();log=O/('quick-'+name+'.log')
 with log.open('wb')as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 stable();row={'name':name,'command':cmd,'actual_exit':p.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};rows.append(row);(O/'quick-gates.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
raise SystemExit(0 if all(x['actual_exit']==0 for x in rows)else 1)
