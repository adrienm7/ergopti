// Private copies; unchanged ownPhase is the sole command-phase physical owner.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const packet = __dirname;
const bindingsPath = path.join(packet, 'RECEIVING-SOURCE-BINDINGS.json');
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const bindings = JSON.parse(fs.readFileSync(bindingsPath));
const identity = filename => {
 const s=fs.lstatSync(filename,{bigint:true});
 if(!s.isFile()||s.isSymbolicLink()) throw Error('Regular source identity refused');
 return {path:filename,dev:String(s.dev),ino:String(BigInt.asUintN(64,s.ino)),uid:String(s.uid),mode:String(s.mode),bytes:Number(s.size),sha256:sha(filename)};
};
const fences=[...bindings.originals,...bindings.private,
 ...['run-receiving.cjs','receiving_launcher.py','RECEIVING-SOURCE-BINDINGS.json'].map(name=>identity(path.join(packet,name)))];
function refence() {
 for(const item of fences) if(JSON.stringify(identity(item.path))!==JSON.stringify(item)) throw Error('Source identity changed');
}
refence();
const owner=require(path.join(packet,'owner/tools/test/run-linux-managed-http-native.cjs'));
refence();
const work=fs.mkdtempSync('/tmp/group6-http-debug-owned-receiving-');
fs.chmodSync(work,0o700);
const test='tools/test/macos_native_http_receiving_facts_test.py';
const refusalNames=[
 'NativeHTTPStageReceiptTests.test10FixtureFlagCannotChangeReleaseOperationsOrMoveCausalBoundaries',
 'HistoricalPACOwnershipProjectionTests.test41CompleteApprovedRepairAndExactLegacyKeepOriginalWholePin',
 'HistoricalPACOwnershipProjectionTests.test44UnrelatedCallbackRoutingDeadlineAndLegacyDriftRemainWholeHashProtected',
 'PACSourceAcquisitionProjectionTests.test45CompleteSourceOwnerKeepsImmutableHistoricalPin'
].sort();
const deadline=process.hrtime.bigint()+120000000000n;
let cancelled=false;
const cancel=()=>{cancelled=true;owner.requestActiveCancellation();};
process.on('SIGTERM',cancel);process.on('SIGINT',cancel);
(async()=>{
 const results=[];
 for(const label of bindings.variants) {
  refence();
  if(cancelled||process.hrtime.bigint()>=deadline)throw Error('Original private deadline refused');
  const cohort=path.join(packet,'cohorts',label);
  const refused=!['before','admitted','inverse'].includes(label);
  const expectedStatus=refused?1:0;
  const result=await owner.ownPhase({command:'python3',args:['-B',path.join(packet,'receiving_launcher.py'),path.join(cohort,test),path.join(work,label+'.json')],
   env:{...process.env,TMPDIR:'/tmp',PYTHONDONTWRITEBYTECODE:'1'},cwd:cohort,work,label,
   worker:path.join(packet,'owner/tools/test/run-linux-managed-http-phase.py'),owner:path.join(packet,'owner/tools/build/stage-linux-network-runtime.py'),
   ownerSha:'ac48a4e9755fb2b9e9cbe35c81b097942bf7be76d14466e03b891b4c78f302f5',kind:'command',budgetMs:30000,gateDeadline:deadline});
  refence();
  const closed=JSON.parse(fs.readFileSync(path.join(work,label+'.owner/closed.json')));
  const summary=JSON.parse(fs.readFileSync(path.join(work,label+'.json')));
  const statusOK=result.status===expectedStatus&&result.signal===null&&result.error===null&&!cancelled&&!owner.hasRetainedPhases()&&!closed.cancelled&&owner.phaseReceipt(closed,closed.pid,'command',expectedStatus);
  const casesOK=summary.total===9&&summary.skip===0&&summary.fail===0&&summary.pass===(refused?5:9)&&summary.errors===(refused?4:0)
   &&(!refused||JSON.stringify(summary.error_names.sort())===JSON.stringify(refusalNames));
  const ok=statusOK&&casesOK;
  results.push({label,ok,status:result.status,signal:result.signal,error:result.error,retained:owner.hasRetainedPhases(),closed,summary,
   stdout_sha256:sha(path.join(work,label+'.stdout')),stderr_sha256:sha(path.join(work,label+'.stderr'))});
  fs.writeFileSync(path.join(work,'RESULTS.json'),JSON.stringify({schema:1,results,all_source_identity_refences_exact:true,
   source_bindings_sha256:sha(bindingsPath),original_clock_seconds:120,phase_budget_seconds:30,
   owner_and_cancellation_unchanged:true,original_cases_and_historical_pin_unchanged:true,
   native_compile_or_certificate_cause_credit:false,main_index_refs_mutated:false},null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({label,ok,pass:summary.pass,fail:summary.fail,errors:summary.errors,status:result.status,retained:owner.hasRetainedPhases()}));
  if(!ok)throw Error('Private original-control receiving refused');
 }
 refence();
 if(cancelled||process.hrtime.bigint()>=deadline||owner.hasRetainedPhases())throw Error('Final source/clock/debt refused');
 fs.writeFileSync(path.join(packet,'RECEIVING-RESULT-LOCATOR.json'),JSON.stringify({work,results_sha256:sha(path.join(work,'RESULTS.json'))},null,2)+'\n',{flag:'wx',mode:0o600});
 console.log('RESULT_DIRECTORY='+work);
})().catch(error=>{console.error('PRIVATE_RECEIVING_REFUSED work='+work+' reason='+error.message);process.exitCode=1;}).finally(()=>{
 if(!owner.hasRetainedPhases()){process.removeListener('SIGTERM',cancel);process.removeListener('SIGINT',cancel);}
});
