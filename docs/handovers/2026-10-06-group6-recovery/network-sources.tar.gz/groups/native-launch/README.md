<!-- README.md -->

# Native25/14 launch proposal

SOURCE ONLY. No import, native launch or compile has executed. Root has released
the previous feeder slot; this proposal still needs bounded peer source review.
No main/index/ref changes. Complete309b qualification after source sets remain
unchanged after the34+528/525 model receipts.

Launch-only run.py owns one direct existing guardian Popen and its pidfd. It
never becomes a subreaper, reaps a Lua/Curl child, scans proc, signals a group
or guesses a resource. The immutable hardware/run_native_subreaper.py remains
the sole Lua/adopted-descendant cleanup owner. Its existing implementation is
unchanged; it performs its original own-child observation/teardown. Rescue,
nonzero/debt/cancellation never earns a positive closure receipt.

The wrapper captures actual guardian PID/parent/group/session/birth from its
known unreaped child, requires a real pidfd, then observes WNOWAIT exit while
the original child identity is still reserved. One final Popen.wait consumes
that direct-child kernel receipt. Exact capture descriptors/pidfd are closed
once; refused metadata/close receipts retain a failed outcome, never guessed
absence. No outer hard kill or new execution budget replaces the guardian's
original40-second deadline. Parent cancellation intent is retained while the
existing guardian finishes its own child cleanup.

The tiny Lua entry reads its own real bounded /proc/self/stat before dofile of
the untouched fixture. It prints only typed PID/parent/group/session/birth into
the complete PRIVATE capture, never a URL/body/configuration. Birth/group/session
are exact decimal strings. The wrapper requires exactly one receipt whose
parent and session/group match the guardian. No marker becomes kill authority.

Both native phases use the SAME exact after309b runtime producer, with original
fixtures24/14 versus reviewed corrected fixtures25/14. This isolates observation/
contract migration from implementation changes. Original180's late-allocation
get_owned port is explicitly native-only in the corrected fixture;168/196 and
all other native case assertions remain public. The additive25th case is the
stronger public no-allocation counterpart. No broad raw-engine retarget exists.

Candidate25 runs first, candidate14 second, stop on first failed candidate. Only
if both pass, replay original24/14 against that same candidate producer and keep
their true statuses distinct. The six after-real-close Body14 cases may reveal a
real old/plain-vs-managed-strong-owner timing gap. Do not weaken them or treat
an unreported case as executed. The receipt binds exact fixture/guardian/entry
hashes, full stdout/stderr hashes, summary/pass/fail observations and physical
Popen reap, plus actual guardian/Lua births. Assertion logs stay private.

Every invocation uses real ordinary-UID LuaJIT/luv, isolated driver cwd and
actual module paths. Existing curl/anonymous pipe/FD/stat/group controls remain
real; only their documented refusal ports are injected. Source hashes are
admitted before launch and rechecked after. Native33584/55/50 and body-pipe20
are not included and remain separate future cohorts.
