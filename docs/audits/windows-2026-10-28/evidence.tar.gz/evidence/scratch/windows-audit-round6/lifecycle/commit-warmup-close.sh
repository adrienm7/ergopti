#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
npx husky install
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd(); proof=Path('/workspace/scratch/windows-audit-round6/lifecycle/warmup-close-qualified-hashes.json')
for p,h in json.loads(proof.read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
CHECK
git add -- static/ergopti_plus/windows/infra/webview_browser_warmup.ahk static/ergopti_plus/windows/tests/meta/ui/webview/test_webview_shared_env_reentrancy_guard.ahk
git commit -F /workspace/scratch/windows-audit-round6/lifecycle/warmup-close-commit-message.txt
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd(); proof=Path('/workspace/scratch/windows-audit-round6/lifecycle/warmup-close-qualified-hashes.json')
for p,h in json.loads(proof.read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
print(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
CHECK
