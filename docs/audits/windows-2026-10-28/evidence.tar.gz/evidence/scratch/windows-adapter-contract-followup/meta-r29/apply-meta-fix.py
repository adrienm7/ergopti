from pathlib import Path
root=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests')
for relative,names in [
 ('meta/modules/llm/prediction/test_llm_callbacks_never_swallowed.ahk',['_LCS_ThrowingCallbackIsLoggedNotSwallowed','_LCS_MissingCallbackIsANoOp']),
 ('meta/adapters/shell_runner/test_shell_runner_isolated_logger.ahk',['_SRIL_HelperReachesTheLogger'])]:
    p=root/relative;s=p.read_text(encoding='utf-8-sig')
    for name in names:
        start=s.index(name+'() {');end=s.index('\n}\n',start)+2;body=s[start:end]
        assert body.count('Threw := ""')==1
        body=body.replace('Threw := ""','Threw := "", ContractThrew := false')
        if 'catch as Err {' in body:
            old='catch as Err {\n\t\tThrew := Err.Message'
            assert body.count(old)==1
            body=body.replace(old,'catch as Err {\n\t\tContractThrew := true\n\t\tThrew := Err.Message')
        else:
            old='catch as Err\n\t\tThrew := Err.Message'
            assert body.count(old)==1
            body=body.replace(old,'catch as Err {\n\t\tContractThrew := true\n\t\tThrew := Err.Message\n\t}')
        assert body.count('Assert(Threw == "",')==1
        body=body.replace('Assert(Threw == "",','Assert(!ContractThrew,')
        s=s[:start]+body+s[end:]
    p.write_text(s,encoding='utf-8-sig',newline='\n')
