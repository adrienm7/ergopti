from pathlib import Path
import hashlib
import importlib.util
import sys
import unittest

P = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')
TEST = ROOT / 'tools/test/macos_native_http_receiving_facts_test.py'
assert hashlib.sha256(TEST.read_bytes()).hexdigest() == '6a6f93dbd7ce8a2aea3d2a9d5632e17668f98ecb30f34647780e026a7832203b'
namespace = {'__name__': 'isolated_guard_original72', '__file__': str(TEST)}
exec(compile(TEST.read_bytes(), str(TEST), 'exec'), namespace)
source = P / 'candidate/static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
spec = importlib.util.spec_from_file_location('isolated_guard_wire', source)
wire = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wire)
namespace['WIRE'] = wire
suite = unittest.TestSuite()
for value in namespace.values():
    if isinstance(value, type) and issubclass(value, unittest.TestCase):
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(value))
result = unittest.TextTestRunner(verbosity=2).run(suite)
print(f'unchanged72 total={result.testsRun} failures={len(result.failures)} errors={len(result.errors)} skips={len(result.skipped)}')
assert result.testsRun == 72
sys.exit(0 if result.wasSuccessful() else 1)
