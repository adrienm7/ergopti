<!-- group6-linux-native-updater-application-proposal3/HANDOVER.md -->

# Retained native updater composition

The actual production branch is connected in the source candidates: Linux
manager download methods reserve the native artifact factory and immutable
archive transfer; the shared Versions caller and update window opt into the
manager's asynchronous native installer. Sibling default synchronous interfaces
remain unchanged. This is a source proposal, not an integrated feature or a
validated end-to-end transaction.

`APPLICATION-SOURCE-ONLY.json` binds all15 proposed production/native/build
paths, their observed root preimages, and nine additive normal-framework test
modules totaling96 independently authored cases. `QUALIFICATION-PLAN.md` lists
the sequential model, causal, legacy, native composition and packaging gates.
The root owns canonical generation, the normal discovery manifest, build/package
activation, source formatting and all final selected gates.

The production revision3 and installer revision5 source review is recorded in
`/workspace/scratch/group6-owned-install-source-review-revision5/REVIEW.json`
(SHA25af8d2e). It closes publication reentry, post-physical source withdrawal,
initial predecessor disposal, channel persistence before disposal and the known
pre-reader refusal join. Every original manager8 body and all37 predecessor
install controls are retained. New22 production controls and8 refusal controls
are unparsed and unrun.

Registry revision6 uses the exact root491 FD preimage, which differs from the
previous qualified686 body solely in its path header. It preserves the reviewed
private adoption/install registry and replaces only the old embeddedade35 feeder
with exact08f69. That private feeder has independent30 modeled+8 native PASS,
with genuine guardian adopted5/pending0/rescue0; its previous failed fixture is
preserved without assigning a cause from the later pass. The C7064/headerdc98
backend has independent26 native and256 clock-bracket PASS. Those results do not
qualify the new registry29 cases or the complete updater/installer chain.

The unresolved producer prerequisite is the final reviewed prepared-header
queue plus streaming output-hop composition. Preserve latest native ownership,
authorization, descendant-group absence and close receipts; historical qualified
GET or sink sources must not overwrite that composition. Its public surface
must expose `get_owned` and `download_output_owned`, resolving each archive
redirect under the same original archive deadline and retaining exact target
ticket/physical-writer authority. Plain pathname reopening, native curl follow,
zero-argument retry proof and differential updates are excluded.

The native C/header sources belong under
`static/ergopti_plus/linux/native/archive_output/`; their canonical helper is
`tools/build/build-linux-native-output.sh`. Root must generate and package
`linux/bin/libergopti_archive_publication.so`, verify the installed ABI and clock
domain, and retain the optional private stdin-owner supervisor bridge413. The
Lua loader refuses a missing component without a pathname fallback. Fixture
binaries are not source artifacts. C policy errno remains canonical Unknown.

No root files, index, Git refs, CI, generators or TODO blocks were changed by
this preparation. Windows runtime remains deferred to its existing PC handover.
Original local filesystem shell commands retain synchronous checkpoint-bound
deadline limitations. Physical native composition, rollback, packaged install,
kernel5.15/6.8 and device validation are outstanding; no item completion is
claimed.
