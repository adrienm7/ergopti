﻿; tests/unit/test_onboarding_finish_payload.ahk

; ==============================================================================
; MODULE: Onboarding WebView Finish Payload Tests
; DESCRIPTION:
; The WebView bridge must reject a malformed ``answers`` value before it can
; enter the onboarding persistence/reload transaction. A scalar used to throw
; from ``answers.Has(...)``; an Array could instead reach the transaction with
; every choice silently defaulted.
; ==============================================================================

_TOFP_FinishRejectsNonMapAnswers() {
	for _, Answers in ["malformed", []] {
		Thrown := false
		Result := true
		try Result := _OnbWeb_Finish(Answers)
		catch
			Thrown := true
		AssertFalse(Thrown,
			"a non-Map finish payload must not throw from the deferred WebView callback")
		AssertFalse(Result,
			"a non-Map finish payload must be rejected before persistence")
	}
}
Test("onboarding WebView: finish rejects non-Map answers (AHK-147)",
	_TOFP_FinishRejectsNonMapAnswers)


; Observes the real producer through its existing deferred-page queue. No native
; WebView is created and no personal configuration source is read or written.
_TOFP_InitDataStringField(Script, Field) {
	Pattern := "(?:^|,)" . Field . ':("(?:\\.|[^"\\])*")'
	Assert(RegExMatch(Script, Pattern, &Captured) > 0,
		"the genuine initData producer must publish " . Field)
	return JsonParse(Captured[1])
}

_TOFP_EmptyFolderInitDestination(Custom) {
	global _ob_locale, _DefaultConfigDir, _ConfigDir, ConfigurationFile
	global _OnbWeb_Ready, _OnbWeb_Queue, _OnboardingCatalogue
	SavedLocale := { present: IsSet(_ob_locale), value: IsSet(_ob_locale) ? _ob_locale : 0 }
	SavedDefault := { present: IsSet(_DefaultConfigDir), value: IsSet(_DefaultConfigDir) ? _DefaultConfigDir : 0 }
	SavedCurrent := { present: IsSet(_ConfigDir), value: IsSet(_ConfigDir) ? _ConfigDir : 0 }
	SavedConfig := { present: IsSet(ConfigurationFile), value: IsSet(ConfigurationFile) ? ConfigurationFile : 0 }
	SavedReady := _OnbWeb_Ready, SavedQueue := _OnbWeb_Queue, SavedCatalogue := _OnboardingCatalogue
	Directory := A_Temp . "\ergopti_onboarding_empty_target_" . DllCall("GetCurrentProcessId", "UInt")
		. "_" . A_TickCount . "_" . Random(100000, 999999)
	DirCreate(Directory)
	try {
		_ob_locale := "en"
		_DefaultConfigDir := "C:\Users\fixture\.config\ergopti_plus\"
		_ConfigDir := Custom ? "E:\Custom-B\" : "C:\Users\fixture\.config\ergopti_plus\"
		ConfigurationFile := Directory . "\config.toml"
		_OnbWeb_Ready := false, _OnbWeb_Queue := [], _OnboardingCatalogue := ""
		_OnbWeb_InjectInitData()
		AssertEqual(_OnbWeb_Queue.Length, 1,
			"the real ready producer queues exactly one initialization without creating a WebView")
		Script := _OnbWeb_Queue[1]
		Assert(InStr(Script, "window.initData({") == 1, "the observed publication must initialize the wizard")
		AssertEqual(_TOFP_InitDataStringField(Script, "empty_config_dir"),
			"C:\Users\fixture\.config\ergopti_plus\",
			"clearing the Windows field selects the OS default even from a custom boot folder")
		AssertEqual(_TOFP_InitDataStringField(Script, "default_config_dir"),
			"C:\Users\fixture\.config\ergopti_plus\")
		AssertEqual(_TOFP_InitDataStringField(Script, "config_dir"), Custom ? "E:\Custom-B\" : "",
			"the original custom-choice payload is preserved")
		AssertFalse(FileExist(ConfigurationFile), "initial presentation cannot create configuration")
	} finally {
		_ob_locale := SavedLocale.present ? SavedLocale.value : unset
		_DefaultConfigDir := SavedDefault.present ? SavedDefault.value : unset
		_ConfigDir := SavedCurrent.present ? SavedCurrent.value : unset
		ConfigurationFile := SavedConfig.present ? SavedConfig.value : unset
		_OnbWeb_Ready := SavedReady, _OnbWeb_Queue := SavedQueue, _OnboardingCatalogue := SavedCatalogue
		DirDelete(Directory)
	}
}

Test("onboarding WebView: empty-folder initData names the default destination from a custom folder",
	_TOFP_EmptyFolderInitDestination.Bind(true))
Test("onboarding WebView: empty-folder initData preserves the default-folder display contract",
	_TOFP_EmptyFolderInitDestination.Bind(false))


; The real modal boundary returns an owned PIDL; only Browse is replaced. This
; observes the genuine picker continuation and deferred page queue without a GUI.
_TOFP_PickerModalBoundary(State, NativeOwner, _Info) {
	global _OnbWeb_SessionEpoch, _OnbWeb_Queue
	State.entered := true
	if State.retire {
		; Reset and a newly constructed singleton each advance this epoch. Their
		; existing queue must survive a result from the older unowned modal.
		_OnbWeb_SessionEpoch += 2
		_OnbWeb_Queue := [State.successor]
	}
	if State.cancel {
		State.returned := true
		return 0
	}
	SelectedPidl := 0
	try {
		Status := NativeOwner.ParseRoot(State.directory, &SelectedPidl)
		if Status != 0 || !SelectedPidl
			throw Error("The isolated picker fixture could not acquire its native PIDL")
		State.returned := true
		return SelectedPidl
	} catch as AcquisitionError {
		if SelectedPidl {
			try NativeOwner.FreePidl(SelectedPidl)
			catch as PidlReleaseError {
				AcquisitionError.Message .= " | fixture PIDL cleanup also failed: " . PidlReleaseError.Message
			}
		}
		throw AcquisitionError
	}
}

_TOFP_PickerContinuation(Retire, Cancel) {
	global _OnbWeb_SessionEpoch, _OnbWeb_Ready, _OnbWeb_Queue
	SavedEpoch := _OnbWeb_SessionEpoch
	SavedReady := _OnbWeb_Ready
	SavedQueue := _OnbWeb_Queue
	SavedBrowse := _Ui_FolderNative.GetOwnPropDesc("Browse")
	Directory := A_Temp . "\ergopti_onboarding_picker_" . DllCall("GetCurrentProcessId", "UInt")
		. "_" . A_TickCount . "_" . Random(100000, 999999)
	DirCreate(Directory)
	State := { entered: false, returned: false, retire: Retire, cancel: Cancel,
		directory: Directory, successor: "successor queue must remain intact" }
	PrimaryFailure := 0
	CleanupFailures := []
	try {
		_OnbWeb_SessionEpoch := SavedEpoch + 10
		_OnbWeb_Ready := false
		_OnbWeb_Queue := [State.successor]
		_Ui_FolderNative.DefineProp("Browse", { Call: _TOFP_PickerModalBoundary.Bind(State) })
		_OnbWeb_PickConfigDir(Directory)
		AssertTrue(State.entered, "the genuine picker must reach its actual native modal boundary")
		AssertTrue(State.returned, "the modal port must return its owned PIDL or explicit cancellation")
		AssertEqual(State.successor, _OnbWeb_Queue[1], "the successor's existing deferred work is preserved")
		AssertEqual(Retire || Cancel ? 1 : 2, _OnbWeb_Queue.Length,
			"only a selected folder whose original wizard remains current may append a page effect")
		if !Retire && !Cancel {
			AssertEqual("window.setConfigDir(" . JsonStringLiteral(Directory) . ")", _OnbWeb_Queue[2],
				"same-session selection retains the exact native filesystem path")
		}
	} catch as OriginalFailure {
		PrimaryFailure := OriginalFailure
	} finally {
		; Each independent owner gets its retirement attempt even if another
		; cleanup refuses. Never replace the original assertion or native error.
		try _Ui_FolderNative.DefineProp("Browse", SavedBrowse)
		catch as BrowseRestoreError {
			CleanupFailures.Push("Browse descriptor: " . BrowseRestoreError.Message)
		}
		try _OnbWeb_SessionEpoch := SavedEpoch
		catch as EpochRestoreError {
			CleanupFailures.Push("session epoch: " . EpochRestoreError.Message)
		}
		try _OnbWeb_Ready := SavedReady
		catch as ReadyRestoreError {
			CleanupFailures.Push("page readiness: " . ReadyRestoreError.Message)
		}
		try _OnbWeb_Queue := SavedQueue
		catch as QueueRestoreError {
			CleanupFailures.Push("page queue: " . QueueRestoreError.Message)
		}
		try DirDelete(Directory)
		catch as DirectoryRetireError {
			CleanupFailures.Push("private directory: " . DirectoryRetireError.Message)
		}
	}
	if PrimaryFailure {
		for Detail in CleanupFailures
			PrimaryFailure.Message .= " | fixture cleanup also failed: " . Detail
		throw PrimaryFailure
	}
	if CleanupFailures.Length {
		Detail := "Native picker fixture cleanup failed"
		for FailureDetail in CleanupFailures
			Detail .= " | " . FailureDetail
		throw Error(Detail)
	}
}

Test("onboarding WebView: current native picker selection preserves its exact path",
	_TOFP_PickerContinuation.Bind(false, false))
Test("onboarding WebView: retired native picker cannot append into a successor queue",
	_TOFP_PickerContinuation.Bind(true, false))
Test("onboarding WebView: current native picker cancellation publishes nothing",
	_TOFP_PickerContinuation.Bind(false, true))
Test("onboarding WebView: retired native picker cancellation preserves the successor queue",
	_TOFP_PickerContinuation.Bind(true, true))
