﻿; modules/llm/ollama_managed_http.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Managed Ollama Selected-Origin HTTP Owner
; DESCRIPTION:
; Uses the actual curl adapter for bounded version/tags receipts. Native response
; completion, private-file cleanup and current selection are separate fences.
; ==============================================================================

class OllamaManagedHttp extends _LocalServerModelsTimerNativeAdapter {
	__New(Options) {
		if !(Options is Map) || !(Options.Get("poll_ms", 0) is Integer) || Options["poll_ms"] <= 0
			throw TypeError("Managed HTTP requires an explicit polling policy.")
		for name in ["request", "timer", "clock"]
			if Options.Has(name) && !HasMethod(Options[name], "Call")
				throw TypeError("Managed HTTP ports must be callable.")
		this.Options := Options.Clone()
		this.Record := 0
		this.Generation := 0
		this.LastError := ""
	}

	Query(Origin, Kind, Deadline, Current, Done, BindLoopback := false) {
		local origin_match := 0
		if !(Origin is String) || !RegExMatch(Origin, "\Ahttp://(?:localhost|127\.0\.0\.1):([0-9]+)\z", &origin_match)
				|| StrLen(origin_match[1]) > 5 || Integer(origin_match[1]) < 1 || Integer(origin_match[1]) > 65535
				|| !(Kind == "version" || Kind == "tags") || !(Deadline is Integer)
				|| !HasMethod(Current, "Call") || !HasMethod(Done, "Call")
				|| !(BindLoopback is Integer) || !(BindLoopback == true || BindLoopback == false)
			throw TypeError("Managed HTTP requires one exact local origin, endpoint and ticket.")
		local previous := Critical("On")
		try {
			if this.Record is Map || this.Generation == 0x7fffffffffffffff
				return false
			local record := Map("generation", ++this.Generation, "origin", Origin, "kind", Kind,
				"deadline", Deadline, "current", Current, "done", Done, "request", 0,
				"building", true, "busy", false, "releasing", false, "cancelled", false, "first_error", "")
			record["timer"] := ObjBindMethod(this, "_PollRecord", record)
			this.Record := record
		} finally Critical(previous)
		local accepted := false
		try {
			if !this._Current(record)
				return false
			local factory := this.Options.Get("request", () => CurlAsyncRequest())
			local request := factory.Call()
			if !(request is CurlAsyncRequest)
				throw TypeError("Managed HTTP requires the genuine owned curl adapter.")
			record["request"] := request
			local boundary := request._DispatchPortFn("before_launch")
			request.DispatchPort := request.DispatchPort is Map ? request.DispatchPort.Clone() : Map()
			request.DispatchPort["before_launch"] := ObjBindMethod(this, "_BeforeLaunch", record, boundary)
			request.Open("GET", Origin . (Kind == "version" ? LLM_EnableVersionPath() : "/api/tags"), true)
			if BindLoopback
				request.SetLoopbackOrigin(Origin)
			local remaining := Deadline - this._Clock()
			if remaining <= 0 || remaining > 0x7fffffff || !this._Current(record)
				return false
			request.SetTimeouts(0, remaining, 0, 0)
			request.SetProxy("")
			accepted := request.Send() == true && this._Current(record)
			return accepted
		} catch Any as Err {
			this._Failure(record, "http_dispatch_refused")
			return false
		} finally {
			record["building"] := false
			if !accepted
				this._CancelRecord(record)
			else
				this._PollRecord(record)
		}
	}

	_Owns(Record) {
		return this.Record is Map && this.Record == Record && this.Generation == Record["generation"]
	}

	_Current(Record) {
		if !this._Owns(Record) || Record["cancelled"] || A_IsSuspended || this._Clock() >= Record["deadline"]
			return false
		local observed_tick := this._Clock()
		local current := Record["current"].Call()
		return current is Integer && current == true && this._Owns(Record) && !Record["cancelled"]
			&& !A_IsSuspended && observed_tick < Record["deadline"]
	}

	_BeforeLaunch(Record, Boundary, Request) {
		if HasMethod(Boundary, "Call")
			Boundary.Call(Request)
		if !this._Current(Record)
			Request.Abort()
	}

	_Failure(Record, Reason) {
		if Record["first_error"] == ""
			Record["first_error"] := Reason
	}

	Cancel() {
		this._CancelRecord(this.Record)
		return !this.HasOwner()
	}

	_CancelRecord(Record) {
		if !(Record is Map) || !this._Owns(Record)
			return true
		Record["cancelled"] := true
		Record["done"] := 0
		local request := Record["request"]
		if request is CurlAsyncRequest {
			try request.Abort()
			catch Any as Err
				this._Failure(Record, "http_retirement_refused")
		}
		if this._Release(Record)
			return true
		this._Schedule(Record)
		return false
	}

	Poll() {
		return this._PollRecord(this.Record)
	}

	_PollRecord(Record) {
		local previous := Critical("On")
		try {
			if !(record is Map) || !this._Owns(record) || record["building"] || record["busy"]
				return
			record["busy"] := true
		} finally Critical(previous)
		local caller := Critical("Off")
		try {
			if !this._Current(record) {
				this._Failure(record, "http_ticket_or_deadline_refused")
				this._CancelRecord(record)
				return
			}
			local request := record["request"]
			if !request.WaitForResponse(0)
				return
			; No delivery while this exact request still owes native/private cleanup.
			if request.CleanupPending
				request._Cleanup()
			if request.CleanupPending || IsObject(request.Handle) || !this._Current(record)
				return
			local receipt := Map("ok", request.Status == 200 && !request.Aborted,
				"status", request.Status, "body", request.ResponseText, "origin", record["origin"],
				"kind", record["kind"], "generation", record["generation"])
			local done := record["done"], current := record["current"]
			if !this._Release(record)
				return
			local observed_tick := this._Clock(), admitted := current.Call()
			if admitted is Integer && admitted == true && !record["cancelled"] && !A_IsSuspended
					&& this.Generation == record["generation"] && observed_tick < record["deadline"]
				done.Call(receipt)
		} catch Any as Err {
			this._Failure(record, "http_observation_refused")
			this._CancelRecord(record)
		} finally {
			record["busy"] := false
			try {
				if this._Owns(record)
					this._Schedule(record)
			} finally Critical(caller)
		}
	}

	_Release(Record) {
		if !this._Owns(Record) || Record["building"] || Record["releasing"]
			return false
		Record["releasing"] := true
		try return this._ReleaseNonReentrant(Record)
		finally Record["releasing"] := false
	}

	_ReleaseNonReentrant(Record) {
		local request := Record["request"]
		if request is CurlAsyncRequest {
			if !request.WaitForResponse(0) || IsObject(request.Handle)
				return false
			if request.CleanupPending
				request._Cleanup()
			if request.CleanupPending
				return false
		}
		if !this._Timer(Record, 0)
			return false
		local previous := Critical("On")
		try {
			if !this._Owns(Record) || Record["building"]
				return false
			this.Record := 0
			this.LastError := Record["first_error"]
			Record["request"] := 0
			return true
		} finally Critical(previous)
	}

	HasOwner() {
		return this.Record is Map
	}

	_Schedule(Record) {
		if this._Owns(Record)
			return this._Timer(Record, -this.Options["poll_ms"])
		return true
	}

	_Timer(Record, Period) {
		local timer := this.Options.Get("timer", ObjBindMethod(this, "_NativeTimer"))
		try {
			local accepted := timer.Call(Record["timer"], Period)
			if accepted is Integer && accepted == true
				return true
		} catch Any as Err {
		}
		this._Failure(Record, "http_timer_refused")
		Record["cancelled"] := true
		Record["done"] := 0
		return false
	}

	_Clock() {
		local clock := this.Options.Get("clock", () => A_TickCount), now := clock.Call()
		if !(now is Integer) || now < 0
			throw TypeError("Managed HTTP requires native-domain nonnegative ticks.")
		return now
	}
}
