--- tests/unit/meta/test_public_preflight.lua

--- ==============================================================================
--- MODULE: Actual Public HTTP Preflight Comparison Controls
--- DESCRIPTION:
--- Exercises the actual public wrapper and isolated native curl engine
--- with independent native admission/closure acknowledgements. Expectations
--- require serializer-only NUL refusal without owner replacement. Original
--- historical and failed public-comparison assertions remain untouched.
--- ==============================================================================

local helpers = require("tests.helpers")
local stage = assert(os.getenv("ERGOPTI_HTTP_STAGE"), "complete staged driver required")

--- Loads an actual public adapter against independent native port receipts.
--- @param kind string Managed public adapter or native production engine.
--- @return table client, table state
local function fresh(kind)
	local state = { handles = {}, closes = {}, kills = {}, spawns = 0 }
	local uv = {}
	local function handle(role)
		local value = { role = role, closing = false, closed = false }
		state.handles[#state.handles + 1] = value
		return value
	end
	function uv.hrtime() return 0 end
	function uv.new_pipe() return handle("pipe") end
	function uv.new_timer() state.timer = handle("timer"); return state.timer end
	function uv.timer_start(timer, timeout, _, callback)
		if timeout < 0 then return nil, "EINVAL" end
		timer.timeout, timer.callback = timeout, callback
		return 0
	end
	function uv.timer_stop() return 0 end
	function uv.read_start(pipe, callback) pipe.callback = callback; return 0 end
	function uv.read_stop() return 0 end
	function uv.is_closing(value) return value.closing or value.closed end
	function uv.close(value, callback)
		value.closing = true
		state.closes[#state.closes + 1] = { handle = value, callback = callback }
		return 0
	end
	function uv.kill(pid, signal) state.kills[#state.kills + 1] = { pid, signal }; return 0 end
	function uv.write(_, config, callback) state.config = config; callback(nil); return 0 end
	function uv.spawn(command, options, callback)
		state.spawns = state.spawns + 1
		state.command, state.options, state.exit = command, options, callback
		return handle("process"), 9173
	end
	function state.ack_closes()
		while #state.closes > 0 do
			local receipt = table.remove(state.closes, 1)
			receipt.handle.closing, receipt.handle.closed = false, true
			if receipt.callback then receipt.callback() end
		end
	end
	function state.complete()
		state.options.stdio[2].callback(nil, "\nERGOPTI_HTTP_STATUS:200\n")
		state.options.stdio[2].callback(nil, nil)
		if kind == "managed" then state.options.stdio[3].callback(nil, "\nERGOPTI_PROXY_RECEIPT:000:?\n") end
		state.options.stdio[3].callback(nil, nil)
		state.exit(0, 0)
		state.ack_closes()
	end
	local names = { "luv", "adapters.curl_http_client", "adapters.system_proxy", "infra.monotonic", "infra.proxy_policy" }
	local saved = {}
	for _, name in ipairs(names) do saved[name] = package.loaded[name]; package.loaded[name] = nil end
	package.loaded.luv = uv
	local client = dofile(stage .. "/adapters/" .. (kind == "native" and "curl_http_client.lua" or "http_client.lua"))
	for _, name in ipairs(names) do package.loaded[name] = saved[name] end
	return client, state
end

--- Calls the actual boolean or owned production surface.
--- @param client table
--- @param method string
--- @param body string
--- @param callback function
--- @return boolean|table
local function call(client, method, body, callback)
	local url, options = "http://127.0.0.1:9173/control", { owner = "nul-owner", timeout_ms = 1000 }
	if method == "post" then return client.post(url, {}, body, callback, options) end
	if method == "stream" then return client.postStream(url, {}, body, options, function() end, callback) end
	options.buffered, options.method = true, "POST"
	return client.dispatch_owned(url, {}, body, options, nil, callback)
end

helpers.describe("curl config: literal-NUL admission", function()
	for _, kind in ipairs({ "managed", "native" }) do
		local methods = kind == "native" and { "post", "stream", "owned" } or { "post", "stream" }
		for _, method in ipairs(methods) do
			for position, body in ipairs({ "\0private", "private\0metadata", "private\0" }) do
				local current_kind, current_method, current_body = kind, method, body
				helpers.it(kind .. " " .. method .. " refuses body NUL position " .. position .. " before acquisition", function()
					local client, state = fresh(current_kind)
					local results = {}
					local operation = call(client, current_method, current_body, function(result) results[#results + 1] = result end)
					local admitted = operation
					if current_method == "owned" then admitted = operation.started end
					-- Retire old implementation's independent fake debt before failing.
					-- Snapshot acquisition first; cleanup cannot hide its side effects.
					local handles, spawns, kills = #state.handles, state.spawns, #state.kills
					if state.spawns > 0 then state.complete() else state.ack_closes() end
					helpers.assert_eq(admitted, false)
					helpers.assert_eq(handles, 0)
					helpers.assert_eq(spawns, 0)
					helpers.assert_eq(kills, 0)
					helpers.assert_eq(#results, 1)
					helpers.assert_eq(results[1].error, "curl config body cannot contain NUL")
					helpers.assert_true(not results[1].ok and results[1].status == 0)
					helpers.assert_true(not client.isActive("nul-owner"))
					if current_method == "owned" then helpers.assert_true(operation:is_settled()) end
				end)
			end
		end
		local current_kind = kind
		helpers.it(kind .. " invalid body cannot cancel or replace a valid boolean owner", function()
			local client, state = fresh(current_kind)
			local valid, invalid = {}, {}
			helpers.assert_true(call(client, "post", '{"ordinary":true}', function(result) valid[#valid + 1] = result end))
			local handles, spawns, kills = #state.handles, state.spawns, #state.kills
			local admitted = call(client, "stream", "private\0metadata", function(result) invalid[#invalid + 1] = result end)
			local added_handles, added_spawns, added_kills = #state.handles - handles, state.spawns - spawns, #state.kills - kills
			local invalid_count, valid_count, active = #invalid, #valid, client.isActive("nul-owner")
			state.complete()
			helpers.assert_eq(admitted, false)
			helpers.assert_eq(added_handles, 0)
			helpers.assert_eq(added_spawns, 0)
			helpers.assert_eq(added_kills, 0)
			helpers.assert_eq(invalid_count, 1)
			helpers.assert_eq(valid_count, 0)
			helpers.assert_true(active)
			helpers.assert_eq(#valid, 1)
			helpers.assert_true(valid[1].ok)
			helpers.assert_eq(invalid[1].error, "curl config body cannot contain NUL")
		end)
	end
end)

return helpers
