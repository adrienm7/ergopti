local root = "/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path = root .. "lua/?.lua;" .. package.path
local Json=require("json");local Policy=require("control.driver_control")
local f=assert(io.open(root.."modules/control/driver_control.json","rb"));local raw=assert(f:read("*a"));assert(f:close());local spec=Policy.validate(Json.decode(raw))
local cases={
 {"canonical null", [[,"successor_pid":null]], true},
 {"escaped null", [[,"successor_\u0070id":null]], true},
 {"last escaped null", [[,"successor_pid":200,"successor_\u0070id":null]], true},
 {"missing successor", "", false},
}
local passed,failed=0,0
for _,row in ipairs(cases) do
 local text='{"schema":1,"request_id":"pending-key","state":"requested","driver_pid":100'..row[2]..',"deadline":1700000120}'
 local decoded=Json.decode(text);assert(decoded.request_id=="pending-key" and decoded.state=="requested")
 local kind,result=Policy.resolve(spec,text,200,1700000000,Json.decode)
 local expected='{"schema":1,"request_id":"pending-key","state":"claimed","driver_pid":200,"successor_pid":200,"deadline":1700000120}\n'
 local ok=(row[3] and kind=="claimed" and result==expected) or (not row[3] and kind==nil and result==nil)
 print((ok and "PASS " or "FAIL ")..row[1].." kind="..tostring(kind))
 if ok then passed=passed+1 else failed=failed+1 end
end
print(passed.." passed, "..failed.." failed");os.exit(failed==0 and 0 or 1)
