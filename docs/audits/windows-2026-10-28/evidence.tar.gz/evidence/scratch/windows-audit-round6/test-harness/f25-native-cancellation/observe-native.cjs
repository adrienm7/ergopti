const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const root = '/workspace/ergopti-windows-r6-tests';
const packet = __dirname;
const mode = process.argv[2];
assert(['old-mutant', 'candidate-mutant', 'candidate-original'].includes(mode));
const runner = path.join(root, 'static/ergopti_plus/windows/tests/run_all.ahk');
let source = fs.readFileSync(runner, 'utf8');
const fixture = mode.startsWith('old') ? 'original-fixtures.ahk' : 'candidate-fixtures.ahk';
const adapter = mode.endsWith('mutant') ? 'mutant-adapter.ahk' : 'original-adapter.ahk';
const windows = name => 'Z:' + path.join(packet, name).replaceAll('/', '\\');
for (const [original, replacement] of [
 ['#Include ../adapters/timer_scheduler.ahk', '#Include ' + windows(adapter)],
 ['#Include unit/infra/dispatch/test_timer_scheduler_suspend.ahk', '#Include ' + windows(fixture)],
 ['#SingleInstance Force', '#SingleInstance Off']
]) {
 assert.equal(source.split(original).length, 2, 'exact private runner enrollment: ' + original);
 source = source.replace(original, replacement);
}
const owned = path.join(path.dirname(runner), '.r6-native-f25-' + crypto.randomBytes(6).toString('hex') + '.ahk');
const fd = fs.openSync(owned, 'wx'); fs.writeFileSync(fd, source); fs.closeSync(fd);
const tap = path.join(packet, mode + '.tap');
let settled = false;
try {
 const argv = ['--kill-after=5s', '300s', 'xvfb-run', '-a', 'wine', '/workspace/toolchain/ahk/AutoHotkey64.exe', '/ErrorStdOut', 'Z:' + owned.replaceAll('/', '\\'), '--only', 'TimerScheduler/suspend F25'];
 const result = cp.spawnSync('timeout', argv, {encoding:'utf8', maxBuffer:4*1024*1024, env:{...process.env, WINEPREFIX:'/workspace/toolchain/wine-r3-metrics-owned', LC_ALL:'C.UTF-8', ERGOPTI_AHK_RESULTS_FILE: 'Z:' + tap.replaceAll('/', '\\')}});
 settled = result.status !== null && result.status !== 124 && result.signal === null && !result.error;
 fs.writeFileSync(path.join(packet, mode + '.stdout'), result.stdout || '');
 fs.writeFileSync(path.join(packet, mode + '.stderr'), result.stderr || '');
 const digest = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
 fs.writeFileSync(path.join(packet, mode + '-receipt.json'), JSON.stringify({mode, argv, status:result.status, signal:result.signal, error:result.error?.message, fixture_sha256:digest(path.join(packet,fixture)), adapter_sha256:digest(path.join(packet,adapter)), tracked_fixture_sha256:digest(path.join(root,'static/ergopti_plus/windows/tests/unit/infra/dispatch/test_timer_scheduler_suspend.ahk')), private_runner_sha256:digest(owned)}, null, 2) + '\n');
 console.log(result.stdout, result.stderr);
 assert(settled, 'the exact private native runner must settle before cleanup');
 const raw = fs.readFileSync(tap, 'utf8');
 assert(raw.includes('1..6'), 'all six pre-existing F25 cases must actually register');
 if (mode === 'candidate-mutant') {
  assert.equal(result.status, 1, 'actual omitted native cancellation must be rejected');
  assert(raw.includes('# 3 passed, 3 failed.'), 'all three armed cancellation variants must reject the mutant');
  assert.equal((raw.match(/# native_requeue mode=/g) || []).length, 4, 'single, duplicate and both cancelAll native owners are observed');
  assert.equal((raw.match(/positive=1 late=1 heartbeat=[1-9]/g) || []).length, 4, 'each genuine native armed callback actually dispatched after the false cancellation');
 } else {
  assert.equal(result.status, 0, 'the actual F25 run must complete successfully');
  assert(raw.includes('# 6 passed, 0 failed.'), 'all existing registered F25 cases pass');
  if (mode === 'candidate-original') {
   assert.equal((raw.match(/positive=1 late=0 heartbeat=[1-9]/g) || []).length, 4, 'every genuine armed callback is cancelled while the independent native heartbeat runs');
  }
 }
} finally {
 if (settled) fs.unlinkSync(owned);
}
