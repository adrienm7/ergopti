<!-- DIAGNOSIS.md -->

# Historical native body-pipe20 source diagnosis

The retained complete hosted log for run37430974838 contains20 actual cases:
16PASS/4FAIL. No new bodypipe execution occurred for this source investigation.
The original fixture is preserved byte-for-byte beside this note. Only the four
bounded failure facts are copied here; the complete private log stays outside
the recovery archive.

| Original case | Native failure | Exact embedded public assertion |
| --- | --- | --- |
| post cancel normal | exit1, stdin53 | `assert(operation.started)` after successful public cancel |
| postStream cancel normal | exit1, stdin53 | Same public owned successor after boolean cancel |
| post timeout normal | exit1, stdin38 | `assert(dispatched)` with1ms configured timeout |
| postStream timeout normal | exit1, stdin38 | Same1ms public dispatch assertion |

The cancel path first proves an actual backpressured native body writer, obtains
`Http.cancel(owner)==true`, then asks the same public owner for an owned GET.
The qualified coordinator deliberately admits replacements only behind a live
BOOLEAN predecessor. Cancellation sets `_cancelled` and clears visible activity;
its stronger physical debt can remain present. The queued replacement admission
therefore refuses this specific cancelled predecessor. This is a genuine public
compatibility gap, not proof of an unsafe descriptor close or an external-device
limitation. A possible next coherent fix is a narrowly recorded positive native
cancellation receipt for a previously started/admitted boolean child, allowing
an accepted owned successor reservation while retaining that exact predecessor
and every child/group/timer ACK. It must not admit owned predecessors, pre-start
body descriptor debt, failed or uncertain cancellation, terminal/expired debt,
or source-withdrawn authority. Its tests must preserve original live-only and
owned-to-owned assertions and distinguish queue acceptance from native start.
No such exception has been added to this qualified application proposal.

The timeout failure occurs before the backpressure assertion. The configured
1ms is the managed whole-operation budget. Native body acquisition/preparation
can consume the remaining budget and cause a synchronous typed timeout refusal
before curl acquisition, unlike the older raw-engine timer that began later.
However, the boolean wrapper's initial preflight and the fixture's construction
of its32MiB body happen before coordinator start; their cost must not be falsely
charged to that budget in the diagnosis. The actual failed capture lacks a typed
failure/phase receipt establishing which later admission boundary expired. A
future bounded diagnostic must retain the original1ms assertion and observe
actual monotonic start/deadline, typed public result and true body-write ownership
without printing payloads. It must not change1ms, invent backpressure, retarget
the entire fixture to raw curl, or report green on an unexecuted case.

The fixture currently uses a direct subprocess timeout15s and a daemon server
thread. Before a future normal gate grants physical cleanup credit, root should
reuse the maintained sole subreaper/capture ownership and prove accepted server
socket/thread retirement. No competing cleanup census, numeric reused-PID kill,
new outer hard-kill path or elapsed-time absence oracle should be introduced.
Existing byte/hash/HTTP-path, callback, FD-count and native-handle assertions
remain independent and must all execute. The future current-producer20 replay is
UNEXECUTED; the final actual25/14 results are distinct.
