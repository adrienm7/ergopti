# Group 3 essential continuation — private draft, 2026-10-13

This draft and staged capsule are private review material. Parent owns the later public save at a stable checkpoint. All thirteen items remain partial: **63, 71, 73, 91, 93, 96, 97, 98, 106, 107, 108, 109, 111**. Items **16 and 38 remain required**. Source, component runtime and real native/device qualification are separate.

## Current checkpoint

Parent reports MacV3 atom `583121a8` in actual Dev `ba83cf377a0767fc0d39a2ce22165eb95d2ef45c`. Its already integrated software is not copied into this capsule. Linux V3 bridge/full eight-case fixture/shared helper and the positive native-Window fixture correction remain dirty pending Parent's atomic delivery. Genuine fourteen Lua54/LuaJIT comparisons retain old3/5, V1 4/4, V2 5/3, V3 8/0 and three ACK omissions7/1 on each ABI. The old whole-Linux **13652 pass/3 fail** run stays retained FAIL. Its two positive retirement doubles are corrected only to return literal true, whole postimage `43ba5b8b...`, independently Source reviewed at `38402226...`. The original final Linux gate **73374 naturally completed exit0**, 497.929 seconds, **521 modules / 13655 pass / 0 fail**. Parent receives the exact 10013-file source, index, HEAD and diff frame unchanged; raw log SHA `a950507bbb0cb255832c2775bfee1d64bc9ac2ee5009f67393d323e3e37f4994`. The exact terminal receipt is retained as a status reference. There is now no active local gate at this checkpoint. Final format/Common and atomic Linux delivery remain Parent-owned and pending; this unit result is not a native GUI/input or release qualification.

Mac optional-consumer receiving is actual standard Lua54 **old31/9 → consumer40/0**, using the entire original thirty-case prefix and ten independent optional-observer cases. Actual stock LuaJIT capability receiving exits **2**, with table.pack absent and **zero helper/subject execution**. The exact parent receipt is `fc631d81724df91b865113f0650a7c22bdb7db400db0a6dea23520405ecdfc79`. Raw child outputs, statuses and matching source/packet frames are saved byte-exact. This validates a controlled consumer over genuine shared components and controlled native/observer ports. The real G5 publisher was **not loaded or enrolled**; published producer source `56dd0f0...` is **not in Dev**. Consumer adoption, real producer composition and native GUI/capture/input/output qualification remain pending; no availability or adoption grant follows.

AHK physical-slot metadata and the proportional V3 Lua→AHK policy drift guard are Source proposals. The model's original standalone include graph/corpus and literal controls are retained; its 83-case native prediction and guard's 34 controls remain **UNRUN**. Native Integer0/1 versus JSON Boolean ambiguity and incomplete Lua parity remain explicit. Root owns coherent model/include/normal-graph controls and existing registry enrollment. Neither metadata Maps nor a copied corpus supplies capture, matcher, session, Writer, native catalogue or input authority.

## Finite saved material and external references

The companion plan/manifest selects only Mac40 consumer deltas and required preimages, independently frozen names, exact source/runtime receipts and raw receiving; AHK metadata/include graph, independent data and V3 policy guard/control proposals; and exact new connected107 V4/108-union reconstruction slices. Archive members are inert regular relative `.raw` files. The manifest binds original paths, byte counts and SHA-256. Restore names only into a separately owned temporary directory for review; do not unpack over the checkout or execute retained commands automatically.

The existing public129 capsule `docs/handovers/2026-10-12-group3-current-preparations/group3-current-preparations-capsule-v1.tar.gz`, SHA `ea210202bb84c888b9fc09ca64b6843316d0e5a5fc9fbd494da5eaf29b792c1d`, remains unchanged and is referenced for its existing continuations. Its older shipped-identity Linux V4 is not the new four-adapter number-row V4/108 union. Therefore only the latter's four frozen V3 baseline sources, exact V4/108 deltas, inverse/composition pins/receipts and original opaque-Reader control protocol are newly retained. Never apply standalone older Capture over the committed item108 `aa810e45...` image; reconcile current preimages and retain current producer/queue owners. Runtime.xi declaration, actual Xorg/libinput/uinput receiving and native40/dead0xfe52 corpus remain separate; no forced-row availability is enabled.

Root/G1's bounded thirty-two registration-span warning proposal remains separately owned. This capsule includes only the current source-only warning review and a reference to the existing public warning archive; it copies no adoption patch or fixture set. The review is not an exhaustive warning census or proof that renaming makes native Snapshot/full suites pass. The original sixteen and ordinary full-suite receiving, strict warning/stdout equality, scopes and budgets remain required.

Already integrated MacV3/Linux software packets, full checkouts, caches, binaries/SDKs, generated-postimage adoption copies and the old public129 archive are excluded. Historical raw receipts are unchanged; their older ACTIVE/UNRUN labels describe their original epochs and do not override the current facts above. Creating/hashing/packing evidence establishes no Source, native, adoption or feature grant.

## Remaining software and native receiving

| Item | Remaining continuation |
| --- | --- |
| 63 | Receive existing brightness/provider behavior and honest no-provider refusal; real device luminance remains separate. |
| 71 | Genuine installed full-save/warm restart must retain unknown/retired values/comments. Mac ordinary admission still needs actual Accessibility trust; hosted wizard receiving is a separate scope. |
| 73 | Receive existing locale/ordered-pair menus and hidden management exclusions; preserve owners/defaults. |
| 91 | Windows first-edge/source arbitration, simultaneous delivery and fake-LCtrl/AltGr provenance remain software/native work. |
| 93 | Coordinate Xi declaration/generator/stager/provider/guard/workflow ownership and genuine source/server/input/output joins; Source metadata is not installed or input qualification. |
| 96 | Receive the existing Ergopti+ picker, AltGr precedence, wrapping/spacing/percent/ligatures and dead-state behavior without replacing defaults. |
| 97/98 | Compose genuine capture/host, effective source and all-owner collision admission, acknowledged publication/output, arbitrary Unicode/dead-key composition, safe migration and installed receiving. Controlled consumer success does not enable public delivery. |
| 106 | Native discovery/invocation and original deadline/termination receiving remain Root/cloud247-owned. Preserve the prior failure; no redesign or menu availability follows. |
| 107 | Preserve connected V4 Reader/Shift leases and native corpus, then receive real Xorg/libinput Writer-device association and remaining Windows/Mac native providers. |
| 108 | Preserve committed effective-group renewal/consumer and inverse ownership when composing new source work; real installed/physical layout/output receiving remains required. |
| 109 | A supported fresh invisible Variables/KeyHistory acquisition API is still missing; a second branded GUI or show-then-hide workaround is not that API. |
| 111 | Genuine packaged signed-helper/input/timer/modifier/Dock receiving remains required, including exact original retirement terminals. |

Items63/71/73/96 require final receiving and demonstrated remaining regressions, not wholesale reimplementation. Shared/generated work goes through its actual owner; no root registration, runner, workflow, Snapshot fixture or G5 producer ownership is transferred by saving evidence.

## Device scopes after native/install admission

**Windows:** ordinary Metrics actions and full save/warm restart; locale and ordered-pair menus; real backlight brightness/no-provider refusal; existing picker/AltGr/wrapping/ligature/dead states. After corresponding providers qualify, receive held-alone then joined/AltGr timing, chosen physical positions/None/repeats/layout changes/dead-key output, and debug-panel duplicate start/Reload/focus. Keep currently unavailable paths unavailable and preserve item16/38 receiving.

**macOS:** use a genuinely trusted installed session for ordinary save/warm restart; receive labels/brightness/notification/panel delivery. Exercise two real displays with cursor/focused window on different displays, moved cursor, spanning/negative/minimized/closed windows and refused focus; global Dock switching needs actual modifier release. After corresponding native providers qualify, receive real Shortcuts invocation/cancellation and position/source/output changes. Controlled Mac Lua54 under Linux is not AppKit, TCC, signed-helper, physical keyboard or installed acceptance.

Parent reviews this finite selection/current preimages and saves the owned public handover at the stable checkpoint, then owns final format/Common and atomic Linux delivery. The final Linux terminal and earlier failure remain distinct. No TODO is removed by this draft.
