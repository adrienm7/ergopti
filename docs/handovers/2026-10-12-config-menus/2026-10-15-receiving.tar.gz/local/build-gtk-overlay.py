import pathlib,os,json
base=pathlib.Path('/workspace/.ergopti-cloud');out=base/'gtk-overlay';out.mkdir(exist_ok=True)
rows=[]
def merge(host,prefix,dest,mapped):
 dest.mkdir(exist_ok=True)
 for name in sorted(set(os.listdir(host) if host.is_dir() else [])|set(os.listdir(prefix) if prefix.is_dir() else [])):
  h,p=host/name,prefix/name;d=dest/name
  if h.is_dir() and not h.is_symlink() and p.is_dir() and not p.is_symlink():
   merge(h,p,d,mapped/name);continue
  target=p if p.exists() or p.is_symlink() else mapped/name
  if d.is_symlink(): assert os.readlink(d)==str(target)
  else: d.symlink_to(target)
  rows.append({'view':str(d),'target':str(target)})
merge(pathlib.Path('/usr/lib/x86_64-linux-gnu'),base/'gtk-root/usr/lib/x86_64-linux-gnu',out/'libs',pathlib.Path('/run/gtk-system-libs'))
merge(pathlib.Path('/usr/bin'),base/'gtk-root/usr/bin',out/'bin',pathlib.Path('/run/gtk-system-bin'))
(out/'manifest.json').write_text(json.dumps({'entries':rows,'count':len(rows),'system_files_modified':False},indent=2)+'\n')
print(len(rows))
