
const page=loadMetricsTypingPage('windows');freezePageClock(page,'2026-05-31T12:00:00Z');
publishTypingPage(page,'windows',{'2020-01-01':{Editor:{chars:20,time:10000}}});
page.elements.get('quick_range').value='3m';page.context.apply_quick_date_range();
console.log(JSON.stringify({start:page.elements.get('date_start').value,end:page.elements.get('date_end').value,errors:page.diagnostics.filter(x=>x.level==='error')}));
assert.equal(page.elements.get('date_start').value,'2026-02-28','three months before May31 must remain in February');
