"""LOCAL native component observation through unchanged owners; no official/GHA admission.

Does not call either GHA-only main or relax system_file. Non-Root file ownership
is recorded separately. Sources are authentic private Git images; all original
native oracle/assertion code and original family/display retirement are retained.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import stat
import subprocess
import sys
import uuid


BASE = Path(__file__).parent
SOURCE = BASE / 'source'
HARDWARE = SOURCE / 'static/ergopti_plus/linux/tests/hardware'
RUNTIME = Path('/workspace/.ergopti-cloud/runtime/usr')
OUT = BASE / 'actual'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not OUT.exists(), 'fresh owned observation directory required'
    OUT.mkdir(mode=0o700)
    source_commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
    tracked = subprocess.check_output(['git','ls-files'],cwd=SOURCE,text=True).splitlines()
    pins = {}
    for name in tracked:
        path = SOURCE / name
        image = subprocess.check_output(['git','show',source_commit+':'+name],cwd=SOURCE)
        assert image == path.read_bytes(), name
        pins[name] = digest(path)
    original = load('local_original_C3_owner', HARDWARE/'run_xi2_property_cookies.py')
    diagnostic = load('local_original_declared_owner', HARDWARE/'run_xi2_luajit_diagnostic.py')
    assert digest(original.FAMILY) == original.FAMILY_SHA == diagnostic.FAMILY_SHA
    posture = diagnostic.runtime_projection(json.loads((SOURCE/'static/ergopti_plus/_shared/data/linux_native_runtime.json').read_text()))
    assert posture == 'DECLARED_SONAME'
    candidate = SOURCE/'static/ergopti_plus/linux/adapters/xkb_source_probe.lua'
    assert digest(candidate) == diagnostic.CANDIDATE_SHA
    paths = {
        'compiler':Path('/usr/bin/gcc').resolve(strict=True),
        'luajit':(RUNTIME/'bin/luajit').resolve(strict=True),
        'xvfb':(RUNTIME/'bin/Xvfb').resolve(strict=True),
        'xi':Path('/usr/lib/x86_64-linux-gnu/libXi.so.6').resolve(strict=True),
        'x11':Path('/usr/lib/x86_64-linux-gnu/libX11.so.6').resolve(strict=True),
        'bridge':Path('/usr/lib/x86_64-linux-gnu/libX11-xcb.so.1').resolve(strict=True),
        'xkb':Path('/usr/lib/x86_64-linux-gnu/libxkbcommon.so.0').resolve(strict=True),
        'xkb11':Path('/usr/lib/x86_64-linux-gnu/libxkbcommon-x11.so.0').resolve(strict=True),
    }
    paths.update({name:(RUNTIME/'include'/name).resolve(strict=True) for name in ['X11/Xlib.h','X11/extensions/XInput2.h','X11/extensions/XI2.h']})
    system = []
    for name,path in paths.items():
        observed = path.stat()
        assert stat.S_ISREG(observed.st_mode)
        try:
            original.system_file(str(path))
        except AssertionError:
            official = 'REFUSED_ORIGINAL_ROOT_POLICY'
        else:
            official = 'ACCEPTED_ORIGINAL_ROOT_POLICY'
        system.append({'role':name,'path':str(path),'sha256':digest(path),'uid':observed.st_uid,
                       'gid':observed.st_gid,'mode':stat.S_IMODE(observed.st_mode),'official_system_file':official})
    assert any(row['official_system_file']=='REFUSED_ORIGINAL_ROOT_POLICY' for row in system)
    environment = dict(os.environ)
    for name in ['LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','LD_DEBUG','LD_DEBUG_OUTPUT','LIBRARY_PATH','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LUA_INIT','LUA_INIT_5_1','GITHUB_SHA','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT']:
        environment.pop(name,None)
    (OUT/'before.json').write_text(json.dumps({'scope':'LOCAL_COMPONENT_ONLY','source_commit':source_commit,'source_pins':pins,'system_inputs':system,'posture':posture,'GHA':'NONE','official_wrappers':'UNRUN'},indent=2)+'\n')
    include = '-I'+str(RUNTIME/'include')
    c3 = OUT/'original-c3';c3.mkdir(mode=0o700)
    executable = c3/'cookie_experiment'
    c3_compile = [str(paths['compiler']),'-std=c11','-Wall','-Wextra','-Werror',include,str(HARDWARE/'xi2_property_cookie.c'),str(paths['xi']),str(paths['x11']),'-o',str(executable)]
    c3_compile_receipt = original.family_run(c3,'compile',c3_compile,60,environment)
    c3_native_command = [sys.executable,str(HARDWARE/'xi2_property_display.py'),str(c3),str(executable),str(paths['xvfb'])]
    c3_native_receipt = original.family_run(c3,'native',c3_native_command,25,environment)
    display = json.loads((c3/'display-receipt.json').read_text())
    assert display['controlled_exit']==0 and display['controlled']=={'controlled_passed':16,'native_fetch':0,'native_free':0}
    assert display['native_exit']==0 and display['rescue']==0 and display['owned_display']=='REAPED'
    assert display['termination_requested'] is True and display['server_pidfd_closed'] is True
    assert display['xvfb_exit'] in (0,-15) and 'failure_type' not in display and 'premature_xvfb_exit' not in display
    facts = display['native']
    assert facts['stage']==7 and facts['opened']==facts['closed_calls']==1 and facts['close_status']==0
    assert facts['xi_major']>=2 and facts['fetched']==facts['freed']==facts['published']==len(original.CASES)==3
    assert facts['xerrors']==facts['input_injections']==0 and facts['native_epoch_claim'] is False
    assert facts['server_peer_pid']>0 and facts['server_peer_uid']==os.getuid()
    assert json.loads((c3/'native.stdout').read_bytes())==facts
    assert not (c3/'native.stderr').read_bytes() and not (c3/'controlled.stderr').read_bytes()
    witness = OUT/'abi.so'
    abi_compile = [str(paths['compiler']),'-std=c11','-Wall','-Wextra','-Werror','-shared','-fPIC',include,str(HARDWARE/'xi2_luajit_abi.c'),str(paths['x11']),'-ldl','-o',str(witness)]
    abi_receipt = original.family_run(OUT,'abi-compile',abi_compile,60,environment)
    config = {'candidate':str(candidate),'lua':str(HARDWARE/'xi2_luajit_receiver.lua'),
              'logger':str(SOURCE/'static/ergopti_plus/_shared/lua/logger/shim.lua'),
              'runtime':str(SOURCE/'static/ergopti_plus/linux/_generated/native_runtime.lua'),
              'driver':str(SOURCE/'static/ergopti_plus/linux'),'nonce':uuid.uuid4().hex,
              'witness':str(witness),'runtime_projection':posture}
    config.update({name:str(paths[name]) for name in ['luajit','xvfb','xi','x11','bridge','xkb','xkb11']})
    config_path = OUT/'config.json'
    original.record(config_path,config)
    native = OUT/'lua-native';native.mkdir(mode=0o700)
    native_command = [sys.executable,str(HARDWARE/'run_xi2_luajit_diagnostic.py'),'--leader',str(native),str(config_path)]
    native_receipt = original.family_run(OUT,'lua-native',native_command,25,environment)
    received = json.loads((native/'display.json').read_text())
    assert received['qualified'] is True and received['display_retired'] is True
    assert received['display_pidfd_closed'] is True and received['rescue']==0
    diagnostic.validate_native(received['native'],posture)
    assert all(digest(SOURCE/name)==value for name,value in pins.items())
    assert all(digest(Path(row['path']))==row['sha256'] for row in system)
    result = {'scope':'LOCAL_COMPONENT_OBSERVATION_ONLY','status':'PASS','official_wrapper':'UNRUN_GHA_AND_ROOT_OWNERSHIP_BARRIERS',
              'source_commit':source_commit,'posture':posture,'C3':facts,'C3_compile_family':c3_compile_receipt,
              'C3_native_family':c3_native_receipt,'ABI_compile_family':abi_receipt,'native_family':native_receipt,
              'native_display':received,'source_after':'PASS_UNCHANGED','system_after':'PASS_UNCHANGED',
              'input_output_grant':False,'native_epoch_claim':False,'installed_receiving':'UNRUN','GHA':'NONE',
              'commands':{'C3_compile':c3_compile,'C3_native':c3_native_command,'ABI_compile':abi_compile,'Lua_native':native_command}}
    original.record(OUT/'LOCAL_RECEIVING.json',result)
    print(json.dumps(result))


if __name__=='__main__':
    main()
