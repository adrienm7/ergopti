﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
#Warn All, StdOut
EnvSet("ERGOPTI_AHK_RESULTS_FILE", A_ScriptDir . "\proof.tap")
#Include framework.ahk
MagicEditorState() {
	static State := Map("initialized", false, "layouts", Map(), "legacy", Map(),
		"ordinary_handles", Map(), "ordinary_physical", Map(), "native_handles", Map(), "ordinary_restore", Map(), "configuration_generation", 0,
		"source_generation", 0, "source_signature", "", "hkl", 0, "decision", 0, "ordinary_claim", 0)
	return State
}

MagicEditorAcquireCohort(Scans, OrdinaryHandles, Handles, Ports, RestoreDebt := unset) {
	if !IsSet(RestoreDebt)
		RestoreDebt := MagicEditorState()["ordinary_restore"]
	if !(Handles is Map) || !(RestoreDebt is Map)
		throw TypeError("The physical broker requires explicit native and personal custody maps.")
	if Handles.Count || RestoreDebt.Count
		throw Error("The physical broker cannot acquire over unsettled cohort compensation.")
	for Name in ["reserve", "activate", "retire", "set_enabled"] {
		if !Ports.Has(Name) || !HasMethod(Ports[Name], "Call")
			throw TypeError("The physical broker requires its exact registrar ports.")
	}
	try {
		for Scan in Scans {
			Handle := Ports["reserve"].Call(Scan)
			if !(Handle is String) || Handle == ""
				throw Error("The physical Win broker refused native acquisition: " . Scan)
			Handles[Scan] := Handle
		}
		for Handle in OrdinaryHandles {
			; The native call can change state before returning false or throwing.
			; Claim its exact restoration duty before crossing that effect boundary.
			RestoreDebt[Handle] := true
			Disabled := Ports["set_enabled"].Call(Handle, false)
			if !((Disabled is Integer) && Disabled == true)
				throw Error("The ordinary Win owner refused its physical broker handoff.")
		}
		for Scan, Handle in Handles {
			Activated := Ports["activate"].Call(Handle)
			if !((Activated is Integer) && Activated == true)
				throw Error("The physical Win broker refused native activation: " . Scan)
		}
	} catch as Err {
		Resolution := MagicEditorSettleCohortDebt(Handles, RestoreDebt, Ports)
		if Resolution["status"] != "settled"
			throw Error(Err.Message . " Unacknowledged compensation: " . Resolution["detail"])
		throw Err
	}
	; The acknowledged complete broker now owns the intentional personal handoff.
	RestoreDebt.Clear()
	return true
}

MagicEditorSettleCohortDebt(Handles, RestoreDebt, Ports) {
	if !(Handles is Map) || !(RestoreDebt is Map) || !(Ports is Map)
		throw TypeError("Cohort compensation requires its exact custody and native ports.")
	for Name in ["retire", "set_enabled"] {
		if !Ports.Has(Name) || !HasMethod(Ports[Name], "Call")
			throw TypeError("Cohort compensation requires its exact native owners.")
	}
	Debt := [], Retired := [], Restored := []
	for Scan, Handle in Handles {
		try {
			Accepted := Ports["retire"].Call(Handle)
			if (Accepted is Integer) && Accepted == true
				Retired.Push(Scan)
			else
				Debt.Push("retire " . Scan)
		} catch as Refusal {
			Debt.Push("retire " . Scan . ": " . Refusal.Message)
		}
	}
	for Scan in Retired
		Handles.Delete(Scan)
	for Handle in RestoreDebt {
		try {
			Accepted := Ports["set_enabled"].Call(Handle, true)
			if (Accepted is Integer) && Accepted == true
				Restored.Push(Handle)
			else
				Debt.Push("restore " . Handle)
		} catch as Refusal {
			Debt.Push("restore " . Handle . ": " . Refusal.Message)
		}
	}
	for Handle in Restored
		RestoreDebt.Delete(Handle)
	Detail := ""
	for Item in Debt
		Detail .= (Detail == "" ? "" : "; ") . Item
	return Map("status", Handles.Count || RestoreDebt.Count ? "retained" : "settled", "detail", Detail)
}

_MET_CohortRefusal(Refuse) {
	Native := Map(), Personal := Map("personal-vk", true, "personal-sc", true)
	Events := [], Handles := Map(), Debt := ""
	Reserve(Scan) {
		Events.Push("reserve " . Scan)
		if Refuse == "reserve" && Scan == "SC028"
			return ""
		Native[Scan] := false
		return Scan
	}
	SetEnabled(Handle, Enabled) {
		Events.Push((Enabled ? "restore " : "disable ") . Handle)
		if Refuse == "disable" && !Enabled && Handle == "personal-sc"
			return false
		Personal[Handle] := Enabled
		return true
	}
	Activate(Handle) {
		Events.Push("activate " . Handle)
		if (Refuse == "activate" || Refuse == "retire") && Handle == "SC028"
			return false
		Native[Handle] := true
		return true
	}
	Retire(Handle) {
		Events.Push("retire " . Handle)
		if Refuse == "retire" && Handle == "SC027"
			return false
		Native.Delete(Handle)
		return true
	}
	try MagicEditorAcquireCohort(Map("SC027", true, "SC028", true),
		["personal-vk", "personal-sc"], Handles,
		Map("reserve", Reserve, "activate", Activate, "retire", Retire, "set_enabled", SetEnabled))
	catch as Err {
		Debt := Err.Message
	}
	if Refuse == "" {
		AssertEqual("", Debt)
		AssertEqual(2, Handles.Count)
		AssertTrue(Native["SC027"] && Native["SC028"], "the complete native cohort is acknowledged")
		AssertFalse(Personal["personal-vk"] || Personal["personal-sc"], "both aliases yield to the sole broker")
		AssertEqual("disable personal-sc", Events[4], "all personal handoffs precede native activation")
	} else {
		Assert(Debt != "", "a native refusal cannot report successful boot")
		AssertTrue(Personal["personal-vk"] && Personal["personal-sc"], "exact previous personal owners recover")
		if Refuse == "retire" {
			AssertEqual(1, Handles.Count, "retirement debt remains owned and inspectable")
			AssertTrue(Handles.Has("SC027"))
			Assert(InStr(Debt, "Unacknowledged compensation"), "retirement refusal is never hidden")
		} else {
			AssertEqual(0, Handles.Count)
			AssertEqual(0, Native.Count, "all acquired native handles retire before failure returns")
		}
	}
}

_AMSG_Observe(Observation, Self, Arguments*) {
	Observation.Entries += 1
	Self.DeleteProp("Call")
	Self.Call(Arguments*)
	Observation.Completions += 1
	throw Error("")
}

_AMSG_Receive(Callback, Target, Fault) {
	if Target.HasOwnProp("Call")
		throw Error("The production function already owns a call override.")
	Observation := {Entries: 0, Completions: 0}
	Observer := _AMSG_Observe.Bind(Observation)
	try {
		if Fault
			Target.DefineProp("Call", {Call: Observer})
		Threw := false
		try Callback.Call()
		catch Any
			Threw := true
		if Fault {
			AssertEqual(1, Observation.Entries, "the exact production call must be observed once")
			AssertEqual(1, Observation.Completions, "the original producer must finish its real effects before injection")
		}
		AssertEqual(Fault, Threw, "the complete original callback must reject a thrown empty-message Error")
	} finally {
		if Fault && Target.HasOwnProp("Call") {
			if Target.GetOwnPropDesc("Call").Call != Observer
				throw Error("The test cannot retire a foreign call observer.")
			Target.DeleteProp("Call")
		}
	}
}

Test("protected cohort original healthy control", _AMSG_Receive.Bind(_MET_CohortRefusal.Bind(""), MagicEditorAcquireCohort, false))
Test("protected cohort original rejects empty error", _AMSG_Receive.Bind(_MET_CohortRefusal.Bind(""), MagicEditorAcquireCohort, true))
RunTests()
