'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const acorn = require('/workspace/ergopti/node_modules/acorn');
const root = __dirname;
const parse = source => acorn.parse(source, { ecmaVersion: 'latest' });
function nodes(ast, predicate) {
 const result = [];
 function walk(node) {
  if (!node || typeof node !== 'object') return;
  if (predicate(node)) result.push(node);
  for (const [key, value] of Object.entries(node)) {
   if (key === 'start' || key === 'end') continue;
   if (Array.isArray(value)) value.forEach(walk);
   else if (value && typeof value === 'object') walk(value);
  }
 }
 walk(ast); return result.sort((a, b) => a.start - b.start);
}
const load = (side, rel) => fs.readFileSync(path.join(root, side, rel), 'utf8');
const wrapper = 'tools/ci/native_http_clock_evidence.cjs';
const test = 'tools/test/test-native-http-clock-evidence.cjs';
const oldWrapper = load('preimages', wrapper), newWrapper = load('candidate', wrapper);
const oldTest = load('preimages', test), newTest = load('candidate', test);
const oldFunctions = nodes(parse(oldWrapper), n => n.type === 'FunctionDeclaration');
const newFunctions = nodes(parse(newWrapper), n => n.type === 'FunctionDeclaration');
assert.deepEqual(oldFunctions.map(n => n.id.name), newFunctions.map(n => n.id.name));
const unchangedFunctions = [];
for (let i = 0; i < oldFunctions.length; i++) {
 const a = oldFunctions[i], b = newFunctions[i];
 if (a.id.name !== 'officialConsistency') {
  assert.equal(oldWrapper.slice(a.start, a.end), newWrapper.slice(b.start, b.end));
  unchangedFunctions.push(a.id.name);
 }
}
const target = 'official metadata consistency never authenticates caller JSON';
const calls = source => nodes(parse(source), n => n.type === 'CallExpression' && ['control', 'mutation'].includes(n.callee.name) && n.arguments[0]?.type === 'Literal');
const oldCalls = calls(oldTest), newCalls = calls(newTest);
assert.equal(oldCalls.length, 32); assert.equal(newCalls.length, 32);
assert.deepEqual(oldCalls.map(n => n.arguments[0].value), newCalls.map(n => n.arguments[0].value));
const unchangedControls = [];
for (let i = 0; i < oldCalls.length; i++) {
 const a = oldCalls[i], b = newCalls[i];
 if (a.arguments[0].value !== target) {
  assert.equal(oldTest.slice(a.start, a.end), newTest.slice(b.start, b.end));
  unchangedControls.push(a.arguments[0].value);
 }
}
assert.equal(unchangedControls.length, 31);
const oldTarget = oldCalls.find(n => n.arguments[0].value === target);
const newTarget = newCalls.find(n => n.arguments[0].value === target);
const oldBody = oldTest.slice(oldTarget.start, oldTarget.end);
const newBody = newTest.slice(newTarget.start, newTarget.end);
const oldAssertionSources = nodes(parse(oldBody), n => n.type === 'CallExpression' && n.callee.type === 'MemberExpression' && n.callee.object.name === 'assert').map(n => oldBody.slice(n.start, n.end));
const newAssertionSources = nodes(parse(newBody), n => n.type === 'CallExpression' && n.callee.type === 'MemberExpression' && n.callee.object.name === 'assert').map(n => newBody.slice(n.start, n.end));
let previous = -1;
for (const assertion of oldAssertionSources) {
 const index = newAssertionSources.findIndex((value, at) => at > previous && value === assertion);
 assert.ok(index > previous, assertion); previous = index;
}
// Preserve the whole test prefix/suffix around the one changed control call.
assert.equal(oldTest.slice(0, oldTarget.start), newTest.slice(0, newTarget.start));
assert.equal(oldTest.slice(oldTarget.end), newTest.slice(newTarget.end));
// Preserve the whole wrapper prefix/suffix around the reviewed comparison.
const a = oldFunctions.find(n => n.id.name === 'officialConsistency');
const b = newFunctions.find(n => n.id.name === 'officialConsistency');
assert.equal(oldWrapper.slice(0, a.start), newWrapper.slice(0, b.start));
assert.equal(oldWrapper.slice(a.end), newWrapper.slice(b.end));
const proof = { source_only: true, native: false, official_authentication: false, controls: 32, unchanged_control_calls_byte_exact: unchangedControls, changed_control: target, original_assertion_expressions_preserved: oldAssertionSources.length, unchanged_wrapper_functions_byte_exact: unchangedFunctions, wrapper_prefix_suffix_byte_exact: true, test_prefix_suffix_byte_exact: true, candidate_hashes: Object.fromEntries([wrapper, test].map(rel => [rel, crypto.createHash('sha256').update(load('candidate', rel)).digest('hex')])) };
fs.writeFileSync(path.join(root, 'source-preservation.json'), JSON.stringify(proof, null, 2) + '\n');
console.log(JSON.stringify({ source_only: true, controls: 32, unchanged_calls: unchangedControls.length, unchanged_functions: unchangedFunctions.length, old_assertions: oldAssertionSources.length }));
