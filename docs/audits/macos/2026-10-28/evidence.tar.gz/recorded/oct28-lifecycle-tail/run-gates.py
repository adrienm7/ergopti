from pathlib import Path
import concurrent.futures,os,subprocess,json,time
r=Path('/workspace/ergopti-macos-lifecycle-tail');s=Path('/workspace/scratch/oct28-lifecycle-tail');env=dict(os.environ)
env['PATH']='/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH'];env['USER']='agent';env['LOGNAME']='agent';env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu'
modules=['tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_deferred_errors','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_async_actions','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_reaches_tray_install_state','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_reaches_tray_submenu','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_latency','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_list_versions','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout','tests.unit.adapters.runtime.test_timer_scheduler_one_shot','tests.unit.adapters.runtime.test_timer_scheduler_error_objects']
groups={
 'related':[('driver-'+str(i+1),['npm','run','-s','test:hs','--','--only='+m])for i,m in enumerate(modules)],
 'style':[('strict',['npm','run','-s','lint:conventions:strict']),('format',['npm','run','-s','format:check'])],
 'meta':[('verify-plan',['node','tools/test/verify-change.cjs','--plan']),('gen-check',['npm','run','-s','gen:check']),('false-green',['node','tools/test/find-false-greens.cjs']),('source-encoding',['node','tools/test/test-source-encoding.cjs']),('undefined-globals',['node','tools/test/test-lua-undefined-globals.cjs']),('source-reads',['node','tools/test/test-no-pinned-source-reads-lua.cjs'])]}
def group(items):
 rows=[]
 for name,command in items:
  start=time.monotonic();p=subprocess.run(command,cwd=r,env=env,capture_output=True,text=True,timeout=120);(s/(name+'.log')).write_text(p.stdout+p.stderr);row={'name':name,'command':command,'actual_exit':p.returncode,'seconds':round(time.monotonic()-start,3)};rows.append(row);print(name,p.returncode,flush=True)
 return rows
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 for result in pool.map(group,groups.values()):rows.extend(result)
(s/'gates.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(x['actual_exit']==0 for x in rows),rows
