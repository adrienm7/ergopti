local base = assert(arg[1])
package.preload['config_scope_participant'] = function()
 return dofile(base .. '/packet-v1/postimages/static/ergopti_plus/_shared/lua/config_scope_participant.lua')
end
arg = { 'tests.unit.infra.test_config_scope_composition' }
dofile(base .. '/focused.lua')
