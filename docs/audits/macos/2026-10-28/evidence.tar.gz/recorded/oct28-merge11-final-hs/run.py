from pathlib import Path
import os,json,subprocess,time,stat,hashlib,re,datetime
from zoneinfo import ZoneInfo
R=Path('/workspace/ergopti-macos-field-admission');O=Path('/workspace/scratch/oct28-merge11-final-hs')
GO=json.loads((O/'go.json').read_text());assert GO['authorized_launch'] and GO['source_phase']=='committed_source'
HEAD=GO['commit'];TREE=GO['tree'];assert HEAD and TREE and HEAD!='f699073f0d9fe66a23cfb2f2e45a71a28c4ec785'
for key in ['verify_plan_receipt','canonical_inventory_receipt']:
 p=Path(GO[key]);assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==GO[key+'_sha256']
def now():return datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def physical(label):
 raw=git('ls-files','--stage','-z');bad=[];n=total=0
 for entry in raw.split(b'\0'):
  if not entry:continue
  head,path=entry.split(b'\t',1);mode,oid,stage=head.split();p=R/os.fsdecode(path);st=p.lstat();data=os.fsencode(os.readlink(p))if stat.S_ISLNK(st.st_mode)else p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode();observed=b'120000'if stat.S_ISLNK(st.st_mode)else b'100755'if st.st_mode&0o111 else b'100644'
  if actual!=oid or observed!=mode:bad.append(os.fsdecode(path))
  n+=1;total+=len(data)
 d={'label':label,'tree':git('write-tree').decode().strip(),'files':n,'bytes':total,'stage_digest':hashlib.sha256(raw).hexdigest(),'mismatches':bad,'unstaged':git('diff','--name-only').decode(),'untracked':git('ls-files','--others','--exclude-standard').decode()};assert d['tree']==TREE and not bad and not d['unstaged'] and not d['untracked'];return d
assert subprocess.run(['git','merge-base','--is-ancestor',GO['dev_commit'],HEAD],cwd=R).returncode==0
assert not git('status','--porcelain')
for p in ['static/ergopti_plus/macos/infra/key_event_health.lua','static/ergopti_plus/macos/adapters/unicode_carrier.lua']:
 assert git('rev-parse',HEAD+':'+p)==git('rev-parse',GO['dev_commit']+':'+p)
assert os.getuid()!=0;assert git('rev-parse','HEAD').decode().strip()==HEAD
D={'state':'RUNNING','source_phase':'committed_source','head':HEAD,'tree':TREE,'worktree':str(R),'producer_pid':os.getpid(),'started_paris':now(),'gates':[],'physical_initial':physical('initial')}
def save():
 p=O/'receipt.pending.json';p.write_text(json.dumps(D,indent=2)+'\n');p.replace(O/'receipt.json')
save();env=dict(os.environ);env['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH'];env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';env['USER']=env['LOGNAME']='agent'
for key,leaf in [('TMPDIR','tmpdir'),('XDG_RUNTIME_DIR','xdg_runtime_dir'),('XDG_CACHE_HOME','xdg_cache_home'),('XDG_CONFIG_HOME','xdg_config_home'),('XDG_DATA_HOME','xdg_data_home'),('XDG_STATE_HOME','xdg_state_home')]:
 p=O/leaf;p.mkdir(mode=0o700,exist_ok=True);env[key]=str(p)
old=json.loads(Path('/workspace/scratch/oct28-final32-hs/receipt.json').read_text())
for g in old['gates']:
 name=g['name'];cmd=g['command'];before=physical(name+'-before');log=O/(name+'.log');start=time.monotonic()
 with log.open('wb')as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 after=physical(name+'-after');row={'name':name,'command':cmd,'actual_exit':p.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'source_before':before,'source_after':after};D['gates'].append(row);save();print(json.dumps({k:v for k,v in row.items()if k not in ['source_before','source_after']}),flush=True)
 if p.returncode:D['state']='FAILED';D['finished_paris']=now();save();raise SystemExit(p.returncode)
D['physical_final']=physical('final');D['state']='ALL_GATES_ACTUAL0';D['finished_paris']=now();save()
