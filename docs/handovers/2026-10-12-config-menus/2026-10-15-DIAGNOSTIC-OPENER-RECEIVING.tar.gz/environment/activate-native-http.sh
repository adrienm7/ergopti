# Source after the standard cloud activation. Validation-only tool paths.
. /workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/activate-prereqs.sh
export ERGOPTI_MANAGED_NATIVE_MODERN_CURL=/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/tools/modern/bin/curl
export ERGOPTI_MANAGED_NATIVE_MODERN_SHA256=b5d2f3d16dd5f5ceaa047c6cc4056a2bd8cde44f8d663538275f8dd9e3ca0111
export ERGOPTI_MANAGED_NATIVE_LEGACY_CURL=/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/tools/legacy-root/usr/bin/curl
export ERGOPTI_MANAGED_NATIVE_LEGACY_SHA256=27125f0331490b7fbf4da11f2bd913ce1b94e071367b2fa8e535ce8c5526e29c
export ERGOPTI_MANAGED_NATIVE_LEGACY_LIBRARY_PATH=/workspace/.ergopti-cloud/native-http-prereqs-5ar36pu4/tools/legacy-libraries
