"""Read-only data receiving; never imports received code or executes native bytes."""
from pathlib import Path
import ast, hashlib, json, math, re, subprocess, struct
P=Path(__file__).resolve().parent
SHA='a18f22edd3153884e67a78500417dbea6342e978'
def digest(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(P/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def gitbytes(path):
 assert not path.startswith('/') and '..' not in Path(path).parts
 return subprocess.run(['git','-C','/workspace/ergopti','show',SHA+':'+path],capture_output=True,check=True).stdout
builder=ast.parse(gitbytes('static/ergopti_plus/macos/tests/support/native_http_fixture_builder.py'))
node=next(n.value for n in builder.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MODULE_MAP' for t in n.targets))
assert isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='encode' and len(node.args)==1 and ast.literal_eval(node.args[0])=='utf-8'
modulemap=ast.literal_eval(node.func.value).encode('utf-8')
clock_summaries={}
for arch in ['arm64','amd64']:
 p=P/('clock-'+arch)
 before,after,final=[read(p/n) for n in ['source-before.json','source-after.json','source-final.json']]
 for field in ['schema','scope','candidate','run_id','run_attempt','architecture','original_source','sources','loaders']:
  assert before[field]==after[field]==final[field],field
 assert before['candidate']==SHA and before['run_id']=='38188708204' and before['run_attempt']=='1' and before['architecture']==arch
 sources={**before['original_source']['sources'],**before['sources'],**before['loaders']}
 assert len(sources)==424
 joined=[]
 for path,expected in sources.items():
  data=gitbytes(path);assert digest(data)==expected,path
  joined.append({'path':path,'bytes':len(data),'sha256':expected})
 recipe=read(p/'payload/source-receipt.json');clock=read(p/'payload/clock-receipt.json');verdict=read(p/'clock-verdict.json')
 assert len(recipe['source_hashes'])==18 and len(recipe['staged_hashes'])==16
 assert all(sources[path]==d for path,d in recipe['source_hashes'].items())
 assert clock['source_hashes']==recipe['source_hashes'] and clock['staged_hashes']==recipe['staged_hashes']
 for stage,expected in recipe['staged_hashes'].items():
  if stage=='CPOSIXCompatibility/module.modulemap':assert digest(modulemap)==expected
  else:
   candidates=[d for source,d in recipe['source_hashes'].items() if source==stage.removeprefix('OwnedNativeHTTPFixture.app/Contents/Resources/') or Path(source).name==Path(stage).name]
   assert candidates==[expected],stage
 for name,expected in verdict['payload_sha256'].items():assert digest((p/'payload'/name).read_bytes())==expected,name
 image=(p/'payload/image.bin').read_bytes();assert digest(image)==recipe['binary_sha256']==clock['binary_sha256']
 assert (clock['device'],clock['inode'])==(recipe['device'],recipe['inode'])
 assert image[:4]==b'\xcf\xfa\xed\xfe'
 cputype=struct.unpack_from('<I',image,4)[0];assert cputype=={'arm64':0x0100000c,'amd64':0x01000007}[arch]
 frame=read(p/'payload/clock-frame.bin');samples=clock['system_uptime'];assert len(samples)==len(frame['system_uptime'])==16
 delta=max(abs(a-b) for a,b in zip(samples,frame['system_uptime']))
 assert delta<1e-9 # JSON decimal representation only; original native predicates remain untouched.
 assert all(clock['python_before']<=x<=clock['python_after'] for x in samples)
 for role,fact in verdict['command_observations'].items():
  assert role in ['compile','sign','strict_verify','clock']
  assert fact==read(p/('payload/'+role+'.json'))
  assert fact['exit_status']==0 and fact['literal_true_settlement'] is True and fact['owner']['closed'] is True
  assert fact['owner']['live_group_members']==[] and fact['owner']['reservation_lost'] is False
  assert all(fact[s] is True for s in ['stdin_closed','stdout_closed','stderr_closed'])
  assert not fact['command_file_debt'] and not fact['command_group_debt']
 result={'source_join':{'candidate':SHA,'run':38188708204,'attempt':1,'architecture':arch,'original_scope_count':len(before['original_source']['sources']),'clock_sources':len(before['sources']),'clock_loaders':len(before['loaders']),'union_raw_Git_bytes_rehashed':len(joined),'all_match':True},'clock':{'samples':16,'python_before':clock['python_before'],'python_after':clock['python_after'],'native_first':samples[0],'native_last':samples[-1],'enclosed':True,'raw_frame_sha256':digest((p/'payload/clock-frame.bin').read_bytes()),'frame_numeric_serialization_max_delta':delta,'image_sha256':digest(image),'cputype':hex(cputype),'device':clock['device'],'inode':clock['inode'],'recipe_inputs':18,'staged_inputs':16,'payload_hashes':len(verdict['payload_sha256']),'command_observations':verdict['command_observations'],'native_statuses':read(p/'native-statuses.json'),'compiler_identity':verdict['compiler_identity'],'python_interpreter_identity':verdict['python_interpreter_identity'],'kernel_executable_identity':verdict['kernel_executable_identity'],'factory_activation':'HELD','qualification':'Official API/artifact and raw source/frame/image hashes received; hashes and numerical sample do not prove kernel executable/compiler/interpreter identity. Independent native client fails.'},'sources':joined}
 write(arch+'-clock-current-receiving.json',result);clock_summaries[arch]={k:v for k,v in result.items() if k!='sources'}
write('both-architectures-clock-summary.json',clock_summaries)
pac_summaries={}
for arch in ['arm64','amd64']:
 p=P/('pac-'+arch);cohorts={}
 for name,expected in [('native-pac-xctest.log',14),('native-pac-source-xctest.log',10)]:
  text=(p/name).read_text()
  rows=[{'suite':a,'case':b,'status':c,'seconds':float(d)} for a,b,c,d in re.findall(r"Test Case '-\[ErgoptiPlusTests\.([^ ]+) ([^\]]+)\]' (passed|failed|skipped) \(([0-9.]+) seconds\)\.",text)]
  assert len(rows)==expected and len({(r['suite'],r['case']) for r in rows})==expected
  cohorts[name]={'planned':expected,'passed':sum(r['status']=='passed' for r in rows),'failed_methods':sum(r['status']=='failed' for r in rows),'skipped':sum(r['status']=='skipped' for r in rows),'unexecuted':0,'cases':rows,'errors':[line for line in text.splitlines() if ': error:' in line],'observations':[line for line in text.splitlines() if line.startswith('# native_http_')]}
 http=(P/('clock-'+arch)/'independent-client.log').read_text()
 facts=[]
 for line in http.splitlines():
  if line.startswith('# ') and ' {' in line:
   role,_,payload=line[2:].partition(' ')
   try: facts.append({'role':role,'value':json.loads(payload)})
   except json.JSONDecodeError:pass
 m=re.search(r'Ran (\d+) tests in ([0-9.]+)s',http);assert m and m.group(1)=='2' and 'FAILED (errors=3)' in http
 errors=re.findall(r'^ERROR: (.+)$',http,re.M)
 assert len(errors)==3
 pac_summaries[arch]={'PAC':cohorts,'independent_HTTP':{'attempted':2,'passed':0,'assertion_failures':0,'errors':3,'teardown_errors':1,'seconds':float(m.group(2)),'error_identities':errors,'facts':facts,'limitation':'Original15s trust addition deadline stops both positive paths; physical worker closure is distinct from trust restoration debt.'}}
write('both-architectures-PAC-and-HTTP-summary.json',pac_summaries)
core=(P/'official-core-job114616824367.log').read_text()
assert '1/414 JS check(s) FAILED' in core
line=next(l for l in core.splitlines() if 'PORTABLE_RECEIVER_FAILURE {' in l)
failure=json.loads(line.split('PORTABLE_RECEIVER_FAILURE ',1)[1]);assert failure['error_code']=='ETIMEDOUT' and failure['signal']=='SIGTERM' and failure['status'] is None
closures=[json.loads(l.split(' ',2)[2]) for l in failure['stdout_tail'].splitlines() if l.startswith('# native_http_fixture_closure ')]
write('core-current-receiving.json',{'candidate':SHA,'run':38188708204,'attempt':1,'job':114616824367,'checks':414,'passed':413,'failed':1,'known_success_checks':[l for l in core.splitlines() if '… OK' in l and ('clock evidence' in l or 'updater' in l.lower())],'failure':failure,'stderr_progress_dots':failure['stderr_tail'].count('.'),'closure_frames':closures,'original_timeout_ms':60000,'interpreter':'/opt/hostedtoolcache/Python/3.12.15/x64/bin/python3','assertion':'the portable receiver must start','case_completion':'UNQUALIFIED: dots are not case identities or156 completion; success child stdout omitted by default wrapper','poll_successor':'NOT_TESTED_BY_A18','native_qualified':False})
print(json.dumps({'clock':{a:{'source_count':v['source_join']['union_raw_Git_bytes_rehashed'],'samples':v['clock']['samples']} for a,v in clock_summaries.items()},'PAC':{a:{k:{key:v[key] for key in ['passed','failed_methods','skipped']} for k,v in d['PAC'].items()} for a,d in pac_summaries.items()},'Core':'413PASS/1FAIL'}))
