# Exact ARM permission-history receiving review

Official run38129586139/attempt1, job114441094292 and artifact11698483204 bind current source5f7a8467c9696b26a75de104f6329b39c181b8cb. The original log and ZIP hashes match supplied retrieval bindings. All348 safe unique regular extracted members equal the original ZIP bytes. All400 item36 and403 SDK source hashes match actual Git blobs; verdicts retain their original exact source receipts.

The native archive executes25 methods:24 pass, one Homebrew method fails with two failure records, one unexpected, and none skip. Archive8, Sparkle15 and consent-argument1 pass, including actual wrong-key preservation, valid retry and relaunch. Homebrew preserves the original Automation prompt deadline before the six Brew scenarios.

The final Brew-helper checkpoint now carries first_permission_worker={schema:1,stage:api-call-starting,api_osstatus:null} despite256 retained history files and92 omitted later records. Subsequent final candidate.failed preserves that copied fact, empty groups/debt and recorded closure. The integrated diagnostic retention correction is therefore received on the exact ARM source. The retained history contains73 typed UI observations: six have no optional discovery fact;67 report a complete first seven-node unrelated traversal without either name. All73 record requester qualification and AX trust, with zero candidates and matches.

The worker fact observes its existing pre-call write. It establishes neither API entry nor blocking, and it does not identify a causal consent defect. The independent no-prompt SDK method passes as metadata-only receiving but actually reports OSStatus-600; catalogue, signed-application and osascript-principal qualification all remain false. It cannot grant same-pair Automation consent.

No new source or test correction is justified by these facts. Continue the unchanged same-pair normal consent route on a qualifying session, then execute all six strict Brew scenarios and final package/installed upgrade/relaunch. Do not infer general hosted-platform incapability or change identities, TCC state, deadlines, grants or assertions speculatively. Intel receiving and complete installation remain separate. Items36/62 and transversal16/38 remain open.

This review only read retained artifacts and Git objects. It started no suite and changed no repository source, index, refs or API state. The companion receipt.json contains exact hashes and bounded observations.
