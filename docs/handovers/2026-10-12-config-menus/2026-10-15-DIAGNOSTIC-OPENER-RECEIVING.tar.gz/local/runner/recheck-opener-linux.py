import datetime
import hashlib
import json
import os
import subprocess
import tempfile
import time
from pathlib import Path

OUT = Path('/workspace/.ergopti-cloud')
VIEW = OUT / 'config-healthcheck-opener-view'
DEST = OUT / 'opener-linux-recheck-status.json'
LOG = OUT / 'opener-linux-recheck.log'
BASE = '614970f3c2f8c2c1b6c27e27ff1c513dd6c933d7'
TREE = '5f3a0f0c5926593b8fe10802ca779d5e55222e51'
assert not DEST.exists(), 'Inspect previous recheck before retry'
original = json.loads((OUT / 'opener-selected-native-status.json').read_text())
pair = json.loads((OUT / 'opener-paired-gates-status.json').read_text())
assert pair['state'] == 'FAILED' and original['status'] == 'FAILED' and original['inputs_unchanged']
assert [(c['gate'], c['exit_code']) for c in original['commands'] if c['exit_code']] == [('linux', 1)]
assert len(original['commands']) == 5
owned = json.loads((OUT / 'resume-healthcheck-opener/owned-paths.json').read_text())
clock_paths = ['static/ergopti_plus/linux/tests/unit/infra/test_native_timer.lua', 'static/ergopti_plus/linux/tests/fixtures/native_relative_timer_siblings.lua', 'static/ergopti_plus/linux/infra/native_timer.lua', 'static/ergopti_plus/linux/adapters/file_digest.lua']


def git(*args):
    return subprocess.check_output(['git', *args], cwd=VIEW, text=True).strip()


def snapshot():
    return {'head': git('rev-parse', 'HEAD'), 'index_tree': git('write-tree'), 'unstaged_paths': git('diff', '--name-only'), 'untracked_paths': git('ls-files', '--others', '--exclude-standard'), 'source_sha256': {p: hashlib.sha256((VIEW / p).read_bytes()).hexdigest() for p in owned}, 'clock_source_sha256': {p: hashlib.sha256((VIEW / p).read_bytes()).hexdigest() for p in clock_paths}}


before = snapshot()
assert before['head'] == BASE and before['index_tree'] == TREE
assert not before['unstaged_paths'] and not before['untracked_paths']
assert all(before[k] == original['after'][k] for k in original['after'])
tmp = tempfile.mkdtemp(prefix='eg-op-r-', dir='/var/tmp')
env = os.environ.copy()
env.update(TMPDIR=tmp, TEMP=tmp)
record = {'status': 'RUNNING', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'before': before, 'temporary_directory': tmp, 'original_status': 'FAILED', 'original_failure': 'Linux13,848PASS/1FAIL; native relative-timer first FIFO digest timeout, 100ms budget. Underlying cause UNKNOWN; 112.03ms is joint digest/writer completion, not timeout fire timestamp.', 'source_or_assertion_changes': False, 'commands': []}
DEST.write_text(json.dumps(record, indent=2) + '\n')
with LOG.open('w') as log:
    commands = [('original-native-sibling-fixture', ['node', 'tools/test/run-linux-lua.cjs', str(VIEW / 'static/ergopti_plus/linux/tests/fixtures/native_relative_timer_siblings.lua')]), ('linux', ['npm', 'run', 'test:linux'])]
    for name, command in commands:
        log.write('\n=== ' + name + ' ===\n')
        log.flush()
        start = time.monotonic()
        result = subprocess.run(command, cwd=VIEW, env=env, stdout=log, stderr=subprocess.STDOUT)
        entry = {'gate': name, 'command': command, 'exit_code': result.returncode, 'seconds': time.monotonic() - start}
        record['commands'].append(entry)
        DEST.write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps(entry), flush=True)
        if result.returncode:
            break
record['after'] = snapshot()
record['inputs_unchanged'] = record['after'] == before
record['status'] = 'PASSED' if len(record['commands']) == 2 and all(c['exit_code'] == 0 for c in record['commands']) and record['inputs_unchanged'] else 'FAILED'
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['log_sha256'] = hashlib.sha256(LOG.read_bytes()).hexdigest()
DEST.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['status', 'inputs_unchanged', 'log_sha256']}), flush=True)
raise SystemExit(0 if record['status'] == 'PASSED' else 1)
