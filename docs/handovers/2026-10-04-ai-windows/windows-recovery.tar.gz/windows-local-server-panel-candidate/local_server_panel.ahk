﻿; ui/menu/menu_llm/local_server_panel.ahk

; ==============================================================================
; MODULE: Native Local Server Menu Panel
; DESCRIPTION:
; Binds the shared row policy to exact private source/view ownership, the native
; models transport and existing joint API publisher. Initialization waits for
; restored runtime state. Discovery never installs or starts a server.
; ==============================================================================

#Requires AutoHotkey v2.0

global _LLM_LocalServerPanel := 0
global _LLM_LocalServerPanelInitBusy := false





; =======================================
; =======================================
; ======= 1/ Panel Initialization =======
; =======================================
; =======================================

/** Creates one native panel after restored AI runtime ownership is available. */
LLM_Menu_LocalServersInit() {
	global _LLM_LocalServerPanel, _LLM_LocalServerPanelInitBusy
	global _LLM_Menu_Loaded, _LLM_Menu_RuntimeActivated, LLM_LOCAL_API_SERVERS
	PreviousCritical := Critical("Off")
	try {
		if !IsSet(_LLM_Menu_Loaded) || !_LLM_Menu_Loaded
				|| !IsSet(_LLM_Menu_RuntimeActivated) || !_LLM_Menu_RuntimeActivated
			return false
		if !(LLM_LOCAL_API_SERVERS is Map) || LLM_LOCAL_API_SERVERS.Count == 0 {
			LoggerWarn("LLM.local_servers", "Local server menu initialization refused an unavailable catalogue.")
			return false
		}
		ClaimCritical := Critical("On")
		try {
			if _LLM_LocalServerPanel is LLM_LocalServerPanel
				return true
			if _LLM_LocalServerPanelInitBusy
				return false
			_LLM_LocalServerPanelInitBusy := true
		} finally Critical(ClaimCritical)
		try {
			LoggerStart("LLM.local_servers", "Initializing local server menu ownership…")
			Panel := LLM_LocalServerPanel()
			ClaimCritical := Critical("On")
			try _LLM_LocalServerPanel := Panel
			finally Critical(ClaimCritical)
		} finally {
			ClaimCritical := Critical("On")
			try _LLM_LocalServerPanelInitBusy := false
			finally Critical(ClaimCritical)
		}
		LoggerDone("LLM.local_servers", "Local server menu owner initialized.")
		LLM_Menu_RequestBuild("local_servers_initialized")
		return true
	} finally Critical(PreviousCritical)
}

/** Returns native rows without creating a runtime during detached boot staging. */
LLM_Menu_LocalServersRows() {
	global _LLM_LocalServerPanel
	if !(_LLM_LocalServerPanel is LLM_LocalServerPanel)
		return [Map("separator", true),
			Map("label", t("menu.llm.local_servers.header"), "disabled", true),
			Map("label", t("menu.llm.unavailable"), "disabled", true)]
	return _LLM_LocalServerPanel.Rows()
}

/** Resolves the precise checked provider without probing or invalidating a view. */
LLM_Menu_LocalServersBackendLabel(Fallback) {
	global _LLM_LocalServerPanel
	return _LLM_LocalServerPanel is LLM_LocalServerPanel
		? _LLM_LocalServerPanel.BackendLabel(Fallback) : Fallback
}

/** Pausing invalidates publication before requesting exact native retirement. */
LLM_Menu_LocalServersOnSuspend() {
	global _LLM_LocalServerPanel
	return !(_LLM_LocalServerPanel is LLM_LocalServerPanel)
		|| _LLM_LocalServerPanel.Retire(false)
}

/** Resumes retained resource cleanup and asks for a fresh menu/source capture. */
LLM_Menu_LocalServersOnResume() {
	global _LLM_LocalServerPanel
	if A_IsSuspended
		return false
	if !LLM_Menu_LocalServersInit()
		return false
	_LLM_LocalServerPanel.Native.RetryPending()
	return LLM_Menu_RequestBuild("local_servers_resume")
}

/** Shutdown may refuse until this owner's exact HTTP and queue debts settle. */
LLM_Menu_LocalServersPrepareShutdown() {
	global _LLM_LocalServerPanel
	return !(_LLM_LocalServerPanel is LLM_LocalServerPanel)
		|| _LLM_LocalServerPanel.Retire(false)
}





; ====================================
; ====================================
; ======= 2/ Native View Owner =======
; ====================================
; ====================================

class LLM_LocalServerPanel {
	__New() {
		global LLM_LOCAL_API_SERVERS, LLM_API_PROVIDER_ORDER
		if !(LLM_LOCAL_API_SERVERS is Map) || LLM_LOCAL_API_SERVERS.Count == 0
				|| !(LLM_API_PROVIDER_ORDER is Array)
			throw Error("The local AI server catalogue is unavailable.")
		this.Servers := LLM_LOCAL_API_SERVERS
		this.Order := []
		for Id in LLM_API_PROVIDER_ORDER
			if this.Servers.Has(Id)
				this.Order.Push(Id)
		if this.Order.Length != this.Servers.Count
			throw Error("The local AI server catalogue ordering is incomplete.")
		this.Source := LLM_Menu_ApiPrivateSourceOwner()
		this.Generation := 0
		this.View := 0
		this.LastSnapshot := 0
		this.Writing := false
		this.Models := LocalServerModelsOwner(Map("servers", this.Servers,
			"timeout_ms", TimingsGet("llm", "local_server_probe_timeout_ms"),
			"poll_ms", TimingsGet("llm", "poll_interval_ms"),
			"on_error", ObjBindMethod(this, "_Error")))
		Ports := this.Source.Ports()
		Ports["order"] := this.Order
		Ports["servers"] := this.Servers
		Ports["models_owner"] := this.Models
		Ports["poll_ms"] := TimingsGet("llm", "poll_interval_ms")
		Ports["clock"] := ObjBindMethod(this, "_Clock")
		Ports["max_age"] := (*) => TimingsGet("llm", "local_server_detection_max_age_ms")
		Ports["on_publish"] := ObjBindMethod(this, "_Published")
		Ports["on_error"] := ObjBindMethod(this, "_Error")
		this.Native := LocalServersOwner(Ports)
	}

	_Clock() {
		return DllCall("Kernel32\GetTickCount64", "UInt64")
	}

	_Format(Key, Values*) {
		return Format(t(Key), Values*)
	}

	_Error(Kind, Detail, Id := "") {
		; Transport errors can contain private request data. Only the fixed
		; error kind and known provider identity belong in this panel's log.
		Provider := this.Servers.Has(Id) ? Id : ""
		LoggerWarn("LLM.local_servers", "Local server {1} owner reported '{2}'.", Provider, Kind)
	}

	_Published(Results, Changed) {
		; Even an identical accepted rescan owns a new cache identity. A fresh
		; source/view capture must therefore follow every acknowledged result.
		LLM_Menu_RequestBuild("local_servers_published")
	}

	/** Retains display-only data under pause; native actions require a live view. */
	Rows() {
		global _LLM_Menu_ApiPrivateAuthorityGeneration
		PreviousCritical := Critical("Off")
		try {
			if A_IsSuspended || this.Writing
				return this.LastSnapshot is Map ? this._Render(this.LastSnapshot, true, 0) : this._UnavailableRows()
			if !this.Source.Admit()
				return this._UnavailableRows()
			if this.Native.IsStale()
				this.Native.Rescan()
			Source := this.Source.Capture()
			if !IsObject(Source)
				return this._UnavailableRows()
			Owner := Map("source", Source, "receipts", Map())
			ClaimCritical := Critical("On")
			try {
				Ready := !A_IsSuspended && !this.Writing
				if Ready {
					Owner["generation"] := ++this.Generation
					this.Native.BeginView()
					Owner["native_view"] := this.Native.ViewGeneration
					Owner["native_models"] := this.Native.ModelGeneration
					Owner["native_configuration"] := this.Native.ConfigurationGeneration
					Owner["native_cache"] := this.Native.Cache
					Owner["native_rescan"] := this.Native.RescanGeneration
					Owner["native_controller"] := this.Native.Controller.Generation
					Owner["authority"] := _LLM_Menu_ApiPrivateAuthorityGeneration
					this.View := Owner
				}
			} finally Critical(ClaimCritical)
			if !Ready
				return this._UnavailableRows()
			Snapshot := Map("results", Map(), "detected", [], "active", 0,
				"backend", "", "sweeping", this.Native.Controller.IsSweeping())
			for Id in this.Order {
				Receipt := this.Native.Capture(Id)
				if !IsObject(Receipt)
					return this._UnavailableRows()
				Owner["receipts"][Id] := Receipt
				Verdict := this.Native.Result(Id)
				if Verdict is Map {
					Snapshot["results"][Id] := Verdict
					if !(Verdict["status"] == "down")
						Snapshot["detected"].Push(Id)
				}
			}
			if !this._ActiveSnapshot(Snapshot) || !this._Current(Owner)
				return this._UnavailableRows()
			for Id, Receipt in Owner["receipts"]
				if !this.Native.IsCurrent(Receipt)
					return this._UnavailableRows()
			if !this._Current(Owner)
				return this._UnavailableRows()
			Snapshot["authority"] := Owner["authority"]
			ClaimCritical := Critical("On")
			try {
				Ready := this._HeldCurrent(Owner)
				if Ready
					this.LastSnapshot := Snapshot
			} finally Critical(ClaimCritical)
			return Ready ? this._Render(Snapshot, false, Owner) : this._UnavailableRows()
		} catch as Err {
			this._Error("view", Err)
			return this._UnavailableRows()
		} finally Critical(PreviousCritical)
	}

	_ActiveSnapshot(Snapshot) {
		global _LLM_Menu
		Menu := _LLM_Menu
		if !(Menu is Map)
			return false
		Snapshot["backend"] := Menu.Get("backend", "")
		Snapshot["menu_owner"] := Menu
		EntryId := Menu.Get("api_entry_id", "")
		Snapshot["active_id"] := EntryId
		for Id in this.Order {
			Entry := this.Source.Entry(Id)
			if Entry is Map && Entry["Id"] == EntryId {
				Snapshot["active"] := Map("provider", Id, "model", Entry["Model"])
				break
			}
		}
		return true
	}

	_SnapshotResult(Snapshot, Id) {
		return Snapshot["results"].Get(Id, 0)
	}

	_Render(Snapshot, Paused, Owner) {
		return LocalServerMenuRows(Map("order", this.Order, "servers", this.Servers,
			"detected", Snapshot["detected"], "result", ObjBindMethod(this, "_SnapshotResult", Snapshot),
			"backend", Snapshot["backend"], "active", Snapshot["active"],
			"sweeping", Snapshot["sweeping"], "paused", Paused, "tr", t,
			"format", ObjBindMethod(this, "_Format"), "actions", Map(
				"select", ObjBindMethod(this, "_Select", Owner),
				"address", ObjBindMethod(this, "_Address", Owner),
				"key", ObjBindMethod(this, "_Key", Owner),
				"rescan", ObjBindMethod(this, "_Rescan", Owner))))
	}

	_UnavailableRows() {
		return [Map("separator", true),
			Map("label", t("menu.llm.local_servers.header"), "disabled", true),
			Map("label", t("menu.llm.unavailable"), "disabled", true)]
	}

	/** Does not mint a receipt or produce HTTP work while resolving the row title. */
	BackendLabel(Fallback) {
		global _LLM_Menu, _LLM_Menu_ApiPrivateAuthorityGeneration
		Snapshot := this.LastSnapshot
		if !(Snapshot is Map) || !(_LLM_Menu is Map) || _LLM_Menu.Get("backend", "") != "api"
				|| _LLM_Menu_ApiPrivateAuthorityGeneration != Snapshot["authority"]
				|| ObjPtr(_LLM_Menu) != ObjPtr(Snapshot["menu_owner"])
				|| !(_LLM_Menu.Get("api_entry_id", "") == Snapshot["active_id"])
			return Fallback
		Label := Fallback
		for Row in this._Render(Snapshot, true, 0)
			if Row.Get("checked", false)
				Label := _LLM_Menu_OptionHead(Row["label"])
		return _LLM_Menu_ApiPrivateAuthorityGeneration == Snapshot["authority"]
			&& ObjPtr(_LLM_Menu) == ObjPtr(Snapshot["menu_owner"])
			&& (_LLM_Menu.Get("backend", "") == "api")
			&& (_LLM_Menu.Get("api_entry_id", "") == Snapshot["active_id"]) ? Label : Fallback
	}

	_Current(Owner, Id := "", Model := "") {
		if !(Owner is Map) || A_IsSuspended || this.Writing || !this.Source.Current(Owner["source"])
			return false
		if Id != "" && (!Owner["receipts"].Has(Id) || !this.Native.IsCurrent(Owner["receipts"][Id], Model))
			return false
		if !this.Source.Current(Owner["source"])
			return false
		PreviousCritical := Critical("On")
		try return this._HeldCurrent(Owner)
		finally Critical(PreviousCritical)
	}

	_HeldCurrent(Owner) {
		global _LLM_Menu_ApiPrivateAuthorityGeneration
		return this.View is Map && ObjPtr(this.View) == ObjPtr(Owner)
			&& Owner["generation"] == this.Generation && Owner["native_view"] == this.Native.ViewGeneration
			&& Owner["native_models"] == this.Native.ModelGeneration
			&& Owner["native_configuration"] == this.Native.ConfigurationGeneration
			&& Owner["native_cache"] == this.Native.Cache
			&& Owner["native_rescan"] == this.Native.RescanGeneration
			&& Owner["native_controller"] == this.Native.Controller.Generation
			&& Owner["authority"] == _LLM_Menu_ApiPrivateAuthorityGeneration
			&& !A_IsSuspended && !this.Writing
	}





; ===================================
; ===================================
; ======= 3/ Retained Actions =======
; ===================================
; ===================================

	_Select(Owner, Id, Model, *) {
		return this._Apply(Owner, Id, Map("model", Model), Model)
	}

	_Address(Owner, Id, *) {
		PreviousCritical := Critical("Off")
		try return this._PromptAddress(Owner, Id)
		finally Critical(PreviousCritical)
	}

	_PromptAddress(Owner, Id) {
		if !this._Current(Owner, Id)
			return false
		Target := this.Native.Target(Id), Server := this.Servers[Id]
		if !(Target is Map) || !this._Current(Owner, Id)
			return false
		Answer := Ui_InputBox(this._Format("dialog.local_servers.address_prompt", Server["label"], Server["base_url"]),
			t("menu.llm.local_servers.header"), "w560 h160", Target["base_url"])
		if !(Answer.Result == "OK") || !this._Current(Owner, Id)
			return false
		BaseUrl := Trim(Answer.Value)
		if BaseUrl == ""
			BaseUrl := Server["base_url"]
		if !_HTTP_CurlScalarIsSafe(BaseUrl) || !RegExMatch(BaseUrl, "i)^https?://[^[:space:]]+$") {
			Ui_MsgBox(this._Format("llm.local_servers.invalid_address", Server["base_url"]), Server["label"], "Iconx")
			return false
		}
		return this._Apply(Owner, Id, Map("base_url", BaseUrl))
	}

	_Key(Owner, Id, *) {
		PreviousCritical := Critical("Off")
		try return this._PromptKey(Owner, Id)
		finally Critical(PreviousCritical)
	}

	_PromptKey(Owner, Id) {
		if !this._Current(Owner, Id)
			return false
		Answer := Ui_InputBox(this._Format("dialog.local_servers.key_prompt", this.Servers[Id]["label"]),
			t("menu.llm.local_servers.header"), "Password w560 h160", "")
		if !(Answer.Result == "OK") || !this._Current(Owner, Id)
			return false
		return this._Apply(Owner, Id, Map("token", Answer.Value))
	}

	_Apply(Owner, Id, Fields, Model := "") {
		PreviousCritical := Critical("Off")
		try return this._ApplyNonCritical(Owner, Id, Fields, Model)
		finally Critical(PreviousCritical)
	}

	_ApplyNonCritical(Owner, Id, Fields, Model := "") {
		if !this._Current(Owner, Id, Model)
			return false
		PreviousCritical := Critical("On")
		try {
			if this.Writing || A_IsSuspended || !(this.View is Map) || ObjPtr(this.View) != ObjPtr(Owner)
				return false
			this.Writing := true
		} finally Critical(PreviousCritical)
		try Result := this.Native.Apply(Owner["receipts"][Id], Fields)
		finally {
			PreviousCritical := Critical("On")
			try this.Writing := false
			finally Critical(PreviousCritical)
		}
		if !(Result is Map)
			return false
		Saved := Result.Get("saved", 0), Pending := Result.Get("pending", 0)
		if !((Saved is Integer) && Saved == 1) && !((Pending is Integer) && Pending == 1)
			return false
		PreviousCritical := Critical("On")
		try {
			this.View := 0
			this.Generation += 1
		} finally Critical(PreviousCritical)
		LLM_Menu_RequestBuild("local_servers_applied")
		if Model == ""
			this.Native.Rescan(ObjBindMethod(this, "_ReportSweep", Id))
		return true
	}

	_Rescan(Owner, *) {
		PreviousCritical := Critical("Off")
		try return this._RescanNonCritical(Owner)
		finally Critical(PreviousCritical)
	}

	_RescanNonCritical(Owner) {
		if !this._Current(Owner)
			return false
		Started := this.Native.Rescan()
		if Started
			LLM_Menu_RequestBuild("local_servers_rescan")
		return Started
	}

	_ReportSweep(Id, Changed) {
		PreviousCritical := Critical("Off")
		try this._ReportSweepNonCritical(Id)
		finally Critical(PreviousCritical)
	}

	_ReportSweepNonCritical(Id) {
		if A_IsSuspended || !this.Source.Admit()
			return
		Verdict := this.Native.Result(Id)
		if !(Verdict is Map)
			return
		Server := this.Servers[Id]
		if Verdict["status"] == "up"
			Body := this._Format("llm.local_servers.found_body", Verdict["models"].Length)
		else if Verdict["status"] == "needs_key"
			Body := this._Format("menu.llm.local_servers.needs_key", Server["label"])
		else
			Body := this._Format("menu.llm.local_servers.none", LocalServerMenuHost(Verdict["base_url"]))
		if !A_IsSuspended && this.Source.Admit()
			TrayTip(Body, Server["label"], Verdict["status"] == "up" ? "Iconi" : "Icon!")
	}

	/** Cleanup acknowledges only this owner; ShellRunner keeps its separate debts. */
	Retire(Shutdown) {
		PreviousCritical := Critical("Off")
		try {
			ClaimCritical := Critical("On")
			try {
				this.Generation += 1
				this.View := 0
			} finally Critical(ClaimCritical)
			Cancelled := this.Native.Cancel(Shutdown)
			Settled := this.Native.RetryPending()
			return Cancelled && Settled
		} finally Critical(PreviousCritical)
	}
}
