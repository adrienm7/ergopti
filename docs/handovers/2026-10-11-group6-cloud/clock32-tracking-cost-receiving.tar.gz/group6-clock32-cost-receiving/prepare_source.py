from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path(__file__).resolve().parent
repo=Path('/workspace/ergopti')
inv=json.loads((root/'source-inventory.json').read_text())
for entry in inv['source_files']:
    data=(repo/entry['path']).read_bytes()
    if hashlib.sha256(data).hexdigest()!=entry['sha256']:
        raise SystemExit('Exact original Source preimage changed: '+entry['path'])
for directory,candidate in [('physical-source',False),('candidate-physical-source',True)]:
    source=root/directory
    if source.exists():
        raise SystemExit('Receiving namespace already exists; preserve and use a fresh capsule extraction')
    source.mkdir()
    for entry in inv['source_files']:
        target=source/entry['path'];target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(repo/entry['path'],target)
    if candidate:
        shutil.copy2(root/'proposal-candidate/tools/ci/native_http_clock_evidence.cjs',source/'tools/ci/native_http_clock_evidence.cjs')
    for args in [['init','-q'],['config','user.name','Private clock Source receiving'],['config','user.email','portable@example.invalid'],['add','--all'],['commit','-qm','Finite pinned clock Source receiving']]:
        subprocess.run(['git','-c','core.hooksPath=/dev/null',*args],cwd=source,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
