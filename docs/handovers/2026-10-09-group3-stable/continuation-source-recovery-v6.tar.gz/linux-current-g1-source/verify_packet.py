# group3-linux93-g1-published-union/verify_packet.py
"""Check inactive source bytes and safe45-member source-pair archive."""
from pathlib import Path
import json,hashlib,tarfile
b=Path(__file__).resolve().parent;r=json.loads((b/'receipt.json').read_text())
for name,expected in r['artifacts'].items():
 p=b/name;assert p.is_file() and not p.is_symlink(),name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,name
with tarfile.open(b/'source-pair.tar') as tar:
 members=tar.getmembers();assert len(members)==45 and len({m.name for m in members})==45
 for m in members:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert tar.extractfile(m).read()==(b/m.name).read_bytes()
for row in r['source_pairs']:
 for folder,field in [('preimages','pre_sha256'),('candidate','post_sha256')]:
  p=b/folder/row['path'];expected=row[field]
  if expected is None:assert not p.exists() and not p.is_symlink()
  else:assert p.is_file() and not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()==expected
print('VERIFIED23 inactive paths:22 existing +1 new; no native admission')
