// _shared/ui/model_browser/script.js

/**
 * ==============================================================================
 * MODULE: Model Selector Page Script
 * DESCRIPTION:
 * The place where the user picks the active AI model: one table, grouped by
 * backend (the local ones, MLX and Ollama, in alphabetical order, then the
 * remote API), with the size on disk, the RAM required, whether the model is
 * installed and which one is current. Shared verbatim by the macOS
 * (hs.webview), Windows (WebView2) and Linux (WebKitGTK) drivers: each injects
 * one payload via injectModels() and receives the user's actions through
 * postBridgeMessage().
 *
 * FEATURES & RATIONALE:
 * 1. One projection: the rows come from the shared model catalogue and the
 *    driver's install scan (_shared/lua/llm/model_catalogue.lua on macOS and
 *    Linux, its pinned AHK twin on Windows); the page never reads files.
 * 2. Only what works now is selectable: a backend the driver reports
 *    unavailable greys its rows with the reason, and a model that is not
 *    installed offers its download, never its activation. Each local backend
 *    header carries "Install <backend>": usable only while its runtime is
 *    missing, greyed with the reason once installed or on a machine that
 *    cannot run it, and showing the install's progress while it runs.
 * 3. The page decides nothing: every action crosses the bridge to the code
 *    path the tray used (validation, persistence, warmup).
 * 4. Keyboard first: rows are focusable, arrows move, Enter uses the focused
 *    model, Delete removes an installed one, and every action is a button.
 * 5. Three rows first: every group opens collapsed to its header (chevron,
 *    emoji, name, model count, tools), so the API and MLX groups are not
 *    buried below the long Ollama list. A collapsed group holding the active
 *    model names it on its header. A filter or a search opens every group it
 *    finds a match in; the groups the user opened stay open while the page
 *    lives, never in a setting.
 * ==============================================================================
 */

var _models = []; // Rows of the current payload.
var _backends = []; // [{ id, brand, emoji, kind, available, reason_key, install? }] in display order.
var _backend = ''; // Active backend id.
var _active = ''; // Active model name (display name) on the active backend.
var _selected = null; // Key of the highlighted row.
var _sortKey = 'name';
var _sortDir = 1;
var _filter = ''; // Backend id the table is narrowed to; '' shows every backend.
var _capabilities = {}; // { disable: bool }.
// Each map below is keyed by group id or by provider section key.
var _expanded = {}; // Open or closed as the user left it; lives as long as the page.
var _narrowKey = ''; // The filter and search the narrowed groups were opened for.
var _narrowCollapsed = {}; // True when the user closed what a narrowing opened.
var _toggles = {}; // Its header toggle in the last render, to keep focus across renders.

// Which column reads which row field. The numeric fields are the catalogue's
// own (models.json hardware_requirements.<backend>.download_gb / ram_gb and
// parameters.total), projected by the shared catalogue module.
var COLUMNS = [
	{ id: 'current', header: 'model_browser.col_current', sort: 'current', cls: 'col-current' },
	{ id: 'name', header: 'model_browser.col_name', sort: 'name', cls: 'col-name' },
	{
		id: 'disk',
		header: 'model_browser.col_disk',
		sort: 'disk_gb',
		cls: 'col-num',
		field: 'disk_gb'
	},
	{ id: 'ram', header: 'model_browser.col_ram', sort: 'ram_gb', cls: 'col-num', field: 'ram_gb' },
	{
		id: 'params',
		header: 'model_browser.col_params',
		sort: 'params_b',
		cls: 'col-num',
		field: 'params_b'
	},
	{ id: 'status', header: 'model_browser.col_status', sort: 'installed', cls: 'col-status' },
	{ id: 'actions', header: 'model_browser.col_actions', sort: null, cls: 'col-actions' }
];
var NUMERIC_SORT = { disk_gb: true, ram_gb: true, params_b: true };

// =========================================
// =========================================
// ======= 1/ Native Bridge Interface ======
// =========================================
// =========================================

var postBridgeMessage = makeHostBridge('model_browser_bridge');
var _session = null;
var _catalogueOwner = {};
var _modelDrafts = new Map();

/** Posts an action with the optional native operation identity. */
function postModelAction(action) {
	if (_session !== null) action.session = _session;
	postBridgeMessage(action);
}

/**
 * Called by the native backend to populate the table.
 * @param {object} payload - { backend, active, models, backends?, capabilities?, session? }.
 */
function injectModels(payload) {
	if (!payload || !Array.isArray(payload.models)) return;
	var session = null;
	if (Object.prototype.hasOwnProperty.call(payload, 'session')) {
		if (!Number.isSafeInteger(payload.session) || payload.session <= 0) {
			throw new TypeError('Model browser session must be a positive safe integer');
		}
		session = payload.session;
	}
	if (session === null || _session !== session) _modelDrafts = new Map();
	_session = session;
	_catalogueOwner = {};
	_models = payload.models;
	_backend = payload.backend || '';
	_active = payload.active || '';
	_backends = Array.isArray(payload.backends) ? payload.backends : [];
	_backends.forEach(checkBrand);
	_capabilities =
		payload.capabilities && typeof payload.capabilities === 'object' ? payload.capabilities : {};
	if (_filter && !backendById(_filter)) _filter = '';
	_selected = null;
	buildFilter();
	updateFooter();
	render();
}

/**
 * Called by the native backend while a download of one row reports progress
 * (Ollama pull and Hugging Face download progress, read by each driver's own
 * progress source). The row shows the percentage until the next payload.
 * @param {object} update - { backend, name, percent }; percent in [0, 100], or null when unknown.
 */
function injectProgress(update) {
	if (!update || typeof update.name !== 'string') return;
	var row = null;
	for (var i = 0; i < _models.length; i++) {
		var m = _models[i];
		if (m.name === update.name && (m.backend || '') === (update.backend || '')) row = m;
	}
	if (!row) return;
	var percent = typeof update.percent === 'number' ? update.percent : NaN;
	row.pending = 'download';
	row.progress = Number.isFinite(percent) ? Math.max(0, Math.min(100, Math.floor(percent))) : null;
	render();
}

/**
 * Called by the native backend while the runtime install of one local backend
 * reports progress. Its group header shows the percentage until the next
 * payload, which carries the outcome (installed and unlocked, or offered again).
 * @param {object} update - { backend, percent }; percent in [0, 100], or null when unknown.
 */
function injectInstallProgress(update) {
	if (!update || typeof update.backend !== 'string') return;
	var b = backendById(update.backend);
	if (!b || !b.install) return;
	var percent = typeof update.percent === 'number' ? update.percent : NaN;
	b.install = {
		state: 'running',
		percent: Number.isFinite(percent) ? Math.max(0, Math.min(100, Math.floor(percent))) : null
	};
	render();
}

// Signal readiness so the native backend can flush its queued injectModels() call.
if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', function () {
		postBridgeMessage('ready');
	});
} else {
	postBridgeMessage('ready');
}

// =====================================
// =====================================
// ======= 2/ i18n Helper ==============
// =====================================
// =====================================

/** The translated string, or the empty string while the locale is loading. */
function _t(key) {
	return (window._i18n_strings && window._i18n_strings[key]) || '';
}

/** Substitutes {name} placeholders of a translated template. */
function _fmt(key, values) {
	return _t(key).replace(/\{(\w+)\}/g, function (all, name) {
		return Object.prototype.hasOwnProperty.call(values, name) ? String(values[name]) : all;
	});
}

var _orig_i18n_apply = window.i18n_apply;
window.i18n_apply = function (strings) {
	if (typeof _orig_i18n_apply === 'function') _orig_i18n_apply(strings);
	buildFilter();
	render();
};

// =====================================
// =====================================
// ======= 3/ Row Model ================
// =====================================
// =====================================

/**
 * The page writes each backend's emoji once, before its brand; a brand that
 * carries the emoji itself (the menu's "<brand> <emoji>" option label) would
 * read "<emoji> <brand> <emoji>", so a driver sending one is refused.
 */
function checkBrand(b) {
	if (b && typeof b.brand === 'string' && b.emoji && b.brand.indexOf(b.emoji) !== -1) {
		throw new TypeError('Backend ' + b.id + ' brand must not carry its emoji');
	}
}

/** Whether a backend runs on this computer; every kind but "remote" does. */
function isLocalBackend(b) {
	return b.kind !== 'remote';
}

/**
 * The backends in display order: the local ones by brand, case-insensitive,
 * then the remote ones in payload order.
 */
function orderedBackends() {
	var name = function (b) {
		return String(b.brand || b.id).toLowerCase();
	};
	var local = _backends.filter(isLocalBackend).sort(function (a, b) {
		return name(a) < name(b) ? -1 : name(a) > name(b) ? 1 : 0;
	});
	return local.concat(
		_backends.filter(function (b) {
			return !isLocalBackend(b);
		})
	);
}

function backendById(id) {
	for (var i = 0; i < _backends.length; i++) if (_backends[i].id === id) return _backends[i];
	return null;
}

/** A row's identity: its backend and its name, since one model exists per backend. */
function rowKey(m) {
	return (m.backend || '') + '\u0000' + (m.name || '');
}

/** Whether the row's backend can run a model right now. Legacy rows carry no backend. */
function backendReady(m) {
	if (!m.backend) return true;
	var b = backendById(m.backend);
	return !b || b.available !== false;
}

function isRemote(m) {
	var b = m.backend ? backendById(m.backend) : null;
	return !!b && b.kind === 'remote';
}

function isCurrent(m) {
	return m.name === _active && (!m.backend || !_backend || m.backend === _backend);
}

/** Whether the row itself can act now: a working backend, no refusal of its own, no download running. */
function rowReady(m) {
	return backendReady(m) && m.available !== false && m.pending !== 'download';
}

/** Only an installed model of a working backend (or a configured API entry) can be made active. */
function isSelectable(m) {
	return rowReady(m) && (m.installed === true || isRemote(m));
}

/** A missing model of a working local backend offers its download instead. */
function isDownloadable(m) {
	return rowReady(m) && !isRemote(m) && m.installed !== true && m.downloadable !== false;
}

function isDeletable(m) {
	return rowReady(m) && !isRemote(m) && m.installed === true && m.deletable !== false;
}

function findRow(key) {
	for (var i = 0; i < _models.length; i++) {
		if (rowKey(_models[i]) === key) return _models[i];
	}
	// Legacy callers name the row only; they mean the active backend's model.
	for (var j = 0; j < _models.length; j++) {
		if (_models[j].name === key) return _models[j];
	}
	return null;
}

/**
 * Whether an identifier typed to add a model is well formed for its backend:
 * an Ollama name ("qwen3:4b", "hf.co/owner/repo:Q4_K_M") or an MLX Hugging Face
 * repository id ("mlx-community/Qwen3-4B-4bit"). The native side checks again
 * with _shared/lua/llm/model_identifier.lua or its AHK twin; all three pass
 * _shared/tests/corpus/llm/model_identifiers.json.
 */
// The add-model texts of each backend that can add a model, named literally so
// the translation audit sees every key this page shows.
var ADD_MODEL_TEXT_KEYS = {
	ollama: {
		placeholder: 'model_browser.add_model_placeholder_ollama',
		invalid: 'model_browser.invalid_identifier_ollama'
	},
	mlx: {
		placeholder: 'model_browser.add_model_placeholder_mlx',
		invalid: 'model_browser.invalid_identifier_mlx'
	}
};

function validModelIdentifier(backend, id) {
	if (typeof id !== 'string' || id === '' || id.length > 200) return false;
	var lower = /^[a-z0-9][a-z0-9._-]*$/;
	var any = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
	if (backend === 'ollama') {
		var fields = id.split(':');
		if (fields.length > 2) return false;
		if (fields.length === 2 && !any.test(fields[1])) return false;
		var segments = fields[0].split('/');
		if (segments.length > 3) return false;
		for (var i = 0; i < segments.length; i++) {
			if (!(i === 0 ? lower : any).test(segments[i])) return false;
		}
		return true;
	}
	if (backend === 'mlx') {
		var parts = id.split('/');
		return parts.length === 2 && any.test(parts[0]) && any.test(parts[1]);
	}
	return false;
}

// =====================================
// =====================================
// ======= 4/ Formatting Helpers =======
// =====================================
// =====================================

function _num(v) {
	var n = parseFloat(v);
	return isNaN(n) ? 0 : n;
}

/** Drops a trailing ".0" / ".00" so "8.00" → "8" but "4.22" stays. */
function _trim(n) {
	return parseFloat(n.toFixed(2)).toString();
}

function fmtGb(value) {
	var n = _num(value);
	return n > 0 ? _fmt('model_browser.unit_gb', { n: _trim(n) }) : '—';
}

/** Formats a billions-of-parameters value, collapsing MoE active/total. */
function fmtParams(row) {
	var total = _num(row.params_b);
	var active = _num(row.active_b);
	if (row.is_moe && active > 0 && active < total) {
		return _fmt('model_browser.unit_params_moe', { active: _trim(active), total: _trim(total) });
	}
	return total > 0 ? _fmt('model_browser.unit_params', { n: _trim(total) }) : '—';
}

function _escHtml(s) {
	return String(s)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;');
}

function backendHeading(b) {
	var kind = _t(b.kind === 'remote' ? 'model_browser.kind_remote' : 'model_browser.kind_local');
	return (b.emoji ? b.emoji + ' ' : '') + (b.brand || b.id) + (kind ? ' — ' + kind : '');
}

// =====================================
// =====================================
// ======= 5/ Rendering ================
// =====================================
// =====================================

function buildHead() {
	var head = document.getElementById('head-row');
	if (!head) return;
	head.innerHTML = COLUMNS.map(function (c) {
		var sorted =
			c.sort && c.sort === _sortKey ? (_sortDir === 1 ? 'ascending' : 'descending') : 'none';
		return (
			'<th scope="col" class="' +
			c.cls +
			'"' +
			(c.sort ? ' data-sort="' + c.sort + '" tabindex="0" aria-sort="' + sorted + '"' : '') +
			'>' +
			_escHtml(_t(c.header)) +
			'</th>'
		);
	}).join('');
	if (typeof head.querySelectorAll !== 'function') return;
	head.querySelectorAll('th[data-sort]').forEach(function (th) {
		th.onclick = function () {
			setSort(th.getAttribute('data-sort'));
		};
		th.onkeydown = function (ev) {
			if (ev.key === 'Enter' || ev.key === ' ') {
				ev.preventDefault();
				setSort(th.getAttribute('data-sort'));
			}
		};
	});
}

function buildFilter() {
	var select = document.getElementById('backend-filter');
	if (!select) return;
	var option = function (b) {
		return (
			'<option value="' +
			_escHtml(b.id) +
			'"' +
			(b.id === _filter ? ' selected' : '') +
			'>' +
			_escHtml((b.emoji ? b.emoji + ' ' : '') + (b.brand || b.id)) +
			'</option>'
		);
	};
	var ordered = orderedBackends();
	var local = ordered.filter(isLocalBackend);
	var remote = ordered.filter(function (b) {
		return !isLocalBackend(b);
	});
	var html = '<option value="">' + _escHtml(_t('model_browser.filter_all')) + '</option>';
	if (local.length && remote.length) {
		// The table's split: an optgroup draws its own separator in WebKit
		// (macOS, Linux) and WebView2 (Windows) alike.
		html +=
			'<optgroup label="' +
			_escHtml(_t('model_browser.kind_local')) +
			'">' +
			local.map(option).join('') +
			'</optgroup><optgroup label="' +
			_escHtml(_t('model_browser.kind_remote')) +
			'">' +
			remote.map(option).join('') +
			'</optgroup>';
	} else {
		html += ordered.map(option).join('');
	}
	select.innerHTML = html;
	select.value = _filter;
	if ('hidden' in select) select.hidden = _backends.length < 2;
	var label = document.getElementById('backend-filter-label');
	if (label && 'hidden' in label) label.hidden = _backends.length < 2;
}

function matches(m, query) {
	if (_filter && m.backend && m.backend !== _filter) return false;
	if (!query) return true;
	return (
		(m.name || '').toLowerCase().indexOf(query) !== -1 ||
		(m.family || '').toLowerCase().indexOf(query) !== -1 ||
		(m.provider || '').toLowerCase().indexOf(query) !== -1
	);
}

function compareRows(a, b) {
	var va, vb;
	if (_sortKey === 'current') {
		va = isCurrent(a) ? 1 : 0;
		vb = isCurrent(b) ? 1 : 0;
		return (vb - va) * _sortDir;
	}
	if (_sortKey === 'installed') return ((b.installed ? 1 : 0) - (a.installed ? 1 : 0)) * _sortDir;
	if (NUMERIC_SORT[_sortKey]) return (_num(a[_sortKey]) - _num(b[_sortKey])) * _sortDir;
	if (_sortKey === 'name') return compareNames(nameSortKey(a), nameSortKey(b)) * _sortDir;
	va = String(a[_sortKey] == null ? '' : a[_sortKey]).toLowerCase();
	vb = String(b[_sortKey] == null ? '' : b[_sortKey]).toLowerCase();
	if (va < vb) return -1 * _sortDir;
	if (va > vb) return 1 * _sortDir;
	return 0;
}

/**
 * What the name sort reads, case-insensitive: the name of a local row; the
 * provider then the model of an API row, so each provider's models stay together.
 */
function nameSortKey(m) {
	var name = String(m.name || '');
	if (!isRemote(m)) return [name.toLowerCase(), ''];
	var slash = name.indexOf('/');
	var provider = m.provider || (slash === -1 ? name : name.slice(0, slash));
	var model = m.model || (slash === -1 ? '' : name.slice(slash + 1));
	return [
		String(provider).toLowerCase(),
		String(model).toLowerCase() + '\u0000' + name.toLowerCase()
	];
}

function compareNames(ka, kb) {
	for (var i = 0; i < ka.length; i++) {
		if (ka[i] < kb[i]) return -1;
		if (ka[i] > kb[i]) return 1;
	}
	return 0;
}

/** The groups the table draws: one per backend in display order, then legacy rows. */
function groupRows(rows, query) {
	var groups = [];
	var byId = {};
	orderedBackends().forEach(function (b) {
		byId[b.id] = { backend: b, rows: [] };
		groups.push(byId[b.id]);
	});
	var loose = { backend: null, rows: [] };
	rows.forEach(function (m) {
		var g = m.backend && byId[m.backend];
		(g || loose).rows.push(m);
	});
	if (loose.rows.length) groups.push(loose);
	return groups.filter(function (g) {
		if (g.rows.length > 0) return true;
		// An empty backend still shows its tools (add a model, add a provider)
		// unless a search or another backend's filter narrows the table.
		return !!g.backend && !query && (!_filter || _filter === g.backend.id) && hasTools(g.backend);
	});
}

function hasTools(b) {
	return (
		(Array.isArray(b.actions) && b.actions.length > 0) ||
		!!b.add_model ||
		(Array.isArray(b.providers) && b.providers.length > 0)
	);
}

/** Applies the filters and the active sort, then rebuilds every group. */
function render() {
	var active = document.activeElement;
	var editing =
		active && active._modelDraftOwner === _catalogueOwner
			? {
					backend: active._modelDraftBackend,
					start: active.selectionStart,
					end: active.selectionEnd,
					direction: active.selectionDirection
				}
			: null;
	var table = document.getElementById('models');
	var empty = document.getElementById('empty');
	if (!table) return;
	buildHead();
	var search = document.getElementById('search');
	var query = ((search && search.value) || '').trim().toLowerCase();
	var rows = _models.filter(function (m) {
		return matches(m, query);
	});
	rows.sort(compareRows);

	if (typeof table.querySelectorAll === 'function') {
		table.querySelectorAll('tbody').forEach(function (tb) {
			table.removeChild(tb);
		});
	}
	var narrowed = !!(_filter || query);
	var narrowKey = narrowed ? _filter + '\u0000' + query : '';
	if (narrowKey !== _narrowKey) {
		_narrowKey = narrowKey;
		_narrowCollapsed = {};
	}
	_toggles = {};
	var sawLocal = false;
	groupRows(rows, query).forEach(function (g) {
		if (g.backend && !isLocalBackend(g.backend) && sawLocal) {
			table.appendChild(buildSeparator());
			sawLocal = false;
		}
		if (g.backend && isLocalBackend(g.backend)) sawLocal = true;
		var tbody = document.createElement('tbody');
		var expanded = true;
		if (g.backend) {
			expanded = groupExpanded(g, narrowed);
			tbody.setAttribute('data-group', g.backend.id);
			tbody.appendChild(buildGroupHead(g.backend, g.rows, expanded, narrowed));
		}
		if (expanded) appendGroupRows(tbody, g, !!query);
		table.appendChild(tbody);
	});

	if (editing && typeof table.querySelectorAll === 'function') {
		table.querySelectorAll('input.add-input').forEach(function (input) {
			if (input._modelDraftBackend !== editing.backend) return;
			input.focus();
			if (
				typeof input.setSelectionRange === 'function' &&
				editing.start !== null &&
				editing.end !== null
			)
				input.setSelectionRange(editing.start, editing.end, editing.direction);
		});
	}
	if (empty) empty.style.display = rows.length === 0 ? 'block' : 'none';
	updateCount(rows.length, _models.length);
	updateCurrent();
}

/**
 * Whether a group shows its rows. A filter or a search opens every group it
 * matches in, unless the user closes it again under that same narrowing;
 * otherwise a group is open only while the user keeps it open.
 */
function groupExpanded(g, narrowed) {
	var id = g.backend.id;
	if (narrowed && g.rows.length > 0) return _narrowCollapsed[id] !== true;
	return _expanded[id] === true;
}

/**
 * Opens or closes one group or provider section, then gives its toggle the
 * focus back.
 * @param {string} id - Group id or section key.
 * @param {boolean} narrowedWithRows - Whether a narrowing opened it.
 * @param {boolean} [open] - Whether it is open now; a section may be open with no record of it.
 */
function toggleGroup(id, narrowedWithRows, open) {
	if (narrowedWithRows) _narrowCollapsed[id] = _narrowCollapsed[id] !== true;
	else _expanded[id] = !(open === undefined ? _expanded[id] === true : open);
	render();
	var toggle = _toggles[id];
	if (toggle && typeof toggle.focus === 'function') toggle.focus();
}

/**
 * A local backend's rows split by catalogue provider, sections in alphabetical
 * order. A row without a provider (the user's own models) stays directly under
 * the backend, and an API group stays flat: its names already start with it.
 * @param {object} g - The group.
 * @returns {object} { loose, sections: [{ key, provider, rows }] }
 */
function splitByProvider(g) {
	if (!g.backend || !isLocalBackend(g.backend)) return { loose: g.rows, sections: [] };
	var loose = [];
	var byProvider = {};
	var sections = [];
	g.rows.forEach(function (m) {
		if (!m.provider) {
			loose.push(m);
			return;
		}
		var key = g.backend.id + '\u0000' + m.provider;
		if (!Object.prototype.hasOwnProperty.call(byProvider, key)) {
			byProvider[key] = { key: key, provider: m.provider, rows: [] };
			sections.push(byProvider[key]);
		}
		byProvider[key].rows.push(m);
	});
	sections.sort(function (a, b) {
		return compareNames([a.provider.toLowerCase()], [b.provider.toLowerCase()]);
	});
	return { loose: loose, sections: sections };
}

/**
 * Whether a provider section shows its rows. A search opens every section it
 * matches in, unless the user closes it under that search; otherwise the
 * user's choice holds, and until they made one only the section of the
 * current or selected model is open.
 */
function sectionExpanded(section, searching) {
	if (searching) return _narrowCollapsed[section.key] !== true;
	if (_expanded[section.key] !== undefined) return _expanded[section.key] === true;
	return section.rows.some(function (m) {
		return isCurrent(m) || rowKey(m) === _selected;
	});
}

/** Draws an open group's rows: those without a provider, then each section. */
function appendGroupRows(tbody, g, searching) {
	var split = splitByProvider(g);
	split.loose.forEach(function (m) {
		tbody.appendChild(buildRow(m));
	});
	split.sections.forEach(function (section) {
		var open = sectionExpanded(section, searching);
		tbody.appendChild(buildSectionHead(g.backend, section, open, searching));
		if (open) {
			section.rows.forEach(function (m) {
				tbody.appendChild(buildRow(m));
			});
		}
	});
}

/**
 * One provider's header inside a backend: the same toggle as a backend's, with
 * its model count and, while collapsed, the current model it holds.
 * @param {object} b - The backend.
 * @param {object} section - { key, provider, rows }.
 * @param {boolean} open - Whether its rows are shown.
 * @param {boolean} searching - Whether a search opened it.
 */
function buildSectionHead(b, section, open, searching) {
	var catalogueOwner = _catalogueOwner;
	var head = document.createElement('tr');
	head.className =
		'group section' + (b.available === false ? ' unavailable' : '') + (open ? ' expanded' : '');
	var th = document.createElement('th');
	th.setAttribute('scope', 'rowgroup');
	th.setAttribute('colspan', String(COLUMNS.length));
	var total = _models.filter(function (m) {
		return m.backend === b.id && m.provider === section.provider;
	}).length;
	var current = open ? null : section.rows.filter(isCurrent)[0];
	var toggle = document.createElement('span');
	toggle.className = 'group-toggle';
	toggle.setAttribute('role', 'button');
	toggle.setAttribute('tabindex', '0');
	toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
	toggle.setAttribute('data-section', section.key);
	toggle.setAttribute('data-nav', 'true');
	toggle.innerHTML =
		'<span class="chevron" aria-hidden="true">▸</span> ' +
		'<span class="group-title">' +
		_escHtml(section.provider) +
		'</span>' +
		' <span class="group-count">' +
		_escHtml(_fmt('model_browser.count_label', { n: section.rows.length, total: total })) +
		'</span>' +
		(current
			? ' <span class="group-active">' +
				_escHtml(_fmt('model_browser.current_label', { model: current.name })) +
				'</span>'
			: '');
	bindHeaderToggle(th, toggle, function () {
		if (_catalogueOwner === catalogueOwner) toggleGroup(section.key, searching, open);
	});
	var activate = toggle.onkeydown;
	toggle.onkeydown = function (ev) {
		if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
			ev.preventDefault();
			moveFocus(toggle, ev.key === 'ArrowDown' ? 1 : -1);
			return;
		}
		activate(ev);
	};
	_toggles[section.key] = toggle;
	th.appendChild(toggle);
	head.appendChild(th);
	return head;
}

/** The thin line between the local backends and the remote ones. */
function buildSeparator() {
	var tbody = document.createElement('tbody');
	tbody.className = 'group-separator';
	tbody.setAttribute('aria-hidden', 'true');
	var tr = document.createElement('tr');
	var td = document.createElement('td');
	td.setAttribute('colspan', String(COLUMNS.length));
	tr.appendChild(td);
	tbody.appendChild(tr);
	return tbody;
}

/** The active model when it belongs to this backend, for its collapsed header. */
function activeIn(b) {
	for (var i = 0; i < _models.length; i++) {
		if (_models[i].backend === b.id && isCurrent(_models[i])) return _models[i];
	}
	return null;
}

// The install states a local backend's payload names (b.install.state).
var INSTALL_STATES = {
	available: true,
	installed: true,
	unsupported: true,
	checking: true,
	running: true
};

/**
 * The "Install <backend>" button of a local backend's header. It acts only
 * while the runtime is missing (or its last install failed). Installed,
 * unsupported on this machine, checking and running grey it, and its caption
 * or the header's reason says why: a tooltip alone must not be the only answer
 * to a click on a greyed button. The click runs the driver's own owned-runtime
 * install (group action "install"), whose progress and outcome come back
 * through the payload; a refusal comes back as install.failed_key.
 */
function buildInstallButton(b, catalogueOwner) {
	var install = b.install;
	if (!INSTALL_STATES[install.state]) throw new Error('Unknown install state for backend ' + b.id);
	var btn = document.createElement('button');
	btn.type = 'button';
	btn.className = 'act install';
	var brand = b.brand || b.id;
	if (install.state === 'running') {
		btn.textContent =
			typeof install.percent === 'number'
				? _fmt('model_browser.install_running_percent', { name: brand, n: install.percent })
				: _fmt('model_browser.install_running', { name: brand });
	} else if (install.state === 'installed') {
		btn.textContent = _t('model_browser.install_installed');
	} else if (install.state === 'checking') {
		btn.textContent = _fmt('model_browser.install_checking', { name: brand });
	} else {
		btn.textContent = _t('model_browser.install_runtime').replace('%s', brand);
	}
	btn.disabled = install.state !== 'available';
	var reasonKey =
		install.state === 'installed'
			? 'model_browser.install_installed'
			: install.state === 'unsupported'
				? install.reason_key
				: '';
	if (reasonKey) {
		btn.title = _fmt(reasonKey, { name: brand });
		btn.setAttribute('aria-description', btn.title);
	}
	btn.onclick = function () {
		if (_catalogueOwner !== catalogueOwner || btn.disabled) return;
		b.install = { state: 'running', percent: null };
		render();
		postModelAction({ action: 'group_action', backend: b.id, id: 'install' });
	};
	return btn;
}

/** The words next to an install button: why it refuses or why it did not start. */
function installNote(text) {
	var note = document.createElement('span');
	note.className = 'install-note';
	note.setAttribute('role', 'alert');
	note.textContent = text;
	return note;
}

/**
 * One backend's header. Its first line is the toggle that shows or hides its
 * rows (chevron, emoji and name, model count, the active model while
 * collapsed); the next holds the install, the driver's own actions (port,
 * token…) and why the backend cannot run now; the last adds a model by
 * identifier or an API by provider. A click anywhere on the header toggles,
 * except on a real control.
 * @param {object} b - The backend.
 * @param {Array} rows - Its rows the filters keep.
 * @param {boolean} expanded - Whether its rows are shown.
 * @param {boolean} narrowed - Whether a filter or a search narrows the table.
 */
function buildGroupHead(b, rows, expanded, narrowed) {
	var catalogueOwner = _catalogueOwner;
	var head = document.createElement('tr');
	head.className =
		'group' + (b.available === false ? ' unavailable' : '') + (expanded ? ' expanded' : '');
	var th = document.createElement('th');
	th.setAttribute('scope', 'rowgroup');
	th.setAttribute('colspan', String(COLUMNS.length));
	var reason = b.available === false && b.reason_key ? _t(b.reason_key) : '';
	var total = _models.filter(function (m) {
		return m.backend === b.id;
	}).length;
	var active = expanded ? null : activeIn(b);
	var toggle = document.createElement('span');
	toggle.className = 'group-toggle';
	toggle.setAttribute('role', 'button');
	toggle.setAttribute('tabindex', '0');
	toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
	toggle.setAttribute('data-group', b.id);
	toggle.innerHTML =
		'<span class="chevron" aria-hidden="true">▸</span> ' +
		'<span class="group-title">' +
		_escHtml(backendHeading(b)) +
		'</span>' +
		' <span class="group-count">' +
		_escHtml(_fmt('model_browser.count_label', { n: rows.length, total: total })) +
		'</span>' +
		(active
			? ' <span class="group-active">' +
				_escHtml(_fmt('model_browser.current_label', { model: active.name })) +
				'</span>'
			: '');
	var narrowedWithRows = narrowed && rows.length > 0;
	var toggleHere = function () {
		if (_catalogueOwner === catalogueOwner) toggleGroup(b.id, narrowedWithRows);
	};
	bindHeaderToggle(th, toggle, toggleHere);
	_toggles[b.id] = toggle;
	th.appendChild(toggle);
	var tools = document.createElement('div');
	tools.className = 'group-tools';
	var adders = document.createElement('div');
	adders.className = 'group-add';

	if (b.install) {
		tools.appendChild(buildInstallButton(b, catalogueOwner));
		if (b.install.state === 'unsupported' && b.install.reason_key !== b.reason_key) {
			tools.appendChild(installNote(_fmt(b.install.reason_key, { name: b.brand || b.id })));
		}
		if (b.install.failed_key) {
			tools.appendChild(installNote(_fmt(b.install.failed_key, { name: b.brand || b.id })));
		}
	}

	(Array.isArray(b.actions) ? b.actions : []).forEach(function (a) {
		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'act';
		btn.textContent = a.text || '';
		btn.disabled = a.disabled === true;
		btn.onclick = function () {
			if (_catalogueOwner !== catalogueOwner || a.disabled === true) return;
			postModelAction({ action: 'group_action', backend: b.id, id: a.id });
		};
		tools.appendChild(btn);
	});

	if (reason) {
		var status = document.createElement('span');
		status.className = 'reason';
		status.textContent = reason;
		tools.appendChild(status);
	}

	if (b.add_model && b.available !== false) {
		var texts = ADD_MODEL_TEXT_KEYS[b.id];
		if (!texts) throw new Error('No add-model text for backend ' + b.id);
		var input = document.createElement('input');
		input.type = 'text';
		input.className = 'add-input';
		input._modelDraftOwner = catalogueOwner;
		input._modelDraftBackend = b.id;
		input.value = _modelDrafts.get(b.id) || '';
		input.addEventListener('input', function () {
			if (_catalogueOwner === catalogueOwner) _modelDrafts.set(b.id, input.value);
		});
		input.setAttribute('spellcheck', 'false');
		input.setAttribute('autocomplete', 'off');
		var hint = _t(texts.placeholder);
		input.setAttribute('placeholder', hint);
		input.setAttribute('aria-label', hint);
		var addBtn = document.createElement('button');
		addBtn.type = 'button';
		addBtn.className = 'act';
		addBtn.textContent = _t('model_browser.add_model_button');
		var error = document.createElement('span');
		error.className = 'add-error';
		error.setAttribute('role', 'alert');
		var submit = function () {
			if (_catalogueOwner !== catalogueOwner) return;
			var name = String(input.value || '').trim();
			if (!validModelIdentifier(b.id, name)) {
				error.textContent = _t(texts.invalid);
				input.setAttribute('aria-invalid', 'true');
				return;
			}
			error.textContent = '';
			input.setAttribute('aria-invalid', 'false');
			postModelAction({ action: 'add_model', backend: b.id, name: name });
		};
		addBtn.onclick = submit;
		input.onkeydown = function (ev) {
			if (ev.key === 'Enter') {
				ev.preventDefault();
				submit();
			}
		};
		adders.appendChild(input);
		adders.appendChild(addBtn);
		adders.appendChild(error);
	}

	if (Array.isArray(b.providers) && b.providers.length > 0) {
		var select = document.createElement('select');
		select.className = 'provider-select';
		select.setAttribute('aria-label', _t('model_browser.add_provider_label'));
		select.innerHTML = b.providers
			.map(function (p) {
				return '<option value="' + _escHtml(p.id) + '">' + _escHtml(p.label || p.id) + '</option>';
			})
			.join('');
		select.value = b.providers[0].id;
		var providerBtn = document.createElement('button');
		providerBtn.type = 'button';
		providerBtn.className = 'act';
		providerBtn.textContent = _t('model_browser.add_provider_button');
		providerBtn.onclick = function () {
			if (_catalogueOwner !== catalogueOwner) return;
			var id = select.value || b.providers[0].id;
			postModelAction({ action: 'add_provider', backend: b.id, provider: id });
		};
		adders.appendChild(select);
		adders.appendChild(providerBtn);
	}

	th.appendChild(tools);
	th.appendChild(adders);
	head.appendChild(th);
	return head;
}

// What keeps its own click inside a header; everything else toggles it.
var HEADER_CONTROLS = 'button, input, select, textarea, a, label';

/**
 * Makes a whole header cell toggle: the mouse anywhere but on a real control,
 * Enter or Space on its focusable toggle. The toggle stops its click, which
 * would otherwise reach the cell and toggle twice.
 * @param {object} cell - The header cell.
 * @param {object} toggle - Its focusable toggle.
 * @param {function} run - Opens or closes the header's rows.
 */
function bindHeaderToggle(cell, toggle, run) {
	toggle.onclick = function (ev) {
		if (ev && ev.stopPropagation) ev.stopPropagation();
		run();
	};
	toggle.onkeydown = function (ev) {
		if (ev.key === 'Enter' || ev.key === ' ') {
			ev.preventDefault();
			run();
		}
	};
	cell.onclick = function (ev) {
		var target = ev && ev.target;
		if (target && target.closest && target.closest(HEADER_CONTROLS)) return;
		run();
	};
}

/** The cells of one row, in COLUMNS order. */
function rowCells(m) {
	var current = isCurrent(m);
	var cells = {
		current:
			'<span class="mark' +
			(current ? ' on' : '') +
			'" aria-label="' +
			_escHtml(current ? _t('model_browser.status_current') : '') +
			'">' +
			(current ? '✓' : '') +
			'</span>',
		name:
			'<span class="name-cell">' +
			_escHtml(m.name || '') +
			'</span>' +
			(m.family || m.provider
				? '<span class="sub">' + _escHtml(m.family || m.provider) + '</span>'
				: '') +
			(m.custom
				? ' <span class="chip">' + _escHtml(_t('model_browser.chip_custom')) + '</span>'
				: '') +
			(m.is_default
				? ' <span class="chip default">' + _escHtml(_t('model_browser.chip_default')) + '</span>'
				: '') +
			(m.type === 'completion'
				? ' <span class="chip completion">' +
					_escHtml(_t('model_browser.type_completion')) +
					'</span>'
				: '') +
			(m.hint_key ? '<span class="sub hint">' + _escHtml(_t(m.hint_key)) + '</span>' : ''),
		disk: _escHtml(fmtGb(m.disk_gb)),
		ram: _escHtml(fmtGb(m.ram_gb)),
		params: _escHtml(fmtParams(m)),
		status:
			m.pending === 'download'
				? '<span class="status pending">' +
					_escHtml(
						typeof m.progress === 'number'
							? _fmt('model_browser.status_downloading_percent', { n: m.progress })
							: _t('model_browser.status_downloading')
					) +
					'</span>'
				: m.inventory_unknown === true
					? '<span class="status">' +
						_escHtml(_t('model_browser.inventory_unavailable')) +
						'</span>'
					: isRemote(m)
						? '<span class="status remote">' +
							_escHtml(_t('model_browser.status_remote')) +
							'</span>'
						: '<span class="dot' +
							(m.installed ? ' on' : '') +
							'" aria-hidden="true"></span> ' +
							_escHtml(
								_t(
									m.installed ? 'model_browser.status_installed' : 'model_browser.status_available'
								)
							),
		actions: rowActions(m, current)
	};
	return COLUMNS.map(function (c) {
		var cls =
			c.cls === 'col-num'
				? 'num'
				: c.id === 'current' || c.id === 'status'
					? 'center'
					: c.id === 'actions'
						? 'col-actions'
						: '';
		return '<td class="' + cls + '">' + cells[c.id] + '</td>';
	}).join('');
}

function rowActions(m, current) {
	var html = '';
	if (isSelectable(m) && !current) {
		html +=
			'<button type="button" class="act" data-act="use">' +
			_escHtml(_t('model_browser.use_button')) +
			'</button>';
	}
	if (isDownloadable(m)) {
		html +=
			'<button type="button" class="act" data-act="download">' +
			_escHtml(_t('model_browser.download_button')) +
			'</button>';
	}
	if (m.custom && !isRemote(m)) {
		html +=
			'<button type="button" class="act danger" data-act="remove">' +
			_escHtml(_t('model_browser.remove_button')) +
			'</button>';
	} else if (isDeletable(m)) {
		html +=
			'<button type="button" class="act danger" data-act="delete">' +
			_escHtml(_t('model_browser.delete_button')) +
			'</button>';
	}
	(Array.isArray(m.actions) ? m.actions : []).forEach(function (a, index) {
		if (!backendReady(m) || m.pending === 'download') return;
		html +=
			'<button type="button" class="act" data-act="row" data-index="' +
			index +
			'">' +
			_escHtml(a.text || '') +
			'</button>';
	});
	if (m.url) {
		html +=
			'<button type="button" class="act link" data-act="source" data-url="' +
			_escHtml(m.url) +
			'" title="' +
			_escHtml(_t('model_browser.source_button')) +
			'" aria-label="' +
			_escHtml(_t('model_browser.source_button')) +
			'">↗</button>';
	}
	return html;
}

/** Builds a single <tr> for a model row. */
function buildRow(m) {
	var catalogueOwner = _catalogueOwner;
	var key = rowKey(m);
	var tr = document.createElement('tr');
	var classes = [];
	if (isCurrent(m)) classes.push('active');
	if (!backendReady(m) || m.available === false) classes.push('unavailable');
	else if (!isSelectable(m)) classes.push('missing');
	if (key === _selected) classes.push('selected');
	tr.className = classes.join(' ');
	tr.tabIndex = 0;
	if (typeof tr.setAttribute === 'function') {
		tr.setAttribute('data-key', key);
		tr.setAttribute('data-nav', 'true');
		tr.setAttribute('aria-disabled', isSelectable(m) ? 'false' : 'true');
		tr.setAttribute('aria-selected', key === _selected ? 'true' : 'false');
	}
	tr.innerHTML = rowCells(m);

	tr.onclick = function (ev) {
		if (_catalogueOwner !== catalogueOwner) return;
		var button =
			ev && ev.target && ev.target.closest ? ev.target.closest('button[data-act]') : null;
		if (button) {
			if (ev.stopPropagation) ev.stopPropagation();
			runAction(
				m,
				button.getAttribute('data-act'),
				button.getAttribute('data-url'),
				button.getAttribute('data-index')
			);
			return;
		}
		selectRow(key);
	};
	tr.ondblclick = function () {
		if (_catalogueOwner !== catalogueOwner) return;
		selectRow(key);
		useSelected();
	};
	tr.onkeydown = function (ev) {
		if (_catalogueOwner !== catalogueOwner) return;
		if (ev.target !== tr) return;
		if (ev.key === 'Enter') {
			ev.preventDefault();
			selectRow(key);
			useSelected();
		} else if (ev.key === ' ') {
			ev.preventDefault();
			selectRow(key);
		} else if (ev.key === 'Delete' || ev.key === 'Backspace') {
			ev.preventDefault();
			if (m.custom) runAction(m, 'remove');
			else if (isDeletable(m)) runAction(m, 'delete');
		} else if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
			ev.preventDefault();
			moveFocus(tr, ev.key === 'ArrowDown' ? 1 : -1);
		}
	};
	tr.onfocus = function () {
		if (_catalogueOwner === catalogueOwner) selectRow(key);
	};
	return tr;
}

/**
 * Moves keyboard focus to the next or previous model row or provider header,
 * across groups, so a collapsed section can be reached and opened by keyboard.
 */
function moveFocus(from, step) {
	var stops = Array.prototype.slice.call(document.querySelectorAll('[data-nav]'));
	var next = stops[stops.indexOf(from) + step];
	if (next && typeof next.focus === 'function') next.focus();
}

function selectRow(key) {
	var row = findRow(key);
	_selected = row ? rowKey(row) : null;
	document.querySelectorAll('tr[data-key]').forEach(function (tr) {
		var on = tr.getAttribute('data-key') === _selected;
		tr.classList.toggle('selected', on);
		tr.setAttribute('aria-selected', on ? 'true' : 'false');
	});
	updateFooter();
}

function updateFooter() {
	var row = _selected ? findRow(_selected) : null;
	var useBtn = document.getElementById('btn-use');
	if (useBtn) useBtn.disabled = !row || !isSelectable(row) || isCurrent(row);
	var disableBtn = document.getElementById('btn-disable');
	if (disableBtn && 'hidden' in disableBtn) disableBtn.hidden = _capabilities.disable !== true;
}

function updateCount(shown, total) {
	var el = document.getElementById('count');
	if (el) el.textContent = _fmt('model_browser.count_label', { n: shown, total: total });
}

/** States the active choice above the table, emoji first, as the tray button does. */
function updateCurrent() {
	var el = document.getElementById('current');
	if (!el) return;
	var b = backendById(_backend);
	var name = _active || _t('model_browser.current_none');
	el.textContent = _fmt('model_browser.current_label', {
		model: (b && b.emoji ? b.emoji + ' ' : '') + name
	});
}

// =====================================
// =====================================
// ======= 6/ Actions ==================
// =====================================
// =====================================

/** Posts one row action; the native side validates it against its own catalogue. */
function postRowAction(action, m) {
	var message = { action: action, name: m.name };
	if (m.backend) message.backend = m.backend;
	postModelAction(message);
}

function runAction(m, act, url, index) {
	if (act === 'row') {
		var a = Array.isArray(m.actions) ? m.actions[Number(index)] : null;
		if (!a || !backendReady(m) || m.pending === 'download') return;
		var message = { action: 'row_action', id: a.id, name: m.name };
		if (m.backend) message.backend = m.backend;
		postModelAction(message);
		return;
	}
	if (act === 'use') {
		if (isSelectable(m)) postRowAction('select_model', m);
	} else if (act === 'download') {
		if (isDownloadable(m)) postRowAction('download_model', m);
	} else if (act === 'delete') {
		if (isDeletable(m)) postRowAction('delete_model', m);
	} else if (act === 'remove') {
		if (m.custom) postRowAction('remove_custom_model', m);
	} else if (act === 'source') {
		postModelAction({ action: 'open_url', url: url || m.url });
	}
}

/** Sends the highlighted model back to the native backend to activate it. */
function useSelected() {
	var row = _selected ? findRow(_selected) : null;
	if (!row || !isSelectable(row)) return;
	postRowAction('select_model', row);
}

function setSort(key) {
	if (!key) return;
	if (_sortKey === key) {
		_sortDir = -_sortDir;
	} else {
		_sortKey = key;
		_sortDir = 1;
	}
	render();
}

// =====================================
// =====================================
// ======= 7/ Initialisation ===========
// =====================================
// =====================================

(function init() {
	var search = document.getElementById('search');
	if (search) search.addEventListener('input', render);

	var filter = document.getElementById('backend-filter');
	if (filter)
		filter.addEventListener('change', function () {
			_filter = filter.value || '';
			render();
		});

	var useBtn = document.getElementById('btn-use');
	if (useBtn) useBtn.addEventListener('click', useSelected);
	var disableBtn = document.getElementById('btn-disable');
	if (disableBtn)
		disableBtn.addEventListener('click', function () {
			if (_capabilities.disable === true) postModelAction({ action: 'disable_model' });
		});

	updateFooter();
	if (window._i18n_strings) render();
})();
