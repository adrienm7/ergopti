#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
p=root/'static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk'
assert p.read_bytes()==(out/'control-result-kind-pre-test.ahk').read_bytes()+(out/'control-result-kind-regression.ahk').read_bytes()
CHECK
git cherry-pick --no-commit 47a8fe3fc3bfb62b89eaad958a2aba2c2f25c41c
python3 - <<'CHECK'
from pathlib import Path
import subprocess,json
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','47a8fe3fc3bfb62b89eaad958a2aba2c2f25c41c'],text=True).splitlines()
assert len(paths)==4
assert set(paths)==set(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines())
for p in paths:
 assert (root/p).read_bytes()==subprocess.check_output(['git','show','47a8fe3fc3bfb62b89eaad958a2aba2c2f25c41c:'+p]),p
(out/'result-kind-dependency-source-identity.json').write_text(json.dumps({'original_atomic_commit':'47a8fe3fc3bfb62b89eaad958a2aba2c2f25c41c','all_four_paths_identical':paths,'qualified_targeted_native_cases':57,'qualification':'Original delivery actual qualified receipts; full E2E/JSON native PowerShell prerequisite remains unqualified under Wine.'},indent=2)+'\n')
CHECK
npm run test:ahk-encoding
npm run test:ahk-loop-capture
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
git commit -C 47a8fe3fc3bfb62b89eaad958a2aba2c2f25c41c
python3 - <<'CHECK'
from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
prod=root/'static/ergopti_plus/windows/infra/driver_control.ahk'
assert prod.read_bytes()==(out/'control-result-kind-old-production.ahk').read_bytes()
p=root/'static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk'
assert p.read_bytes()==(out/'control-result-kind-pre-test.ahk').read_bytes()+(out/'control-result-kind-regression.ahk').read_bytes()
prod.write_bytes((out/'control-result-kind-candidate.ahk').read_bytes())
(out/'control-result-kind-candidate-hashes.json').write_text(json.dumps({str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [p,prod]},indent=2)+'\n')
print('DEPENDENCY_LOCAL_COMMIT',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
CHECK
exec env WINEPREFIX=/workspace/toolchain/wine-r3-metrics-owned WINEPATH='Z:\workspace\toolchain\node-v22.22.2-win-x64' timeout --kill-after=5s 300s xvfb-run -a bash tools/test/run-ahk-under-wine.sh --ahk /workspace/toolchain/ahk/AutoHotkey64.exe --runner run_all.ahk --results /workspace/scratch/windows-audit-round6/verification-worker/328-lifecycle-result-kind-green51.tap -- --only driver-control:
