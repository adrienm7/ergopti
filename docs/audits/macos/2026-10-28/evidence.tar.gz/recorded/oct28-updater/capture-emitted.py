import os,subprocess,json,hashlib,importlib.util,sys
from pathlib import Path
w=Path('/workspace/ergopti-macos-cloner-i18n');driver=w/'static/ergopti_plus/macos';fixture=driver/'tests/support/modules/updater/release_arming_fixture.py';spec=importlib.util.spec_from_file_location('arming',fixture);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);e=dict(os.environ,USER='agent',LOGNAME='agent');e['PATH']='/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:'+e['PATH'];e['LUA']='/workspace/toolchain/bin/lua'
r=subprocess.run([e['LUA'],'-',str(driver),str(w/'static/ergopti_plus/_shared'),'/fixture/ErgoptiPlus.app','/fixture/stage/app/ErgoptiPlus.app','999999999',''],input=m.CAPTURE,text=True,capture_output=True,env=e,check=True);x=json.loads(r.stdout);assert x['executable']=='/bin/sh' and x['args'][0]=='-c';out=Path(sys.argv[1]);out.mkdir();(out/'capture.json').write_text(json.dumps(x,indent=2)+'\n');
for label,value in [('SWAP',x['args'][3]),('DETACH',x['args'][1])]:
 (out/(label+'.sh')).write_text(value);print(label,hashlib.sha256(value.encode()).hexdigest())
