# static/ergopti_plus/windows/platform/native/CMakeLists.txt
# MODULE: Ergopti navigation event owner native build.
# DESCRIPTION: Builds the x64 Win32 DLL and deterministic state-machine test.

cmake_minimum_required(VERSION 3.20)

project(ergopti_nav_owner LANGUAGES C)

if(NOT WIN32)
	message(FATAL_ERROR "ergopti_nav_owner requires Win32")
endif()

if(NOT CMAKE_SIZEOF_VOID_P EQUAL 8)
	message(FATAL_ERROR "ergopti_nav_owner supports x64 only")
endif()

add_library(ergopti_nav_owner SHARED
	nav_event_owner.c
	replay_route_core.c
	terminal_output_plan.c
	hook_trace.c
	editor_replace.c
	nav_event_owner.def
)

target_compile_features(ergopti_nav_owner PRIVATE c_std_11)
target_link_libraries(ergopti_nav_owner PRIVATE user32)

add_executable(ergopti_nav_event_owner_test
	nav_event_owner_test.c
	editor_replace_test.c
	nav_event_owner.c
	replay_route_core.c
	terminal_output_plan.c
	hook_trace.c
	editor_replace.c
)

target_compile_features(ergopti_nav_event_owner_test PRIVATE c_std_11)
target_compile_definitions(ergopti_nav_event_owner_test PRIVATE
	ERGOPTI_NAV_TESTING=1)
target_link_libraries(ergopti_nav_event_owner_test PRIVATE user32)

add_executable(ergopti_terminal_capture_owned_test
	terminal_capture_owned_test.c
	editor_replace_test.c
	editor_replace.c
	replay_route_core.c
	terminal_output_plan.c
	hook_trace.c
)
target_compile_features(ergopti_terminal_capture_owned_test PRIVATE c_std_11)
target_compile_definitions(ergopti_terminal_capture_owned_test PRIVATE
	ERGOPTI_NAV_TESTING=1)
target_link_libraries(ergopti_terminal_capture_owned_test PRIVATE user32)

add_executable(ergopti_replay_route_core_test
	replay_route_core.c
	replay_route_core_test.c
)
target_compile_features(ergopti_replay_route_core_test PRIVATE c_std_11)

add_executable(ergopti_terminal_output_plan_test
	replay_route_core.c
	terminal_output_plan.c
	terminal_output_plan_test.c
)
target_compile_features(ergopti_terminal_output_plan_test PRIVATE c_std_11)

add_executable(ergopti_hook_trace_test
	hook_trace.c
	hook_trace_test.c
)
target_compile_features(ergopti_hook_trace_test PRIVATE c_std_11)

if(MSVC)
	set_property(TARGET ergopti_terminal_capture_owned_test PROPERTY
		MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
	target_compile_options(ergopti_terminal_capture_owned_test PRIVATE /W4 /WX /wd5105)
	set_property(TARGET ergopti_nav_owner PROPERTY
		MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
	set_property(TARGET ergopti_nav_event_owner_test PROPERTY
		MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
	# VS 2019 16.11 diagnoses SDK 10.0.19041's own macro expansion as C5105.
	# Keep warnings fatal while suppressing only that external-header warning.
	set_property(TARGET ergopti_replay_route_core_test PROPERTY
		MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
	target_compile_options(ergopti_replay_route_core_test PRIVATE /W4 /WX /wd5105)
	set_property(TARGET ergopti_terminal_output_plan_test PROPERTY
		MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
	target_compile_options(ergopti_terminal_output_plan_test PRIVATE /W4 /WX /wd5105)
	set_property(TARGET ergopti_hook_trace_test PROPERTY
		MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
	target_compile_options(ergopti_hook_trace_test PRIVATE /W4 /WX /wd5105)
	target_compile_options(ergopti_nav_owner PRIVATE /W4 /WX /wd5105)
	target_compile_options(ergopti_nav_event_owner_test PRIVATE /W4 /WX /wd5105)
endif()

include(CTest)
if(BUILD_TESTING)
	add_test(NAME ergopti_terminal_capture_owned_test
		COMMAND ergopti_terminal_capture_owned_test)
	add_test(NAME ergopti_hook_trace_test COMMAND ergopti_hook_trace_test)
	add_test(NAME ergopti_terminal_output_plan_test
		COMMAND ergopti_terminal_output_plan_test)
	add_test(NAME ergopti_replay_route_core_test
		COMMAND ergopti_replay_route_core_test)
	add_test(NAME ergopti_nav_event_owner_test
		COMMAND ergopti_nav_event_owner_test)
endif()
