"""Serial focused portable receiver; never canonical refs or native qualification."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,tempfile
BASE=Path(__file__).resolve().parent
facts=json.loads((BASE/'runtime-source-inventory.json').read_text())['files']
for relative,pin in facts.items():
    source=BASE/'runtime-source'/relative
    assert source.stat().st_size==pin['bytes']
    assert hashlib.sha256(source.read_bytes()).hexdigest()==pin['sha256']
subprocess.run([sys.executable,'-I','-B',str(BASE/'prove_source.py')],check=True)
work=Path(tempfile.mkdtemp(prefix='passive-receive-',dir=BASE));receipts=[]

def namespace(name,mutate=None):
    root=work/name/'source';root.parent.mkdir();shutil.copytree(BASE/'runtime-source',root)
    if mutate is not None:mutate(root)
    options={'cwd':root,'stdout':subprocess.DEVNULL,'stderr':subprocess.PIPE,'check':True}
    for args in (['init','-q'],['config','user.name','Portable receiving'],['config','user.email','portable@example.invalid'],['add','--all'],['commit','-qm','Isolated passive receiving inputs']):
        subprocess.run(['git','-c','core.hooksPath=/dev/null',*args],**options)
    private=root.parent/'private-tmp';private.mkdir(mode=0o700)
    return root,private

def receive(name,command,root,private,expected,red=False):
    environment=os.environ.copy();environment['TMPDIR']=str(private)
    environment['NODE_PATH']='/workspace/ergopti/node_modules'
    stdout=root.parent/(name+'.stdout');stderr=root.parent/(name+'.stderr')
    with stdout.open('wb') as out,stderr.open('wb') as err:
        result=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err,timeout=180)
    raw=stderr.read_text();out=stdout.read_text()
    record={'name':name,'exit':result.returncode,'stdout_sha256':hashlib.sha256(stdout.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(stderr.read_bytes()).hexdigest(),'qualification':'PORTABLE_ONLY_NATIVE_MODELED','expected':expected,'red':red}
    if command[0]==sys.executable:
        count=re.search(r'Ran (\d+) tests?',raw);assert count,(name,str(root.parent))
        assert int(count[1])==expected,(name,count[1],expected)
        summary=re.search(r'FAILED \(([^)]+)\)',raw)
        numbers={key:int(value) for key,value in re.findall(r'(failures|errors|skipped)=(\d+)',summary[1] if summary else '')}
        record.update({'tests':expected,'failures':numbers.get('failures',0),'errors':numbers.get('errors',0),'skips':numbers.get('skipped',0)})
        if red:assert result.returncode!=0 and record['failures']>0 and record['errors']==0 and record['skips']==0,(name,record,str(root.parent))
        else:assert result.returncode==0 and '\nOK\n' in raw and not summary,(name,str(root.parent))
    elif red:assert result.returncode!=0 and 'AssertionError' in raw and 'MODULE_NOT_FOUND' not in raw,(name,str(root.parent))
    else:assert result.returncode==0 and f'CLOCK_RECEIVER controls={expected} native=false official=false' in out,(name,str(root.parent))
    receipts.append(record);(work/'receipts.json').write_text(json.dumps({'state':'PORTABLE_ONLY_NO_NATIVE_OR_API_CREDIT','receipts':receipts},indent=2)+'\n')
    print(json.dumps(record,sort_keys=True),flush=True)

node=shutil.which('node');assert node
workflow='.github/workflows/ci-macos.yml'
original_workflow=(BASE/'preimage'/workflow).read_bytes()
root,private=namespace('canonical_old_workflow')
assert (root/workflow).read_bytes()==original_workflow
receive('canonical_receiver32',[node,str(root/'tools/test/test-native-http-clock-evidence.cjs')],root,private,32)
assert (root/workflow).read_bytes()==original_workflow
stdout=(root.parent/'canonical_receiver32.stdout').read_text()
names=re.findall(r'^PASS (.*)$',stdout,re.M);assert len(names)==len(set(names))==32

def omitted_proposed_upload(root):
    path=root/'tools/test/fixtures/native_http_clock_workflow.yml'
    source=path.read_text();needle='Retain independent native HTTP clock receiving';assert source.count(needle)==1
    path.write_text(source.replace(needle,'EXPLICIT omitted proposed upload control',1))
root,private=namespace('omitted_proposed_fixture_upload',omitted_proposed_upload)
assert (root/workflow).read_bytes()==original_workflow
receive('omitted_proposed_fixture_upload',[node,str(root/'tools/test/test-native-http-clock-evidence.cjs')],root,private,32,red=True)
assert (root/workflow).read_bytes()==original_workflow
print(json.dumps({'terminal':True,'logs':str(work),'workflow_preimage_unchanged':True,'frozen_proposed_input_only':True,'native_live_wiring_credit':False},sort_keys=True))
