from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path('/workspace/ergopti')
PACKET = Path(__file__).resolve().parent
SOURCE = 'static/ergopti_plus/linux/modules/shortcuts/keyboard_shortcuts.lua'
TEST = 'static/ergopti_plus/linux/tests/unit/modules/shortcuts/test_keyboard_shortcuts.lua'
EXPECTED_SOURCE = 'dc1334e8cc95bc294be7900fbaefa8574a2e8c65378684c91773c25bdda6d2eb'
EXPECTED_TEST = 'd66dde379ab583ba037c0c5c02dc32141d333a4840c387b571cfe53401ea77c3'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def record(path, data):
    target = PACKET / path
    assert not target.exists(), str(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return {'path': str(target), 'bytes': len(data), 'sha256': digest(data)}

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == '7892616a62d6925126d4ff98b4d4818eb387813b', head
original_source = (ROOT / SOURCE).read_bytes()
original_test = (ROOT / TEST).read_bytes()
assert digest(original_source) == EXPECTED_SOURCE
assert digest(original_test) == EXPECTED_TEST
source_text = original_source.decode()
start = source_text.index('\tlocal generation = _dispatch_generation\n', source_text.index('function M.consume('))
end = source_text.index('\t\tLogger.error(LOG, "Keyboard shortcut %s could not be queued', start)
original_span = source_text[start:end]
repair = (PACKET / 'repair-span.lua').read_text()
assert repair.endswith('\tend) ~= true then\n')
candidate_source = (source_text[:start] + repair + source_text[end:]).encode()
assert digest(candidate_source) == '4244f7a56851e445da40727b5517d258128af1311c6f97b231c05e91cefc38f2'

test_text = original_test.decode()
helper_start = test_text.index('\tlocal function with_editor(')
helper_end = test_text.index('\n\thelpers.it(', helper_start)
helper = test_text[helper_start:helper_end]
helper_reference = 'b3b67df955c62b33708fd66465b1d0fd1531592072ad598a2bd9b5f5da2ff9f4'
assert digest(helper.encode()) == helper_reference
additions = ('\n\nhelpers.describe("keyboard shortcuts: late contextual delivery custody", function()\n'
             + helper + '\n' + (PACKET / 'additions-body.lua').read_text()).encode()
candidate_test = original_test + additions
assert candidate_test[:len(original_test)] == original_test
assert source_text[:start].encode() == candidate_source[:len(source_text[:start].encode())]
assert candidate_source.endswith(source_text[end:].encode())
assert additions.count(b'helpers.it(') == 10
assert b'helpers.assert_true(pcall(' not in additions
assert b'local completed, observed_failures, executed_actions = pcall(function()' in additions
assert b'return observed, #state.fired' in additions

files = {}
for name, data in [('original/' + SOURCE, original_source), ('original/' + TEST, original_test),
                   ('candidate/' + SOURCE, candidate_source), ('candidate/' + TEST, candidate_test),
                   ('additions.lua', additions), ('frozen-editor-helper.lua', helper.encode()),
                   ('original-span.lua', original_span.encode())]:
    files[name] = record(name, data)

patch = ''
for path, old, new in [(SOURCE, original_source, candidate_source), (TEST, original_test, candidate_test)]:
    patch += ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                        fromfile='a/' + path, tofile='b/' + path))
files['candidate.patch'] = record('candidate.patch', patch.encode())
check = subprocess.run(['git', 'apply', '--check', str(PACKET / 'candidate.patch')], cwd=ROOT,
                       capture_output=True, text=True)
assert check.returncode == 0, check.stderr
files['patch-check.stdout'] = record('patch-check.stdout', check.stdout.encode())
files['patch-check.stderr'] = record('patch-check.stderr', check.stderr.encode())

mutations = {
    'late-guard-removed': (
        '\t\tfire(hit, hit.physical and function() return physical_current(hit) end\n\t\t\tor hit.decision and contextual_current or nil)',
        '\t\tfire(hit, hit.physical and function() return physical_current(hit) end or nil)'),
    'stale-admission-after-source': (
        'master = live.master, paused = live.paused, inhibited = live.inhibited',
        'master = admission.master, paused = admission.paused, inhibited = admission.inhibited'),
    'post-admission-owner-fence-removed': (
        'if not called or type(admission) ~= "table" or not owner_current() then return false end',
        'if not called or type(admission) ~= "table" then return false end'),
    'post-decision-owner-fence-removed': (
        'if not resolved or type(current) ~= "table" or not owner_current() then return false end',
        'if not resolved or type(current) ~= "table" then return false end'),
    'terminal-owner-fence-removed': (
        'return owner_current() and current.active == true', 'return current.active == true'),
    'issuer-pins-removed': (
        '\t\t\t\t\tand opts.admission == admission_reader and M.magic_editor_decision == decision_reader\n', ''),
    'source-error-escape': (
        'local resolved, current = pcall(decision_reader, admission)',
        'local resolved, current = true, decision_reader(admission)'),
}
causals = {}
for name, (old, new) in mutations.items():
    text = candidate_source.decode()
    assert text.count(old) == 1, name
    data = text.replace(old, new, 1).encode()
    files['mutants/' + name + '.lua'] = record('mutants/' + name + '.lua', data)
    causals[name] = {'source': files['mutants/' + name + '.lua'], 'before': old, 'after': new,
                     'runtime_status': 'UNRUN'}

# Exact current tracked dependency bytes, without copying any repository tree.
# This is a preparation manifest, not an executed-runtime dependency trace.
tracked = subprocess.check_output(['git', 'ls-files', '-z', '--',
    'static/ergopti_plus/linux', 'static/ergopti_plus/_shared/lua',
    'static/ergopti_plus/_shared/data', 'static/ergopti_plus/_shared/modules',
    'static/ergopti_plus/_shared/tests'], cwd=ROOT).split(b'\0')
dependencies = []
for item in tracked:
    if not item:
        continue
    relative = item.decode()
    path = ROOT / relative
    if path.is_file():
        data = path.read_bytes()
        dependencies.append({'path': relative, 'bytes': len(data), 'sha256': digest(data)})
dependency_manifest = json.dumps({'head': head, 'kind': 'current tracked preparation bytes only',
                                 'tree_copy_created': False, 'files': dependencies}, indent=2).encode() + b'\n'
files['dependency-manifest.json'] = record('dependency-manifest.json', dependency_manifest)

receipt = {
    'version': 'fresh recovered V6 proposal', 'head': head, 'canonical_paths': [SOURCE, TEST],
    'original_source_sha256': EXPECTED_SOURCE, 'original_test_sha256': EXPECTED_TEST,
    'candidate_source_sha256': digest(candidate_source), 'candidate_test_sha256': digest(candidate_test),
    'original_test_prefix_byte_exact': True, 'whole_original_prefix_bytes': len(original_test),
    'original_helper_byte_exact': True, 'original_helper_sha256': helper_reference,
    'outside_consume_replacement_byte_exact': True, 'case_count_from_frozen_loop_domains': 20,
    'lexical_it_sites': 10, 'mutant_count': len(causals), 'mutations': causals,
    'git_apply_check': {'exit': check.returncode, 'status': 'PASS'},
    'runtime_status': 'UNRUN: parent canonical Mac selected gate active; no Lua/native/JS execution permitted',
    'old_raw_logs_status': 'LOST: recovered container has no old private packet or unpublished e1c Git object',
    'fresh_runtime_claims': [], 'files': files,
}
record('packet-receipt.json', json.dumps(receipt, indent=2).encode() + b'\n')
print(json.dumps({'head': head, 'source': digest(candidate_source), 'test': digest(candidate_test),
                  'patch': digest(patch.encode()), 'additions': digest(additions),
                  'receipt': digest((PACKET / 'packet-receipt.json').read_bytes()),
                  'dependency_count': len(dependencies), 'runtime': 'UNRUN'}, indent=2))
