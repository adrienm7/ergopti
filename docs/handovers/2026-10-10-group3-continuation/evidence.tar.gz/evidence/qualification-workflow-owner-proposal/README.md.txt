# Private qualification-upload workflow proposal

Status: source-only partial proposal. Shared-workflow ownership is pending; G5 has active workflow receiving. Do not adopt blindly. No canonical source, index, refs, running workflow or test suite was changed.

`qualification-uploads.patch` changes exactly eight newly introduced diagnostic upload conditions to `${{ !cancelled() }}` (Core also retains `matrix.suite == 'js'`) and exactly five required `assets-qualification-*` missing-file policies from `warn` to `error`. Names, paths, actions, wrappers, native commands, conditions on every other step, budgets, failure propagation and step order remain byte-exact. Existing optional diagnostics, including their `always()`/`warn` policies, are preserved. The three macOS wildcard qualification uploads retain `warn` in this compact proposal; their release semantics need separate owner review.

## Linux relocation is blocked by an actual producer dependency

The original guard in `tools/test/test-linux-ci-evidence.cjs:1676` requires every E2E step from `Record mandatory E2E evidence` onward to remain success-only, with no explicit `if`. Both newly added qualification-only uploads currently lie after that boundary. Merely changing their conditions preserves cancellation but does not satisfy that original tail invariant.

Moving the two uploads before Record would fit the existing pre-tail `!cancelled()` policy without moving a native prerequisite. However, when the whole E2E suite is legitimately deferred, Record itself creates `stable-linux-simultaneous-native.json`; the earlier contained native harness does not run in this branch. Moving its mandatory-file upload ahead of this producer would turn that approved deferral into a missing-file failure. No relocation is included. The owner must establish the source-bound simultaneous receipt before the boundary in every admitted path, then separately review relocation of only those two uploads. This proposal does not modify receipt production, qualification admission, the original tail guard, or mandatory native order.

## Coordinated adoption

Root/shared-workflow ownership must be granted and G5 receiving synchronized. Verify all exact preimages in `proposal.json` against the current sources. Coordinate the Linux producer/order fix with its owner before final adoption; retain every original native prerequisite, independent count floor, status, kill/subreaper deadline and mandatory evidence guard. Guard owners must receive these exact upload identities and protocols independently rather than introduce generic conditional allowlists. Names and paths stay unchanged, including the separate Windows naming conflict. Other plan/output, Hammerspoon and audio receiving mismatches are outside this patch.

`proposal.json` supplies complete-file, exact-step and unified-hunk pre/post SHA-256 values, byte-exact unowned-source/order conservation, and the source HEAD. These are source comparison receipts, not executed tests. No claim is made that the nineteen external mismatches, full JS gate, native lanes, packaging, installation or release qualification now pass.
