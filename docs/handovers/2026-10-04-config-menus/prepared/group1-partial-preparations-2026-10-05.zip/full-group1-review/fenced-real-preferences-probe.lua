local root, preference=assert(arg[1]),assert(arg[2])
package.path=root..'/static/ergopti_plus/linux/?.lua;'..root..'/static/ergopti_plus/linux/?/init.lua;'..root..'/static/ergopti_plus/_shared/lua/?.lua;'..root..'/static/ergopti_plus/_shared/lua/?/init.lua;'..package.path
require('compat.utf8').install()
local Preferences=require(preference)
local Transaction=require('config_scope_transaction');local Fenced=require('config_scope_fenced_transaction')
local path, backup=os.tmpname(),os.tmpname();os.remove(backup)
local original='[gestures]\nenabled = true\nswipe_3_down = "copy"\n[future]\nkeep = 73\n'
local function write(file,text)local f=assert(io.open(file,'wb'));assert(f:write(text));assert(f:close())end
local function read(file)local f=io.open(file,'rb');if not f then return nil,'absent' end;local t=assert(f:read('*a'));assert(f:close());return t,'ok' end
write(path,original)
local files={read_with_status=read,write=write,write_if_unchanged=function(file,text,expected)
 local t,s=read(file);if s~=expected.status or(s=='ok' and t~=expected.content)then return false end;write(file,text);return true end}
local runtime={marker='before'}
local primary=Transaction.new({path=path,backup_path=backup,manifest=require('infra.manifest_reader'),files=files,
 capture=function()return {marker=runtime.marker}end,
 apply=function()runtime.marker='after';return true end,
 restore=function(s)runtime.marker=s.marker;return true end})
local token={};local owner=Fenced.new({owner=token,transaction=primary,scope='gestures',available=function()return true end,
 fences={{acquire=Preferences.acquire,release=Preferences.release}}})
local accepted,detail=owner.apply('clear');local pending=owner.pending();local retried=owner.retry_restore()
print(preference,'apply=',accepted,'pending=',pending,'retry=',retried,'ordinary-admit=',Preferences.admit(),'detail=',detail)
local current=read(path);os.remove(path);os.remove(backup)
assert(current==original,'actual primary inverse returns exact source')
assert(runtime.marker=='before','actual primary runtime inverse returned')
assert(accepted==true,'successful native preference release cannot be acknowledged while public owner remains busy/held; generic adoption is blocked')
