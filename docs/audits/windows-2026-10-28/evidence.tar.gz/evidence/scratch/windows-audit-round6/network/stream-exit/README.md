# Streaming native exit admission

Commit: `00c8c8b54a3d181d1f93da21bb890fed7f7baaef`.

Bug: the live Ollama streaming poll confirmed native process exit but discarded the exit status before interpreting the complete provider done frame. Native transport failures could therefore invoke success.

Valid old actual AHK receipt 061: exit 0 control passed; actual exits 18/28/259 and an actually unqueryable retained handle each wrongly published success. All exact-object wait/status/output preconditions passed before the semantic assertions. Initial 056 was INVALID bug evidence: nested generated child source failed parsing, now replaced by a checked-in standalone BOM/LF child. Preserve this distinction.

Correction: under a short ownership Critical, read the already-signaled native status before retiring the exact handle; use the canonical exit query and reject nonzero or unreadable receipts. No default success when ownership is absent. Existing live-reader cancellation fixtures now retain actual completed native children.

Actual whole affected cohort 068: 31/31 PASS. Earlier 067 had five environment failures because the owned Wine prefix lacked Windows System32 curl; installing the existing verified genuine Windows curl 8.23 resolved all five without source/test changes. A static gate 140 also correctly rejected the new fixture's missing initial comment; after adding its filename comment, exact child source 153 passed 5/5 native cases. Genuine gates/commit 141 passed at 27 October 2026 00:57:41–00:57:50 Paris.

These are actual AHK 2.0.26/Wine executions, not full native Windows CI certification. Full native suite/E2E and CI remain integration requirements. No external network, capture or user contents. No push by this agent.

See checkpoint.json and copied receipts for evidence; patch 00c8c8b54a.patch is ready.
