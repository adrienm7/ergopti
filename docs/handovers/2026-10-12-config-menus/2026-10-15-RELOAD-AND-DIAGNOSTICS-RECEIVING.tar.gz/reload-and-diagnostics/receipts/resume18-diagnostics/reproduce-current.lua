local root = assert(arg[1])
package.path = root .. "/static/ergopti_plus/macos/?.lua;" .. root .. "/static/ergopti_plus/macos/?/init.lua;"
    .. root .. "/static/ergopti_plus/_shared/lua/?.lua;" .. root .. "/static/ergopti_plus/_shared/lua/?/init.lua;" .. package.path
local Json = require("json")
local events, logs, tasks = {}, {}, {}
local logger = setmetatable({}, { __index = function(_, name) return function(tag, text, ...)
    logs[#logs + 1] = { level = name, tag = tag, text = string.format(text, ...) }
end end })
package.loaded["infra.logger"] = logger
package.loaded["infra.deferred_work"] = { after = function() error("No deferred work is expected") end }
_G.hs = { fs = { attributes = function() return "file" end }, timer = { absoluteTime = function() return 1000000000 end }, task = {} }
local function new_task(bin, done, args)
    local env = {}
    local task = { bin = bin, args = args, complete = done, running = false }
    function task:environment() return env end
    function task:setEnvironment(value) env = value; return self end
    function task:start() self.running = true; events[#events + 1] = "start"; return self end
    function task:isRunning() return self.running end
    function task:terminate() self.running = false; return self end
    tasks[#tasks + 1] = task
    return task
end
hs.task.new = new_task
local Shell = require("adapters.shell_runner")
local real_spawn, callbacks = Shell.spawn, {}
Shell.spawn = function(bin, args, done, ...)
    callbacks[#callbacks + 1] = type(done)
    return real_spawn(bin, args, done, ...)
end
local Report = require("ui.healthcheck.report")
local open_result = Report.perform({ action = "open_path", id = "errors_today" },
    { errors_today = "/disposable/errors.log" }, {}, {}, { exists = function() return true end })
assert(#tasks == 1 and tasks[1].bin == "/usr/bin/open")
assert(open_result.ok == true and callbacks[1] == "nil")
local child_success, child_kind, child_exit = os.execute("/bin/sh -c 'exit 23'")
assert(child_success == nil and child_kind == "exit" and child_exit == 23)
tasks[1].running = false
tasks[1].complete(child_exit, "", "controlled failure")
assert(next(Shell._active_tasks) == nil, "The production adapter receives terminal retirement")
assert(open_result.ok == true, "Literal report retains its premature success")
local result = { source = "literal current macOS report and actual shell_runner/task_environment/runtime_log modules",
    boundary = "Controlled hs.task native port; independent real Linux child exit 23; no actual Cocoa/open execution",
    open_path = { callback_type = callbacks[1], immediate_ok = open_result.ok, native_exit = child_exit,
        success_after_terminal = open_result.ok, adapter_tasks_retired = true } }

local function read_json(relative)
    local file = assert(io.open(root .. "/static/ergopti_plus/_shared/" .. relative, "rb"))
    local value = Json.decode(file:read("*a")); file:close(); return value
end
local schema = read_json("modules/diagnostics/schema.json")
schema.export_strings = read_json("data/locales/en.json")
local docs = { schema = schema, templates = read_json("modules/diagnostics/issue_templates.json"),
    redaction = read_json("modules/diagnostics/redaction.json"), repository = read_json("modules/updater/defaults.json").github }
package.loaded["infra.i18n"] = { get = function(key) return key end }
local snapshot = { schema_version = 2, driver = "macos", generated_at = "2026-10-15T00:00:00Z",
    sections = { versions = { ergopti_version = "2.4.0" }, issues = { recent = {} } } }
local document = require("healthcheck.share").document(snapshot, schema)
events = {}
local outcome = Report.perform({ action = "report", text = document.text },
    { diagnostics_dir = "/disposable/diagnostics" }, docs, {}, {
        copy = function() events[#events + 1] = "copy"; return true end,
        save = function(dir, name) events[#events + 1] = "save-close"; return dir .. "/" .. name end,
        open_url = function() events[#events + 1] = "browser"; return true end,
    }, snapshot)
assert(#tasks == 2 and tasks[2].args[1] == "-R")
assert(tasks[2].running == true and outcome.ok == true)
assert(events[#events] == "browser")
local before_terminal = {}
for _, value in ipairs(events) do before_terminal[#before_terminal + 1] = value end
tasks[2].running = false
tasks[2].complete(23, "", "controlled reveal failure")
result.reveal_order = { callback_type = callbacks[2], events_before_reveal_terminal = before_terminal,
    immediate_ok = outcome.ok, reveal_exit = 23, adapter_tasks_retired = next(Shell._active_tasks) == nil }
print(Json.encode(result))
return result
