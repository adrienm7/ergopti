﻿; modules/updater.ahk

; ==============================================================================
; MODULE: Updater
; DESCRIPTION:
; Provides version display, one-click self-update, and background polling
; against GitHub Releases. The "Check / Update" menu item is dynamic: it
; reads as "Vérifier les mises à jour" at rest, "Mettre à jour vers vX.Y.Z"
; when a newer version is cached, and is disabled while a check is in
; progress. Clicking it always does the right thing in one action.
;
; FEATURES & RATIONALE:
; 1. One-click update: a single menu item handles check → download → swap.
;    No intermediate dialog is shown when an update is already cached.
; 2. Background polling: optional periodic silent check; surfaces a TrayTip
;    on new releases and updates the menu label immediately.
; 3. Channel-aware: the user subscribes to one channel of the shared registry
;    (_shared/modules/updater/channels.json, most stable first). The choice is
;    persisted in the shared config TOML by Updater_SetChannel, its one owner.
; 4. GitHub Releases API: async WinHTTP requests retain immutable manual or
;    background provenance through their terminal callback.
; ==============================================================================

; INDEX: this file declares nothing itself; it #Include-s the updater
; sub-modules below. Functions and globals are hoisted into the global
; namespace, so load order is irrelevant.
;   updater/channels.ahk    -- Update-channel registry interpreter (generated data).
;   updater/schedule.ahk    -- Automatic-check schedule port (generated timing).
;   updater/core.ahk        -- Config, version compare, release fetch + parse.
;   updater/changelog.ahk   -- Menu actions, one-click update, changelog window.
;   updater/self_update.ahk -- Download, executable swap, background polling.
;   updater/config_backup.ahk -- Configuration backup and restore (Versions window).
;   updater/release_install.ahk -- One-click install of a chosen release.

#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\_generated\update_channels.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\modules\updater\channels.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\_generated\update_schedule.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\modules\updater\schedule.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\modules\updater\core.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\modules\updater\changelog.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\modules\updater\self_update.ahk
#Include Z:\workspace\scratch\windows-audit-round6\delivery-review\restore-publication-identity\private-config-backup.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\modules\updater\release_install.ahk
#Include Z:\workspace\ergopti-windows-r7-installer\static\ergopti_plus\windows\modules\updater\asset_signature.ahk
