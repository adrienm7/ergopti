# Independent Windows Delay review

Status: source implementation has no identified correctness blocker; new native menu fixture requires one bounded teardown correction before approval.

Reviewed isolated candidate `/workspace/ergopti-delivery/full-group1-delay` against base `88909124461a3dbdfe5b745453fe50333eb64adc`. Exact five-file hashes are in `review-manifest.json`. This review did not modify the candidate, root checkout, index, refs or CI.

## Required correction

`static/ergopti_plus/windows/tests/unit/test_tap_hold_hand_sections.ahk:330` deletes the newly rendered parent menu and prunes only that parent. The rendered tree includes native hold and Delay submenus with registered callbacks. Deleting the parent detaches those children; dispatcher pruning intentionally preserves IDs owned by detached child menus. This is the documented native heap-corruption failure mode in `docs/memory/windows-ahk.md`, and the existing test helper `_CTC_ReleaseMenu` explicitly fixes it by releasing descendants while holding their Menu objects. Use that helper for the new fixture (and the directly touched head fixture if correcting the same ownership defect there). Do not globally clear dispatcher maps or foreign detached registrations. The helper is included by `run_all.ahk`; `Test` registers callbacks for execution after all includes, so its later include is valid.

## Test-fixture qualification

The nonfinite vectors at `test_tap_hold_global_transaction_20260813.ahk:556` and `:557` obtain values from legacy `msvcrt\strtod` without proving that the results are NaN and Infinity. Add explicit type/value validity assertions or construct IEEE double values with Buffer/NumPut. Otherwise a native CRT returning zero could satisfy the refusal assertions without testing nonfinite input. This review does not claim that the available CRT actually returns zero; native execution is unavailable here.

## Source findings

The public duration writer accepts only Integer/Float values satisfying a positive bounded comparison, refuses unknown and case-mismatched physical IDs through the existing shared catalogue, and binds a private candidate mutation that changes only `time_activation_seconds`. The existing transaction owner acquires both master and child leases before cloning desired state, persists and atomically replaces before publication, and requires strict integer1 receipts. Duration does not bypass these owners or add a second persistence path.

The new menu callback object captures each physical key independently and discards native event arguments. The prompt reads the effective per-key runtime getter from desired configuration, substitutes the translated printf placeholder, accepts only the real InputBox Object/String contract, rejects cancellation/missing/invalid/overflow input, and rounds positive milliseconds before converting to seconds. It checks source pointer and target path after the prompt, invokes the writer once, and calls reload once only after strict accepted publication. Prompt, I/O and reload run outside inherited Critical and restore the caller's posture.

The old transaction test file remains an exact byte prefix. Head tests retain original four-row order, caption, payload, native position and platform-projection assertions through a bounded projection that removes exactly the one declared Delay tail. The additional full-tree test requires all five positions and the genuine custom command. HIGH07 keeps its registration/data assertions and adds an explicit head-then-tail declaration check.

## Executed portable checks

- Encoding: passed, 1830 AHK files retain UTF-8 BOM and LF.
- AHK v2 syntax antipattern gate: passed, 1815 Windows source files.
- Loop-capture guard: passed, 14 independent self-test fixtures.
- Translated Format placeholder gate: passed, 16 Windows calls in 21 locales.

The initial RTK launcher attempt could not initialize its default read-only HOME cache. Recorded checks then ran as direct child processes with stdout captured into this review directory, as the repository launcher contract allows for parsed/logged output. No setup or candidate files were changed to bypass that environment issue.

## Remaining gates and prerequisites

Native AHK unit/meta, E2E, resident startup, packaging/installation and physical Windows menu interaction were not executed. No Wine or native AHK interpreter is available. The new neutral `menu.tapholds.key_tap_delay_dialog_prompt_current` key and all 21 translations remain root-owned publication prerequisites. Shared Delay/check template/compiler records require the delegated shared-source review and root generator publication; this bounded review does not approve those files. Current duration tests intentionally disable initialized master ownership for private fixture isolation; the existing owner delegation supplies master projection behavior, but this review does not claim a newly executed master-off integration test.
