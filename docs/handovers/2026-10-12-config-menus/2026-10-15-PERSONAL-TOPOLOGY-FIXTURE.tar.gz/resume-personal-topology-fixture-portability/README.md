# Linux topology test-fixture portability receiving

This is a test-fixture-only supplement to the sealed Linux Personal topology proposal. The Linux Unit job installs LuaJIT and luv but does not install lua-posix. The frozen v3 test file returned before registering all 34 new topology subjects when POSIX.dir was unavailable. Its ordinary unit exit code therefore remained zero while none of those regressions ran.

The proposed test image is `candidate-tests.lua`, SHA256 `2340d5e638fbf0660839991d3f96de74d55908e805c53028f5b3e9552d276658`. `fixture-portability.patch` is the delta against frozen `tests-83.lua`, SHA256 `d14677ca2fd8f79acdb973e4ea4d7f76b4a896e08890bf91b833bbf9d2a73f6c`. The entire original 49 prefix remains byte-identical: 38,693 bytes, SHA256 `7538539f52f671d0bf9503fabede610fedfafd45fe85b44cc902898b9369ff38`. All 34 added subject names and expectations remain identical. After the new fixture setup, the complete case body is unchanged except for its two inventory-port variable references.

The producer remains exact reviewed v3, SHA256 `ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768`. No production, workflow, CI-runner, registration or assertion change is proposed.

## Controlled fixture port

When real lua-posix.dir is available, the fixture keeps its existing POSIX port unchanged. Otherwise it prints an explicit diagnostic and supplies a named fixture_filesystem port backed by actual native luv operations:

- fs_scandir/fs_scandir_next enumerate actual filesystem names, including LF names. Refusal and exhaustion remain distinct.
- fs_lstat supplies actual no-follow device/inode/type and the complete mtime timespec used by the existing fixture contract.

The existing counting/refusal/duplicate/reentry wrappers still surround that inventory port. This is a controlled test fixture, not a new production fallback and not execution of the absent POSIX library. Missing native fixture capabilities explicitly report that receiving was not executed; no replacement passing subject is registered. The existing s.no_posix branches remain unchanged and still make require(posix) unavailable so those cases reach the producer's actual native-stat or checked-shell branches.

## Final isolated receiving

`isolated-portability-matrix.json` contains 10 naturally terminal children. Every child has its own mkdtemp-created TMPDIR and TEMP, recorded in its receipt; each owned temporary root is empty and removed afterward. The final corpus runs as a complete owning module, never only the new block.

| Final fixture mode | Lua 5.4 | LuaJIT | New topology subjects executed |
| --- | --- | --- | ---: |
| Real POSIX available | 83 passed / 0 failed | 83 passed / 0 failed | 34 each |
| POSIX unavailable only at topology-group entry | 83 passed / 0 failed | 83 passed / 0 failed | 34 each |
| POSIX unavailable globally | 82 passed / 0 failed | 82 passed / 0 failed | 34 each |

Global absence leaves one unchanged original subject unavailable: `file_watchers subsecond polling: detects same-second edits with installed posix`. It is optional in the preserved prefix and cannot truthfully run without that library. Global absent mode is therefore48 original subjects plus34 new, with one original integration subject UNRUN. The topology-only controlled absence mode runs all 49 originals first and then removes POSIX only for the new group's entire construction and execution, receiving 83 total. No source flag or runtime feature was added to achieve these modes; only the external runner controls package.loaded/preload at the exact group boundary and restores them afterward.

The same isolated harness first runs the unchanged frozen v3 test fixture under both absence modes on both engines. Topology-only absence gives 49 passed, zero failed, zero of34 topology subjects executed. Global absence gives 48 passed, zero failed, zero of34 executed. Those underlying unit children exit 0, but the independent receiving count/name gate rejects each with exit 1 and reports all 34 missing names. These are receiving failures, not fabricated assertion failures. The revised fixture then passes the same complete-module count/name gate in all six engine/mode combinations.

`expected-subjects.json` pins the independent accepted v3 subject list and its original successful log. Its source is the preserved test corpus receipt, not a regenerated implementation-derived expectation. `receiving-receipt.json` rechecks every terminal status/log hash, all 34 executed names, prefix preservation, producer identity, cleanup and dependency provenance.

## Preliminary matrix retained

The first complete portability matrix also received the same expected results, but inherited activation's shared TMPDIR while the parent ran a canonical native gate. The unchanged original 49 fixture names include epoch seconds and a per-module sequence rather than PID. A same-second collision was therefore possible. No collision or failure is asserted; the preliminary raw logs and 10 statuses are retained with that limitation. They are superseded for final receiving by the isolated replay, rather than silently overwritten.

The first matrix and the final replay both finished naturally. No process was stopped or source input changed while its child was active. The canonical gate was never read or edited by this proposal.

## Provenance and limits

The external source capture is based on Git commit `b666a22f72cf3b27e55bef08720f7064348d1d40`. Recover its 2,361 dependency files with `git archive` of `static/ergopti_plus/linux` and `static/ergopti_plus/_shared`, then validate `source-manifest.json`. Apart from the two declared producer/test overlays, every byte remains unchanged; there are no missing or extra dependency files. The archive omits that duplicate source tree and package caches.

Both matrix scripts, their external runner and all 20 raw terminal receipts are included. The runtime environment sources `/workspace/.ergopti-cloud/activate.sh`. Final child temporary roots are created under `/var/tmp/ergopti-cloud-validation` with environment overrides supplied directly to subprocess.run; they are never shared between children. Running the packet elsewhere requires updating its external source-root locations and restoring the saved Lua dependencies.

The original v3 proof archive remains byte-identical: `resume-personal-watch-topology-receiving.tar.gz`, SHA256 `ef732a0a888d5f7c5724f9e6b42e3c5b25286b815e60ec28fdd992a3cb2d37a3`. It retains the production red/candidate/withdrawal/restored matrix and historical source/corpus evidence. This supplement proves portable execution of the unchanged new expectations. It does not replace the parent's later canonical full-gate, CI, packaging or installed acceptance results.

The parent and resume_menus independently accepted this fixture source delta. Their review is source evidence, separate from the executed receipts. SHA256SUMS covers all other archive members; the receiving archive is reopened and every member byte-compared before handoff.
