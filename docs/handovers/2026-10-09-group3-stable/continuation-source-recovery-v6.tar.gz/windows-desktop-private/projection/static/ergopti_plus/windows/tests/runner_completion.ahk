﻿; Watchdog: kill the process if RunTests() never returns (e.g. a corpus
; consumer blocks on a synchronous HTTP call, an InputHook with no timeout,
; or a blocking dialog in a headless CI context). The current corpus normally
; uses a small fraction of this per-test budget; the cap remains three minutes
; below CI's 25-minute process timeout so partial TAP can still be validated.
global _SUITE_STARTUP_BUDGET_MS := 120000
global _SUITE_PER_TEST_BUDGET_MS := 200
global _SUITE_MAX_TIMEOUT_MS := 1320000
global _SUITE_TIMEOUT_MS := _SuiteTimeoutForCount(TEST_REGISTRY.Length)

; Saturation deliberately reserves time for CI to publish partial results.
_SuiteTimeoutForCount(PlannedCount) {
	global _SUITE_MAX_TIMEOUT_MS, _SUITE_STARTUP_BUDGET_MS, _SUITE_PER_TEST_BUDGET_MS
	return Min(_SUITE_MAX_TIMEOUT_MS,
		_SUITE_STARTUP_BUDGET_MS + PlannedCount * _SUITE_PER_TEST_BUDGET_MS)
}

_WatchdogFire() {
	; Preserve the exact partial execution list before force-exiting. The CI
	; validator rejects any missing RUNNING/result pair.
	try _CopyTestResultsForCi()
	try FileAppend("`n[WATCHDOG] Test suite timed out after " . _SUITE_TIMEOUT_MS . " ms - force-exiting.`n", "*")
	ExitApp(2)
}
SetTimer(_WatchdogFire, -_SUITE_TIMEOUT_MS)

; Drive everything. RunTests prints a TAP-style report to stdout and exits
; with the appropriate code — control never returns from this call.

RunTests()
