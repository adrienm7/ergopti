from pathlib import Path
import ast,difflib,hashlib,json,re
p=Path('/tmp/group6-release-darwin-enrollment-ec170e2d6-r2-deadline');repo=Path('/workspace/ergopti')
def sha(b):return hashlib.sha256(b).hexdigest()
def apply(text,diff):
 lines=text.splitlines(True); out=[]; pos=0;i=2;rows=diff.splitlines(True)
 while i<len(rows):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',rows[i]); assert m
  at=int(m[1])-1 if int(m[1]) else 0;out+=lines[pos:at];pos=at;i+=1
  while i<len(rows) and not rows[i].startswith('@@ '):
   row=rows[i];i+=1
   if row[0]==' ':assert lines[pos]==row[1:];out.append(lines[pos]);pos+=1
   elif row[0]=='-':assert lines[pos]==row[1:];pos+=1
   elif row[0]=='+':out.append(row[1:])
   else:raise AssertionError('Unknown hunk record')
 out+=lines[pos:];return ''.join(out)
m=json.loads((p/'MANIFEST.json').read_text())
for name in m['candidate_paths']:
 before=(p/'preimage'/name).read_text() if (p/'preimage'/name).exists() else ''
 after=(p/'candidate'/name).read_text()
 for old,new in [(before,after),(after,before)]:
  diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='old',tofile='new'))
  assert apply(old,diff)==new
source=(p/'candidate/tools/diagnostics/macos_release_stage_native_receiving.cjs').read_text()
worker=source.split('const WORKER = `',1)[1].split('`;',1)[0]
ast.parse(worker)
corpus=ast.parse((repo/'tools/diagnostics/macos_release_stage_route_test.py').read_text())
perms=next(n.value for n in corpus.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PERMUTATIONS' for t in n.targets))
extras=next(n.value for n in corpus.body if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='CASES')
assert len(perms.elts)==6 and len(extras.elts)==44
proof={'version':1,'every_forward_reverse_hunk_exact':True,'corpus_literal_6_plus_44':True,'corpus_ast_sha256':sha(ast.dump(corpus,include_attributes=False).encode()),'worker_ast_sha256':sha(ast.dump(ast.parse(worker),include_attributes=False).encode()),'owner_shared_or_product_files_modified':False,'author_target_execution':0}
q=p/'SOURCE-PROOF.json';q.write_text(json.dumps(proof,indent=2)+'\n')
m['source_proof_addendum']={'path':str(q),'sha256':sha(q.read_bytes()),'size':q.stat().st_size}
m['authoring_sources']=[{'path':str(p/n),'sha256':sha((p/n).read_bytes()),'size':(p/n).stat().st_size} for n in ['prepare-packet.py','verify-source-packet.py','PREIMAGE-LOCATION.json']]
(p/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha((p/'MANIFEST.json').read_bytes()),'patch_sha256':sha((p/'darwin-enrollment.patch').read_bytes()),'source_proof':proof}))
