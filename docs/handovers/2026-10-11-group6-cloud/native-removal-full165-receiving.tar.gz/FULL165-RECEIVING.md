# Full portable removal-successor receiving

The unchanged original 156 cases plus the nine additive removal controls execute
as 165 passed / zero failed / zero errors / zero skipped in 45.164 seconds.
The original sixty-second business boundary is retained. All 29 candidate and
live-source hashes agree before and after; no candidate bytecode cache appears.
The directly owned child is reaped and its process group is absent. Original
fixture/capture/debt assertions remain authoritative; these process checks do
not assert an atomic namespace guarantee or macOS keychain closure.

This is an independent private 29-file source derived from committed 475b plus
only the two immutable R2 candidate files. Neither the live fixture nor the
live 156-case registry is changed. The earlier proposal and all original test
bodies/providers remain unchanged. An initial parent single-line output parser
received 164 rows because original test47 emits its bounded same-owner diagnostic
before a separate ok. The actual diagnostic and terminal row are independently
received without changing a test, assertion or expectation. The complete case
identities, original footer, physical command result and raw outputs are retained.

The shared Root/G4 source ownership and normal selected adoption gates are still
required. Darwin trust installation/removal, current original Windows23 and
complete native packaging/installation remain unrun on this proposal. No native
qualification, hosted timeout cause or TODO closure follows from this run.
