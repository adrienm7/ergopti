#!/usr/bin/env python3
"""Supervise an isolated actual Hammerspoon tooltip pixel observation on macOS."""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import plistlib
import re
import shutil
import subprocess
import sys
import tempfile
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identities(repo):
    paths = []
    for directory in (repo / "static/ergopti_plus/macos", repo / "static/ergopti_plus/_shared"):
        for path in directory.rglob("*"):
            if path.is_symlink():
                raise ValueError("redirected production snapshot input: " + str(path))
            if path.is_file():
                paths.append(path)
    paths += [repo / "tools/bench/macos-metrics/run.py", repo / "tools/build/build_macos_app.sh"]
    return {str(path.relative_to(repo)): digest(path) for path in sorted(paths)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--app", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path, help="fresh, nonexistent evidence directory")
    args = parser.parse_args()
    if sys.platform != "darwin":
        parser.error("requires native macOS, a GUI login and actual Hammerspoon; Linux is unsupported")
    from PIL import __version__ as pillow_version
    from observe import observe
    if pillow_version != "11.3.0":
        parser.error("requires Pillow 11.3.0 for the read-only pixel observer")
    repo = args.repo.resolve(strict=True)
    app = args.app.resolve(strict=True)
    version_source = (repo / "tools/build/build_macos_app.sh").read_text(encoding="utf-8")
    versions = re.findall(r'^HAMMERSPOON_VERSION="\$\{HAMMERSPOON_VERSION:-([^}]+)\}"$',
                          version_source, re.MULTILINE)
    if len(versions) != 1:
        parser.error("repository-selected Hammerspoon version missing or ambiguous")
    with (app / "Contents/Info.plist").open("rb") as stream:
        info = plistlib.load(stream)
    if info.get("CFBundleShortVersionString") != versions[0]:
        parser.error("app differs from repository-selected Hammerspoon version")
    subprocess.run(["/usr/bin/codesign", "--verify", "--strict", "--deep", str(app)],
                   check=True, timeout=30)
    output = args.output.absolute()
    output.mkdir(parents=True, exist_ok=False)
    scratch = Path(tempfile.mkdtemp(prefix="ergopti-tooltip-native-")).resolve()
    here = Path(__file__).resolve().parent
    report = {"status": "error", "scratch": str(scratch), "native_execution": "pending",
              "physical_input": "unmeasured", "watcher_orchestration": "unmeasured",
              "pillow_version": pillow_version}
    launcher = None
    native = None
    lifecycle = None
    executable = scratch / "Hammerspoon.app/Contents/MacOS/Hammerspoon"
    failure = None
    before = None
    try:
        before = identities(repo)
        probe_hashes = {name: digest(here / name) for name in ("init.lua", "run.py", "observe.py")}
        source_root = scratch / "source"
        for name in ("macos", "_shared"):
            destination = source_root / "static/ergopti_plus" / name
            shutil.copytree(repo / "static/ergopti_plus" / name, destination)
        for relative, expected in before.items():
            if relative.startswith("static/") and digest(source_root / relative) != expected:
                raise ValueError("source copy differs from captured source identity: " + relative)
        if identities(repo) != before:
            raise ValueError("production source drifted during snapshot acquisition")
        (output / "sources.json").write_text(json.dumps({"production": before, "probe": probe_hashes}, indent=2)
                                              + "\n", encoding="utf-8", newline="\n")
        subprocess.run(["/usr/bin/ditto", str(app), str(scratch / "Hammerspoon.app")],
                       check=True, timeout=60)
        source_executable = app / "Contents/MacOS/Hammerspoon"
        if digest(source_executable) != digest(executable):
            raise ValueError("copied actual runtime executable changed")
        report["runtime_executable_sha256"] = digest(executable)
        report["expected_version"] = versions[0]
        subprocess.run(["/usr/bin/codesign", "--verify", "--strict", "--deep", str(scratch / "Hammerspoon.app")],
                       check=True, timeout=30)
        shutil.copyfile(here / "init.lua", scratch / "init.lua")
        (scratch / "probe-config.json").write_text(json.dumps({"source_root": str(source_root),
                                "output_dir": str(output.resolve()), "expected_version": versions[0]}),
                                encoding="utf-8", newline="\n")
        # Reuse the existing libproc exact-path authority and bounded cleanup;
        # neither its source nor another diagnostic owner's workflow is edited.
        helper = repo / "tools/bench/macos-metrics/run.py"
        specification = importlib.util.spec_from_file_location("ergopti_tooltip_lifecycle", helper)
        lifecycle = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(lifecycle)
        if digest(helper) != before[str(helper.relative_to(repo))]:
            raise ValueError("native lifecycle helper drifted")
        native = lifecycle.NativeProcesses()
        with (output / "launch.log").open("xb") as log:
            launcher = subprocess.Popen(["/usr/bin/open", "-n", "-g", "-W",
                                str(scratch / "Hammerspoon.app"), "--args", "-MJConfigFile", str(scratch / "init.lua")],
                                stdout=log, stderr=subprocess.STDOUT)
            deadline = time.monotonic() + 60
            observed = False
            while time.monotonic() < deadline:
                owners = native.matching(executable)
                if len(owners) > 1:
                    raise ValueError("isolated native executable has multiple owners")
                observed = observed or bool(owners)
                path = output / "result.json"
                if path.exists():
                    result = json.loads(path.read_text(encoding="utf-8"))
                    if not observed or len(owners) != 1:
                        raise ValueError("native result lacks an observed living exact executable owner")
                    if result.get("version") != versions[0]:
                        raise ValueError("native result version differs from actual selected app")
                    pixels = observe(result, output)
                    if identities(repo) != before:
                        raise ValueError("production sources drifted during native observation")
                    if {name: digest(here / name) for name in probe_hashes} != probe_hashes:
                        raise ValueError("diagnostic sources drifted during observation")
                    report.update(status="ok", native_execution="executed", native_process_observed=True,
                                  painted_captures=12, result=result, pixels=pixels)
                    break
                if launcher.poll() is not None:
                    raise RuntimeError("Launch Services exited before an actual paint receipt")
                time.sleep(0.05)
            else:
                raise RuntimeError("actual paint observation exceeded its 60-second deadline")
    except Exception as error:
        failure = str(error)
    finally:
        if launcher is not None:
            try:
                lifecycle.cleanup(native, executable, launcher)
                report["application_cleanup"] = "confirmed exact executable absent"
            except Exception as error:
                failure = (failure + "; " if failure else "") + "cleanup: " + str(error)
        else:
            report["application_cleanup"] = "no launcher was acquired"
        if failure:
            report.update(status="error", error=failure)
        (output / "supervisor.json").write_text(json.dumps(report, indent=2) + "\n",
                                               encoding="utf-8", newline="\n")
    print(json.dumps(report))
    return 0 if report["status"] == "ok" else 1


if __name__ == "__main__":
    sys.exit(main())
