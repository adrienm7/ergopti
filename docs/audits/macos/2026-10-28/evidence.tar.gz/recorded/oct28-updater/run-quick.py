import subprocess,os,json,time,sys,datetime
from pathlib import Path
from zoneinfo import ZoneInfo
w=Path('/workspace/ergopti-macos-cloner-i18n');d=Path('/workspace/scratch/oct28-updater')/sys.argv[1];d.mkdir();e=dict(os.environ);e.update(USER='agent',LOGNAME='agent',HUSKY='1');e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu'
for key in ['TMPDIR','XDG_RUNTIME_DIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_STATE_HOME']:
 p=d/key.lower();p.mkdir(mode=0o700);e[key]=str(p)
cmds=[('false-green',['node','tools/test/find-false-greens.cjs']),('hooks-install',['npx','husky','install'])]
for label,module in [('installer','tests.unit.modules.updater.test_release_installer'),('receipts','tests.unit.modules.updater.lifecycle.test_release_swap_receipts'),('arming','tests.unit.modules.updater.lifecycle.test_release_arming_receipt')]:cmds.append((label,['npm','run','-s','test:hs','--','--only='+module]))
cmds += [('verify-plan',['node','./tools/test/verify-change.cjs','--plan']),('normal-hook',['sh','.husky/pre-commit'])]
r=[]
for label,cmd in cmds:
 start=time.monotonic()
 with (d/(label+'.log')).open('w') as f:x=subprocess.run(cmd,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT)
 row={'label':label,'command':cmd,'actual_exit':x.returncode,'seconds':time.monotonic()-start};r.append(row);(d/'receipt.json').write_text(json.dumps({'started_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'gates':r},indent=2)+'\n');print(json.dumps(row),flush=True)
 if x.returncode:sys.exit(x.returncode)
