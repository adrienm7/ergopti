﻿; modules/llm/ollama_model_pull_owner.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Owned Windows Ollama Model Command
; DESCRIPTION:
; Reuses the exact runtime/guardian owner for a separate foreground model job.
; Explicit consent and current origin/version/model selection remain mandatory.
; Completion is physical command retirement, never an AI-enable or tags receipt.
; ==============================================================================

/** Owns a single captured model command through the existing guardian lifecycle. */
class OllamaModelPullOwner extends OllamaRuntimeOwner {
	__New(Options, ModelTag) {
		if !(Options is Map) || Options.Has("spawn")
			throw TypeError("A managed model command requires the default guardian source owner.")
		if !(ModelTag is String) || !RegExMatch(ModelTag, "\A[A-Za-z0-9][A-Za-z0-9._/-]*(:[A-Za-z0-9._-]+)?\z")
			throw ValueError("The model command requires one literal admitted model tag.")
		if Options.Has("guardian_ctor") && !HasMethod(Options["guardian_ctor"], "Call")
			throw TypeError("The explicit guardian constructor port must be callable.")
		super.__New(Options)
		this.ModelTag := ModelTag
	}

	_ValidTarget(Target) {
		return super._ValidTarget(Target) && Target.Get("model_tag", "") == this.ModelTag
	}

	_NativeSpawn(Record, Executable, Arguments, OnDone) {
		; The parent has already captured the target and explicit authorization.
		; The tag is read from that immutable record, not a later menu selection.
		local tag := Record["target"]["model_tag"]
		if tag != this.ModelTag
			throw ValueError("The captured model command no longer matches its owner.")
		local command := Arguments.Clone()
		command.Push("-Action", "pull", "-ModelTag", tag)
		local spec := this.Options["source_spec"].Call(Record["target"].Clone())
		local constructor := this.Options.Get("guardian_ctor", OllamaGuardianTask)
		return constructor.Call(ObjBindMethod(this, "_NativePort"), spec, Executable,
			command, OnDone, ObjBindMethod(this, "_Current", Record),
			Record["created_at"] + this.Options["startup_ms"], this.Options["poll_ms"],
			this.Options["source_capture_bytes"])
	}
}
