local root = "/workspace/.ergopti-cloud/config-personal-root-view/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local helpers = require("tests.helpers")
if arg[1] then helpers.set_only_filter(arg[1]) end
require("tests.unit.meta.test_file_watchers")
local results = helpers.get_results()
print(require("json").encode(results))
os.exit(results.failed == 0 and 0 or 1)
