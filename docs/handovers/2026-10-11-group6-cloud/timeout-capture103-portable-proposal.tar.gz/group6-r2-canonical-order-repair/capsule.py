"""Package regular bounded files only; preserve frozen prior receipts."""
from pathlib import Path
import hashlib
import json
import tarfile

BASE = Path(__file__).resolve().parent
files = sorted(path for path in BASE.rglob('*') if path.is_file() and path.name != 'capsule-inventory.json')
assert not any(path.is_symlink() for path in BASE.rglob('*'))
assert not any('__pycache__' in path.parts or path.suffix == '.pyc' for path in files)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
inventory = {str(path.relative_to(BASE)): {'bytes': path.stat().st_size, 'sha256': sha(path)} for path in files}
(BASE / 'capsule-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
archive = BASE.parent / 'group6-r2-canonical-order-repair.tar.gz'
with tarfile.open(archive, 'w:gz') as capsule:
    for path in files + [BASE / 'capsule-inventory.json']:
        capsule.add(path, arcname=str(Path(BASE.name) / path.relative_to(BASE)), recursive=False)
print(json.dumps({'capsule': str(archive), 'members': len(files) + 1, 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'inventory_sha256': sha(BASE / 'capsule-inventory.json')}, sort_keys=True))
