from pathlib import Path
import json,subprocess,sys
packet=Path(__file__).parent;worker=Path('/workspace/scratch/windows-audit-round6/verification-worker')
receipt=json.loads((worker/'receipts/373-harness-replay-actual-current-exit.json').read_text());assert receipt['exit_code']==1
raw=(worker/'373-harness-replay-actual-current.tap').read_text(encoding='utf-8-sig');lines=[s[len('#   replay: '):] for s in raw.splitlines() if s.startswith('#   replay: ')];assert len(lines)==1
expected=['Z:\\workspace\\toolchain\\ahk\\AutoHotkey64.exe','Z:'+str(packet/"current replay's é probe.ahk").replace('/','\\'),'--owned-selection',"two ' quotes \" $() ` é"]
manifest={'command':lines[0],'expected':expected};path=packet/'powershell-input.json';path.write_text(json.dumps(manifest,ensure_ascii=False)+'\n')
result=subprocess.run(['pwsh','-NoLogo','-NoProfile','-NonInteractive','-File',str(packet/'verify-powershell-replay.ps1'),'-InputJson',str(path)],capture_output=True,text=True)
(packet/'powershell-parser.stdout').write_text(result.stdout);(packet/'powershell-parser.stderr').write_text(result.stderr)
print(result.stdout,result.stderr,flush=True)
if result.returncode:sys.exit(result.returncode)
parsed=json.loads(result.stdout);assert parsed['actual']==expected
(packet/'powershell-proof.json').write_text(json.dumps(parsed,ensure_ascii=False,indent=2)+'\n')
