#!/bin/bash
source /workspace/tooling/activate-ergopti.sh
export PATH="/workspace/tooling/gtk/usr/bin:$PATH"
export LD_LIBRARY_PATH="/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
export LUA_CPATH="/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;$LUA_CPATH"
export LUA_PATH="/workspace/tooling/gtk/usr/share/lua/5.1/?.lua;/workspace/tooling/gtk/usr/share/lua/5.1/?/init.lua;$LUA_PATH"
export GI_TYPELIB_PATH="/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/girepository-1.0${GI_TYPELIB_PATH:+:$GI_TYPELIB_PATH}"
export WEBKIT_INJECTED_BUNDLE_PATH="/workspace/tooling/gtk/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/injected-bundle"
