# Retained tar feeder revision 4 — source only

Revision 2 remains immutable and its first native failure remains preserved. Its
18 semantic models passed, but no native tar scope completed (one failure,
seven unexecuted); unresolved physical cleanup is a failure, not a completion.
No cause for the blocked native edge has been established.

Production scope is limited to the private lexical feeder: capture exactly one
native supervisor terminal callback's raw boolean `ok` and string `stdout`, then
copy those closed fields privately; never consult mutable `supervisor.result`.
A missing/refused callback yields failure despite real physical settlement.
Success now has an absent error field. The owned-process bridge is byte-identical
to revision 2; no native I/O, group, close, consent or deadline guard changes.

The private native fixture uses original luv functions through transparent
argument/return/callback delegates. Its evidence records actual submissions and
callbacks, not ownership closure inferred from accepted work. `submitting`
means return admission is unavailable (including a throwing call); `accepted`
means a non-nil native request was returned; `refused` means a nil request was
returned; `callback` means the existing exact callback ran. Pending booleans must
be read alongside that closed enum. Reader/pipe/process/timer close fields are
only existing callback observations and never replace the supervisor's strong
leader/group/close ACK. Group absence is not exported as a diagnostic fact.

Only fixed case/reason labels, booleans, small counts and actual PID/PPID/group/
birth ticks are written to exclusive bounded JSON files under a newly owned
0700 `session/tar-evidence`; no argv, path, archive byte, stdout, stderr or secret
is exported. Exact diagnostic descriptor owners remain held on an ambiguous
close and make the fixture unavailable; no bare-number close retry exists.
The approved namespace is exclusively owned and trusted. These diagnostics are
not isolation against a deliberately interfering process running as the same UID.

The wrapper calls the existing byte-pinned `run_native_subreaper.py` without
changing its Popen, wait, rescue or final closure logic. Lua checks the actual
parent against that explicit launcher PID and publishes its own PID/birth/group
before fixture actions. The native spawn delegate holds exact process/stdio
capabilities and publishes the actual tar PID/birth/group before returning the
original native result to supervision. Receipt refusal is a fixture failure;
acquired operation cleanup stays in the original protected ledger. The existing
guardian owns child rescue/reaping; rescue remains failure. Neither this wrapper
nor diagnostics adds a signal, timer, wait, process poll or reaper.

Original eight native scenario bodies, every native assertion and both 10-second
await and 5-second case deadlines remain byte-identical. The entire original 12-scope I/O control
region remains byte-identical; only their common model helper now supplies the
actual terminal callback. Five additive literal callback/result controls and seven
independent diagnostic delegation controls are authored, UNPARSED/UNEXECUTED.
The original six bridge models are unchanged.

Prospective isolated overlay contains candidate owned_process + feeder part,
controls native_retained_tar + private_tar_diagnostics at one candidate directory,
and the exact qualified C shared library. Command form:

```
python3 controls/run_retained_tar_native.py controls/run_native_subreaper.py \
  /absolute/luajit /absolute/driver /absolute/overlay \
  /absolute/qualified/libergopti_archive_publication.so /absolute/new0700session
```

This is a source plan, not an executed command. No tests/imports/compilation or
main-tree changes are authorized until root assigns an exclusive slot after
peer review. Native cause and final package/installer integration remain unknown.

Revision4 additionally refences exact captured completion and worker state after
final lineage/clock admission. The rev3 result-publication reentry failure gets
a literal duplicate-during-final-current control; immutable rev3 source ACK does
not qualify this revised seam. Native fixture, diagnostic delegates, bridge and
guardian remain exact rev3 bytes. Final narrow source review pending.
