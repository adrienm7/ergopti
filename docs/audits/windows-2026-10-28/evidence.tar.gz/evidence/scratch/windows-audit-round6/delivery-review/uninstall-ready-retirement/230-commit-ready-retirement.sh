set -euo pipefail
cd /workspace/ergopti-windows-r7-installer
pwd
if test -n "$(git diff --cached --name-only)"; then
    printf '%s\n' 'Refusing to mix an existing index with the readiness fix' >&2
    exit 1
fi
node tools/test/verify-change.cjs --plan
node tools/test/test-ahk-encoding.cjs
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
git diff --check
git add -- static/ergopti_plus/windows/infra/uninstall.ahk static/ergopti_plus/windows/tests/unit/infra/lifecycle/test_uninstall.ahk
git commit -F /workspace/scratch/windows-audit-round6/delivery-review/uninstall-ready-retirement/commit-message.txt
git log -1 --format=fuller
git status --short
