# Unused constructor data reads in the guarded Linux root proof

The original positive control inserts one unused table of direct local values
at the start of the actual exported `M.build(ctx)` body. Its unchanged assertion
requires canonical imported-owner credit. The new guarded-header source route
also invokes `declaredLinuxTopLevelPublication`, whose two stricter gates reject
that genuine data-only statement: sibling custody rejects the bare ManifestMenu
value, and the closed root protocol rejects an additional leading statement.
No bracket-member conversion or header-template call change is needed.

This private successor changes only the bounded source predicate and adds source
controls. The predicate recognizes a single leading local plain table whose
fresh variable appears nowhere else in executable tokens. Its fields contain
only direct reads of `separator_render`, `ManifestMenu`, or the `ctx` parameter.
Named fields and array fields are both data. Their keys cannot be Lua keywords.
No calls, member lookup, nested tables, callback definitions, owner assignments,
protected-name shadows, or subsequent alias use qualify.

Only that proven unused declaration is excluded from the proof's token view.
The original module export, lexical renderer custody, guarded header algorithm,
full root body, child receiving chain, source identity, and render-result gates
remain mandatory. No native Lua source or runtime behavior changes. A quoted
brace cannot supply a delimiter, and a quoted or commented source cannot supply
a real exported builder. Unsupported constructor expressions remain unmodified
and fail the existing complete protocol obligation.

The original table-data positive assertion, all original callback-write and
quoted-brace negatives, and every other existing assertion remain unchanged.
Additions include a positive independent variable/field/order shape, followed
by seven executable constructor, member lookup, alias use, shadow, nested
callback, and quoted-delimiter negatives.

`SOURCE-ONLY-PROPOSAL.json` pins the two exact Root preimages and successor
postimages. The root library preimage is `7814fcb2...`; the manifest target
preimage is `59e9949a...`. This is source preparation only. Independent review,
syntax/format gates, the actual manifest target, broader JS/native suites,
generation, and CI are UNRUN. Root owns runtime validation and adoption.
No Root files, index, refs, generated artifacts, or CI were changed here.
