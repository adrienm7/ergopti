# Native desktop entry: private source prototype v2

Status: **bounded private source preparation only**. Canonical files, index, refs, workflows and the shared validation projection were not changed. Windows ownership clearance and independent review are pending. Native AHK parsing/execution, PowerShell receipt controls, Windows desktop behavior and packaging are **UNRUN** here.

## Concrete failure and scope

Run `37936720478` at `6d2c8b001c25bc1e55f235d0147a80886fb9cff4` completed the first original native console cohort with five successful cases, but its canonical stdout comparison failed because the full ordinary compilation image emitted 5,445 `LocalSameAsGlobal` warnings. The six AltGr cases did not execute. The separately retained raw log and complete inventory establish 115 original global/built-in names, not merely the initial three `Code` loops. This preparation neither filters warnings nor disables their policy.

The new entry compiles both complete original case files and their genuine selected-runtime dependencies while sharing the original argument parser, initial result receipt, fatal handler, log-directory assignments and watchdog completion with `run_all.ahk`. The full ordinary suite remains mandatory. Production adapter/include order, `TestQualificationRegisterParser(JsonParse)` and the existing `InstallSendNoOps()` boundary are preserved. The real console/runtime and hook child fixtures remain the original files. No test implementation is copied into the new entry.

Within this selected source closure, six original local names collide with real native built-ins and two local `Assigned` receivers collide with a top-level test registration loop. The candidate alpha-renames those six scoped local bindings and puts the original registration loop in one immediately invoked registration function. Its original `.Bind(Assigned)` expression and case order remain unchanged. The production native built-in exports are untouched. This is a source-level remedy for those eight observed warning sites, **not a claim that native compilation will emit zero warnings**.

## Exact proposed paths and custody

Five new files:

- `static/ergopti_plus/windows/tests/runner_prelude.ahk`
- `static/ergopti_plus/windows/tests/runner_log_directories.ahk`
- `static/ergopti_plus/windows/tests/runner_completion.ahk`
- `static/ergopti_plus/windows/tests/run_native_desktop.ahk`
- `tools/lib/ahk-runner-source.cjs` (portable guard reader only)

Eleven existing files:

- `static/ergopti_plus/windows/infra/toml/toml_document.ahk`: `_TOML_DocumentToken`, `Run` to `TomlQuoteRunLength` (seven tokens). G1 narrow grant `6083424588` covers this region only.
- `static/ergopti_plus/windows/infra/key_combinations.ahk`: `_KeyCombinationRunTap`, `Run` to `KeyCombinationTapAction` (two tokens).
- `static/ergopti_plus/windows/adapters/text_sender.ahk`: `_TextSenderKeystroke`, `Mod` to `TextSenderModifier` (four tokens).
- `static/ergopti_plus/windows/platform/remap/constants.ahk`: `_TapHoldKeyTapModifiers`, `Mod` to `TapHoldTapModifier` (two tokens).
- `static/ergopti_plus/windows/adapters/editor_replace.ahk`: `_TextSenderNativePollReceipt`, `OsError` to `TextSenderNativeErrorCode` (three tokens).
- `static/ergopti_plus/windows/tests/unit/test_key_combinations.ahk`: ordinary helper `_KCT_SlotsAreWrittenToTheConfiguration`, `Reload` to `SavedReloadCalls` (seven tokens), plus the exact `Assigned` loop wrapper. The six selected cases and their assertion bodies are unchanged.
- `static/ergopti_plus/windows/tests/run_all.ahk`: shared prelude/footer/log-directory include seams at the original positions; every other original code token remains.
- `static/ergopti_plus/windows/tests/meta/test_suite_watchdog_manifest.ahk`: only its two original source reads follow `runner_completion.ahk`; all original tests/assertions remain.
- `tools/test/run-windows-native-desktop.ps1`: only entry path and missing-entry message. `Assert-DesktopNativeManifest`, cohort inventory, receipt comparison, exit/cancellation/timeout policies are byte-exact.
- `tools/test/test-ahk-runner-arguments.cjs`: original isolated native argument probe reads the genuine shared prelude. All seven valid and ten invalid native input controls remain.
- `tools/test/test-windows-native-desktop.cjs`: additive actual source checks and refusals; all original eleven names, strict collector/workflow assertions, fourteen causal refusals and seventeen native PowerShell controls remain.

G6 no-overlap response `6083375308` is retained as coordination context. Root's broader Windows/native ownership request `6083850069` is pending. No workflow, schema, locale, generator, original console case file, framework, stubs or native child fixture is edited. Future ONEPAC includes outside the original extracted bootstrap are preserved in `run_all.ahk`.

## Preimages and preservation

`source-pairs.json` records sixteen original/candidate pairs plus all 57 retained input pins, including stage 0, actual canonical HEAD `2f0c13d643bdeb0c00746a1db610f13a44e4dfeb`, latest fetched `origin/dev` `d8243dae8a291fe1555233ad7c9da4583353594d`, and the actual native failure commit. All 43 non-workflow preimages are unchanged against actual HEAD, stage 0 and current upstream. Four workflow dependency images were updated **only in the private projection** to exact `d8243dae` for the final guard replay; their hashes are recorded separately in `upstream-pins.json`. No historical workflow image is proposed for adoption.

The source graph contains 28 original AHK runtime inputs and the same four original child inputs. Three shared owner files plus the native entry yield 32 actual compiled source images. Optional/dynamic/library/foreign/missing include targets are refused by the portable guard. An unresolved source never becomes an empty proof. This strict lexical source traversal is not a native compiler or AHK AST.

`qualify.cjs` establishes:

- Expanded original full runner code-token identity, including original include/execution order.
- Exact whole-file inverse for each local alpha-renaming, plus the exact inverse registration wrapper.
- Eleven actual original selected registrations and their callback body tokens unchanged (`selected-case-preservation.json`). Every original ordinary assertion/body expression is preserved modulo the one scoped ordinary-helper identifier rename.
- Original strict PowerShell collector fragment byte identity and whole-file identity after reversing its two invocation strings.
- Whole original argument JS AST after reversing only the common-reader seam.
- Whole original native desktop JS AST after peeling the nineteen additive module nodes and its one appended runner-path assertion; all 23 original module nodes remain in order (`native-guard-ast-preservation.json`).
- Unchanged watchdog meta source except its two source-owner path literals.
- All 28 original runtime and four native child input hashes.

`forward.patch` and `inverse.patch` round-trip all sixteen paths byte-exactly in a compact external directory. All proposed text is UTF-8/LF and every AHK image has BOM. Configured Prettier passes the three changed/new JS files. The retained `native-guard-addon.fragment.cjs` is an earlier unconsumed draft; the actual registered candidate is `projection/tools/test/test-windows-native-desktop.cjs` and the patch, never that draft fragment.

## Bounded tests and limits

- Private preservation/consumer qualification: **28 checks PASS**.
- Complete registered native desktop JS guard: original **14 causal refusals PASS**, plus **29 independent actual source refusals PASS**. These include foreign/duplicate prelude, missing original flag/parser/receipt, actual case substitution, omitted native sources, watchdog failure/publication/timeout changes, per-function old bindings, top-level registration pollution and graph-leaf warning waivers.
- The original `run_all` source is causally refused by the new actual shared-source consumer. Restoring all original local bindings in each of six functions, and separately the complete original registration loop, is refused. Independent omission of namespace consumption admits all six old bindings; omission of graph-leaf warning checks admits a real `#Warn LocalSameAsGlobal, Off` directive. These controls expose a causal consumer role without changing an original assertion.
- Named-function lexical reader: bounded literal/comment positive and duplicate/missing/unclosed negative controls PASS.
- Unchanged loop-capture guard: original fourteen fixtures and this compact source tree PASS. This is **not** a scan/qualification of the entire Windows driver.
- Native AHK argument cases: **SKIP on Linux**, original seven valid/ten invalid controls preserved.
- Native PowerShell receipt controls: **SKIP on Linux**, original seventeen controls preserved.
- Native AHK compiler, complete ordinary Windows suite, console five, AltGr six, physical input, package/installation: **UNRUN**.
- Full JS suite/generators/shared projections: **UNRUN** by this agent; Root owns final combined validation.

Windows CI must compile and run the actual final sources to settle any additional sparse-source runtime dependencies, exercise unchanged native argument/watchdog/meta guards and qualify both exact native cohorts with canonical unfiltered stdout/stderr/manifest receipts. Any newly observed warning or missing runtime dependency must be fixed at its actual owner. No timeout increase, warning filtering, empty receipt, disabled warning policy or weaker collector oracle is proposed.

The earlier frozen warning inventory (36 seals) and closure feasibility packet (eight seals) remain byte-exact; `ancestor-preservation.json` verifies all 44 seals. This preparation does not close TODO91/109 or claim physical/native success.
