# Inactive actual native latency handover

**READ-ONLY / INACTIVE / NO SOURCE PATCH / proposed profiling UNRUN.** Actual evidence is partial1954/10962:1952PASS,2FAIL,9008withoutterminalresult,nofooter. The unchanged22-minute watchdog fired. All11 earlier fixture failures and4fullsave families now actuallyPASS; nine genuine acquired-read temporal controls remainUNRUN. This is **TODO5/42 software performance and native CI work**, not device-only work. Do not add another diagnostic to canonicalRunAll before the original temporal controls can execute within its unchanged budget. No filter/shard/Count/prototype/index/authority-cache proposal is qualified.

Measured capacity:238768.561ms; Apply127281.460; refusal110858.479; Inspect16.951. Existing **ready capture_noop** guard32 costs397.775ms for32acceptedcalls; it has no active owned terminal bundle and cannot price transaction AllLive.

## Source ledger and static diagnosis

Exact current-source hashes are in `READ-ONLY-PHASE-AND-SOURCE-DIAGNOSIS-V2.json`; copied bytes are in `reference-inputs`.

| Source coordinates | Preserved contract / concrete observation |
|---|---|
|config_scope115–179|Apply includes typed rendering, extra image build, independent34backups and actualjournalprepare/apply. Rollback91–102 does not rerun this renderer; therefore rendering alone cannot explain110srefusal.|
|config_transition_runtime677–725,738–766|Constructor genuinely prepares/captures known config source; AllLive fresh canonical/native/locator/row guard before+after. UnboundedRead has outer before/after plus innerDispatch before/after =4AllLive calls. Present nonconfig snapshot exists2+read4+hash2 =8nominalguardpasses.|
|config_migrate976–1062,1328–1407|Fresh complete registry/native structural traversal remains. Recoveryimages are captured once atconstructor, not reissued perguard. Readyguard32 is distinct from owned transition/recoveryguard.|
|config_write_lease205–257,341–354,413–429,442–459|OwnsExact calls fullissuer; selector calls fullissuer again; each examined member calls fullissuer again. ForNtokens/kcandidatechecks, validOwnsExact has at least2+k full Ntoken walks (O(N*k), worstO(N²)); actualk/costunmeasured.|
|config_transition599–619,1034–1085,1257–1304,1476–1517|Every real snapshot uses exists/read/hash; prepare/apply/recovery preserve artifact/namespacepreflight, sideverification andcleanup. Real nativeIO/hash/flush costs remain unseparated.|
|file_system1005–1083|Actual config ACK/replacement/create/delete span consumes live finaladmission and original Win32receipt. GenericFS bodies stay untouched.|
|test_hotstrings_scope6–29,272–358|Real32personal+override+config files; existingreadyguard32 strictCountobserver/refusal/repair; unchanged genuine34target/backups/exactrollback subject.|

**Cardinality correction:**34target paths+locator establish35minimum distinct paths. The actual default acquisition additionally prepends global `ConfigurationFile` (`config_write_lease:297`), while runtime already adds fixtureconfig (`config_transition_runtime:358–370`). A distinct active config yields36tokens. Current phase log records no token count, so neither35nor36 is claimed observed. V1's exact35 wording is historical and superseded. This matters when pricing whole-bundle membership.

## Exact inactive profiling seam and invariants

Use the same original `ConfigTransitionAcquireLifecycleBundle` on `_HotstringsScopeFixture(32)` and all actual targets/locator/active-config paths. Record **actual original issued cardinality**; never omit an active config to create a faster35token surrogate. Retain existingfixture settle behavior and originalnativeissuance; coordinate nativelease/bootstrap ownership before sourcework.

A separate future authorized component diagnostic can time32 original `_ConfigWriteTerminalOwnsExact` calls,32 same captured **owned** sourceguard calls, and32 actual admitted originalport `exists` calls on the realconfig. Require literal successes32/32, realpresence1 and identicalnativebytes. The private forwardadapter is data only; canonical eight originalcallbacks remainsoleauthority. No customclonecertificate/publicREADY/metadataissuer/newACK may stand in for nativeadmission. No diagnostic subset qualifies the fullsuite.

Meaningful refusals remain mandatory: genuine owngetter withdrawal on issued tokenkey or canonicalregistryCount must refuse the same membership/guard/callback with **Hits0**, unchangedtargets/namespace and noacknowledgement. Restore exact originaldescriptor in mandatoryfinally; require sameheldbundle/guard success afterrepair, never reissue or reacquire to forgivewithdrawal. Clock/report/producer/refusal/repair exceptions must still release onlytheoriginalbundle andcleanonlyownedfixturepaths. No conditionalSkip or swallowedfailure.

Original34-store effect/pending/backup/byte-exactrollback assertions and deadline stay unchanged. Originalnine acquired-handle/nativeactivity/interleaving/foreignobserverzeroeffects/exactrepair controls must execute andpass before temporalqualification. Neither readyguard32 nor membershiptimings replace thosecontrols.

Current source does not prove an optimization from phase split alone. Removing nestedRead guards changes actualtemporalobservations; reducing issuer/member scans needs coordinated coherent nativeowner work and purity/custody proof eveninsideCritical (mutable namedhelper/prototype dispatch remains). No cached acceptedauthority may cross nativeyield or publicaliases. Keep proposalsinactive until actual component measurements and independent receiving proof establish cause/behavior.
