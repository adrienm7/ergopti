from pathlib import Path
import json,subprocess,hashlib
B=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-current-g1-union-independent');P=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-g1-published-union/freeze');Q=B/'projection';D='1028f6bd3eeb08a1aa50f96d1ad9738d2826d7bb';G='/workspace/ergopti';h=lambda b:hashlib.sha256(b).hexdigest();pins=json.loads((B/'source-pins.json').read_text());owned={r['path'] for r in json.loads((P/'receipt.json').read_text())['source_pairs']};generated={r['path'] for r in json.loads((P/'generation.json').read_text())['census'] if r['generated']}
for p in (P/'dependencies/g1-source').rglob('*'):
 if not p.is_file():continue
 n=str(p.relative_to(P/'dependencies/g1-source'))
 if n in owned or n in generated:continue
 b=subprocess.check_output(['git','show',D+':'+n],cwd=G);assert b==p.read_bytes();out=Q/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);pins['inputs'].append({'path':n,'sha256':h(b),'source':D,'context':'original G1 control dependency'})
(B/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(B/'results-attempt1.json').write_bytes((B/'results.json').read_bytes());(B/'logs/luajit-g1-ai-attempt1.log').write_bytes((B/'logs/luajit-g1-ai.log').read_bytes())
s=(B.parent/'review-linux93-current-g1-union.py').read_text();tail=s[s.index('results=[];env='):];header='from pathlib import Path\nimport subprocess,os,json\nB=Path('+repr(str(B))+');Q=B/"projection";R=B/"review-scripts";P=Path('+repr(str(P))+')\ndef put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)\ndef j(p,v):put(p,(json.dumps(v,indent=2)+"\\n").encode())\n';exec(header+tail)
