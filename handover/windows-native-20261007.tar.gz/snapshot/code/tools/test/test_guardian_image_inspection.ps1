# tools/test/test_guardian_image_inspection.ps1
<#
==============================================================================
MODULE: Guardian Image Inspection Recording Controls
DESCRIPTION:
Runs the actual builder function and actual host/bridge call in Windows PS5.
Only dumpbin is a recording port; no image, compiler, daemon or driver is run.
==============================================================================
#>
[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$Repository)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSEdition -cne 'Desktop') {
    throw 'Guardian inspection controls require actual Windows PowerShell 5.'
}
$builderPath = [IO.Path]::Combine($Repository, 'tools', 'build', 'build_windows_ollama_guardian.ps1')
$tokens = $null
$parseErrors = $null
$tree = [Management.Automation.Language.Parser]::ParseFile($builderPath, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw 'The actual builder source has parse errors.' }
$definitions = @($tree.FindAll({ param($node)
    $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Assert-GuardianImage'
}, $true))
$calls = @($tree.FindAll({ param($node)
    $node -is [Management.Automation.Language.CommandAst] -and $node.GetCommandName() -ceq 'Assert-GuardianImage'
}, $true))
if ($definitions.Count -ne 1 -or $calls.Count -ne 1) {
    throw 'The actual image inspection function and build-loop call must each be unique.'
}
. ([scriptblock]::Create($definitions[0].Extent.Text))
$script:GII_Call = [scriptblock]::Create($calls[0].Extent.Text)
$recipePath = [IO.Path]::Combine($Repository, 'tools', 'build', 'windows_ollama_guardian_recipe.json')
$recipe = [IO.File]::ReadAllText($recipePath, [Text.UTF8Encoding]::new($false, $true)) | ConvertFrom-Json
$script:GII_Exports = @($recipe.exports)
if ($script:GII_Exports.Count -lt 2 -or @($script:GII_Exports | Where-Object {
    $_ -isnot [string] -or $_ -cnotmatch '^[A-Za-z_][A-Za-z0-9_]*$'
}).Count -ne 0) { throw 'The actual recipe needs its complete typed export list.' }
$script:GII_Port = $null

function Assert-GII([bool]$Value, [string]$Reason) {
    if (-not $Value) { throw $Reason }
}
function Reset-GII {
    $script:GII_Port = @{ calls = [Collections.Generic.List[object]]::new();
        dependencies = @('    KERNEL32.dll'); dependency_exit = 0;
        exports = @($script:GII_Exports); export_exit = 0 }
}
function dumpbin.exe {
    param([Parameter(ValueFromRemainingArguments = $true)][object[]]$Arguments)
    Assert-GII ($Arguments.Count -eq 3 -and $Arguments[0] -ceq '/nologo') 'The actual dumpbin argument shape changed.'
    $expected = (Get-Variable -Name ExpectedExports -Scope 1 -ErrorAction Stop).Value
    $script:GII_Port.calls.Add(@{ mode = [string]$Arguments[1]; image = [string]$Arguments[2];
        expected_null = $null -eq $expected; expected = @($expected) })
    if ($Arguments[1] -ceq '/dependents') {
        $global:LASTEXITCODE = $script:GII_Port.dependency_exit
        return $script:GII_Port.dependencies
    }
    Assert-GII ($Arguments[1] -ceq '/exports') 'The actual dumpbin inspection mode changed.'
    $global:LASTEXITCODE = $script:GII_Port.export_exit
    $ordinal = 0
    foreach ($name in $script:GII_Port.exports) {
        ++$ordinal
        '    {0} 0 00001000 {1}' -f $ordinal, $name
    }
}
function Invoke-GII([string]$kind) {
    $image = 'recording-' + $kind + '.exe'
    $plan = [pscustomobject]@{ recipe = [pscustomobject]@{ exports = @($script:GII_Exports) } }
    & $script:GII_Call
}
function Require-GIIRefusal([string]$Kind, [string]$Reason) {
    $refused = $null
    try { Invoke-GII $Kind } catch { $refused = $_ }
    Assert-GII ($null -ne $refused -and $refused.Exception.Message -ceq $Reason) 'The actual inspection refused for an unexpected reason or admitted the image.'
}
$controls = @(
    @{ name = 'host empty export array remains non-null at the actual inspection'; body = {
        Reset-GII
        Invoke-GII 'host'
        Assert-GII ($script:GII_Port.calls.Count -eq 1) 'A host must inspect dependencies exactly once without exporting.'
        Assert-GII (-not $script:GII_Port.calls[0].expected_null) 'The actual host call lost its empty array to null.'
        Assert-GII ($script:GII_Port.calls[0].expected.Count -eq 0) 'The host acquired unexpected export requirements.'
        Assert-GII ($script:GII_Port.calls[0].image -ceq 'recording-host.exe') 'The exact host inspection target changed.'
    } },
    @{ name = 'bridge exact typed export list is inspected unchanged'; body = {
        Reset-GII
        Invoke-GII 'bridge'
        Assert-GII ($script:GII_Port.calls.Count -eq 2) 'The bridge must inspect dependencies and exports.'
        Assert-GII (-not $script:GII_Port.calls[0].expected_null) 'The bridge export list became null.'
        Assert-GII (@(Compare-Object $script:GII_Exports $script:GII_Port.calls[1].expected -CaseSensitive).Count -eq 0) 'The actual bridge call replaced its exact export list.'
        Assert-GII ($script:GII_Port.calls[1].mode -ceq '/exports') 'The bridge did not inspect its export table.'
    } },
    @{ name = 'bridge missing export remains refused'; body = {
        Reset-GII
        $script:GII_Port.exports = @($script:GII_Exports | Select-Object -First ($script:GII_Exports.Count - 1))
        Require-GIIRefusal 'bridge' 'The exact guardian bridge ABI export table differs from its definition.'
    } },
    @{ name = 'bridge foreign export remains refused'; body = {
        Reset-GII
        $script:GII_Port.exports += 'FOREIGN_RECORDING_EXPORT'
        Require-GIIRefusal 'bridge' 'The exact guardian bridge ABI export table differs from its definition.'
    } },
    @{ name = 'host dynamic compiler runtime remains refused before empty-export admission'; body = {
        Reset-GII
        $script:GII_Port.dependencies = @('    VCRUNTIME140.dll')
        Require-GIIRefusal 'host' 'A guardian image requires a dynamic compiler runtime.'
        Assert-GII ($script:GII_Port.calls.Count -eq 1) 'A refused dynamic runtime cannot advance to export inspection.'
    } },
    @{ name = 'host dependency inspection native refusal remains fatal'; body = {
        Reset-GII
        $script:GII_Port.dependency_exit = 7
        Require-GIIRefusal 'host' 'The guardian dependency inspection failed.'
        Assert-GII ($script:GII_Port.calls.Count -eq 1) 'A failed dependency inspection cannot advance.'
    } },
    @{ name = 'bridge export inspection native refusal remains fatal'; body = {
        Reset-GII
        $script:GII_Port.export_exit = 9
        Require-GIIRefusal 'bridge' 'The guardian export inspection failed.'
    } },
    @{ name = 'legacy subexpression transports null while array expression retains emptiness'; body = {
        $legacy = $(if ($false) { @('unused') } else { @() })
        $array = @(if ($false) { @('unused') } else { @() })
        Assert-GII ($null -eq $legacy) 'The old PS5 empty subexpression premise differs.'
        Assert-GII ($null -ne $array -and $array.Count -eq 0) 'The explicit array expression must retain an empty array.'
    } }
)
[Console]::Out.WriteLine('1..8')
for ($index = 0; $index -lt $controls.Count; ++$index) {
    try {
        & ($controls[$index].body)
        [Console]::Out.WriteLine('ok ' + ($index + 1) + ' - ' + $controls[$index].name)
    } catch {
        [Console]::Out.WriteLine('not ok ' + ($index + 1) + ' - ' + $controls[$index].name)
        [Console]::Error.WriteLine('Actual guardian inspection control refused; expected_exports_null=' +
            $(if ($null -ne $script:GII_Port -and $script:GII_Port.calls.Count -gt 0) {
                [string]$script:GII_Port.calls[0].expected_null
            } else { 'unobserved' }))
        exit 1
    }
}
exit 0
