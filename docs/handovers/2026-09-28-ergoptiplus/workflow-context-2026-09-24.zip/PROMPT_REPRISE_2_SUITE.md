# Prompt de reprise n° 2 — terminer la todo de la refonte (dans quelques jours)

Colle ce texte dans une session neuve de Claude Code ouverte dans
`D:/Documents/GitHub/ergopti`, après la release préparée avec
`PROMPT_REPRISE_1_RELEASE.md`. Cette session-là a dû mettre à jour ce fichier ;
si ce n'est pas le cas, reconstruis l'état avec
`git log origin/dev` et le journal cité plus bas.

---

Objectif : implémenter le reste de la refonte ErgoptiPlus, par-dessus `dev` à
jour.

## 0. Règles impératives

- Lis `AGENTS.md`, `docs/memory/README.md` et les skills
  `workflow-change-control`, `orchestrate-pass`, `verify-change`,
  `cross-driver-parity`, `i18n` et `commit-and-push`.
- Ne jamais arrêter un workflow en cours pour y ajouter une demande : route-la
  vers un run suivant. Mesure les durées avec les horodatages, jamais au nombre
  de messages.
- Quota limité : au plus 3 à 4 agents en parallèle. Chaque prompt d'agent dit
  dès le départ : « inspecte ta copie (git log base..HEAD, git status) et
  continue le travail existant ». Chaque lane s'arrête après deux échecs
  consécutifs. Un relecteur séparé seulement pour les tâches à risque.
- **Commence toujours par `git fetch origin dev`** et fais partir chaque
  nouvelle branche du `dev` à jour : j'y pousse souvent des correctifs Linux.
- Ne pousse jamais `dev` ni `main` sans mon accord explicite. Pousser une
  branche de fonctionnalité est permis.

## 1. Contexte

- **Demandes :** `D:/ewt/_context/feature_map_script_with_R1-R35.js` (R1 à R35).
  R36 correspond aux 3 touches personnalisables (tâche D6).
- **Décisions produit validées et spec de chaque tâche :**
  `D:/ewt/_context/overhaul_workflow_script.js` (constantes `DECISIONS` et
  `LANES`).
- **Rapports d'analyse :** `D:/ewt/_context/map/`.
- **Journal des runs précédents :**
  `C:/Users/admin/.claude/projects/D--Documents-GitHub-ergopti/7b42cfbe-60d7-41bb-87b3-b1a03baf7926/subagents/workflows/wf_97b8817b-99f/journal.jsonl`.
- **L'amont a retiré kanata sous Linux :** le démon exécute les tap-holds et la
  couche de navigation (`linux/platform/remap/tap_hold_engine.lua`,
  `tap_hold_loader.lua`, `tap_hold_manager.lua`). Toute tâche touchant les
  tap-holds ou la couche de nav Linux part de ce moteur.

## 2. Tâches restantes (spec détaillée de chacune dans `LANES`)

- **W1 :**
  - défauts neutres : config vide = comportement de l'OS, toute fonctionnalité
    qui modifie la saisie désactivée par défaut ;
  - valeurs « conseillées » séparées dans le manifest ;
  - persistance clairsemée ;
  - « Restaurer les valeurs conseillées » et « Tout effacer (comportement du
    système) » par périmètre.

  Pas de migration à prévoir : il n'y a pas encore d'utilisateurs.
- **W2 :** assistant de premier lancement, une page par sous-menu (« Activer »,
  non par défaut, avec une liste dépliable des réglages conseillés à importer),
  lancé automatiquement sur les 3 OS quand `config.toml` est absent.
- **Trou A1 :** les items d'un sous-menu désactivé restent actifs et
  modifiables. Sous Windows, il faut d'abord changer le modèle d'état
  (`ApplyMasterGatesToFeatures`).
- **A4 :** sous-menu Tap-Hold avec « Main gauche — Tap / Hold » et « Main
  droite — Tap / Hold » ; sous-menu « Combinaisons de touches » sous Raccourcis,
  avec sa propre case à cocher ; catalogue de touches partagé.
- **A5 :** avertissements de conflit avec les gestes système, ligne de statut
  ✓/⚠ et « Réglages des gestes du système… ».
- **B4 :** la console de débogage s'ouvre grande et centrée.
- **C4 :** fenêtre de résultat de la vérification centrée, sur 2 lignes, avec
  les boutons Fermer / Mettre à jour, le canal vérifié et une ligne par autre
  canal plus récent ; localisation de Sparkle. Plus les trous de C2/C3, dont la
  fréquence de vérification macOS.
- **D3 :** 4 actions Spaces / bureaux (normal et circulaire) ; retrait de
  `space_wrap`.
- **D4 :**
  - action « générer une prédiction IA » sur les 3 OS, avec un retour visible à
    chaque refus ;
  - raccourcis conseillés Ctrl+Espace (macOS), Win+Espace (Windows),
    Super+Espace (Linux), touches avalées ;
  - retrait des anciens réglages de raccourci déclencheur ;
  - libellé « Modèle sélectionné » et pluriel corrigé ;
  - « Nombre de suggestions » déplacé dans les paramètres de génération.
- **D5 :** actions inspirées de Shortcutie, SANS « fermer toutes les apps »
  (confirmation pour la suppression de la quarantaine et pour vider la
  corbeille).
- **Trou D2 :** `copy_selected_path` sous Linux.
- **F2 :** interrupteur Karabiner respecté ; « Retirer Ergopti de Karabiner » ;
  sauvegarde et restauration du registre du pavé tactile Windows ; état du
  guardian de remap dans le diagnostic.
- **N3 :** éditeur web de la couche de navigation (clavier visuel, pavé
  numérique, clics, molette), qui écrit `layers.toml` et alimente le moteur de
  chaque driver ; entrée « Éditer la couche de navigation… ».
- **Plus tard :** Optimot, quand son auteur aura donné son accord. Il suffira
  de déposer son `.keylayout` dans le dossier du registre.

## 3. Méthode

Découpe en 2 ou 3 runs courts de 3 ou 4 lanes chacun, chaque lane sur son propre
worktree (sous `C:/ewtb/` ou `D:/ewt/`), créé depuis le `dev` à jour. Chaque
tâche est livrée en TDD (le test échoue d'abord), avec des commits atomiques et
la parité sur les 3 OS et les 21 locales.

À la fin de chaque run :
1. intègre les lanes sur une branche de fonctionnalité, par cherry-pick
   linéaire ;
2. refais `git fetch origin dev` et rebase ;
3. lance les vérifications complètes, pousse la branche de fonctionnalité et
   suis la CI ;
4. présente-moi un bilan et attends mon accord avant de pousser `dev`.
