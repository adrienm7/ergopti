'use strict';
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
for(const [id,sensitive,expectedChars,expectedBigrams] of [['capital-i-dot',true,2,1],['separate-combining-dot',true,3,2],['separate-combining-dot',false,3,2],['capital-i-dot',false,2,1]]) {
 const page=loadMetricsTypingPage('windows');
 const native=JSON.parse(fs.readFileSync('/workspace/scratch/windows-audit-round6/ui-metrics/expanding-case-native-producer/'+id+'.json','utf8'));
 const blob={metrics_manifest:native.manifest,_prefetch_data:native.range,app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}};
 page.messageListeners.filter(e=>e.name==='message').at(-1).callback({data:{type:'prefetch',blob}});
 if(sensitive)page.elements.get('btn_case_sensitive').classList.add('active');else page.elements.get('btn_case_sensitive').classList.remove('active');
 page.context.apply_local_filters();
 vm.runInContext("app_state.current_tab='c'",page.context);page.context.render_current_tab();page.timers.at(-1)();
 const chars=JSON.parse(vm.runInContext('JSON.stringify(app_state.rendered_list.map(r=>({key:r.key,count:r.count})))',page.context));
 vm.runInContext("app_state.current_tab='bg'",page.context);page.context.render_current_tab();page.timers.at(-1)();
 const bigrams=JSON.parse(vm.runInContext('JSON.stringify(app_state.rendered_list.map(r=>({key:r.key,count:r.count})))',page.context));
 console.log(JSON.stringify({id,sensitive,chars,bigrams,expectedChars,expectedBigrams}));
 assert.equal(chars.reduce((total,r)=>total+r.count,0),expectedChars,'case mode preserves native character occurrences');
 assert.equal(bigrams.length,expectedBigrams,'case mode preserves native bigrams');
}
