#!/usr/bin/env python3
"""Replay authenticated native-HTTP prerequisites; never install host packages.

create accepts a NEW native-http-* prefix only. readmit never writes that prefix
and requires the caller's retained official admission digest. Neither mode runs
a project/native gate. Source/pin drift or rotated package identities refuse.
"""

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

EXPECTED = json.loads(
    r"""{"packages":[{"name":"girepository-tools","version":"2.84.4-3~deb13u5","architecture":"amd64","filename":"pool/main/g/glib2.0/girepository-tools_2.84.4-3~deb13u5_amd64.deb","sha256":"2498e412b01d5d77049829d525b7ff559fd4be269a59cc4a50479337a50d8619","bytes":152356,"authenticated_index":true},{"name":"gpgv","version":"2.4.7-21+deb13u1+b5","architecture":"amd64","filename":"pool/main/g/gnupg2/gpgv_2.4.7-21+deb13u1+b5_amd64.deb","sha256":"104e4c57b98f0b883aa94c68fbe7ec7b48bcdec7c0f9dedf2a51a5054aaeb5ae","bytes":241100,"authenticated_index":true},{"name":"libblkid-dev","version":"2.41.5-0+deb13u1","architecture":"amd64","filename":"pool/main/u/util-linux/libblkid-dev_2.41.5-0+deb13u1_amd64.deb","sha256":"775bc91f7a265d21cdfc6b710813017b2366e5c5bb665cd2e6979af5dd8a03a8","bytes":208756,"authenticated_index":true},{"name":"libffi-dev","version":"3.4.8-2","architecture":"amd64","filename":"pool/main/libf/libffi/libffi-dev_3.4.8-2_amd64.deb","sha256":"76b2b80193a656733e1408ebec5371334be5fd48eb5f50ab99d6baf6081d0f1b","bytes":61136,"authenticated_index":true},{"name":"libgcrypt20","version":"1.11.0-7+deb13u1","architecture":"amd64","filename":"pool/main/libg/libgcrypt20/libgcrypt20_1.11.0-7+deb13u1_amd64.deb","sha256":"f0eb41f8cb40896e0822e9ab65611e8383c12b721c76c54764f744abb4a8c247","bytes":843104,"authenticated_index":true},{"name":"libgio-2.0-dev","version":"2.84.4-3~deb13u5","architecture":"amd64","filename":"pool/main/g/glib2.0/libgio-2.0-dev_2.84.4-3~deb13u5_amd64.deb","sha256":"a9bbd748ddd40a08b336e8d6b1755e698957ac640d081ddc4c330b716c6b89c3","bytes":1691796,"authenticated_index":true},{"name":"libgio-2.0-dev-bin","version":"2.84.4-3~deb13u5","architecture":"amd64","filename":"pool/main/g/glib2.0/libgio-2.0-dev-bin_2.84.4-3~deb13u5_amd64.deb","sha256":"d43dddb9b306cb8427bd383e100b8510da8cfa03b5968624f3787bc66a5a95b8","bytes":168564,"authenticated_index":true},{"name":"libgirepository-2.0-0","version":"2.84.4-3~deb13u5","architecture":"amd64","filename":"pool/main/g/glib2.0/libgirepository-2.0-0_2.84.4-3~deb13u5_amd64.deb","sha256":"c87a2d4dac81be719fb3dc2e3a1d78376151d8c5c34071e08c10304b8d1fd3c3","bytes":144928,"authenticated_index":true},{"name":"libglib2.0-0t64","version":"2.84.4-3~deb13u5","architecture":"amd64","filename":"pool/main/g/glib2.0/libglib2.0-0t64_2.84.4-3~deb13u5_amd64.deb","sha256":"e2baf92c57d1db1753e5781a61450d9a01e7833c7bd2dfe87776a6811c11ecc2","bytes":1521120,"authenticated_index":true},{"name":"libglib2.0-dev","version":"2.84.4-3~deb13u5","architecture":"amd64","filename":"pool/main/g/glib2.0/libglib2.0-dev_2.84.4-3~deb13u5_amd64.deb","sha256":"ad98b1a769da55a8007ea9953306b0deb6092205d4fac8d915e2bd83d4ecc8a5","bytes":57744,"authenticated_index":true},{"name":"libglib2.0-dev-bin","version":"2.84.4-3~deb13u5","architecture":"amd64","filename":"pool/main/g/glib2.0/libglib2.0-dev-bin_2.84.4-3~deb13u5_amd64.deb","sha256":"d35ef75a4b04ea10081d484e025b0a4fecd0232ffc0e76403bcd249b3b47e643","bytes":56944,"authenticated_index":true},{"name":"libgpg-error0","version":"1.51-4","architecture":"amd64","filename":"pool/main/libg/libgpg-error/libgpg-error0_1.51-4_amd64.deb","sha256":"22b95570fd41c113ef6f5651563b4d748292844baab1278a46eb940c1dec2322","bytes":82108,"authenticated_index":true},{"name":"libmount-dev","version":"2.41.5-0+deb13u1","architecture":"amd64","filename":"pool/main/u/util-linux/libmount-dev_2.41.5-0+deb13u1_amd64.deb","sha256":"2bef03b918e927648c6552143e17e82aa7ed2a4ce180fabd07a7d1cac7ff8686","bytes":30740,"authenticated_index":true},{"name":"libselinux1-dev","version":"3.8.1-1","architecture":"amd64","filename":"pool/main/libs/libselinux/libselinux1-dev_3.8.1-1_amd64.deb","sha256":"0107595c65dd5cfe7ce3643d400e7b2be2c2528bcd110ad5af8605711a858921","bytes":169104,"authenticated_index":true},{"name":"libsepol-dev","version":"3.8.1-1","architecture":"amd64","filename":"pool/main/libs/libsepol/libsepol-dev_3.8.1-1_amd64.deb","sha256":"c085881d0546f6d539909f5710d7a3243aeb24338f6dc455b0ef6199f45bd753","bytes":372908,"authenticated_index":true},{"name":"libsysprof-capture-4-dev","version":"48.0-2","architecture":"amd64","filename":"pool/main/s/sysprof/libsysprof-capture-4-dev_48.0-2_amd64.deb","sha256":"3cb76e124187700f5977a0acb914b3f82b2bd28105fce6f1cf2a34497b234af2","bytes":49864,"authenticated_index":true},{"name":"native-architecture","version":"0.2.6","architecture":"all","filename":"pool/main/a/architecture-properties/native-architecture_0.2.6_all.deb","sha256":"cb065efb2dd0ad8de45ace298bdb959e4d66478ca8599312bde4fa543d8b7532","bytes":2264,"authenticated_index":true},{"name":"uuid-dev","version":"2.41.5-0+deb13u1","architecture":"amd64","filename":"pool/main/u/util-linux/uuid-dev_2.41.5-0+deb13u1_amd64.deb","sha256":"cb7d7db20e5d91193c2c6629a3f4aa917e3bc558c72b7f2db7203bcfa9a3ba1b","bytes":49068,"authenticated_index":true}],"sources":{"tools/test/fixtures/validation-curl/prepare_validation_keyring.py":"e6a55b865bb87f56783a203537b5db07b7a66191209d493c4159a2ccc28424a0","tools/test/fixtures/validation-curl/setup_validation_curl.py":"ebdbdccffab7a17cea7823736f156bb29129e1445aab7bae2d6f33711931f212","tools/test/fixtures/validation-curl/PINS.json":"e46c8011cf4a8da400dff797c3f09d34ac5cdc91fb04bbebbd4b44466432c8de","tools/test/linux-managed-http-evidence.cjs":"91c8fe210a75566d19fd7a60347cbef299bfadae8f7f1d1b10dda2014e6f19a2","tools/build/stage-linux-network-runtime.py":"ac48a4e9755fb2b9e9cbe35c81b097942bf7be76d14466e03b891b4c78f302f5","tools/test/run-linux-managed-http-native.cjs":"7bb793ed6329d47fb9e5ef14a5f2c6b7297d55b1d1d3768a1155ee19c576bf2d"},"apt_config_sha256":"1ffc5f1e878ea653d4116a0ad510bdc55221a9cae5dd8eab9e6853f81d68f638","apt_sources_sha256":"309219659268a8195e6c262fd9725ed3e24871e395afcf6c35b3f3034118e8cd"}"""
)
BASE = Path("/workspace/.ergopti-cloud")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    require(
        path.is_file() and not path.is_symlink(), "Regular input required: " + str(path)
    )
    return path.read_bytes()


def run(argv, cwd, env=None, timeout=120):
    p = subprocess.run(
        [str(v) for v in argv],
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    require(p.returncode == 0, "Prerequisite command refused: " + str(argv[0]))
    return p.stdout


def inputs(repo):
    require(
        repo.is_absolute() and repo.is_dir() and not repo.is_symlink(),
        "Canonical repository required",
    )
    for name, expected in EXPECTED["sources"].items():
        require(
            digest(regular(repo / name)) == expected,
            "Original owner/pin changed: " + name,
        )
    require(
        not os.getenv("LD_PRELOAD") and not os.getenv("LD_AUDIT"),
        "Loader injection refused",
    )


def root_check(root):
    require(
        root.is_absolute()
        and root.parent == BASE
        and re.fullmatch(r"native-http-[A-Za-z0-9._-]+", root.name),
        "Owned native-http prefix required",
    )
    require(root.resolve() == root, "Symlink prefix refused")
    s = root.lstat()
    require(
        stat.S_ISDIR(s.st_mode)
        and s.st_uid == os.geteuid()
        and stat.S_IMODE(s.st_mode) == 0o700,
        "Private owned prefix required",
    )


def environment(root):
    env = dict(os.environ)
    sdk = root / "sysroot"
    env["PATH"] = str(sdk / "usr/bin") + ":" + env["PATH"]
    env["LD_LIBRARY_PATH"] = str(sdk / "usr/lib/x86_64-linux-gnu") + (
        ":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else ""
    )
    env["PKG_CONFIG_PATH"] = (
        str(sdk / "usr/lib/x86_64-linux-gnu/pkgconfig")
        + ":"
        + str(sdk / "usr/share/pkgconfig")
        + (":" + env["PKG_CONFIG_PATH"] if env.get("PKG_CONFIG_PATH") else "")
    )
    env["ERGOPTI_MANAGED_NATIVE_GIO_SYSROOT"] = str(sdk)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def member_path(name):
    if name.startswith("./"):
        name = name[2:]
    p = PurePosixPath(name)
    require(
        not p.is_absolute() and ".." not in p.parts, "Unsafe package member refused"
    )
    return str(p)


def sdk_readmit(root):
    # Literal SHA identities came from authenticated signed APT observations;
    # mutable cached sdk-packages.json is never treated as authority.
    expected = {}
    for package in EXPECTED["packages"]:
        deb = root / "apt/debs" / Path(package["filename"]).name
        raw = regular(deb)
        require(
            len(raw) == package["bytes"] and digest(raw) == package["sha256"],
            "Authenticated SDK package differs",
        )
        data = run(["dpkg-deb", "--fsys-tarfile", deb], root)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            for m in archive:
                name = member_path(m.name)
                if m.isdir():
                    continue
                if m.isfile():
                    expected[name] = (
                        "file",
                        digest(archive.extractfile(m).read()),
                        m.mode & 0o777,
                    )
                elif m.issym():
                    expected[name] = ("link", m.linkname, None)
                else:
                    raise RuntimeError("Unsupported SDK package member type")
    sdk = root / "sysroot"
    actual = set()
    for here, dirs, files in os.walk(sdk, followlinks=False):
        base = Path(here)
        for name in list(dirs):
            p = base / name
            if p.is_symlink():
                files.append(name)
                dirs.remove(name)
        for name in files:
            p = base / name
            relative = p.relative_to(sdk).as_posix()
            actual.add(relative)
            require(relative in expected, "Unadmitted SDK file")
            kind, value, mode = expected[relative]
            if kind == "link":
                require(p.is_symlink() and os.readlink(p) == value, "SDK link differs")
            else:
                require(
                    digest(regular(p)) == value
                    and stat.S_IMODE(p.stat().st_mode) == mode,
                    "SDK payload differs",
                )
    require(actual == set(expected), "SDK payload incomplete")
    return len(actual)


def readmit(repo, root, admission_sha):
    inputs(repo)
    root_check(root)
    require(
        re.fullmatch("[0-9a-f]{64}", admission_sha),
        "External admission digest required",
    )
    admission = root / "tools/TOOLS-ADMISSION.json"
    require(
        digest(regular(admission)) == admission_sha,
        "Retained official admission differs",
    )
    payloads = sdk_readmit(root)
    pins_file = repo / "tools/test/fixtures/validation-curl/PINS.json"
    pins = json.loads(regular(pins_file))
    require(
        digest(regular(root / "keyring/trusted.gpg"))
        == pins["validation_keyring"]["aggregate"]["sha256"],
        "Private keyring differs",
    )
    require(
        digest(regular(root / "tools/modern.tar.xz")) == pins["modern"]["sha256"],
        "Official source differs",
    )
    require(
        digest(regular(root / "tools/InRelease")) == pins["legacy"]["inrelease_sha256"],
        "Signed legacy authority differs",
    )
    env = environment(root)
    # This original physical reader checks private root/receipt, real ELF hashes
    # and pinned legacy libraries; no success-shaped environment is fabricated.
    text = run(
        [
            "node",
            repo / "tools/test/linux-managed-http-evidence.cjs",
            "--tools-env",
            admission,
            root / "tools",
            pins_file,
        ],
        root,
        env,
    ).decode()
    tools = dict(line.split("=", 1) for line in text.splitlines())
    receipt = json.loads(regular(admission))
    for name in ("modern", "legacy"):
        child_env = dict(env)
        if name == "legacy":
            child_env["LD_LIBRARY_PATH"] = (
                str(root / "tools/legacy-libraries") + ":" + env["LD_LIBRARY_PATH"]
            )
        version = (
            run(
                [receipt["tools"][name]["path"], "--disable", "--version"],
                root,
                child_env,
            )
            .decode()
            .splitlines()[0]
        )
        require(
            version == receipt["tools"][name]["actual_version"],
            "Actual curl runtime differs",
        )
    with tempfile.TemporaryDirectory(
        prefix="native-http-readmit-", dir=BASE
    ) as temporary:
        status = run(
            [
                "gpgv",
                "--keyring",
                root / "keyring/trusted.gpg",
                "--status-fd",
                "1",
                "--output",
                Path(temporary) / "Release",
                root / "tools/InRelease",
            ],
            root,
            env,
        ).decode()
        signers = [
            line.split()[2]
            for line in status.splitlines()
            if line.startswith("[GNUPG:] VALIDSIG ")
        ]
        require(
            pins["legacy"]["required_signer"] in signers,
            "Original Debian signer refused",
        )
    flags = run(
        ["pkg-config", "--cflags", "--libs", "gio-2.0", "gmodule-2.0"],
        root,
        {**env, "PKG_CONFIG_SYSROOT_DIR": str(root / "sysroot")},
    ).decode()
    require(str(root / "sysroot") in flags, "Owned GIO SDK unavailable")
    inputs(repo)
    return {
        "state": "physically_readmitted",
        "root": str(root),
        "admission_sha256": admission_sha,
        "sdk_payload_files": payloads,
        "sdk_signed_packages": len(EXPECTED["packages"]),
        "pins_sha256": digest(regular(pins_file)),
        "native_gate_executed": False,
        "native_30_qualification": "UNEXECUTED",
        "tools_environment": tools,
    }


def create(repo, root, apt_config):
    inputs(repo)
    require(
        root.is_absolute()
        and root.parent == BASE
        and re.fullmatch(r"native-http-[A-Za-z0-9._-]+", root.name),
        "Owned destination required",
    )
    require(not root.exists() and not root.is_symlink(), "Existing prefix refused")
    require(
        apt_config == BASE / "apt/apt.conf"
        and digest(regular(apt_config)) == EXPECTED["apt_config_sha256"],
        "Original signed APT configuration differs",
    )
    require(
        digest(regular(BASE / "apt/sources.list")) == EXPECTED["apt_sources_sha256"],
        "Original signed APT source differs",
    )
    require(
        Path("/usr/include/openssl/ssl.h").is_file(),
        "Real /usr OpenSSL SDK is an external prerequisite",
    )
    root.mkdir(mode=0o700)
    for p in (
        "apt/lists/partial",
        "apt/cache/archives/partial",
        "apt/debs",
        "tmp",
        "sysroot",
    ):
        (root / p).mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, APT_CONFIG=str(apt_config), PYTHONDONTWRITEBYTECODE="1")
    options = [
        "-o",
        "Dir::State::lists=" + str(root / "apt/lists"),
        "-o",
        "Dir::Cache::archives=" + str(root / "apt/cache/archives"),
        "-o",
        "Dir::Cache::pkgcache=" + str(root / "apt/pkgcache.bin"),
        "-o",
        "Dir::Cache::srcpkgcache=" + str(root / "apt/srcpkgcache.bin"),
    ]
    run(["apt-get", *options, "update"], root, env, 180)
    for package in EXPECTED["packages"]:
        text = run(
            ["apt-cache", *options, "show", package["name"] + "=" + package["version"]],
            root,
            env,
        ).decode()
        matches = []
        for paragraph in text.strip().split("\n\n"):
            fields = dict(
                line.split(": ", 1)
                for line in paragraph.splitlines()
                if ": " in line and not line.startswith(" ")
            )
            if (
                fields.get("Package") == package["name"]
                and fields.get("Version") == package["version"]
                and fields.get("Architecture") == package["architecture"]
            ):
                matches.append(fields)
        expected = {
            "Filename": package["filename"],
            "SHA256": package["sha256"],
            "Size": str(package["bytes"]),
        }
        require(
            matches
            and all(
                all(fields.get(k) == v for k, v in expected.items())
                for fields in matches
            ),
            "Fresh signed SDK identity refused",
        )
        deb = root / "apt/debs" / Path(package["filename"]).name
        with urllib.request.urlopen(
            "https://deb.debian.org/debian/" + package["filename"], timeout=40
        ) as response:
            data = response.read()
        require(
            len(data) == package["bytes"] and digest(data) == package["sha256"],
            "SDK download differs",
        )
        deb.write_bytes(data)
        run(["dpkg-deb", "--extract", deb, root / "sysroot"], root)
    env = environment(root)
    env["TMPDIR"] = str(root / "tmp")
    jobs = [
        (
            "models",
            [
                "python3",
                "-B",
                repo / "tools/test/test_validation_keyring_preparation.py",
            ],
            120,
        ),
        (
            "keyring",
            [
                "python3",
                "-B",
                repo
                / "tools/test/fixtures/validation-curl/prepare_validation_keyring.py",
                "--repo",
                repo,
                "--destination",
                root / "keyring",
            ],
            320,
        ),
        (
            "setup",
            [
                "python3",
                "-B",
                repo / "tools/test/fixtures/validation-curl/setup_validation_curl.py",
                "--repo",
                repo,
                "--destination",
                root / "tools",
                "--openssl-prefix",
                "/usr",
                "--keyring",
                root / "keyring/trusted.gpg",
                "--jobs",
                "2",
            ],
            1850,
        ),
    ]
    for label, argv, timeout in jobs:
        with (
            (root / (label + ".stdout.private")).open("xb") as out,
            (root / (label + ".stderr.private")).open("xb") as err,
        ):
            p = subprocess.run(
                [str(x) for x in argv],
                cwd=root,
                env=env,
                stdout=out,
                stderr=err,
                timeout=timeout,
            )
        require(p.returncode == 0, "Official preparation refused: " + label)
    sha = digest(regular(root / "tools/TOOLS-ADMISSION.json"))
    result = readmit(repo, root, sha)
    activation = root / "activate-native-http-replay.sh"
    values = result["tools_environment"]
    lines = [
        "# Validation-only environment; source after the standard cloud activation.",
        "export PATH=" + shlex.quote(str(root / "sysroot/usr/bin")) + ':"$PATH"',
        "export LD_LIBRARY_PATH="
        + shlex.quote(str(root / "sysroot/usr/lib/x86_64-linux-gnu"))
        + "${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}",
        "export PKG_CONFIG_PATH="
        + shlex.quote(
            str(root / "sysroot/usr/lib/x86_64-linux-gnu/pkgconfig")
            + ":"
            + str(root / "sysroot/usr/share/pkgconfig")
        )
        + "${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}",
        "export ERGOPTI_MANAGED_NATIVE_GIO_SYSROOT="
        + shlex.quote(str(root / "sysroot")),
    ]
    lines.extend(
        "export " + key + "=" + shlex.quote(value) for key, value in values.items()
    )
    activation.write_text("\n".join(lines) + "\n")
    result["activation"] = str(activation)
    result["activation_sha256"] = digest(regular(activation))
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("mode", choices=("readmit", "create"))
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--expected-admission-sha256")
parser.add_argument("--apt-config", type=Path, default=BASE / "apt/apt.conf")
args = parser.parse_args()
try:
    if args.mode == "readmit":
        result = readmit(args.repo, args.root, args.expected_admission_sha256 or "")
    else:
        result = create(args.repo, args.root, args.apt_config)
    print(json.dumps(result, indent=2))
except Exception:
    print(
        "Native HTTP prerequisite replay refused; no native qualification claimed.",
        file=sys.stderr,
    )
    raise
