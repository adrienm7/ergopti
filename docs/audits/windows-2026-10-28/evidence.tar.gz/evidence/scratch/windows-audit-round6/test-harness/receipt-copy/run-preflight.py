from pathlib import Path
import subprocess,json,sys,hashlib
root=Path('/workspace/ergopti-windows-r6-tests');packet=Path(__file__).parent
for name,expected in json.loads((packet/'candidate-hashes.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected
commands=[['node','tools/test/verify-change.cjs','--plan'],['node','tools/test/test-ahk-encoding.cjs'],['node','tools/test/test-ahk-loop-capture.cjs'],['node','tools/test/find-false-greens.cjs'],['node','tools/lint/lint-conventions.js','--fail-on-violations']]
results=[]
for argv in commands:
 print('EXECUTE '+repr(argv),flush=True)
 result=subprocess.run(argv,cwd=root)
 results.append({'argv':argv,'exit_code':result.returncode})
 (packet/'preflight-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if result.returncode:sys.exit(result.returncode)
