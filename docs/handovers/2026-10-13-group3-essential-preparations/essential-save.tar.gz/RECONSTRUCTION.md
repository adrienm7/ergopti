# Reconstruction limits and omitted duplicates

The Mac40 consumer's two exact preimages plus complete proposal.patch reconstruct
the pinned host `daf9981e...` and forty-case fixture `b968cfb1...`. Their whole
postimage duplicates and already integrated MacV3 proposal are deliberately not
copied. Original receiver paths remain raw provenance and must be rebound only
through a separately reviewed receiving packet after restoration. Do not execute
the stored absolute commands directly from this capsule.

The guard packet's duplicate `original/physical_slots.ahk` is represented once by
`ahk/metadata/physical_slots.ahk.raw`, exact SHA074275bb. Restore that original path
from this same byte image if constructing a private standalone guard fixture.
The original Lua and unchanged script-source helper are saved with the V3 guard.
Independent registry/corpus bytes are saved once; no expectation is regenerated.

Connected107 reconstruction starts with the four saved V4 preimages (frozen V3
bytes), applies the exact V3→V4 Hook delta, then V4→union Capture delta. Original
inverse/composition records bind every resulting whole hash. The alternative
current108→union Capture patch retains committed108 bytes; reconcile its exact
current source first. This is inactive reconstruction, not adoption. Original
Reader/core/native corpus and Xi/server/output receiving prerequisites stay at
their recorded source owners and must be rejoined before any receiving.

The public129 archive is referenced by hash and not copied. Its original manifest
is retained as a small provenance reference; it does not contain the newer
connected107 Shift correction/108 union. Root/G1 owns the warning correction;
only the source-only review/reference is saved, never its patch or fixtures.

All original raw labels and old statuses are byte-exact historical evidence.
HANDOVER.md records the new parent-supplied current checkpoint. No generated
product output, binary, SDK, real G5 publisher source, integrated Mac/Linux
software packet, full checkout/cache or public archive is added.
