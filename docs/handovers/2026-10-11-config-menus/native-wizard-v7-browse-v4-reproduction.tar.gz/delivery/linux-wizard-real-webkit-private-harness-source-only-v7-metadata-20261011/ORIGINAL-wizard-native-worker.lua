-- Private native receiving scenario. Production modules and file authorities
-- remain intact; this is an X11/WebKit UI subject, not an installed daemon.
local mode, target, receipt_path = assert(arg[1]), assert(arg[2]), assert(arg[3])
local report = { mode = mode, status = "running", assertions = {}, cleanup = {},
	limitations = { "no physical input", "no native Browse picker", "no daemon restart" } }
local Json = require("json")
local Manager, Gtk, GLib

local function check(value, name)
	report.assertions[#report.assertions + 1] = { name = name, passed = value == true }
	print((value == true and "PASS " or "FAIL ") .. name)
	assert(value == true, name)
end

local function read(path)
	local file, detail, errno = io.open(path, "rb")
	if not file then return nil, detail, errno end
	local read_ok, bytes, read_error = pcall(file.read, file, "*a")
	local close_ok, closed, close_error = pcall(file.close, file)
	if not close_ok or closed ~= true then
		report.cleanup.stream_errors = report.cleanup.stream_errors or {}
		report.cleanup.stream_errors[#report.cleanup.stream_errors + 1] = tostring(close_ok and close_error or closed)
	end
	-- The original read failure remains primary even if its held stream also
	-- refuses close. A successful read needs the actual close acknowledgement.
	if not read_ok then error(bytes, 0) end
	if type(bytes) ~= "string" then error(tostring(read_error or "native file read failed"), 0) end
	if not close_ok or closed ~= true then error(tostring(close_ok and close_error or closed), 0) end
	return bytes
end

local function pump()
	-- Bound each dispatch batch; a recurring source must not monopolize the probe.
	for _ = 1, 100 do
		if not Gtk.events_pending() then break end
		Gtk.main_iteration_do(false)
	end
	GLib.usleep(20000)
end

local function wait(predicate, seconds)
	local deadline = GLib.get_monotonic_time() + (seconds or 15) * 1000000
	repeat
		pump()
		if predicate() then return true end
	until GLib.get_monotonic_time() >= deadline
	return false
end

local function evaluate(source)
	local view = assert(Manager.webview_for("onboarding"), "actual onboarding WebView missing")
	local done, answer, failure = false, nil, nil
	view:run_javascript(source, nil, function(_, result)
		local called, value = pcall(function()
			return view:run_javascript_finish(result):get_js_value():to_string()
		end)
		if called then answer = value else failure = tostring(value) end
		done = true
	end, nil)
	assert(wait(function() return done end, 10), "actual WebKit evaluation deadline")
	assert(not failure, failure)
	return answer
end

local function page_ready()
	return wait(function()
		return evaluate("String(typeof _platform==='string' && _platform==='linux' && document.querySelectorAll('#lang-list .lang-item').length===21)") == "true"
	end)
end

local function step()
	return evaluate("String(_steps[_stepIndex])")
end

local function click_next(expected)
	check(evaluate("String(!document.getElementById('btn-next').disabled)") == "true", "Next admitted at " .. expected)
	evaluate("document.getElementById('btn-next').click(); 'clicked'")
	check(wait(function() return step() == expected end), "actual navigation to " .. expected)
end

local function english()
	evaluate("document.querySelector('#lang-list .lang-item[data-code=\"en\"]').click(); 'clicked'")
	check(wait(function()
		return evaluate("String(_selectedLocale==='en' && document.title==='ErgoptiPlus — Setup')") == "true"
	end), "actual English locale preview arrives")
end

local function close_native()
	local view = assert(Manager.webview_for("onboarding"))
	view:get_toplevel():close()
	check(wait(function() return not Manager.is_visible("onboarding") end), "native GTK close retires wizard")
end

local environment_ok, environment_error = pcall(function()
	assert(os.getenv("DISPLAY") or os.getenv("WAYLAND_DISPLAY"), "no genuine display")
	local lgi = require("lgi")
	Gtk, GLib = lgi.require("Gtk", "3.0"), lgi.GLib
	lgi.require("WebKit2", "4.1")
end)

local passed, failure = false, environment_error
if environment_ok then
	passed, failure = xpcall(function()
		local Paths = require("infra.config_paths")
		local I18n = require("infra.i18n")
		I18n.init()
		Manager = require("ui.webview_manager")
		-- No injected persistence/prepare/input/restart callbacks or mocked capabilities.
		Manager.set_daemon_state({})
		local Startup = require("ui.onboarding.startup")
		local startup_error
		local shown = Startup.run({ graphical = true, path = Paths.config("config.toml"),
			show = function(app) return Manager.show(app) == true end,
			fail = function(detail) startup_error = detail end })
		check(shown == true and startup_error == nil, "genuine first-use startup is admitted")
		if mode == "reopen" then
			check(Paths.get_config_dir() == target, "new process reads persisted moved folder")
			check(I18n.get_locale() == "en", "new process reads persisted English locale")
			check(not Manager.is_visible("onboarding"), "configured startup does not reopen wizard")
			local original = assert(read(target .. "/config.toml"))
			check(Manager.show("onboarding") == true, "explicit real rerun opens wizard")
			check(page_ready(), "rerun page receives genuine host data")
			check(evaluate("String(_configDir)") == target, "rerun DOM has persisted folder")
			click_next("config")
			click_next("tap_holds")
			check(wait(function() return evaluate("String(!_configPending)") == "true" end), "rerun chosen-folder read acknowledged")
			local Manifest = require("infra.manifest_reader")
			local master_pages = { shortcuts = "shortcuts.enabled", gestures = "gestures.enabled",
				llm = "llm.enabled", metrics = "metrics.enabled" }
			for _, path in ipairs({ "shortcuts.enabled", "gestures.enabled", "llm.enabled", "metrics.enabled" }) do
				check(Manifest.default_for(path) == false, "actual native declared off default " .. path)
				local quoted = assert(Json.encode(path))
				check(evaluate("String(!Object.prototype.hasOwnProperty.call(_current," .. quoted .. ") || _current[" .. quoted .. "]===false)") == "true", "rerun current value " .. path)
			end
			check(Manifest.default_for("category_enabled.key_combinations") == true,
				"actual native key-combinations default is on")
			check(evaluate("String(_current['category_enabled.key_combinations']===false)") == "true",
				"rerun receives explicit key-combinations off value")
			local pages = { "tap_holds", "shortcuts", "gestures", "keyboard_layout", "hotstrings", "llm", "metrics" }
			for index, page in ipairs(pages) do
				check(step() == page, "rerun real page order " .. page)
				if master_pages[page] then
					local quoted_page = assert(Json.encode(page))
					check(evaluate("String(_pageState[" .. quoted_page .. "].answer===false && document.getElementById('page-no').checked && !document.getElementById('page-yes').checked)") == "true",
						"fresh-process visible native off state " .. master_pages[page])
				end
				if index < #pages then click_next(pages[index + 1]) end
			end
			close_native()
			check(read(target .. "/config.toml") == original, "rerun cancellation preserves exact config bytes")
		else
			check(Manager.is_visible("onboarding"), "absent config offers actual wizard")
			check(page_ready(), "real page owns ready and receives 21 locale rows")
			english()
			if mode == "cancel" then
				click_next("config")
				close_native()
				local bytes, _, errno = read(Paths.config("config.toml"))
				check(bytes == nil and errno == 2, "fresh cancellation does not create config")
			elseif mode == "finish" then
				-- Reaching this mode in a fresh process proves cancellation was not completion.
				click_next("config")
				evaluate("document.getElementById('config-input').value=" .. assert(Json.encode(target)) .. "; 'entered'")
				click_next("tap_holds")
				check(wait(function() return evaluate("String(!_configPending)") == "true" end), "real moved-folder read acknowledged")
				local metrics_path = os.getenv("XDG_DATA_HOME") .. "/ergopti/metrics.sqlite"
				check(wait(function() return evaluate("String(_metricsPath)") == metrics_path end), "metrics store remains in actual XDG data folder")
				local pages = { "tap_holds", "shortcuts", "gestures", "keyboard_layout", "hotstrings", "llm", "metrics" }
				check(evaluate("String(_steps.length)") == "9", "seven declared pages after two opening steps")
				for index, page in ipairs(pages) do
					check(step() == page, "genuine page order " .. page)
					evaluate("var n=document.getElementById('page-no'); n.checked=true; n.dispatchEvent(new Event('change',{bubbles:true})); 'chosen'")
					check(evaluate("String(document.getElementById('page-no').checked)") == "true", "explicit No choice " .. page)
					if index < #pages then click_next(pages[index + 1]) end
				end
				check(evaluate("String(!document.getElementById('btn-next').disabled)") == "true", "actual Finish is admitted")
				-- Finish may destroy the view before JavaScript completion; do not require
				-- an artificial reply or suppress the actual native retirement.
				Manager.webview_for("onboarding"):run_javascript("document.getElementById('btn-next').click()", nil, nil, nil)
				check(wait(function() return not Manager.is_visible("onboarding") end, 25), "genuine Finish commits and retires native window")
				check(type(read(target .. "/config.toml")) == "string", "actual moved-folder config exists after Finish")
				check(Paths.get_config_dir() == target, "current resolver confirms actual folder publication")
				check(I18n.get_locale() == "en", "current locale confirms actual persistence acknowledgement")
			else error("unsupported private scenario: " .. mode) end
		end
	end, debug.traceback)
end

-- Attempt independent cleanup even after any assertion or native callback failure.
if Manager then
	local called, retired = pcall(Manager.shutdown)
	report.cleanup.manager_called, report.cleanup.manager_retired = called, called and retired == true
	if not called or retired ~= true then
		passed = false
		report.cleanup.error = tostring(retired)
		if failure == nil then failure = "actual manager cleanup refused: " .. tostring(retired) end
	end
end
report.status = environment_ok and (passed and "PASS" or "FAIL") or "ENVIRONMENT_UNRUN"
report.failure = not passed and tostring(failure) or nil
if not passed then io.stderr:write(tostring(failure), "\n") end
local receipt, open_error = io.open(receipt_path, "wb")
local receipt_ok = false
if receipt then
	local write_ok, written, write_error = pcall(function()
		return receipt:write(assert(Json.encode(report)), "\n")
	end)
	local close_ok, closed, close_error = pcall(receipt.close, receipt)
	receipt_ok = write_ok and written ~= nil and close_ok and closed == true
	if not receipt_ok then
		io.stderr:write("Native receipt write/close refused: ", tostring(write_ok and write_error or written),
			" / ", tostring(close_ok and close_error or closed), "\n")
	end
else io.stderr:write("Native receipt open refused: ", tostring(open_error), "\n") end
if not receipt_ok then os.exit(1) end
os.exit(environment_ok and (passed and 0 or 1) or 2)
