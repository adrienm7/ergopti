import sys, re
sys.path.insert(0, sys.argv[2])
from todo_model import done_items
lines = open(sys.argv[1], encoding='utf-8').read().split('\n')
pat = re.compile(r'Left|left:|still|maintainer|review|counterpart|remain|not yet|follow|pending|confirm|by hand|hardware|real |field|next|later|TODO|wants|needs|open question|undecided|to decide|unverified|only on|except', re.I)
for n, (a, b, s, k) in enumerate(done_items(lines)):
    body = ' '.join(l.strip() for l in lines[a:b])
    sents = re.split(r'(?<=[.;])\s+', body)
    hits = [x for x in sents[1:] if pat.search(x)]
    print(f'#{n} L{a+1} [{s[3:30]}] {k[:150]}')
    for h in hits: print('    > ' + h[:400])
