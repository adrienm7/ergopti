func managedHTTPFailure(_ error: NSError) -> String {
	guard error.domain == NSURLErrorDomain else { return "unavailable" }
	switch error.code {
	case NSURLErrorTimedOut: return "deadline"
	case NSURLErrorCancelled: return "cancelled"
	case NSURLErrorNotConnectedToInternet, NSURLErrorNetworkConnectionLost: return "offline"
	case NSURLErrorCannotFindHost, NSURLErrorDNSLookupFailed: return "offline"
	case NSURLErrorServerCertificateUntrusted, NSURLErrorServerCertificateHasBadDate,
		NSURLErrorServerCertificateHasUnknownRoot, NSURLErrorServerCertificateNotYetValid,
		NSURLErrorSecureConnectionFailed, NSURLErrorClientCertificateRejected,
		NSURLErrorClientCertificateRequired: return "certificate"
	case NSURLErrorUserAuthenticationRequired: return "unavailable"
	case NSURLErrorCannotConnectToHost: return "connect"
	default: return "unavailable"
	}
}
