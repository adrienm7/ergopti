import importlib.util
import pathlib
import sys
import unittest
root = pathlib.Path(__file__).parent
mode = sys.argv[1]
sys.path.insert(0, "/workspace/ergopti/tools/diagnostics")
sys.path.insert(0, str(root / mode / "tools/diagnostics"))
spec = importlib.util.spec_from_file_location("receiving_controls", root / "candidate/tools/diagnostics/macos_brew_archive_acceptance_test.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
suite = unittest.TestSuite([module.FirstCommandTimeoutControls("test_generic_exit_wait_keeps_supplied_float_budget_and_opaque_deadline_null")])
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert result.testsRun == 1 and not result.skipped
sys.exit(0 if result.wasSuccessful() else 1)
