# Product wiring for Windows item 49

This is an implementation sequence, not another benchmark. It reads the current
local source snapshot and the pinned protocol author pointer. All fifteen
production bindings still match the packet's published ad937 preimages exactly.
The local TODO is pinned separately; this report does not attribute its bytes to
an unobserved current remote HEAD. No code, native process, GUI or keyboard run
was performed by this proposal.

## What can be reused now

The private protocol core already contains modifier provenance by physical side
and injected SendLevel, bounded physical edge storage, once-only DOWN action
reservation, retained repeats/UP, an exclusive replay claim, exact accepted FIFO
prefix ACK, partial retry and sticky overflow. Its seventeen recording cases
remain software evidence. Existing native terminal release is already the
exclusive physical sender: retain NavReleaseTerminalCaptureOwned, its unlocked
SendInput call, accepted count and atomic final ownership release. Do not put a
second sender in the protocol module.

The paired instrumented AHK/C runtime and both real order fixture runs reported
by Root are qualification tools. Keep them to refute changes on actual callback
entries and receiving text/caret. Do not ship their observation ABI, substitute
an InputHook proxy, install a third hook, or call these injected fixtures physical
hardware proof or stock AHK timing.

## The specific product seam still missing

nav_event_owner.c:807 NavCaptureTerminalEventLocked stores a physical edge before
NavProcessHookEventLocked when its native LL callback is reached. At :1916,
NavLowLevelKeyboardProc can therefore suppress only after that native entry.
ErgoptiPlus.ahk:1397 still relies on starting native last to run it first.
HookDispatcher._OnKeyDown/:307 and _OnKeyUp/:329 expose only ih/vk/sc; independent
AHK hotkey/KLE handlers also consume routes. These callbacks cannot prove raw
flags, extra-info or a unique earlier native event merely from a global capture
flag. An AHK-first effect can precede native reservation.

G7P_MatchUnique explicitly matches a closed two-observer cohort. G7P_Capture
requires genuine AHK-native and C entries. That receiving oracle is useful for
qualification, but collecting both entries after an effect does not make the
effect transactional. Never fabricate the AHK entry from a copy of C data to
make this function usable under stock AHK.

Preferred product direction: one native raw-event/reservation owner for captured
routes, with deferred AHK effect handlers consuming exact native receipts. This
keeps stock AHK and avoids making a private instrumented runtime a product
dependency. The transfer must disarm the old direct effect path for each owned
route before activating its native equivalent. This is a per-route ownership
handoff covering every eligible event; it is not a physical-only blanket guard
or a global replay exemption. Lower/ineligible injection retains its explicit
pass policy. Unsupported routes must prevent capture admission before sending,
not disappear after a partial effect.

## Minimal sequential software lots

1. Native capture state and replay adapter.
   Add internal native/nav_event_owner/event_protocol.c and .h, promoted from the
   core's provenance/reservation/replay logic. Keep the private paired observer
   oracle separate. The production function accepts an authenticated raw edge
   from the existing NavLowLevelKeyboardProc; no caller-supplied stage claims
   replace callback ownership. Add owner/generation/capture identity and route
   generation to NavState and each captured edge. Capture raw flags/extra-info,
   VK/SC/extended/DOWN-UP before suppression; retain once-only DOWN, repeat and
   held release identity. Store captured effective left/right modifiers, not a
   later GetKeyState union. Reuse the existing replay claim and accepted prefix;
   zero/partial sends retain debt and native overflow/error stays sticky.
   Modify CMakeLists.txt plus C tests. Do not change delivered editor-replace
   behavior or renderer timings. Initial state needs a genuine released-state
   census; never invent G7P_Begin's 0xFF witness. Transactions borrow established
   modifier state so held modifiers are not zeroed at every expansion.

2. Authenticated native-to-AHK route receipts.
   Extend the canonical header/def and adapters/llm_nav_event_owner.ahk with a
   small typed route-reservation/receipt API. Proposed receipt fields are native
   owner generation, capture token, edge ordinal, binding generation, raw edge
   fingerprint and effective modifier mask. AHK borrows exact owner storage;
   route reads/claims are metadata operations, and the actual callback/action
   executes outside Critical. New adapter methods reject stale, duplicate,
   unreserved, foreign and already delivered receipts. A receipt marks delivery
   before arbitrary user code; a callback exception cannot replay that action.
   No text or raw key streams are written to normal product logs. Regenerate
   DLL and manifest only through tools/build/build_windows_nav_owner.ps1; keep
   source/recipe/PE/CFG/export assertions, update the typed ABI contract together.

3. Route handoff and paced expansion integration.
   Wire infra/hotstrings/hotstring_dispatch.ahk at
   _HSE_BeginOwnedTerminalTransaction, _HSE_ReleaseTerminalCapture and
   _HSE_RetryTerminalReplay to the retained capture/reservation identity. Obtain
   native route activation ACK before paced sender effects. Abort restores only
   undelivered work; commit/retry consumes only physically accepted FIFO edges.
   Preserve the original replay marker, exact trailing-character behavior,
   accepted-prefix ACK and held-release/menu-mask obligations.
   Register the route snapshot before start and replace the start-order comment
   only after both real order regressions pass. Route changes reserve a new
   generation; active held edges finish under their old immutable generation.

4. Cover the six concrete consumers without two active effect paths.
   KLE/layout/deadkey: modules/keymap/keylayout/keylayout_emulation.ahk
   (_KLE_BaseCriterion, _KLE_Emit, _KLE_OnKey, PressNative). A captured receipt
   carries the selected layout/HKL/dead-key generation; preserved G3 typed HKL
   observations and unavailable-field refusals remain authoritative. Never
   recompute a different layout while releasing a held edge.
   Digits/profile/navigation: native bindings and the existing adapter route
   receipt/profile flow. Preserve menu masking and native ownership on UP.
   Tap-hold: platform/remap/tap_hold_loader.ahk and roll keys plus dispatcher
   trackers. Bind timer decisions, repeat and UP to the original press token;
   owner changes while held cannot create a second tap/hold action.
   Combinations: platform/remap/key_combination_keys.ahk and
   infra/key_combinations.ahk; route generation retains each side's modifiers.
   Script shortcuts: infra/script_altgr_hotkeys.ahk (_ScriptAltGrDispatch) and
   its existing user callback route. Claim once before user code; a refused or
   throwing callback does not release captured UP or permit duplicate effects.
   Ordinary keyboard/character tracking: infra/hook_dispatcher.ahk. Keep one
   InputHook; native-owned effect routes consume receipt identity, while proxy
   callback payload remains explicitly non-native evidence. No new hook.

5. Lifecycle and initialization.
   ErgoptiPlus.ahk initializes metadata before registration, publishes a route
   snapshot, then activates one native owner. Stop/suspend/reload first revokes
   new DOWN reservations while retaining existing repeats/UP/replay claims.
   infra/lifecycle.ahk and the adapter retain owner/storage/held modifier debt
   until actual native drain/unhook/thread Wait0/close ACK; no timeout retirement.
   Keep READ, predecessor quiescence and current ProgramActions ordering intact.
   Configuration publication cannot replace a route generation with live holds.

## Required registered regression matrix

Native C tests: both modeled callback orders; physical left/right modifiers;
known injected levels above/equal/below InputLevel; lower-integrity/unknown
injection and private replay; simultaneous physical edge during replay; DOWN,
repeat, UP and unmatched UP; partial and zero accepted SendInput; overflow;
reentrant delivery/replay, callback throw and generation switch while held.
The old 929 assertion expressions and exclusive replay tests stay intact.

AHK tests call the real product adapter and actual consumer handlers with
explicit recording ports. Add test_event_capture_protocol and route integration
registrations to tests/run_all.ahk; each route receives an exact receipt or
refuses before effect. Independent negatives remove the reservation, replace
owner/binding generation, duplicate DOWN, clear another SendLevel's modifier,
use a later HKL, accept a planned prefix, and drop held UP debt. Each inverse
must fail the route/ownership assertion, not a parse or prerequisite check.

Root genuine Windows acceptance uses the existing paired actual LL qualification
runtime, extended to invoke these product handlers, not a fresh benchmark.
Exercise actual AHK-first and native-first, including real SendInput rehook,
for each of the six routes and assert exact receiving text/caret/modifiers plus
native close census. Add absent/duplicate/ambiguous native tuple and stale route
generation negatives. These remain instrumented injected receiving results.
Then run stock source and compiled/install startup, complete AHK unit/E2E and
natural exit/reload gates. Instrumentation is excluded from shipped artifacts.

Maintainer physical Windows11 and Windows10 validation is still necessary:
physical typing during paced expansion/replay, modifier holds across owners,
dead-key/layout and profile switches, suspend/reload, secure desktop transitions
and balanced releases/menu masking in both actual orders. Stock timing and
physical provenance are separate observations. A passing paired fixture alone
does not close item49. No deadline increase, prompt permission, sender-policy
switch or test-skip is proposed.

## Immediate next code handoff

Root can assign lot1 plus the route-receipt contract of lot2 first, retaining the
private 17-case core and delivered C corpora as preimages. Before admitting that
lot, require a receiving witness that native capture reservation precedes the
real AHK effect in AHK-first order. If the direct legacy handler is still active,
the route transfer is incomplete: do not compensate after it has already acted.
Only after that contract is proven should lots3/4 enable captured routes. This
is a bounded product implementation path, not an always-refusing end state or
another performance experiment.
