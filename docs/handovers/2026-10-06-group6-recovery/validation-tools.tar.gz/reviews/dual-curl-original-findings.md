Dual validation curl source review
=================================

Original manifest617510cb / setup465df6a4 remains source-only and unexecuted. All five manifest bindings verified; official modern release222954438/asset260804610/url/size/f461 digest agree. Independent legacy provenance binds exact InRelease77737, signed Packages.xz9e0, signer4D64, and separately labeled official Debian distribution packages. Current canonical native build owner SHAa488 matches PINS.

Fresh gpgv must succeed and return required VALID_SIG; signed release identity/date/any Valid-Until are checked, SHA256 index section matched before fetching, and one exact package/version/amd64/Filename/size/SHA record matched before extraction. Modern authenticated tar data filter and legacy exact selected ELF/library hashes precede use. Local installed OpenSSL SDK is explicit; loader and actual HTTP/HTTPS/TLS backend admission are performed; only three older SONAMEs prefix the legacy child environment and inherited native library suffix remains. No global binary/library replacement or TLS bypass is authored. Missing mutable pinned metadata intentionally refuses rather than selecting latest.

Two narrow concrete source blockers sent author/root: (1) library version substring matching accepts libcurl7.88.10 for expected7.88.1 and8.14.10 for expected8.14.1; require a complete bounded libcurl token. (2) the sole owner caps native commands by original1800s but namespace current() and final tools receipt do not check original deadline; late non-native work can publish tools_admitted beyond that total. Preserve the original absolute deadline at final publication and do not give success credit for failed/late inputs.

No setup parser/import/build/download/loader/version/native fixture was executed by this review. No final source ACK until corrected freeze is re-read. Native30 remains unexecuted; setup admission alone never implies proxy/TLS/native transport success.
