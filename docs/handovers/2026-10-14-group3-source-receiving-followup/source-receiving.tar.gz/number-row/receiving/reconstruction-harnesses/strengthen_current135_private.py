from pathlib import Path
import hashlib
p=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');r='tools/diagnostics/number_row_native_causal.py';s=(p/'postimages'/r).read_text()
anchor='    current()\n    return inputs, provenance\n\n\ndef _composition_contract';assert s.count(anchor)==1
s=s.replace(anchor,'    # Reobserve real current Git first, then every working image after all\n    # supplier/metadata reads. Earlier bytes cannot borrow a later HEAD check.\n    for path, data in inputs.items():\n        again, blob, mode = _git_input(repo, head, path)\n        record = approved[path]\n        if again != data or blob != record["git_blob"] or mode != record["git_mode"]:\n            raise ValueError("reviewed current Git source changed after reads")\n    current()\n    for path, data in inputs.items():\n        item = repo / path\n        if item.is_symlink() or not item.is_file() or item.read_bytes() != data:\n            raise ValueError("reviewed working source changed after reads: " + path)\n    current()\n    return inputs, provenance\n\n\ndef _composition_contract')
s=s.replace('source_review_sha256=approval["source_review_sha256"],','received_source_review_reference_sha256=approval["source_review_sha256"],\n            receiver_approval_from_source_basis=False,')
(p/'postimages'/r).write_text(s);new=hashlib.sha256(s.encode()).hexdigest()
for f in ['prepare_number_row_native_causal.py','generate_number_row_source_composition.py','test_number_row_source_composition.py']:
 path=p/'postimages/tools/diagnostics'/f;t=path.read_text();assert '5c4557a57ea4444ca98cd0f90a37f5ec14282e8251e59f0f5a4a97786c00c162' in t;t=t.replace('5c4557a57ea4444ca98cd0f90a37f5ec14282e8251e59f0f5a4a97786c00c162',new)
 if f=='test_number_row_source_composition.py':
  t=t.replace('import tempfile\n','import tempfile\nimport subprocess\n',1).replace('parser.add_argument("--source-basis", type=Path)','parser.add_argument("--source-basis", type=Path)\nparser.add_argument("--canonical-repo", type=Path)',1).replace('if args.source_basis is None:', 'if args.source_basis is None or args.canonical_repo is None:',1)
  old='''        with self.assertRaisesRegex(ValueError, "actual current source commit changed"):
            subject._current_composition_inputs(
                args.repo, "3f59f730a680ba4d8a509267b6b50d192789e317", legacy, received, composition
            )'''
  newtext='''        # Genuine frozen canonical HEAD and working source, not a supplied
        # mismatched HEAD in the candidate fixture. Admission stops at the real
        # missing70 ancestry; independently observe the genuine bootstrap delta.
        frozen = "3f59f730a680ba4d8a509267b6b50d192789e317"
        self.assertEqual(subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=args.canonical_repo, text=True
        ).strip(), frozen)
        with self.assertRaisesRegex(ValueError, "approved committed source is not an ancestor"):
            subject._current_composition_inputs(
                args.canonical_repo, frozen, legacy, received, composition
            )
        path = "static/ergopti_plus/macos/launcher/Sources/ErgoptiPlus/OwnedRuntimeBootstrapStageOwner.swift"
        actual, _, _ = subject._git_input(args.canonical_repo, frozen, path)
        self.assertEqual(actual, (args.canonical_repo / path).read_bytes())
        self.assertNotEqual(actual, (args.projection / path).read_bytes())'''
  assert t.count(old)==1;t=t.replace(old,newtext)
  anchor='''    def test_14_source_join_cannot_certify_native_success(self):'''
  extra='''        # Real missing-history observation in our private object metadata.
        # No hosted-shallow assertion or fabricated Git return is made.
        self.assertNotEqual(args.repo.resolve(), args.canonical_repo.resolve())
        alternate = args.repo / ".git/objects/info/alternates"
        unavailable = alternate.with_name("alternates-source-control-unavailable")
        alternate.rename(unavailable)
        try:
            missing = subprocess.run(["git", "cat-file", "-e", approval["published_source_commit"]],
                                     cwd=args.repo, capture_output=True)
            self.assertNotEqual(missing.returncode, 0)
            legacy, received, composition = self.contract()
            with self.assertRaisesRegex(ValueError, "approved committed source is not an ancestor"):
                subject._current_composition_inputs(args.repo, args.head, legacy, received, composition)
        finally:
            unavailable.rename(alternate)
        # Change the real private HEAD during an original real Git source read;
        # the wrapper forwards actual Git bytes unchanged and adds only this
        # controlled source-currency interruption. It never mocks Git answers.
        getter = subject._git_input
        changed = False
        def change_head(repo, head, path):
            nonlocal changed
            result = getter(repo, head, path)
            if not changed:
                subprocess.run(["git", "update-ref", "--no-deref", "HEAD",
                                "3f59f730a680ba4d8a509267b6b50d192789e317"], cwd=args.repo, check=True)
                changed = True
            return result
        subject._git_input = change_head
        try:
            legacy, received, composition = self.contract()
            with self.assertRaisesRegex(ValueError, "actual current source commit changed"):
                subject._current_composition_inputs(args.repo, args.head, legacy, received, composition)
            self.assertTrue(changed)
        finally:
            subject._git_input = getter
            subprocess.run(["git", "update-ref", "--no-deref", "HEAD", args.head], cwd=args.repo, check=True)
        # A late genuine file change after earlier source rows were checked
        # must be found by the final working-image join. Source reads remain
        # original and the altered bytes/fixture are restored in finally.
        victim = args.repo / approval["sources"][0]["path"]
        prior = victim.read_bytes()
        last = approval["sources"][-1]["path"]
        calls = 0
        def change_working(repo, head, path):
            nonlocal calls
            result = getter(repo, head, path)
            if head == args.head and path == last:
                calls += 1
                if calls == 2:
                    victim.write_bytes(prior + b"\\nsource-control late negative image\\n")
            return result
        subject._git_input = change_working
        try:
            legacy, received, composition = self.contract()
            with self.assertRaisesRegex(ValueError, "reviewed working source changed after reads"):
                subject._current_composition_inputs(args.repo, args.head, legacy, received, composition)
            self.assertEqual(calls, 2)
        finally:
            subject._git_input = getter
            victim.write_bytes(prior)

'''
  assert t.count(anchor)==1;t=t.replace(anchor,extra+anchor)
  t=t.replace('''        self.assertIs(proof["native_authority"], False)
        self.assertEqual(proof["native_execution"], "UNRUN")''','''        self.assertIs(proof["native_authority"], False)
        self.assertIs(proof["receiver_approval_from_source_basis"], False)
        self.assertEqual(proof["native_execution"], "UNRUN")''',1)
 path.write_text(t)
print(new)
