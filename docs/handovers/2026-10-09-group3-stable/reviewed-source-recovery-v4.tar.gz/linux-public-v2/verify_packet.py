# group3-linux93-public-join-v2/verify_packet.py
"""Verify inactive artifact seals and the exact three-pair archive."""
from pathlib import Path
import hashlib,json,tarfile
b=Path(__file__).resolve().parent
r=json.loads((b/'receipt.json').read_text())
for name,want in r['artifacts'].items():
 p=b/name
 assert p.is_file() and not p.is_symlink(),name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==want,name
with tarfile.open(b/'source-pair.tar') as t:
 names=set()
 for m in t:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  names.add(m.name);assert t.extractfile(m).read()==(b/m.name).read_bytes()
 assert len(names)==6
for p in r['source_pairs']:
 for kind,field in [('preimages','pre_sha256'),('candidate','post_sha256')]:
  assert hashlib.sha256((b/kind/p['path']).read_bytes()).hexdigest()==p[field]
print('VERIFIED inactive V2: three exact source pairs; no native qualification')
