"""Finite source enrollment and whole-file forward/inverse proof outside checkout."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil
import subprocess
import tempfile

P = Path(__file__).resolve().parent
ROOT = Path('/workspace/ergopti')
RELS = ['static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py',
        'tools/test/macos_native_http_receiving_facts_test.py',
        'tools/test/test-managed-ollama-protocol.cjs']

def bodies(data):
    text = data.decode()
    tree = ast.parse(text)
    return {f'{getattr(parent, "name", "module")}.{node.name}': ast.get_source_segment(text, node)
            for parent in [tree, *ast.walk(tree)] if isinstance(parent, (ast.Module, ast.ClassDef))
            for node in parent.body if isinstance(node, ast.FunctionDef)}

original = (P / 'preimage' / RELS[1]).read_bytes()
candidate = (P / 'candidate' / RELS[1]).read_bytes()
assert hashlib.sha256(original).hexdigest() == '6a6f93dbd7ce8a2aea3d2a9d5632e17668f98ecb30f34647780e026a7832203b'
a, b = bodies(original), bodies(candidate)
for name, body in a.items():
    assert b[name] == body, name
old_tests = [name for name in a if name.rsplit('.', 1)[1].startswith('test')]
new_tests = [name for name in b if name.rsplit('.', 1)[1].startswith('test') and name not in a]
assert len(old_tests) == 72 and len(new_tests) == 18
assert all(name.startswith('NativeCommandGuardTests.') for name in new_tests)
wire_before, wire_after = [bodies((P / role / RELS[0]).read_bytes()) for role in ['preimage', 'candidate']]
assert wire_before.keys() == wire_after.keys()
changed = [name for name in wire_before if wire_before[name] != wire_after[name]]
assert set(changed) == {'WireFixture.__init__', 'WireFixture._command', 'WireFixture.close'}
patches, inverses, paths = [], [], {}
for rel in RELS:
    before = (P / 'preimage' / rel).read_bytes()
    after = (P / 'candidate' / rel).read_bytes()
    assert (ROOT / rel).read_bytes() == before, rel
    assert b'\r' not in before + after
    paths[rel] = {'preimage_sha256': hashlib.sha256(before).hexdigest(), 'candidate_sha256': hashlib.sha256(after).hexdigest()}
    patches.append(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + rel, tofile='b/' + rel)))
    inverses.append(''.join(difflib.unified_diff(after.decode().splitlines(True), before.decode().splitlines(True), fromfile='a/' + rel, tofile='b/' + rel)))
(P / 'proposal.patch').write_text(''.join(patches))
(P / 'inverse.patch').write_text(''.join(inverses))
private = Path(tempfile.mkdtemp(prefix='g6-guard90-inverse-', dir='/tmp'))
private.chmod(0o700)
try:
    for rel in RELS:
        target = private / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((P / 'preimage' / rel).read_bytes())
    for patch, role in [('proposal.patch', 'candidate'), ('inverse.patch', 'preimage')]:
        for arguments in [['--check'], []]:
            result = subprocess.run(['git', 'apply', *arguments, str(P / patch)], cwd=private, capture_output=True)
            assert result.returncode == 0, result.stderr
        assert sorted(str(path.relative_to(private)) for path in private.rglob('*') if path.is_file()) == sorted(RELS)
        for rel in RELS:
            assert (private / rel).read_bytes() == (P / role / rel).read_bytes()
finally:
    shutil.rmtree(private)
manifest = {'qualification': 'SOURCE_BOUND_PORTABLE_SOFTWARE_CORRECTION_NO_NATIVE_CREDIT_NO_ADOPTION',
            'paths': paths, 'strict_registry': 90, 'original72_identities': old_tests,
            'additive18_identities': new_tests, 'every_original_function_body': 'BYTE_EXACT',
            'wire_changed_functions': changed, 'wire_original_settle_calls': 1,
            'private_whole_file_forward_inverse': 'PASS_EXACT_ALL_THREE_PATHS',
            'owned_files': {name: hashlib.sha256((P / name).read_bytes()).hexdigest() for name in ['proposal.patch', 'inverse.patch', 'receive90.py', 'reproduce90.py', 'enroll.py']}}
if (P / 'owning90-receiving.json').exists():
    manifest['receiving_sha256'] = hashlib.sha256((P / 'owning90-receiving.json').read_bytes()).hexdigest()
(P / 'manifest90.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, sort_keys=True))
