import os,subprocess,json,concurrent.futures,time
from pathlib import Path
r=Path('/workspace/ergopti-macos-integration');s=Path('/workspace/scratch/oct28-merge10-verification');env=dict(os.environ)
env['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH'];env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu';env['USER']=env['LOGNAME']='agent'
commands={'gen-check':['npm','run','-s','gen:check'],'format':['npm','run','-s','format:check'],'strict':['npm','run','-s','lint:conventions:strict'],'ahk-locals':['npm','run','-s','test:ahk-local-same-as-global'],'windows-source':['node','tools/test/test-windows-updater-original-source.cjs'],'encoding':['node','tools/test/test-source-encoding.cjs'],'ahk-encoding':['npm','run','-s','test:ahk-encoding'],'undefined-lua':['node','tools/test/test-lua-undefined-globals.cjs'],'hs-carrier':['npm','run','-s','test:hs','--','--only=tests.unit.modules.keymap.synthetic.test_text_carrier_avoids_held_key'],'hs-field':['npm','run','-s','test:hs','--','--only=tests.unit.infra.field_run.test_field_run'],'plan':['node','tools/test/verify-change.cjs','--plan']}
def run(item):
 name,cmd=item;start=time.monotonic()
 with(s/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'actual_exit':p.returncode,'seconds':round(time.monotonic()-start,3)};print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:rows=list(ex.map(run,commands.items()))
(s/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(0 if all(x['actual_exit']==0 for x in rows)else 1)
