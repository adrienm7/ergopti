from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

root = Path('/workspace/ergopti')
outside = Path('/workspace/ergopti-cloud')
name = sys.argv[1]
paths = json.loads(Path(sys.argv[2]).read_text())
assert len(set(paths)) == len(paths)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fence():
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'unstaged_tracked_diff': subprocess.check_output(['git', 'diff', '--name-only', '--'], cwd=root, text=True),
        'logical_index_tree': subprocess.check_output(['git', 'write-tree'], cwd=root, text=True).strip(),
        'source_sha256': {path: sha(root / path) for path in paths},
    }

before = fence()
(outside / (name + '-gate-before.json')).write_text(json.dumps(before, indent=2) + '\n')
start = time.monotonic()
log = outside / ('verify-' + name + '-canonical-final.log')
with log.open('wb') as stream:
    result = subprocess.run(['node', 'tools/test/verify-change.cjs'], cwd=root,
                            stdout=stream, stderr=subprocess.STDOUT)
after = fence()
assert before == after, 'Source, HEAD or index changed during serial gate'
receipt = {'exit': result.returncode, 'seconds': round(time.monotonic() - start, 3),
           'before_and_after_fence_equal': True, **before,
           'log_sha256': sha(log), 'log_bytes': log.stat().st_size,
           'log': str(log), 'native_credit': False}
(outside / (name + '-canonical-gate-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'source_sha256'}), flush=True)
raise SystemExit(result.returncode)
