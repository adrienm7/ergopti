﻿; Private native producer observation; no tracked source is edited.
_R6B_Events(Scalars) {
	Events := []
	for Scalar in Scalars
		Events.Push([Scalar, 100, Map("st", "none")])
	return Events
}
_R6B_Run(Scalars) {
	KLW.ctx := Map()
	KLW_ResetBatch()
	KLW_WalkTypingEntry(Map("timestamp", "2026-10-26 12:00:00.000",
		"app", "bracket-probe.exe", "events", _R6B_Events(Scalars)))
}
_R6Accuracy_OriginalProducerRows() {
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	try {
		Tables := ["ngram_bigrams", "ngram_trigrams", "ngram_quadgrams",
			"ngram_pentagrams", "ngram_hexagrams", "ngram_heptagrams"]
		Prefixes := ["", "a", "ab", "abc", "abcd", "abcde"]
		for Index, Prefix in Prefixes {
			FinalChar := Chr(Ord("a") + Index - 1)
			Scalars := StrSplit(Prefix)
			Scalars.Push("[BS]", FinalChar, "[BS]")
			_R6B_Run(Scalars)
			Token := Prefix . "[BS]" . FinalChar
			Key := "2026-10-26" . Chr(1) . "bracket-probe.exe" . Chr(1) . Token
			Rows := KLW.batch["ngram"][Tables[Index]]
			AssertTrue(Rows.Has(Key), "actual native Backspace history must create this original typed n-gram")
			AssertEqual(1, Rows[Key]["c"])
			AssertEqual(1, Rows[Key]["e"], "the final real Backspace records the preceding sequence correction")
			FileAppend("NATIVE_PRECISION_ROW " . Tables[Index] . " token=" . JsonStringLiteral(Token)
				. " c=" . Rows[Key]["c"] . " e=" . Rows[Key]["e"] . "`n", "*")
		}
		for Spec in [
			Map("table", "ngram_pentagrams", "token", "[bs]a", "scalars", ["[", "b", "s", "]", "a", "[BS]"]),
			Map("table", "ngram_bigrams", "token", "ab", "scalars", ["a", "b", "[BS]"]),
			Map("table", "ngram_chars", "token", "a", "scalars", ["a", "[BS]"])
		] {
			_R6B_Run(Spec["scalars"])
			Key := "2026-10-26" . Chr(1) . "bracket-probe.exe" . Chr(1) . Spec["token"]
			Rows := KLW.batch["ngram"][Spec["table"]]
			AssertTrue(Rows.Has(Key))
			AssertEqual(1, Rows[Key]["c"])
			AssertEqual(1, Rows[Key]["e"])
			FileAppend("NATIVE_LITERAL_PRECISION_ROW " . Spec["table"] . " token=" . JsonStringLiteral(Spec["token"])
				. " c=" . Rows[Key]["c"] . " e=" . Rows[Key]["e"] . "`n", "*")
		}
	} finally {
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
	}
}
Test("audit: original native Backspace and literal precision rows (r6-accuracy-native-producer)",
	_R6Accuracy_OriginalProducerRows)

_R6CorrectedWord_Occurrence(Bigram) {
	SavedContext := KLW.ctx
	SavedBatch := KLW.batch
	try {
		Scalars := StrSplit(Bigram ? "one cat" : "cat")
		Scalars.Push("[BS]", "t", " ")
		_R6B_Run(Scalars)
		Table := Bigram ? "ngram_word_bigrams" : "ngram_words"
		Token := Bigram ? "one cat" : "cat"
		Key := "2026-10-26" . Chr(1) . "bracket-probe.exe" . Chr(1) . Token
		Rows := KLW.batch["ngram"][Table]
		AssertTrue(Rows.Has(Key), "the completed final word must exist after a corrected keystroke")
		AssertEqual(1, Rows[Key]["e"], "the actual correction remains recorded")
		if Bigram {
			CleanKey := "2026-10-26" . Chr(1) . "bracket-probe.exe" . Chr(1) . "one"
			AssertEqual(1, KLW.batch["ngram"]["ngram_words"][CleanKey]["c"], "the clean completed word is the occurrence positive")
		}
		FileAppend("NATIVE_CORRECTED_WORD " . Table . " token=" . JsonStringLiteral(Token)
			. " c=" . Rows[Key]["c"] . " e=" . Rows[Key]["e"] . "`n", "*")
		AssertEqual(1, Rows[Key]["c"], "one completed word sequence contributes one occurrence even when corrected")
	} finally {
		KLW.ctx := SavedContext
		KLW.batch := SavedBatch
	}
}
Test("audit: a corrected completed word retains its occurrence (r6-corrected-word-occurrence)",
	_R6CorrectedWord_Occurrence.Bind(false))
Test("audit: a corrected completed word pair retains its occurrence (r6-corrected-word-occurrence)",
	_R6CorrectedWord_Occurrence.Bind(true))
