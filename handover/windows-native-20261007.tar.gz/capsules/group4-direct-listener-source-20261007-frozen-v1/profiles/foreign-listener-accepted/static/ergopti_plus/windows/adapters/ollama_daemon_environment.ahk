﻿; adapters/ollama_daemon_environment.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Owned Direct Daemon Environment and Listener
; DESCRIPTION:
; Captures child-only Unicode environment and authenticates an IPv4 listener
; against a borrowed original process capability; no process is opened by PID.
; ==============================================================================

global _SR_DaemonEnvironmentOwners := Map()

_SR_DaemonOrdinal(Left, Right) {
	local result := DllCall("Kernel32\CompareStringOrdinal", "Str", Left, "Int", -1,
		"Str", Right, "Int", -1, "Int", true, "Int")
	if result == 0
		throw Error("Child environment ordinal comparison refused.")
	return result - 2
}

/** Pure merge/sort owner; the caller supplies an already captured parent block. */
_SR_DaemonEnvironmentBuild(Entries, Host, Models, Compare := _SR_DaemonOrdinal) {
	if !(Entries is Array) || !(Host is String) || !RegExMatch(Host, "\A127\.0\.0\.1:([0-9]+)\z", &match)
			|| StrLen(match[1]) > 5 || Integer(match[1]) < 1 || Integer(match[1]) > 65535
			|| !(Models is String) || !RegExMatch(Models, "\A[A-Za-z]:\\") || !HasMethod(Compare, "Call")
		throw TypeError("Direct daemon environment requires its captured local target.")
	local rows := []
	for entry in Entries {
		if !(entry is String)
			throw TypeError("Parent environment entries must be UTF-16 strings.")
		local delimiter := InStr(entry, "=", true, SubStr(entry, 1, 1) == "=" ? 2 : 1)
		if delimiter <= 1
			throw ValueError("Parent environment variable shape refused.")
		local name := SubStr(entry, 1, delimiter - 1)
		for old in rows
			if Compare.Call(name, old["name"]) == 0
				throw ValueError("Parent environment contains duplicate case-insensitive names.")
		rows.Push(Map("name", name, "value", SubStr(entry, delimiter + 1)))
	}
	for name, value in Map("OLLAMA_HOST", Host, "OLLAMA_MODELS", Models) {
		local found := false
		for row in rows {
			if Compare.Call(name, row["name"]) == 0 {
				row["name"] := name
				row["value"] := value
				found := true
			}
		}
		if !found
			rows.Push(Map("name", name, "value", value))
	}
	local sorted := []
	for row in rows {
		local inserted := false
		loop sorted.Length {
			if Compare.Call(row["name"], sorted[A_Index]["name"]) < 0 {
				sorted.InsertAt(A_Index, row)
				inserted := true
				break
			}
		}
		if !inserted
			sorted.Push(row)
	}
	local units := 1
	for row in sorted {
		for text in [row["name"], row["value"]] {
			loop StrLen(text)
				if NumGet(StrPtr(text), (A_Index - 1) * 2, "UShort") == 0
					throw ValueError("Child environment rejects embedded NUL units.")
		}
		units += StrLen(row["name"]) + 1 + StrLen(row["value"]) + 1
	}
	local block := Buffer(units * 2, 0), offset := 0
	for row in sorted {
		local text := row["name"] . "=" . row["value"]
		StrPut(text, block.Ptr + offset, StrLen(text) + 1, "UTF-16")
		offset += (StrLen(text) + 1) * 2
	}
	return block
}

_SR_DaemonEnvironmentCapture(Host, Models) {
	global _SR_DaemonEnvironmentOwners
	local owner := Map("pointer", 0, "phase", "acquiring", "first_error", "")
	_SR_DaemonEnvironmentOwners[ObjPtr(owner)] := owner
	owner["pointer"] := DllCall("Kernel32\GetEnvironmentStringsW", "Ptr")
	local pointer := owner["pointer"]
	if !pointer {
		_SR_DaemonEnvironmentOwners.Delete(ObjPtr(owner))
		throw Error("Parent environment capture refused.")
	}
	local entries := [], primary := 0
	try {
		local position := pointer
		while NumGet(position, 0, "UShort") != 0 {
			local text := StrGet(position, "UTF-16")
			entries.Push(text)
			position += (StrLen(text) + 1) * 2
		}
	} catch as Err {
		primary := Err
	} finally {
		local released := false
		try released := DllCall("Kernel32\FreeEnvironmentStringsW", "Ptr", pointer, "Int")
		catch as ReleaseError {
			if !IsObject(primary)
				primary := ReleaseError
		}
		if released {
			owner["pointer"] := 0
			owner["phase"] := "retired"
			_SR_DaemonEnvironmentOwners.Delete(ObjPtr(owner))
		} else {
			owner["phase"] := "retained-debt"
			owner["first_error"] := "parent_environment_release_refused"
			if !IsObject(primary)
				primary := Error("Parent environment capture retains native release debt.")
		}
	}
	if IsObject(primary)
		throw primary
	return _SR_DaemonEnvironmentBuild(entries, Host, Models)
}

/** Keeps the old five-argument creator contract and forwards one closed block. */
_SR_DaemonCreateWithEnvironment(Environment, Application, Command, Flags, Startup, Process) {
	if !(Environment is Buffer) || Environment.Size < 4 || Mod(Environment.Size, 2) != 0
			|| NumGet(Environment, Environment.Size - 2, "UShort") != 0
			|| NumGet(Environment, Environment.Size - 4, "UShort") != 0
		throw TypeError("Direct daemon creation requires a double-NUL Unicode block.")
	local created := DllCall("Kernel32\CreateProcessW", "Str", Application, "Ptr", Command.Ptr,
		"Ptr", 0, "Ptr", 0, "Int", true, "UInt", Flags | 0x400,
		"Ptr", Environment.Ptr, "Ptr", 0, "Ptr", Startup.Ptr, "Ptr", Process.Ptr, "Int")
	if !created
		throw Error("Direct daemon CreateProcessW refused (Win32 " . A_LastError . ").")
	return true
}

_OllamaListenerProcessId(Process) {
	return DllCall("Kernel32\GetProcessId", "Ptr", Process, "UInt")
}
_OllamaListenerJob(Process, Job) {
	local member := 0
	if !DllCall("Kernel32\IsProcessInJob", "Ptr", Process, "Ptr", Job, "Int*", &member, "Int")
		throw Error("Original daemon job membership query refused.")
	return member != 0
}
_OllamaListenerTable() {
	local bytes := 0
	local status := DllCall(A_WinDir . "\System32\Iphlpapi.dll\GetExtendedTcpTable", "Ptr", 0, "UInt*", &bytes,
		"Int", false, "UInt", 2, "Int", 3, "UInt", 0, "UInt")
	if status != 122 || bytes < 4
		throw Error("TCP listener allocation query refused.")
	local table := Buffer(bytes, 0)
	status := DllCall(A_WinDir . "\System32\Iphlpapi.dll\GetExtendedTcpTable", "Ptr", table.Ptr, "UInt*", &bytes,
		"Int", false, "UInt", 2, "Int", 3, "UInt", 0, "UInt")
	if status != 0 || bytes > table.Size || bytes < 4
		throw Error("TCP listener snapshot refused.")
	local count := NumGet(table, 0, "UInt")
	if count > (bytes - 4) // 24
		throw Error("TCP listener snapshot row bounds refused.")
	return Map("table", table, "bytes", bytes, "count", count)
}

/** Refuses foreign/wildcard listeners; absence is pending under the old deadline. */
_OllamaListenerOwned(Port, Job, Process, Pid, Bindings := 0) {
	if !(Port is Integer) || Port < 1 || Port > 65535 || !Job || !Process || !Pid
		return Map("state", "refused", "error", 87)
	local wait := Bindings is Map ? Bindings["wait"] : PLC_WaitHandle
	local pid_query := Bindings is Map ? Bindings["pid"] : _OllamaListenerProcessId
	local job_query := Bindings is Map ? Bindings["job"] : _OllamaListenerJob
	local table_query := Bindings is Map ? Bindings["table"] : _OllamaListenerTable
	if wait.Call(Process, 0) != 258 || pid_query.Call(Process) != Pid || !job_query.Call(Process, Job)
		return Map("state", "refused", "error", 6)
	local snapshot := table_query.Call(), matches := 0, foreign := false
	if !(snapshot is Map) || !(snapshot.Get("table", 0) is Buffer)
		return Map("state", "refused", "error", 13)
	local table := snapshot["table"], count := snapshot.Get("count", -1), bytes := snapshot.Get("bytes", -1)
	if !(count is Integer) || count < 0 || !(bytes is Integer) || bytes > table.Size || bytes < 4
			|| count > (bytes - 4) // 24 || NumGet(table, 0, "UInt") != count
		return Map("state", "refused", "error", 13)
	loop count {
		local offset := 4 + (A_Index - 1) * 24
		local packed := NumGet(table, offset + 8, "UInt")
		local local_port := ((packed & 0xff) << 8) | ((packed >> 8) & 0xff)
		if NumGet(table, offset, "UInt") != 2 || local_port != Port
			continue
		local address := NumGet(table, offset + 4, "UInt")
		if address != 0 && address != 0x0100007f
			continue
		matches += 1
		if address != 0x0100007f
			foreign := true
	}
	if wait.Call(Process, 0) != 258 || pid_query.Call(Process) != Pid || !job_query.Call(Process, Job)
		return Map("state", "refused", "error", 6)
	if foreign || matches > 1
		return Map("state", "refused", "error", 5)
	return Map("state", matches == 1 ? "owned" : "missing", "error", 0)
}