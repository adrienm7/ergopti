from pathlib import Path
import hashlib,json,tarfile,gzip,io
b=Path('/workspace/.ergopti-cloud/resume-personal-topology-exact-causal')
sha=lambda data:hashlib.sha256(data).hexdigest()
m=json.loads((b/'exact-causal-matrix.json').read_text());assert m['state']=='COMPLETE'and len(m['rows'])==8
corpus=(b/'candidate-tests.lua').read_bytes();literal=(b/'literal-producer.lua').read_bytes();restored=(b/'candidate3-prepared.lua').read_bytes();original=(b/'literal-tests.lua').read_bytes()
assert sha(corpus)=='2340d5e638fbf0660839991d3f96de74d55908e805c53028f5b3e9552d276658'
assert sha(literal)=='c0809fe78b188fa84afa2cba16bf557b081131a9d43d1f28b754881131ccfdb4'
assert sha(restored)=='ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768'
assert corpus.startswith(original)and len(original)==38693
expected=json.loads((b/'expected-subjects.json').read_text())['names'];optional='file_watchers subsecond polling: detects same-second edits with installed posix';assert len(expected)==83
summary=[]
prior_literal=json.loads((b/'reference-d146-literal-status.json').read_text())
prior_names=[f['name']for f in prior_literal['failures']]
assert len(prior_names)==28
for row in m['rows']:
 stem=f"{row['label']}-{row['mode']}-{row['runtime']}"
 assert row==json.loads((b/(stem+'-status.json')).read_text())
 for stream in('stdout','stderr'):assert sha((b/(stem+'.'+stream+'.log')).read_bytes())==row[stream+'_sha256']
 assert row['test_sha256']==sha(corpus)
 assert row['producer_sha256']==sha(literal if row['label']=='literal'else restored)
 assert not row['remaining_owned_fixture_paths']and not Path(row['temporary_root']).exists()
 assert row['environment_overrides']==dict(TEMP=row['temporary_root'],TMPDIR=row['temporary_root'])
 wanted=[name for name in expected if row['mode']!='global-absent'or name!=optional]
 failed_names=[f['name']for f in row['failures']]
 assert sorted(row['passing_names']+failed_names)==sorted(wanted)
 assert row['passed']+row['failed']==len(wanted)and row['executed_topology_subjects']==34
 assert all(name.startswith('(linux-watch-topology)')for name in failed_names)
 if row['label']=='literal':assert failed_names==prior_names
 assert row['child_exit_code']==(1 if row['label']=='literal'else 0)
 assert(row['failed']>0)if row['label']=='literal'else(row['failed']==0)
 summary.append({key:row[key]for key in('label','mode','runtime','passed','failed','child_exit_code','executed_topology_subjects','original_installed_posix_optional_unavailable')}|{'failed_subject_names':failed_names})
assert len({row['temporary_root']for row in m['rows']})==8
manifest=json.loads((b/'source-manifest.json').read_text());owned=['static/ergopti_plus/linux/infra/file_watchers.lua','static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua']
for f in manifest['files']:
 p=b/'source'/f['path'];assert p.is_file()
 if f['path']not in owned:assert sha(p.read_bytes())==f['sha256']
assert {f['path']for f in manifest['files']}=={str(p.relative_to(b/'source'))for p in(b/'source').rglob('*')if p.is_file()}
assert(b/'source'/owned[0]).read_bytes()==restored and(b/'source'/owned[1]).read_bytes()==corpus
companions=[('resume-personal-watch-topology-receiving.tar.gz','ef732a0a888d5f7c5724f9e6b42e3c5b25286b815e60ec28fdd992a3cb2d37a3'),('resume-personal-topology-fixture-portability-receiving.tar.gz','0bf4806c00308c64bb08be84352ef77e10be3a95b3a10885507c4b619e034a4f')]
for name,digest in companions:assert sha((b.parent/name).read_bytes())==digest
receipt={'state':'COMPLETE_EXACT_FINAL_FIXTURE_CAUSAL_JOIN','test_sha256':sha(corpus),'literal_producer_sha256':sha(literal),'restored_producer_sha256':sha(restored),'original_prefix_bytes':len(original),'original_prefix_sha256':sha(original),'matrix_summary':summary,'literal_28_failed_subject_names_match_prior_d146_reference':True,'prior_d146_literal_reference_sha256':sha((b/'reference-d146-literal-status.json').read_bytes()),'all34_added_subjects_execute_every_child':True,'original_prefix_executed_subjects_all_passing':True,'unique_child_temporary_roots':[row['temporary_root']for row in m['rows']],'remaining_owned_fixture_paths':[],'captured_dependency_files':len(manifest['files']),'nonowned_drift_missing_extra':[],'unchanged_companion_archives':[{'name':name,'sha256':digest}for name,digest in companions],'limits':['External owning module only; no canonical fullgate, CI, package, installed driver or device qualification.','Global absent mode leaves exactly the preserved original installed-posix optional integration subject unavailable; all34 topology subjects execute.','Missing POSIX uses the reviewed controlled real-luv fixture port for inventory-dependent cases; explicit no-posix cases still reach actual producer native-stat/checked-shell branches.','Literal topology failures may precede injected safeguard boundaries; the separate final83 withdrawal matrix establishes the individual protection causal controls.']}
(b/'receiving-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
readme='''# Exact final-fixture causal join\n\nThis separate supplement runs the exact final CI-capable test source2340 against the literal published producer c080, then restores reviewed producer ce210 and reruns identical children. Neither source assertions nor fixture code were edited. All eight processes run the complete owning module from a separate external source capture and receive independently created TMPDIR and TEMP roots. Each naturally terminates and its owned root is empty and removed before the next process starts.\n\nThe exact test SHA256 is `'''+sha(corpus)+'''`. The complete original49 prefix remains byte-identical at38,693 bytes, SHA256 `'''+sha(original)+'''`. The literal producer is `'''+sha(literal)+'''`; restored producer is `'''+sha(restored)+'''`.\n\n| Producer | POSIX mode | Runtime | Passed | Failed | Exit | Added subjects executed | Original optional unavailable |\n| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |\n'''
for row in summary:readme+=f"| {row['label']} | {row['mode']} | {row['runtime']} | {row['passed']} | {row['failed']} | {row['child_exit_code']} | {row['executed_topology_subjects']} | {row['original_installed_posix_optional_unavailable']} |\n"
readme+='''\nAll counts above are observed terminal results. The exact 28 literal failed subject names match the earlier D146 reference on all four literal children; the preserved reference receipt is included. The literal children actually fail runtime expectations, rather than merely failing a subject-count guard. All34 topology subjects execute in each child and all original prefix subjects that are available remain passing. Global no-POSIX mode has82 executed subjects and exactly one preserved original optional integration subject UNRUN: `file_watchers subsecond polling: detects same-second edits with installed posix`. It is not reported as83 global-no-POSIX successes.\n\nThe same source2340 fixture supplies an explicitly controlled, real-luv-backed scan/stat port when lua-posix is absent. That is fixture portability, not an assertion that the missing POSIX library executed. Existing explicit s.no_posix cases still remove the injected port and use actual production native-stat/checked-shell branches. Native filesystem operations, native handles and their private cleanup remain real; selected source-boundary faults, callback replay, generation reentry and debounce clock advancement remain controlled models.\n\n`exact-causal-matrix.json` and per-child statuses record exact commands, source/test hashes, temporary environment overrides, names, failures, child exit codes and stdout/stderr hashes. `receiving-receipt.json` independently rechecks all eight children and original-prefix passing names. This supplement does not repeat the11 individual safeguard withdrawals from the original packet and does not promote early old-producer failures into specific injected-fault causal proof.\n\n`runner.lua` and `run-exact-causal.py` target the external source root in `/workspace/.ergopti-cloud/resume-personal-topology-exact-causal`; recovery elsewhere requires adjusting that path. Dependencies are identified by the Git baseline b666a22f72cf3b27e55bef08720f7064348d1d40 and the2,361-file `source-manifest.json`. Recover the Linux/shared tracked files from Git, validate the manifest, and overlay only the declared producer/test images. The duplicate captured source tree is omitted; all nonowned files are checked unchanged, with no missing or extra files.\n\nBoth prior archives are independently rehashed and remain byte-identical: original topology packet ef732a0a888d5f7c5724f9e6b42e3c5b25286b815e60ec28fdd992a3cb2d37a3 and portability supplement0bf4806c00308c64bb08be84352ef77e10be3a95b3a10885507c4b619e034a4f. This separate compact packet adds the exact adopted-test-source causal join without overwriting their evidence.\n\nNo canonical checkout, CI workflow or expectation changed. The parent owns canonical full-gate, CI and publication receipts; this external owning-module result does not qualify packaging, installed daemon, actual keyboard expansion or device acceptance. SHA256SUMS covers every other member; the archive is reopened and all member bytes compared before handoff.\n'''
for a,z in [('source2340','source 2340'),('original49','original 49'),('at38,693','at 38,693'),('All34','All 34'),('has82','has 82'),('as83','as 83'),('the11','the 11'),('the2,361','the 2,361'),('supplement0bf','supplement 0bf')]:readme=readme.replace(a,z)
(b/'README.md').write_text(readme)
files=sorted([p for p in b.iterdir()if p.is_file()and p.name!='SHA256SUMS'],key=lambda p:p.name)
(b/'SHA256SUMS').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n'for p in files));files.append(b/'SHA256SUMS');files.sort(key=lambda p:p.name)
archive=b.parent/'resume-personal-topology-exact-causal-receiving.tar.gz'
with archive.open('wb')as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0)as zipped:
  with tarfile.open(fileobj=zipped,mode='w')as tar:
   for p in files:
    data=p.read_bytes();info=tarfile.TarInfo('resume-personal-topology-exact-causal/'+p.name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive)as tar:
 assert len(tar.getmembers())==len(files)
 for p in files:assert tar.extractfile('resume-personal-topology-exact-causal/'+p.name).read()==p.read_bytes()
output={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(files),'all_members_reopened_and_byte_compared':True,'test_sha256':sha(corpus),'literal_producer_sha256':sha(literal),'restored_producer_sha256':sha(restored)}
(b.parent/'resume-personal-topology-exact-causal-receiving.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
