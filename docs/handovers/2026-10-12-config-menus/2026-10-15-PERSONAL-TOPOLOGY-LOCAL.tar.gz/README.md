# Canonical Linux Personal topology checkpoint

The final selected gate ran naturally to exit zero on frozen source bytes.
publication.json joins those exact bytes to the subsequently published source
commit and complete tree. Every member is covered by SHA256SUMS.

The earlier successful gate and the long-temp failure are retained separately;
they are not relabelled final publication receiving. The first could share old
same-second fixture names with an external reader; no collision is established.
The second is reproduced on baseline sources as a Unix socket length failure.
The final gate uses a short unique TMPDIR and TEMP after the external readers
are terminal. Native fault/port models, full units and scripted E2E remain
distinct from installed Personal profiles, packaging and physical acceptance.
