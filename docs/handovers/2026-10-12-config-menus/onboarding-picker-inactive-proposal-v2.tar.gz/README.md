# Inactive Windows onboarding modal-continuation proposal, version 2

This packet is not integrated or published. Its literal source is public Dev
`0ba71fa72c09f012c13545c9d9c5236ebf92358c`. Exact preimages and candidates are
in `SOURCE-PREIMAGES.json`; `proposal.patch` touches only the onboarding native
producer and its existing enrolled unit file. No runner, framework, manifest,
warning policy, callback, original test assertion or existing registration is changed.

## Source-derived defect

The current message callback checks its session epoch before entering the
native folder dialog. `Ui_DirSelect` then opens an unowned
`SHBrowseForFolderW` modal (`OwnerHwnd=0`). That native message loop can outlive
the wizard that opened it. After another wizard is constructed, the original
continuation publishes through `_OnbWeb_Eval`, which uses the current session
instead of the picker’s original session. A selected folder from the older
window can therefore enter the successor page.

The proposed producer captures the epoch before native selection and refuses
publication after modeled retirement. Same-session selection and both cancellation
paths retain their behavior. This is source-derived reasoning; actual native
close/reopen reproduction has not run in this Linux container.

The Windows paths-editor sibling has the same post-modal continuation gap in
`ui/paths_editor/init.ahk`, `_PathsEdWeb_Browse`. Its `_PathsEdWeb_SessionCall`
checks only before `Ui_DirSelect`; the subsequent `_PathsEdWeb_Eval` reads live
state. That sibling is outside this precise proposal and remains unchanged.
macOS captures its native owner/view before selection and checks them on
publication. The Linux synchronous picker blocks its daemon loop; this audit
does not invent an equivalent reentrancy reproduction there.

## Additive controls and their limits

Four tests append to the existing `test_onboarding_finish_payload.ahk`, which
the published principal includes. Its original bytes remain a complete prefix.
The controls replace only the original `Browse` property descriptor on the
native ABI owner, restoring that exact descriptor in `finally`. The selection
port returns a real private-folder PIDL; the genuine wrapper acquires and
releases COM, callback and PIDL resources. The modal port directly advances the epoch as a controlled model of singleton
retirement. This is not an actual modal close/reopen sequence, nor qualification
of native resource retirement during that sequence. The actual producer and existing
JavaScript queue provide the observation. Queue assertions run outside the
producer's caught native-call boundary.

Expected causal results, not executed results: with the identical seven-test
owning file, candidate 7 PASS/0 FAIL, literal producer 6 PASS/1 FAIL, restored
candidate 7 PASS/0 FAIL. The failing literal control must be the retired
selection appending into the successor queue. Four new controls include
same-owner selection, retired selection, same-owner cancellation and retired
cancellation. Do not claim these expected counts as a received native result.

Local checks: both images decode as UTF-8 with BOM and LF; `git apply --check`
accepts the patch against the unchanged owned preimages. The repository's
unchanged header, AHK anti-pattern/string-escaping, section-spacing and banner
functions report zero violations over the two external candidate images.
`lint-selected.mjs` records that bounded invocation. This is not the complete
repository convention gate and does not parse AHK. No AutoHotkey interpreter
or Wine is available. Native parsing, units, E2E, complete stdout, WebView2,
packaging, installation and actual desktop reproduction are all **UNRUN**.
`selected-gates.json` records the actual verification planner's required gates;
it is a plan, not successful gate execution.

## Concrete Windows receiving procedure

1. Root first admits the current principal/Snapshot source images and obtains
   complete native stdout using the original warnings and callbacks. Do not
   suppress warning prefixes or refresh receiving pins without independent
   review. Compose this packet only in an isolated receiving checkout whose
   owned preimages still match; refresh unrelated Dev contributions first.
2. Apply the two-path patch. Run the pinned AutoHotkey parse and `verify-change`
   gates. The owner of the inventories must handle any current test-count
   receipt changes; this packet deliberately changes none of those files.
3. Run the actual principal with `/ErrorStdOut` and
   `--only "onboarding WebView:"`, preserving both complete stdout and stderr
   and the actual command exit. Confirm all seven tests ran, including all
   original assertions. The four new controls must not silently disappear.
4. Keep the identical candidate test file and dependencies, replace only
   `ui/onboarding/webview.ahk` with its sealed literal image, and repeat. Require
   the specific retired-selection queue assertion to fail, while the six other
   tests pass. Restore the sealed candidate producer and require 7/0. Record
   source hashes, runtime version, native warning output and terminal exits
   for all phases. Do not regenerate the independent expectations.
5. Run the full unfiltered principal and E2E, preserving original warnings,
   callbacks and complete receiving. A filtered regression is not general
   qualification. Complete the current required packaging/install gates.
6. On a disposable installed WebView2 profile, open wizard A and its native
   Browse dialog. While that unowned dialog remains open, close A and open B
   through the actual tray action. Enter a distinct path in B, then accept a
   third path in A's surviving picker. B's field and state must remain intact;
   its subsequent import/Finish must use B's deliberate path. Repeat with
   cancel and with A remaining current. If the UI prevents one interaction,
   record that observed route and exercise an actual owned close/reopen
   event while the dialog pumps; do not report an unperformed sequence.
7. Independently qualify the sibling paths editor's config and logs Browse
   routes before proposing a sibling fix. This packet does not fix them.

Every step above remains required before adoption. The packet carries no
permission to publish an unreceived native change.

## Version 2 fixture cleanup review

The sealed version 1 packet remains byte-identical with SHA256
`cd2e9dcef92973d08b018ae7390cf6f862b52cf539416a59a54e0e4f2d403b22`.
Version 2 changes only the added test fixture's failure cleanup. Browse
descriptor, epoch, readiness, queue and directory each receive an independent
cleanup attempt. If a primary assertion/native Error exists, that exact Error
object is rethrown with cleanup details appended after its original message;
its original stack is retained. A cleanup-only refusal creates a separate
cleanup Error after every attempt. PIDL-acquisition cleanup likewise retains
the original acquisition Error if PIDL release also raises.

No new test is registered by this revision: the same three original subjects
and four additive controls give the same expected, unexecuted 7/0 → 6/1 → 7/0
causal sequence. Actual modal close/reopen, native retirement during it, and
cleanup-refusal injection require Windows receiving.
