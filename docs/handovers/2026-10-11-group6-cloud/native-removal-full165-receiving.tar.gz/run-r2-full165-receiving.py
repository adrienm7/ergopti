from pathlib import Path
import hashlib,json,os,signal,subprocess,time
outside=Path('/workspace/ergopti-cloud'); live=Path('/workspace/ergopti'); base=outside/'group6-native-removal-r2-full165-preparation'
inventory=json.loads((base/'source-inventory.json').read_text()); source=Path(inventory['physical_source']); rows=inventory['files']; assert len(rows)==29 and inventory['projected_census']==165
assert json.loads((outside/'native-successor-preservation-canonical-gate-receipt.json').read_text())['exit']==0, 'Serial JS gate must finish first'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fence():return {'candidate':{r['path']:sha(source/r['path']) for r in rows},'live':{r['path']:sha(live/r['path']) for r in rows}}
before=fence()
for r in rows:assert before['candidate'][r['path']]==r['candidate_sha256'] and before['live'][r['path']]==r['live_sha256'],r['path']
env=dict(os.environ);env['TMPDIR']=str(base/'private-tmp');env['PYTHONDONTWRITEBYTECODE']='1'
cmd=['/workspace/ergopti-cloud/python/bin/python','-I','-B',str(source/'tools/test/macos_native_http_receiving_facts_test.py'),'-v']
start=time.monotonic(); timed_out=False
with (base/'full165.stdout').open('wb') as out,(base/'full165.stderr').open('wb') as err:
 child=subprocess.Popen(cmd,cwd=source,env=env,stdout=out,stderr=err,start_new_session=True)
 try: code=child.wait(timeout=60)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
after=fence();assert before==after,'Source drift during full corpus'
cache=list(source.rglob('__pycache__'));assert not cache,'Unexpected bytecode cache'
try:os.killpg(child.pid,0);group_closed=False
except ProcessLookupError:group_closed=True
stderr=(base/'full165.stderr').read_text(errors='replace')
receipt={'exit':code,'seconds':round(time.monotonic()-start,3),'business_timeout_seconds':60,'timed_out':timed_out,'original165_footer_received':'Ran 165 tests in ' in stderr and stderr.rstrip().endswith('OK'),'source_fence_before_after_equal':True,'fenced_candidate_and_live_paths':29,'bytecode_cache_count':len(cache),'child_reaped':child.poll() is not None,'owned_group_absent_after_reap':group_closed,'stdout_sha256':sha(base/'full165.stdout'),'stderr_sha256':sha(base/'full165.stderr'),'native_qualified':False,'live_adoption':False}
(base/'full165-receiving.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
assert not timed_out and code==0 and receipt['original165_footer_received'] and group_closed
