local root = assert(os.getenv("ERGOPTI_NETWORK_PACKET"), "portable packet root required")
local repository = assert(os.getenv("ERGOPTI_HTTP_REPOSITORY"), "dependency repository required")
local stage = root .. "/static/ergopti_plus/linux"
package.path = stage .. "/?.lua;" .. stage .. "/?/init.lua;" .. stage .. "/../_shared/lua/?.lua;" .. repository .. "/static/ergopti_plus/linux/?.lua;" .. repository .. "/static/ergopti_plus/_shared/lua/?.lua;" .. package.path
for _, name in ipairs({"test_proxy_policy", "test_managed_http", "test_system_proxy", "test_system_proxy_callbacks", "test_runtime_executable", "test_literal_nul_admission", "test_native_diagnostic_privacy", "test_curl_engine_scan"}) do
 dofile(root .. "/controls/" .. name .. ".lua")
end
local results = require("tests.helpers").get_results()
print(string.format("LINUX HTTP CONTINUATION MODELS: %d passed, %d failed", results.passed, results.failed))
os.exit(results.failed == 0 and 0 or 1)
