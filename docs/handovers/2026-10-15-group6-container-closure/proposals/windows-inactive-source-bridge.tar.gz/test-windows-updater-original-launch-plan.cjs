// Source-only declaration controls; never import the inert native API or launch.
'use strict';
const assert = require('node:assert/strict');
const {
	bindLaunchRequirements,
	FILTERS,
	PROVIDER_SHA256
} = require('./windows-updater-original-launch-plan.cjs');

const copy = (value) => JSON.parse(JSON.stringify(value));
function pair(role = 'original23') {
	const request = {
		role,
		candidate: 'a'.repeat(40),
		source_manifest_sha256: 'b'.repeat(64),
		caller: { path: 'C:\\Qualification\\caller.cjs', sha256: 'c'.repeat(64) },
		runtime: { path: 'C:\\Qualification\\AutoHotkey64.exe', sha256: 'd'.repeat(64) },
		entry: { path: 'C:\\Qualification\\source\\run_all.ahk', sha256: 'e'.repeat(64) },
		nonce: 'f'.repeat(32),
		captures: { stdout: '1'.repeat(64), stderr: '2'.repeat(64) },
		environment: {
			LOCALAPPDATA: 'C:\\Qualification\\isolated',
			ERGOPTI_STARTUP_SMOKE_DIR: 'C:\\Qualification\\isolated',
			ERGOPTI_STARTUP_SMOKE_NONCE: 'f'.repeat(32)
		},
		filter: role === 'original23' ? '(updater-channel-replacement-transaction)' : null,
		dry_run: false
	};
	const expected = copy(request);
	delete expected.environment;
	return { request, expected };
}

let passed = 0;
function check(name, callback) {
	callback();
	passed += 1;
	console.log(`PASS ${name}`);
}

check('all original three filters and unchanged original budgets', () => {
	assert.deepEqual(FILTERS, [
		'(updater-channel-replacement-transaction)',
		'(updater-global-config-barrier)',
		'(updater-channel-inherited-critical)'
	]);
	for (const filter of FILTERS)
		for (const dry of [false, true]) {
			const { expected, request } = pair();
			expected.filter = request.filter = filter;
			expected.dry_run = request.dry_run = dry;
			const output = bindLaunchRequirements(expected, request);
			assert.deepEqual(output.argv, [
				'/ErrorStdOut',
				request.entry.path,
				`--only=${filter}`,
				...(dry ? ['--dry-run'] : [])
			]);
			assert.equal(output.original_budget_ms, 300000);
		}
});
check('interpreted startup keeps its own argv and explicit environment', () => {
	const { expected, request } = pair('interpreted-startup');
	const output = bindLaunchRequirements(expected, request);
	assert.deepEqual(output.argv, ['/ErrorStdOut', request.entry.path]);
	assert.equal(output.original_budget_ms, 120000);
	assert.deepEqual(output.environment, request.environment);
});
check('actual received provider identity and inert roles are unchanged', () => {
	const { expected, request } = pair();
	const output = bindLaunchRequirements(expected, request);
	assert.equal(PROVIDER_SHA256, 'd02912f92dc73444b1f7ff8ff03ea3df91e292523c42aa632b0c3f0f30beee36');
	assert.equal(output.provider_source_sha256, PROVIDER_SHA256);
	assert.deepEqual(output.provider_roles_unchanged, ['node-inert', 'powershell-inert']);
	assert.equal(output.unreceived_native_contract.length, 7);
});
check('source bindings never grant native authority', () => {
	const { expected, request } = pair();
	const output = bindLaunchRequirements(expected, request);
	assert.equal(output.status, 'SOURCE_BINDING_ONLY_NO_RUNTIME_AUTHORITY');
	for (const key of ['executable', 'provider_qualified', 'native23_qualified'])
		assert.equal(output[key], false);
	assert.ok(Object.isFrozen(output));
	assert.ok(Object.isFrozen(output.argv));
	assert.ok(Object.isFrozen(output.environment));
	assert.throws(() => {
		output.executable = true;
	}, TypeError);
	request.runtime.path = 'C:\\Changed.exe';
	assert.equal(output.runtime.path, 'C:\\Qualification\\AutoHotkey64.exe');
});
for (const field of ['candidate', 'source_manifest_sha256', 'nonce'])
	check(`${field} mutation refuses`, () => {
		const { expected, request } = pair();
		request[field] = '0'.repeat(request[field].length);
		assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	});
for (const role of ['caller', 'runtime', 'entry'])
	for (const key of ['path', 'sha256'])
		check(`${role}.${key} swap refuses`, () => {
			const { expected, request } = pair();
			request[role][key] = key === 'path' ? 'C:\\Qualification\\foreign.exe' : '0'.repeat(64);
			assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
		});
check('role and filter cannot be changed under the same caller/nonce', () => {
	for (const change of [
		{ role: 'interpreted-startup', filter: null },
		{ filter: FILTERS[1] },
		{ dry_run: true },
		{ role: 'powershell-inert' }
	]) {
		const { expected, request } = pair();
		Object.assign(request, change);
		assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	}
});
check('unknown fields and claimed capabilities refuse', () => {
	for (const extra of [
		'argv',
		'provider',
		'qualified',
		'native23_qualified',
		'callback',
		'profile'
	]) {
		const { expected, request } = pair();
		request[extra] = true;
		assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	}
});
check('capture swap and duplicate captures refuse', () => {
	for (const key of ['stdout', 'stderr']) {
		const { expected, request } = pair();
		request.captures[key] = '0'.repeat(64);
		assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	}
	const { expected, request } = pair();
	expected.captures.stderr = request.captures.stderr = request.captures.stdout;
	assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
});
check('explicit environment aliases and runtime preloads refuse', () => {
	for (const environment of [
		null,
		{},
		{ Path: 'a', PATH: 'b' },
		{ NODE_OPTIONS: '--require foreign' },
		{ PYTHONPATH: 'foreign' },
		{ DOTNET_STARTUP_HOOKS: 'foreign' },
		{ COMPLUS_ReadyToRun: '1' },
		{ X: 'bad\0value' },
		{ X: '\ud800' }
	]) {
		const { expected, request } = pair();
		request.environment = environment;
		assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	}
});
check('data accessors refuse without executing a getter', () => {
	const { expected, request } = pair();
	let calls = 0;
	Object.defineProperty(request, 'nonce', {
		enumerable: true,
		get() {
			calls += 1;
			return expected.nonce;
		}
	});
	assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	assert.equal(calls, 0);
});
check('path aliases do not become approved image declarations', () => {
	for (const value of [
		'relative.exe',
		'\\\\server\\share\\a.exe',
		'C:/a.exe',
		'C:\\a\\..\\b.exe',
		'C:\\a.\\b.exe',
		'C:\\a.exe:stream',
		'C:\\a\0.exe',
		'C:\\a\\\\b.exe',
		'C:\\a\ud800.exe'
	]) {
		const { expected, request } = pair();
		expected.runtime.path = request.runtime.path = value;
		assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	}
});
check('startup nonce and local fixture root cannot drift', () => {
	for (const change of [
		{ ERGOPTI_STARTUP_SMOKE_NONCE: '0'.repeat(32) },
		{ ERGOPTI_STARTUP_SMOKE_DIR: 'C:\\Foreign' },
		{ LOCALAPPDATA: '' }
	]) {
		const { expected, request } = pair('interpreted-startup');
		Object.assign(request.environment, change);
		assert.throws(() => bindLaunchRequirements(expected, request), TypeError);
	}
});
console.log(`Source-only declaration controls: ${passed} PASS; native execution UNRUN.`);
