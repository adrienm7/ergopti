import subprocess,pathlib,json,os,datetime
from zoneinfo import ZoneInfo
p=pathlib.Path('/workspace/scratch/oct28-recommended-oracle-review/revision2')
with(p/'producer.log').open('wb')as f:
 c=subprocess.Popen(['python3',str(p/'finish-proof.py')],stdout=f,stderr=subprocess.STDOUT)
 (p/'producer.json').write_text(json.dumps({'wrapper_pid':os.getpid(),'producer_pid':c.pid})+'\n');rc=c.wait()
(p/'tool-exit.json').write_text(json.dumps({'actual_child_wait_exit':rc,'finished_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()})+'\n')
