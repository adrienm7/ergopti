package.preload["modules.shortcuts.keyboard_shortcuts"]=function() return assert(loadfile("/workspace/.ergopti-cloud/recovery-2026-10-10/baseline-e2e-overlay/keyboard_shortcuts.lua"))() end
if arg then arg[-1]="/workspace/.ergopti-cloud/recovery-2026-10-10/baseline-e2e-overlay/luajit-old" end
