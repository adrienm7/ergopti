#!/usr/bin/env python3
"""Materialize sealed proposal inputs in this external packet, never over a checkout."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

packet = Path(__file__).resolve().parent
repository = Path(sys.argv[1]).resolve()
contract = json.loads((packet / 'HANDWRITTEN-FOUR-SITE-CONTRACT.json').read_text())
manifest = json.loads((packet / 'PATCH-MANIFEST.json').read_text())
for role in ('before', 'candidate'):
    if (packet / role).exists():
        raise SystemExit(f'Refusing to overwrite existing {role} inputs')
for row in manifest:
    source = subprocess.check_output(
        ['git', 'show', f"{contract['source_sha']}:{row['path']}"], cwd=repository
    )
    assert hashlib.sha256(source).hexdigest() == row['before_sha256']
    for role in ('before', 'candidate'):
        destination = packet / role / row['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source)
for row in manifest:
    subprocess.run(
        ['patch', '--batch', '--fuzz=0', '-p1', '-i', str(packet / row['patch'])],
        cwd=packet / 'candidate', check=True,
    )
    result = (packet / 'candidate' / row['path']).read_bytes()
    assert hashlib.sha256(result).hexdigest() == row['candidate_sha256']
print('Materialized only the six sealed before/candidate files; no checkout was edited.')
