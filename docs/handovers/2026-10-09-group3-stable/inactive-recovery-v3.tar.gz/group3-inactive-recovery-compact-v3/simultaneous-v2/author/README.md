<!-- Private Linux93 original Hook cohort cleanup successor -->

# Inactive simultaneous v2: published Reader cohort cleanup

This two-path successor depends on the immutable private simultaneous v1 receipt
`288b9a6b9123892fc2882282ff248e5e22e4422301f501663b1db925ff3f0de4`.
V1 remains review-blocked: after a completed chord and original releases, real
Hook `check_device` remove/re-add publishes a new Hook-owned Reader, but Stop
selects its stale buffered cleanup map and leaves the new Reader current/open.
The independent probe reproduced v1 FAIL/original production PASS on both ABIs.
V1 bytes remain intact. This successor is private and independently unreviewed;
it is excluded from tonight's integrated source and has no public/native claim.

The product delta is eight Hook lines. Only a successful existing source
transaction with native-complete original authority replaces the retained
buffered cleanup map with its exact acknowledged `tx.sources` and `tx.pointers`.
No additional getter, numeric slot authority, foreign close or Writer operation
is added. A foreign Reader replacement outside that original publication still
retains the prior cleanup lease; the existing dedicated foreign replacement
regression remains green.

The registered module's entire v1 prefix is unchanged. One appended control
performs completed input → actual check_device cadence → remove → re-add → Stop.
It captures the new original Reader lease before Stop, observes current/open
state, then privately retires only that probe lease before asserting the recorded
product observations. Probe cleanup therefore cannot turn a failure into PASS.

Both LuaJIT and Lua5.4 pass189/0, retaining all188 v1 cases (161 old,27 v1 additions).
V1 product with that appended control gives188/1 on each. The verbatim independent
probe gives old exit1/current=true/open=true → new exit0/current=false/open=false
on each. Existing source/options, output ACK/debt and foreign Reader preservation
controls remain intact. All tests use the existing explicitly controlled FFI
constructor, not real kernel devices. Kernel hotplug, physical input, public
simultaneous admission/defaults/menu/Save/copy transaction and full suites remain
UNEXECUTED or unimplemented as recorded by v1. No canonical/index/Git/workflow/
generator or original frozen packet was changed.

Verify this directory and ordered application without modifying any checkout:

```sh
sha256sum --check files.sha256
(cd preimages && git apply --check ../candidate.patch)
```

Focused replay requires the frozen v1 dependencies and ordinary cloud Lua/Luv
activation. Run serially from the canonical Linux directory, using this private
overlay followed by frozen v1; never alongside a canonical full suite:

```sh
. /workspace/.ergopti-cloud/activate.sh
cd /workspace/ergopti/static/ergopti_plus/linux
/workspace/.ergopti-cloud/bin/luajit /ABS/V2/run_overlay.lua /ABS/V2 /ABS/V1
/workspace/.ergopti-cloud/bin/lua5.4 /ABS/V2/run_overlay.lua /ABS/V2 /ABS/V1
```

For the standalone verbatim probe, run from V2 with `replay_probe.lua ROOT V1 V2`.
For the intentional188/1 predecessor, use `V2/old-with-regression` instead of V2
in the focused runner. Review/admission must join both ordered source packets
and resolve actual Hook/Pair/Base/source-owner overlap; no missing permission is
inferred and no new input or output capability is advertised.
