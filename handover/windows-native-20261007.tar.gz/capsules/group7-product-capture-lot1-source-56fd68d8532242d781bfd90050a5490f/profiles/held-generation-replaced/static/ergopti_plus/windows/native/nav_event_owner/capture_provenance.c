// static/ergopti_plus/windows/native/nav_event_owner/capture_provenance.c
/** @file capture_provenance.c
 * @brief Effect-free provenance used by the real terminal-capture callback.
 */
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <string.h>
#include "capture_provenance.h"

void NavCaptureProvenance_Reset(NavCaptureProvenanceState *state)
{
    memset(state, 0, sizeof(*state));
}

int NavCaptureProvenance_Observe(NavCaptureProvenanceState *state,
    uint16_t vk, uint16_t sc, uint32_t flags, uint64_t extra_info, uint32_t time,
    uint8_t kind, uint8_t modifier_bit, uint64_t capture_token,
    uint64_t navigation_generation, uint64_t profile_generation,
    NavCaptureProvenanceEdge *out_edge)
{
    uint32_t index;
    uint32_t level;
    uint8_t repeated;
    uint8_t initial_known;
    if (state == NULL || out_edge == NULL || vk == 0 || vk > 0xFFu || sc > 0xFFu
            || (flags & ~(LLKHF_EXTENDED | LLKHF_LOWER_IL_INJECTED | LLKHF_INJECTED | LLKHF_ALTDOWN | LLKHF_UP)) != 0 || (kind != ERGOPTI_NAV_EVENT_DOWN && kind != ERGOPTI_NAV_EVENT_UP)
            || ((flags & LLKHF_UP) != 0) != (kind == ERGOPTI_NAV_EVENT_UP)
            || ((flags & LLKHF_LOWER_IL_INJECTED) != 0 && (flags & LLKHF_INJECTED) == 0)
            || (modifier_bit && (modifier_bit & (modifier_bit - 1u))))
        return 0;
    if (state->faulted || state->next_sequence == UINT64_MAX) {
        state->faulted = 1;
        return 0;
    }
    memset(out_edge, 0, sizeof(*out_edge));
    out_edge->sequence = ++state->next_sequence;
    out_edge->capture_token = capture_token;
    out_edge->navigation_generation = navigation_generation;
    out_edge->profile_generation = profile_generation;
    out_edge->vk = vk;
    out_edge->sc = sc;
    out_edge->flags = flags;
    out_edge->extra_info = extra_info;
    out_edge->time = time;
    out_edge->kind = kind;
    if ((flags & LLKHF_INJECTED) == 0) {
        index = sc ? sc + ((flags & LLKHF_EXTENDED) ? 256u : 0u) : 512u + vk;
        repeated = state->down[index];
        initial_known = state->known[index];
        out_edge->repeat_known = initial_known;
        if (kind == ERGOPTI_NAV_EVENT_DOWN) {
            out_edge->repeat = repeated;
            if (!repeated) {
                state->down_sequence[index] = out_edge->sequence;
                state->down_capture_token[index] = capture_token;
                state->navigation_generation[index] = navigation_generation;
                state->profile_generation[index] = profile_generation;
                state->action_sequence[index] = initial_known ? out_edge->sequence : 0;
                out_edge->reserve_action = initial_known;
            }
            state->down[index] = 1;
        }
        out_edge->down_sequence = state->down_sequence[index];
        out_edge->action_sequence = state->action_sequence[index];
        out_edge->down_capture_token = state->down_capture_token[index];
        if (repeated || kind == ERGOPTI_NAV_EVENT_DOWN) {
            out_edge->navigation_generation = navigation_generation;
            out_edge->profile_generation = state->profile_generation[index];
        }
        state->known[index] = 1;
        if (modifier_bit) {
            state->known_modifier_lr = (uint8_t)(state->known_modifier_lr | modifier_bit);
            if (kind == ERGOPTI_NAV_EVENT_UP)
                state->physical_lr = (uint8_t)(state->physical_lr & ~modifier_bit);
            else
                state->physical_lr = (uint8_t)(state->physical_lr | modifier_bit);
        }
        if (kind == ERGOPTI_NAV_EVENT_UP) {
            state->down[index] = 0;
            state->down_sequence[index] = 0;
            state->action_sequence[index] = 0;
            state->down_capture_token[index] = 0;
        }
    } else if ((flags & LLKHF_LOWER_IL_INJECTED) == 0 && modifier_bit
            && extra_info <= ERGOPTI_NAV_AHK_SEND_LEVEL_BASE
            && extra_info >= ERGOPTI_NAV_AHK_SEND_LEVEL_BASE - ERGOPTI_NAV_AHK_SEND_LEVEL_MAX) {
        level = (uint32_t)(ERGOPTI_NAV_AHK_SEND_LEVEL_BASE - extra_info);
        if (kind == ERGOPTI_NAV_EVENT_UP)
            state->injected_lr[level] = (uint8_t)(state->injected_lr[level] & ~modifier_bit);
        else
            state->injected_lr[level] = (uint8_t)(state->injected_lr[level] | modifier_bit);
    }
    out_edge->physical_lr = state->physical_lr;
    out_edge->known_modifier_lr = state->known_modifier_lr;
    memcpy(out_edge->injected_lr, state->injected_lr, sizeof(out_edge->injected_lr));
    return 1;
}

int NavCaptureProvenance_Effective(const NavCaptureProvenanceEdge *edge,
    uint8_t input_level, uint8_t *out_mask)
{
    uint8_t mask;
    uint32_t index;
    if (edge == NULL || out_mask == NULL || input_level > ERGOPTI_NAV_AHK_SEND_LEVEL_MAX)
        return 0;
    mask = edge->physical_lr;
    for (index = (uint32_t)input_level + 1; index <= ERGOPTI_NAV_AHK_SEND_LEVEL_MAX; ++index)
        mask = (uint8_t)(mask | edge->injected_lr[index]);
    *out_mask = mask;
    return 1;
}
