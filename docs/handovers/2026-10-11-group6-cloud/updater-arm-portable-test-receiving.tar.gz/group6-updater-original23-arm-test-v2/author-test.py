from pathlib import Path
import shutil, hashlib
base = Path('/workspace/ergopti-cloud/group6-updater-original23-current-source-plan')
root = Path(__file__).parent
rel = 'tools/test/test-windows-updater-original-source.cjs'
shutil.copytree(base/'canonical-physical-source', root/'physical-source', dirs_exist_ok=True)
old = (base/'proposal-candidate'/rel).read_text()
(root/'preimage.cjs').write_text(old)
s = old
needle = 'async function modelMain(f, code) {'
helper = '''// A private CommonJS realm models architecture only; Git, filesystem and Source bytes remain real.
// The module and CLI share Object prototypes; injected Error preserves assertion error identity.
function architectureModel(f, architecture, overrides = {}) {
	const context = vm.createContext({
		process: { ...process, arch: architecture, env: process.env, ...overrides.process },
		Error,
		Buffer,
		setTimeout,
		clearTimeout,
		console: overrides.console || console
	});
	let api;
	const required = (name) => {
		if (name === './windows-updater-original-source.cjs') return api;
		if (name === 'node:child_process' && overrides.childProcess) return overrides.childProcess;
		return f.required(name);
	};
	function load(relative, code = fs.readFileSync(path.join(f.directory, relative), 'utf8')) {
		const ownedModule = { exports: {} };
		const compiled = vm.runInContext('(function(require,module,__dirname){\\n' + code + '\\n})', context, {
			filename: path.join(f.directory, relative)
		});
		compiled(required, ownedModule, path.dirname(path.join(f.directory, relative)));
		return ownedModule.exports;
	}
	api = load(modulePath);
	return { api, cli: load(collectorPath), context, required };
}
const passiveCopy = (value) => JSON.parse(JSON.stringify(value));
'''
assert s.count(needle)==1
s=s.replace(needle,helper+needle)
start=s.index('\tconst required = f.required;\n',s.index(needle))
end=s.index('\tconst receipt = JSON.parse(stdout.at(-1));',start)
s=s[:start]+'''	const model = architectureModel(f, 'x64', {
		childProcess: {
			...cp,
			spawn: (...args) => {
				calls.push(args);
				throw new Error('CONTROLLED_NO_NATIVE_ACQUISITION');
			}
		},
		console: {
			log: (x) => stdout.push(String(x)),
			error: (...x) => stderr.push(x.map(String).join(' '))
		},
		process: {
			platform: 'win32',
			argv: [process.execPath, 'collector.cjs', '--local', ahk, '2.0.0.0', evidence],
			env,
			exit: (x) => exits.push(x)
		}
	});
	model.context.require = model.required;
	model.context.module = { exports: {} };
	model.context.__dirname = path.dirname(path.join(f.directory, collectorPath));
	await vm.runInContext(code + '\\nmain();', model.context, {
		filename: path.join(f.directory, collectorPath)
	});
'''+s[end:]
s=s.replace("'imports neither main nor Source or native acquisition'", "'imports collect no Source receipt and start neither main nor native children'")
oldblock="""		withEnvironment({}, () => {
			const v = f.api.localInvocation(['--local', '/absolute/ahk.exe', '2.0.0.0', temporary]);
			assert.deepEqual(v.context, f.context);
			assert.deepEqual(v.arguments, ['/absolute/ahk.exe', '2.0.0.0']);
			assert.equal(v.evidence_root, temporary);
		});"""
newblock="""		withEnvironment({}, () => {
			const args = ['--local', '/absolute/ahk.exe', '2.0.0.0', temporary];
			const v = architectureModel(f, 'x64').api.localInvocation(args);
			assert.deepEqual(passiveCopy(v.context), f.context);
			assert.deepEqual(passiveCopy(v.arguments), ['/absolute/ahk.exe', '2.0.0.0']);
			assert.equal(v.evidence_root, temporary);
			refuses(() => architectureModel(f, 'arm64').api.localInvocation(args), /architecture/);
		});"""
assert s.count(oldblock)==1
s=s.replace(oldblock,newblock)
oldblock="""		withEnvironment({}, () => {
			const before = f.api.localInvocation(['--local', '/ahk', 'v', temporary]);
			withEnvironment({ GITHUB_TOKEN: 'independent noncredential sentinel' }, () =>
				assert.deepEqual(f.api.localInvocation(['--local', '/ahk', 'v', temporary]), before)
			);
			assert.equal(before.context.context_bound, false);
			assert.equal(before.context.run_id, null);
		});"""
newblock="""		withEnvironment({}, () => {
			const model = architectureModel(f, 'x64');
			const before = model.api.localInvocation(['--local', '/ahk', 'v', temporary]);
			withEnvironment({ GITHUB_TOKEN: 'independent noncredential sentinel' }, () =>
				assert.deepEqual(model.api.localInvocation(['--local', '/ahk', 'v', temporary]), before)
			);
			assert.equal(before.context.context_bound, false);
			assert.equal(before.context.run_id, null);
		});"""
assert s.count(oldblock)==1
s=s.replace(oldblock,newblock)
oldblock="""				if (process.arch === 'x64') {
					const v = f.cli.invocation();
					assert.equal(v.local, false);
					assert.equal(v.context.role, 'candidate');
					assert.equal(v.context.context_bound, true);
					assert.equal(v.context.run_id, '123');
					assert.equal(v.context.run_attempt, '2');
				} else refuses(() => f.cli.invocation(), /architecture/);"""
newblock="""				const args = process.argv;
				const v = architectureModel(f, 'x64', { process: { argv: args } }).cli.invocation();
				assert.equal(v.local, false);
				assert.equal(v.context.role, 'candidate');
				assert.equal(v.context.context_bound, true);
				assert.equal(v.context.run_id, '123');
				assert.equal(v.context.run_attempt, '2');
				refuses(
					() => architectureModel(f, 'arm64', { process: { argv: args } }).cli.invocation(),
					/architecture/
				);"""
assert s.count(oldblock)==1
s=s.replace(oldblock,newblock)
(root/'physical-source'/rel).write_text(s)
print(hashlib.sha256(s.encode()).hexdigest())
