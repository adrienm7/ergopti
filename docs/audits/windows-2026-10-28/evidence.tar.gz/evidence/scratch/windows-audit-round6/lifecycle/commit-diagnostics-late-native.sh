#!/usr/bin/env bash
set -euo pipefail

: "${1:?Pass the owned checkout path}"
cd -- "$1"
python3 '/workspace/scratch/windows-audit-round6/lifecycle/validate-native-controls.py' "$PWD"
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
npm run lint:conventions:strict
if test -n "$(git diff --cached --name-only)"; then
  printf "%s\n" "Refusing to mix an existing index with the native control fix" >&2
  exit 1
fi
git add -- 'static/ergopti_plus/windows/ui/healthcheck/core.ahk' 'static/ergopti_plus/windows/tests/unit/ui/healthcheck/test_diagnostics_window_control.ahk'
git commit -F '/workspace/scratch/windows-audit-round6/lifecycle/diagnostics-late-native-commit-message.txt'
python3 '/workspace/scratch/windows-audit-round6/lifecycle/validate-native-controls.py' "$PWD"
