from pathlib import Path
import difflib,hashlib,json,re,subprocess,tarfile,gzip,io
b=Path('/workspace/.ergopti-cloud/resume-personal-watch-topology')
sha=lambda data: hashlib.sha256(data).hexdigest()
producer='static/ergopti_plus/linux/infra/file_watchers.lua'
test='static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua'
manifest=json.loads((b/'source-manifest.json').read_text())
matrix=json.loads((b/'final-matrix.json').read_text())
assert matrix['state']=='COMPLETE' and len(matrix['phases'])==26
source=(b/'candidate3-prepared.lua').read_bytes();corpus=(b/'tests-83.lua').read_bytes();original=(b/'literal-tests.lua').read_bytes()
assert sha(source)=='ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768'
assert sha(corpus)=='d14677ca2fd8f79acdb973e4ea4d7f76b4a896e08890bf91b833bbf9d2a73f6c'
assert corpus.startswith(original) and corpus==original+(b/'added-tests.lua').read_bytes()
assert (b/'source'/producer).read_bytes()==source and (b/'source'/test).read_bytes()==corpus
all_files={p['path']for p in manifest['files']}
for f in manifest['files']:
 p=b/'source'/f['path'];assert p.is_file(),f['path']
 if f['path']not in (producer,test):assert sha(p.read_bytes())==f['sha256'],f['path']
assert all_files=={str(p.relative_to(b/'source'))for p in (b/'source').rglob('*')if p.is_file()}
original_ok=None
summary=[]
for row in matrix['phases']:
 assert row['test_sha256']==sha(corpus)
 prefix=f"{row['name']}-{row['runtime']}"
 assert row==json.loads((b/f'{prefix}-status.json').read_text())
 for stream in ('stdout','stderr'):
  assert sha((b/f'{prefix}.{stream}.log').read_bytes())==row[f'{stream}_sha256']
 is_negative=row['name'].startswith('withdraw-')
 assert row['exit_code']==(1 if is_negative else 0)
 if is_negative:
  assert row['passed']==0 and row['failed']==row['expected_failed_for_control']>0
  image=b/(row['name']+'.lua');assert sha(image.read_bytes())==row['producer_sha256']
 else:
  assert row['passed']==83 and row['failed']==0 and row['producer_sha256']==sha(source)
  names=re.findall(r'^  ok   (.*)$',(b/f'{prefix}.stdout.log').read_text(),re.M)
  assert len(names)==83
  if original_ok is None:original_ok=names[:49]
  assert names[:49]==original_ok
 summary.append({k:row[k]for k in ('name','runtime','producer_sha256','exit_code','passed','failed') }|{'named_failures':[x['name']for x in row['failures']]})
for runtime in ('lua54','luajit'):
 row=json.loads((b/f'literal83-{runtime}-status.json').read_text())
 assert (row['passed'],row['failed'],row['exit_code'])==(55,28,1)
 names=re.findall(r'^  ok   (.*)$',(b/f'literal83-{runtime}.log').read_text(),re.M)
 assert names[:49]==original_ok
assert not list(Path('/var/tmp/ergopti-cloud-validation').glob('ergopti_topology_*'))
for name,delta in [('tests-72-rejected-reentry.lua','added-tests-v2.lua'),('tests-72-same-owner.lua','added-tests-v3.lua'),('tests-77.lua','added-tests-v4.lua'),('tests-80-fixture-typo.lua','added-tests-v5.lua'),('tests-81.lua','added-tests-81.lua')]:
 (b/name).write_bytes(original+(b/delta).read_bytes())
preimages={producer:{'before':sha((b/'literal-producer.lua').read_bytes()),'after':sha(source)},test:{'before':sha(original),'after':sha(corpus)}}
(b/'preimages.json').write_text(json.dumps(preimages,indent=2)+'\n')
patch=''
for name,old,new in [(producer,(b/'literal-producer.lua').read_text(),source.decode()),(test,original.decode(),corpus.decode())]:
 patch+=f'diff --git a/{name} b/{name}\n'+''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(b/'proposal.patch').write_text(patch)
# Patch check uses ONLY external literal files, never the canonical checkout.
preimage_dir=b/'patch-check-preimages'
for name,content in [(producer,(b/'literal-producer.lua').read_bytes()),(test,original)]:
 p=preimage_dir/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
checked=subprocess.run(['git','apply','--check',str(b/'proposal.patch')],cwd=preimage_dir,text=True,capture_output=True)
assert checked.returncode==0,(checked.stdout,checked.stderr)
versions={key:subprocess.run(cmd,text=True,capture_output=True).stdout.strip()for key,cmd in [('lua54',['lua','-v']),('luajit',['luajit','-v']),('gnu_ls',['ls','--version'])]}
receipt={'status':'COMPLETE_EXTERNAL_OWNING_MODULE_ONLY','baseline_commit':manifest['commit'],'owned_preimages':preimages,'original_prefix_bytes':len(original),'original_subjects':49,'new_subjects':34,'final_subjects':83,'literal_final83_each_engine':{'passed':55,'failed':28,'exit_code':1},'matrix_phases':summary,'full_candidate_and_restored_each_engine':{'passed':83,'failed':0,'exit_code':0},'preserved_original49_names':original_ok,'dependency_capture':{'file_count':len(manifest['files']),'nonowned_missing_changed_or_extra':[],'recovery':'git archive b666a22f72cf3b27e55bef08720f7064348d1d40 static/ergopti_plus/linux static/ergopti_plus/_shared; validate source-manifest.json before overlaying only the two final images'},'remaining_owned_fixture_directories':[],'external_preimage_patch_check':{'exit_code':checked.returncode,'stdout':checked.stdout,'stderr':checked.stderr},'versions':versions,'limits':['No full canonical gate, CI, installed daemon, Hotstrings engine, packaging or device result is contained in this external receipt.','M.stop boolean acknowledges Personal retirement ledger only; generic root shutdown semantics are historical.','Root disappearance accepted callback is preserved; new parent-anchor/reappearance coverage is excluded.','Artificial clock advances and controlled native-boundary faults/reentry/callback replay establish source contracts, not actual kernel failure or process reentrancy scheduling.','GNU ls NUL fallback tested here with coreutils9.7; other native distributions/versions remain unqualified.']}
(b/'receiving-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
# Include every raw terminal evidence artifact and historical source/corpus in b,
# excluding the captured dependencies and independent patch-check duplicate tree.
files=sorted([p for p in b.iterdir()if p.is_file()and p.name!='SHA256SUMS'],key=lambda p:p.name)
(b/'SHA256SUMS').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n'for p in files))
files.append(b/'SHA256SUMS');files.sort(key=lambda p:p.name)
archive=b.parent/'resume-personal-watch-topology-receiving.tar.gz'
with archive.open('wb')as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0)as zipped:
  with tarfile.open(fileobj=zipped,mode='w')as tar:
   for p in files:
    data=p.read_bytes();info=tarfile.TarInfo('resume-personal-watch-topology/'+p.name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive)as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for p in files:assert tar.extractfile('resume-personal-watch-topology/'+p.name).read()==p.read_bytes()
archive_receipt={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(files),'all_members_reopened_and_byte_compared':True,'producer_sha256':sha(source),'test_sha256':sha(corpus),'omitted_dependency_tree':'source/; recover from baseline Git commit and source-manifest.json','omitted_duplicate_preimage_tree':'patch-check-preimages/'}
(b.parent/'resume-personal-watch-topology-receiving.json').write_text(json.dumps(archive_receipt,indent=2)+'\n')
print(json.dumps(archive_receipt,indent=2))
