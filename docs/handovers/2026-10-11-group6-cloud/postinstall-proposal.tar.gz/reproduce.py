"""Replay an unadopted two-file proposal against its exact existing checkout."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("repository", type=Path)
parser.add_argument("--ruff", default="ruff")
options = parser.parse_args()
root = options.repository.resolve()
packet = Path(__file__).resolve().parent
manifest = json.loads((packet / "manifest.json").read_text())
for name, binding in manifest["files"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == binding["preimage"]
    for role in ("preimage", "candidate"):
        assert hashlib.sha256((packet / role / name).read_bytes()).hexdigest() == binding[role]
version = subprocess.run([options.ruff, "--version"], check=True, capture_output=True, text=True)
assert version.stdout.strip() == "ruff 0.15.8"
files = [str(packet / "candidate" / name) for name in manifest["files"]]
subprocess.run([options.ruff, "format", "--check", "--config", str(root / "pyproject.toml"), *files], check=True)
subprocess.run([options.ruff, "check", "--config", str(root / "pyproject.toml"), *files], check=True)
for subject, extra, expected_status in [("original", ["--additional-only"], 1), ("candidate", [], 0)]:
    result = subprocess.run([sys.executable, "-I", "-B", str(packet / "receive.py"), subject, "--repository", str(root), *extra])
    assert result.returncode == expected_status, (subject, result.returncode)
