"""Semantic checks of original-owner fixture outputs; no macOS native operation."""

import copy
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
SEEDED = Path(sys.argv[2])
UNSEEDED = Path(sys.argv[3])
ORDINARY = Path(sys.argv[4])
NAMES = [
    "composed-single",
    "empty-pending-backspace",
    "spacing-accent-backspace-control",
    "empty-pending-escape",
    "empty-pending-arrow",
    "two-ascii-event",
    "two-ascii-separate-control",
    "unicode-ascii-event-control",
    "two-latin-event-control",
    "three-ascii-event-control",
    "suffix-only-unicode-prefix",
    "suffix-only-spaced-punctuation",
    "suffix-only-separated-control",
]
OWNERS = {
    "keymap_add": "modules/keymap/init.lua",
    "registry_tail": "modules/keymap/registry.lua",
    "expander": "modules/keymap/expander.lua",
    "serializer": "adapters/synthetic_input.lua",
}
EXPECTED_BUFFERS = [
    "aé",
    "",
    "a",
    "a",
    "",
    "^0",
    "",
    "",
    "",
    "",
    "´EXPANDED",
    "\u202fEXPANDED",
    "´EXPANDED",
]


def check(record, profile):
    marker = profile == "seeded"
    ordinary = profile == "ordinary"
    baselines = 1 if marker else (2 if ordinary else 0)
    expected_buffers = EXPECTED_BUFFERS.copy()
    if profile == "unseeded":
        for i, value in {7: "€0", 8: "éà", 9: "^00", 10: "´0", 11: "\u202f?"}.items():
            expected_buffers[i] = value
    assert "No native macOS" in record["qualification"]
    rows = record["rows"]
    assert [row["name"] for row in rows] == NAMES
    for index, row in enumerate(rows):
        assert set(row["owner_sources"]) == set(OWNERS)
        for role, path in OWNERS.items():
            assert row["owner_sources"][role] == "@" + str(
                ROOT / "static/ergopti_plus/macos" / path
            )
        assert row["buffer"] == expected_buffers[index]
        assert (
            row["observations"] and row["observations"][-1]["buffer"] == row["buffer"]
        )
        if index < 6 or (profile == "unseeded" and index in (7, 8, 9, 10, 11)):
            assert row["emitted_count"] == 0
            assert all(
                not observation["consumed"]
                and observation["returned_count"] == 0
                and observation["returned_text"] == ""
                for observation in row["observations"]
            )
        else:
            assert row["emitted_count"] == 1 and row["emitted"] == ["EXPANDED"]
            last = row["observations"][-1]
            assert last["consumed"] is True and last["returned_text"] == "EXPANDED"
            assert last["returned_count"] == (18 if index == 6 else 16)
        if index >= 5:
            assert (
                len(row["observations"]) == (2 if index in (6, 12) else 1) + baselines
            )
            if marker:
                assert row["observations"][0]["input"] == ""
            if ordinary:
                first, second = row["observations"][:2]
                assert first["input"] == "x" and first["buffer"] == "x"
                assert (
                    second["input"] == ""
                    and second["code"] == 51
                    and second["buffer"] == ""
                )
                assert not first["consumed"] and not second["consumed"]
    prefix = ["x", "x"] if ordinary else []
    assert rows[5]["tail_calls"] == prefix + ["^0", "0"]
    assert rows[6]["tail_calls"] == prefix + ["^", "^", "0", "0"]
    assert rows[7]["tail_calls"] == prefix + ["0", "0"]
    assert rows[8]["tail_calls"] == prefix + ["à", "à"]
    assert rows[9]["tail_calls"] == prefix + ["0", "0"]
    assert rows[10]["observations"][-1]["input"] == "´0"
    assert rows[11]["observations"][-1]["input"] == "\u202f?"
    assert rows[12]["observations"][-2]["input"] == "´"
    return rows


seeded = json.loads(SEEDED.read_bytes())
unseeded = json.loads(UNSEEDED.read_bytes())
ordinary = json.loads(ORDINARY.read_bytes())
srows, urows, orows = (
    check(seeded, "seeded"),
    check(unseeded, "unseeded"),
    check(ordinary, "ordinary"),
)
for index in range(5, 13):
    baseline, control = copy.deepcopy(srows[index]), copy.deepcopy(orows[index])
    baseline["observations"] = baseline["observations"][1:]
    control["observations"] = control["observations"][2:]
    control["tail_calls"] = control["tail_calls"][2:]
    assert baseline == control, "ordinary baseline changed carrier outcome"
negative_controls = []
for label, mutate in [
    ("missing case", lambda r: r["rows"].pop()),
    (
        "wrong original owner",
        lambda r: r["rows"][5]["owner_sources"].__setitem__(
            "expander", "@fixture/expander.lua"
        ),
    ),
    ("miss falsely expanded", lambda r: r["rows"][5].__setitem__("buffer", "EXPANDED")),
    (
        "prefix unexpectedly constructed",
        lambda r: r["rows"][10]["observations"][-1].__setitem__(
            "returned_text", "´EXPANDED"
        ),
    ),
    ("split control missing", lambda r: r["rows"][6].__setitem__("emitted_count", 0)),
]:
    changed = copy.deepcopy(seeded)
    mutate(changed)
    try:
        check(changed, "seeded")
    except AssertionError:
        negative_controls.append(label)
    else:
        raise AssertionError("checker did not reject " + label)
print(
    json.dumps(
        {
            "cases_per_record": 13,
            "records": 3,
            "unseeded_first_event_timing_declines": 5,
            "unchanged_original_owner_functions_per_case": 4,
            "ordinary_baseline_matching_cases": 8,
            "negative_controls_rejected": negative_controls,
            "qualification": "Original production Lua functions over registered in-memory fixture; native dead state and receiver unmeasured.",
        },
        indent=2,
    )
)
