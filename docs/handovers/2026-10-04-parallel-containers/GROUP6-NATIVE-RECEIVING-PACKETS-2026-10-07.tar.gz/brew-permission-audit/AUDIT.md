# Brew same-identity Automation prerequisite: source-only audit

Reviewed complete preimages at `9d7b838d570004ba66d974a12410d7032df8eb83`.
This packet has no implementation patch. Its six complete source preimages are
bound by MANIFEST.json. No product, test, native compiler, permission query,
permission prompt, workflow, branch or index operation was executed by this
audit. The cached SDK declaration was read and copied, not reacquired.

## Actual qualification retained

The previously reported manual macOS run `37604627108`, at
`35ef2db8fb6d6b920d51ce6ec692e7f124ffe9e7`, passes the real Sparkle cohort but
fails complete Package acceptance. Brew passes native AppKit registration and
its original unconfined positive, then refuses the deny-removal positive:
original exit 66, send OSStatus 0, reply error -10004, nonce read -1701, absent
second delivery marker, and diagnostic nonprompt permission query -1744.
The same receiver has no terminal observation at the retained failure sample.
The complete full-policy denial and all six Brew archive cases are UNRUN.
Installation is SKIPPED. Release is SKIPPED. These native results are inherited
from the root's recorded receipts, not re-executed here.

`-1744` proves that the specific diagnostic permission query requires consent
in its actual context. It does not prove that consent is the sole cause of the
original reply `-10004`, that a grant already exists, or that prompting repairs
the original transport. The successful preceding unconfined positive must be
preserved and explained by any proposed diagnosis.

## Public SDK contract

`upstream/AppleEvents.h:545-589`, from the previously archived Apple SDK header,
provides these limits:

- Permission is queried for the current application, the specified already
  running target, event class and event ID. A wildcard query has a different
  scope from querying the original `kCoreEventClass/kAEOpenApplication` event.
- Some AppleEvents are allowed without prompting. Thus a successful send does
  not imply unrestricted Automation authorization.
- `askUserIfNeeded=false` must not display a consent prompt. A missing grant
  returns `errAEEventWouldRequireUserConsent` (-1744).
- `askUserIfNeeded=true` requests normal OS consent when needed. It does not
  silently confer authorization. A refusal can return
  `errAEEventNotPermitted`; an unavailable target can return `procNotFound`.
- The API is thread safe on macOS 10.14 and later, but its documentation says
  not to call it on the main thread because a user prompt can take arbitrarily
  long to return. There is no deadline argument in this public API.
- `kAEDoNotPromptForUserConsent` applies to the send independently of receiver
  interaction flags. The current send must remain nonprompting.

This header documents permission behavior; it does not document the actual
responsible-process attribution for the current Python -> sender versus
Python -> sandbox-exec -> sender chains. It cannot identify which application
System Settings would display for the observed failure.

## Current concrete source boundaries

`macos_brew_archive_acceptance.py` creates sender and receiver bundles with
fresh UUID-suffixed CFBundleIdentifiers. It compiles their original sources,
ad-hoc signs each bundle, verifies its signature, then retains the exact live
receiver PID and nonce. Both Info.plists already contain
`NSAppleEventsUsageDescription`. No signing entitlements file or hardened
runtime option is supplied in this fixture.

The original unconfined positive directly executes the owned sender binary.
The deny-removal positive executes that same binary through sandbox-exec with
exactly the original appleevent-send denial removed. Other containment rules,
including file writes and outbound connections, remain. The full-policy denial
reuses the original policy. These process chains are not interchangeable
permission identities merely because their final executable path is the same.

The failed-positive diagnostic query is currently the only permission call in
the sender source. The registered CJS guard binds that exact nonprompt failure
branch and rejects changing the query to `true`, assigning a success result,
or substituting permission evidence for the original send/nonce proof.
Neither this branch nor its receiving assertions should be changed to obtain
an interactive prerequisite.

## Feasible future CODE shape, unimplemented and unqualified

A future explicit interactive prerequisite could request public OS consent
from a worker thread in a separately compiled translation unit linked into the
same final sender executable. The original failed-positive query and original
sender assertions could stay intact. A new explicit permission mode would run
through the same deny-removal sandbox chain against the same retained receiver
PID, event class and ID, before the unchanged receiving sends.

This is a design seam, not an implemented feature or supported passing recipe.
The actual responsible identity, prompt appearance, privilege result and effect
on the original -10004 reply must first be measured. The complete fresh signed
sender binary must be the same for prerequisite and receiving; a different
helper binary, rebuilt code hash, retired UUID pair or Terminal grant does not
prove authorization for this run.

The prerequisite requires its own reserved child/process group and physical
retirement acknowledgement, a bounded outer owner and explicit interactive
opt-in. Its blocking public API must never be substituted into the original
sender failure path. It must not extend the original native send, readiness,
child, invoker or retirement deadlines. An unattended hosted runner has no
human available to accept a normal secure consent prompt. Timeout or refusal
must remain a failure with retained ownership debt where applicable, never a
skip or simulated grant. No patch implementing this seam is supplied.

## Missing native evidence and future controls (all UNRUN)

1. Measure the actually displayed responsible application/target for the same
   fresh sender/receiver pair in the deny-removal chain. Do not infer Terminal,
   Python, sandbox-exec or the bundle identity from paths alone.
2. Establish whether the public permission request is admitted in that exact
   sandbox context and whether an actual visible secure prompt is presented.
   Record canonical status and closed identity facts; do not publish nonce,
   private reply bytes, raw paths or permission database contents.
3. If approved interactively, require a fresh exact-target nonprompt query
   result and then independently execute the original two positive sends,
   exact nonce replies and distinct exclusive delivery markers. A permission
   result cannot replace any send, marker or reply assertion.
4. Preserve the original unconfined success before claiming the prompt explains
   the sandbox-only refusal. Distinguish consent, sandbox restriction, reply
   construction and target handler admission instead of relabeling -10004.
5. Exercise refusal, unavailable target, replaced target identity, no visible
   prompt, prerequisite timeout and owner retirement debt. None can grant or
   bypass the original receiving admission.
6. Re-run full-policy denial after positives, with original refusal status and
   unchanged markers. Qualify all six actual Brew install/upgrade/refusal/
   recovery cases and read-only host-state assertions.
7. Complete the actual macOS Package and original installation matrix on the
   final source SHA. A filtered Sparkle pass or permission-only test cannot
   qualify the aggregate. Release remains excluded in this task.

No TCC editing/reset, permission-store copying, security disabling, broad
sandbox permission, alternate accepted sender, identity copying, Terminal
rerouting, deadline increase, expectation regeneration or assertion removal is
part of the proposed continuation.

## Delivery status

Source review: completed. Source patch: none. New controls: not authored or
executed. Native permission request/grant: UNRUN. Native Brew requalification:
UNRUN. Original complete sources and independent SDK bytes are preserved under
`preimage/` and `upstream/` with SHA-256 values. The whole-file inverse is the
identical original file, since this packet changes no implementation.

TODO36 remains OPEN, including this CODE prerequisite and actual Mac/device
acceptance. TODO16/38 remain unchanged. No item is closed by this audit.
