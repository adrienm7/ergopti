import{n as e}from"../chunks/XKyaHtl9.js";import{$ as t,I as n,R as r,X as i,_ as a,_t as o,b as s,f as c,gt as l,ht as u,it as d,mt as f,nt as p,ot as m,rt as h,s as g}from"../chunks/BiIdZTvV.js";import"../chunks/9dAfDHy3.js";import{t as _}from"../chunks/DfkZ1jRe.js";import{n as v}from"../chunks/CJYPFTQh.js";import"../chunks/llOOrmwh.js";import{t as y}from"../chunks/BpzCeCBO.js";import{t as b}from"../chunks/B-NxTKnF.js";import{n as x,t as S}from"../chunks/BzWHwOuh.js";var C=e({prerender:()=>!0}),w=r(`<section class="main"><h1 data-aos="zoom-in">Informations sur la Disposition <!></h1> <hr class="margin-h1"/></section>`);function T(e){var t=w(),r=h(t),i=m(h(r));_(i,{}),o(r),l(2),o(t),n(e,t)}var E=r(`<section><h2>Autocritiques</h2> <h3>L’importance des compromis</h3> <p>Il est évident qu’il n’est pas possible de maximiser plusieurs paramètres simultanément. Bien
		que largement supérieure sur de nombreux points à la plupart des dispositions, <!> est donc malheureusement loin d’être parfaite. En effet, la création d’une disposition est une affaire
		de compromis. Des choix ont dû être effectués pour maximiser chacun des critères d’évaluation sans
		trop compromettre les autres.</p> <p>Par exemple, le <kbd>E</kbd> n’est pas sur l’index de la rangée de repos. Cela peut sembler
		étrange, tant son apparition est incontournable dans les textes (sauf dans le livre <em>La Disparition</em> qui réussit l’exploit de ne jamais l’utiliser). Le <kbd>E</kbd> est de
		loin la lettre la plus fréquente. Elle est tellement incontournable que sur le <a class="link">clavier affichant la fréquence des touches</a> de la page d’accueil, une transformation mathématique a été nécessaire pour que les fréquences relatives
		aux autres touches soient visibles et comparables (passage au logarithme). En effet, si l’on affichait
		les fréquences relatives telles quelles, le <kbd>E</kbd> serait tellement plus fréquent qu’il écraserait
		complètement les autres fréquences, rendant impossible de les comparer par un code couleur.</p> <p>Pourtant, cette lettre n’a pas été placée sur l’index, comme le fait pourtant BÉPO. La raison
		principale est que la mettre ailleurs permet de sensiblement de réduire les <!>s. En effet,
		si le <kbd>E</kbd> avait été sur l’index, alors les 6 touches tapées par ce doigt auraient
		possiblement généré des <!>s avec le <kbd>E</kbd>. <kbd>E</kbd> s’associe avec quasiment
		toutes les lettres, par conséquent ce serait une très mauvaise idée. Au contraire, la voyelle <kbd>U</kbd> ne s’associe pas avec beaucoup de lettres, ce qui la rend beaucoup plus pertinente à cet emplacement.
		D’autant que ce nouvel arrangement des voyelles permet alors de très bons roulements. En outre, placer
		la lettre <kbd>E</kbd> sur l’index avec 5 autres lettres risque aussi de surcharger celui-ci. Il
		vaut mieux répartir la charge avec le majeur.</p> <p>Pour finir, parfois tous les emplacements sont mauvais pour une touche. Il faut alors choisir le
		moins pire. Par conséquent, <!> a évidemment des défauts, dont les principaux sont recensés
		ici.</p> <h3>Distances non optimales</h3> <ul><li><kbd>E</kbd> est sur le majeur et non sur l’index. Théoriquement, l’index est plus fort et
			devrait donc être l’endroit idéal pour la lettre <kbd>E</kbd> qui est de loin la lettre la
			plus fréquente, loin devant la deuxième lettre la plus fréquente de l’alphabet. Cependant,
			comme l’index se charge de 6 touches, il faut aussi veiller à ne pas le surcharger. Par
			conséquent, ce n’est en réalité pas si grave que cela que le <kbd>E</kbd> soit sur le majeur et
			non sur l’index.</li> <li>Le <kbd>K</kbd>, bien que très rare en français et peu fréquent en anglais, est à une position
			assez lointaine sur un clavier ISO, car en plein milieu du clavier. Il est notamment utilisé
			en anglais avec les combinaisons <kbd-output>SK</kbd-output>, <kbd-output>CK</kbd-output>, etc. Sur un clavier Ergodox, ce problème s’atténue, en
			particulier sur les claviers concaves de type Kinesis Advantage ou Glove80.</li> <li>Les touches <kbd>Q</kbd> et <kbd>Z</kbd> pourraient aussi être critiquées, car elles
			nécessitent des extensions de l’auriculaire droit, étant sur une autre colonne que celle de
			repos. <kbd>Z</kbd> étant très rare et le raccourci <kbd>Ctrl</kbd> + <kbd>Z</kbd> pouvant être réalisé
			avec la main gauche, cela ne pose pas vraiment de problème.</li> <li>Certains pourront aussi critiquer le fait que la touche <kbd>J</kbd> soit trop bien située,
			étant sur un excellent emplacement sur l’index gauche. En effet, cette lettre a l’une des
			fréquences les plus faibles de toutes les lettres, que ce soit en français et en anglais. Si
			elle a été placée ici en <!>, c’est en vue de l’utilisation d’<!>, pensée dès le début comme une extension de la disposition. Ainsi, ce choix de
			placement de la touche <kbd>J</kbd> est justifié par le fait que cela permet de facilement
			ajouter de nouvelles fonctionnalités à la disposition sans avoir à créer une toute nouvelle
			disposition pour tirer parti de ces nouvelles fonctionnalités sans que cela n’ait d’impact
			négatif. Si la touche magique <kbd class="glow">★</kbd> est à cet emplacement, c’est aussi
			parce que c’est sur la colonne du <kbd>U</kbd>, pour éviter le maximum de <!>s lors de
			la conversion de cette touche en touche de répétition. En effet, les doubles consonnes sont
			très peu suivies d’un <kbd>U</kbd>.</li></ul> <h3>Non compatible avec les claviers très compacts</h3> <p>Certains claviers ont moins de touches, par exemple en n’ayant que 6 colonnes, voire seulement
		5, par main. <!> a été conçue pour exploiter toutes les touches d’un clavier standard,
		donc 6 colonnes à gauche et 7 à droite. Sur la dernière colonne de droite, il n’y a cependant que
		les touches mortes <kbd class="deadkey">◌̂</kbd> et <kbd class="deadkey">◌̈</kbd> qui seront
		beaucoup plus rarement utilisées. Ces touches mortes sont en accès direct sur la septième
		colonne, mais peuvent également être obtenues sur la couche <kbd>ShiftAltGr</kbd> avec <kbd>Shift</kbd> + <kbd>AltGr</kbd> + <kbd>Ê</kbd> pour <kbd-output>◌̂</kbd-output> et <kbd>Shift</kbd> + <kbd>AltGr</kbd> + <kbd>T</kbd> pour le Tréma <kbd-output>◌̈</kbd-output>.</p> <p>Il n’en demeure pas moins qu’<!> n’est pas 1DFH (1u Distance From Home). Les lettres
		accentuées du français étant en accès direct avec <!>, il est impossible de
		réaliser une disposition 1DFH, car il y a trop de touches à placer par rapport à l’espace
		disponible. La disposition <a href="https://ergol.org" target="_blank" class="link">Ergo‑L</a> est
		quant à elle une disposition 1DFH, mais au prix d’une touche morte permettant de réaliser les accents.
		Cela signifie que dans ce genre de dispositions, il y a plus de frappes pour écrire un mot, car pour
		écrire une lettre accentuée, il faut d’abord appuyer sur la touche morte, puis sur la lettre.</p> <h3>Quelques <!>s restants</h3> <ul><li><kbd>CT</kbd> engendre beaucoup de <!>s, mais un <!> avec le <kbd>C</kbd> est de toute
			manière inévitable avec l’une des 4 consonne de la <em>homerow</em> droite. Cette combinaison
			est l’une des moins pires\xA0: en fréquence d’apparition, <kbd-output>NC</kbd-output> > <kbd-output>CR</kbd-output> > <kbd-output>CT</kbd-output> > <kbd-output>SC</kbd-output>.</li> <li><kbd>PT</kbd> : il est triste de se dire que pour quelqu’un utilisant une disposition o<strong>pt</strong>imisée, l’écriture même de ce mot ne l’est pas…</li> <li><kbd>EO</kbd> et <kbd>OE</kbd>\xA0: bien qu’inexistants en français, ces bigrammes sont
			relativement fréquents en anglais (people, does, etc.)</li></ul> <p class="encadre"><b>Note\xA0:</b> Tous ces problèmes de <!>s sont résolus grâce à l’utilisation d’<!>, y compris pour les <!>s encore plus rares qui ne sont pas listés ici. <i class="icon-face-smile"><span class="path1"></span><span class="path2"></span></i></p> <h3>Alternance des mains non maximale</h3> <ul><li><kbd>W</kbd> devrait théoriquement plutôt être du côté droit du clavier, car cette lettre est
			souvent précédée ou suivie d’une voyelle. Toutefois, la placer sur l’index gauche permet de
			mettre cette lettre sur un excellent emplacement tout en n’entraînant aucun <!> supplémentaire
			sur l’index gauche. Ainsi, la distance des doigts aux touches s’en trouve diminuée, et des roulements
			très confortables pour l’anglais sont introduits, notamment avec le <kbd>O</kbd> (<kbd-output>WO</kbd-output>, <kbd-output>OW</kbd-output>).</li></ul> <h3>Manque de logique pour certains placements de touches</h3> <p>La touche <kbd>À</kbd> était auparavant au-dessus du <kbd>A</kbd> et la touche <kbd>È</kbd> en-dessous du <kbd>E</kbd>. C’était logique, le A avec le A et le E avec le E. En outre, <kbd>AltGr</kbd> + <kbd>È</kbd> donnait <kbd-output>\\</kbd-output>, en miroir de <kbd>AltGr</kbd> + <kbd>É</kbd> qui donne <kbd-output>/</kbd-output>, tandis que <kbd>AltGr</kbd> + <kbd>À</kbd> donnait <kbd-output>\`</kbd-output>.</p> <p>Cependant, les touches <kbd>À</kbd> et <kbd>È</kbd> ont depuis été interverties. En effet, <!> utilisant beaucoup la touche <kbd>À</kbd>, il convenait de la mettre sous un
		doigt fort et non plus sur l’auriculaire. Les symboles en <kbd>AltGr</kbd> ont en revanche été
		conservés, car le <kbd>\\</kbd> est plus fréquemment utilisé que le <kbd>\`</kbd>, en particulier
		en LaTeX. En résulte un placement moins logique des caractères en <kbd>AltGr</kbd> pour ces deux
		touches.</p> <h3>Manque de caractères et non optimisation pour les autres langues</h3> <p><!> possède peu de touches mortes et de couches de symboles. En effet, la disposition
		ne se prétend pas être exhaustive en incorporant tous les alphabets des langues européennes comme
		le BÉPO, ou encore le cyrillique, l’écriture phonétique, les pièces d’échec, etc. comme Optimot.
		Ces couches n’intéressent que peu d’utilisateurs et occupent des emplacements du clavier très accessibles
		pour une utilisation très rare.</p> <p>En outre, <!> a été optimisée pour le français et l’anglais ; elle n’a pas été pensée
		pour être utilisée dans d’autres langues. Par conséquent, <!> n’est probablement
		pas la disposition la plus adaptée si vous écrivez dans une langue différente du français et de l’anglais.</p></section>`,2);function D(e,r){u(r,!1),g();var i=E(),s=m(h(i),4),d=m(h(s));_(d,{}),l(),o(s);var p=m(s,2),y=m(h(p),7);l(3),o(p);var S=m(p,2),C=m(h(S));x(C,{});var w=m(C,4);x(w,{}),l(9),o(S);var T=m(S,2),D=m(h(T));_(D,{}),l(),o(T);var O=m(T,4),k=m(h(O),6),A=m(h(k),3);_(A,{});var j=m(A,2);b(j,{});var M=m(j,8);x(M,{}),l(3),o(k),o(O);var N=m(O,4),P=m(h(N));_(P,{});var F=m(P,14);a(F,1,`deadkey`);var I=m(F,8);a(I,1,`deadkey`),l(),o(N);var L=m(N,2),R=m(h(L));_(R,{});var z=m(R,2);_(z,{}),l(3),o(L);var B=m(L,2),V=m(h(B));x(V,{}),l(),o(B);var H=m(B,2),U=h(H),W=m(h(U),2);x(W,{});var G=m(W,2);x(G,{});var K=m(G,6),q=m(K,2),J=m(q,2);m(J,2),l(),o(U),l(4),o(H);var Y=m(H,2),X=m(h(Y),2);x(X,{});var ee=m(X,2);b(ee,{});var te=m(ee,2);x(te,{}),l(2),o(Y);var Z=m(Y,4),ne=h(Z),re=m(h(ne),2);x(re,{});var ie=m(re,4);m(ie,2),l(),o(ne),o(Z);var Q=m(Z,6),ae=m(h(Q),5);b(ae,{}),l(11),o(Q);var $=m(Q,4),oe=h($);_(oe,{}),l(),o($);var se=m($,2),ce=m(h(se));_(ce,{});var le=m(ce,2);_(le,{}),l(),o(se),o(i),t(e=>c(y,`href`,e),[()=>v(`/ergopti/presentation`)+`#keyboard_frequences`]),n(e,i),f()}var O=r(`<section><h2 id="changelog">Changelog</h2> <h3>Version 2.2.1 (Janvier 2026)</h3> <ul><li>Correction de l’inversion des caractères <kbd-output>-</kbd-output> et <kbd-output>_</kbd-output> sur la touche <kbd-output>◌̈</kbd-output>.</li> <li>Ajout des caractères <kbd>í</kbd> et <kbd>Í</kbd> manquants. Cet ajout permute les positions
			sur la couche circonflexe de <kbd>ó</kbd>/<kbd>Ó</kbd>, <kbd>º</kbd>/<kbd>°</kbd> ainsi que de <kbd>/</kbd>/<kbd>\\</kbd>. Désormais, il est plus facile d’écrire des dates de type <kbd>dd/mm/yyyy</kbd>, car le <kbd-output>/</kbd-output> est plus accessible, se réalisant par
			appui sur <kbd-output>◌̂</kbd-output> puis <kbd-output>◌̈</kbd-output>.</li> <li>Le pilote Windows utilise désormais <strong>Kana au lieu de AltGr</strong>, ce qui libère
			toutes les combinaisons en <kbd>Ctrl</kbd> + <kbd>Alt</kbd> pour de nouvelles utilisations.
			Auparavant, <kbd>Ctrl</kbd> + <kbd>Alt</kbd> était une autre manière d’accéder à la couche AltGr du pilote, mais cette duplication
			inutile empêchait d’utiliser certains raccourcis.</li> <li>Ajout de nombreux scripts <!> pour macOS. Cela inclut un script Hammerspoon
			ainsi que des workflows Alfred.</li> <li>Amélioration significative des scripts d’installation du pilote sur Linux. Désormais, les
			systèmes les plus récents (avec une version de <em>libxkbcommon ≥ 1.13.0</em>) bénéficient
			d’une installation plus propre et plus fiable. En effet, précédemment les installations
			nécessitaient la modification manuelle de fichiers système, ce qui était très peu robuste et
			pouvait entraîner des erreurs.</li></ul> <h3>Version 2.2 (Octobre 2025)</h3> <p>Le changement le plus visible d’<!> v2.2 est la permutation des touches <kbd>€</kbd>, <kbd>%</kbd> et <kbd>=</kbd> sur la rangée des chiffres. Celle-ci a été réalisée
		afin d’améliorer l’accès aux touches les plus fréquentes. De plus, la touche <kbd>€</kbd> a été modifiée pour mettre le <kbd-output>€</kbd-output> en AltGr et placer le <kbd-output>$</kbd-output> en accès direct. Ici encore, c’est parce que ce caractère est beaucoup
		plus utilisé, que ce soit en tant que monnaie, mais aussi en programmation ou sur Excel par exemple.</p> <p>En outre, les symboles <kbd-output>º</kbd-output>, <kbd-output>°</kbd-output> et <kbd-output>ª</kbd-output> étaient auparavant sur la touche <kbd>0</kbd>. Ils ont été déplacés
		sur la touche <kbd>=</kbd> afin de libérer les emplacements sur la touche <kbd>0</kbd>. Cette
		modification a permis d’ajouter, sur les touches de chiffres, les chiffres en exposant en <kbd>AltGr</kbd> ainsi que les chiffres en indice en <kbd>Shift</kbd> + <kbd>AltGr</kbd>.</p> <tiny-space></tiny-space> <p>Le deuxième changement, moins visible, est une nette amélioration des touches mortes. Celles-ci
		sont désormais beaucoup plus complètes et plus logiquement agencées.</p> <tiny-space></tiny-space> <p>Enfin, un gros changement concerne <!> dont le code AutoHotkey a été complètement
		réécrit. Celui-ci est désormais beaucoup plus simple et robuste. En outre, chaque feature peut désormais
		s’activer ou se désactiver grâce à un menu de configuration apparaissant lors du clic sur l’icône
		du script dans la barre des taches.</p> <p>Cette nouvelle version permet à tout le monde d’utiliser des raccourcis, la couche de symboles,
		les chiffres en accès direct, etc. à la carte, quelle que soit sa disposition actuelle. Ainsi,
		même une personne utilisant AZERTY, BÉPO, Optimot, etc. et ne souhaitant pas apprendre <!> peut avoir à sa disposition ces nombreuses features. Certains raccourcis de cette nouvelle
		version ont été inversés afin d’être encore plus confortables à utiliser et de nombreux ont été ajoutés.</p> <h3>Version 2.1 (Janvier 2025)</h3> <p><!> v2.1 intervertit le <kbd>C</kbd> et le <kbd>G</kbd>. Les résultats sur les
		analyseurs sont tous un peu moins bons avec ce changement, car le <!> <kbd>CT</kbd> est
		plus fréquent que l'ancien qui était <kbd>SC</kbd> et intervient sur l’annulaire au lieu de l’index.</p> <p>Cependant, cette modification était importante à réaliser, car le <kbd>C</kbd> est désormais
		plus accessible. C’est, tout comme le passage en v2.0, une histoire de longueur des doigts. En
		outre, le roulement <kbd>CH</kbd> s’en trouve être beaucoup plus confortable, étant désormais un
		roulement vers l’intérieur. Une autre amélioration est que le <kbd>C</kbd> n’est plus sur le
		même doigt que le <kbd>D</kbd>, ce qui permet de taper la commande <kbd-output>cd</kbd-output> (change directory) sans <!>.</p> <p>Cette interversion est pénalisée par les analyseurs de disposition, qui comptent un peu plus de <!>s. Pourtant, à l’usage, le <!> sur <kbd>CT</kbd> se révèle moins gênant que
		l’ancien sur <kbd>SC</kbd>.</p> <h3>Version 2.0 (Janvier 2025)</h3> <p><!> v2.0 est une évolution majeure de la disposition, d’où le changement de numérotation.
		La modification est en réalité très simple\xA0: <strong>interversion de la rangée inférieure de la main droite avec la rangée supérieure</strong>.</p> <p>Ce changement n’est pas anodin et apporte les bénéfices suivants\xA0:</p> <ul><li>bigrammes <kbd>TH</kbd> et <kbd>SH</kbd> beaucoup plus confortables sur clavier ISO ;</li> <li>bigramme <kbd>ND</kbd> beaucoup plus confortable ;</li> <li>positionnement du <kbd>M</kbd> plus près du <kbd>P</kbd>, car désormais sur la même rangée et
			non plus à 2 rangées d’écart.</li></ul> <br/> <p>Ce changement n’a pas été pris à la légère, celui-ci faisant bouger 8 touches. Il n’améliore en
		plus même pas le taux de <!>s, car les touches assignées à chaque doigt restent les
		mêmes. C’est vraiment une interversion de confort pour taper des bigrammes.</p> <p>Elle demeure une évolution souhaitable, car le bigramme <kbd>TH</kbd> est <b>de loin</b> le plus
		fréquent en anglais. <kbd>ND</kbd> est lui aussi extrêmement fréquent, en particulier en
		anglais, et prend la place de <kbd>NC</kbd> dont la fréquence d’apparition est en comparaison minime.</p> <p>La raison pour laquelle le <kbd>TH</kbd> est beaucoup plus confortable avec la version 2.0 est
		que le majeur et l’annulaire étant des doigts longs, ils ont plus de facilité à atteindre la
		rangée supérieure que celle inférieure. Au contraire, l’index étant un peu plus court, c’est la
		rangée inférieure qui est plus accessible pour ce doigt. C’est d’ailleurs aussi pour cela que la
		touche <kbd>★</kbd> a été placée sur l’index gauche en rangée du bas et non du haut\xA0: car cette position
		est la plus confortable.</p> <p>Le <kbd>L</kbd>, très fréquent en français mais moins en anglais, est donc sur une touche un peu
		moins accessible. Cela permet au <kbd>H</kbd>, une lettre à la fréquence extrêmement forte en
		anglais et fréquence moyenne-faible en français, d’être plus accessible.</p> <br/> <p>En résumé, la version 2.0 d’<!> conserve ses excellents scores en alternance des
		mains, distance parcourue, minimisation des <!>s, etc. Toutefois, elle <strong>est désormais beaucoup plus confortable pour l’écriture de l’anglais</strong>.</p> <h3>Version 1.1 (Octobre 2024)</h3> <p><!> v1.1 est la première version de la disposition à être dévoilée au public. Elle
		fige enfin les quelques lettres qui changeaient au fil des versions de test v1.0.x pour une disposition
		stable suite à tous ces essais.</p></section>`,2);function k(e){var t=O(),r=m(h(t),4),i=h(r),s=m(h(i)),c=m(s,2),u=m(c,2);a(u,1,`deadkey`),l(),o(i);var d=m(i,2),f=m(h(d),19),p=m(f,2);a(p,1,`deadkey`);var g=m(p,2);a(g,1,`deadkey`),l(),o(d);var v=m(d,4),y=m(h(v));b(y,{}),l(),o(v),l(2),o(r);var S=m(r,4),C=m(h(S));_(C,{});var w=m(C,10);m(w,2),l(),o(S);var T=m(S,4),E=m(T,4),D=m(E,2),k=m(h(D));b(k,{}),l(),o(D);var A=m(D,2),j=m(h(A));_(j,{}),l(),o(A);var M=m(A,4),N=h(M);_(N,{});var P=m(N,6);x(P,{}),l(5),o(M);var F=m(M,2),I=m(h(F),9),L=m(I,2);x(L,{}),l(),o(F);var R=m(F,2),z=m(h(R));x(z,{});var B=m(z,2);x(B,{}),l(5),o(R);var V=m(R,4),H=h(V);_(H,{}),l(3),o(V);var U=m(V,8),W=m(h(U));x(W,{}),l(),o(U);var G=m(U,10),K=m(h(G));_(K,{});var q=m(K,2);x(q,{}),l(3),o(G);var J=m(G,4),Y=h(J);_(Y,{}),l(),o(J),o(t),n(e,t)}var A=r(`<section><h2>Contact</h2> <div class="encadre"><p class="text-center margin0">Le créateur de la disposition <!> et de ce site est <strong>Adrien MOYAUX</strong>.</p> <p>Vous pouvez créer une nouvelle <em>Issue</em> sur <a href="https://github.com/adrienm7/ergopti" target="_blank" class="link">la page GitHub du projet</a> si vous avez une question ou un problème, notamment pour l’installation.</p> <p class="margin0">Il est aussi possible de rejoindre le <a class="link">serveur Discord BÉPO | Ergodis</a> où <!> dispose d’un canal dédié, simplifiant les échanges.</p></div></section>`);function j(e){var r=A(),i=m(h(r),2),a=h(i),s=m(h(a));_(s,{}),l(3),o(a);var u=m(a,4),d=m(h(u)),f=m(d,2);_(f,{}),l(),o(u),o(i),o(r),t(()=>c(d,`href`,y)),n(e,r)}var M=r(`<section><h2 class="first-h2">Genèse et inspirations</h2> <p>La genèse de la disposition <!> remonte à début 2022, suite à la découverte de la
		disposition <a href="https://optimot.fr/" target="_blank" class="link">Optimot</a>. À ce moment-là, j’étais
		un utilisateur du <a href="https://bepo.fr/" target="_blank" class="link">BÉPO</a> depuis déjà de nombreuses années. Les améliorations d’Optimot par rapport au BÉPO sont significatives,
		avec notamment une forte diminution des bigrammes à un doigt (<!>s) et un meilleur placement
		des lettres pour l’anglais. Cependant, l'idée d’apprendre Optimot, pour peut-être découvrir par
		la suite une disposition encore meilleure, était peu attrayante.</p> <p>Pour m’assurer de ne pas avoir à passer mon temps à apprendre de nouvelles dispositions, toutes
		meilleures les unes que les autres, la solution a été radicale\xA0: développer la mienne, optimisée
		pour mes besoins. Évidemment, une telle tâche nécessite un investissement en temps considérable.
		Il faut déjà comprendre ce qui fait une bonne disposition, puis réarranger les touches pour en
		créer une au moins aussi bonne, si ce n’est meilleure, que les autres dispositions déjà
		disponibles. Enfin, il faut tester soi-même la disposition, car certains défauts n’apparaissent
		pas toujours sur un analyseur théorique. Et pour la tester, il faut réapprendre totalement à
		taper au clavier, et ce à chaque fois que l’on essaie une nouvelle disposition.</p> <tiny-space></tiny-space> <p>Les premières versions de ce projet, baptisées <strong><a href="https://bepo.fr/wiki/Utilisateur:Adrien_Moyaux" target="_blank" class="link">Optim7</a></strong>, étaient des dérivés directs d’Optimot. L'objectif initial était d’améliorer les scores sur
		les analyseurs de disposition et de corriger des choix qui ne me convenaient pas. Par exemple,
		je voulais les chiffres en accès direct, ce qui n’est pas le cas en Optimot, son créateur
		préférant y mettre les symboles.</p> <p>Rapidement, <!> s’éloigna d’Optimot sur plusieurs aspects fondamentaux. L'un des
		points clés était ma volonté d’optimiser les <em>roulements</em>, entraînant de nombreux essais
		d’arrangements des touches pour la <em>homerow</em>, notamment sur la partie droite avec les
		consonnes. Un des choix majeurs fut de privilégier un agencement <kbd>SNTR</kbd> plutôt que le <kbd>TSRN</kbd> du BÉPO et d’Optimot. En effet, le bigramme <kbd>NT</kbd> est le plus fréquent des bigrammes
		consonne-consonne, et il est pertinent de l'optimiser pour qu'il se réalise sur des doigts
		consécutifs. D’autant que <kbd>NTR</kbd> se réalise également en roulement.</p> <p>L’agencement final des quatre lettres de la rangée principale droite a donc été soigneusement
		conçu pour maximiser les bigrammes consonantiques, pour une frappe harmonieuse. Seuls les
		bigrammes <kbd>ST</kbd> et <kbd>TS</kbd> (comme dans « <kbd>ST</kbd>A<kbd>TS</kbd> ») ne profitent malheureusement pas
		de cette optimisation des roulements, car il était impossible de tout avoir en même temps. En
		résumé, <!> a été <strong>pensée dès le départ pour maximiser les roulements, mais sans sacrifier l’alternance des
			mains</strong>. La disposition a la même alternance des mains que BÉPO ou Optimot, tout en ayant des
		roulements largement plus fréquents pour les lettres ne bénéficiant pas de cette alternance.</p> <tiny-space></tiny-space> <p>La disposition a beaucoup évoluée au fil du temps. En particulier, la touche sur l’index gauche
		a plusieurs fois changé\xA0: <kbd>Q</kbd>, puis <kbd>P</kbd>, puis <kbd>W</kbd> et enfin la création d’une touche spéciale <kbd>★</kbd> et le déplacement de <kbd>É</kbd> sur l’annulaire gauche.</p> <p>Bien que la création d’<!> ait été un processus étalé sur plusieurs années, près
		de 90% de la disposition est restée constante. Les ajustements concernaient principalement le déplacement
		de certaines lettres, nécessitant ainsi de petites phases de réapprentissage régulières. Néanmoins,
		la plupart des changements se sont avérés non pertinents, ce qui explique l'absence de modifications
		majeures entre les premières versions d’<strong>Optim7</strong> et la version finale d’<!>.</p> <tiny-space></tiny-space> <p>À un certain stade de développement, il devint évident que la disposition <strong>Optim7</strong> n'était plus une simple variante d’Optimot. Le besoin de renommer ce
		projet s’est alors imposé. Grâce à la suggestion d’un utilisateur nommé <strong>Zigmund</strong> sur Discord, après avoir longtemps cherché avec lui un nom aussi
		remarquablement bien trouvé que celui d’Optimot, le nom <strong>HyperTexte</strong> fut d’abord retenu. Cependant, il s’avéra par la suite que ce nom était
		mal choisi, car déjà utilisé sur de nombreux sites ailleurs (ce qui n’est pas étonnant, avec toutes
		les mentions de «\xA0lien hypertexte\xA0»). La découverte de la disposition, notamment grâce à un moteur
		de recherche, s’en trouvait compromise. Le site de présentation n’apparaissait même pas en première
		page des résultats.</p> <p>Environ un mois après la sortie publique de la disposition, <strong>HyperTexte</strong> fut renommée <!>, son nom définitif. Ce nouveau nom
		reflète à la fois l’ergonomie de la disposition et l’optimisation de celle-ci, la lettre <kbd>O</kbd> faisant le lien entre les deux (ergo[nomie] & opti[misation]). En outre, il est
		court, d’une longueur idéale de 7 lettres, et peu présent en ligne. Une fois la nouvelle
		appellation trouvée, le nom de domaine <a href="https://ergopti.fr" class="link">https://ergopti.fr</a> fut également réservé à ce moment-là.</p> <h3>Comment la disposition a été développée</h3> <p><i class="icon-circle-1"><span class="path1"></span><span class="path2"></span></i> La première
		étape dans la création d’<!> a été de partager les touches du clavier en deux groupes\xA0: main
		gauche et main droite. L’objectif est de maximiser l’alternance des mains, c’est-à-dire de faire
		en sorte que les touches qui sont le plus souvent tapées l’une après l’autre le soient par des mains
		différentes.</p> <p>Pour optimiser ce critère, les voyelles ont toutes été placées d’un côté du clavier. Celles-ci
		étant majoritairement précédées et suivies de consonnes, cela amène immédiatement une grande
		alternance des mains. À noter que cette idée est loin d’être nouvelle, car elle est déjà
		appliquée dans presque toutes les dispositions alternatives\xA0: Dvorak, BÉPO, Optimot, etc.</p> <p>Dans le cas d’<!>, les voyelles ont été placées sur le côté gauche. La raison est que
		sur la plupart des claviers standards, il y a moins de touches sur ce côté. Le côté droit a en
		effet trois colonnes de touches pour l’auriculaire alors que l’auriculaire gauche n’en a qu’une.
		Ces nombreux emplacements sont précieux, surtout pour les langues ayant besoin de caractères
		supplémentaires, comme les accents en français. Le nombre de consonnes étant largement supérieur
		au nombre de voyelles, même en comptant les voyelles accentuées du français, les placer du côté
		avec le plus de touches était logique.</p> <p>Le seul problème avec cette approche est que l’on perd des raccourcis utiles sur la main gauche
		qui se font avec des consonnes, comme <kbd>Ctrl</kbd> + <kbd>C</kbd> pour copier ou <kbd>Ctrl</kbd> + <kbd>V</kbd> pour coller. Cependant, <!> a une solution pour que
		ce ne soit pas un problème en dupliquant ces raccourcis sur les voyelles accentuées.</p> <tiny-space></tiny-space> <p><i class="icon-circle-2"><span class="path1"></span><span class="path2"></span></i> La deuxième
		étape dans la création de la disposition a été de placer les touches les plus souvent utilisées
		le plus proche possible des doigts. Les doigts sont effectivement toujours censés reposer sur la
		rangée de repos du clavier (la ligne du milieu, aussi appelée <em>homerow</em>). Il est donc
		naturel de chercher à placer sur cette rangée les lettres les plus utilisées pour réduire les
		déplacements de doigts aux touches.</p> <p>De même, certaines touches sont plus facilement accessibles que d’autres sur les claviers
		standards à cause de la longueur des doigts. Par exemple, la touche <kbd>C</kbd> en
		AZERTY/QWERTY est plus accessible que la touche <kbd>R</kbd>, car il est plus aisé de déplacer
		l’index gauche vers le bas que vers le haut. Ainsi, les touches les plus utilisées ont été
		placées sur la rangée de repos, et les autres lettres ont été placées sur les autres lignes en
		fonction de leur accessibilité.</p> <tiny-space></tiny-space> <p><i class="icon-circle-3"><span class="path1"></span><span class="path2"></span></i> La troisième
		étape a été de déplacer des lettres pour réduire au maximum le nombre de <!>s et de ciseaux,
		tout en maximisant les roulements. Encore une fois, la maximisation des roulements était la
		priorité dès le début du projet.</p> <p>Cette étape a été la plus difficile, car intervertir seulement deux touches peut transformer une
		disposition excellente en une disposition très moyenne. Il faut effectivement avoir en tête les
		bigrammes les plus fréquents et s’assurer que déplacer une touche à un autre emplacement ne va
		pas empirer la situation.</p> <h3>Simplification et utilisation de la couche <kbd>AltGr</kbd></h3> <p><!> utilise intensivement la couche <kbd>AltGr</kbd>. Celle-ci permet de réduire
		drastiquement les distances parcourues pour atteindre de nombreuses touches. N’ayant nullement
		besoin de tous les caractères exotiques et touches mortes du BÉPO ou d’Optimot, la majeure
		partie fut supprimée pour ne conserver que l’essentiel. Cette simplification permit de libérer
		de nombreux excellents emplacements sur la couche <kbd>AltGr</kbd> et laissa assez de place pour
		y loger tous les symboles. Ainsi, plus besoin d’étendre les doigts pour atteindre la rangée des chiffres
		pour taper des parenthèses, guillemets ou opérateurs mathématiques. Au contraire, tous ces symboles
		sont désormais sous les doigts, sur les trois rangées principales du clavier.</p> <p>En outre, les chiffres sont quant à eux passés en accès direct, un changement très appréciable
		lors de l'utilisation quotidienne. C’est une fois avoir passé les chiffres en accès direct que
		l’on se rend compte de l’énorme gain de confort que cela procure et l’on se demande pourquoi on
		n’avait pas cela plus tôt. Pourtant, même BÉPO, qui est déjà largement plus optimisé qu’AZERTY,
		ne le propose pas, pas plus qu’Optimot. D’ailleurs, en dehors des dispositions françaises, la
		plupart des dispositions alternatives proposent les chiffres en accès direct, comme Dvorak,
		Colemak, Neo, etc. Même le QWERTY américain propose les chiffres en accès direct, ce qui est un
		comble pour cette disposition qui est l’une des moins optimisées au monde.</p> <h3>Atouts d’<!></h3> <p>La singularité d’<!> ne réside pas seulement dans ses excellents scores en français,
		anglais et en programmation, où elle rivalise avec les meilleures dispositions actuelles. Sa version
		étendue, <!>, pousse encore plus loin l’efficacité de cette disposition déjà très
		performante, en la rendant véritablement exceptionnelle.</p> <p>Le qualificatif d’exceptionnel n’est pas exagéré\xA0: <!> permet, une fois maîtrisée,
		de supprimer presque totalement les <!>s, y compris ceux liés à la répétition d’une même
		touche. Cela est rendu possible grâce à la touche spéciale <kbd class="glow">★</kbd>, permettant
		de réitérer la frappe de la touche précédente avec une fluidité inédite, ainsi qu’à la touche <kbd>,</kbd> de réduction des <!>s.</p> <p>Il convient de préciser que l’idée de cette touche de répétition ne vient pas d’<!>. Elle provient d’une (voire plus) disposition anglophone. d’autres concepts ont
		également été empruntés, comme l'utilisation d’AHK (AutoHotkey) dans la disposition <a href="https://ballerboo.github.io/boolayout/" target="_blank" class="link">Boo</a> afin de modifier
		le comportement des combinaisons de touches. Ce système permet d’optimiser encore davantage les roulements
		sur des touches adjacentes qui n'engendrent pas de bigrammes habituels.</p> <p>C’est ainsi que l’on peut avoir à la fois les roulements <kbd>CH</kbd>, <kbd>WH</kbd> et <kbd>OW/WO</kbd>, grâce à ce mécanisme appliqué à la lettre <kbd>W</kbd>. Avoir les roulements <kbd>CH</kbd> et <kbd>WH</kbd> a depuis le début été un objectif, car ces deux combinaisons sont très fréquentes.
		Les avoir en roulement offre un confort exceptionnel.</p></section>`,2);function N(e){var t=M(),r=m(h(t),2),i=m(h(r));_(i,{});var a=m(i,6);x(a,{}),l(),o(r);var s=m(r,4),c=m(s,4),u=m(h(c));_(u,{}),l(13),o(c);var d=m(c,2),f=m(h(d),9);_(f,{}),l(3),o(d);var p=m(d,2),g=m(p,4),v=m(h(g));_(v,{});var y=m(v,4);_(y,{}),l(),o(g);var S=m(g,2),C=m(S,4),w=m(h(C),3);_(w,{}),l(5),o(C);var T=m(C,4),E=m(h(T),2);_(E,{}),l(),o(T);var D=m(T,4),O=m(h(D));_(O,{}),l(),o(D);var k=m(D,2),A=m(h(k),9);_(A,{}),l(),o(k);var j=m(k,2),N=m(j,6),P=m(N,2),F=m(h(P),2);x(F,{}),l(),o(P);var I=m(P,6),L=h(I);_(L,{}),l(5),o(I);var R=m(I,4),z=m(h(R));b(z,{}),o(R);var B=m(R,2),V=m(h(B));_(V,{});var H=m(V,2);b(H,{}),l(),o(B);var U=m(B,2),W=m(h(U));b(W,{});var G=m(W,2);x(G,{});var K=m(G,6);x(K,{}),l(),o(U);var q=m(U,2),J=m(h(q));_(J,{}),l(3),o(q),l(2),o(t),n(e,t)}var P=r(`<section><h2 id="licence">Licence</h2> <p>La disposition de clavier <!>, ses pilotes ainsi que son site de présentation <a href="https://ergopti.fr" class="link">https://ergopti.fr</a> sont distribués sous la <strong>licence MIT</strong>. Le code source est librement disponible
		sur GitHub\xA0: <a href="https://github.com/adrienm7/ergopti" class="link">https://github.com/adrienm7/ergopti</a>.</p> <p>La license MIT est une licence permissive, simple et courte, qui n'impose que quelques
		conditions, notamment la préservation des mentions de droits d’auteur et de licence. Les travaux
		sous cette licence, y compris les modifications et œuvres dérivées, peuvent être redistribués
		sous d’autres termes, et ce, même sans fournir le code source. La seule condition est de
		conserver les mentions de licence et de droits d’auteur.</p> <h3>Permissions</h3> <ul><li>Utilisation commerciale ;</li> <li>Modification ;</li> <li>Distribution ;</li> <li>Usage privé.</li></ul> <h3>Limitations</h3> <ul><li>Absence de garantie ;</li> <li>Aucune responsabilité.</li></ul> <h3>Conditions</h3> <ul><li>Conservation des mentions de licence et des droits d’auteur.</li></ul></section>`);function F(e){var t=P(),r=m(h(t),2),i=m(h(r));_(i,{}),l(7),o(r),l(14),o(t),n(e,t)}var I=r(`<meta name="description" content="Genèse, autocritiques, historique des versions, licence et contact de la Disposition Ergopti"/>`),L=r(`<!> <!> <!> <!> <!>`,1),R=r(`<bloc-introduction><!></bloc-introduction>`,2);function z(e){s(`1871sr3`,e=>{var t=I();i(()=>{p.title=`Informations sur la Disposition Ergopti`}),n(e,t)}),S(e,{children:(e,t)=>{var r=L(),i=d(r);N(i,{});var a=m(i,2);D(a,{});var o=m(a,2);k(o,{});var s=m(o,2);F(s,{}),j(m(s,2),{}),n(e,r)},$$slots:{default:!0,introduction:(e,t)=>{var r=R();T(h(r),{}),o(r),n(e,r)}}})}export{z as component,C as universal};