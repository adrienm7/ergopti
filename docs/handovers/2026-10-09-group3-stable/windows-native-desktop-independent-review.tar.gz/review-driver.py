from pathlib import Path
import hashlib,json,subprocess,shutil,os
A=Path('/workspace/.ergopti-cloud/preparations/windows-native-desktop-source-prototype-v2');B=Path('/workspace/.ergopti-cloud/reviews/windows-native-desktop-source-v2-independent');B.mkdir(mode=0o700)
def h(data):return hashlib.sha256(data).hexdigest()
seal=[]
for line in (A/'SHA256SUMS').read_text().splitlines():
 value,name=line.split('  ',1);p=Path(name);assert not p.is_absolute() and '..' not in p.parts;assert h((A/p).read_bytes())==value;seal.append({'path':name,'sha256':value})
assert len(seal)==165
assert h((A/'RECEIPT.json').read_bytes())=='0d544cdf32a04c79522928e681bc05f70d4345be2440aae0693bcd838c844d75'
pairs=json.loads((A/'source-pairs.json').read_text());receipt=json.loads((A/'RECEIPT.json').read_text());git=[]
repo=Path('/workspace/ergopti')
def show(ref,file):
 cp=subprocess.run(['git','show',ref+':'+file],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE);return cp
for row in pairs['changed_paths']:
 file=row['file'];candidate=(A/'projection'/file).read_bytes();assert h(candidate)==row['after_sha256'];assert b'\r' not in candidate
 if file.endswith('.ahk'):assert candidate.startswith(b'\xef\xbb\xbf')
 for ref in [pairs['actual_head'],pairs['origin_dev'],'HEAD',':']:
  cp=show(ref,file) if ref!=':' else subprocess.run(['git','show',':'+file],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if row['new']:assert cp.returncode!=0,(ref,file,'new path already exists')
  else:assert cp.returncode==0 and h(cp.stdout)==row['before_sha256'],(ref,file,'preimage drift')
  git.append({'file':file,'ref':ref,'exists':cp.returncode==0,'sha256':h(cp.stdout) if cp.returncode==0 else None})
 if not row['new']:assert h((A/'preimage'/file).read_bytes())==row['before_sha256']
assert len(pairs['changed_paths'])==16
# Sparse copies only: exact frozen projection and preimage. No source rewriting.
shutil.copytree(A/'projection',B/'projection');shutil.copytree(A/'preimage',B/'preimage')
for name in ['qualify.cjs','alpha-renames.json','source-pairs.json','RECEIPT.json','forward.patch','inverse.patch','upstream-pins.json','ancestor-preservation.json']:
 shutil.copyfile(A/name,B/name)
# Author qualifier writes only its __dirname; it is executed in the reviewer copy.
cp=subprocess.run(['node',str(B/'qualify.cjs')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=dict(os.environ,TMPDIR='/tmp'),timeout=90)
(B/'independent-qualify.log').write_bytes(cp.stdout);print(cp.returncode,cp.stdout.decode(errors='replace'),flush=True);assert cp.returncode==0
# Recheck immutable packet after focused replay.
for row in seal:assert h((A/row['path']).read_bytes())==row['sha256']
(B/'independent-git-preimages.json').write_text(json.dumps(git,indent=2)+'\n')
(B/'original-165-seals.json').write_text(json.dumps(seal,indent=2)+'\n')
(B/'independent-replay.json').write_text(json.dumps({'source_checks':28,'exit':cp.returncode,'author_seals_preserved':165,'current_git_preimages':64,'paths':16,'canonical_mutations':False,'native_AHK':'UNRUN','PowerShell':'SKIPPED_NON_WINDOWS','ordinary_complete_suite':'UNRUN','full_JS':'UNRUN','compiler':'UNRUN'},indent=2)+'\n')
