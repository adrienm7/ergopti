const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { loadMetricsAppsPage } = require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
const source = fs.readFileSync('/workspace/ergopti-windows-r6-ui-metrics/tools/test/test-metrics-filter-cache.cjs','utf8');
const publish = source.slice(source.indexOf('function publishLoadedAppsData('), source.indexOf('const streakCases = ['));
const ports = source.slice(source.indexOf('const iconInputs = '), source.indexOf("for (const host of ['windows', 'macos', 'linux']) {", source.indexOf('function iconPage(')));
eval(publish + ports + `
const f = iconPage('windows');
f.publish({Editor:iconInputs.red}); f.complete(0);
assert.equal(f.color('Editor'),'#ff0000');
const before=vm.runInContext('Object.keys(_dominantColorCache)',f.page.context);
publishLoadedAppsData(f.page,'windows',{}, {},2);
const after=vm.runInContext('Object.keys(_dominantColorCache)',f.page.context);
console.log(JSON.stringify({before,after,selected:vm.runInContext('currentSelectedDate',f.page.context),currentIconCount:vm.runInContext('Object.keys(appIcons).length',f.page.context),retainsPreviousPayload:vm.runInContext('Object.values(_dominantColorCache).some(x => x.source === '+JSON.stringify(iconInputs.red)+')',f.page.context),errors:f.page.diagnostics.filter(x=>x.level==='error')}));
assert.deepEqual(Array.from(after),[],'an empty accepted snapshot must release obsolete decoded image payloads');
`);
