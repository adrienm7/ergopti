from pathlib import Path
import subprocess,json,sys,hashlib
p=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');records=json.loads((p/'sparse-fixtures.json').read_text());record=next(x for x in records if x['fixture']=='current135');root=Path(record['root']);head=record['actual_private_controller_commit'];out=p/'source-control-runs/current135-original-receiver-genuine70-refusal';out.mkdir();h=lambda b:hashlib.sha256(b).hexdigest();code=record['controller_postimages'];saved={x:(root/x).read_bytes() for x in code};index=(root/'.git/index').read_bytes();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
for path in code:
 old=(p/'preimages'/path).read_bytes();assert old==subprocess.check_output(['git','show','70d88b885d45ae616b69f33b9826f76fb1be9493:'+path],cwd=root);(root/path).write_bytes(old)
subprocess.run(['git','update-ref','--no-deref','HEAD','70d88b885d45ae616b69f33b9826f76fb1be9493'],cwd=root,check=True)
try:
 recipe='tools/diagnostics/fixtures/number-row-native-causal/projection-manifest.original-c15.json.raw';approval=p/'provisional-current135-envelope.json';argv=[sys.executable,'-B','tools/diagnostics/generate_number_row_source_composition.py','--head','70d88b885d45ae616b69f33b9826f76fb1be9493','--recipe',recipe,'--approval',str(approval),'--approval-sha256',h(approval.read_bytes()),'--receiver','tools/diagnostics/number_row_native_causal.py','--output',str(out/'must-not-be-created.json')];(out/'argv.json').write_text(json.dumps({'argv':argv,'cwd':str(root),'expected':'authentic original99/source-approval refusal, before materialization','published_HEAD':'70d88b885d45ae616b69f33b9826f76fb1be9493'},indent=2)+'\n');result=subprocess.run(argv,cwd=root,capture_output=True,timeout=30);(out/'stdout.raw').write_bytes(result.stdout);(out/'stderr.raw').write_bytes(result.stderr);(out/'exit.raw').write_text(str(result.returncode)+'\n');assert result.returncode!=0 and b'exact source approval record required' in result.stderr and not (out/'must-not-be-created.json').exists();print(result.returncode);print(result.stderr.decode()[-900:])
finally:
 for path,data in saved.items():(root/path).write_bytes(data)
 subprocess.run(['git','update-ref','--no-deref','HEAD',head],cwd=root,check=True)
 assert (root/'.git/index').read_bytes()==index
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 for path,data in saved.items():assert (root/path).read_bytes()==data
 (out/'restoration.json').write_text(json.dumps({'private_controller_HEAD_restored':head,'private_index_bytes_unchanged':True,'four_working_controller_images_exact':True,'canonical_mutation':False},indent=2)+'\n')
