#ifndef ERGOPTI_GROUP4_GUARDIAN_WIN32_H
#define ERGOPTI_GROUP4_GUARDIAN_WIN32_H

#include <windows.h>
#include "guardian.h"

typedef struct {
    HANDLE job;
    HANDLE parent;
    HANDLE stop;
    HANDLE setup_process;
    DWORD parent_pid;
    DWORD daemon_pid;
    FILETIME parent_creation;
    FILETIME daemon_creation;
    DWORD terminate_code;
    DWORD first_os_error;
} GG_Win32Context;

typedef struct {
    DWORD volume_serial;
    DWORD file_index_high;
    DWORD file_index_low;
    DWORD is_directory;
    const wchar_t *native_path;
} GG_Win32Identity;

GG_Port GG_Win32Port(GG_Win32Context *);
int GG_Win32CheckContent(GG_Win32Context *, HANDLE, const GG_Win32Identity *);

#endif
