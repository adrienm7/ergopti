'use strict';
// Portable ordering/control receiving only. This does not run a Windows host.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const base = __dirname;
const marker = 'CLOCK_RECEIVER controls=32 SKIPPED reason=POSIX_file_modes_and_process_owners_unavailable native=false official=false\n';
function observe(source, platform) {
  let requires=0, stdout='', exit=null;
  const exitStop = {}, requireStop = {};
  try {
    vm.runInNewContext(source, {
      process:{platform, stdout:{write(value){stdout+=value;}},exit(code){exit=code;throw exitStop;}},
      require(){requires++;throw requireStop;}
    },{timeout:1000});
  } catch (error) {
    assert.ok(error===exitStop || error===requireStop);
  }
  return {requires,stdout,exit};
}
const relative='tools/test/test-native-http-clock-evidence.cjs';
const original=fs.readFileSync(path.join(base,'preimage',relative),'utf8');
const candidate=fs.readFileSync(path.join(base,'candidate',relative),'utf8');
assert.deepEqual(observe(candidate,'win32'),{requires:0,stdout:marker,exit:0});
assert.deepEqual(observe(candidate,'linux'),{requires:1,stdout:'',exit:null});
const red=observe(original,'win32');
assert.throws(()=>assert.deepEqual(red,{requires:0,stdout:marker,exit:0}),assert.AssertionError);
console.log(JSON.stringify({qualification:'MODELED_WINDOWS_PLATFORM_ONLY',earlyWin32SkipBeforeAnyRequire:true,nonWindowsDoesNotSkip:true,originalAssertionRed:true,actualWindowsNative:false}));
