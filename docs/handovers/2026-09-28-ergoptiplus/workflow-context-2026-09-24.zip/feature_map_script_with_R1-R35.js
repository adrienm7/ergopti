export const meta = {
  name: 'ergopti-feature-map',
  description: 'Map current code for 35 macOS/Windows/Linux feature requests before implementation',
  phases: [
    { title: 'Map', detail: '10 read-only investigators, one per subsystem, across the 3 drivers' },
    { title: 'Critique', detail: 'completeness critic over the merged map' },
  ],
}

const REQUESTS = `
Numbered user requests (user is French; UI in 21 locales under static/ergopti_plus/_shared/data/locales/*.json, en.json canonical). The user mostly tested macOS (Hammerspoon + packaged ErgoptiPlus.app + Karabiner fork). Goal: full parity across macOS (static/ergopti_plus/macos), Windows AHK v2 (static/ergopti_plus/windows) and Linux LuaJIT (static/ergopti_plus/linux), shared code in static/ergopti_plus/_shared. AHK works well today; Linux never tested live; macOS opens but "no menu can be activated".
R1 "Enable all features" menu button does nothing (macOS).
R2 Keyboard layout submenu lists input sources with the current one checked: add a disabled header item at the top, e.g. "Input methods".
R3 If the ErgoptiPlus app crashes or is force-quit, Ergopti's own Karabiner remapping (subprocess/rules) MUST stop. Only Ergopti's; a user's real Karabiner install stays. Parity: Linux kanata/ydotool/evdev grab children, Windows equivalents.
R4 Many new actions on 3 OSes inspired by the macOS app Shortcutie: close all apps, open an app, clear/open notifications, show desktop, remove quarantine flag of the selected app, chmod +x the selected file, etc.
R5 BLOCKING: on macOS nearly nothing works because everything is disabled; config.toml has [gestures] enabled = true yet the Gestures submenu is greyed/disabled.
R6 Debug > Console opens too small; it must open centered and large.
R7 Logs too verbose: hundreds of "gestures health check tick" lines (debug level) differing only by timestamp. Reduce the timer or collapse repeats ("x2", "x3").
R8 Launcher error dialog: "ErgoptiPlus could not start. Step native_logger. Cause: native logger did not ACK retained sequence 181557 after 4 sends. Details in ~/Library/Logs/ErgoptiPlus/launcher.log". Find the root cause. Also the log location: proposal to move ALL logs (driver logs currently under the config folder /logs) to the OS logs dir under an ergopti_plus subfolder on 3 OSes, configurable from the menu item that sets the config folder path; menu items "open today's log", "open logs folder" must follow.
R9 Rename menu item "Ouvrir le journal des erreurs" to "Ouvrir le fichier des erreurs du jour" in all locales; the file holds errors AND warnings: drop warnings?
R10 System diagnostics UI overhaul: "recent warnings/errors" section filled from today's errors file (last N lines?); explain adapters "wired" vs "ok" (maybe two lists); structure with H1/H2/H3 and small tables: paths (config, logs...), versions (Hammerspoon, Karabiner, build, git commit), hardware, OS version + running apps + CPU/memory usage, pressed modifiers + last physical keys from Karabiner + caps state, LLM status (enabled, model/API, health), every Ergopti feature on/off, internet connectivity, required system permissions granted? + buttons to open settings, connected peripherals USB/Bluetooth.
R11 "Check for latest version" button label untranslated; the result dialog is not centered on screen, icon and text left aligned -> center all; 2 lines: "vX" / "is already the latest version", or if outdated: two buttons (close / update) instead of OK.
R12 Release notes UI: Markdown parsing issue, v133 shows raw <details><summary>. Release bodies now put downloads first and the changelog folded (commit de5ef9ebf); in this UI show the changelog first (expanded) and downloads second.
R13 Update channel selector (dev vs main) placed between the separator and "Check for updates", 3 OSes (may exist on Windows only). Release notes UI opens the selected channel and can switch channel (syncing the menu). The check-for-updates dialog states which channel was checked. If a newer dev build exists while on main, maybe offer it. Scalable channel registry (main/dev/beta/alpha) with no coupling.
R14 Diagnostics UI buttons: copy / save to file / open a GitHub issue. Debug submenu: add "Report a bug" and "Suggest a feature" below "System diagnostics", opening prefilled GitHub issues. Non-technical users; GitHub account friction; URL prefill limits.
R15 Every bug/error must be logged AND show a UI with the error text, where it is logged, and a button to create a GitHub issue.
R16 The transient "checking for updates" text must be translated in all locales.
R17 Rename menu items "Notes de version" -> "Versions" and "Ouvrir la page des versions" -> "Versions — GitHub" in all locales.
R18 Remove the enable-all/disable-all features buttons; rename submenu "Actions globales" to "Configuration" containing: restore recommended values, clean config.toml (migrate/remove obsolete keys), the config-folder item (config + logs paths), setup wizard.
R19 Best solution for users who want everything off then enable features one by one.
R20/R29 Every submenu's FIRST item is a checkbox toggling the whole submenu (replacing "Enable all"/"Disable all" pairs, and replacing macOS click-on-submenu-title toggling); the submenu title is checked when enabled. Harmonize on Windows behaviour.
R21 Top-level order: TapHolds, Shortcuts, Gestures, --, Keyboard layout, Hotstrings, AI, --, Metrics, Applications (Applications macOS-only for now).
R22 App Cloner description: "Dupliquer une application" (drop "installée").
R23 Future-proofing: breaking changes, config key renames, schema versioning, migrations, deprecations: professional best practices.
R24 Gestures submenu: remove the "Circular Spaces navigation" toggle; replace with 4 actions (Space left/right x normal/circular), in the action list shared by gestures and shortcuts.
R25 Terminology: "default values" vs "recommended values": one shared locale key everywhere (gestures, shortcuts, ...). Distinguish "reset to recommended" from "clear all" (e.g. set every macOS gesture to None = OS default).
R26 Diagnostics privacy: anonymize home/user names, omit running apps unless opted in?
R27 Menubar icon: the 2 items selecting the icon become one selector, last item of the "— Disposition Ergopti —" section; default v1. Sections: Ergopti layout, menubar input languages with active one, option for the language to use when Ergopti is paused/active (maybe also when closed?).
R28 Big feature: manage other layouts (Optimot, Ergo-L) besides Ergopti: bundle or fetch releases, install/uninstall/update by button, normalize them; "Disposition Ergopti" -> "Disposition personnalisée"; UI to manage installed/available layouts; Windows AHK should read a layout file instead of the hardcoded Ergopti layout. Staged plan.
R30 Gestures: assigning an action to a macOS gesture the OS already uses must show a warning UI with a link to disable the system default (user tested 3-finger tap: nothing shown). Alternative: top item in Gestures submenu with OK/KO status from checking system settings, plus an item opening quick links to system gesture settings.
R31 Tap-Hold submenu: remove the "— Tap / Hold" header item; rename "Main gauche" -> "Main gauche — Tap / Hold" (same for right); remove all modifier-shortcut items from Tap-Hold and move them (symmetric shortcuts, propagate tap on combo, ...) to a submenu under Shortcuts: key combinations, ordered (tap1 then tap2) or chord.
R32 New actions if missing: paste without formatting, uppercase/lowercase/titlecase the selection, wrap the selection with a configurable symbol.
R33 Big feature: navigation layer editable key by key (web UI?) incl. numpad, scroll wheel, mouse buttons; default = current nav layer. Config split (layer.toml?) vs one file. Principle: empty config => OS default behaviour. First run asks per submenu to enable + import recommended settings; default "no" everywhere (no keylogger/caps remap behind the user's back). Recommended settings: hotstrings (packs by language, per file/section), metrics, shortcuts (per shortcut), tap-hold, gestures.
R34 AI submenu is disabled yet shows "Modèle actif : Qwen" -> rename "Modèle sélectionné" in all locales. "Number of suggestions" item duplicates the one in the generation parameters submenu. AHK: Ctrl+Space should generate a prediction but seems broken. Create a "generate prediction" action assignable to gestures/shortcuts; remove the generation-shortcut item; default shortcut in Shortcuts submenu (Win+Space? Ctrl+Space on macOS? Tab?). Shortcuts bound to actions must swallow their keys (Win+Space must not cycle input languages).
R35 Automatic update checks with a frequency selector (1min 5min 30min 1h 6h 12h 1d 3d 1w 1mo) on 3 OSes; handle machines powered off daily (persist last check, catch up on startup).
`

const COMMON = `You are a READ-ONLY investigator in the Ergopti repository (D:/Documents/GitHub/ergopti, Windows host, use absolute paths). Do NOT edit, create, stage or commit any file. Start by reading docs/memory/README.md and only the memory topics relevant to your scope. Use Grep/Glob/Read. Be concrete: cite repo-relative file paths with line numbers for every claim about current behaviour. Distinguish what exists per driver (macos / windows / linux / shared). When you find a bug root cause, give the evidence chain. When proposing changes, name the owning source of truth (shared manifest, shared JSON, generator) rather than per-driver copies, and name the tests that should be added (repo test layout: macOS static/ergopti_plus/macos/tests/{unit,meta}, Windows static/ergopti_plus/windows/tests/{unit,meta}, Linux static/ergopti_plus/linux/tests/unit, JS tools/test/*.cjs). Keep the report dense; no filler.
${REQUESTS}`

const REPORT = {
  type: 'object',
  properties: {
    scope: { type: 'string' },
    current_state: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          request_ids: { type: 'array', items: { type: 'string' } },
          driver: { type: 'string' },
          summary: { type: 'string' },
          refs: { type: 'array', items: { type: 'string' } },
        },
        required: ['request_ids', 'driver', 'summary', 'refs'],
      },
    },
    root_causes: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          request_ids: { type: 'array', items: { type: 'string' } },
          symptom: { type: 'string' },
          cause: { type: 'string' },
          evidence: { type: 'array', items: { type: 'string' } },
          confidence: { type: 'string' },
        },
        required: ['request_ids', 'symptom', 'cause', 'evidence', 'confidence'],
      },
    },
    proposals: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          request_ids: { type: 'array', items: { type: 'string' } },
          title: { type: 'string' },
          design: { type: 'string' },
          files_to_change: { type: 'array', items: { type: 'string' } },
          tests: { type: 'string' },
          effort: { type: 'string', enum: ['S', 'M', 'L', 'XL'] },
          depends_on_user_decision: { type: 'boolean' },
          risks: { type: 'string' },
        },
        required: ['request_ids', 'title', 'design', 'files_to_change', 'tests', 'effort', 'depends_on_user_decision', 'risks'],
      },
    },
    questions_for_user: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          request_ids: { type: 'array', items: { type: 'string' } },
          question: { type: 'string' },
          options: { type: 'array', items: { type: 'string' } },
          recommendation: { type: 'string' },
          why: { type: 'string' },
        },
        required: ['request_ids', 'question', 'options', 'recommendation', 'why'],
      },
    },
    gotchas: { type: 'array', items: { type: 'string' } },
  },
  required: ['scope', 'current_state', 'root_causes', 'proposals', 'questions_for_user', 'gotchas'],
}

const SCOPES = [
  {
    key: 'menu',
    prompt: `SCOPE: menu structure and labels. Requests R1 R2 R9 R17 R18 R20/R29 R21 R22 R27 (and labels of R11 R16 R34). Map: the shared menu manifest (static/ergopti_plus/_shared/modules/menu/, find its canonical source and generator — memory says menu_manifest.json is generated), the macOS renderer (macos/ui/menu/*.lua, especially init.lua, menu_state.lua, global_actions_transaction.lua, menu_keyboard_layout.lua, menu_keyboard_slots.lua, menu_apps.lua), Windows (windows/ui/menu/*.ahk, windows/ui/tray_menu.ahk), Linux (linux/ui/menu/*). For each driver: exact current top-level order, how a submenu is toggled on/off (click on title on macOS? first item on Windows?), how "Enable all"/"Disable all" and "Actions globales" work and why "Enable all" could do nothing on macOS, where the menubar-icon selection items live, the Updates and Debug submenus content/order, which locale keys hold "Ouvrir le journal des erreurs", "Notes de version", "Ouvrir la page des versions", "Vérifier la dernière version"/check-for-updates, "checking for updates", App Cloner description, "Modèle actif". Also map the i18n pipeline: locale JSON keys, the TSV caches, tools/locale/check_locales.py and parity tests, how drivers look up keys (so we know the exact procedure to add/rename a key in 21 locales). Read .agents/skills/i18n/SKILL.md.`,
  },
  {
    key: 'macos-blocking',
    prompt: `SCOPE: R5 BLOCKING bug + R1. On macOS "nearly nothing works because everything is disabled; config.toml has [gestures] enabled = true yet the Gestures submenu is greyed/disabled", and "Enable all features" does nothing, "macOS opens but no menu can be activated". Trace, in static/ergopti_plus/macos, the complete path from config.toml loading (infra/toml, config schema in _shared/core/config_schema) to feature state (gestures, hotstrings, shortcuts, tap-holds, metrics, llm) to menu item enabled/checked/disabled rendering (ui/menu/*.lua, global_feature_switch, menu_state, builder). Find EVERY condition that can grey out a submenu or make toggles inert: pause / Disable All state persisted, onboarding not completed, accessibility/input-monitoring trust missing, Karabiner fork lease not ready, adapters not wired, strict TOML validation rejecting keys (rejected-override latch), config dir resolution pointing to a different config, schema v2 key names differing from what the user's file uses (the user's old config at D:/Documents/GitHub/config/ergopti_plus/hammerspoon/config.toml is an example of a real user file; compare its keys to the current schema), menu callbacks that throw and are swallowed. Also look at git log -30 on static/ergopti_plus/macos for recent changes that could have introduced a regression (e.g. commits "bring pause, Disable All ... to parity"). Produce ranked root-cause hypotheses with evidence and a way to confirm each from logs the user can send, plus the fix and the regression test.`,
  },
  {
    key: 'logging',
    prompt: `SCOPE: logging. Requests R6 R7 R8 R9 (+ error file content for R10). Read static/ergopti_plus/_shared/modules/logger/SPEC.md and .agents/skills/logger/SKILL.md. Map: how each driver resolves the logs directory (config dir /logs?), launcher.log on macOS (~/Library/Logs/ErgoptiPlus) and the Swift launcher (macos/launcher/Sources), the native logger transport and its ACK/retained-sequence protocol ("native logger did not ACK retained sequence N after 4 sends" — find the exact code, explain when it fires, why a sequence number like 181557 could be retained across launches, and the root cause candidates, e.g. a persisted spool/journal replayed on start, a logger process from a previous run, a symlinked logs folder), the per-driver menu items opening today's log / errors log / logs folder, the paths editor UI (_shared/ui/paths_editor + driver hosts) and paths.toml, the errors-only sink. Find the "gestures health check tick" log line (all drivers) and any other periodic debug lines that spam; propose a shared repeat-collapsing mechanism ("last message repeated xN" like syslog) in the logger core for all 3 drivers vs lowering timers. Find how Debug > Console is opened on macOS (hs.openConsole / hs.console) and what the Windows/Linux equivalents are, and how to size/center the window. Give OS-conventional log locations for 3 OSes (macOS ~/Library/Logs/ErgoptiPlus, Windows %LOCALAPPDATA%, Linux XDG_STATE_HOME) and the migration implications (existing logs, crash_reports, metrics which must stay in config?).`,
  },
  {
    key: 'child-processes',
    prompt: `SCOPE: R3. If ErgoptiPlus crashes or is force-quit (kill -9, Force Quit), Ergopti's own remapping must stop, without touching a user's own Karabiner-Elements setup. Map on macOS: how Ergopti installs/uses its Karabiner fork (vendor/karabiner-elements, platform/remap, config_karabiner.toml generator, lease/token-scoped rules and variables per memory "project-hs-karabiner-exact-lease-isolation"), whether rules live in the user's karabiner.json profile or in a separate core-service process owned by Ergopti, the launcher (macos/launcher/Sources, com.ergoptiplus.remap-guardian.plist — what the guardian does), what happens today on crash (lease expiry? heartbeat? guardian?), and gaps. Also Linux (linux/platform/remap, kanata/ydotool/evdev grab children: are they killed on parent death? PR_SET_PDEATHSIG? process groups?) and Windows (native/nav_event_owner DLL, vendor/ergopti_crash_worker.ps1, any child processes). Propose a robust design per OS (e.g. heartbeat lease with TTL enforced by a watchdog independent of the app, kqueue NOTE_EXIT on the parent pid, launchd KeepAlive semantics) and the tests. Note that the user explicitly said: stop Ergopti's remapping only; leave the user's real Karabiner if Ergopti's Karabiner integration is disabled.`,
  },
  {
    key: 'diagnostics',
    prompt: `SCOPE: diagnostics and error reporting. Requests R10 R14 R15 R26. Map the "System diagnostics" / healthcheck UI (_shared/ui/healthcheck and driver hosts macos/ui/healthcheck, windows/ui/healthcheck, linux/ui/healthcheck; macos/modules/diagnostics, linux/modules/diagnostics, _shared/lua/diagnostics, _shared/modules/logger/diagnostic_snapshot.json): every section/table it shows today and where each value comes from, what "adapters wired" vs "adapters ok" mean exactly in code, the "recent warnings/errors" section source, the buttons (copy/close), and how each driver passes data to the web UI. Map existing crash/fatal dialogs (boot_fatal, crash_reports, ergopti_crash_worker.ps1, AHK OnError) and whether errors produce any user-visible UI. Check .github for ISSUE_TEMPLATE forms (none exist?) and the repo URL used by the updater. Propose: the restructured diagnostics model (sections: paths, versions incl. git commit, hardware, OS+processes+CPU/RAM/disk, input state/modifiers/Karabiner last keys, LLM, features on/off, network connectivity, permissions with open-settings buttons, peripherals) as ONE shared schema consumed by 3 drivers, privacy redaction rules (home path -> ~, user/host names, serials) with an opt-in "include detailed info" checkbox, save-to-file format, the GitHub issue flow (issue forms in .github/ISSUE_TEMPLATE, prefilled URL with ?template=&title=&body= and URL-length limits ~8k, clipboard + file-attachment fallback, no-account alternative), and a global error dialog with rate limiting/dedup. List what each driver can collect natively (e.g. system_profiler SPUSBDataType/SPBluetoothDataType on macOS, Get-PnpDevice/WMI on Windows, lsusb/bluetoothctl on Linux) and cost/latency concerns (never on the typing path, async).`,
  },
  {
    key: 'updater',
    prompt: `SCOPE: updates. Requests R11 R12 R13 R16 R17 R35. Map _shared/modules/updater, _shared/lua/updater, macos/modules/updater, windows/modules/updater, linux/modules/updater, the changelog/release-notes UI (_shared/ui/changelog, _shared/ui/markdown.js and driver hosts), the download window, the "check for updates" flow and its result dialog on each OS (where it is drawn, why not centered, label keys), any existing channel selector (dev vs main — which driver has it, config key, how channels map to GitHub releases/tags e.g. v0.0.0-dev.N vs stable), any existing automatic periodic check (interval config key, timer, persistence of last-check time) per driver, and the release body format produced by CI (.github/workflows release job; commit de5ef9ebf "put the downloads first and fold the changelog in release notes") so we know exactly what markdown (with <details><summary>) the UI receives. Propose: a shared channel registry (data file listing channels with id, label key, tag matcher, order) consumed by all drivers and the UI; channel-switch sync between menu and UI; the markdown renderer fix for <details>/<summary> and reordering (changelog first, downloads last); the centered 2-line result dialog with Close/Update buttons; a shared auto-check scheduler contract (frequency choices, persisted last_check_at, catch-up on startup after sleep/power-off, jitter, respects pause, never on typing path) with tests on each driver.`,
  },
  {
    key: 'actions',
    prompt: `SCOPE: actions shared by gestures and shortcuts. Requests R4 R24 R32 R34(action part). Map the shared action registry (_shared/modules/actions, _shared/ui/action_picker, apps.manifest.json) and each driver's action implementations (macos/modules/gestures, macos/modules/shortcuts/actions, windows/modules/gestures, windows/modules/shortcuts, linux/modules/gestures, linux/modules/shortcuts): list every existing action id with per-driver availability, how an action is declared once and implemented per driver, how the action picker lists them, how Spaces navigation and the "circular Spaces" toggle (gestures space_wrap config key) work today, whether paste-as-plain-text, change-case (upper/lower/title) of selection, wrap-selection (wrap_symbols module) and LLM "generate prediction" exist as actions. Research the macOS app Shortcutie (use WebSearch/WebFetch) to list its action catalogue, then propose a prioritized list of new actions with per-OS implementation notes (macOS: AppleScript/hs.application/xattr -d com.apple.quarantine on Finder selection/chmod +x via Finder selection; Windows: PowerShell/COM Shell.Application/Explorer selection; Linux: DBus/xdg/wmctrl/gdbus notifications) and which are OS-specific. Explain how to make the 4 Spaces actions replace the toggle and migrate existing config (space_wrap + space_next/space_prev values).`,
  },
  {
    key: 'shortcuts-taphold-gestures-llm',
    prompt: `SCOPE: Shortcuts, Tap-Hold, Gestures and AI submenus. Requests R24 R25 R30 R31 R34. Map for each driver: the Tap-Hold submenu items (header "— Tap / Hold", "Main gauche"/"Main droite", modifier-shortcut items, symmetric shortcuts, propagate tap on combo, etc.) and their config keys (_shared/tap_hold/defaults.toml, _shared/lua/tap_hold, _shared/lua/chord); the Shortcuts submenu items and config; the Gestures submenu items (space_wrap toggle, reset-to-default items, per-gesture action pickers) and how macOS system gesture conflicts are detected/warned today (search for trackpad preference domains like com.apple.AppleMultitouchTrackpad / com.apple.driver.AppleBluetoothMultitouch.trackpad, TrackpadThreeFingerTapGesture, warning dialogs) and why assigning tap_3 showed no warning; the AI (llm) submenu items: where "Modèle actif" is rendered and whether it is greyed when llm disabled, the "number of suggestions" item vs generation-parameters submenu duplicate, the prediction trigger shortcut on each OS (Windows Ctrl+Space: find the hotkey registration and why it may not fire — e.g. registered only when llm.trigger.shortcut true, conflicts with IME, suspended), and how shortcuts swallow their keys (AHK hotkey without ~, macOS eventtap consume, Linux grab) — especially Win+Space and Ctrl+Space (macOS input-source switching). List every "reset to default"/"valeurs par défaut" item across menus and their locale keys (R25). Propose the new Tap-Hold and "Key combinations" submenu structure and config migration, and a recommended default prediction shortcut per OS with conflict analysis.`,
  },
  {
    key: 'config-defaults-onboarding',
    prompt: `SCOPE: configuration model, defaults, migrations, onboarding. Requests R18 R19 R23 R25 R33(config part). Map: _shared/core/config_schema (schema files, version field?), where defaults live (per feature), how each driver loads/saves config.toml (macos/infra/toml, windows/infra/toml, linux infra), the "clean config / unused keys cleanup" features (unused_keys_cleanup.lua in _shared/lua/menu and macos/ui/menu), any existing migration code (legacy spellings, v2 refactor, ApplyConfigToml legacy boolean migration), any schema_version key, the restore-defaults actions (global and per submenu) and their semantics (do they write defaults into the file or delete keys?), whether an absent key means "default" (feature ON?) or "off", the onboarding / setup wizard (_shared/ui/onboarding and driver hosts): its steps and what it enables. Evaluate the user's principle "empty config = OS default behaviour, everything off until the user opts in; first run asks per submenu whether to enable it and import recommended settings" against the current code: list every feature that is ON when its key is absent. Propose: a versioned config with ordered migrations (schema_version, migration registry shared as data, backup before migrate, idempotent, tested with fixtures per version), deprecation policy for renamed keys, a single "recommended" preset source per feature, "reset to recommended" vs "clear (OS default)" semantics, split config files (config.toml + layer.toml/nav_layer.toml?) with a recommendation, and how the first-run wizard should present per-submenu opt-in with per-item import (hotstring packs by language/file/section, shortcuts per shortcut, tap-hold, gestures, metrics).`,
  },
  {
    key: 'layouts-navlayer',
    prompt: `SCOPE: keyboard layouts and navigation layer. Requests R2 R27 R28 R33. Map: how the Ergopti layout is shipped and installed per OS (static/ergopti/macos keylayout bundles, static/ergopti/linux xkb, static/ergopti/windows, macos menu_keyboard_layout.lua / menu_keyboard_slots.lua, linux infra/xkb_keymap.lua and install.sh, Windows AHK hardcoded layout — find where the AHK layout mapping is defined and whether it's generated from a source file), how the keyboard-layout submenu lists input sources and the menubar icon items (v1/v2 icons), the "language when Ergopti paused/active" option. Research (WebSearch/WebFetch) Optimot (optimot.fr) and Ergo-L (ergol.org, GitHub Nuclear-Squid/ergol) distribution formats and licences (macOS .keylayout/.bundle, Windows KLC/MSKLC/kbdedit, Linux xkb), whether they publish GitHub releases, and whether a single canonical description (e.g. Ergo-L's TOML/YAML layout source or kalamine format) could drive all 3 OSes. Then map the navigation layer on each OS (where layer keys are defined: _shared/lua/keymap, macos/modules/keymap, windows/modules/keymap, linux kanata/golden_kanata_defalias.kbd, config_karabiner.toml generation) and design a per-key editable nav layer (data model incl. numpad, mouse buttons, scroll wheel; defaults = current layer; web UI editor reusing _shared/ui patterns; storage in a separate layer.toml vs config.toml trade-offs). Produce a staged plan for R28 and R33 with effort per stage.`,
  },
]

phase('Map')
const reports = await parallel(SCOPES.map(s => () =>
  agent(`${COMMON}\n\n${s.prompt}`, { label: `map:${s.key}`, phase: 'Map', schema: REPORT })
    .then(r => (r ? { key: s.key, ...r } : null))))
const ok = reports.filter(Boolean)
log(`${ok.length}/${SCOPES.length} scope reports returned`)

phase('Critique')
const critique = await agent(
  `${COMMON}\n\nYou are the completeness critic. Below are ${ok.length} scope reports (JSON) mapping the requests. Identify: (1) requests R1..R35 with no or thin coverage, (2) contradictions between reports, (3) claims that look unverified or likely wrong — spot-check the 8 most important ones against the source and correct them, (4) cross-cutting dependencies and a recommended implementation order (what blocks what; what is safe to do before the user answers design questions). Return concise markdown.\n\n${JSON.stringify(ok)}`,
  { label: 'critic', phase: 'Critique' })

return { reports: ok, critique }
