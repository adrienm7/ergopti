-- Private original-source overlay; no canonical writes or native input allocation.
local packet=assert(arg[1])
local root='/workspace/ergopti/static/ergopti_plus'
local generated=arg[4] or packet..'/generator-context'
local source=packet..'/dependencies/g1-source/static/ergopti_plus'
package.path=packet..'/candidate/static/ergopti_plus/linux/?.lua;'..packet..'/candidate/static/ergopti_plus/linux/?/init.lua;'
 ..generated..'/static/ergopti_plus/linux/?.lua;'
 ..source..'/linux/?.lua;'..source..'/linux/?/init.lua;'
 ..root..'/linux/?.lua;'..root..'/linux/?/init.lua;'
 ..packet..'/candidate/static/ergopti_plus/_shared/lua/?.lua;'
 ..source..'/_shared/lua/?.lua;'..source..'/_shared/lua/?/init.lua;'
 ..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
if arg[3] then
 local directory=arg[3];local searchers=package.searchers or package.loaders;local original=searchers[2]
 local allowed={['ui.menu.menu_builder']=true}
 searchers[2]=function(name)
  if allowed[name] then
   local relative=name:gsub('%.','/')..'.lua';local file=io.open(directory..'/'..relative,'rb')
   if file then
    local bytes=assert(file:read('*a'));assert(file:close())
    local label='@'..packet..'/candidate/static/ergopti_plus/linux/'..relative
    return assert((loadstring or load)(bytes,label)),label:sub(2)
   end
  end
  return original(name)
 end
end
require('compat.utf8').install()
local native_loop=require('luv')
local paths=require('infra.paths');local shared=paths.shared
paths.shared=function(relative)
 if relative=='data/locales/cs.json' or relative=='data/locales/pl.json' then
  return packet..'/candidate/static/ergopti_plus/_shared/'..relative
 end
 if relative=='modules/menu/menu_manifest.json' then return packet..'/generator-context/static/ergopti_plus/_shared/'..relative end
 return shared(relative)
end
require(assert(arg[2]))
local result=require('tests.helpers').get_results()
assert(require('luv')==native_loop)
print('PUBLISHED_G1_UNION_CONTROLLED '..result.passed..'/'..result.failed)
os.exit(result.failed>0 and 1 or 0)
