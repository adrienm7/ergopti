# Prepared archive session route

This source-only slice connects the official provider to the existing consent/current session and its original prepared→publish→runtime path. Archive mode is intent only. A genuine source-owned ticket is consumed exactly once by FilesDefault; raw row metadata cannot replace that authority. No READY signal publishes AI enable. The coordinator retains its original version/tags/model and separate model-consent owners.

The factory reuses exactly one ready IntakeNative instance whose complete eight-role pins match. An older base-only or partial initialization refuses instead of creating a second DLL owner. Constructors start no process. All nine file roles and the eight native projection remain unchanged. The same original workflow deadline is carried through the official provider.

Session/coordinator retirement includes provider/PAC/download ownership and exact timer fences. Cancellation keeps the session record while archive handback is pending. Original local-archive API calls remain available and unchanged; the new canonical caller must explicitly select official mode. Six recording controls exercise real ticket issue/consume/publication construction behind recorded process/transport ports, plus four selected causal inverses. They have not been parsed or executed by the author.

Canonical UI/init, model-directory, listener proof, actual HTTPS/native daemon receiving, restart/repair and packaging remain unfinished. This is an adoption candidate, not Group4 readiness.
