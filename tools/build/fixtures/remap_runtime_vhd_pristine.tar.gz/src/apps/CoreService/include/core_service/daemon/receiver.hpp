#pragma once

// `krbn::core_service::daemon::receiver` can be used safely in a multi-threaded environment.

#include "app_icon.hpp"
#include "application_launcher.hpp"
#include "console_user_server_peer.hpp"
#include "constants.hpp"
#include "core_service/daemon/core_service_daemon_state_manager.hpp"
#include "device_grabber.hpp"
#include "filesystem_utility.hpp"
#include "process_lifecycle_manager.hpp"
#include "types.hpp"
#include "types/core_service_daemon_state.hpp"
#include <array>
#include <filesystem>
#include <functional>
#include <memory>
#include <pqrs/dispatcher.hpp>
#include <pqrs/osx/session.hpp>
#include <pqrs/osx/system_preferences.hpp>
#include <pqrs/osx/system_preferences/extra/nlohmann_json.hpp>
#include <pqrs/unix_domain_stream.hpp>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace krbn::core_service::daemon {
class receiver final : public pqrs::dispatcher::extra::dispatcher_client {
public:
  // Signals (invoked from the shared dispatcher thread)

  nod::signal<void()> server_bound;

  // Methods

  receiver(const receiver&) = delete;

  receiver(std::optional<uid_t> current_console_user_id,
           std::weak_ptr<core_service_daemon_state_manager> weak_core_service_daemon_state_manager)
      : dispatcher_client(),
        current_console_user_id_(current_console_user_id),
        weak_core_service_daemon_state_manager_(weak_core_service_daemon_state_manager) {
    prepare_karabiner_core_service_daemon_socket_directory();

    if (auto m = weak_core_service_daemon_state_manager_.lock()) {
      core_service_daemon_state_manager_connection_ = m->core_service_daemon_state_changed.connect([this](const auto& core_service_daemon_state) {
        enqueue_to_dispatcher([this, core_service_daemon_state] {
          send_core_service_daemon_state(core_service_daemon_state);
        });
      });
    }

    //
    // Setup server_
    //

    auto socket_file_path = karabiner_core_service_daemon_socket_file_path();

    server_ = std::make_shared<pqrs::unix_domain_stream::server>(
        weak_dispatcher_,
        socket_file_path,
        constants::get_unix_domain_stream_server_options(),
        [](const auto& peer_credentials) {
          auto result = get_shared_codesign_manager()->same_team_id(peer_credentials.pid);
          if (!result) {
            // During an update, retrieving the Team ID may fail, causing an error once.
            // Since this can occur during normal use, treat it as debug rather than warn.
            logger::get_logger()->debug("receiver: peer is not code-signed with same Team ID (pid: {0})",
                                        peer_credentials.pid.value_or(-1));
          }
          return result;
        });

    server_->bound.connect([this, socket_file_path] {
      logger::get_logger()->debug("receiver: bound");

      auto chown_uid = current_console_user_id_.value_or(uid_t(0));
      logger::get_logger()->debug("receiver: chown socket: {0}", chown_uid);
      if (!filesystem_utility::chown(socket_file_path, chown_uid, 0)) {
        return;
      }

      if (!filesystem_utility::permissions(socket_file_path,
                                           filesystem_utility::permissions_0600)) {
        return;
      }

      server_bound();
    });

    server_->bind_failed.connect([this](auto&& error_code) {
      logger::get_logger()->error("receiver: bind_failed");

      // If the socket directory is deleted for any reason,
      // bind_failed will be triggered, so recreate the directory each time.
      prepare_karabiner_core_service_daemon_socket_directory();
    });

    server_->closed.connect([] {
      logger::get_logger()->debug("receiver: closed");
    });

    server_->peer_connected.connect([](auto, auto&&) {
      // Do nothing
    });

    server_->peer_closed.connect([this](auto peer_id) {
      handle_peer_closed(peer_id);
    });

    server_->peer_error_occurred.connect([](auto peer_id, auto&& error_code) {
      logger::get_logger()->debug("receiver: peer_error_occurred ({0}): {1}", peer_id, error_code.message());
    });

    server_->received.connect([](auto, auto&&) {
      // Do nothing
    });

    server_->request_received.connect([this](auto peer_id, auto request_id, auto&& buffer) {
      handle_request(peer_id,
                     request_id,
                     buffer);
    });

    server_->async_start();

    //
    // Start device_grabber
    //

    start_grabbing_if_system_core_configuration_file_exists();

    logger::get_logger()->debug("receiver is initialized");
  }

  ~receiver() override {
    detach_from_dispatcher([this] {
      core_service_daemon_state_manager_connection_.disconnect();
      console_user_server_peer_id_ = std::nullopt;
      console_user_server_peer_ = nullptr;
      stop_device_grabber();
      server_ = nullptr;
    });

    logger::get_logger()->debug("receiver is terminated");
  }

private:
  void async_request(pqrs::unix_domain_stream::peer_id peer_id,
                     nlohmann::json json) {
    if (server_) {
      server_->async_request(
          peer_id,
          nlohmann::json::to_msgpack(json),
          [](auto&& error_code, auto&&) {
            if (error_code) {
              logger::get_logger()->debug("receiver: request failed: {0}", error_code.message());
            }
          });
    }
  }

  void async_respond(pqrs::unix_domain_stream::peer_id peer_id,
                     pqrs::unix_domain_stream::request_id request_id,
                     nlohmann::json json) {
    if (server_) {
      server_->async_respond(peer_id,
                             request_id,
                             nlohmann::json::to_msgpack(json));
    }
  }

  void async_respond_none(pqrs::unix_domain_stream::peer_id peer_id,
                          pqrs::unix_domain_stream::request_id request_id) {
    async_respond(peer_id,
                  request_id,
                  nlohmann::json{
                      {"operation_type", operation_type::none},
                  });
  }

  void handle_peer_closed(pqrs::unix_domain_stream::peer_id peer_id) {
    if (temporarily_ignored_device_ids_by_peer_.erase(peer_id) > 0) {
      update_temporarily_ignored_device_ids();
    }
    connected_devices_observer_peer_ids_.erase(peer_id);
    notification_message_observer_peer_ids_.erase(peer_id);

    if (multitouch_extension_peer_id_ == peer_id) {
      logger::get_logger()->debug("multitouch_extension is closed.");

      multitouch_extension_peer_id_ = std::nullopt;
      clear_multitouch_extension_environment_variables();
    }

    if (core_service_agent_peer_id_ == peer_id) {
      core_service_agent_peer_id_ = std::nullopt;
    }

    if (console_user_server_peer_id_ == peer_id) {
      console_user_server_peer_id_ = std::nullopt;
      console_user_server_peer_ = nullptr;

      stop_device_grabber();
      start_grabbing_if_system_core_configuration_file_exists();
    }
  }

  void handle_request(pqrs::unix_domain_stream::peer_id peer_id,
                      pqrs::unix_domain_stream::request_id request_id,
                      pqrs::not_null_shared_ptr_t<std::vector<uint8_t>> buffer) {
    if (buffer->empty()) {
      server_->async_close_peer(peer_id);
      return;
    }

    try {
      nlohmann::json json = nlohmann::json::from_msgpack(*buffer);
      switch (json.at("operation_type").get<operation_type>()) {
        case operation_type::core_service_bundle_permission_check_result:
          if (auto m = weak_core_service_daemon_state_manager_.lock()) {
            core_service_agent_peer_id_ = peer_id;

            // If the required permissions were missing when this process started,
            // and a newly launched process confirms that the permissions are now granted,
            // restart this process.
            // (The actual restart is handled by launchd, so this process just exits.)

            auto iohid_listen_event_allowed = json.at("iohid_listen_event_allowed").get<bool>();
            auto accessibility_process_trusted = json.at("accessibility_process_trusted").get<bool>();
            auto restart_required =
                !required_permissions_granted() &&
                iohid_listen_event_allowed &&
                accessibility_process_trusted;

            auto result = core_service_permission_check_result();
            result.set_iohid_listen_event_allowed(iohid_listen_event_allowed);
            result.set_accessibility_process_trusted(accessibility_process_trusted);

            m->set_bundle_permission_check_result(result);

            if (restart_required) {
              logger::get_logger()->info("The required permissions are granted. Restarting core daemons.");

              process_lifecycle_manager::async_request_termination();
            }
          }
          async_respond_none(peer_id,
                             request_id);
          break;

        case operation_type::system_preferences_updated:
          system_preferences_properties_ = json.at("system_preferences_properties")
                                               .get<pqrs::osx::system_preferences::properties>();
          if (device_grabber_) {
            device_grabber_->async_set_system_preferences_properties(system_preferences_properties_);
          }
          logger::get_logger()->debug("`system_preferences` is updated.");
          async_respond_none(peer_id,
                             request_id);
          break;

        case operation_type::start_device_grabber: {
          console_user_server_peer_id_ = peer_id;
          console_user_server_peer_ = std::make_shared<console_user_server_peer>(weak_dispatcher_,
                                                                                 server_,
                                                                                 peer_id);

          stop_device_grabber();
          start_device_grabber(json.at("user_core_configuration_file_path").get<std::string>());

          if (auto m = weak_core_service_daemon_state_manager_.lock()) {
            send_core_service_daemon_state(m->copy_state());
          }

          request_core_service_bundle_permission_check_result_refresh();

          async_respond_none(peer_id,
                             request_id);
          break;
        }

        case operation_type::frontmost_application_changed: {
          auto app = json.at("frontmost_application").get<application>();

          //
          // Synchronize frontmost_application_changed to console_user_server
          //

          if (console_user_server_peer_) {
            console_user_server_peer_->async_frontmost_application_changed(app);
          }

          //
          // Update environment_variables in device_grabber
          //

          if (app.get_bundle_identifier() != "org.pqrs.Karabiner-EventViewer") {
            frontmost_application_ = app;
            if (device_grabber_) {
              device_grabber_->async_post_frontmost_application_changed_event(app);
            }
          }
          async_respond_none(peer_id,
                             request_id);
          break;
        }

        case operation_type::focused_ui_element_changed: {
          auto element = json.at("focused_ui_element").get<focused_ui_element>();

          //
          // Synchronize focused_ui_element_changed to console_user_server
          //

          if (console_user_server_peer_) {
            console_user_server_peer_->async_focused_ui_element_changed(element);
          }

          //
          // Update accessibility.* variables
          //

          focused_ui_element_ = element;
          set_focused_ui_element_variables();
          async_respond_none(peer_id,
                             request_id);
          break;
        }

        case operation_type::input_source_changed:
          input_source_properties_ = json.at("input_source_properties")
                                         .get<pqrs::osx::input_source::properties>();
          if (device_grabber_) {
            device_grabber_->async_post_input_source_changed_event(input_source_properties_);
          }
          async_respond_none(peer_id,
                             request_id);
          break;

        case operation_type::temporarily_ignore_device: {
          const auto& device_id_json = json.at("device_id");

          // null means that EventViewer no longer requests a device to be ignored,
          // such as when capture stops or MainView captures All devices.
          if (device_id_json.is_null()) {
            temporarily_ignored_device_ids_by_peer_.erase(peer_id);
          } else {
            temporarily_ignored_device_ids_by_peer_.insert_or_assign(
                peer_id,
                device_id(device_id_json.get<uint64_t>()));
          }

          update_temporarily_ignored_device_ids();
          async_respond_none(peer_id,
                             request_id);
          break;
        }

        case operation_type::get_manipulator_environment:
          if (device_grabber_) {
            device_grabber_->async_invoke_with_manipulator_environment(
                [this, peer_id, request_id](auto&& manipulator_environment) {
                  async_respond(peer_id,
                                request_id,
                                nlohmann::json{
                                    {"operation_type", operation_type::manipulator_environment},
                                    {"manipulator_environment", manipulator_environment.to_json()},
                                });
                });
          } else {
            async_respond_none(peer_id,
                               request_id);
          }
          break;

        case operation_type::connect_multitouch_extension:
          logger::get_logger()->debug("multitouch_extension is connected.");
          multitouch_extension_peer_id_ = peer_id;
          async_respond_none(peer_id,
                             request_id);
          break;

        case operation_type::set_app_icon: {
          // `set_app_icon` requires root privileges.
          auto number = json.at("number").get<int>();

          logger::get_logger()->info("set_app_icon {0}", number);

          app_icon(number).save_to_file(constants::get_system_app_icon_configuration_file_path());

          application_launcher::launch_app_icon_switcher();

          if (console_user_server_peer_) {
            console_user_server_peer_->async_app_icon_changed(number);
          }

          async_respond_none(peer_id,
                             request_id);
          break;
        }

        case operation_type::set_variables:
          if (device_grabber_) {
            for (const auto& [k, v] : json.at("variables").items()) {
              device_grabber_->async_post_set_variable_event(
                  manipulator_environment_variable_set_variable(
                      k,
                      v.get<manipulator_environment_variable_value>(),
                      nullptr,
                      std::nullopt,
                      nullptr));
            }
          }
          async_respond_none(peer_id,
                             request_id);
          break;

        case operation_type::clear_user_variables:
          if (device_grabber_) {
            device_grabber_->async_invoke_with_manipulator_environment(
                [this, peer_id, request_id](auto&& manipulator_environment) {
                  for (const auto& name : manipulator_environment.get_variable_names()) {
                    if (name.starts_with("system.") ||
                        name.starts_with("accessibility.")) {
                      continue;
                    }

                    device_grabber_->async_post_set_variable_event(
                        manipulator_environment_variable_set_variable(
                            name,
                            std::nullopt,
                            nullptr,
                            std::nullopt,
                            nullptr,
                            manipulator_environment_variable_set_variable::type::unset));
                  }

                  async_respond_none(peer_id,
                                     request_id);
                });
          } else {
            async_respond_none(peer_id,
                               request_id);
          }
          break;

        case operation_type::observe_connected_devices:
          connected_devices_observer_peer_ids_.insert(peer_id);
          async_respond_connected_devices(peer_id,
                                          request_id);
          break;

        case operation_type::observe_notification_message:
          notification_message_observer_peer_ids_.insert(peer_id);
          async_respond_notification_message(peer_id,
                                             request_id);
          break;

        case operation_type::get_system_variables:
          if (device_grabber_) {
            device_grabber_->async_invoke_with_manipulator_environment(
                [this, peer_id, request_id](auto&& manipulator_environment) {
                  async_respond(
                      peer_id,
                      request_id,
                      nlohmann::json{
                          {"operation_type", operation_type::system_variables},
                          {
                              "system_variables",
                              {
                                  {
                                      "system.now.milliseconds",
                                      manipulator_environment.get_variable("system.now.milliseconds"),
                                  },
                                  {
                                      "system.scroll_direction_is_natural",
                                      manipulator_environment.get_variable("system.scroll_direction_is_natural"),
                                  },
                                  {
                                      "system.use_fkeys_as_standard_function_keys",
                                      manipulator_environment.get_variable("system.use_fkeys_as_standard_function_keys"),
                                  },
                              },

                              // Note:
                              // The accessibility.* variables contain information such as window titles,
                              // so they should not be exposed to other applications via the CLI
                              // and are therefore excluded from the return value.
                          }});
                });
          } else {
            async_respond_none(peer_id,
                               request_id);
          }
          break;

        case operation_type::get_multitouch_extension_variables:
          if (device_grabber_) {
            device_grabber_->async_invoke_with_manipulator_environment(
                [this, peer_id, request_id](auto&& manipulator_environment) {
                  std::unordered_map<std::string, manipulator_environment_variable_value> variables;
                  for (const auto& name : multitouch_extension_environment_variable_names) {
                    variables[name] = manipulator_environment.get_variable(name);
                  }

                  async_respond(peer_id,
                                request_id,
                                nlohmann::json{
                                    {"operation_type", operation_type::multitouch_extension_variables},
                                    {"multitouch_extension_variables", variables}});
                });
          } else {
            async_respond_none(peer_id,
                               request_id);
          }
          break;

        default:
          server_->async_close_peer(peer_id);
          break;
      }
    } catch (std::exception& e) {
      logger::get_logger()->error("received data is corrupted");
      server_->async_close_peer(peer_id);
    }
  }

  std::filesystem::path karabiner_core_service_daemon_socket_file_path() const {
    return constants::get_karabiner_core_service_daemon_socket_file_path();
  }

  void prepare_karabiner_core_service_daemon_socket_directory() const {
    filesystem_utility::prepare_system_directories(current_console_user_id_);
  }

  void start_grabbing_if_system_core_configuration_file_exists() {
    if (!required_permissions_granted()) {
      logger::get_logger()->info("device_grabber is not started because the required permissions are not granted.");
      return;
    }

    auto file_path = constants::get_system_core_configuration_file_path();
    if (filesystem_utility::exists(file_path)) {
      stop_device_grabber();
      start_device_grabber(std::nullopt);
    }
  }

  void start_device_grabber(const std::optional<std::string>& user_core_configuration_file_path) {
    if (device_grabber_) {
      return;
    }

    if (!required_permissions_granted()) {
      logger::get_logger()->info("device_grabber is not started because the required permissions are not granted.");
      return;
    }

    if (auto m = weak_core_service_daemon_state_manager_.lock()) {
      m->reset_device_grabber_state();
    }

    device_grabber_ = std::make_unique<device_grabber>(console_user_server_peer_,
                                                       weak_core_service_daemon_state_manager_);

    connected_devices_changed_connection_ = device_grabber_->connected_devices_changed.connect([this] {
      send_connected_devices_to_observers();
    });

    notification_message_changed_connection_ = device_grabber_->notification_message_changed.connect([this](const auto&) {
      send_notification_message_to_observers();
    });

    device_grabber_->async_set_system_preferences_properties(system_preferences_properties_);
    device_grabber_->async_post_frontmost_application_changed_event(frontmost_application_);
    set_focused_ui_element_variables();
    device_grabber_->async_post_input_source_changed_event(input_source_properties_);
    update_temporarily_ignored_device_ids();

    device_grabber_->async_start(user_core_configuration_file_path,
                                 current_console_user_id_);

    logger::get_logger()->debug("device_grabber is started.");
  }

  void stop_device_grabber() {
    if (!device_grabber_) {
      return;
    }

    connected_devices_changed_connection_.disconnect();
    notification_message_changed_connection_.disconnect();
    device_grabber_ = nullptr;
    if (auto m = weak_core_service_daemon_state_manager_.lock()) {
      m->reset_device_grabber_state();
    }

    send_connected_devices_to_observers();
    send_notification_message_to_observers();

    logger::get_logger()->debug("device_grabber is stopped.");
  }

  void update_temporarily_ignored_device_ids() {
    if (!device_grabber_) {
      return;
    }

    std::unordered_set<device_id> device_ids;
    for (const auto& device_id : temporarily_ignored_device_ids_by_peer_ | std::views::values) {
      device_ids.insert(device_id);
    }

    device_grabber_->async_set_temporarily_ignored_device_ids(device_ids);
  }

  [[nodiscard]] bool required_permissions_granted() const {
    if (auto m = weak_core_service_daemon_state_manager_.lock()) {
      if (auto result = m->copy_current_process_permission_check_result()) {
        return result->required_permissions_granted();
      }
    }

    return false;
  }

  void async_respond_connected_devices(pqrs::unix_domain_stream::peer_id peer_id,
                                       pqrs::unix_domain_stream::request_id request_id) {
    async_invoke_with_connected_devices_message(
        [this, peer_id, request_id](const auto& message) {
          async_respond(peer_id,
                        request_id,
                        message);
        });
  }

  void send_connected_devices_to_observers() {
    async_invoke_with_connected_devices_message(
        [this](const auto& message) {
          for (const auto& peer_id : connected_devices_observer_peer_ids_) {
            async_request(peer_id,
                          message);
          }
        });
  }

  void async_invoke_with_connected_devices_message(std::function<void(const nlohmann::json&)> function) {
    auto invoke = [function](const auto& connected_devices_json) {
      function(nlohmann::json{
          {"operation_type", operation_type::connected_devices},
          {"connected_devices", connected_devices_json},
      });
    };

    if (device_grabber_) {
      device_grabber_->async_invoke_with_connected_devices(invoke);
    } else {
      invoke(nlohmann::json::array());
    }
  }

  void async_respond_notification_message(pqrs::unix_domain_stream::peer_id peer_id,
                                          pqrs::unix_domain_stream::request_id request_id) {
    async_invoke_with_notification_message_message(
        [this, peer_id, request_id](const auto& message) {
          async_respond(peer_id,
                        request_id,
                        message);
        });
  }

  void send_notification_message_to_observers() {
    async_invoke_with_notification_message_message(
        [this](const auto& message) {
          for (const auto& peer_id : notification_message_observer_peer_ids_) {
            async_request(peer_id,
                          message);
          }
        });
  }

  void async_invoke_with_notification_message_message(std::function<void(const nlohmann::json&)> function) {
    auto invoke = [function](const auto& notification_message) {
      function(nlohmann::json{
          {"operation_type", operation_type::notification_message},
          {"notification_message", notification_message},
      });
    };

    if (device_grabber_) {
      device_grabber_->async_invoke_with_notification_message(invoke);
    } else {
      invoke("");
    }
  }

  void set_focused_ui_element_variables() {
    if (device_grabber_) {
      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.role_string",
              manipulator_environment_variable_value(focused_ui_element_.get_role().value_or("")),
              nullptr,
              std::nullopt,
              nullptr));

      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.subrole_string",
              manipulator_environment_variable_value(focused_ui_element_.get_subrole().value_or("")),
              nullptr,
              std::nullopt,
              nullptr));

      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.title_string",
              manipulator_environment_variable_value(focused_ui_element_.get_title().value_or("")),
              nullptr,
              std::nullopt,
              nullptr));

      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.window_title_string",
              manipulator_environment_variable_value(focused_ui_element_.get_window_title().value_or("")),
              nullptr,
              std::nullopt,
              nullptr));

      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.window_position_x",
              manipulator_environment_variable_value(
                  static_cast<int64_t>(focused_ui_element_.get_window_position_x().value_or(0))),
              nullptr,
              std::nullopt,
              nullptr));

      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.window_position_y",
              manipulator_environment_variable_value(
                  static_cast<int64_t>(focused_ui_element_.get_window_position_y().value_or(0))),
              nullptr,
              std::nullopt,
              nullptr));

      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.window_size_width",
              manipulator_environment_variable_value(
                  static_cast<int64_t>(focused_ui_element_.get_window_size_width().value_or(0))),
              nullptr,
              std::nullopt,
              nullptr));

      device_grabber_->async_post_set_variable_event(
          manipulator_environment_variable_set_variable(
              "accessibility.focused_ui_element.window_size_height",
              manipulator_environment_variable_value(
                  static_cast<int64_t>(focused_ui_element_.get_window_size_height().value_or(0))),
              nullptr,
              std::nullopt,
              nullptr));
    }
  }

  void send_core_service_daemon_state(const core_service_daemon_state& core_service_daemon_state) {
    if (console_user_server_peer_) {
      console_user_server_peer_->async_core_service_daemon_state(core_service_daemon_state);
    }
  }

  void request_core_service_bundle_permission_check_result_refresh() {
    if (!core_service_agent_peer_id_) {
      return;
    }

    async_request(
        *core_service_agent_peer_id_,
        nlohmann::json{
            {"operation_type", operation_type::refresh_core_service_bundle_permission_check_result},
        });
  }

  void clear_multitouch_extension_environment_variables() {
    if (device_grabber_) {
      for (const auto& name : multitouch_extension_environment_variable_names) {
        device_grabber_->async_post_set_variable_event(
            manipulator_environment_variable_set_variable(
                name,
                std::nullopt,
                nullptr,
                std::nullopt,
                nullptr,
                manipulator_environment_variable_set_variable::type::unset));
      }
    }
  }

  static constexpr std::array multitouch_extension_environment_variable_names{
      "multitouch_extension_finger_count_upper_quarter_area",
      "multitouch_extension_finger_count_lower_quarter_area",
      "multitouch_extension_finger_count_left_quarter_area",
      "multitouch_extension_finger_count_right_quarter_area",
      "multitouch_extension_finger_count_upper_half_area",
      "multitouch_extension_finger_count_lower_half_area",
      "multitouch_extension_finger_count_left_half_area",
      "multitouch_extension_finger_count_right_half_area",
      "multitouch_extension_finger_count_total",
      "multitouch_extension_palm_count_upper_half_area",
      "multitouch_extension_palm_count_lower_half_area",
      "multitouch_extension_palm_count_left_half_area",
      "multitouch_extension_palm_count_right_half_area",
      "multitouch_extension_palm_count_total",
  };

  std::optional<uid_t> current_console_user_id_;
  std::weak_ptr<core_service_daemon_state_manager> weak_core_service_daemon_state_manager_;
  nod::scoped_connection core_service_daemon_state_manager_connection_;

  std::shared_ptr<pqrs::unix_domain_stream::server> server_;
  std::unique_ptr<device_grabber> device_grabber_;
  nod::scoped_connection connected_devices_changed_connection_;
  nod::scoped_connection notification_message_changed_connection_;
  std::optional<pqrs::unix_domain_stream::peer_id> core_service_agent_peer_id_;
  std::optional<pqrs::unix_domain_stream::peer_id> console_user_server_peer_id_;
  std::shared_ptr<console_user_server_peer> console_user_server_peer_;
  std::optional<pqrs::unix_domain_stream::peer_id> multitouch_extension_peer_id_;
  std::unordered_map<pqrs::unix_domain_stream::peer_id, device_id> temporarily_ignored_device_ids_by_peer_;
  std::unordered_set<pqrs::unix_domain_stream::peer_id> connected_devices_observer_peer_ids_;
  std::unordered_set<pqrs::unix_domain_stream::peer_id> notification_message_observer_peer_ids_;

  pqrs::osx::system_preferences::properties system_preferences_properties_;
  application frontmost_application_;
  focused_ui_element focused_ui_element_;
  pqrs::osx::input_source::properties input_source_properties_;
};
} // namespace krbn::core_service::daemon
