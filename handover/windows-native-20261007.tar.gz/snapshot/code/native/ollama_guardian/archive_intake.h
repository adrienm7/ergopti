#ifndef ERGOPTI_ARCHIVE_INTAKE_H
#define ERGOPTI_ARCHIVE_INTAKE_H

#include "guardian_service.h"

typedef enum {
    GAI_RESERVED=0, GAI_SOURCE_BOUND=1, GAI_NAMESPACE_READY=2,
    GAI_DOWNLOAD_BOUND=3, GAI_DOWNLOADING=4, GAI_SEAL_GRANTED=5,
    GAI_STOPPING=6, GAI_RETIRED=7, GAI_DEBT=8
} GAI_Phase;
typedef struct {
    uint64_t id;
    uint32_t phase,first_error,guardian_phase,activation_claimed;
    uint32_t download_terminal,download_exit,download_members,source_terminal;
    uint32_t source_exit,composite_members,seal_claimed,reserved;
} GAI_Status;

/* The resident internal ShellRunner bridge serializes callers. Registry rows
   precede every effect and remain allocated on uncertainty. Process arguments
   originate only from the authenticated, suspended constructor; no PID reopen
   or caller receipt/Boolean is a lifecycle authority. */
int GAI_Create(uint32_t,uint32_t,const uint8_t[32],const uint8_t[32],uint64_t *);
/* First-install late binding: reserve the row/composite before source launch,
   then validate its continuously held inventory before allocating a channel. */
int GAI_Reserve(const wchar_t *,const uint8_t[32],const uint8_t[32],uint64_t *);
int GAI_BindInventory(uint64_t,const GI_Expected *,size_t,uint64_t,uint64_t);
int GAI_TransferChannel(uint64_t,uint64_t[5]);
int GAI_WriteChannelCommand(uint64_t);
int GAI_OutputIntent(uint64_t,wchar_t *,uint32_t);
int GAI_OutputUnits(uint64_t,uint32_t *);
int GAI_ConfirmOutput(uint64_t,const wchar_t *);
int GAI_Inherited(uint64_t,HANDLE *,HANDLE *,HANDLE *,HANDLE *);
int GAI_AcquireInheritance(uint64_t,uint64_t *);
int GAI_ReleaseInheritance(uint64_t,uint64_t);
/* Attach runs BEFORE the ordinary ShellRunner private job assignment. Bind
   runs afterward and verifies membership of that same retained process. */
int GAI_AttachSource(uint64_t,HANDLE);
int GAI_ClaimSource(uint64_t);
int GAI_BindSource(uint64_t,HANDLE,HANDLE);
int GAI_AttachDownload(uint64_t,HANDLE);
int GAI_BindDownload(uint64_t,HANDLE,HANDLE);
int GAI_BeginGuardian(uint64_t);
int GAI_ClaimDownload(uint64_t);
int GAI_RequestSeal(uint64_t);
int GAI_Stop(uint64_t);
int GAI_Poll(uint64_t,GAI_Status *);

#endif
