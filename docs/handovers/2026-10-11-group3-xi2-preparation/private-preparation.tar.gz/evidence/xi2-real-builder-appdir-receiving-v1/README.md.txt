# Actual driver and AppDir builder receiving

This separate private receiving follows the sealed minimal staging/export receipt.
No product/test/workflow, index, ref, or canonical path was changed. The original
private worktree `build/linux` was absent and not a symlink before execution, so
its built-in removal did not remove prior state.

The genuine driver builder ran without `--skip-smoke`: exit 0, actual CLI `--help`
passed, the real engine loaded and instantiated, and all 11 listed shared modules
loaded. The original archive C backend was compiled through its existing builder.
The AppImage builder then ran with only `--skip-appimage`: exit 0, 2353 production
payload files copied, all 11 required payload checks passed, original native
staging/network admission passed, and AppRun, launcher, desktop entry and icon
were assembled. The completed AppDir contains 2419 files.

The stamp is the real detached HEAD
`2c144060853239c9c416ea1a9c08030382ed2b1f`; the 14 dirty candidate source hashes are
recorded separately. No candidate commit SHA was fabricated. Both builders read
current production source bytes through their original tracked-file copy owners.
Actual ELF LuaJIT precedes the cloud wrappers; existing task-owned pkg-config
metadata is used without rewriting its declared system paths. The previous
receiving's APT download/extraction and metadata revision limitations still apply.

Commands, outer raw statuses, stdout/stderr hashes and all resulting build file
hashes are retained. Every candidate source image and HEAD stayed unchanged.
The outer generic subreaper is not independent full-family device proof; the
unchanged production stager retains its own subprocess/FD/closure ownership.

This is builder and assembly receiving only. AppRun was assembled, not launched;
appimagetool was explicitly not run. No AppImage image, package installation,
other-distribution receiving, X server, Display, device, cookie or input/output
qualification is claimed. Shared canonical admission remains pending.

Verify this evidence directory with `sha256sum --check files.sha256`. The large
actual output tree is retained in the private worktree and mapped byte-for-byte
by `after.json`; do not rerun the builder over an occupied output without explicit
ownership/retention review, because its original script removes that output tree.
