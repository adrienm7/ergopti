"""Actual POSIX query left live; Security/native settlement explicitly modeled."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys

P=Path(__file__).resolve().parent
source=P/'native_http_wire_fixture.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='6c37993b0895b169197748eb8812fcce8c1648f1824654e38519d95f92f5efe1'
spec=importlib.util.spec_from_file_location('canonical72_postinstall_closure',source);W=importlib.util.module_from_spec(spec);spec.loader.exec_module(W)
QUERY_IMAGE='EXPLICIT-PORTABLE-QUERY-IMAGE-NOT-A-NATIVE-EXECUTABLE'
RECEIPT={'version':1,'export_status':0,'entry_count':1,'owned_status':0,'owned_present':1}

class NativeProtocolModel:
 """All command bodies are actual portable children; no sudo/security runs."""
 def __init__(self):self.children=[];self.query_count=0;self.unsettled=None;self.security=[]
 def acquire_owned(self,arguments,native,register,**options):
  query=arguments==[QUERY_IMAGE,'--fixture-admin-trust-query']
  if query:
   self.query_count+=1;unsettled=self.query_count==1
   body='import time; time.sleep(60)' if unsettled else 'import sys,json; sys.stdin.buffer.read(); sys.stdout.write(json.dumps('+repr(RECEIPT)+'))'
  else:
   assert arguments[:3]==['/usr/bin/sudo','-n','/usr/bin/security']
   assert arguments[3] in ('add-trusted-cert','remove-trusted-cert')
   self.security.append(arguments[3]);unsettled=False;body='import sys; sys.stdin.buffer.read()'
  process=subprocess.Popen([sys.executable,'-I','-B','-c',body],start_new_session=True,**options)
  class Owner:
   reaped=False
   def __init__(self):self.process=process;self.settle_calls=0
   def wait_for_exit(self,timeout):
    if unsettled:raise subprocess.TimeoutExpired('EXPLICIT modeled postinstall query wait',timeout)
    self.process.wait(timeout=timeout)
   def settle(self):
    self.settle_calls+=1
    if unsettled:return False
    if self.process.poll() is None:self.process.terminate()
    self.process.wait(timeout=5);self.reaped=True;return True
  owned=Owner();self.children.append(owned)
  if unsettled:self.unsettled=owned
  register(owned);return owned

fixture=None;model=NativeProtocolModel();facts={};proved=False
try:
 fixture=W.WireFixture(native=False);root=fixture.root
 fixture.native=True;fixture.groups=model;fixture.native_groups=object();fixture.trust_query_executable=QUERY_IMAGE
 output,errors=io.StringIO(),io.StringIO();primary=None
 with contextlib.redirect_stdout(output),contextlib.redirect_stderr(errors):
  try:fixture.trust(True)
  except subprocess.TimeoutExpired as failure:primary=failure
 assert primary is not None,'Unsettled query did not preserve original timeout primary'
 assert fixture.command_fact['phase']=='settle' and fixture.trust_attempted
 assert fixture.command_file_debt==[] and model.unsettled.process.poll() is None
 facts={'version':1,'qualification':'REAL_POSIX_POSTINSTALL_QUERY_MODELED_SECURITY_NATIVE_PROTOCOL_ONLY','original_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'original_primary':'subprocess.TimeoutExpired','phase_before_close':fixture.command_fact['phase'],'trust_debt_before_close':fixture.trust_attempted,'capture_debt_before_close':len(fixture.command_file_debt),'unsettled_query_pid':model.unsettled.process.pid,'unsettled_query_settle_calls_before_close':model.unsettled.settle_calls,'child_live_before_close':True}
 with contextlib.redirect_stdout(output),contextlib.redirect_stderr(errors):fixture.close()
 facts.update({'fixture_closed_after_close':fixture.closed,'private_root_exists_after_close':root.exists(),'child_live_after_close':model.unsettled.process.poll() is None,'trust_debt_after_close':fixture.trust_attempted,'phase_after_close':fixture.command_fact['phase'],'unsettled_query_settle_calls_after_close':model.unsettled.settle_calls,'modeled_security_calls':model.security,'actual_portable_query_children':model.query_count})
 assert facts['fixture_closed_after_close'] and not facts['private_root_exists_after_close'] and facts['child_live_after_close']
 assert model.security==['add-trusted-cert','remove-trusted-cert'] and model.query_count==2
 proved=True
finally:
 for owned in model.children:
  child=owned.process
  if child.poll() is None:child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
  if child.stdin is not None and not child.stdin.closed:child.stdin.close()
 facts['outer_exact_children_reaped']=all(c.process.returncode is not None for c in model.children)
 if fixture is not None and not fixture.closed:
  fixture.native=False;fixture.groups=None;fixture.trust_attempted=False
  fixture.close()
assert proved and facts['outer_exact_children_reaped']
print(json.dumps(facts,sort_keys=True))
