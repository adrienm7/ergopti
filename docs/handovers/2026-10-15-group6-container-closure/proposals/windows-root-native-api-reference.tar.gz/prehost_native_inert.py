"""Private inert Node/PS native seam, not a provider or original23 enrollment.

The externally admitted top-level caller owns this module and its runtime.
Import defines types only. Root owns every actual native invocation/receiving.
"""

import ctypes as c
from ctypes import wintypes as w
import hashlib
import ntpath
import secrets
import subprocess
import sys
import time


class Startup(c.Structure):
    _fields_ = [('cb', w.DWORD), ('reserved', w.LPWSTR), ('desktop', w.LPWSTR),
                ('title', w.LPWSTR), ('x', w.DWORD), ('y', w.DWORD),
                ('width', w.DWORD), ('height', w.DWORD), ('xchars', w.DWORD),
                ('ychars', w.DWORD), ('fill', w.DWORD), ('flags', w.DWORD),
                ('show', w.WORD), ('reserved_size', w.WORD),
                ('reserved_data', c.POINTER(c.c_ubyte)), ('input', w.HANDLE),
                ('output', w.HANDLE), ('error', w.HANDLE)]


class StartupEx(c.Structure):
    _fields_ = [('startup', Startup), ('attributes', c.c_void_p)]


class ProcessInfo(c.Structure):
    _fields_ = [('process', w.HANDLE), ('thread', w.HANDLE),
                ('pid', w.DWORD), ('tid', w.DWORD)]


class FileInfo(c.Structure):
    _fields_ = [('attributes', w.DWORD), ('created', w.FILETIME),
                ('accessed', w.FILETIME), ('written', w.FILETIME),
                ('volume', w.DWORD), ('size_high', w.DWORD),
                ('size_low', w.DWORD), ('links', w.DWORD),
                ('index_high', w.DWORD), ('index_low', w.DWORD)]


class BasicLimit(c.Structure):
    _fields_ = [('process_time', c.c_int64), ('job_time', c.c_int64),
                ('flags', w.DWORD), ('minimum', c.c_size_t), ('maximum', c.c_size_t),
                ('active', w.DWORD), ('affinity', c.c_size_t),
                ('priority', w.DWORD), ('scheduling', w.DWORD)]


class IoCounters(c.Structure):
    _fields_ = [(name, c.c_uint64) for name in
                ('reads', 'writes', 'other', 'read_bytes', 'write_bytes', 'other_bytes')]


class ExtendedLimit(c.Structure):
    _fields_ = [('basic', BasicLimit), ('io', IoCounters),
                ('process_memory', c.c_size_t), ('job_memory', c.c_size_t),
                ('peak_process', c.c_size_t), ('peak_job', c.c_size_t)]


class Accounting(c.Structure):
    _fields_ = [(name, c.c_int64) for name in ('user', 'kernel', 'period_user', 'period_kernel')]
    _fields_ += [(name, w.DWORD) for name in ('faults', 'total', 'active', 'terminated')]


class Security(c.Structure):
    _fields_ = [('size', w.DWORD), ('descriptor', c.c_void_p), ('inherit', w.BOOL)]


class Overlapped(c.Structure):
    _fields_ = [('internal', c.c_size_t), ('internal_high', c.c_size_t),
                ('offset', w.DWORD), ('offset_high', w.DWORD), ('event', w.HANDLE)]


def absolute_file(value):
    """Refuse namespace aliases; native ancestor leases do the later admission."""
    if type(value) is not str or '\0' in value or '/' in value:
        raise ValueError('Explicit Windows path required')
    drive, tail = ntpath.splitdrive(value)
    if len(drive) != 2 or drive[1] != ':' or not tail.startswith('\\'):
        raise ValueError('Local absolute drive path required')
    if any(part in ('.', '..') or ':' in part or part.endswith((' ', '.'))
           for part in tail.split('\\')[1:] if part):
        raise ValueError('Aliased path component refused')
    if ntpath.normpath(value) != value:
        raise ValueError('Noncanonical path refused')
    return value


def environment_bytes(environment):
    if type(environment) is not dict or not environment:
        raise ValueError('Explicit inert environment required')
    seen = set()
    entries = []
    for name in sorted(environment):
        value = environment[name]
        if type(name) is not str or not name or '=' in name or '\0' in name:
            raise ValueError('Environment name refused')
        if type(value) is not str or '\0' in value or name.upper() in seen:
            raise ValueError('Environment value or duplicate refused')
        if name.upper().startswith(('NODE_', 'PYTHON', 'DOTNET_', 'COMPLUS_')):
            raise ValueError('Ambient preload configuration refused')
        seen.add(name.upper())
        entries.append(name + '=' + value)
    result = ('\0'.join(entries) + '\0\0').encode('utf-16le')
    if len(result) > 4194304:
        raise ValueError('Environment size refused')
    return result


class Native:
    """Typed Windows ABI only; this object grants no caller admission."""

    def __init__(self):
        if sys.platform != 'win32' or c.sizeof(w.HANDLE) != 8:
            raise RuntimeError('Only Windows x64 inert receiving is supported')
        if (c.sizeof(Startup), c.sizeof(StartupEx), c.sizeof(ProcessInfo),
                c.sizeof(ExtendedLimit), c.sizeof(Accounting), c.sizeof(Overlapped)) != (104, 112, 24, 144, 48, 32):
            raise RuntimeError('Native structure ABI refused')
        self.kernel = c.WinDLL('kernel32.dll', use_last_error=True)
        self.ntdll = c.WinDLL('ntdll.dll')
        definitions = {
            'CreateFileW': ([w.LPCWSTR, w.DWORD, w.DWORD, c.c_void_p, w.DWORD, w.DWORD, w.HANDLE], w.HANDLE),
            'GetFileInformationByHandle': ([w.HANDLE, c.POINTER(FileInfo)], w.BOOL),
            'GetFileType': ([w.HANDLE], w.DWORD),
            'GetFinalPathNameByHandleW': ([w.HANDLE, w.LPWSTR, w.DWORD, w.DWORD], w.DWORD),
            'ReadFile': ([w.HANDLE, c.c_void_p, w.DWORD, c.POINTER(w.DWORD), c.c_void_p], w.BOOL),
            'WriteFile': ([w.HANDLE, c.c_void_p, w.DWORD, c.POINTER(w.DWORD), c.c_void_p], w.BOOL),
            'CreateJobObjectW': ([c.c_void_p, w.LPCWSTR], w.HANDLE),
            'SetInformationJobObject': ([w.HANDLE, c.c_int, c.c_void_p, w.DWORD], w.BOOL),
            'QueryInformationJobObject': ([w.HANDLE, c.c_int, c.c_void_p, w.DWORD, c.c_void_p], w.BOOL),
            'AssignProcessToJobObject': ([w.HANDLE, w.HANDLE], w.BOOL),
            'TerminateJobObject': ([w.HANDLE, w.UINT], w.BOOL),
            'TerminateProcess': ([w.HANDLE, w.UINT], w.BOOL),
            'WaitForSingleObject': ([w.HANDLE, w.DWORD], w.DWORD),
            'GetExitCodeProcess': ([w.HANDLE, c.POINTER(w.DWORD)], w.BOOL),
            'ResumeThread': ([w.HANDLE], w.DWORD),
            'CloseHandle': ([w.HANDLE], w.BOOL),
            'CreateEventW': ([c.c_void_p, w.BOOL, w.BOOL, w.LPCWSTR], w.HANDLE),
            'CreateNamedPipeW': ([w.LPCWSTR, w.DWORD, w.DWORD, w.DWORD, w.DWORD, w.DWORD, w.DWORD, c.c_void_p], w.HANDLE),
            'ConnectNamedPipe': ([w.HANDLE, c.c_void_p], w.BOOL),
            'GetOverlappedResult': ([w.HANDLE, c.POINTER(Overlapped), c.POINTER(w.DWORD), w.BOOL], w.BOOL),
            'CancelIoEx': ([w.HANDLE, c.POINTER(Overlapped)], w.BOOL),
            'InitializeProcThreadAttributeList': ([c.c_void_p, w.DWORD, w.DWORD, c.POINTER(c.c_size_t)], w.BOOL),
            'UpdateProcThreadAttribute': ([c.c_void_p, w.DWORD, c.c_size_t, c.c_void_p, c.c_size_t, c.c_void_p, c.c_void_p], w.BOOL),
            'DeleteProcThreadAttributeList': ([c.c_void_p], None),
            'CreateProcessW': ([w.LPCWSTR, w.LPWSTR, c.c_void_p, c.c_void_p, w.BOOL, w.DWORD, c.c_void_p, w.LPCWSTR, c.POINTER(StartupEx), c.POINTER(ProcessInfo)], w.BOOL),
        }
        for name, (arguments, result) in definitions.items():
            function = getattr(self.kernel, name)
            function.argtypes, function.restype = arguments, result
            setattr(self, name, function)
        self.ImageMapping = self.ntdll.NtQueryInformationProcess
        self.ImageMapping.argtypes = [w.HANDLE, w.ULONG, c.c_void_p, w.ULONG, c.POINTER(w.ULONG)]
        self.ImageMapping.restype = c.c_int32

    @staticmethod
    def check(result, action):
        if not result:
            raise c.WinError(c.get_last_error(), action)
        return result

    def handle(self, value, action):
        if value in (None, 0, c.c_void_p(-1).value):
            raise c.WinError(c.get_last_error(), action)
        return value


class OwnedInertCase:
    """One-shot retained owner for inert fixtures only. Never production-qualified."""

    def __init__(self, directory, image, image_sha256, launch_image, launch_sha256, script, script_sha256,
                 role, environment, lifetime_ms=30000):
        if role not in ('node-inert', 'powershell-inert'):
            raise ValueError('No production role is implemented')
        if type(lifetime_ms) is not int or not 1 <= lifetime_ms <= 30000:
            raise ValueError('Inert lifetime bound refused')
        self.directory = absolute_file(directory)
        self.image_path = absolute_file(image)
        self.launch_path = absolute_file(launch_image)
        self.script_path = absolute_file(script)
        for digest in (image_sha256, launch_sha256, script_sha256):
            if type(digest) is not str or len(digest) != 64 or any(ch not in '0123456789abcdef' for ch in digest):
                raise ValueError('Expected SHA256 required')
        if not script.endswith(('.js', '.cjs') if role == 'node-inert' else '.ps1'):
            raise ValueError('Inert source extension refused')
        self.role, self.environment = role, environment_bytes(environment)
        self.expected_image, self.expected_launch, self.expected_script = image_sha256, launch_sha256, script_sha256
        self.deadline = time.monotonic() + lifetime_ms / 1000
        self.state, self.handles, self.directories = 'NEW', [], {}
        self.process = self.thread = self.job = self.image = self.server = None
        self.pending_io = []
        self.assigned = self.create_attempted = self.create_observed = False
        self.pi = ProcessInfo()
        self.attributes = self.crt = self.command = self.env_buffer = None
        self.attribute_initialized = False
        self.facts = {'scope': 'inert-native-capability', 'qualified': False,
                      'provider_qualified': False, 'native23_qualified': False,
                      'role': role, 'pid': None, 'resumed': False,
                      'terminal': False, 'job_zero': False, 'closed': False,
                      'timeout': False, 'deadline_exceeded': False,
                      'cancel_requested': False, 'forced_calls': [],
                      'io_cancel_calls': 0, 'io_ambiguous': False,
                      'retirement_ambiguous': False, 'natural_success': False}
        self.native = Native()

    def remaining(self):
        remaining = int((self.deadline - time.monotonic()) * 1000)
        if remaining <= 0:
            self.facts['timeout'] = True
            self.facts['deadline_exceeded'] = True
            raise TimeoutError('Inert capability deadline reached')
        return remaining

    def keep(self, handle, label):
        handle = self.native.handle(handle, label)
        self.handles.append({'handle': handle, 'label': label, 'closed': False, 'close_attempted': False})
        return handle

    def info(self, handle, directory=False):
        result = FileInfo()
        self.native.check(self.native.GetFileInformationByHandle(handle, c.byref(result)), 'file identity')
        if self.native.GetFileType(handle) != 1 or result.attributes & 0x400:
            raise ValueError('Disk/reparse identity refused')
        if bool(result.attributes & 0x10) != directory or (not directory and result.links != 1):
            raise ValueError('File kind/link identity refused')
        identity = {'volume': result.volume, 'index': (result.index_high << 32) | result.index_low,
                'size': (result.size_high << 32) | result.size_low,
                'written': (result.written.dwHighDateTime << 32) | result.written.dwLowDateTime}
        return {key: identity[key] for key in ('volume', 'index')} if directory else identity

    def named(self, handle, path):
        buffer = c.create_unicode_buffer(32768)
        count = self.native.GetFinalPathNameByHandleW(handle, buffer, len(buffer), 0)
        if not 0 < count < len(buffer):
            raise ValueError('Final acquired path refused')
        value = buffer.value
        if not value.startswith('\\\\?\\') or value[4:].casefold() != path.casefold():
            raise ValueError('Acquired namespace differs')

    def parents(self, path, include_directory=False):
        directory = path if include_directory else ntpath.dirname(path)
        drive, tail = ntpath.splitdrive(directory)
        current = drive + '\\'
        paths = [current]
        for part in tail.split('\\'):
            if part:
                current = ntpath.join(current, part)
                paths.append(current)
        for name in paths:
            if name.casefold() not in self.directories:
                handle = self.keep(self.native.CreateFileW(name, 0x100080, 3, None, 3, 0x02200000, None), 'ancestor')
                identity = self.info(handle, True)
                self.named(handle, name)
                self.directories[name.casefold()] = (handle, identity, name)
        for handle, identity, name in self.directories.values():
            if self.info(handle, True) != identity:
                raise ValueError('Ancestor identity changed')
            self.named(handle, name)

    def acquire(self, path, expected, image=False):
        self.parents(path)
        access = 0x80000000 | 0x100000 | (0x20 if image else 0)
        handle = self.keep(self.native.CreateFileW(path, access, 1, None, 3, 0x00200000, None), 'image' if image else 'source')
        before = self.info(handle)
        self.named(handle, path)
        maximum = 134217728 if image else 1048576
        if not 0 < before['size'] <= maximum:
            raise ValueError('Input byte bound refused')
        digest, total = hashlib.sha256(), 0
        buffer = c.create_string_buffer(65536)
        while True:
            self.remaining()
            count = w.DWORD()
            self.native.check(self.native.ReadFile(handle, buffer, len(buffer), c.byref(count), None), 'hash acquired input')
            if count.value > len(buffer):
                raise ValueError('Native read count refused')
            if count.value == 0:
                break
            total += count.value
            if total > before['size']:
                raise ValueError('Acquired input grew')
            digest.update(buffer.raw[:count.value])
        if total != before['size'] or self.info(handle) != before or digest.hexdigest() != expected:
            raise ValueError('Acquired source/image digest refused')
        return handle, before

    def overlapped(self):
        event = self.keep(self.native.CreateEventW(None, True, False, None), 'io-event')
        result = Overlapped()
        result.event = event
        return result

    def finish_io(self, operation, count, timeout_ms):
        status = self.native.WaitForSingleObject(operation.event, timeout_ms)
        if status != 0:
            self.facts['io_ambiguous'] = True
            if status == 258:
                self.facts['timeout'] = True
            raise TimeoutError('Owned pipe IO did not settle')
        ok = self.native.GetOverlappedResult(self.server, c.byref(operation), c.byref(count), False)
        error = c.get_last_error() if not ok else 0
        if not ok:
            self.facts['io_ambiguous'] = True
            if error in (109, 232, 995):
                self.pending_io.remove(operation)
            raise c.WinError(error, 'complete pipe IO')
        self.pending_io.remove(operation)

    def pipe_operation(self, write, data=None, count=0):
        self.remaining()
        operation = self.overlapped()
        buffer = c.create_string_buffer(data, len(data)) if write else c.create_string_buffer(count)
        received = w.DWORD()
        # Keep the buffer alive with the OVERLAPPED until completion or cancellation.
        operation.buffer = buffer
        self.pending_io.append(operation)
        function = self.native.WriteFile if write else self.native.ReadFile
        ok = function(self.server, buffer, len(buffer), c.byref(received), c.byref(operation))
        error = c.get_last_error() if not ok else 0
        if ok:
            self.pending_io.remove(operation)
        elif error == 997:
            self.finish_io(operation, received, self.remaining())
        else:
            self.facts['io_ambiguous'] = True
            self.pending_io.remove(operation)
            raise c.WinError(error, 'owned pipe IO')
        if not 0 < received.value <= len(buffer):
            self.facts['io_ambiguous'] = True
            self.close_one(operation.event)
            raise ValueError('Owned pipe byte count refused')
        self.close_one(operation.event)
        return received.value if write else buffer.raw[:received.value]

    def channel(self):
        name = '\\\\.\\pipe\\ergopti-prehost-inert-' + secrets.token_hex(16)
        self.server = self.keep(self.native.CreateNamedPipeW(name, 3 | 0x00080000 | 0x40000000,
                                                            0, 1, 4096, 4096, 0, None), 'parent-channel')
        security = Security(c.sizeof(Security), None, True)
        client = self.keep(self.native.CreateFileW(name, 0xc0000000, 0, c.byref(security), 3, 0, None), 'child-channel-copy')
        operation = self.overlapped()
        ok = self.native.ConnectNamedPipe(self.server, c.byref(operation))
        error = c.get_last_error() if not ok else 0
        if not ok and error == 997:
            self.pending_io.append(operation)
            received = w.DWORD()
            self.finish_io(operation, received, self.remaining())
        elif not ok and error != 535:
            self.close_one(operation.event)
            raise c.WinError(error, 'connect owned channel')
        self.close_one(operation.event)
        if self.native.GetFileType(client) != 3 or self.native.GetFileType(self.server) != 3:
            raise ValueError('Actual pipe type required')
        return client

    def start(self, resume=False):
        if self.state != 'NEW':
            raise RuntimeError('Duplicate or invalid initialization refused')
        self.state = 'PREPARING'
        try:
            self.parents(self.directory, True)
            self.image, self.image_identity = self.acquire(self.image_path, self.expected_image, True)
            if self.launch_path.casefold() == self.image_path.casefold() and self.expected_launch == self.expected_image:
                self.launch, self.launch_identity = self.image, self.image_identity
            else:
                self.launch, self.launch_identity = self.acquire(self.launch_path, self.expected_launch, True)
            self.source, self.source_identity = self.acquire(self.script_path, self.expected_script)
            self.facts['approved_image'] = {'sha256': self.expected_image, 'identity': self.image_identity}
            self.facts['created_image'] = {'sha256': self.expected_launch, 'identity': self.launch_identity}
            self.facts['source'] = {'sha256': self.expected_script, 'identity': self.source_identity}
            self.job = self.keep(self.native.CreateJobObjectW(None, None), 'job')
            limits = ExtendedLimit()
            limits.basic.flags = 0x2000
            self.native.check(self.native.SetInformationJobObject(self.job, 9, c.byref(limits), c.sizeof(limits)), 'no-breakaway job')
            security = Security(c.sizeof(Security), None, True)
            stdin = self.keep(self.native.CreateFileW('NUL', 0x80000000, 3, c.byref(security), 3, 0, None), 'stdin')
            if self.native.GetFileType(stdin) != 2:
                raise ValueError('NUL device required')
            stdout = self.keep(self.native.CreateFileW(ntpath.join(self.directory, 'stdout.bin'), 0xc0000000,
                                                     1, c.byref(security), 1, 0x00200000, None), 'stdout')
            stderr = self.keep(self.native.CreateFileW(ntpath.join(self.directory, 'stderr.bin'), 0xc0000000,
                                                     1, c.byref(security), 1, 0x00200000, None), 'stderr')
            if self.info(stdout)['size'] != 0 or self.info(stderr)['size'] != 0:
                raise ValueError('Fresh capture files required')
            client = self.channel()
            handles = (stdin, stdout, stderr, client)
            length = c.c_size_t()
            if self.native.InitializeProcThreadAttributeList(None, 1, 0, c.byref(length)) or c.get_last_error() != 122:
                raise ValueError('Attribute sizing refused')
            if not 0 < length.value <= 1048576:
                raise ValueError('Attribute size refused')
            self.attributes = c.create_string_buffer(length.value)
            self.native.check(self.native.InitializeProcThreadAttributeList(self.attributes, 1, 0, c.byref(length)), 'initialize attributes')
            self.attribute_initialized = True
            self.handle_array = (w.HANDLE * 4)(*handles)
            self.native.check(self.native.UpdateProcThreadAttribute(self.attributes, 0, 0x20002,
                                                                   self.handle_array, c.sizeof(self.handle_array), None, None), 'restrict four inherited handles')
            raw = (4).to_bytes(4, 'little') + bytes([0x41, 1, 1, 9])
            raw += b''.join(value.to_bytes(8, 'little') for value in handles)
            self.crt = (c.c_ubyte * len(raw)).from_buffer_copy(raw)
            startup = StartupEx()
            startup.startup.cb, startup.startup.flags = c.sizeof(startup), 0x101
            startup.startup.reserved_size = len(raw)
            startup.startup.reserved_data = c.cast(self.crt, c.POINTER(c.c_ubyte))
            startup.startup.input, startup.startup.output, startup.startup.error = handles[:3]
            startup.attributes = c.cast(self.attributes, c.c_void_p)
            arguments = ([self.launch_path, self.script_path] if self.role == 'node-inert' else
                         [self.launch_path, '-NoLogo', '-NoProfile', '-NonInteractive', '-File', self.script_path])
            self.command = c.create_unicode_buffer(subprocess.list2cmdline(arguments))
            self.env_buffer = c.create_string_buffer(self.environment, len(self.environment))
            self.remaining()
            self.create_attempted = True
            result = self.native.CreateProcessW(self.launch_path, self.command, None, None, True,
                                                0x08080404, self.env_buffer, self.directory,
                                                c.byref(startup), c.byref(self.pi))
            self.create_observed = True
            self.adopt_process()
            self.native.check(result, 'create suspended inert process')
            if self.process is None or self.thread is None:
                raise RuntimeError('Successful creation lacks retained handles')
            self.native.check(self.native.AssignProcessToJobObject(self.job, self.process), 'assign held suspended process')
            self.assigned = True
            supplied = w.HANDLE(self.image)
            status = self.native.ImageMapping(self.process, 44, c.byref(supplied), c.sizeof(supplied), None) & 0xffffffff
            self.facts['image_status_hex'] = f'{status:08x}'
            if status != 0:
                raise RuntimeError('Kernel image mapping refused before resume')
            if self.native.WaitForSingleObject(self.process, 0) != 258:
                raise RuntimeError('Created process not held live before resume')
            if (self.info(self.image) != self.image_identity or self.info(self.launch) != self.launch_identity
                    or self.info(self.source) != self.source_identity):
                raise RuntimeError('Leased input changed before resume')
            self.state = 'SUSPENDED'
            # Remove Parent's client copy after verified transfer, otherwise EOF lies.
            self.close_one(client)
            if resume:
                self.resume()
            return self.facts.copy()
        except BaseException:
            self.state = 'DEBT'
            raise

    def adopt_process(self):
        for field, label in (('process', 'process'), ('thread', 'thread')):
            value = getattr(self.pi, field)
            if value and getattr(self, field) is None:
                setattr(self, field, self.keep(value, label))
        if self.pi.pid:
            self.facts['pid'] = self.pi.pid

    def resume(self):
        if self.state != 'SUSPENDED':
            raise RuntimeError('Only an authenticated suspended case may resume')
        self.remaining()
        count = self.native.ResumeThread(self.thread)
        self.facts['resume_return'] = count
        if count != 1:
            self.facts['resumed'] = None
            self.state = 'DEBT'
            raise RuntimeError('Unexpected suspend count; retirement required')
        self.state = 'RESUMED'
        self.facts['resumed'] = True

    def exchange(self, payload):
        if self.state != 'RESUMED' or type(payload) is not bytes or not 1 <= len(payload) <= 4096:
            raise ValueError('One bounded inert byte payload required')
        frame = len(payload).to_bytes(4, 'little') + payload
        position = 0
        while position < len(frame):
            position += self.pipe_operation(True, frame[position:])
        response = bytearray()
        while len(response) < len(frame):
            response.extend(self.pipe_operation(False, count=len(frame) - len(response)))
        if bytes(response) != frame:
            raise ValueError('Raw fd3 echo differs')
        self.facts['transport_bytes'] = len(frame)
        self.facts['transport_sha256'] = hashlib.sha256(frame).hexdigest()
        return bytes(response)

    def close_one(self, handle):
        row = next(row for row in self.handles if row['handle'] == handle and not row['closed'])
        if row['close_attempted']:
            raise RuntimeError('Handle closure already refused')
        row['close_attempted'] = True
        self.native.check(self.native.CloseHandle(handle), 'close retained handle')
        row['closed'] = True

    def retire(self, cancel=False):
        if self.state == 'CLOSED':
            raise RuntimeError('Duplicate retirement refused')
        self.facts['natural_success'] = False
        self.facts['retirement_ambiguous'] = True
        self.facts['cancel_requested'] = cancel
        self.facts['deadline_exceeded'] = self.facts['deadline_exceeded'] or time.monotonic() >= self.deadline
        self.adopt_process()
        if self.create_attempted and not self.create_observed and self.process is None:
            self.facts['retirement_ambiguous'] = True
            self.state = 'DEBT'
            raise RuntimeError('Native creation outcome unknown; retain resources')
        self.facts['retirement_ambiguous'] = False
        try:
            if self.process is not None:
                status = self.native.WaitForSingleObject(self.process, 0)
                if status not in (0, 258):
                    raise RuntimeError('Retained process wait refused')
                if status == 258:
                    if not cancel and self.state == 'RESUMED':
                        budget = max(0, int((self.deadline - time.monotonic()) * 1000))
                        status = self.native.WaitForSingleObject(self.process, budget)
                        if status not in (0, 258):
                            raise RuntimeError('Natural retained wait refused')
                    if status == 258:
                        if not cancel and self.state == 'RESUMED':
                            self.facts['timeout'] = True
                        forced = {'operation': 'TerminateJobObject' if self.assigned else 'TerminateProcess',
                                  'reason': 'explicit-cancel' if cancel else
                                            ('natural-wait-timeout' if self.state == 'RESUMED' else 'unresumed-retirement'),
                                  'exit_code': 126, 'returned': None}
                        self.facts['forced_calls'].append(forced)
                        forced['returned'] = bool(self.native.TerminateJobObject(self.job, 126) if self.assigned else
                                                  self.native.TerminateProcess(self.process, 126))
                        self.native.check(forced['returned'], 'cancel exact retained actor')
                    if self.native.WaitForSingleObject(self.process, 10000) != 0:
                        raise RuntimeError('Retained process retirement unacknowledged')
                code = w.DWORD()
                self.native.check(self.native.GetExitCodeProcess(self.process, c.byref(code)), 'actual exit')
                self.facts['exit_code'] = code.value
            self.facts['terminal'] = True
            if self.job is not None:
                accounting = Accounting()
                deadline = time.monotonic() + 10
                while True:
                    self.native.check(self.native.QueryInformationJobObject(self.job, 1, c.byref(accounting), c.sizeof(accounting), None), 'actual job accounting')
                    if accounting.active == 0:
                        break
                    forced = {'operation': 'TerminateJobObject', 'reason': 'active-descendants',
                              'exit_code': 127, 'returned': None}
                    self.facts['forced_calls'].append(forced)
                    forced['returned'] = bool(self.native.TerminateJobObject(self.job, 127))
                    self.native.check(forced['returned'], 'cancel retained descendants')
                    if time.monotonic() >= deadline:
                        raise RuntimeError('Retained job still has actors')
                    time.sleep(0.01)
            self.facts['job_zero'] = True
            for operation in list(self.pending_io):
                self.facts['io_cancel_calls'] += 1
                if not self.native.CancelIoEx(self.server, c.byref(operation)) and c.get_last_error() != 1168:
                    raise RuntimeError('Owned IO cancellation refused')
                if self.native.WaitForSingleObject(operation.event, 10000) != 0:
                    raise RuntimeError('Owned IO cancellation unsettled')
                count = w.DWORD()
                ok = self.native.GetOverlappedResult(self.server, c.byref(operation), c.byref(count), False)
                if not ok and c.get_last_error() not in (109, 232, 995):
                    raise RuntimeError('Owned IO terminal refused')
                self.pending_io.remove(operation)
            if self.image is not None and self.info(self.image) != self.image_identity:
                raise RuntimeError('Image lease identity changed')
            if hasattr(self, 'launch') and self.info(self.launch) != self.launch_identity:
                raise RuntimeError('Created image lease identity changed')
            if hasattr(self, 'source') and self.info(self.source) != self.source_identity:
                raise RuntimeError('Source lease identity changed')
            self.state = 'RETIRED'
            if self.attribute_initialized:
                self.native.DeleteProcThreadAttributeList(self.attributes)
                self.attribute_initialized = False
            errors = []
            for row in reversed(self.handles):
                if not row['closed'] and not row['close_attempted']:
                    try:
                        self.close_one(row['handle'])
                    except BaseException as error:
                        errors.append(error)
            if errors or any(not row['closed'] for row in self.handles):
                raise RuntimeError('Native handle closure debt retained')
            self.state = 'CLOSED'
            self.facts['closed'] = True
            self.facts['deadline_exceeded'] = self.facts['deadline_exceeded'] or time.monotonic() >= self.deadline
            self.facts['natural_success'] = (
                self.facts['resumed'] is True and self.facts.get('exit_code') == 0 and
                self.facts['cancel_requested'] is False and self.facts['timeout'] is False and
                self.facts['deadline_exceeded'] is False and not self.facts['forced_calls'] and
                self.facts['io_cancel_calls'] == 0 and self.facts['io_ambiguous'] is False and
                self.facts['retirement_ambiguous'] is False)
            return self.facts.copy()
        except BaseException:
            self.facts['retirement_ambiguous'] = True
            self.facts['natural_success'] = False
            self.state = 'DEBT'
            raise

    def custody(self):
        """Failure snapshot only; values never establish physical retirement."""
        return {**self.facts, 'state': self.state,
                'outstanding_handles': [row['label'] for row in self.handles if not row['closed']],
                'pending_io': len(self.pending_io), 'creation_attempted': self.create_attempted,
                'creation_observed': self.create_observed}
