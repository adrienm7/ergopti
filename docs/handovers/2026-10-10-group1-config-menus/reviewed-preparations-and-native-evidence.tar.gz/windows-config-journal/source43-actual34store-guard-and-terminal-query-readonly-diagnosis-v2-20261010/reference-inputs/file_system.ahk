﻿; adapters/file_system.ahk

#Include %A_LineFile%\..\..\infra\file_read_activity.ahk

; ==============================================================================
; MODULE: FileSystem Adapter (AutoHotkey)
; DESCRIPTION:
; AHK v2 implementation of the FileSystem port contract defined in
; static/ergopti_plus/_shared/core/ports/FileSystem.spec.js. Wraps AHK v2's
; FileRead, FileOpen, FileExist, and FileDelete built-ins behind the five
; canonical functions (FSRead, FSWrite, FSAppend, FSExists, FSDelete) so
; domain modules perform file I/O without coupling to AHK-specific APIs.
;
; NAMING CONVENTION:
; Port method → AHK name mapping:
;   read(path)           → FSRead(Path)
;   write(path, content) → FSWrite(Path, Content)
;   append(path, content)→ FSAppend(Path, Content)
;   exists(path)         → FSExists(Path)
;   delete(path)         → FSDelete(Path)
;
; ENCODING:
; AHK v2 FileRead and FileOpen default to UTF-8 when the file has a BOM.
; FSRead and FSWrite explicitly pass the "UTF-8" encoding flag to FileOpen
; so all operations are UTF-8 regardless of the system ANSI code page.
; ==============================================================================




; =======================================================
; =======================================================
; ======= 1/ Adapter Methods ============================
; =======================================================
; =======================================================

; Reads UTF-8 text using AHK's BOM handling and preserves native read failures.
; @param Path {String} File path.
; @return {String} Text contents; throws when the read fails.
FSReadStrict(Path) {
	return FileRead(Path, "UTF-8")
}

; Reads a file's raw bytes and preserves native read failures.
; @param Path {String} File path.
; @return {Buffer} The bytes; throws when the read fails.
FSReadBytesStrict(Path) {
	return FileRead(Path, "RAW")
}

; Reads the entire contents of a file as a UTF-8 string.
; @param Path {String} Absolute path to the file.
; @return {String|false} File contents on success, false on any error.
FSRead(Path) {
	if !(Path is String) or Path = ""
		return false
	try {
		local FH := FileOpen(Path, "r", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		local Content := FH.Read()
		FH.Close()
		return Content
	} catch {
		return false
	}
}

; Writes content to a file, overwriting any existing content.
; Creates the file if it does not exist.
; @param Path    {String} Absolute path to the file.
; @param Content {String} UTF-8 content to write.
; @param OpenFn   {Func|0} Optional deterministic open seam for tests.
; @param DeleteFn {Func|0} Optional deterministic cleanup seam for tests.
; @param WriteFn  {Func|0} Optional native write seam for tests.
; @return {Boolean} True on success, false on error.
FSWrite(Path, Content, OpenFn := 0, DeleteFn := 0, WriteFn := 0) {
	ResolvedOpen := HasMethod(OpenFn, "Call") ? OpenFn : FileOpen
	ResolvedDelete := HasMethod(DeleteFn, "Call") ? DeleteFn : FileDelete
	return _FSWriteComplete(Path, Content, ResolvedOpen, ResolvedDelete, WriteFn)
}

; Owns a write from the first successful open through either a complete close or
; deletion of the partial artifact. OpenFn/DeleteFn make the short-write boundary
; deterministic in tests without weakening the public FileSystem port.
_FSWriteComplete(Path, Content, OpenFn, DeleteFn, WriteFn := 0) {
	if !(Path is String) or Path = ""
		return false
	if !(Content is String)
		Content := ""
	FH := 0
	Opened := false
	Succeeded := false
	try {
		FH := OpenFn.Call(Path, "w", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		Opened := true
		if !_FSWriteUtf8Bytes(FH, Content, WriteFn)
			return false
		FH.Close()
		FH := 0
		Succeeded := true
		return true
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
		if Opened && !Succeeded
			try DeleteFn.Call(Path)
	}
}

; Writes a complete control artifact and flushes its handle before returning.
; Atomic protocols still validate the stage and publish it with
; FSAtomicMoveReplace; this helper only makes the stage bytes durable.
FSWriteDurable(Path, Content, OpenFn := 0, DeleteFn := 0, FlushFn := 0, WriteFn := 0) {
	ResolvedOpen := HasMethod(OpenFn, "Call") ? OpenFn : FileOpen
	ResolvedDelete := HasMethod(DeleteFn, "Call") ? DeleteFn : FileDelete
	ResolvedFlush := HasMethod(FlushFn, "Call") ? FlushFn : FSFlushFileBuffers
	return _FSWriteDurableComplete(Path, Content, ResolvedOpen, ResolvedDelete,
		ResolvedFlush, WriteFn)
}

_FSWriteDurableComplete(Path, Content, OpenFn, DeleteFn, FlushFn, WriteFn := 0) {
	if !(Path is String) or Path = ""
		return false
	if !(Content is String)
		Content := ""
	FH := 0
	Opened := false
	Succeeded := false
	try {
		FH := OpenFn.Call(Path, "w", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		Opened := true
		if !_FSWriteUtf8Bytes(FH, Content, WriteFn)
			return false
		if FlushFn.Call(FH) != true
			throw Error("flush failed")
		FH.Close()
		FH := 0
		Succeeded := true
		return true
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
		if Opened && !Succeeded
			try DeleteFn.Call(Path)
	}
}

; Creates a private UTF-8 control artifact without ever replacing an existing
; path, then flushes its bytes before reporting success. ``FileOpen(..., "w")``
; cannot express CREATE_NEW and a probe followed by a write is a TOCTOU race,
; so the transaction journal uses this Windows-only helper outside the portable
; FileSystem port. A failed partial creation is removed only when this call
; actually created it; a collision is byte-preserving.
FSWriteCreateDurable(Path, Content) {
	if !(Path is String) or Path = "" or !(Content is String)
		return 0
	static GENERIC_WRITE := 0x40000000
	static CREATE_NEW := 1
	static FILE_ATTRIBUTE_NORMAL := 0x00000080
	static FILE_FLAG_WRITE_THROUGH := 0x80000000
	Handle := -1
	Created := false
	Succeeded := false
	try {
		Handle := DllCall("kernel32\CreateFileW",
			"Str", Path,
			"UInt", GENERIC_WRITE,
			"UInt", 0,
			"Ptr", 0,
			"UInt", CREATE_NEW,
			"UInt", FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH,
			"Ptr", 0,
			"Ptr")
		if (Handle == -1)
			return 0
		Created := true
		ByteCount := StrPut(Content, "UTF-8") - 1
		Utf8 := Buffer(ByteCount + 1, 0)
		if (ByteCount > 0)
			StrPut(Content, Utf8, ByteCount + 1, "UTF-8")
		Offset := 0
		while (Offset < ByteCount) {
			Written := 0
			if !DllCall("kernel32\WriteFile",
					"Ptr", Handle,
					"Ptr", Utf8.Ptr + Offset,
					"UInt", ByteCount - Offset,
					"UInt*", &Written,
					"Ptr", 0,
					"Int") or Written <= 0
				return 0
			Offset += Written
		}
		if !DllCall("kernel32\FlushFileBuffers", "Ptr", Handle, "Int")
			return 0
		Succeeded := true
		return 1
	} catch {
		return 0
	} finally {
		if (Handle != -1)
			try DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int")
		if Created && !Succeeded
			try DllCall("kernel32\DeleteFileW", "Str", Path, "Int")
	}
}

; Flushes one already-open writable file handle to stable storage. Callers use
; this before an atomic rename when the rename itself is a durable protocol
; boundary. The File object owns and closes the handle; this adapter only asks
; Windows to persist its buffered bytes.
FSFlushFileBuffers(FileObject) {
	if !IsObject(FileObject)
		return false
	try return DllCall("FlushFileBuffers", "Ptr", FileObject.Handle,
		"Int") != 0
	catch
		return false
}

; Appends content to a file, creating it if it does not exist.
; @param Path    {String} Absolute path to the file.
; @param Content {String} UTF-8 content to append.
; @return {Boolean} True on success, false on error.
FSAppend(Path, Content) {
	return _FSAppendComplete(Path, Content, FileOpen)
}

; Completes an append only when Windows accepts every encoded UTF-8 byte.
; Unlike an overwrite stage, a partially appended user file cannot be safely
; deleted or rolled back, so callers must receive failure and retain ownership.
_FSAppendComplete(Path, Content, OpenFn, WriteFn := 0) {
	if !(Path is String) or Path = ""
		return false
	if !(Content is String)
		Content := ""
	FH := 0
	try {
		FH := OpenFn.Call(Path, "a", "UTF-8-RAW")
		if !IsObject(FH)
			return false
		if !_FSWriteUtf8Bytes(FH, Content, WriteFn)
			return false
		FH.Close()
		FH := 0
		return true
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
	}
}

; Only use with a newly opened UTF-8 file, before any buffered text writes.
; Both File.Write and RawWrite buffer small blocks; Close and Handle discard
; buffer-flush failures. WriteFile checks the actual OS receipt instead. Keep
; this primitive logger-free so filesystem failures cannot recurse into logging.
_FSWriteUtf8Bytes(FileObject, Content, WriteFn := 0) {
	if FileObject.Encoding != "UTF-8"
		return false
	ByteCount := StrPut(Content, "UTF-8") - 1
	if ByteCount = 0
		return true
	Utf8 := Buffer(ByteCount + 1, 0)
	StrPut(Content, Utf8, ByteCount + 1, "UTF-8")
	Written := 0
	ResolvedWrite := HasMethod(WriteFn, "Call") ? WriteFn : _FSNativeWrite
	return ResolvedWrite.Call(FileObject.Handle, Utf8, ByteCount, &Written)
		&& Written = ByteCount
}

_FSNativeWrite(Handle, Bytes, ByteCount, &Written) {
	return DllCall("WriteFile", "Ptr", Handle, "Ptr", Bytes,
		"UInt", ByteCount, "UInt*", &Written, "Ptr", 0, "Int") != 0
}

; Returns true if a file or directory exists at the given path, false otherwise.
; @param Path {String} Absolute path to test.
; @return {Boolean} True on success, false on error.
FSExists(Path) {
	if !(Path is String) or Path = ""
		return false
	; FileExist returns a non-empty attribute string on match, "" on miss
	return FileExist(Path) != "" ? true : false
}

; Strict file existence for recovery protocols. Only the two Windows
; not-found statuses mean absence; access, device, or filesystem errors throw
; so recovery never mistakes "could not inspect" for "does not exist".
FSStrictExists(Path) {
	if !(Path is String) or Path = ""
		throw ValueError("A strict existence probe requires a non-empty path.")
	Attributes := DllCall("kernel32\GetFileAttributesW", "Str", Path, "UInt")
	if (Attributes != 0xFFFFFFFF)
		return 1
	ErrorCode := A_LastError
	if (ErrorCode == 2 || ErrorCode == 3)
		return 0
	throw OSError(ErrorCode, A_ThisFunc,
		"GetFileAttributesW failed for '" . Path . "'.")
}

/**
 * Enumerates one directory without treating access or device failures as absence.
 * @param {String} Path - Directory path; proven optional absence yields no entries.
 * @param {Integer} Directories - True selects directories, false regular entries.
 * @returns {Array} Absolute child paths; dot entries are excluded.
 */
FSListDirectoryStrict(Path, Directories := false) {
	if !FSStrictExists(Path)
		return []
	if !DirExist(Path)
		throw ValueError("Directory enumeration requires a directory.")
	Data := Buffer(592, 0)
	Handle := DllCall("kernel32\FindFirstFileW", "Str", RTrim(Path, "\/") . "\*", "Ptr", Data, "Ptr")
	if Handle == -1 {
		ErrorCode := A_LastError
		if ErrorCode == 2
			return []
		throw OSError(ErrorCode, A_ThisFunc, "Directory enumeration could not start.")
	}
	Entries := []
	try {
		loop {
			Name := StrGet(Data.Ptr + 44, 260, "UTF-16")
			IsDirectory := (NumGet(Data, 0, "UInt") & 0x10) != 0
			if Name != "." && Name != ".." && IsDirectory == !!Directories
				Entries.Push(RTrim(Path, "\/") . "\" . Name)
			if !DllCall("kernel32\FindNextFileW", "Ptr", Handle, "Ptr", Data, "Int") {
				ErrorCode := A_LastError
				if ErrorCode != 18
					throw OSError(ErrorCode, A_ThisFunc, "Directory enumeration did not complete.")
				break
			}
		}
	} finally {
		if !DllCall("kernel32\FindClose", "Ptr", Handle, "Int")
			throw OSError(A_LastError, A_ThisFunc, "Directory enumeration handle did not close.")
	}
	return Entries
}

/**
 * Resolves an existing directory to an absolute long path without recasing it.
 * @param {String} Path - Existing directory without wildcard characters.
 * @returns {String} Absolute long path; volume roots keep their final separator.
 * @throws {Error|OSError} Missing directories or incomplete native resolution.
 */
FSResolveDirectoryPath(Path) {
	if Path == "" || InStr(Path, "*") || InStr(Path, "?")
		throw Error("Startup working directory cannot be resolved")
	if !DirExist(Path)
		throw Error("Startup working directory does not exist")
	Size := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", 0, "Ptr", 0, "Ptr", 0, "UInt")
	if !Size
		throw OSError(A_LastError, A_ThisFunc)
	Full := Buffer(Size * 2)
	Written := DllCall("kernel32\GetFullPathNameW", "Str", Path, "UInt", Size,
		"Ptr", Full, "Ptr", 0, "UInt")
	if !Written || Written >= Size
		throw Error("Startup working directory resolution did not complete")
	Size := DllCall("kernel32\GetLongPathNameW", "Ptr", Full, "Ptr", 0, "UInt", 0, "UInt")
	if !Size
		throw OSError(A_LastError, A_ThisFunc)
	Long := Buffer(Size * 2)
	Written := DllCall("kernel32\GetLongPathNameW", "Ptr", Full, "Ptr", Long, "UInt", Size, "UInt")
	if !Written || Written >= Size
		throw Error("Startup working directory long-name resolution did not complete")
	Resolved := StrGet(Long)
	if RegExMatch(Resolved, "i)^[a-z]:\\$")
		return Resolved
	return RTrim(Resolved, "\")
}

; Creates one directory exclusively, without adopting existing paths or parents.
; @param Path {String} Non-empty directory path with an existing parent.
; @return {Boolean} True only after native exclusive creation succeeds.
; @throws {ValueError|OSError} Invalid paths and all native failures are explicit.
FSCreateDirectoryExclusiveStrict(Path) {
	if !(Path is String) || Path == ""
		throw ValueError("Exclusive directory creation requires a non-empty path.")
	Created := DllCall("kernel32\CreateDirectoryW", "WStr", Path, "Ptr", 0, "Int")
	ErrorCode := A_LastError
	if !Created
		throw OSError(ErrorCode, A_ThisFunc, Path)
	return true
}

; Creates a directory, and its missing parents, when it does not exist.
; @param Path {String} Absolute directory path.
; @return {Boolean} True when it was created, false when it already existed.
; @throws {Error} When it cannot be created.
FSEnsureDirectoryStrict(Path) {
	if !(Path is String) || Path == ""
		throw ValueError("A directory creation requires a non-empty path.")
	if DirExist(Path)
		return false
	DirCreate(Path)
	return true
}

; Deletes a file. Returns true if deleted or already absent, false on error.
; @param Path {String} Absolute path to the file to delete.
; @return {Boolean} True on success, false on error.
FSDelete(Path) {
	return _FSDeleteWith(Path, _FSDeleteNativeReceipt)
}

_FSDeleteNativeReceipt(Path) {
	; One native call distinguishes successful deletion, proven absence, and every
	; other failure without a FileExist/DeleteFile race or an ambiguous probe.
	Deleted := DllCall("kernel32\DeleteFileW", "Str", Path, "Int")
	ErrorCode := A_LastError
	return Map("deleted", Deleted != 0, "error", ErrorCode)
}

_FSDeleteWith(Path, DeleteFn) {
	if !(Path is String) or Path = ""
		return false
	try {
		Receipt := DeleteFn.Call(Path)
		if !(Receipt is Map)
			return false
		Deleted := Receipt.Get("deleted", false)
		if (Deleted is Integer) && Deleted == true
			return true
		ErrorCode := Receipt.Get("error", 0)
		if !(ErrorCode is Integer)
			return false
		return ErrorCode == 2 || ErrorCode == 3
	} catch {
		return false
	}
}

; Verify a stable read-only file before deleting that same object exclusively.
; The callback must return true only for an artifact owned by its caller.
; Sharing/identity failures retain the file for a later retry.
FSDeleteVerified(Path, VerifyFn) {
	Handle := DllCall("kernel32\CreateFileW", "Str", Path, "UInt", 0x80000000,
		"UInt", 1, "Ptr", 0, "UInt", 3, "UInt", 0x00200000, "Ptr", 0, "Ptr")
	if Handle = -1
		return false
	try {
		Info := Buffer(52, 0)
		if !DllCall("kernel32\GetFileInformationByHandle", "Ptr", Handle, "Ptr", Info, "Int")
				|| (NumGet(Info, 0, "UInt") & 0x410)
			return false
		Before := FSHandleSnapshot(Handle)
		if !Before.Get("ok", false) || !VerifyFn.Call(Path)
			return false
	} finally DllCall("kernel32\CloseHandle", "Ptr", Handle)
	; DELETE access and no sharing prevent any new connection or replacement
	; between the identity check and marking this handle for deletion.
	Handle := DllCall("kernel32\CreateFileW", "Str", Path, "UInt", 0x80010000,
		"UInt", 0, "Ptr", 0, "UInt", 3, "UInt", 0x00200000, "Ptr", 0, "Ptr")
	if Handle = -1
		return false
	try {
		After := FSHandleSnapshot(Handle)
		if !After.Get("ok", false)
			return false
		for Key in ["volume", "index_high", "index_low", "size", "write_high", "write_low"] {
			if Before[Key] != After[Key]
				return false
		}
		; FILE_DISPOSITION_INFO contains one BOOLEAN. Closing deletes the
		; verified object, whereas DeleteFileW after closing would race a rename.
		Disposition := Buffer(1, 1)
		return DllCall("kernel32\SetFileInformationByHandle", "Ptr", Handle,
			"Int", 4, "Ptr", Disposition, "UInt", 1, "Int") != 0
	} finally DllCall("kernel32\CloseHandle", "Ptr", Handle)
}

; Acquire a persistent guard file without sharing, truncation, or inheritance.
; Windows-only protocol helper, intentionally outside the portable port map.
; @param Path {String} Guard path in an existing owned directory.
; @returns {Integer} Owned handle, or 0 when unavailable or not an ordinary file.
FSOpenExclusiveGuard(Path) {
	if !(Path is String) || Path = ""
		throw ValueError("An exclusive guard requires a non-empty path.")
	Handle := DllCall("kernel32\CreateFileW", "Str", Path, "UInt", 0xC0000000,
		"UInt", 0, "Ptr", 0, "UInt", 4, "UInt", 0x00200080, "Ptr", 0, "Ptr")
	if Handle = -1
		return 0
	Info := Buffer(52, 0)
	if !DllCall("kernel32\GetFileInformationByHandle", "Ptr", Handle, "Ptr", Info, "Int")
			|| (NumGet(Info, 0, "UInt") & 0x410) {
		DllCall("kernel32\CloseHandle", "Ptr", Handle)
		return 0
	}
	return Handle
}

; Release exactly the acquired guard. Keep its pathname stable across owners.
; @param Handle {Integer} Owned guard returned by FSOpenExclusiveGuard.
; @returns {Boolean} Whether Windows released the native handle.
FSCloseExclusiveGuard(Handle) {
	return Handle && DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
}

; Idempotent strict deletion for recovery protocols. Unlike FSDelete, this
; does not route through FileExist (whose empty result conflates absence with
; an OS probe failure). Non-absence failures are surfaced to the journal.
FSDeleteStrict(Path) {
	if !(Path is String) or Path = ""
		throw ValueError("A strict delete requires a non-empty path.")
	Receipt := _FSDeleteNativeReceipt(Path)
	if Receipt["deleted"]
		return 1
	ErrorCode := Receipt["error"]
	if (ErrorCode == 2 || ErrorCode == 3)
		return 1
	throw OSError(ErrorCode, A_ThisFunc,
		"DeleteFileW failed for '" . Path . "'.")
}

; Returns the current byte length, or -1 when the path is absent/unreadable.
; Kept outside the portable port map for transactional file protocols that must
; validate an artifact without exposing AHK FileGetSize to domain modules.
FSSize(Path) {
	if !(Path is String) or Path = ""
		return -1
	try return FileGetSize(Path)
	catch
		return -1
}

; Reads a small control file only when its size is inside the explicit budget.
; This prevents a malformed sidecar from turning an early-boot capability check
; into an unbounded allocation.
FSReadBounded(Path, MaxBytes) {
	if !(Path is String) or Path = ""
		or !IsNumber(MaxBytes) or MaxBytes <= 0
		return false
	FH := 0
	try {
		FH := FileOpen(Path, "r", "UTF-8-RAW")
		if !IsObject(FH) or FH.Length > MaxBytes
			return false
		; Never issue an unbounded Read after the size probe. The same open handle
		; may grow concurrently; one extra character detects overflow while the
		; UTF-8 byte check preserves the contract for multibyte text.
		Content := FH.Read(MaxBytes + 1)
		if (FH.Pos < FH.Length
			or StrPut(Content, "UTF-8") - 1 > MaxBytes)
			return false
		return Content
	} catch {
		return false
	} finally {
		if IsObject(FH)
			try FH.Close()
	}
}

; Reads a transition target through Win32 without FileOpen's BOM skip. The WAL
; hashes exact UTF-8 byte images, so a leading EF BB BF must survive as U+FEFF
; and malformed/non-canonical UTF-8 must be refused rather than normalized to
; replacement characters. FILE_SHARE_READ excludes concurrent writers while
; the snapshot handle is open.
FSReadUtf8Exact(Path) {
	return _FSReadUtf8ExactImpl(Path, 0, false)
}

; Byte-faithful verification for staged UTF-8 control/source artifacts. The
; ordinary FSRead/FileRead path consumes a physical EF BB BF prefix, so comparing
; its String to a BOM-bearing expected payload produces a deterministic false
; mismatch even though the bytes on disk are correct.
FSUtf8ExactMatches(Path, Expected) {
	if !(Expected is String)
		return false
	Observed := FSReadUtf8Exact(Path)
	return (Observed is String) and Observed == Expected
}

FSReadUtf8ExactBounded(Path, MaxBytes) {
	if !(MaxBytes is Integer) || MaxBytes <= 0
		return false
	return _FSReadUtf8ExactImpl(Path, MaxBytes, true)
}

_FSReadUtf8ExactImpl(Path, MaxBytes, Bounded) {
	if !(Path is String) || Path == ""
		return false
	static GENERIC_READ := 0x80000000
	static FILE_SHARE_READ := 0x00000001
	static OPEN_EXISTING := 3
	static FILE_ATTRIBUTE_NORMAL := 0x00000080
	Handle := -1
	OpeningReturned := false
	Closed := false
	Content := false
	ReadActivity := FileReadActivityEnter(Path)
	try {
		Handle := DllCall("kernel32\CreateFileW",
			"Str", Path,
			"UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ,
			"Ptr", 0,
			"UInt", OPEN_EXISTING,
			"UInt", FILE_ATTRIBUTE_NORMAL,
			"Ptr", 0,
			"Ptr")
		OpeningReturned := true
		if Handle != -1 {
			FileReadActivityBind(ReadActivity, Handle)
			Content := _FSReadUtf8ExactHandle(Handle, MaxBytes, Bounded)
		}
	} catch {
		Content := false
	} finally {
		if Handle == -1 {
			; A returned failed opening owns no handle; a thrown acquisition stays debt.
			Closed := OpeningReturned
		} else {
			try Closed := DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
			catch {
				Closed := false
			}
		}
		if Closed
			FileReadActivityLeave(ReadActivity)
	}
	return Closed ? Content : false
}

/** Reads and validates the original UTF-8 bytes through one retained handle. */
_FSReadUtf8ExactHandle(Handle, MaxBytes, Bounded) {
	ByteCount := 0
	if !DllCall("kernel32\GetFileSizeEx", "Ptr", Handle,
			"Int64*", &ByteCount, "Int")
		return false
	if ByteCount < 0 || ByteCount > 0x7FFFFFFF
		return false
	if Bounded && ByteCount > MaxBytes
		return false
	Raw := Buffer(ByteCount > 0 ? ByteCount : 1, 0)
	Offset := 0
	while Offset < ByteCount {
		Chunk := Min(ByteCount - Offset, 0x7FFFF000)
		ReadCount := 0
		if !DllCall("kernel32\ReadFile",
				"Ptr", Handle,
				"Ptr", Raw.Ptr + Offset,
				"UInt", Chunk,
				"UInt*", &ReadCount,
				"Ptr", 0,
				"Int") || ReadCount <= 0
			return false
		Offset += ReadCount
	}
	FinalSize := 0
	if !DllCall("kernel32\GetFileSizeEx", "Ptr", Handle,
			"Int64*", &FinalSize, "Int") || FinalSize != ByteCount
		return false
	if ByteCount == 0
		return ""
	Content := StrGet(Raw.Ptr, ByteCount, "UTF-8")
	CanonicalCount := StrPut(Content, "UTF-8") - 1
	if CanonicalCount != ByteCount
		return false
	Canonical := Buffer(CanonicalCount + 1, 0)
	StrPut(Content, Canonical, CanonicalCount + 1, "UTF-8")
	MatchingBytes := DllCall("ntdll\RtlCompareMemory",
		"Ptr", Raw, "Ptr", Canonical, "UPtr", ByteCount, "UPtr")
	return MatchingBytes == ByteCount ? Content : false
}

; Admit only the target's HWND-sequence scratch format after its owner exits.
; A reused HWND conservatively retains debris instead of risking an active write.
; @param FileName {String} Candidate basename from the directory enumeration.
; @param TargetName {String} Exact basename of the writer's destination.
; @returns {Boolean} Whether the recognized producer window no longer exists.
FSAtomicTempOwnerIsGone(FileName, TargetName) {
	if TargetName = "" || StrCompare(SubStr(FileName, 1, StrLen(TargetName)), TargetName, true) != 0
		return false
	Suffix := SubStr(FileName, StrLen(TargetName) + 1)
	if !RegExMatch(Suffix, "^\.([1-9]\d{0,9})-[1-9]\d{0,18}\.tmp$", &Owner)
		return false
	Hwnd := Integer(Owner[1])
	return Hwnd <= 0xFFFFFFFF && !DllCall("User32\IsWindow", "Ptr", Hwnd, "Int")
}

; Publishes a complete same-directory stage with one write-through Win32 rename.
; Failure retains Source and leaves Destination untouched.
; NativeError reports the immediate Win32 error; zero also denotes unavailable
; native information on invalid arguments or a DllCall exception.
FSAtomicMoveReplace(Source, Destination, &NativeError := 0) {
	NativeError := 0
	if !(Source is String) or Source = ""
		or !(Destination is String) or Destination = ""
		return false
	static MOVEFILE_REPLACE_EXISTING := 0x00000001
	static MOVEFILE_WRITE_THROUGH := 0x00000008
	try {
		DllCall("kernel32\SetLastError", "UInt", 0)
		Moved := DllCall("MoveFileExW", "Str", Source, "Str", Destination,
			"UInt", MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH, "Int")
		NativeError := A_LastError
		return Moved != 0
	} catch Error {
		; No completed native receipt is available for a DllCall exception.
		NativeError := 0
		return false
	}
}

; Publishes Source only when Destination is still absent. Omitting
; MOVEFILE_REPLACE_EXISTING makes the directory-entry operation atomic and
; collision-preserving; WRITE_THROUGH makes the rename a durable boundary.
FSAtomicMoveCreate(Source, Destination) {
	if !(Source is String) or Source = ""
		or !(Destination is String) or Destination = ""
		return 0
	static MOVEFILE_WRITE_THROUGH := 0x00000008
	try return DllCall("kernel32\MoveFileExW", "Str", Source,
		"Str", Destination, "UInt", MOVEFILE_WRITE_THROUGH, "Int") ? 1 : 0
	catch
		return 0
}

; Atomically replaces Destination with Source when both are on the same volume.
; Kept in the adapter so domain modules never call FileMove directly.
FSMove(Source, Destination, Overwrite := false) {
        if !(Source is String) or Source = "" or !(Destination is String) or Destination = ""
                return false
        try {
                FileMove(Source, Destination, Overwrite)
                return true
        } catch {
                return false
        }
}

/** Open a BOM-aware UTF-8 reader; native refusal reaches the identity owner. */
FSOpenReadStrict(Path) {
	return FileOpen(Path, "r", "UTF-8")
}

; Opens a file for STREAMED reading and hands the handle back.
; FSRead loads a whole file; the at-rest migration walks data.sql, which can be
; hundreds of megabytes, and would have to hold all of it in memory to rewrite
; two columns of a few statements. The handle is UTF-8-RAW so a byte-exact
; passthrough is possible: the byte-order mark, if any, arrives as content and
; leaves as content instead of being stripped on one side and re-added on the
; other.
; @param Path {String} Absolute path to the file.
; @return {Object|String} An AHK file object, or "" on any error.
FSOpenRead(Path) {
	if !(Path is String) or Path = ""
		return ""
	try {
		local FH := FileOpen(Path, "r", "UTF-8-RAW")
		return IsObject(FH) ? FH : ""
	} catch {
		return ""
	}
}

; Opens a file for STREAMED writing, truncating any existing content.
; Counterpart of FSOpenRead; see its note on UTF-8-RAW.
; @param Path {String} Absolute path to the file.
; @return {Object|String} An AHK file object, or "" on any error.
FSOpenWrite(Path) {
	if !(Path is String) or Path = ""
		return ""
	try {
		local FH := FileOpen(Path, "w", "UTF-8-RAW")
		return IsObject(FH) ? FH : ""
	} catch {
		return ""
	}
}

; Returns stable identity, size and write-time metadata for an already-open file
; handle. This Windows-specific helper deliberately stays outside the canonical
; ADAPTER_FILE_SYSTEM port map; it is an implementation boundary used by the
; metrics reader to distinguish append, in-place repair and file replacement.
FSHandleSnapshot(FileHandle) {
	if !FileHandle
		return Map("ok", false)
	try {
		; BY_HANDLE_FILE_INFORMATION is a fixed 52-byte DWORD structure.
		static INFO_BYTES := 52
		local Info := Buffer(INFO_BYTES, 0)
		if !DllCall("kernel32\GetFileInformationByHandle",
			"Ptr", FileHandle,
			"Ptr", Info.Ptr,
			"Int")
			return Map("ok", false)
		return Map(
			"ok", true,
			"write_low", NumGet(Info, 20, "UInt"),
			"write_high", NumGet(Info, 24, "UInt"),
			"volume", NumGet(Info, 28, "UInt"),
			"size", (NumGet(Info, 32, "UInt") << 32)
				| NumGet(Info, 36, "UInt"),
			"index_high", NumGet(Info, 44, "UInt"),
			"index_low", NumGet(Info, 48, "UInt")
		)
	} catch {
		return Map("ok", false)
	}
}

; Reads an exact byte range together with the identity of the handle it came
; from, so a caller can prove the bytes belong to the file it expects. NUL bytes
; (an interrupted append's hole) are optionally blanked to spaces: UTF-8
; conversion stops at the first NUL. Windows-specific, outside the port map.
; @param Path {String} Absolute path to the file.
; @param Start {Integer} First byte offset.
; @param Count {Integer} Exact number of bytes to read.
; @param BlankNul {Boolean} Whether to replace every NUL byte with a space.
; @return {Map} ok, buffer, snapshot (FSHandleSnapshot), nul_bytes.
FSReadRange(Path, Start, Count, BlankNul := false) {
	local Buf := Buffer(Max(Count, 1), 0)
	local FH := FileOpen(Path, "r")
	if !IsObject(FH)
		return Map("ok", false)
	try {
		local Snapshot := FSHandleSnapshot(FH.Handle)
		FH.Pos := Start
		if Count > 0 && FH.RawRead(Buf, Count) != Count
			return Map("ok", false, "snapshot", Snapshot)
	} finally FH.Close()
	local Blanked := 0
	if BlankNul {
		local Cursor := Buf.Ptr
		local Stop := Buf.Ptr + Count
		while Cursor < Stop {
			local Hit := DllCall("msvcrt\memchr", "Ptr", Cursor, "Int", 0, "UPtr", Stop - Cursor, "Cdecl Ptr")
			if !Hit
				break
			NumPut("UChar", 0x20, Hit)
			Blanked += 1
			Cursor := Hit + 1
		}
	}
	return Map("ok", true, "buffer", Buf, "snapshot", Snapshot, "nul_bytes", Blanked)
}

; Copies a file byte for byte to a path that must not exist yet, then checks
; the copy reads back as its source. The configuration backup's copies.
; @param Source {String} File to copy.
; @param Destination {String} New path; an existing one is never replaced.
; @return {Boolean} True only for a complete, verified copy; a mismatched copy
;   is removed.
FSCopyCreateVerified(Source, Destination) {
	if !(Source is String) || Source == "" || !(Destination is String) || Destination == ""
		return false
	try FileCopy(Source, Destination, false)
	catch
		return false
	if FSSameBytes(Source, Destination)
		return true
	try FileDelete(Destination)
	return false
}

; Whether two files hold exactly the same bytes.
; @param PathA {String}
; @param PathB {String}
; @return {Boolean} False when either cannot be read.
FSSameBytes(PathA, PathB) {
	try {
		A := FileRead(PathA, "RAW")
		B := FileRead(PathB, "RAW")
	} catch {
		return false
	}
	if (A.Size != B.Size)
		return false
	if (A.Size == 0)
		return true
	return DllCall("ntdll\RtlCompareMemory", "Ptr", A, "Ptr", B, "UPtr", A.Size, "UPtr") == A.Size
}

; Replaces a file by the bytes of another through a verified same-directory
; stage and one atomic rename; a failure leaves the destination as it was.
; @param Source {String} File whose bytes are published.
; @param Destination {String} File replaced (or created).
; @return {Boolean}
FSCopyReplaceAtomic(Source, Destination) {
	if !(Source is String) || Source == "" || !(Destination is String) || Destination == ""
		return false
	Stage := Destination . ".ergopti-restore.tmp"
	try FileCopy(Source, Stage, true)
	catch
		return false
	if FSSameBytes(Source, Stage) && FSAtomicMoveReplace(Stage, Destination)
		return true
	try FileDelete(Stage)
	return false
}

; Whether a path is a reparse point (a symbolic link or a junction), which a
; folder walk never follows: it can lead back up the tree.
; @param Path {String}
; @return {Boolean}
FSIsReparsePoint(Path) {
	return InStr(FileExist(Path), "L") > 0
}

; Machine-readable contract map - consumed by the generic adapter compliance test
; (tests/test_adapter_compliance_new.ahk) to verify every required method exists
; and is callable without manually listing functions per-adapter.
global ADAPTER_FILE_SYSTEM := Map(
    "read",   FSRead,
    "write",  FSWrite,
    "append", FSAppend,
    "exists", FSExists,
    "delete", FSDelete,
)


/** Configuration-only byte receipt; native opening errors never grant write authority. */
FSConfigReadUtf8Exact(Path, &NativeOpenError := 0) {
	static OriginalRead := FSReadUtf8Exact, HandleRead := _FSReadUtf8ExactHandle
	static Enter := FileReadActivityEnter, Bind := FileReadActivityBind, Leave := FileReadActivityLeave
	NativeOpenError := 0
	if OriginalRead != FSReadUtf8Exact || HandleRead != _FSReadUtf8ExactHandle
			|| Enter != FileReadActivityEnter || Bind != FileReadActivityBind || Leave != FileReadActivityLeave
		return false
	if !(Path is String) || Path == ""
		return false
	static GENERIC_READ := 0x80000000
	static FILE_SHARE_READ := 0x00000001
	static OPEN_EXISTING := 3
	static FILE_ATTRIBUTE_NORMAL := 0x00000080
	Handle := -1
	OpeningReturned := false
	Closed := false
	Content := false
	for Owner in [OriginalRead, HandleRead, Enter, Bind, Leave]
		if Object.Prototype.HasOwnProp.Call(Owner, "Call")
			return false
	ReadActivity := Enter.Call(Path)
	try {
		Handle := DllCall("kernel32\CreateFileW",
			"Str", Path,
			"UInt", GENERIC_READ,
			"UInt", FILE_SHARE_READ,
			"Ptr", 0,
			"UInt", OPEN_EXISTING,
			"UInt", FILE_ATTRIBUTE_NORMAL,
			"Ptr", 0,
			"Ptr")
		OpeningReturned := true
		if Handle == -1
			NativeOpenError := A_LastError ; Capture the actual failed CreateFileW before cleanup.
		if Handle != -1 {
			if OriginalRead != FSReadUtf8Exact || HandleRead != _FSReadUtf8ExactHandle
					|| Enter != FileReadActivityEnter || Bind != FileReadActivityBind || Leave != FileReadActivityLeave
				return false
			for Owner in [OriginalRead, HandleRead, Enter, Bind, Leave]
				if Object.Prototype.HasOwnProp.Call(Owner, "Call")
					return false
			Bind.Call(ReadActivity, Handle)
			Content := HandleRead.Call(Handle, 0, false)
		}
	} catch {
		Content := false
	} finally {
		if Handle == -1 {
			; A returned failed opening owns no handle; a thrown acquisition stays debt.
			Closed := OpeningReturned
		} else {
			try Closed := DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int") != 0
			catch {
				Closed := false
			}
		}
		if Closed
			Leave.Call(ReadActivity)
	}
	return Closed ? Content : false
}

; Pure logical admission is consumed only within a configuration native span.
_FSNativeAdmissionAccepted(AdmissionFn) {
	if (AdmissionFn is Integer) && AdmissionFn == 0
		return true
	if !HasMethod(AdmissionFn, "Call")
		return false
	try {
		Accepted := AdmissionFn.Call()
		return (Accepted is Integer) && Accepted == 1
	} catch {
		return false
	}
}

/** Consumes captured unchanged-source admission within the configuration span. */
FSNativeAcknowledge(AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		Accepted := Accept == _FSNativeAdmissionAccepted && Accept.Call(AdmissionFn)
		return Accepted && Accept == _FSNativeAdmissionAccepted
			&& !Object.Prototype.HasOwnProp.Call(Accept, "Call")
	}
	finally Critical(PreviousCritical)
}

/** Configuration replacement through the retained genuine write-through producer. */
FSConfigAtomicMoveReplace(Source, Destination, &NativeError := 0, AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	static Move := FSAtomicMoveReplace
	NativeError := 0
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		if Move != FSAtomicMoveReplace || Accept != _FSNativeAdmissionAccepted || !Accept.Call(AdmissionFn)
				|| Accept != _FSNativeAdmissionAccepted
				|| Move != FSAtomicMoveReplace {
			; No native operation ran, so no Win32 error receipt is invented.
			return false
		}
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return Move.Call(Source, Destination, &NativeError)
	} finally Critical(PreviousCritical)
}

/** Configuration-only no-replace publication keeps the existing producer receipt. */
FSConfigAtomicMoveCreate(Source, Destination, AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	static Move := FSAtomicMoveCreate
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		if Move != FSAtomicMoveCreate || Accept != _FSNativeAdmissionAccepted || !Accept.Call(AdmissionFn)
				|| Accept != _FSNativeAdmissionAccepted
				|| Move != FSAtomicMoveCreate
			return 0
		for Owner in [Accept, Move]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return Move.Call(Source, Destination)
	} finally Critical(PreviousCritical)
}

/** Configuration-owned recovery removal retains the original strict delete receipt. */
FSConfigDeleteStrict(Path, AdmissionFn := 0) {
	static Accept := _FSNativeAdmissionAccepted
	static Delete := FSDeleteStrict, Receipt := _FSDeleteNativeReceipt
	static DeleteWith := _FSDeleteWith, Exists := FSStrictExists
	PreviousCritical := Critical("On")
	try {
		for Owner in [Accept, Delete, Receipt, DeleteWith, Exists]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		if Delete != FSDeleteStrict || Receipt != _FSDeleteNativeReceipt
				|| DeleteWith != _FSDeleteWith || Exists != FSStrictExists
				|| Accept != _FSNativeAdmissionAccepted || !Accept.Call(AdmissionFn)
				|| Accept != _FSNativeAdmissionAccepted
				|| Delete != FSDeleteStrict || Receipt != _FSDeleteNativeReceipt
				|| DeleteWith != _FSDeleteWith || Exists != FSStrictExists
			return 0
		for Owner in [Accept, Delete, Receipt, DeleteWith, Exists]
			if Object.Prototype.HasOwnProp.Call(Owner, "Call")
				return false
		return Delete.Call(Path)
	} finally Critical(PreviousCritical)
}
