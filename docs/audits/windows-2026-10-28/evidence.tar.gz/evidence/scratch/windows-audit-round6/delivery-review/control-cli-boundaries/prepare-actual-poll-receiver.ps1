param([Parameter(Mandatory)][string]$Source,[Parameter(Mandatory)][string]$Destination)
$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($Source,[ref]$tokens,[ref]$errors)
if ($errors.Count -ne 0){throw 'Actual control CLI failed parsing.'}
$definitions=@($ast.EndBlock.Statements|Where-Object{$_ -is [Management.Automation.Language.FunctionDefinitionAst]})
if ($definitions.Count -lt 1){throw 'The actual CLI functions are absent.'}
$statements=@($ast.EndBlock.Statements)
$starts=@(for($i=0;$i -lt $statements.Count;$i++){
 $s=$statements[$i]
 if($s -is [Management.Automation.Language.AssignmentStatementAst] -and $s.Left -is [Management.Automation.Language.VariableExpressionAst] -and $s.Left.VariablePath.UserPath -ceq 'resultPath'){$i}
})
if($starts.Count -ne 1){throw 'The actual public result receiver is not unique.'}
$prelude=@'
param([string]$Folder,[string]$SpecPath,[string]$RequestId,[int]$DriverPid=4000,[int]$TimeoutMs=1000)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$folder=$Folder
$spec=Get-Content -Raw -Encoding UTF8 -LiteralPath $SpecPath|ConvertFrom-Json
$requestId=$RequestId
$driverPid=$DriverPid
'@
$body=$prelude+"`n"+(($definitions|ForEach-Object{$_.Extent.Text})-join "`n")+"`n"+(($statements[$starts[0]..($statements.Count-1)]|ForEach-Object{$_.Extent.Text})-join "`n")+"`n"
[IO.File]::WriteAllText($Destination,$body,[Text.UTF8Encoding]::new($false))
