local packet=assert(arg[1])
local root='/workspace/ergopti/static/ergopti_plus'
local baseline='/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v1'
package.path=packet..'/candidate/static/ergopti_plus/linux/?.lua;'..packet..'/candidate/static/ergopti_plus/linux/?/init.lua;'
 ..baseline..'/candidate/static/ergopti_plus/linux/?.lua;'..baseline..'/candidate/static/ergopti_plus/linux/?/init.lua;'
 ..baseline..'/generator-context/static/ergopti_plus/linux/?.lua;'
 ..root..'/linux/?.lua;'..root..'/linux/?/init.lua;'
 ..baseline..'/candidate/static/ergopti_plus/_shared/lua/?.lua;'..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
if arg[3] then
 -- Closed counterfactual file overlay: only these two exact module paths may
 -- differ. Keep their real logical loader coordinates so a source-role refusal
 -- cannot substitute for the specific omitted predicate being tested.
 local directory=arg[3]
 local searchers=package.searchers or package.loaders
 local original_searcher=searchers[2]
 local allowed={["modules.shortcuts.key_combinations"]=true,["platform.remap.tap_hold_manager"]=true}
 searchers[2]=function(name)
  if allowed[name] then
   local relative=name:gsub("%.","/")..".lua"
   local file=io.open(directory.."/"..relative,"rb")
   if file then
    local bytes=assert(file:read("*a"));assert(file:close())
    local label="@"..packet.."/candidate/static/ergopti_plus/linux/"..relative
    local compile=loadstring or load
    return assert(compile(bytes,label)),label:sub(2)
   end
  end
  return original_searcher(name)
 end
end
require('compat.utf8').install()
local native_loop=require('luv')
local paths=require('infra.paths');local shared=paths.shared
paths.shared=function(relative)
 if relative=='modules/menu/menu_manifest.json' then return baseline..'/generator-context/static/ergopti_plus/_shared/'..relative end
 return shared(relative)
end
local modules={arg[2] or 'tests.unit.modules.test_key_combinations'}
for _,name in ipairs(modules) do require(name) end
local results=require('tests.helpers').get_results()
assert(require('luv')==native_loop)
print('PUBLIC_JOIN_CONTROLLED '..results.passed..'/'..results.failed)
os.exit(results.failed>0 and 1 or 0)
