# Genuine personal-info output-field refusal coordinate successor

The actual full JS run retained a strict uniqueness failure in the personal-info
negative control: Linux now has two raw disabled reads, one in its new About
header and the original in its personal editor receiving row. macOS has one.
This one-file Source successor targets each driver's full genuine personal-info
refusal expression, including the real adjacent native condition.

Only the before/after tuple changes to explicit hs/Linux literal coordinates.
Both after-values retain the exact native expression and replace only the
`disabled` field with `foreign_disabled`, preserving the original negative
mutation. No native owner, production matcher, assertion, reason or other
control changes. All 1048 original assert-dot lines remain byte-identical;
reversing this tuple recreates the complete exact current test preimage.

The complete original same-section census covers all 60 control tuples: 53
macOS and 60 Linux before-image checks, including seven Linux-only controls.
Static counts find only this one ambiguous preimage. After this narrow repair,
all 113 genuine native coordinates occur exactly once in their actual pinned
provider. This source-count evidence does not prove classifier behavior.

The parent-owned full JS failure log is pinned in SOURCE-ONLY-PROPOSAL.json.
All chronology and the earlier source-only packets remain untouched. Context
files are immutable read-only evidence, not receiving edits. Runtime, formatter,
generators and all gates are UNRUN by this child; Root owns actual whole-target
execution before repeating the complete selected gates.
