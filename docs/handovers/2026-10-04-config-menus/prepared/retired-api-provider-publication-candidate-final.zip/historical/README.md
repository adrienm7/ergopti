# Retired API-provider preparation

This is a read-only dependency handoff, not an integrated correction or a qualified candidate. The actual native catalogue seams remain owned by feat/ai. Parent explicitly paused edits there until ownership is released/serialized. TODO33 remains open.

Exact featuref49a0b145 preimages are saved in preimages/ with SHA256 and current-checkout equality in preimages.json. Causal real-file LuaJIT probe and two independent expected-behavior failures are retained. See ergopti-todo33-next-regression.md for actual source ownership, Mac behavior already implemented, the explicit published cloud+local eligibility port proposal, preservation requirements, and the stale Linux navigation boot TODO wording.

Never infer retirement from an empty/unavailable/unpublished catalogue; this packet contains no guessed availability receipt or runtime change. Actual native publication, full tests, E2E, packaging, hardware and CI are not executed. Only real private API-store source IO/libc publication and actual shipped provider lookup were exercised; no network call occurred.
