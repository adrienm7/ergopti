# producer/test_ollama_intake_source.ps1
# Recording controls use the actual worker/library source; no kernel owner is
# created. The independent receiver must qualify native release and file identity.
[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$SourceRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
$producerDirectory = [IO.Path]::Combine($SourceRoot, 'native', 'ollama_guardian', 'producer')
$workerPath = [IO.Path]::Combine($producerDirectory, 'ollama_source_worker.ps1')
$filesPath = [IO.Path]::Combine($producerDirectory, 'ollama_managed_files.ps1')
$producerPath = [IO.Path]::Combine($producerDirectory, 'ollama_source_producer.ps1')
$workerText = [IO.File]::ReadAllText($workerPath, [Text.UTF8Encoding]::new($false, $true))
$argumentMatch = [regex]::Matches($workerText, '(?ms)\$sourceLibraryArguments = @\{[^}]+\}')
if ($argumentMatch.Count -ne 1) { throw 'The actual worker library argument owner is not unique.' }

function Assert-IntakeModel([bool]$Value, [string]$Reason) {
	if (-not $Value) { throw $Reason }
}
function Test-WorkerDotSource {
	$StageIdentity = '12345678:0000000000000001'
	$CataloguePath = 'C:\synthetic\retained-catalogue.json'
	$AssetId = 'windows-amd64'
	$MaxExpandedBytes = [long]2147483648
	$MaxEntries = 123
	$actualArguments = $argumentMatch[0].Value
	Invoke-Expression $actualArguments
	. $filesPath @sourceLibraryArguments
	Assert-IntakeModel ($StageIdentity -ceq '12345678:0000000000000001') 'The actual library lost the captured stage identity.'
	Assert-IntakeModel ($CataloguePath -ceq 'C:\synthetic\retained-catalogue.json') 'The actual library lost the captured catalogue path.'
	Assert-IntakeModel ($AssetId -ceq 'windows-amd64') 'The actual library lost the captured asset.'
	Assert-IntakeModel ($MaxExpandedBytes -eq [long]2147483648) 'The actual library lost the captured expanded-byte budget.'
	Assert-IntakeModel ($MaxEntries -eq 123) 'The actual library lost the captured entry budget.'
}

# Full real producer definitions are loaded. Only the three downstream ports of
# Prepare-OllamaIntakeAfterNativeSeal below are controlled in these two models.
. $producerPath
$script:intakeReadCalls = 0
$script:intakePrepareCalls = 0
$script:intakeWait = 0
$script:intakeHeldRelease = [ordered]@{ stream = [object]::new(); version = '0.24.0'; pin = [object]::new() }
function Wait-OllamaSourceHandoff([string]$Id, [IntPtr]$Release, [IntPtr]$Parent) {
	Assert-IntakeModel ($Id -ceq 'recording-owner') 'The handoff lost its exact source owner.'
	Assert-IntakeModel ($Release -eq [IntPtr]::new(1) -and $Parent -eq [IntPtr]::new(2)) 'The handoff changed its controlled tuple.'
	return $script:intakeWait
}
function Read-OllamaHeldReleaseArchive($Source, [string]$Asset, [string]$Archive,
	[long]$ExpandedBudget, [int]$EntryBudget, [string]$ExpectedCatalogueHash, [bool]$RetireArchive) {
	++$script:intakeReadCalls
	Assert-IntakeModel ([object]::ReferenceEquals($Source, $script:intakeHeldRelease)) 'Preparation reopened or replaced its retained release owner.'
	Assert-IntakeModel ($Asset -ceq 'windows-amd64' -and $ExpandedBudget -eq 1000 -and $EntryBudget -eq 10) 'The captured archive policy changed.'
	Assert-IntakeModel ($RetireArchive -and $Archive -ceq 'C:\synthetic\.intake-recording\archive.zip') 'The retained archive/cleanup target changed.'
	return [ordered]@{ source = $Source }
}
function Prepare-OllamaManagedStage($Root, $Archive, [string]$Ticket) {
	++$script:intakePrepareCalls
	Assert-IntakeModel ([object]::ReferenceEquals($Archive.source, $script:intakeHeldRelease)) 'Stage preparation did not receive that same archive owner.'
	Assert-IntakeModel ($Ticket -ceq '0123456789abcdef0123456789abcdef') 'Stage preparation changed the closed ticket.'
	return [ordered]@{ phase = 'prepared'; ticket = $Ticket }
}
function New-IntakeModelRow {
	$script:OIA_Rows = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal)
	$script:OIA_Rows.Add('recording-owner', [ordered]@{ phase = 'offered'; offer = 'recording-owner';
		release = $script:intakeHeldRelease; asset = 'windows-amd64'; directory_path = 'C:\synthetic\.intake-recording';
		expanded_budget = 1000; entry_budget = 10; catalogue_hash = ('0' * 64); root = [object]::new();
		ticket = '0123456789abcdef0123456789abcdef'; archive = $null; prepared = $null })
}
[Console]::Out.WriteLine('1..3')
try {
	Test-WorkerDotSource
	[Console]::Out.WriteLine('ok 1 - actual worker preserves all five overlapping library parameters')
	New-IntakeModelRow
	$script:intakeWait = 1
	$refused = $false
	try { [void](Prepare-OllamaIntakeAfterNativeSeal 'recording-owner' ([IntPtr]::new(1)) ([IntPtr]::new(2))) }
	catch { $refused = $_.Exception.Message -ceq 'Parent retirement cannot authorize archive preparation.' }
	Assert-IntakeModel ($refused -and $script:intakeReadCalls -eq 0 -and $script:intakePrepareCalls -eq 0) 'Parent death authorized archive work.'
	[Console]::Out.WriteLine('ok 2 - parent terminal cannot authorize archive preparation')
	New-IntakeModelRow
	$script:intakeWait = 0
	$prepared = Prepare-OllamaIntakeAfterNativeSeal 'recording-owner' ([IntPtr]::new(1)) ([IntPtr]::new(2))
	Assert-IntakeModel ($prepared.phase -ceq 'prepared' -and $script:intakeReadCalls -eq 1 -and $script:intakePrepareCalls -eq 1) 'The exact modeled seal did not perform one same-owner preparation.'
	[Console]::Out.WriteLine('ok 3 - actual preparation carries the same retained release into its reader')
} catch {
	[Console]::Error.WriteLine($_.Exception.Message)
	exit 1
}
exit 0
