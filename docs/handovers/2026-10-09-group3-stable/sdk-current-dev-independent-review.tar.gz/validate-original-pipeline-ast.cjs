'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const parser = require('/workspace/ergopti/node_modules/@babel/parser');
const relative = 'tools/test/test-ci-pipeline-wiring.cjs';
const name = 'Observe the actual no-prompt SDK permission API independently';
const parse = (part) => parser.parse(fs.readFileSync(path.join(__dirname,part,relative),'utf8'),{sourceType:'script'}).program;
const before = parse('preimages'), after = parse('candidate');
const clean = (value) => {
 if (Array.isArray(value)) return value.map(clean);
 if (!value || typeof value !== 'object') return value;
 const output = {};
 for (const [key,item] of Object.entries(value)) if (!['start','end','loc','extra','leadingComments','trailingComments','innerComments','comments','tokens'].includes(key)) output[key] = clean(item);
 return output;
};
let tuple = 0, check = 0, inverses = 0;
const map = after.body.find((node) => node.type === 'VariableDeclaration' && node.declarations[0].id.name === 'MACOS_NATIVE_STEP_CONDITIONS');
map.declarations[0].init.elements = map.declarations[0].init.elements.filter((node) => {
 const owned = node.elements[1]?.value === 'item36-native' && node.elements[2]?.value === name;
 if (owned) tuple++;
 return !owned;
});
after.body = after.body.filter((node) => {
 const owned = node.type === 'BlockStatement' && node.body.some((inner) => inner.type === 'VariableDeclaration' && inner.declarations.some((decl) => decl.id.name === 'name' && decl.init.value === name));
 if (owned) inverses++;
 return !owned;
});
const walk = (node) => {
 if (!node || typeof node !== 'object') return;
 for (const [key,value] of Object.entries(node)) {
  if (Array.isArray(value)) {
   node[key] = value.filter((item) => {
    const owned = item?.type === 'IfStatement' && item.test.type === 'BinaryExpression' && item.test.operator === '==='
     && item.test.left.name === 'where' && item.test.right.type === 'CallExpression' && item.test.right.callee.name === 'conditionKey'
     && item.test.right.arguments[1]?.value === 'item36-native' && item.test.right.arguments[2]?.value === name;
    if (owned) check++;
    return !owned;
   });
   node[key].forEach(walk);
  } else if (value && typeof value === 'object') walk(value);
 }
};
walk(after);
assert.equal(tuple,1);assert.equal(check,1);assert.equal(inverses,1);
assert.deepEqual(clean(after),clean(before));
console.log(JSON.stringify({original_whole_guard_AST_preserved:true,removed_exact_tuple:tuple,removed_exact_key_command_check:check,removed_additive_inverse_block:inverses},null,2));
