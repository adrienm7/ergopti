from pathlib import Path
import hashlib,json,re,tarfile,gzip,io,subprocess
b=Path('/workspace/.ergopti-cloud/resume-personal-topology-fixture-portability')
sha=lambda data:hashlib.sha256(data).hexdigest()
old=(b/'tests-83.lua').read_bytes();candidate=(b/'candidate-tests.lua').read_bytes();original=(b/'literal-tests.lua').read_bytes();producer=(b/'candidate3-prepared.lua').read_bytes()
assert candidate.startswith(original)and len(original)==38693
assert sha(old)=='d14677ca2fd8f79acdb973e4ea4d7f76b4a896e08890bf91b833bbf9d2a73f6c'
assert sha(candidate)=='2340d5e638fbf0660839991d3f96de74d55908e805c53028f5b3e9552d276658'
assert sha(producer)=='ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768'
old_tail=old.decode().split('\tlocal function session(backend_name, run)',1)[1]
new_tail=candidate.decode().split('\tlocal function session(backend_name, run)',1)[1]
assert new_tail.replace('pairs(fixture_filesystem)','pairs(actual_posix)').replace('local entries = fixture_filesystem.dir(path)','local entries = actual_posix.dir(path)')==old_tail
matrices={}
for phase,filename,prefix in [('preliminary','portability-matrix.json',''),('isolated','isolated-portability-matrix.json','isolated-')]:
 matrix=json.loads((b/filename).read_text());assert matrix['state']=='COMPLETE'and len(matrix['rows'])==10
 assert matrix['producer_sha256']==sha(producer)and matrix['portable_test_sha256']==sha(candidate)
 for row in matrix['rows']:
  stem=f"{prefix}{row['label']}-{row['mode']}-{row['runtime']}"
  assert row==json.loads((b/(stem+'-status.json')).read_text())
  for stream in ('stdout','stderr'):assert sha((b/(stem+'.'+stream+'.log')).read_bytes())==row[stream+'_sha256']
  assert row['child_exit_code']==0 and row['failed']==0
  if row['label']=='frozen-v3':
   assert row['receiver_exit_code']==1 and row['executed_topology_subjects']==0 and len(row['missing_expected_subjects'])==34
   assert row['passed']==(48 if row['mode']=='global-absent'else 49)
  else:
   assert row['receiver_exit_code']==0 and row['executed_topology_subjects']==34 and not row['missing_expected_subjects']
   assert row['passed']==(82 if row['mode']=='global-absent'else 83)
  if row['mode']!='available':assert row['controlled_posix_refusals']>0
  if phase=='isolated':
   assert not row['remaining_owned_fixture_paths']and not Path(row['temporary_root']).exists()
   assert row['environment_overrides']==dict(TEMP=row['temporary_root'],TMPDIR=row['temporary_root'])
 matrices[phase]=matrix
roots=[row['temporary_root']for row in matrices['isolated']['rows']];assert len(set(roots))==10
m=json.loads((b/'source-manifest.json').read_text());owned=['static/ergopti_plus/linux/infra/file_watchers.lua','static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua']
for f in m['files']:
 p=b/'source'/f['path'];assert p.is_file()
 if f['path']not in owned:assert sha(p.read_bytes())==f['sha256']
assert (b/'source'/owned[0]).read_bytes()==producer and(b/'source'/owned[1]).read_bytes()==candidate
assert {f['path']for f in m['files']}=={str(p.relative_to(b/'source'))for p in(b/'source').rglob('*')if p.is_file()}
previous_archive=b.parent/'resume-personal-watch-topology-receiving.tar.gz'
assert sha(previous_archive.read_bytes())=='ef732a0a888d5f7c5724f9e6b42e3c5b25286b815e60ec28fdd992a3cb2d37a3'
preimages=b/'patch-check-preimages';preimage=preimages/owned[1];preimage.parent.mkdir(parents=True,exist_ok=True);preimage.write_bytes(old)
check=subprocess.run(['git','apply','--check',str(b/'fixture-portability.patch')],cwd=preimages,capture_output=True,text=True)
assert check.returncode==0,(check.stdout,check.stderr)
receipt={'external_literal_test_patch_check':{'exit_code':check.returncode,'stdout':check.stdout,'stderr':check.stderr},'state':'COMPLETE_EXTERNAL_FIXTURE_ONLY_RECEIVING','producer_unchanged_sha256':sha(producer),'frozen_test_sha256':sha(old),'portable_test_sha256':sha(candidate),'original_prefix_bytes':38693,'original_prefix_sha256':sha(original),'all34_case_tail_unchanged_except_two_port_references':True,'final_isolated_modes_each_engine':{'available':{'passed':83,'failed':0,'new_topology_executed':34},'topology-absent':{'passed':83,'failed':0,'new_topology_executed':34},'global-absent':{'passed':82,'failed':0,'new_topology_executed':34,'unchanged_original_installed_posix_optional_unavailable':1}},'frozen_v3_absence_red_each_engine':{'topology-absent':{'passed':49,'failed':0,'child_exit_code':0,'receiver_exit_code':1,'new_topology_executed':0,'missing_subjects':34},'global-absent':{'passed':48,'failed':0,'child_exit_code':0,'receiver_exit_code':1,'new_topology_executed':0,'missing_subjects':34}},'unique_child_temporary_roots':roots,'remaining_owned_fixture_paths':[],'dependency_manifest_files':len(m['files']),'nonowned_dependency_drift_missing_extra':[],'preliminary_matrix_limit':'Completed first matrix reused activation TMPDIR shared with concurrent canonical receiving; retained as preliminary due possible same-second legacy fixture name collisions. No actual failure or collision is asserted. Final matrix supplies distinct TMPDIR and TEMP for each child.','limits':['Fallback is a controlled test-fixture filesystem port backed by real luv operations; it does not claim execution of absent lua-posix.','Existing s.no_posix cases still remove require(posix) and exercise production native-stat/checked-shell branches.','No production, CI, workflow or original test-prefix edits in this proposal.','Canonical fullgate/CI/installed acceptance belong to parent; this external receipt does not qualify them.'],'companion_original_packet':{'archive':'resume-personal-watch-topology-receiving.tar.gz','sha256':'ef732a0a888d5f7c5724f9e6b42e3c5b25286b815e60ec28fdd992a3cb2d37a3','unchanged':True}}
(b/'receiving-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted([p for p in b.iterdir()if p.is_file()and p.name!='SHA256SUMS'],key=lambda p:p.name)
(b/'SHA256SUMS').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n'for p in files));files.append(b/'SHA256SUMS');files.sort(key=lambda p:p.name)
archive=b.parent/'resume-personal-topology-fixture-portability-receiving.tar.gz'
with archive.open('wb')as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0)as zipped:
  with tarfile.open(fileobj=zipped,mode='w')as tar:
   for p in files:
    data=p.read_bytes();info=tarfile.TarInfo('resume-personal-topology-fixture-portability/'+p.name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive)as tar:
 assert len(tar.getmembers())==len(files)
 for p in files:assert tar.extractfile('resume-personal-topology-fixture-portability/'+p.name).read()==p.read_bytes()
output={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(files),'all_members_reopened_and_byte_compared':True,'portable_test_sha256':sha(candidate),'producer_unchanged_sha256':sha(producer)}
(b.parent/'resume-personal-topology-fixture-portability-receiving.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
