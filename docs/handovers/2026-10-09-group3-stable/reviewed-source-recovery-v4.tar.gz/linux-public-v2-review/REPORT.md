<!-- public93-v2-independent/REPORT.md -->

# Independent review of the inactive Linux simultaneous public join

Verdict: **SOURCE_CLEAR_PRIVATE_ORDERED_SOURCE_ONLY** for the nineteen-path public V1 followed by the additive three-path V2. The original public V1 remains immutable and HOLD on its own. This review neither adopts the proposals nor completes TODO93 or any other Group3 item.

## Exact reviewed sources

- Public V1 receipt: `3da5ab41a31cf1176a39552c51fe5fe21a8738a6bfe1b5ff36eddbe858cb684d`; patch: `6b6a22ff573689eff8628b971491a96779ecd3cdaa5998455c9e202f2c232e44`; seals: `73852d9ff6e1a77f5021a05249b06b8fc5f8edd3f63c3f6c114f9088fb013840`.
- Public V2 receipt: `b641ef20792023aafc2c5ece36e1043a90a134b935a5b1a0a3c4592a063ff5d0`; patch: `7df39d6f8056e71694dbd21dcfb59e9fe538aabb2afd6b079b9703f763b5a803`; seals: `b42cb3db1bebc688f82aac6671f9ca98aac5e0bddbda68abdeb853ed9ab717d7`.
- Original independent V1 HOLD report: `d6c23591aeba8fa8e6f252ce7616da5e9d99da826a4322ed19b0f68fc3f6fa32`; verdict: `7096d27e8a4378b12fa721f97b4cf06f16e14f65819f7bb330ea61a240ae1007`; 32 seals: `e2f96c2872e1cf1b64b40ea7a21208455b34454abc73e8132ef76670b0ee5121`.

Every V1 preimage is its actual `cbb0efd431752da5ec8ccf38029463a76bb4ee55` Git object, and every V2 preimage is the exact corresponding frozen V1 postimage. The eighteen existing canonical paths still match those preimages at the observed HEAD `990c017f282338d600d37464ed3b5d279249790a`; the declaration test helper is new. This observation does not reserve files or replace the parent's final current-source and ownership reconciliation.

Eight independent private `git apply` operations checked and applied V1 then V2 forwards, and V2 then V1 inverses, comparing every resulting image. No index, ref or canonical file was written. Both frozen packets' 424 and 168 artifact pins and the original independent HOLD seals remain exact.

## Authority and lifecycle review

V1's config-reading owner could normalize arbitrary caller keys/actions into a privately registered pending-input configuration. The original controlled receiving counterexample runs the actual Reader, Hook, pair engine and output broker: original Manager refuses `private_unlisted`, while a detached caller catalogue previously obtains registry membership, first-key buffering and that callback. Original output cleanup succeeds before the deliberate failure. V2 rejects the same unmodified counterexample on both ABIs before all three effects, and original cleanup still succeeds.

The V2 Manager actually invokes its captured original SourceOwner, base engine and pair constructors; its private constructor-port table does not borrow future public constructor exports. It records only its own constructed owner/options identities, loaded catalogue/keys/hold data, original getter and action callbacks. Options become current only for the exact successfully installed engine and installation generation after Hook acknowledgement. A caller cannot insert a registry record through a public registration or positive Boolean API. The pure observer joins these private records with original constructor/config-loader/catalogue currency, exact loaded data, unpaused installation and its own original plain `package.loaded` Manager identity.

The last module check closes the reviewed borrowed-observer alias seam: genuine managed reconfiguration while a future Manager alias contains the original getter cannot acquire pending input. Removing that check fails its actual reconfiguration control. Future first-read fake observers, later observer/getter/constructor/config-loader/catalogue replacements and external source-callback pause/catalogue revocation are independently exercised. SourceOwner checks the captured observation and options/state currency before and after the actual canonical source guard. The source role check is a scoped loader identity check; the private original invocation and records provide the options provenance.

The existing normal original Lua loader/generated-data bootstrap is an explicit premise. This is not protection against arbitrary VM/debug mutation or fabricated source filenames. Counterfactual loaders keep the genuine logical module coordinates so a source-role mismatch cannot mask the omitted predicate; those are honest controlled fork-source experiments, not authentication of arbitrary loaded code. Sampled identity fences also cannot detect an unobserved replacement restored between all observation barriers.

The ordered runtime V1 plus its separately reviewed runtime V2 cleanup repair remain in the ordered public proposal. The Hook postimage is the exact repaired runtime image; the complete original runtime189 and public199 test byte prefixes remain exact. Actual original source reconciliation, output debt/retirement, first-key ownership, pause, source replacement, hotplug, backlog, timer, SYN_DROPPED and fallback tests remain executed. No new output, physical-input or native state action authority is granted by the public declaration, Save or copy.

## Persistence, menus and original assertions

Linux declares typed `100` milliseconds and `false` symmetry exactly once through the real Features owner; neither comes from a macOS timeout fallback. Third-slot defaults/recommendations remain None. The schema permits future/personal leaves; scoped and global inventories filter to known pair leaves and retain the original parameter/source/publication/inverse leases. Save/copy preserve master switches, explicit None, personal data and unknown records. Copy reads the fresh canonical Linux tap namespace through the explicit optional shared policy parameter, while the unchanged original Mac/shared API and corpus still execute.

Actual local/global Scope and menu tests cover these joins and their refusal/inverse cases. Native state third slots OneShotShift/CapsWord and program/window actions remain denied by the actual picker/validator and original binding guards; their missing receiving joins are software work, not merely physical validation. Predecessor cases explicitly hide only the two new declarations; positive public cases use the actual generated Features data. No expected corpus was regenerated.

All original registered test callback bodies and assertion lines are retained in order: global scope 20 bodies/92 assertion lines, local scope 46/191, module 94/304, menu 5/32. Whole original runtime189/public199 prefixes additionally preserve the earlier 161 controls and 425 assertion prefix. All 291 unrelated incoming menu sections and the actual five G1 Source44 About/slot function bodies are exact. The source guard retains all 38 original executable `errors.push` assertion bodies according to Acorn, with 42 after additions. Its admission extension accepts only the original or explicitly checked new mode and complete original input-port inventory plus the new pending ports; the old refusal, native state and lifecycle checks remain. Source guard shape is supplementary evidence, not native delivery proof.

## Independently executed evidence

On **each** of LuaJIT and Lua5.4, the closed private sources execute:

| Cohort | Observed result |
| --- | --- |
| Ordered V1+V2 runtime | 216 passed, 0 failed |
| Actual local Scope/menu | 81 passed, 0 failed |
| Original menu/21-language checks | 8 passed, 0 failed |
| Global Scope | 27 passed, 0 failed |
| Unchanged original shared/Mac copy corpus | 13 passed, 0 failed |
| Whole old public V1 modules with new controls | 201 passed, 15 expected failures |
| Old SourceOwner with repaired Manager | 202 passed, 14 expected failures |
| Eight V2 predicate omissions | 215/1, 214/2 or 213/3; each genuinely RED |
| Old local/global Scope | 64/17 and 25/2 expected RED |
| Wrong copy namespace/omitted receiving filter/future-pair filter | 79/2, 78/3 and 25/2 expected RED |
| Independent bool/copied/meta/unissued caller-data probes | 4 passed, 0 failed; original cleanup true |

The independent original receiving probe observes registry/pending/callback **true/true/true** on V1, with deliberate exit1 after cleanup; the repaired probe observes **false/false/false**, exit0, cleanup true on both ABIs. Its only source edit is the private dependency root; original callback and assertion bodies remain exact.

The single focused catalogue guard passes on the actual ordered postimages. Its original guard and all fourteen original source omission/default variants fail as expected. This ran only one existing read-only source guard, not the full JS suite, and uses immutable cbb Git-object inputs and the private proposals. Acorn assertion preservation is a separate focused source check.

Forty completed focused Lua cohort processes comprise ten positive cohorts and thirty expected negative cohorts. Four independent original/repaired receiving processes and two caller-data processes supplement them. None were skipped. Two additional initial reviewer harness failures are preserved separately: the shared corpus JSON was initially absent from the sparse graph, and a blanket caller metatable accidentally returned `true` as Files/route ports. The first was fixed by pinning the unchanged original cbb corpus, and the second by restricting the invented field to `invented_authority`, leaving genuine Files/route intact. The corrected controls pass; neither harness failure is claimed as a product regression or an expected rejection control.

The private graph pins 504 existing input images plus the original corpus; it includes 222 immutable cbb Lua dependency supplements and remains 15MiB on disk. It is a sparse source graph, not a checkout. Source images remain byte-exact after the completed controlled replays. Logs, commands, supplemental fixture pins, source joins, callback hashes and patch roundtrip observations are retained beside this report.

## Required next acceptance

No whole registered driver/JS suites, formatter/schema gates, generators, native kernel/desktop/physical tests, installation or packaging ran in this review. The FFI/event transport is controlled; genuine Lua/Luv and production software components do not establish a kernel input receipt. The private proposal remains inactive until the parent reconciles current source ownership/preimages, applies the ordered source patches, regenerates manifest/menu/architecture through their owners and runs selected/full relevant gates and the exact native receiving qualifications.

Shared manifest/menu/schema ownership remains coordinated with G1; current G5/G6 source and native workflow enrollment must be reconciled. Generated references are test inputs, excluded from both source patches. No workflow, builder, generated output, canonical source, Git index/ref, public capability or default/master switch was changed by the reviewer.

All thirteen Group3 items remain partial; no TODO is removed, items16/38 remain, and withdrawn item22 is not reintroduced. Cross-device chord receiving, native state/program/window third-slot binding joins and physical host coverage remain separate gaps. This verdict closes the reproduced constructor authority defect for the bounded ordered private software sources only.
