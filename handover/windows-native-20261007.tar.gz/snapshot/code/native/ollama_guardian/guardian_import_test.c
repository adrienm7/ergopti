#include "guardian_import.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    uint32_t duplicate_calls, validate_calls, close_calls, releases;
    uint32_t refuse_duplicate, refuse_validate;
    uintptr_t refuse_close;
    uintptr_t closed[16];
} GI_TestPort;

#define GI_CHECK(Name,Expr) do { if (!(Expr)) { \
    fprintf(stderr,"FAIL %s:%d: %s\n",Name,__LINE__,#Expr); return 0; } } while (0)

static void *Allocate(void *context, size_t bytes) {
    (void)context;
    return calloc(1u,bytes);
}
static void Release(void *context, void *value) {
    GI_TestPort *p=context; ++p->releases; free(value);
}
static int Source(void *context, uintptr_t source, uintptr_t *out) {
    (void)context;
    if(source!=71u)return 0;
    *out=171u; return 1;
}
static int Content(void *context, uintptr_t source, const GI_Expected *expected,
                    uintptr_t *out) {
    GI_TestPort *p=context;
    ++p->duplicate_calls;
    if(source!=171u)return 0;
    *out=expected->source_handle+100u;
    return p->refuse_duplicate!=p->duplicate_calls;
}
static int Validate(void *context, uintptr_t handle, const GI_Expected *expected) {
    GI_TestPort *p=context;
    ++p->validate_calls;
    return handle==expected->source_handle+100u && p->refuse_validate!=p->validate_calls;
}
static int Close(void *context, uintptr_t handle) {
    GI_TestPort *p=context;
    if(p->close_calls<16u)p->closed[p->close_calls]=handle;
    ++p->close_calls;
    return handle!=p->refuse_close;
}
static GI_Port Port(GI_TestPort *context) {
    GI_Port port={context,Allocate,Release,Source,Content,Validate,Close};
    return port;
}
static void Expected(GI_Expected *items) {
    static const uint16_t path1[]={67u,58u,92u,97u,0u};
    static const uint16_t path2[]={67u,58u,92u,98u,0u};
    memset(items,0,2u*sizeof(*items));
    items[0].source_handle=21u; items[0].volume=1u; items[0].index=101u;
    items[0].native_path=path1;items[0].path_units=4u;
    items[1].source_handle=22u; items[1].volume=1u; items[1].index=102u;
    items[1].native_path=path2;items[1].path_units=4u;
}

static int Healthy(void) {
    const char *name="healthy import";
    GI_Row row={0};GI_TestPort p={0};GI_Expected expected[2];Expected(expected);
    GI_CHECK(name,GI_Begin(&row,1u,71u,expected,2u,Port(&p)));
    GI_CHECK(name,row.phase==GI_PREPARED && row.source==0u && row.acquired==2u);
    GI_CHECK(name,p.duplicate_calls==2u && p.validate_calls==2u && p.close_calls==1u && p.closed[0]==171u);
    GI_CHECK(name,GI_Abort(&row));
    GI_CHECK(name,row.phase==GI_ABORTED && p.close_calls==3u && p.releases==1u);
    GI_CHECK(name,GI_Abort(&row) && p.close_calls==3u && p.releases==1u);
    return 1;
}
static int Partial(void) {
    const char *name="partial acquisition preserved";
    GI_Row row={0};GI_TestPort p={0};GI_Expected expected[2];Expected(expected);p.refuse_duplicate=2u;
    GI_CHECK(name,!GI_Begin(&row,2u,71u,expected,2u,Port(&p)));
    GI_CHECK(name,row.id==2u && row.phase==GI_RESOURCE_DEBT && row.first_error==5u && row.acquired==1u);
    GI_CHECK(name,row.contents[0].handle==121u && row.contents[1].handle==122u && row.source==171u);
    GI_CHECK(name,!GI_MarkExported(&row));
    GI_CHECK(name,GI_Abort(&row) && p.close_calls==3u && p.releases==1u);
    return 1;
}
static int Validation(void) {
    const char *name="validation refusal preserved";
    GI_Row row={0};GI_TestPort p={0};GI_Expected expected[2];Expected(expected);p.refuse_validate=1u;
    GI_CHECK(name,!GI_Begin(&row,3u,71u,expected,2u,Port(&p)));
    GI_CHECK(name,row.first_error==6u && row.acquired==1u && row.contents[0].handle==121u && row.source==171u);
    GI_CHECK(name,p.duplicate_calls==1u && p.validate_calls==1u && p.close_calls==0u);
    GI_CHECK(name,GI_Abort(&row) && p.close_calls==2u && p.releases==1u);
    return 1;
}
static int SourceDebt(void) {
    const char *name="source close uncertain no retry";
    GI_Row row={0};GI_TestPort p={0};GI_Expected expected[2];Expected(expected);p.refuse_close=171u;
    GI_CHECK(name,!GI_Begin(&row,4u,71u,expected,2u,Port(&p)));
    GI_CHECK(name,row.first_error==7u && row.source_close_attempted==1u && row.source_close_uncertain==1u && row.source==171u);
    GI_CHECK(name,!GI_Abort(&row) && p.close_calls==3u && p.releases==0u);
    GI_CHECK(name,!GI_Abort(&row) && p.close_calls==3u && row.first_error==7u);
    /* Test-only RAM reclamation after all behavioral checks; fake caps only. */
    free(row.contents);return 1;
}
static int FileDebt(void) {
    const char *name="content close uncertain no retry";
    GI_Row row={0};GI_TestPort p={0};GI_Expected expected[2];Expected(expected);
    GI_CHECK(name,GI_Begin(&row,5u,71u,expected,2u,Port(&p)));p.refuse_close=121u;
    GI_CHECK(name,!GI_Abort(&row) && row.first_error==8u && row.contents[0].uncertain==1u && row.contents[0].handle==121u);
    GI_CHECK(name,p.close_calls==3u && p.releases==0u && row.contents[1].handle==0u);
    GI_CHECK(name,!GI_Abort(&row) && p.close_calls==3u && p.releases==0u);
    free(row.contents);return 1;
}
static int Duplicate(void) {
    const char *name="duplicate identity refused before acquisition";
    GI_Row row={0};GI_TestPort p={0};GI_Expected expected[2];Expected(expected);expected[1].index=expected[0].index;
    GI_CHECK(name,!GI_Begin(&row,6u,71u,expected,2u,Port(&p)));
    GI_CHECK(name,row.first_error==2u && row.contents==NULL && row.source==0u && p.duplicate_calls==0u);
    GI_CHECK(name,GI_Abort(&row) && p.close_calls==0u && p.releases==0u);
    return 1;
}
static int Export(void) {
    const char *name="export prevents parent abort";
    GI_Row row={0};GI_TestPort p={0};GI_Expected expected[2];Expected(expected);
    GI_CHECK(name,GI_Begin(&row,7u,71u,expected,2u,Port(&p)));
    GI_CHECK(name,GI_MarkExported(&row) && row.phase==GI_EXPORTED);
    GI_CHECK(name,!GI_MarkExported(&row));
    GI_CHECK(name,!GI_Abort(&row) && p.close_calls==1u && p.releases==0u);
    free(row.contents);return 1;
}
int main(void) {
    int (*tests[])(void)={Healthy,Partial,Validation,SourceDebt,FileDebt,Duplicate,Export};
    const char *names[]={"healthy import","partial acquisition preserved","validation refusal preserved","source close uncertain no retry","content close uncertain no retry","duplicate identity refused before acquisition","export prevents parent abort"};
    size_t i;
    for(i=0u;i<sizeof(tests)/sizeof(*tests);++i){
        int good=tests[i]();printf("%s %zu - %s\n",good?"ok":"not ok",i+1u,names[i]);
        if(!good)return 1;
    }
    return 0;
}
