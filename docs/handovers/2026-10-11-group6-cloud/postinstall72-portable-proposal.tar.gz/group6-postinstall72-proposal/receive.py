"""Run isolated composed tests using the checkout's unchanged support graph."""
from pathlib import Path
import argparse, importlib.util, sys, unittest
BASE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('subject',choices=('original','candidate','frozen'))
parser.add_argument('--cohort',choices=('all','postinstall','interaction'),default='all')
parser.add_argument('--repository',default='/workspace/ergopti')
parser.add_argument('--tests',default='candidate')
options=parser.parse_args()
root=Path(options.repository).resolve()
test_path=root/'tools/test/macos_native_http_receiving_facts_test.py'
namespace={'__name__':'isolated_composed_receiving','__file__':str(test_path)}
source=(BASE/options.tests/'tools/test/macos_native_http_receiving_facts_test.py').read_text()
exec(compile(source,str(test_path),'exec'),namespace)
roles={'original':BASE/'preimage','candidate':BASE/'candidate','frozen':BASE/'frozen'}
fixture=roles[options.subject]/'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
spec=importlib.util.spec_from_file_location('isolated_composed_wire_'+options.subject,fixture)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
namespace['WIRE']=module
classes={'postinstall':'NativePostInstallTrustObservationTests','interaction':'NativePostInstallCancellationInteractionTests'}
suite=unittest.TestSuite()
for name,value in namespace.items():
 if isinstance(value,type) and issubclass(value,unittest.TestCase) and (options.cohort=='all' or name==classes[options.cohort]):
  suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(value))
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(f'receiving subject={options.subject} cohort={options.cohort} total={result.testsRun} failures={len(result.failures)} errors={len(result.errors)} skips={len(result.skipped)}')
sys.exit(0 if result.wasSuccessful() else 1)
