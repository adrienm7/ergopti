﻿; modules/llm/ollama_managed_windows_lifecycle.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Canonical Managed Windows Runtime Lifecycle
; DESCRIPTION:
; Holds one coordinator after generated code pins and native policies exist.
; Shutdown/reload/disable invalidate before retirement; persistent file debt is
; separately visible and cannot be mistaken for process or HTTP handback.
; ==============================================================================

global _LLM_ManagedWindowsCoordinator := 0

LLM_ManagedWindows_Init(Coordinator) {
	global _LLM_ManagedWindowsCoordinator
	if !(Coordinator is OllamaManagedCoordinator)
		throw TypeError("Managed Windows initialization requires its genuine coordinator.")
	local previous := Critical("On")
	try {
		if !(_LLM_ManagedWindowsCoordinator is Integer && _LLM_ManagedWindowsCoordinator == 0)
			throw Error("Managed Windows coordination initialization is exclusive.")
		_LLM_ManagedWindowsCoordinator := Coordinator
	} finally Critical(previous)
	return true
}

/** Rejects lifecycle observation before the exclusive canonical initialization. */
_LLM_ManagedWindowsRequireState() {
	global _LLM_ManagedWindowsCoordinator
	if !_LLM_ManagedWindowsCoordinator
		throw Error("Managed Windows lifecycle has not been initialized.")
	if !(_LLM_ManagedWindowsCoordinator is OllamaManagedCoordinator)
		throw TypeError("Managed Windows lifecycle state is not its genuine owner.")
	return _LLM_ManagedWindowsCoordinator
}

LLM_ManagedWindows_PrepareShutdown() {
	return _LLM_ManagedWindowsRequireState().Stop()
}

LLM_ManagedWindows_HasNativeOwner() {
	return _LLM_ManagedWindowsRequireState().HasNativeOwner()
}

LLM_ManagedWindows_DataDebt() {
	return _LLM_ManagedWindowsRequireState().Files.HasFileDebt()
}
