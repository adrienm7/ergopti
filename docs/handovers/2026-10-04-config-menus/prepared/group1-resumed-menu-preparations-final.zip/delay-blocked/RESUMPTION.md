# Delay source resumption remains open

Current prepared partial packet: `tap-hold-delay-current.patch`, SHA256
`f8f32ad75ce2ed3d45d565b882bd38ddb702537b60b406217eb5621325717865`.
It owns15 exact paths on accepted head `b3ce4124…` and Metrics V3 `64282fbf…`.
Focused Linux27/0 (Lua5.4/LuaJIT), macOS23/0 and original-provider inverses26/1
and21/2 pass the stated causal controls. Native Windows/fullselected/E2E/
package/install were not run. This packet is not approved for integration.

The historical statement that Windows per-key timing is unsupported is wrong.
Its loader already accepts time_activation_seconds and TapHoldDuration uses it.
Only the tray editor is unported; the missing UI is feasible source work, not a
physical-device blocker. The current Windows hide policy must be resolved.

Use the existing native ownership path: detached _TH_CandidateEntry builder,
_TH_CommitTapHoldMutation master+tap-hold leases, strict integer1 staging/
replacement/authorization receipts and Critical defusing. Add a validated known
physical-key numeric setter and Ui_InputBox prompt. Cancelled/invalid answers
write nothing; valid input persists once and reloads once through the strict
_TH_ReloadTapHoldMenu owner. Bind each key explicitly so UI-event arguments and
loop captures cannot redirect it. Existing locale prompts use printf%d/%s, not
AHK Format placeholders; substitute the bounded native millisecond value without
changing translated text. Ui_InputBox returns Result/Value object fields; invalid
or throwing shapes must write/reload zero times. Preserve tap/hold/enabled/future key members.
Test real writer source/neighbors plus writer/replace/authorization false/nil/
truthy refusal, terminal admission, target/live-owner revocation and reload debt.

A minimal Windows port can mirror Linux's custom-duration command while leaving
Mac's global-reset row Mac-only. Read effective captions through the existing
TapHoldDuration over desired state. If implementing reset, first model actual
per-key inheritance: loader90–133 merges shared defaults field by field. Deleting
a custom duration can restore that key's shipped0.2–0.35s, not guessed global0.2.
Loaded memory already contains inherited fields, so Has(time_activation_seconds)
is not evidence of a stored override. Do not invent that provenance or a global
Windows editor. Use existing runtime bounds and reject non-finite/non-positive/
over-bound/zero-after-rounding values before writing.

Preserve the immutable independent head corpus. Independently specify stronger
complete Windows delay expectations and keep every first-four head order/caption/
Win32/payload assertion when adapting obsolete total-child counts. Prove an
original native-port inverse. Never regenerate expectations from new code.

The root's separate Linux certification correction `40d562e7…` formats captions
from independent full_context state. A future Delay composition needs a precise
empty-key delay fixture value (currently0ms), while retaining unknown-getter,
actual invalid-caption, completeness and non-vacuity assertions. Do not exempt
or skip the new group.

The user requested immediate partial integration, so no new Windows port was
implemented in this worker. This immutable preparation and concrete source
requirements remain for resumption. All physical acceptance and transverse16/38
requirements remain separate and open.
