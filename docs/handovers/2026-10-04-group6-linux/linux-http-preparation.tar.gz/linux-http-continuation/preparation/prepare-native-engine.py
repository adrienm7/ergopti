#!/usr/bin/env python3
"""Prepare a reviewable curl engine candidate from one exact saved preimage."""

from pathlib import Path
import argparse

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--preimage", type=Path, default=ROOT / "http_client.preimage.lua")
parser.add_argument("--output", type=Path, default=ROOT / "static/ergopti_plus/linux/adapters/curl_http_client.lua")
arguments = parser.parse_args()
source = arguments.preimage.read_text()


def replace(old, new):
    global source
    if source.count(old) != 1:
        raise RuntimeError("Native source seam is not unique")
    source = source.replace(old, new, 1)


replace("--- adapters/http_client.lua", "--- adapters/curl_http_client.lua")
replace('local TransportPolicy = require("infra.http_transport_policy")',
        'local TransportPolicy = require("infra.http_transport_policy")')
replace('local STATUS_MARKER = "ERGOPTI_HTTP_STATUS:"',
        'local STATUS_MARKER = "ERGOPTI_HTTP_STATUS:"\nlocal PROXY_MARKER = "ERGOPTI_PROXY_RECEIPT:"')
replace('M.HAS_ASYNC = luv ~= nil',
        'M.HAS_ASYNC = luv ~= nil\n\n--- Returns the existing native engine timeout default without duplicating it.\n'
        '--- @return number\nfunction M.default_timeout_ms() return DEFAULT_TIMEOUT_MS end')
replace('if _active[request.owner] == request then _active[request.owner] = nil end\n\tclose_timer(request)',
        'if _active[request.owner] == request then _active[request.owner] = nil end\n'
        '\tif request.operation and type(request.operation._on_terminal) == "function" then\n'
        '\t\tlocal ok = pcall(request.operation._on_terminal, result)\n'
        '\t\tif not ok then Logger.error(LOG, "Native HTTP terminal observer raised.") end\n'
        '\tend\n\tclose_timer(request)')
replace('local function curl_args(url, headers, body, options)\n\tlocal timeout_ms',
        'local function curl_args(url, headers, body, options)\n\tlocal timeout_ms')
old = '''\targs[#args + 1] = (options.buffered and "" or "%{stderr}")
\t\t.. "\\n" .. STATUS_MARKER .. "%{http_code}\\n"'''
new = '''\tlocal proxy_receipt = ""
\tif type(options.proxy_selection) == "table" then
\t\tproxy_receipt = "%{stderr}\\n" .. PROXY_MARKER .. "%{http_connect}:"
\t\t\t.. (options.proxy_metrics_available and "%{proxy_used}" or "?") .. "\\n"
\tend
\targs[#args + 1] = proxy_receipt .. (options.buffered and "%{stdout}" or "%{stderr}")
\t\t.. "\\n" .. STATUS_MARKER .. "%{http_code}\\n"'''
# Preserve the old default writeout byte-for-byte when no proxy selection exists.
new += '''
\tif proxy_receipt == "" and options.buffered then
\t\targs[#args] = "\\n" .. STATUS_MARKER .. "%{http_code}\\n"
\tend'''
replace(old, new)
replace('local lines = {}\n\tlocal names = {}', '''local lines = {}
\tif type(options.proxy_selection) == "table" then
\t\tlocal selection = options.proxy_selection
\t\tif selection.mode == "selected" then
\t\t\tlines[#lines + 1] = "proxy = " .. config_quote(selection.proxy)
\t\telseif selection.mode == "direct" then
\t\t\tlines[#lines + 1] = 'proxy = ""'
\t\t\tlines[#lines + 1] = 'noproxy = "*"'
\t\telseif selection.mode ~= "environment" then error("native proxy selection is invalid") end
\tend
\tlocal names = {}''')
replace('''\t\tmax_download_bytes = options.max_download_bytes,
\t}''', '''\t\tmax_download_bytes = options.max_download_bytes,
\t\tproxy_selection = options.proxy_selection,
\t\tproxy_metrics_available = options.proxy_metrics_available == true,
\t}''')
replace('''\t\toperation = operation,
\t\thandles = {},''', '''\t\toperation = operation,
\t\tproxy_selection = options.proxy_selection,
\t\thandles = {},''')
replace('request.stderr_tail = (request.stderr_tail .. chunk):sub(-(#STATUS_MARKER + 16))',
        'request.stderr_tail = (request.stderr_tail .. chunk):sub(-(#STATUS_MARKER + #PROXY_MARKER + 128))')

insert = '''--- Adds only actual native transport metrics to the safe failure contract.
--- @param request table
--- @param result table
--- @return table
local function native_receipt(request, result)
\tif type(request.proxy_selection) ~= "table" then return result end
\tlocal tail = request.stderr_tail:gsub("\\n" .. STATUS_MARKER .. "%d%d%d\\n?$", "")
\tlocal connect_text, used_text = tail:match("\\n" .. PROXY_MARKER .. "(%d%d%d):([01?])\\n?$")
\tlocal connect_status = tonumber(connect_text)
\tlocal selection = request.proxy_selection
\tlocal stage, provenance = "connect", "unavailable"
\tif request.exit_code == 5 then stage, provenance = "proxy_resolve", "verified"
\telseif request.exit_code == 60 then stage, provenance = "tls", "verified"
\telseif connect_status and connect_status >= 300 then stage, provenance = "proxy_connect", "verified"
\telseif result.status and result.status > 0 then stage, provenance = "http", "verified"
\telseif request.exit_code == 7 and used_text == "1" then stage, provenance = "proxy_connect", "verified" end
\tresult.failure_receipt = {
\t\tstage = stage, backend = "curl", failure_provenance = provenance,
\t\tcurl_exit = request.exit_code, http_status = result.status or 0,
\t\tproxy_connect_status = connect_status,
\t\tproxy_mode = selection.capability == "unavailable" and "unavailable" or selection.mode,
\t\ttls_verification = "enforced",
\t}
\tresult.proxy_used = used_text == "1"
\treturn result
end

'''
replace('--- Completes once both the process and its two output streams ended.\n',
        insert + '--- Completes once both the process and its two output streams ended.\n')
replace('''\tif request.buffered then
\t\tfinish(request, buffered_result(request))
\telse
\t\tfinish(request, streaming_result(request))
\tend''', '''\trequest.stderr_text = request.stderr_text:gsub("\\n" .. PROXY_MARKER .. "%d%d%d:[01?]\\n", "")
\tif request.buffered then
\t\tfinish(request, native_receipt(request, buffered_result(request)))
\telse
\t\tfinish(request, native_receipt(request, streaming_result(request)))
\tend''')

start = source.index('function M.get_owned(url, headers, options, callback)')
end = source.index('\n--- Downloads one response body', start)
owned = source[start:end]
owned = owned.replace('function M.get_owned(url, headers, options, callback)',
                      'local function owned_request(url, headers, body, options, on_chunk, callback)', 1)
owned = owned.replace('local operation = { started = false, _settled = false, _cancelled = false, _listeners = {} }',
                      'local operation = { started = false, _settled = false, _cancelled = false, _listeners = {},\n'
                      '\t\t_on_terminal = type(options) == "table" and options.on_native_terminal or nil }', 1)
a = owned.index('\tfunction operation:cancel()')
b = owned.index('\n\tlocal request_options = {}', a)
owned = owned[:a] + '''\tfunction operation:request_cancel()
\t\tlocal logical_api = options.owned_api == false
\t\tif not logical_api then self._cancelled = true end
\t\tif self._settled then return true end
\t\tlocal request = self._request
\t\tif not request then return false end
\t\tif not request.terminal then
\t\t\tif request.spawned and not request.exited and not terminate_group(request) then return false end
\t\t\tself._cancelled = true
\t\t\tfinish(request, { ok = false, status = 0, body = "", error = "cancelled" }, true)
\t\telse
\t\t\tif request.spawned and not request.exited and not terminate_group(request) then return false end
\t\t\tself._cancelled = true
\t\t\tretry_owned_cleanup(request)
\t\tend
\t\treturn true
\tend
\tfunction operation:cancel()
\t\tself:request_cancel()
\t\treturn self._settled
\tend''' + owned[b:]
owned = owned.replace('\trequest_options.buffered = true\n\trequest_options.method = "GET"\n', '', 1)
owned = owned.replace('type(headers) == "table" and headers or {}, nil,\n\t\trequest_options, nil, callback, operation)',
                      'type(headers) == "table" and headers or {}, body,\n\t\trequest_options, on_chunk, callback, operation)', 1)
methods = '''
--- Runs a buffered owned GET through the unchanged native curl engine.
function M.get_owned(url, headers, options, callback)
\tlocal request = {}
\tfor key, value in pairs(type(options) == "table" and options or {}) do request[key] = value end
\trequest.buffered, request.method = true, "GET"
\treturn owned_request(url, headers, nil, request, nil, callback)
end

--- Runs an owned request with caller-admitted method and stream options.
--- This native seam is consumed by the public coordinator, not a shared port.
--- @param url string
--- @param headers table
--- @param body string|nil
--- @param options table
--- @param on_chunk function|nil
--- @param on_done function
--- @return table
function M.dispatch_owned(url, headers, body, options, on_chunk, on_done)
\treturn owned_request(url, headers, body, options, on_chunk, on_done)
end

--- Refuses invalid native metadata before the coordinator starts any child.
--- @param url string
--- @param headers table
--- @param body string|nil
--- @param options table
--- @return boolean
--- @return string|nil
function M.preflight(url, headers, body, options)
\tif type(url) ~= "string" or url == "" then return false, "curl URL must be a non-empty string" end
\tif url:find("\\0", 1, true) then return false, "curl config URL cannot contain NUL" end
\tlocal protocols, err = TransportPolicy.resolve(url, options.https_only == true)
\tif not protocols then return false, err end
\toptions.protocols = protocols
\tif options.follow_redirects then
\t\tlocal allowed, follow_error = RedirectPolicy.allows_native_follow(headers)
\t\tif allowed == nil then return false, follow_error end
\t\toptions.follow_redirects = allowed
\tend
\tlocal composed, argv = pcall(curl_args, url, headers, body, options)
\tif not composed then return false, "curl configuration refused" end
\tif ShellRunner.validate_spawn_args("curl", argv) ~= "" then return false, "curl argument vector refused" end
\treturn true
end
'''
source = source[:start] + owned + methods + source[end:]
# Curl's C-string config parser cannot represent literal byte zero. Keep this
# native serializer admission separate from general shared HTTP body policy.
replace('--- Quotes one value for a curl config file, escaping what its parser reads\n', '--- Detects bytes curl\'s stdin config parser cannot represent literally.\n--- This is a native serializer limit, not a policy for other HTTP transports.\n--- @param value string|nil\n--- @return boolean\nlocal function config_has_nul(value)\n\treturn type(value) == "string" and value:find("\\0", 1, true) ~= nil\nend\n\n--- Quotes one value for a curl config file, escaping what its parser reads\n')
replace('local function config_quote(value)\n', 'local function config_quote(value)\n\tif config_has_nul(value) then error("curl config value cannot contain NUL", 0) end\n')
replace('\tlocal protocols, transport_error = TransportPolicy.resolve(url, options.https_only == true)', '\t-- Refuse unrepresentable body bytes before native ownership or replacement.\n\t-- JSON-escaped NUL, leading @ and CR/LF remain literal supported input.\n\tif config_has_nul(body) then return reject("curl config body cannot contain NUL") end\n\tlocal protocols, transport_error = TransportPolicy.resolve(url, options.https_only == true)')
replace('\tif url:find("\\0", 1, true) then return false, "curl config URL cannot contain NUL" end\n', '\tif url:find("\\0", 1, true) then return false, "curl config URL cannot contain NUL" end\n\tif config_has_nul(body) then return false, "curl config body cannot contain NUL" end\n')
# Native curl diagnostics must not forward credential-bearing URI text.
replace('--- Converts a completed buffered curl request to the port result envelope.\n', '--- Withholds native diagnostics that can expose credential-bearing proxy URIs.\n--- Curl\'s malformed-proxy errors may quote raw or encoded userinfo. A partial\n--- regex scrub cannot prove safety after truncation; retain the actual exit code.\n--- Metrics and response bodies are decoded separately and remain unchanged.\n--- @param request table\n--- @param diagnostic string\n--- @return string\nlocal function public_diagnostic(request, diagnostic)\n\tif request.exit_code == 5 or diagnostic:find("://", 1, true) or diagnostic:find("@", 1, true) then\n\t\treturn "curl exited with code " .. tostring(request.exit_code)\n\tend\n\treturn diagnostic\nend\n\n--- Converts a completed buffered curl request to the port result envelope.\n')
replace('\tlocal status = tonumber(status_text)\n', '\tlocal status = tonumber(status_text)\n\tlocal diagnostic = public_diagnostic(request, request.stderr_text)\n')
if source.count('request.stderr_text ~= "" and request.stderr_text') != 2: raise RuntimeError('Native diagnostic source seams changed')
source = source.replace('request.stderr_text ~= "" and request.stderr_text', 'diagnostic ~= "" and diagnostic')
replace('\tlocal diagnostic = request.stderr_text:gsub("\\n" .. STATUS_MARKER .. "%d%d%d\\n?$", "")', '\tlocal diagnostic = public_diagnostic(request, request.stderr_text:gsub("\\n" .. STATUS_MARKER .. "%d%d%d\\n?$", ""))')
target = arguments.output
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(source)
print(target)
