from pathlib import Path
root=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests')
for relative,callback,diagnostic,expected,producer in [
 ('unit/modules/llm/api/test_llm_api_remove_confirmation.ahk','_WAR_RemovalRetainsSource','ErrorMessage','Mode == "throw"','_LLM_Menu_RemoveActiveApiEntry'),
 ('unit/modules/llm/servers/test_llm_delete_confirmation_owner.ahk','_LDCO_ConfirmationRetainsOwner','ConfirmationError','Mode == "confirm-error"','_LLM_Menu_PromptDeleteCachedModel')]:
    p=root/relative;s=p.read_text(encoding='utf-8-sig');start=s.index(callback+'(Mode) {');end=s.index('\n}\n',start)+2;body=s[start:end]
    old=diagnostic+' := ""';assert body.count(old)==1;body=body.replace(old,old+', ContractThrew := false')
    old='catch as Err\n\t\t\t'+diagnostic+' := Err.Message';assert body.count(old)==1;body=body.replace(old,'catch as Err {\n\t\t\tContractThrew := true\n\t\t\t'+diagnostic+' := Err.Message\n\t\t}')
    needle='\t\tAssertEqual('+expected+' ?';assert body.count(needle)==1
    body=body.replace(needle,'\t\tAssertEqual('+expected+', ContractThrew, "Unexpected callback failures cannot pass as a refused action.")\n'+needle)
    s=s[:start]+body+s[end:];p.write_text(s,encoding='utf-8-sig',newline='\n')
