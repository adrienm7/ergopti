# Native file-write helper TMPDIR receiving

This compact environmental receipt runs the ORIGINAL `tests/hardware/run_file_write_special_receipts.py` with backend ffi and LuaJIT, first with the exact long TMPDIR from the failed parent gate, then with a short unique `/var/tmp/eg-*` root. No code or assertion is modified.

The complete external source capture has 2,361 files, every byte matching Git baseline b666 and e6, not only the helper or adapter. `baseline-identity.json` records Git blob comparisons against both immutable trees; `source-manifest.json` pins every SHA256. The unused watcher and test module were restored to their literal baseline copies before either helper process starts, so the entire tree is baseline-identical. No canonical source or index was changed.

| Environment | Completed PASS receipts | FAIL check receipts | Remaining checks not completed | Process exit |
| --- | ---: | ---: | ---: | ---: |
| Exact long TMPDIR, 64 bytes | 14 | 0 | 10 | 1 |
| Unique short TMPDIR, 20 bytes | 24 | 0 | 0 | 0 |

The long run aborts while creating the 15th fixture, at Python `listener.bind`, with `OSError: AF_UNIX path too long`. It does not reach the 24-check terminal summary and is not a successful 14-check suite. The constructed socket pathname has 109 bytes; Linux sockaddr_un.sun_path has 108 bytes including the terminating NUL, so an ordinary pathname can use 107 bytes. The short root gives 65 pathname bytes and all 24 checks pass. Both process results, literal environments, commands and raw stdout/stderr hashes are recorded. The helper's own unique temporary directories are removed in both cases. The externally owned short root is empty and removed; the pre-existing parent long root is retained.

`source-evidence-map.json` identifies exact copies of the original helper, FileSystem adapter, regular-file writer, shared logger shim and core. Helper SHA256 is a27587a75dd4e4062dfbf8bfb41473d1df01ef18053c381b526035a874bce1c7; FileSystem SHA256 is c10d26d6ea07654e52b7f7ddb58bd8eab3c0371304418661ba5ac7b34e4ff27d. The source import chain is inspected separately: the worker requires luv, FileSystem and fixture ffi; invoked write/append methods load regular_file_writer, whose dependencies are luv/ffi. Logger shim resolves the dependency-free shared logger. No invoked chain imports infra.file_watchers, and there is no ambient LUA_INIT. This is source inspection, not dynamic require tracing.

The original helper explicitly labels its controlled path-retarget and metadata-refusal fixtures over native files/descriptors. That distinction remains intact. This packet neither rewrites its expectations nor claims installed-device acceptance. It establishes that the exact previously published baseline reproduces the long-path failure and succeeds under a short root; a subsequent full canonical gate/CI receipt belongs to the parent. The parent's historical failed full-gate log remains outside this archive.

The duplicate source capture is omitted. Recover Linux/shared sources from the full baseline commits in `receiving-receipt.json` and verify the manifest. The included runner uses absolute external capture paths; relocate those explicitly when reproducing. All raw terminal receipts and source snapshots are retained, SHA256SUMS covers every other member, and all archive members are reopened and byte-compared before handoff.
