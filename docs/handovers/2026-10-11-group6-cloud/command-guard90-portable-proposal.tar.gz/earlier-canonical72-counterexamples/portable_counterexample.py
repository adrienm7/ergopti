"""Real POSIX child, modeled unsettled native protocol; no Darwin/cause claim."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

P=Path(__file__).resolve().parent
source=P/'native_http_wire_fixture.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='6c37993b0895b169197748eb8812fcce8c1648f1824654e38519d95f92f5efe1'
spec=importlib.util.spec_from_file_location('canonical72_unchanged_closure',source);W=importlib.util.module_from_spec(spec);spec.loader.exec_module(W)

class UnsettledModel:
 """Models legitimate timeout + settle(false); owns an actual POSIX child."""
 def __init__(self):self.owner=None;self.settle_calls=0
 def acquire_owned(self,arguments,native,register,**options):
  process=subprocess.Popen(arguments,start_new_session=True,**options)
  model=self
  class Owner:
   reaped=False
   def __init__(self):self.process=process
   def wait_for_exit(self,timeout):raise subprocess.TimeoutExpired('EXPLICIT modeled native wait',timeout)
   def settle(self):model.settle_calls+=1;return False
  self.owner=Owner();register(self.owner);return self.owner

fixture=None;model=UnsettledModel();facts={};closed=False
try:
 fixture=W.WireFixture(native=False);root=fixture.root
 fixture.groups=model;fixture.native_groups=object()
 primary=None
 try:
  fixture._command([sys.executable,'-I','-B','-c','import time; time.sleep(60)'],timeout=0.01)
 except subprocess.TimeoutExpired as failure:primary=failure
 assert primary is not None,'Original timeout primary was not propagated'
 assert fixture.command_fact['phase']=='settle'
 assert fixture.command_file_debt==[]
 process=model.owner.process
 assert process.poll() is None and root.exists()
 facts={'version':1,'qualification':'REAL_POSIX_CHILD_MODELED_NATIVE_PROTOCOL_ONLY','original_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'phase_before_close':fixture.command_fact['phase'],'capture_debt_before_close':len(fixture.command_file_debt),'settle_calls_before_close':model.settle_calls,'child_live_before_close':True}
 fixture.close()
 facts.update({'fixture_closed_after_close':fixture.closed,'private_root_exists_after_close':root.exists(),'child_live_after_close':process.poll() is None,'settle_calls_after_close':model.settle_calls})
 assert facts['fixture_closed_after_close'] and not facts['private_root_exists_after_close'] and facts['child_live_after_close']
 closed=True
finally:
 if model.owner is not None:
  child=model.owner.process
  if child.poll() is None:child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
  facts['outer_exact_child_reaped']=child.returncode is not None
  if child.stdin is not None and not child.stdin.closed:child.stdin.close()
 if fixture is not None and not fixture.closed:
  fixture.groups=None
  fixture.close()
assert closed and facts['outer_exact_child_reaped']
print(json.dumps(facts,sort_keys=True))
