// _shared/ui/metrics_apps/modal.js
// ======= 8/ App Drill-Down Modal =======
// =====================================================
// =====================================================

let _appModalChart = null;

// The control that opened the drill-down, which gets the focus back on close.
let _appModalOpener = null;

/**
 * Makes everything but the drill-down inert, or live again: while the modal
 * is open the keyboard and assistive technology stay in it (WCAG 2.4.3).
 * @param {boolean} inert
 */
function setAppModalBackgroundInert(inert) {
	Array.from(document.body.children).forEach((node) => {
		if (node.id !== 'app_drilldown_modal' && node.tagName !== 'SCRIPT') node.inert = inert;
	});
}

/**
 * Aggregates the manifest for a single app within the active period and
 * renders the drill-down modal: 6 stat tiles, an hourly chart, top
 * destinations, layouts, records, and hotstrings/IA share.
 * @param {string} appName
 */
function openAppDrilldown(appName) {
	const modal = document.getElementById('app_drilldown_modal');
	if (!modal) return;
	const agg = window._lastAggData;
	if (!agg) return;
	const a = agg.apps[appName];
	if (!a) return;

	// The accepted aggregate already excludes each app/day rejected by the
	// current category and date filters.
	const hourly = {};
	for (let h = 0; h < 24; h++) hourly[String(h).padStart(2, '0')] = { time_ms: 0, chars: 0 };
	Object.entries(a.modal_hourly || {}).forEach(([hour, data]) => {
		if (hourly[hour]) hourly[hour] = data;
	});

	// Title
	document.getElementById('app_modal_title').textContent = appName;

	// Stat tiles
	const focus_min = (a.time_ms || 0) / 60000;
	const density = focus_min > 0 ? (a.chars || 0) / focus_min : 0;
	const focus_lat_mean =
		(a.focus_latency_count || 0) > 0 ? a.focus_latency_sum_ms / a.focus_latency_count : 0;
	const tiles = [
		{ label: _t('ui_apps.tile_focus'), value: formatDuration(a.time_ms || 0), detail: '' },
		{
			label: _t('ui_apps.tile_typing'),
			value: formatDuration(a.typing_time || 0),
			detail:
				a.time_ms > 0
					? _t('ui_apps.modal_pct_focus').replace(
							'{pct}',
							((a.typing_time / a.time_ms) * 100).toFixed(1)
						)
					: ''
		},
		{
			label: _t('ui_apps.tile_chars'),
			value: format_int(a.chars || 0),
			detail: density > 0 ? _t('ui_apps.modal_density').replace('{n}', density.toFixed(0)) : ''
		},
		{
			label: _t('ui_apps.tile_sessions'),
			value: String(a.session_count || 0),
			detail:
				a.session_longest_ms > 0
					? _t('ui_apps.modal_longest_session').replace(
							'{dur}',
							formatDuration(a.session_longest_ms)
						)
					: ''
		},
		{
			label: _t('ui_apps.tile_focus_lat'),
			value: (a.focus_latency_count || 0) > 0 ? `${Math.round(focus_lat_mean)} ms` : '—',
			detail: a.focus_latency_count > 0 ? `n=${a.focus_latency_count}` : ''
		},
		{
			label: _t('ui_apps.tile_backspaces'),
			value: format_int(a.bs_total || 0),
			detail:
				a.chars > 0
					? _t('ui_apps.modal_backspace_pct').replace(
							'{pct}',
							((a.bs_total / a.chars) * 100).toFixed(1)
						)
					: ''
		}
	];
	document.getElementById('app_modal_tiles').innerHTML = tiles
		.map(
			(t) =>
				`<li class="app-modal-tile">
			<p class="app-modal-tile-label">${escapeHtml(t.label)}</p>
			<p class="app-modal-tile-value">${escapeHtml(t.value)}</p>
			${t.detail ? `<p class="app-modal-tile-detail">${escapeHtml(t.detail)}</p>` : ''}
		</li>`
		)
		.join('');

	// Hourly chart
	const labels = [],
		chars_arr = [];
	for (let h = 0; h < 24; h++) {
		const hh = String(h).padStart(2, '0');
		labels.push(`${hh}h`);
		chars_arr.push((hourly[hh] && hourly[hh].chars) || 0);
	}
	const ctx = document.getElementById('app_modal_hourly').getContext('2d');
	if (_appModalChart) _appModalChart.destroy();
	_appModalChart = new Chart(ctx, {
		type: 'bar',
		data: {
			labels,
			datasets: [
				{
					label: _t('ui_apps.ds_chars'),
					data: chars_arr,
					backgroundColor: 'rgba(34, 211, 238, 0.55)',
					borderRadius: 2
				}
			]
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			plugins: { legend: { display: false } },
			scales: {
				x: {
					ticks: { color: ThemeTokens.color('grey-888'), font: { size: 9 } },
					grid: { color: 'rgba(255,255,255,0.04)' }
				},
				y: {
					ticks: { color: ThemeTokens.color('grey-888'), font: { size: 9 } },
					grid: { color: 'rgba(255,255,255,0.04)' }
				}
			}
		}
	});

	// Destinations
	const dest_html =
		a.switches && Object.keys(a.switches).length > 0
			? Object.entries(a.switches)
					.sort((x, y) => y[1] - x[1])
					.slice(0, 8)
					.map(
						([dest, n]) =>
							`<li class="pair"><bdi>${escapeHtml(dest)}</bdi><data value="${n}">${n}</data></li>`
					)
					.join('')
			: `<li class="muted">${_t('ui_apps.kpi_no_backslash_out')}</li>`;
	document.getElementById('app_modal_dests').innerHTML = dest_html;

	// Layouts are projected with the same admitted app/day rows as the tiles.
	const layouts = a.modal_layouts || {};
	const layouts_html =
		Object.keys(layouts).length > 0
			? Object.entries(layouts)
					.sort((x, y) => y[1] - x[1])
					.map(
						([id, n]) =>
							`<li class="pair"><bdi>${escapeHtml(id)}</bdi><data value="${n}">${n}×</data></li>`
					)
					.join('')
			: `<li class="muted">${_t('ui_apps.kpi_no_layout')}</li>`;
	document.getElementById('app_modal_layouts').innerHTML = layouts_html;

	// Records
	const recs = [];
	if (a.session_longest_ms > 0) {
		recs.push(
			`${_t('ui_apps.modal_record_session')
				.replace('{dur}', formatDuration(a.session_longest_ms))
				.replace('{chars}', '')}`
		);
	}
	if (a.session_longest_chars > 0) {
		recs.push(`${_t('ui_typing.lbl_longest_chars')}: ${format_int(a.session_longest_chars)}`);
	}
	if ((a.burst_max_cpm || 0) > 0) {
		recs.push(`${_t('ui_apps.modal_record_burst').replace('{n}', a.burst_max_cpm.toFixed(0))}`);
	}
	if ((a.cascade_count || 0) > 0) {
		recs.push(`${_t('ui_apps.modal_record_cascade').replace('{n}', a.cascade_count)}`);
	}
	const rec_html =
		recs.length > 0
			? recs.map((r) => `<li>${r}</li>`).join('')
			: `<li class="muted">${_t('ui_apps.kpi_no_record')}</li>`;
	document.getElementById('app_modal_records').innerHTML = rec_html;

	// Hotstrings & IA
	const hs_pct = (a.chars || 0) > 0 ? (a.hs_chars / a.chars) * 100 : 0;
	const llm_pct = (a.chars || 0) > 0 ? (a.llm_chars / a.chars) * 100 : 0;
	document.getElementById('app_modal_assist').innerHTML =
		`<li>${_t('ui_apps.modal_hs_line')
			.replace('{n}', format_int(a.hs_chars || 0))
			.replace('{pct}', hs_pct.toFixed(1))}</li>` +
		`<li>${_t('ui_apps.modal_llm_line')
			.replace('{n}', format_int(a.llm_chars || 0))
			.replace('{pct}', llm_pct.toFixed(1))}</li>` +
		`<li class="muted">${_t('ui_apps.modal_total_chars').replace('{n}', format_int(a.chars || 0))}</li>`;

	// A click on the backdrop, outside the card, closes it too (bound once).
	if (!modal._backdropBound) {
		modal.addEventListener('click', (event) => {
			if (event.target === modal) window.closeAppDrilldown();
		});
		modal._backdropBound = true;
	}

	// A redraw of an open drill-down keeps the control that first opened it.
	if (modal.style.display !== 'flex') _appModalOpener = document.activeElement;
	setAppModalBackgroundInert(true);
	modal.style.display = 'flex';
	document.getElementById('app_modal_close').focus();
}

window.openAppDrilldown = openAppDrilldown;
window.closeAppDrilldown = function () {
	const modal = document.getElementById('app_drilldown_modal');
	if (!modal || modal.style.display === 'none') return;
	modal.style.display = 'none';
	setAppModalBackgroundInert(false);
	const opener = _appModalOpener;
	_appModalOpener = null;
	if (opener && opener.isConnected && typeof opener.focus === 'function') opener.focus();
};

// Escape closes the drill-down, as every dialog does.
document.addEventListener('keydown', (event) => {
	if (event.key === 'Escape') window.closeAppDrilldown();
});

// Integers in the interface language the host seeded, as the dates are; it
// was French for every locale (MET-07).
function format_int(n) {
	return new Intl.NumberFormat(window._i18n_locale || undefined).format(Math.round(n || 0));
}

document.addEventListener('DOMContentLoaded', initDashboard);

// Native readiness becomes visible after every external page dependency has run.
window.publishMetricsAppsCategories = metricsAppsPublications.categories;
window.publishMetricsAppsData = metricsAppsPublications.data;
