from pathlib import Path
import subprocess,json,sys,hashlib
root=Path('/workspace/ergopti-windows-r6-tests');packet=Path(__file__).parent
for name,expected in json.loads((packet/'candidate-hashes.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected
results=[]
for argv in json.loads((packet/'consumer-commands.json').read_text()):
 print('EXECUTE '+repr(argv),flush=True)
 result=subprocess.run(argv,cwd=root)
 results.append({'argv':argv,'exit_code':result.returncode})
 (packet/'consumer-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if result.returncode:sys.exit(result.returncode)
