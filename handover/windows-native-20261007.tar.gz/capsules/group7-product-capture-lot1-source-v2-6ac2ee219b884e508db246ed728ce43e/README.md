# Product capture lot1: native raw identity and provenance

SOURCE ONLY. No compiler/native test/hook/GUI/input run has occurred for this
packet. The primary, READY graphs, prior source capsules and shipped DLL remain
unchanged. Current Windows11 and hosted CI are the Root admission scope; Windows10
is a separately listed TODO requirement, not a new automatic gate in this packet.

This is a stock product callback change, not a new observer or benchmark. The
existing NavLowLevelKeyboardProc invokes the new effect-free provenance owner
through its existing capture branch before any terminal suppression. Every raw
entry has a native lifetime sequence; physical-side and exact SendLevel masks
are retained separately. Captured edges store immutable raw flags/time/extra,
native sequence, originating DOWN/capture token, held binding generations and
per-level modifiers. Unknown initial DOWN cannot reserve an action; only a
previously observed release establishes a new DOWN reservation. Repeats/UP keep
the original identity/generation. Private injected replay and lower-integrity
input cannot clear physical holds. Invalid mask input has explicit refusal,
never a healthy zero mask. No later GetKeyState/snapshot reconstructs edge masks.

The original FIFO and one native SendInput release owner remain authoritative.
Partial ACK's existing memmove retains the exact provenance with each suffix;
zero-progress/overflow/reentrant claims keep the delivered ownership semantics.
Existing fault status/error is not replaced by a later provenance refusal.
Two test-only raw seams add the real SDK UP flag so new raw invariants test the
same shape as Win32. All34 old native case bodies/assertions are whole-byte
preserved; new case35 contains seven recording groups, including the actual
retained queue, partial release and typed snapshot retrieval. Fake replay sinks
are explicit models, not real SendInput/native process receiving proof.

Stock boundary: ih/vk/sc InputHook data still lacks exact raw-event identity.
The new reserve_action/action_sequence fields are internal native metadata,
not an AHK effect permit and not a claimed AHK-entry witness. This lot does not
enable a second AHK/native dispatch path or close item49. Next lot must transfer
each eligible route to one native reservation owner before activating deferred
AHK receipt effects, retain old held generations, and supply an initial released
census without inventing one. The paired private AHK/C observer remains solely
qualification evidence; no pair is fabricated here and no instrumented runtime
is shipped. Missing stock callback identity cannot be solved by a global capture
guard, replay exemption, nearest-QPC pairing or post-effect reconciliation.

Root execution plan (fresh external receiving copy only): verify every baseline
and absent new file; compose all eight targets. CMake/MSVC uses the real header
constants and new sources. Build with /W4 /WX and canonical Framework/toolchain
contract. First run exact native case name "captured raw provenance stock callback"
while GUI/hook activity is prohibited; it creates no thread/window/input. Expect
case1/1 plus fixed seven recording groups. Compile each of the eight one-image
profiles in a separate owner, same unchanged corpus, require executable exit1
at its named control function, not compiler/setup refusal. Restore and run1/1.
When Root permits the existing editor GUI corpus, run all35 original+new cases.
The canonical builder retains x64/CFG/ASLR/DEP/static runtime/export checks and
hashes every new .c/.h/recipe file. Regenerate DLL+manifest via that owner only;
no preexisting binary is represented as matching these new sources.

Before activation of product routes, Root must extend the existing paired real
order receiving fixture to exercise the actual dispatcher/effect handlers,
then stock unit/E2E/startup/package/install and Windows11 physical acceptance.
No new timeout, sender mode, driver API fallback, TCC permission or policy skip.

## Narrow V2 compiler successor

V1 remains immutable. Actual strict MSVC compilation refused C4701 for the
conditionally callee-initialized observed snapshot. V2 explicitly initializes
that local aggregate to zero while preserving the independent validity guard.
No zero-initialized row can pass when provenance observation refuses. Eight
profiles are rebuilt against V2; tests and seven groups are V1 byte-exact.
Qualification of this V2 remains separate from source authoring.
