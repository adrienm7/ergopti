def native_clock_python_loader(cache):
    # Bounded pathname admission, not an atomic freshness or interpreter attestation.
    cache = Path(cache)
    if (
        not cache.is_absolute()
        or cache.resolve() != cache
        or sys.pycache_prefix != str(cache)
        or sys.flags.isolated != 1
        or sys.flags.ignore_environment != 1
        or sys.flags.no_user_site != 1
        or sys.dont_write_bytecode is not True
        or sys.flags.safe_path is not True
    ):
        raise NativeClockRefused("Native clock Python loader context refused")
    before = cache.lstat()
    if not stat.S_ISDIR(before.st_mode) or stat.S_IMODE(before.st_mode) != 0o700:
        raise NativeClockRefused("Native clock private cache mode refused")
    if any(cache.iterdir()):
        raise NativeClockRefused("Native clock private cache contains bytecode")
    after = cache.lstat()
    if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
        raise NativeClockRefused("Native clock private cache replaced")
    return {
        "version": 1,
        "isolated": 1,
        "ignore_environment": 1,
        "no_user_site": 1,
        "dont_write_bytecode": True,
        "safe_path": True,
        "cache_empty": True,
        "cache_device": before.st_dev,
        "cache_inode": before.st_ino,
    }


class NativeClockEvidence:
    """Passive exclusive file export; never another child or retirement owner."""

    def __init__(self, destination):
        self.root = Path(destination)
        if not self.root.is_absolute() or self.root.parent.resolve() != self.root.parent:
            raise NativeClockRefused("Native clock evidence parent refused")
        self.root.mkdir(mode=0o700)
        self.identity = self.root.lstat()
        self.records = {}
        self.refused = False
        if stat.S_IMODE(self.identity.st_mode) != 0o700:
            raise NativeClockRefused("Native clock evidence mode refused")

    def _write(self, name, raw):
        if name not in {
            "compile.json", "sign.json", "strict_verify.json", "clock.json",
            "clock-frame.bin", "image.bin", "source-receipt.json", "clock-receipt.json",
            "python-loader.json",
        } or type(raw) is not bytes or len(raw) > 8_388_608:
            raise NativeClockRefused("Native clock passive export refused")
        directory = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            current = os.fstat(directory)
            named = self.root.lstat()
            if (
                not stat.S_ISDIR(current.st_mode)
                or (current.st_dev, current.st_ino) != (self.identity.st_dev, self.identity.st_ino)
                or (named.st_dev, named.st_ino) != (current.st_dev, current.st_ino)
                or stat.S_IMODE(current.st_mode) != 0o700
            ):
                raise NativeClockRefused("Native clock evidence root changed")
            descriptor = os.open(
                name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                0o600, dir_fd=directory,
            )
            try:
                offset = 0
                while offset < len(raw):
                    written = os.write(descriptor, raw[offset:])
                    if written <= 0:
                        raise NativeClockRefused("Native clock evidence write refused")
                    offset += written
                acquired = os.fstat(descriptor)
                if not stat.S_ISREG(acquired.st_mode) or acquired.st_nlink != 1:
                    raise NativeClockRefused("Native clock evidence alias refused")
            finally:
                os.close(descriptor)
            final = self.root.lstat()
            if (final.st_dev, final.st_ino) != (current.st_dev, current.st_ino):
                raise NativeClockRefused("Native clock evidence root replaced")
        finally:
            os.close(directory)

    def command(self, role, fact):
        # The command boundary performs bounded memory observation only. File
        # export waits until the original clock's after reading and validation.
        try:
            if role not in ("compile", "sign", "strict_verify", "clock") or role in self.records:
                raise NativeClockRefused("Native clock passive role refused")
            received = dict(fact)
            raw = received.pop("stdout")
            if role == "clock" and (type(raw) is not bytes or len(raw) > 4096):
                raise NativeClockRefused("Native clock raw frame exceeds bound")
            self.records[role] = (received, raw if role == "clock" else None)
        except BaseException:
            self.refused = True
            raise

    def export(self, build, builder, raw, fact):
        if self.refused or set(self.records) != {"compile", "sign", "strict_verify", "clock"}:
            raise NativeClockRefused("Native clock passive records incomplete")
        if self.records["clock"][1] != raw:
            raise NativeClockRefused("Native clock raw frame changed")
        if native_clock_python_loader(self.root.parent / "private-cache") != self.loader:
            raise NativeClockRefused("Native clock private loader changed")
        for role, (record, _) in self.records.items():
            self._write(role + ".json", json.dumps(record, sort_keys=True).encode("ascii"))
        self._write("clock-frame.bin", raw)
        image = builder.regular_bytes(build.verify())[0]
        receipt = builder.regular_bytes(build.receipt_path)[0]
        if (
            hashlib.sha256(image).hexdigest() != build.image_digest
            or hashlib.sha256(receipt).hexdigest() != build.receipt_digest
        ):
            raise NativeClockRefused("Native clock original export changed")
        # These are original bytes, not reconstructed receipts or executable copies.
        self._write("image.bin", image)
        self._write("source-receipt.json", receipt)
        self._write("clock-receipt.json", json.dumps(fact, sort_keys=True).encode("ascii"))
        build.verify()
        self._write("python-loader.json", json.dumps(self.loader, sort_keys=True).encode("ascii"))


def prepare_native_clock_evidence(build):
    destination = os.environ.get("ERGOPTI_NATIVE_CLOCK_EVIDENCE")
    if destination is None:
        return
    try:
        sink = NativeClockEvidence(destination)
        sink.loader = native_clock_python_loader(sink.root.parent / "private-cache")
        build.passive_clock_evidence = sink
        build.passive_command_receiver = sink.command
    except BaseException as refused:
        if not isinstance(refused, Exception) or (
            type(refused) is wire.FixtureFailure
            and refused.args == ("Native fixture cancelled",)
        ):
            raise
        # Original receiving proceeds. Missing evidence never means qualification.


def export_native_clock_evidence(build, builder, raw, fact):
    try:
        sink = getattr(build, "passive_clock_evidence", None)
        if sink is not None:
            sink.export(build, builder, raw, fact)
    except BaseException as refused:
        if not isinstance(refused, Exception) or (
            type(refused) is wire.FixtureFailure
            and refused.args == ("Native fixture cancelled",)
        ):
            raise
