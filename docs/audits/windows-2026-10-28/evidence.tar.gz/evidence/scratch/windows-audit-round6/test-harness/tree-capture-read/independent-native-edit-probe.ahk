﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
#Warn All, StdOut
NativeUnits(Text) {
 Hex := ""
 Loop StrLen(Text)
  Hex .= Format("{:04X}", NumGet(StrPtr(Text), (A_Index - 1) * 2, "UShort"))
 return Hex
}
NativeEditProbe() {
 Window := Gui()
 EditControl := Window.AddEdit("w400 h100 Multi WantTab", "")
 Window.Show("Hide")
 try {
  if DllCall("IsWindowVisible", "Ptr", Window.Hwnd) || WinGetPID(EditControl.Hwnd) != DllCall("GetCurrentProcessId", "UInt")
   throw Error("The native Edit must be hidden and exclusively owned.")
  for Text in ["A" . Chr(0xE9), "A" . Chr(0x1F642)] {
   EditControl.Value := ""
   SendMessage(0x00C2, 1, StrPtr(Text), EditControl)
   SendMessage(0x00B1, StrLen(Text), StrLen(Text), EditControl)
   Before := NativeUnits(EditControl.Value)
   SendMessage(0x0102, 8, 1, EditControl)
   After := NativeUnits(EditControl.Value)
   FileAppend("NATIVE_EDIT_BEFORE=" . Before . ";AFTER_ONE_WM_CHAR_BACKSPACE=" . After . "`n", "*", "UTF-8")
   if Before == "004100E9" && After != "0041"
    throw Error("The BMP positive control must physically delete its final character.")
   if Before == "0041D83DDE42" && After != "0041D83D"
    throw Error("The actual independent native control does not reproduce the observed Wine half-surrogate behavior.")
  }
 } finally Window.Destroy()
}
try {
 NativeEditProbe()
 ExitApp(0)
} catch as EditProbeTopError {
 FileAppend("NATIVE_EDIT_PROBE_ERROR=" . EditProbeTopError.Message . "`n", "**", "UTF-8")
 ExitApp(1)
}
