#ifndef ERGOPTI_GROUP4_GUARDIAN_CONTRACT_H
#define ERGOPTI_GROUP4_GUARDIAN_CONTRACT_H

#include <stddef.h>
#include <stdint.h>

typedef enum {
    GG_EMPTY = 0,
    GG_READY = 1,
    GG_STOPPING = 2,
    GG_RETIRED = 3,
    GG_CONSTRUCTION_DEBT = 4,
    GG_CLOSE_DEBT = 5
} GG_Phase;

/* Native waits return 0 for nonsignaled, 1 for signaled, and -1 for error. */
typedef struct {
    void *context;
    int (*validate_job)(void *, uintptr_t, uintptr_t);
    int (*wait_parent)(void *, uintptr_t);
    int (*wait_stop)(void *, uintptr_t);
    int (*query_members)(void *, uintptr_t, uint32_t *);
    int (*terminate_job)(void *, uintptr_t);
    int (*close_handle)(void *, uintptr_t);
} GG_Port;

typedef struct {
    uintptr_t handle;
    uint32_t attempted;
    uint32_t uncertain;
} GG_Content;

typedef struct {
    uint32_t initialized;
    uint32_t job_bound;
    uint32_t termination_attempted;
    uint32_t first_error;
    uint32_t observed_members;
    uint32_t queried_zero;
    GG_Phase phase;
    uintptr_t job;
    uintptr_t parent;
    uintptr_t stop;
    uintptr_t setup_process;
    GG_Content *contents;
    size_t count;
    GG_Port port;
} GG_Owner;

/* Caller supplies a zeroed owner before acquisition and donates exact native
 * inherited capabilities. Content storage remains owned for the entire owner
 * lifetime, including debt. Serialized caller; no callback may reenter owner.
 * No PID, receipt Boolean, arbitrary IPC completion flag, or retry permission
 * is accepted by Step. Ready requires the actual process/job relationship.
 */
int GG_Init(GG_Owner *, uintptr_t, uintptr_t, uintptr_t, uintptr_t,
            GG_Content *, size_t, GG_Port);
GG_Phase GG_Step(GG_Owner *);

#endif
