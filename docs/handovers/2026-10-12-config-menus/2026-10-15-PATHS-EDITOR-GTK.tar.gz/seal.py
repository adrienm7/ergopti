import pathlib,json,hashlib,tarfile,gzip,io
P=pathlib.Path(__file__).parent;B=P.parent
H=lambda x:hashlib.sha256(x).hexdigest()
files={};summaries={}
def add(name,p):
 assert p.is_file() and not p.is_symlink(),str(p)
 files[name]=p.read_bytes()
for name in ['worker.lua','controller.py','seal.py','literal-source.tar']:add(name,P/name)
for n in ['run-with-gtk.sh','activate-gtk.sh','gtk-install-receipt.json','gtk-dependency-feasibility.json']:
 if (B/n).exists():add('runtime/'+n,B/n)
add('runtime/run-private-wizard.py',B/'gtk-current-v9/run-private-wizard.py')
for n in ['script.js','index.html']:add('proposal/'+n,B/'resume-paths-editor-proposal/formatted-v2/candidate/static/ergopti_plus/_shared/ui/paths_editor'/n)
for phase in ['candidate','literal','restored']:
 j=json.loads((P/phase/'ACTUAL-RESULTS.json').read_text());assert j['status'] in ['PASS','FAIL'] and not j['source_drift'] and not j['cleanup_errors']
 totalpass=totalfail=0
 for c in j['cases']:
  for s in c['stages']:
   a=s.get('receipt',{}).get('assertions',[]);totalpass+=sum(x['passed'] for x in a);totalfail+=sum(not x['passed'] for x in a)
 summaries[phase]={'status':j['status'],'pass':totalpass,'fail':totalfail,'cases':{c['case']:c['status'] for c in j['cases']},'source_count':j['source_count'],'source_drift':j['source_drift'],'cleanup_errors':j['cleanup_errors']}
 add(phase+'/ACTUAL-RESULTS.json',P/phase/'ACTUAL-RESULTS.json')
 for p in (P/phase).iterdir():
  if not p.is_dir() or p.name=='source':continue
  for f in p.iterdir():
   if f.is_file() and (f.name.endswith(('.stdout','.stderr','.json','.log'))):add(phase+'/'+p.name+'/'+f.name,f)
  storage=p/'config/ergopti_plus/storage.json'
  if storage.is_file():add(phase+'/'+p.name+'/storage.json',storage)
base=json.loads((P/'literal/ACTUAL-RESULTS.json').read_text())['source_files']
for phase in ['candidate','restored']:
 j=json.loads((P/phase/'ACTUAL-RESULTS.json').read_text());changed=[p for p,h in base.items() if j['source_files'][p]!=h];assert sorted(changed)==sorted(j['overlay']),changed
summary={'kind':'genuine GTK paths-editor duplicate-ready causal source receiving','phases':summaries,'literal_commit':j['literal_commit'],'literal_tree':j['literal_tree'],'exact_overlay':j['overlay'],'only_two_source_assets_change':True,'worker_and_controller_identical_across_phases':True,'no_production_or_repository_test_edits':True,'limitations':j['limitations']}
files['SUMMARY.json']=(json.dumps(summary,indent=2)+'\n').encode()
files['SHA256SUMS']=''.join(H(v)+'  '+k+'\n' for k,v in sorted(files.items())).encode()
out=B/'resume-paths-gtk-receiving.tar.gz';assert not out.exists()
with out.open('xb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(files.items()):
    m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(data))
with tarfile.open(out) as tar:
 assert len(tar.getmembers())==len(files)
 for m in tar:assert tar.extractfile(m).read()==files[m.name]
receipt={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(files),'bytes':out.stat().st_size,'summary':summary}
(P/'SEALED-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
