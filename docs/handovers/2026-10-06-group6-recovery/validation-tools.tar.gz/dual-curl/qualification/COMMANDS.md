# Prospective exclusive qualification commands

SOURCE ONLY; no commands below have run. Root controls the exclusive slot.
Proposal2 is immutable manifest98d8dfc1/sourcef73fc5a6 and independently source
ACKed. Keep all exact outputs private. Stop on the first failure. Do not silently
retry downloads, change pins, install globally, or claim setup as native30.

The observed local prerequisites are real `/usr/include/openssl/ssl.h` and
`/usr/share/keyrings/debian-archive-keyring.pgp`; no runtime/compiler execution
has validated them for this proposal. Local SDK/loader/build and network remain
unqualified. The approved command owner is exact current sourcea4882a52.

1. After the root gate is terminal and the slot explicitly granted, verify
   PINS, setup source and command owner against their manifests, then parse/format
   ONLY these scratch candidates. Source imports will occur only inside the
   following qualification after permission; no product source is changed.
2. Run receiving negatives first (five fixed cases; actual changed-owner setup
   must acquire no destination and physically retire its failed child):

```bash
source /workspace/ergopti-env.sh
python3 -B /workspace/scratch/group6-dual-curl-qualification-plan/negative_controls.py \
  --phase before \
  --proposal /workspace/scratch/group6-dual-curl-setup-proposal2 \
  --repo /workspace/ergopti \
  --keyring /usr/share/keyrings/debian-archive-keyring.pgp \
  > /workspace/scratch/group6-dual-curl-qualification-plan/before.private.log 2>&1
```

3. In that same exclusive slot run actual authenticated downloads/source build
   and actual loader/version admission. Destination must be absent. The setup
   uses the real original total1,800s plus its exact physical owner cleanup.
   Avoid an independent shell timeout that destroys its ledger:

```bash
python3 -B /workspace/scratch/group6-dual-curl-setup-proposal2/setup_validation_curl.py \
  --repo /workspace/ergopti \
  --destination /workspace/scratch/group6-dual-curl-qualified-tools \
  --openssl-prefix /usr \
  --keyring /usr/share/keyrings/debian-archive-keyring.pgp \
  --jobs 2 \
  > /workspace/scratch/group6-dual-curl-qualification-plan/setup.private.log 2>&1
```

4. Only after actual setup EXIT0 and exact private tools receipt/hash admission,
   run three further independent actual artifact negatives. Genuine signature
   passes first, then a fixed signed commitment bit-change must fail; authentic
   index and library pass first, then truncation/bit-change must fail. Original
   authenticated inputs and selected library remain unchanged:

```bash
python3 -B /workspace/scratch/group6-dual-curl-qualification-plan/negative_controls.py \
  --phase after \
  --proposal /workspace/scratch/group6-dual-curl-setup-proposal2 \
  --repo /workspace/ergopti \
  --keyring /usr/share/keyrings/debian-archive-keyring.pgp \
  --admitted-root /workspace/scratch/group6-dual-curl-qualified-tools \
  > /workspace/scratch/group6-dual-curl-qualification-plan/after.private.log 2>&1
```

5. Hash/revalidate immutable proposal/owner bytes and both admitted real ELFs,
   selected private old libraries, download commitments and retained receipt.
   Record exact setup exit, before5/after3 pass/fail/skip counts, native failure
   phases and physical child/FD closure. Release the slot explicitly.

Only afterward may root wire the normal native GET30 qualifier to actualmodern
`.../modern/bin/curl` and actuallegacy`.../legacy-root/usr/bin/curl` plus
`.../legacy-libraries`. Apply modern PATH only to the gate subprocess; legacy
LD directory only through the existing scoped argument and inherited suffix.
Parent owns actual gate/source snapshot and normal CI integration. Native30,
physical enterprise routes, whole formats and installer qualification remain
UNEXECUTED by these setup checks. Cache adoption remains unsupported.

Missing key/signature/metadata/hash/SDK/toolchain/loader/runtime is a concrete
refusal, not a reason to weaken the exact pins. Source pins may need an explicit
new independently authenticated revision if mutable official Debian metadata
has advanced. Retain failed inputs; do not count a private receipt alone as an
admission after setup failure/deadline. The already qualified canonical command
owner provides deadline/escaped-child retirement, but this new setup's native
execution has not yet run.
