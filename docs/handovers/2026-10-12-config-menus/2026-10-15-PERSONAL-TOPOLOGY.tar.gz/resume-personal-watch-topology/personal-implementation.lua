--- Runs one classified command; a failed read or process close is never empty data.
local function _personal_command(command)
	local opened, pipe = pcall(io.popen, command, "r")
	if not opened or not pipe then return nil, "personal filesystem command could not open" end
	local read, content = pcall(pipe.read, pipe, "*a")
	local closed, status = pcall(pipe.close, pipe)
	if not read or type(content) ~= "string" or not closed or status ~= true and status ~= 0 then
		return nil, "personal filesystem command did not acknowledge completion"
	end
	return content
end

--- Keeps the existing POSIX no-follow / shell-follow directory policy.
local function _personal_metadata(path)
	if posix and type(posix.stat) == "function" then
		local called, attributes = pcall(posix.stat, path)
		if not called or type(attributes) ~= "table" or attributes.dev == nil or attributes.ino == nil then
			return nil, "personal filesystem metadata is unavailable: " .. path
		end
		return { dev = attributes.dev, ino = attributes.ino, kind = attributes.type or attributes.mode }
	end
	local content, detail = _personal_command("LC_ALL=C stat -L -c '%d:%i:%F' -- '" .. path:gsub("'", "'\\''") .. "' 2>/dev/null")
	if not content then return nil, detail end
	local device, inode, kind = content:match("^(%d+):(%d+):([^\r\n]+)\n$")
	if not device then return nil, "personal filesystem metadata is malformed: " .. path end
	return { dev = device, ino = inode, kind = kind }
end

--- A refused directory listing retains all admitted coverage for explicit retry.
local function _personal_list(path)
	local entries
	if posix and type(posix.dir) == "function" then
		local called, result = pcall(posix.dir, path)
		if not called or type(result) ~= "table" then return nil, "personal directory enumeration refused: " .. path end
		entries = result
	else
		local content, detail = _personal_command("ls -1A -- '" .. path:gsub("'", "'\\''") .. "' 2>/dev/null")
		if not content then return nil, detail end
		entries = {}
		for name in content:gmatch("[^\n]+") do entries[#entries + 1] = name end
	end
	local result = {}
	for _, name in ipairs(entries) do
		if type(name) ~= "string" or name == "" or name:find("/", 1, true) then
			return nil, "personal directory enumeration returned an invalid entry"
		end
		if name ~= "." and name ~= ".." then result[#result + 1] = name end
	end
	return result
end

local function _same_personal_binding(entry, attributes)
	return entry and entry.dev == attributes.dev and entry.ino == attributes.ino and entry.kind == attributes.kind
end

--- Close requests remain pinned until the actual native callback acknowledges them.
local function _retire_personal(entry)
	entry.active, entry.staging = false, false
	if not entry.handle or entry.retired then return true end
	_personal_retiring[entry] = true
	if entry.close_requested then return false end
	if entry.started and not entry.stopped then
		local called, status, detail = pcall(entry.stop, entry.handle)
		if not called or status == nil or status == false then
			Logger.warn(LOG, "Personal watcher stop remains owned for '%s': %s.", entry.path, tostring(called and detail or status))
			return false
		end
		entry.stopped = true
	end
	entry.close_requested = true
	local called, status, detail = pcall(entry.close, entry.handle, function()
		entry.retired = true
		_personal_retiring[entry] = nil
	end)
	if not called or status == false or detail ~= nil then
		entry.close_requested = false
		Logger.warn(LOG, "Personal watcher close remains owned for '%s': %s.", entry.path, tostring(called and detail or status))
		return false
	end
	return entry.retired == true
end

local function _retry_personal_retirement()
	for entry in pairs(_personal_retiring) do _retire_personal(entry) end
end

local function _personal_rename(events)
	if type(events) ~= "table" then return false end
	if events.rename == true then return true end
	for _, event in ipairs(events) do if event == "rename" then return true end end
	return false
end

--- Admits only this exact active lexical binding and its original session.
local function _personal_event(entry, err, filename, events)
	if entry.epoch ~= _personal_epoch or _personal_root == nil or entry.retired or entry.close_requested then return end
	if not entry.active then
		if entry.staging then _personal_revision = _personal_revision + 1 end
		return
	end
	if _personal_entries[entry.path] ~= entry then return end
	if err then
		Logger.warn(LOG, "Personal fs_event error on '%s': %s.", entry.path, tostring(err))
		return
	end
	local changed, topology = entry.path, false
	if entry.kind == "directory" then
		if type(filename) == "string" and filename ~= "" then
			changed = entry.path .. "/" .. filename
			local previous = _personal_entries[changed]
			if _is_toml(filename) then
				topology = _personal_rename(events)
			elseif previous and previous.kind == "directory" or _is_dir(changed) then
				topology = true
			else
				return
			end
		elseif type(events) == "table" and next(events) ~= nil then
			topology = true
		else
			return
		end
	else
		topology = _personal_rename(events)
	end
	if topology then
		_personal_dirty = true
		_personal_revision = _personal_revision + 1
	end
	_schedule_reload("personal source: " .. changed, { changed })
end

--- Arms new directories before enumerating them; queued events cannot fall into a gap.
local function _new_personal_entry(path, attributes, epoch)
	local entry = { path = path, dev = attributes.dev, ino = attributes.ino, kind = attributes.kind,
		epoch = epoch, active = false, staging = true }
	if not luv then
		entry.last_mtime = _mtime(path)
		if entry.last_mtime == nil then return nil, "personal polling timestamp is unavailable: " .. path end
		return entry
	end
	entry.stop, entry.close = luv.fs_event_stop, luv.close
	local called, handle = pcall(luv.new_fs_event)
	if not called or not handle then return nil, "personal watcher allocation refused: " .. path end
	entry.handle = handle
	local protected, activated, detail = pcall(luv.fs_event_start, handle, path, FS_EVENT_FLAGS, function(err, filename, events)
		_personal_event(entry, err, filename, events)
	end)
	if not protected or activated == nil or activated == false then
		_retire_personal(entry)
		return nil, "personal watcher activation refused: " .. path .. ": " .. tostring(protected and detail or activated)
	end
	entry.started = true
	return entry
end

--- Produces a complete census, keeping ambiguous or refused subtrees unjudged.
local function _personal_census(path, depth, desired, staged, previous, epoch)
	if depth > SCAN_MAX_DEPTH then
		Logger.warn(LOG, "Personal hotstrings scan hit max depth %d at '%s' — not descending further (directory cycle?).", SCAN_MAX_DEPTH, path)
		return true
	end
	local attributes, detail = _personal_metadata(path)
	if not attributes then return false, detail end
	if attributes.kind ~= "directory" then return false, "personal directory is unavailable: " .. path end
	local function admit(target, image)
		local entry = previous[target]
		if not _same_personal_binding(entry, image) then
			entry, detail = _new_personal_entry(target, image, epoch)
			if not entry then return false end
			staged[#staged + 1] = entry
		end
		desired[target] = entry
		return true
	end
	if not admit(path, attributes) then return false, detail end
	local entries
	entries, detail = _personal_list(path)
	if not entries then return false, detail end
	for _, name in ipairs(entries) do
		local child = path .. "/" .. name
		local image
		image, detail = _personal_metadata(child)
		if not image then return false, detail end
		if image.kind == "directory" then
			local accepted
			accepted, detail = _personal_census(child, depth + 1, desired, staged, previous, epoch)
			if not accepted then return false, detail end
		elseif _is_toml(name) then
			if not admit(child, image) then return false, detail end
			local after
			after, detail = _personal_metadata(child)
			if not after or not _same_personal_binding(desired[child], after) then return false, detail or "personal file changed during admission" end
		end
	end
	local after
	after, detail = _personal_metadata(path)
	if not after or not _same_personal_binding(desired[path], after) then return false, detail or "personal directory changed during admission" end
	return true
end

_reconcile_personal = function()
	if _personal_root == nil then _personal_dirty = false; return true end
	local epoch, revision, previous = _personal_epoch, _personal_revision, _personal_entries
	local desired, staged = {}, {}
	local called, accepted, detail = pcall(_personal_census, _personal_root, 1, desired, staged, previous, epoch)
	if not called or not accepted or epoch ~= _personal_epoch or previous ~= _personal_entries or revision ~= _personal_revision then
		for _, entry in ipairs(staged) do _retire_personal(entry) end
		Logger.warn(LOG, "Personal watcher coverage remains unchanged; reconciliation refused: %s.", tostring(called and detail or accepted))
		return false
	end
	_personal_entries, _personal_dirty = desired, false
	for _, entry in pairs(desired) do entry.staging, entry.active = false, true end
	for path, entry in pairs(previous) do if desired[path] ~= entry then _retire_personal(entry) end end
	return true
end
