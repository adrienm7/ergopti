﻿; modules/llm/ollama_runtime_source_spec.ahk
#Requires AutoHotkey v2.0

/** Captures descriptor lookup/allocation expectations; native worker authenticates. */
class OllamaRuntimeSourceSpec {
	__New(Receipt) {
		if !(Receipt is Map) || !(Receipt.Get("ok", false) is Integer) || Receipt["ok"] != true
				|| Receipt.Get("schema", 0) != 1 || Receipt.Get("phase", "") != "published"
			throw TypeError("Runtime source requires a complete published expectation.")
		this.Spec := Map()
		for name in ["RootPath", "RootIdentity", "Ticket", "StageIdentity", "ManifestHash",
			"DescriptorIdentity", "DescriptorHash", "RecordCapacity", "PathCapacity", "Executable"] {
			if !Receipt.Has(name)
				throw ValueError("Runtime source expectation is incomplete.", -1, name)
			this.Spec[name] := Receipt[name]
		}
		for name in ["RootPath", "Executable"]
			if !(this.Spec[name] is String) || !RegExMatch(this.Spec[name], "\A[A-Za-z]:\\")
					|| this._HasNul(this.Spec[name]) || InStr(this.Spec[name], "`r") || InStr(this.Spec[name], "`n")
				throw ValueError("Runtime source paths require complete native absolute paths.")
		for name in ["RootIdentity", "StageIdentity", "DescriptorIdentity"]
			if !RegExMatch(this.Spec[name], "\A[0-9a-f]{8}:[0-9a-f]{16}\z")
				throw ValueError("Runtime source native identity is malformed.")
		for name in ["ManifestHash", "DescriptorHash"]
			if !RegExMatch(this.Spec[name], "\A[0-9a-f]{64}\z")
				throw ValueError("Runtime source digest is malformed.")
		if !RegExMatch(this.Spec["Ticket"], "\A[0-9a-f]{32}\z")
			throw ValueError("Runtime source ticket is malformed.")
		for name in ["RecordCapacity", "PathCapacity"]
			if !(this.Spec[name] is Integer) || this.Spec[name] <= 0 || this.Spec[name] > 0xffffffff
				throw ValueError("Runtime source wire capacity is malformed.")
		if 80 + this.Spec["RecordCapacity"] * 72 + this.Spec["PathCapacity"] * 2 > 0xffffffff
			throw ValueError("Runtime source channel exceeds the native allocation wire.")
		if Receipt.Has("ModelsDirectory") || Receipt.Has("ModelsFolderName") || Receipt.Has("ModelsIdentity") {
			for name in ["ModelsDirectory", "ModelsFolderName", "ModelsIdentity"] {
				if !(Receipt.Get(name, 0) is String) || Receipt[name] == "" || this._HasNul(Receipt[name])
					throw ValueError("Models source expectations require the complete captured tuple.")
				this.Spec[name] := Receipt[name]
			}
			if !RegExMatch(this.Spec["ModelsDirectory"], "\A[A-Za-z]:\\")
					|| !RegExMatch(this.Spec["ModelsIdentity"], "\A[0-9a-f]{8}:[0-9a-f]{16}\z")
				throw ValueError("Models source expectations require a native path and identity.")
		}
		local expected := this.Spec["RootPath"] . "\.stage-" . this.Spec["Ticket"] . "\ollama.exe"
		if this.Spec["Executable"] != expected
			throw ValueError("Runtime executable is not the captured descriptor container member.")
	}

	_HasNul(Text) {
		; Native string-search treats a NUL needle as empty. Inspect stored units.
		loop StrLen(Text)
			if NumGet(StrPtr(Text), (A_Index - 1) * 2, "UShort") == 0
				return true
		return false
	}

	ForTarget(Target) {
		if !(Target is Map) || Target.Get("executable", "") != this.Spec["Executable"]
			throw ValueError("Runtime target differs from its exact source expectation.")
		if Target.Has("models_folder_name") {
			if this.Spec.Get("ModelsDirectory", "") != Target.Get("models_dir", "")
					|| this.Spec.Get("ModelsFolderName", "") != Target["models_folder_name"]
				throw ValueError("The models target differs from its captured native publication tuple.")
		} else if this.Spec.Has("ModelsDirectory")
			throw ValueError("The models target omitted the acquired shared policy.")
		local result := this.Spec.Clone()
		result.Delete("Executable")
		return result
	}
}

/** Owns consent generation and routes stop/reload/disable to physical retirement. */
class OllamaManagedRuntime {
	__New(Options, CurrentFn, ConsentFn) {
		if !(Options is Map) || !HasMethod(CurrentFn, "Call") || !HasMethod(ConsentFn, "Call")
			throw TypeError("Managed runtime requires shared current and explicit consent owners.")
		this.Options := Options.Clone()
		this.CurrentFn := CurrentFn
		this.ConsentFn := ConsentFn
		this.Generation := 0
		this.Owner := 0
		this.Source := 0
	}

	Start(Receipt, Target, OnExit := 0) {
		local previous_critical := Critical("On")
		try {
			if IsObject(this.Owner) && this.Owner.HasOwner()
				return false
			local generation := ++this.Generation
			this.Source := OllamaRuntimeSourceSpec(Receipt)
			local options := this.Options.Clone()
			options["source_spec"] := ObjBindMethod(this.Source, "ForTarget")
			this.Owner := OllamaRuntimeOwner(options)
			local owner := this.Owner
		} finally Critical(previous_critical)
		return owner.Start(Target, Map("authorize", ObjBindMethod(this, "_Consent", generation),
			"is_current", ObjBindMethod(this, "_Current", generation)), OnExit)
	}

	_Current(Generation, Target) {
		if Generation != this.Generation || A_IsSuspended
			return false
		local current := this.CurrentFn.Call(Target.Clone())
		return current is Integer && current == true && Generation == this.Generation && !A_IsSuspended
	}

	_Consent(Generation, Target) {
		if !this._Current(Generation, Target)
			return false
		local accepted := this.ConsentFn.Call(Target.Clone())
		return accepted is Integer && accepted == true && this._Current(Generation, Target)
	}

	/** Revokes publication first; false means the exact owner still retains debt. */
	Invalidate() {
		local previous_critical := Critical("On")
		try {
			this.Generation += 1
			local owner := this.Owner
		} finally Critical(previous_critical)
		return !IsObject(owner) || owner.Stop()
	}

	HasOwner() {
		return IsObject(this.Owner) && this.Owner.HasOwner()
	}
}
