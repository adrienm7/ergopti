from pathlib import Path
import json,hashlib,collections,datetime
from zoneinfo import ZoneInfo
s=Path('/workspace/scratch/oct28-ci-final33')
monitor_exit=json.loads((s/'monitor-resumed-exit.json').read_text());assert monitor_exit['exit_code']==0
p=s/'public-latest.json';d=json.loads(p.read_text());run=d['run'];jobs=d['jobs']['jobs']
assert run['id']==40739753554 and run['head_sha']=='80e8092f2051ad4927dcc880f9585a0e69f6613a'
assert run['status']=='completed' and run['conclusion'] is not None
assert len(jobs)==d['jobs']['total_count'] and len({j['id']for j in jobs})==len(jobs)
assert all(j['status']=='completed' for j in jobs)
def par(v):return datetime.datetime.fromisoformat(v.replace('Z','+00:00')).astimezone(ZoneInfo('Europe/Paris')).isoformat() if v else None
out={'run_id':run['id'],'attempt':run['run_attempt'],'url':run['html_url'],'source_head':run['head_sha'],'status':run['status'],'conclusion':run['conclusion'],'started_paris':par(run['run_started_at']),'updated_paris':par(run['updated_at']),'observed_paris':d['observed_paris'],'job_count':len(jobs),'job_conclusions':dict(collections.Counter(j['conclusion']for j in jobs)),'jobs':[],'retained_proofs':{},'snapshot_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'monitor_actual_child_exit':monitor_exit,'scope':'Exact published80 source. Not combined34/37ad source. All actual jobs/steps including cleanup and artifact tails are retained; no retries, cancellation or workflow/source edits.'}
for j in jobs:
 out['jobs'].append({'id':j['id'],'name':j['name'],'conclusion':j['conclusion'],'started_paris':par(j['started_at']),'completed_paris':par(j['completed_at']),'runner_id':j['runner_id'],'steps':[{'number':x['number'],'name':x['name'],'conclusion':x['conclusion'],'started_paris':par(x['started_at']),'completed_paris':par(x['completed_at'])}for x in j['steps']]})
for name in ['lua-executed-counts.json','native26-evidence.json','native-intel-evidence.json','tooltip-native-evidence.json','macos-build-evidence.json','common-data-source-failure-evidence.json','installed-macos26-evidence.json','installed-macos15-symlinks-evidence.json','installed-macos15-tilde-evidence.json','installed-macos15-cold-evidence.json','installed-clean-cancellation-evidence.json']:
 q=s/name;out['retained_proofs'][name]={'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
q=s/'final-receipt.json';q.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'path':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'run_id':out['run_id'],'conclusion':out['conclusion'],'counts':out['job_conclusions']}))
