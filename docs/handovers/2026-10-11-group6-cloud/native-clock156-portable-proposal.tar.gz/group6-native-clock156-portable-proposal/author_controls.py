"""Prepare fixed physical client loading and exactly13 frozen clock controls."""
from pathlib import Path
import ast
import json
import hashlib

BASE = Path(__file__).resolve().parent
FROZEN = BASE.parent / 'group6-native-clock-role-proposal/portable_clock_contract_tests.py'
source = FROZEN.read_text()
classes = ('ClockFrameContractTests', 'ClockContextContractTests')
tree = ast.parse(source)
body = '\n\n'.join(ast.get_source_segment(source, node) for node in tree.body if isinstance(node, ast.ClassDef) and node.name in classes)
original = {node.name: ast.get_source_segment(source, node) for node in tree.body if isinstance(node, ast.ClassDef) and node.name in classes}
identities = {node.name: sorted(item.name for item in node.body if isinstance(item, ast.FunctionDef) and item.name.startswith('test')) for node in tree.body if isinstance(node, ast.ClassDef) and node.name in classes}
assert [len(identities[name]) for name in classes] == [8, 5]
header = '''"""Portable clock frame/context controls; no Swift or Darwin acceptance.

Load the actual independent receiver through a fixed repository-relative path.
These controls never run its native TestCase, native setup, compiler or helper.
"""

import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "static/ergopti_plus/macos/tests/support/native_http_wire_client_receiving.py"
spec = importlib.util.spec_from_file_location("portable_clock_native_receiver", SOURCE)
CLIENT = importlib.util.module_from_spec(spec)
spec.loader.exec_module(CLIENT)
frame = CLIENT.native_clock_frame
epoch = CLIENT.native_clock_epoch
Refused = CLIENT.NativeClockRefused


'''
selector = '\n\nEXPECTED_TEST_IDENTITIES = ' + repr({name: tuple(values) for name, values in identities.items()}) + '\n\n\ndef enrolled_cases():\n    """Expose exactly8+5 controls; any identity or census drift refuses import."""\n    classes = (ClockFrameContractTests, ClockContextContractTests)\n    for case in classes:\n        actual = tuple(unittest.defaultTestLoader.getTestCaseNames(case))\n        if case.__module__ != __name__ or actual != EXPECTED_TEST_IDENTITIES[case.__name__]:\n            raise RuntimeError("Portable native clock control identity refused")\n    if sum(len(EXPECTED_TEST_IDENTITIES[case.__name__]) for case in classes) != 13:\n        raise RuntimeError("Portable native clock control census refused")\n    return classes\n'
after = header + body + selector
new = ast.parse(after)
assert {node.name: ast.get_source_segment(after, node) for node in new.body if isinstance(node, ast.ClassDef)} == original
path = BASE / 'candidate/tools/test/macos_native_http_clock_contract_controls.py'
path.write_text(after)
(BASE / 'controls-manifest.json').write_text(json.dumps({'qualification': 'SOURCE_ONLY_UNFORMATTED_UNRUN_NO_ADOPTION_NO_NATIVE_CREDIT', 'methods': identities, 'census': 13, 'source_path': str(path.relative_to(BASE)), 'sha256': hashlib.sha256(after.encode()).hexdigest(), 'frozen_authored13_class_bodies': 'BYTE_EXACT', 'loader': 'fixed physical actual client; standard library only; no fragment exec', 'dependencies': 'unqualified until current owning136 and root-corrected client preimages are frozen; actual client definitions only, no native setup execution'}, indent=2) + '\n')
print(json.dumps({'controls': str(path), 'sha256': hashlib.sha256(after.encode()).hexdigest(), 'methods': 13}, sort_keys=True))
