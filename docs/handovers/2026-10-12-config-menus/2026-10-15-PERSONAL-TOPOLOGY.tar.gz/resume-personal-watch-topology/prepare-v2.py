from pathlib import Path
b=Path('/workspace/.ergopti-cloud/resume-personal-watch-topology');s=(b/'candidate2-prepared.lua').read_text()
s=s.replace('local _personal_root, _personal_dirty = nil, false','local _personal_root, _personal_dirty, _personal_retry_at = nil, false, nil',1)
s=s.replace('local RuntimeLog = require("diagnostics.runtime_log")','local RuntimeLog = require("diagnostics.runtime_log")\nlocal Shell = require("adapters.shell_runner")',1)
a=s.index('--- Runs one classified command;');z=s.index('--- Keeps the existing POSIX no-follow',a)
s=s[:a]+'''--- Uses the shared checked command owner; partial failed output is never empty data.
local function _personal_command(command)
	local called, completed, output, detail = pcall(Shell.exec_checked, command)
	if not called or completed ~= true or type(output) ~= "string" then
		return nil, called and detail or "personal filesystem command refused"
	end
	return output
end

'''+s[z:]
s=s.replace('"LC_ALL=C stat -L -c \'%d:%i:%F\' -- \'" .. path:gsub("\'", "\'\\\\\'\'") .. "\' 2>/dev/null"','"LC_ALL=C stat -L -c \'%d:%i:%F\' -- " .. Shell.quote(path) .. " 2>/dev/null"',1)
s=s.replace('"ls -1A -- \'" .. path:gsub("\'", "\'\\\\\'\'") .. "\' 2>/dev/null"','"ls -1A -- " .. Shell.quote(path) .. " 2>/dev/null"',1)
assert 'path:gsub' not in s[s.index('local function _personal_command'):s.index('local function _same_personal_binding')]
s=s.replace('''	local result = {}
	for _, name in ipairs(entries) do
		if type(name) ~= "string" or name == "" or name:find("/", 1, true) then''','''	local result, seen = {}, {}
	for _, name in ipairs(entries) do
		if type(name) ~= "string" or name == "" or name:find("/", 1, true) or seen[name] then''',1)
s=s.replace('''		if name ~= "." and name ~= ".." then result[#result + 1] = name end
''','''		seen[name] = true
		if name ~= "." and name ~= ".." then result[#result + 1] = name end
''',1)
s=s.replace('''		if entry.staging then _personal_revision = _personal_revision + 1 end
''','''		if entry.staging then
			_personal_revision = _personal_revision + 1
			if not err then
				local changed = type(filename) == "string" and filename ~= "" and entry.path .. "/" .. filename or entry.path
				_schedule_reload("personal staging activity: " .. changed, { changed })
			end
		end
''',1)
s=s.replace('''		if not reconciled then
			_reload_deadline = _now_ms() + _debounce_sec * 1000
			return
		end
	end
	_reload_deadline = nil''','''		_personal_retry_at = reconciled and nil or _now_ms() + _debounce_sec * 1000
		-- Coverage is observational: refusal never withholds an accepted source
		-- burst. Actual activity while staging still extends the shared settle.
		if _reload_deadline and _now_ms() < _reload_deadline then return end
	end
	_reload_deadline = nil''',1)
s=s.replace('''	_personal_entries, _personal_dirty = desired, false
''','''	local changed = false
	for path, entry in pairs(desired) do if previous[path] ~= entry then changed = true end end
	for path, entry in pairs(previous) do if desired[path] ~= entry then changed = true end end
	_personal_entries, _personal_dirty = desired, false
''',1)
s=s.replace('''	for path, entry in pairs(previous) do if desired[path] ~= entry then _retire_personal(entry) end end
	return true
end''','''	for path, entry in pairs(previous) do if desired[path] ~= entry then _retire_personal(entry) end end
	return true, changed
end

--- Repairs coverage on a bounded independent deadline, never once per idle pump.
local function _retry_personal_coverage()
	if not _personal_retry_at or _now_ms() < _personal_retry_at or _reload_deadline then return end
	local epoch = _personal_epoch
	local accepted, changed = _reconcile_personal()
	if epoch ~= _personal_epoch then return end
	_personal_retry_at = accepted and nil or _now_ms() + _debounce_sec * 1000
	if accepted and changed then
		-- Files could change while their refused bindings were unobserved. Admit
		-- one fresh consumer read through the existing settle/generation owner.
		_schedule_reload("personal coverage repaired", { _personal_root })
	end
end''',1)
s=s.replace('''			if not _reconcile_personal() then _reload_deadline = _now_ms() + _debounce_sec * 1000 end''','''			if not _reconcile_personal() then _personal_retry_at = _now_ms() + _debounce_sec * 1000 end''',1)
s=s.replace('''	_check_deadline()

	-- Pump-mode''','''	_check_deadline()
	_retry_personal_coverage()

	-- Pump-mode''',1)
s=s.replace('''	_personal_root, _personal_dirty = nil, false
''','''	_personal_root, _personal_dirty, _personal_retry_at = nil, false, nil
''',1)
# Lua's `true and nil or fallback` is never a nil selector.
s=s.replace('''		_personal_retry_at = reconciled and nil or _now_ms() + _debounce_sec * 1000''','''		if reconciled then _personal_retry_at = nil else _personal_retry_at = _now_ms() + _debounce_sec * 1000 end''')
s=s.replace('''	_personal_retry_at = accepted and nil or _now_ms() + _debounce_sec * 1000''','''	if accepted then _personal_retry_at = nil else _personal_retry_at = _now_ms() + _debounce_sec * 1000 end''')
(b/'candidate2-prepared.lua').write_text(s)
print('candidate2_lines',len(s.splitlines()))
