# Genuine personal-info nil-refusal mutation coordinate successor

This private one-file Source proposal repairs the real negative-control mutation
coordinate shared by the macOS and Linux personal-info source providers. Linux
now contains three genuine `if not current() then return nil end` guards after
the About header addition; the original personal-info guard immediately precedes
`return current, template` on both providers. The full actual guard-plus-tail
coordinate occurs exactly once in each pinned provider.

Only the mutation tuple gains that adjacent real return tail. The after-image
still changes solely the nil refusal to `nil or { foreign = true }`; the tail
remains exact. The uniqueness assertion stays one, every negative publication
and typed assertion stays false, and every inverse assertion stays true. No
occurrence index, synthetic owner, production source edit or assertion change is
used. The library and native files in context are immutable read-only pins, not
receiving source edits.

All original assert-dot source lines are byte-identical, and reversing the two
coordinate literals recreates the complete exact test preimage. All text is LF.
This static evidence establishes coordinate uniqueness, not runtime correctness.

The actual writable V3 target failure remains retained at the path and hash in
SOURCE-ONLY-PROPOSAL.json. Earlier V3 sandbox EROFS evidence also remains intact.
No JS/native runtime, generator, Git, Root source, index or ref was modified.
Root owns formatting, actual target execution and subsequent complete gates.
