const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const assert = require('node:assert/strict');
const target = process.argv[2];
const input = process.argv[3];
const originalThrows = assert.throws;
let count = 0;
assert.throws = (...args) => { count++; return originalThrows(...args); };
try {
 const script = new Module(target);
 script.filename = target;
 script.paths = Module._nodeModulePaths(path.dirname(target));
 script._compile(fs.readFileSync(input, 'utf8'), target);
 assert.equal(count, 22, 'every new negative control executes');
} finally {
 console.log(JSON.stringify({ actual_negative_controls_executed: count }));
}
