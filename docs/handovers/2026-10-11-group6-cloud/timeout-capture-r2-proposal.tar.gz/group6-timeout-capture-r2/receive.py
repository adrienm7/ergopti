from pathlib import Path
import argparse
import importlib.util
import sys
import unittest

BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('subject', choices=('original', 'first', 'candidate'))
parser.add_argument('--additional-only', action='store_true')
parser.add_argument('--cancellation-only', action='store_true')
parser.add_argument('--repository', default='/workspace/ergopti')
options = parser.parse_args()
ROOT = Path(options.repository).resolve()
test_path = ROOT / 'tools/test/macos_native_http_receiving_facts_test.py'
namespace = {'__name__': 'isolated_native_trust_receiving', '__file__': str(test_path)}
source = (BASE / 'candidate/tools/test/macos_native_http_receiving_facts_test.py').read_text()
exec(compile(source, str(test_path), 'exec'), namespace)
fixture_root = ROOT if options.subject == 'original' else BASE / ('comparison' if options.subject == 'first' else 'candidate')
fixture_path = fixture_root / 'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
spec = importlib.util.spec_from_file_location('isolated_wire_' + options.subject, fixture_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
namespace['WIRE'] = module
suite = unittest.TestSuite()
for name, value in namespace.items():
    if isinstance(value, type) and issubclass(value, unittest.TestCase):
        if options.cancellation_only:
            selected = name == 'NativeTimedAddCancellationTests'
        elif options.additional_only:
            selected = name == 'NativeTimedAddCaptureObservationTests'
        else:
            selected = True
        if selected:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(value))
result = unittest.TextTestRunner(verbosity=2).run(suite)
print('receiving subject=' + options.subject + ' total=' + str(result.testsRun) + ' failures=' + str(len(result.failures)) + ' errors=' + str(len(result.errors)) + ' skips=' + str(len(result.skipped)))
sys.exit(0 if result.wasSuccessful() else 1)
