from pathlib import Path
import os,sys,subprocess,signal,tempfile,time,json,hashlib,shlex,datetime,zipfile
ROOT=Path('/workspace/ergopti-macos-integration');OUT=Path('/workspace/scratch/oct28-protected-bootstrap-report');SCRIPT=ROOT/'static/ergopti_plus/macos/modules/llm';source=(SCRIPT/'native_python_bootstrap.sh').read_text();caller=(SCRIPT/'ensure-ollama-native-deps.sh').read_text()
start=caller.index('report_failed_stage() {');end=caller.index('trap report_failed_stage EXIT',start)+len('trap report_failed_stage EXIT');trap=caller[start:end]
rows=[]
for mode in ['failure','group_term','python_group_term']:
 with tempfile.TemporaryDirectory(prefix=mode+'-',dir=OUT)as temporary:
  case=Path(temporary);home=case/'home';tmp=case/'tmp';home.mkdir();tmp.mkdir();ready=case/'ready.json';fixture=case/'download.py';wheel=case/'wheel.whl';version=(SCRIPT/'uv-release.sh').read_text().split('UV_RELEASE_VERSION=\"',1)[1].split('\"',1)[0]
  with zipfile.ZipFile(wheel,'w')as archive:archive.writestr(f'uv-{version}.data/scripts/uv',b'#!/bin/sh\nexit 0\n')
  fixture.write_text("""import os,sys,pathlib,json,signal,shutil
assert len(sys.argv)==6,sys.argv
url,destination,digest,empty,policy=sys.argv[1:]
assert (url,digest)in[(os.environ['EXPECTED_URL'],os.environ['EXPECTED_SHA']),(os.environ['EXPECTED_PY_URL'],os.environ['EXPECTED_PY_SHA'])]
assert empty=='' and policy=='resilient'
p=pathlib.Path(destination)
assert p.name==('uv.whl'if url==os.environ['EXPECTED_URL']else os.environ['EXPECTED_PY_BASENAME']) and p.parent.parent==pathlib.Path(os.environ['TMPDIR']) and p.parent.name.startswith('ergopti-native-runtime-python.')
if os.environ['MODE']=='python_group_term'and url==os.environ['EXPECTED_URL']:
 shutil.copyfile(os.environ['FIXTURE_WHEEL'],p);sys.exit(0)
p.write_bytes(b'controlled partial download bytes')
ready=pathlib.Path(os.environ['READY']);pending=ready.with_suffix('.pending')
pending.write_text(json.dumps({'payload':str(p),'owner_pid':os.getppid(),'download_pid':os.getpid()}));pending.replace(ready)
if os.environ['MODE']=='failure':sys.exit(1)
signal.pause()
""")
  run=case/'subject.sh';run.write_text('set -eu\nset -o pipefail\n'+f'SCRIPT_DIR={shlex.quote(str(SCRIPT))}\n'+f'source {shlex.quote(str(SCRIPT/"uv-release.sh"))}\n'+source+'\nBOOTSTRAP_STAGE=start\n'+trap+'\nexport EXPECTED_URL="$UV_WHEEL_ARM64_URL" EXPECTED_SHA="$UV_WHEEL_ARM64_SHA256"\n'+f'managed_bootstrap_download() {{ export EXPECTED_PY_URL=\"$MANAGED_PYTHON_URL\" EXPECTED_PY_SHA=\"$MANAGED_PYTHON_SHA256\" EXPECTED_PY_BASENAME=\"$MANAGED_PYTHON_CACHE_BASENAME\"; {shlex.quote(sys.executable)} {shlex.quote(str(fixture))} "$@"; }}\n'+'native_bootstrap_python "$HOME/Library/Application Support/Ergopti/native-bootstrap"\n')
  env=dict(os.environ,HOME=str(home),TMPDIR=str(tmp),READY=str(ready),MODE=mode,ERGOPTI_NATIVE_ARCH='arm64',FIXTURE_WHEEL=str(wheel))
  proc=subprocess.Popen(['/bin/bash',str(run)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  try:
   deadline=time.monotonic()+5
   while not ready.exists() and proc.poll()is None and time.monotonic()<deadline:time.sleep(.01)
   assert ready.exists(),proc.communicate(timeout=5)
   receipt=json.loads(ready.read_text())
   if mode in('group_term','python_group_term'):os.killpg(proc.pid,signal.SIGTERM)
   stdout,stderr=proc.communicate(timeout=5);payload=Path(receipt['payload']);live=[]
   for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():continue
    try:
     fields=(entry/'stat').read_text().split(') ',1)[1].split()
     if int(fields[2])==proc.pid and fields[0]!='Z':live.append({'pid':int(entry.name),'state':fields[0]})
    except(FileNotFoundError,ProcessLookupError,PermissionError):pass
   row={'case':mode,'actual_exit':proc.returncode,'stdout':stdout.decode(),'stderr':stderr.decode(),'workspace_exists':payload.parent.exists(),'partial_exists':payload.exists(),'partial_bytes':payload.read_bytes().decode()if payload.exists()else None,'live_group_members':live,'receipt':receipt,'observed_before_fixture_retirement':True}
   assert not live,row
   if mode=='failure':assert proc.returncode==1 and not payload.parent.exists(),row
   else:assert proc.returncode==-signal.SIGTERM and payload.parent.is_dir() and payload.read_bytes()==b'controlled partial download bytes',row
   rows.append(row)
  finally:
   if proc.poll()is None:os.killpg(proc.pid,signal.SIGKILL);proc.communicate(timeout=5)
result={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'at_paris':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).isoformat(),'protected_unfixed_bug_confirmed':True,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'caller_sha256':hashlib.sha256(caller.encode()).hexdigest(),'helper_bytes_unchanged':True,'caller_trap_bytes_unchanged':True,'rows':rows,'scope':'Linux-host actual Bash, filesystem and process-group SIGTERM over unchanged production helper/caller EXIT trap. Only managed_bootstrap_download is replaced by a strict local fixture which checks all five real arguments and creates actual partial wheel/archive bytes (Python-stage probe receives an inert local uv zip at the same strict trusted download boundary); no Darwin/native PTY execution or network download claimed. Own temporary fixtures retired after observations.','no_repository_source_or_index_change':True,'no_native_stat_port_needed':True,'not_fixed_reason':'Owned Ollama installation explicitly excluded by user; report only.'}
(OUT/'proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
