'use strict';
// Source-bound AHK regex/structural model. This does not execute AutoHotkey.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const packet = process.argv[2] || '/tmp/group6-windows-route-origin-diagnostic-r1';
const ahk = path.join(packet, 'proposed/static/ergopti_plus/windows/tests/unit/test_managed_routes_native.ahk');
const admitted = 'c88aaea21f2db7c16ec6cda0f06c64dd08005e735cc221a7bc30a02e82772173';
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
assert.equal(hash(ahk), admitted);
const bytes = fs.readFileSync(ahk);
assert.ok(bytes.subarray(0, 3).equals(Buffer.from([0xef, 0xbb, 0xbf])));
assert.ok(!bytes.includes(13));
const source = bytes.toString('utf8');
const anchor = '\tPattern :=';
const end = '\n\tif !RegExMatch(Err, Pattern, &Fact)';
assert.equal(source.split(anchor).length - 1, 1);
assert.equal(source.split(end).length - 1, 1);
const block = source.slice(source.indexOf(anchor) + anchor.length, source.indexOf(end));
const pieces = [...block.matchAll(/"([^"]*)"/g)].map(x => x[1]);
assert.equal(pieces.length, 7);
const expression = pieces.join('').replace(/^m\)/, '').replaceAll('`r', '\r');
const guards = [
  'StrLen(Err) > 8192',
  'RegExMatch(Err, Pattern, , Fact.Pos + Fact.Len)',
  'Integer(Fact[4]) < -2147483648 || Integer(Fact[4]) > 2147483647',
  'Fact[3] == "0" && Fact[4] != "0"',
  'Integer(Fact[8]) < -1 || Integer(Fact[8]) > 4096',
  'Fact[6] != "hashtable" && (Fact[7] != "unknown" || Fact[8] != "-1" || Fact[9] != "unknown")',
  'Fact[8] != "1" && (Fact[10] != "unknown" || Fact[11] != "unknown")',
];
for (const guard of guards) assert.equal(source.split(guard).length - 1, 1, guard);
function decode(stream) {
  assert.equal(hash(ahk), admitted);
  if (typeof stream !== 'string' || stream.length > 8192) return null;
  const frames = [...stream.matchAll(new RegExp(expression, 'gm'))];
  if (frames.length !== 1) return null;
  const f = frames[0];
  if (Number(f[4]) < -2147483648 || Number(f[4]) > 2147483647 || (f[3] === '0' && f[4] !== '0')) return null;
  if (Number(f[8]) < -1 || Number(f[8]) > 4096) return null;
  if (f[6] !== 'hashtable' && (f[7] !== 'unknown' || f[8] !== '-1' || f[9] !== 'unknown')) return null;
  if (f[8] !== '1' && (f[10] !== 'unknown' || f[11] !== 'unknown')) return null;
  return f.slice(1, 12).join('|');
}
const good = 'ROUTE_DIAG stage=vector_receipt vector=1 native_observed=0 native_errno=0 status=unknown result_shape=hashtable ok=true route_count=1 limits=match single_source=native_direct single_kind=direct\n';
const unknown = 'ROUTE_DIAG stage=vector_receipt vector=1 native_observed=0 native_errno=0 status=unknown result_shape=unknown ok=unknown route_count=-1 limits=unknown single_source=unknown single_kind=unknown\n';
const change = (before, after) => { assert.equal(good.split(before).length - 1, 1); return good.replace(before, () => after); };
const cases = [
  ['native-direct', good, true],
  ['system-direct', change('single_source=native_direct', 'single_source=system_direct'), true],
  ['system-proxy', change('single_source=native_direct single_kind=direct', 'single_source=system_proxy single_kind=proxy'), true],
  ['single-unrecognized', change('single_source=native_direct single_kind=direct', 'single_source=unknown single_kind=unknown'), true],
  ['unknown', unknown, true],
  ['null', unknown.replace('result_shape=unknown', 'result_shape=null'), true],
  ['array', unknown.replace('result_shape=unknown', 'result_shape=array'), true],
  ['other', unknown.replace('result_shape=unknown', 'result_shape=other'), true],
  ['two-with-source', change('route_count=1', 'route_count=2'), false],
  ['zero-with-kind', change('route_count=1', 'route_count=0').replace('single_source=native_direct', 'single_source=unknown'), false],
  ['unknown-count-with-source', change('route_count=1', 'route_count=-1').replace('single_kind=direct', 'single_kind=unknown'), false],
  ['two-unknown', change('route_count=1', 'route_count=2').replace('single_source=native_direct single_kind=direct', 'single_source=unknown single_kind=unknown'), true],
  ['zero-unknown', change('route_count=1', 'route_count=0').replace('single_source=native_direct single_kind=direct', 'single_source=unknown single_kind=unknown'), true],
  ['source-case', change('single_source=native_direct', 'single_source=Native_direct'), false],
  ['kind-case', change('single_kind=direct', 'single_kind=Direct'), false],
  ['source-private', change('single_source=native_direct', 'single_source=private-origin-secret'), false],
  ['kind-private', change('single_kind=direct', 'single_kind=private-origin-secret'), false],
  ['source-delimiter', change('single_source=native_direct', 'single_source=native_direct|private-origin-secret'), false],
  ['kind-trailing', change('single_kind=direct', 'single_kind=direct private-origin-secret'), false],
  ['count-over', change('route_count=1', 'route_count=4097'), false],
  ['count-negative', change('route_count=1', 'route_count=-2'), false],
  ['count-leading-zero', change('route_count=1', 'route_count=01'), false],
  ['count-policy-ceiling', change('route_count=1', 'route_count=4096').replace('single_source=native_direct single_kind=direct', 'single_source=unknown single_kind=unknown'), true],
  ['errno-max', good.replace('native_observed=0 native_errno=0', 'native_observed=1 native_errno=2147483647'), true],
  ['errno-min', good.replace('native_observed=0 native_errno=0', 'native_observed=1 native_errno=-2147483648'), true],
  ['errno-over', good.replace('native_observed=0 native_errno=0', 'native_observed=1 native_errno=2147483648'), false],
  ['errno-under', good.replace('native_observed=0 native_errno=0', 'native_observed=1 native_errno=-2147483649'), false],
  ['unverified-errno', change('native_errno=0', 'native_errno=5'), false],
  ['duplicate', good + good, false],
  ['duplicate-different', good + change('single_source=native_direct', 'single_source=system_direct'), false],
  ['duplicate-crlf', good + good.replace('\n', '\r\n'), false],
  ['missing-source', good.replace(' single_source=native_direct', ''), false],
  ['missing-kind', good.replace(' single_kind=direct', ''), false],
  ['url-suffix', good.trimEnd() + ' url=https://private-origin-secret.invalid/\n', false],
  ['credential-field', good.replace(' ok=true', ' token=private-origin-secret ok=true'), false],
  ['foreign-shape-ok', unknown.replace('result_shape=unknown ok=unknown', 'result_shape=other ok=true'), false],
  ['foreign-shape-count', unknown.replace('result_shape=unknown', 'result_shape=other').replace('route_count=-1', 'route_count=0'), false],
  ['foreign-shape-limits', unknown.replace('result_shape=unknown', 'result_shape=other').replace('limits=unknown', 'limits=match'), false],
  ['surrounding-private', 'https://private-origin-secret.invalid/token\n' + good, true],
  ['old-frame', good.replace(' single_source=native_direct single_kind=direct', ''), false],
  ['crlf', good.replace('\n', '\r\n'), true],
  ['status-case', change('status=unknown', 'status=Unknown'), false],
  ['oversized', 'x'.repeat(8193) + '\n' + good, false],
  ['prefixed-frame', 'prefix ' + good, false],
  ['zero-int32-unknown', unknown, true],
  ['non-string', { stdout: good }, false],
];
// Independent closed-vocabulary expectations, not generated from the production regex.
const sources = ['loopback', 'environment', 'environment_bypass', 'system_direct', 'system_bypass', 'system_config_absent_direct', 'system_config_absent_bypass', 'system_proxy', 'system_config_absent_proxy', 'wpad_absent_direct', 'wpad_absent_bypass', 'wpad_absent_proxy', 'native_proxy', 'native_direct', 'native_bypass'];
assert.equal(sources.length, 15);
for (const value of sources) cases.push(['source-' + value, change('single_source=native_direct', 'single_source=' + value), true]);
for (const [label, stream, accepted] of cases) {
  const result = decode(stream);
  assert.equal(result !== null, accepted, label);
  if (result !== null) {
    assert.match(result, /^[a-z_]+\|[0-3]\|[01]\|-?[0-9]+\|[a-z_]+\|[a-z]+\|[a-z]+\|-?[0-9]+\|[a-z]+\|[a-z_]+\|[a-z]+$/);
    assert.ok(!result.includes('private-origin-secret'), label);
  }
  console.log('PASS ' + label);
}
assert.equal(cases.length, 61);
assert.equal(hash(ahk), admitted);
console.log('PASS source-bound route diagnostic Node controls: 61; no AutoHotkey or WinHTTP native credit');
