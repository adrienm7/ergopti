"""Prepared Root-only receiver. No provider enrollment or original23 execution."""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys


def digest(file):
    return hashlib.sha256(Path(file).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--node', required=True)
    parser.add_argument('--node-sha256', required=True)
    parser.add_argument('--pwsh', required=True)
    parser.add_argument('--pwsh-sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    if sys.platform != 'win32':
        raise RuntimeError('Root Windows receiving only')
    base = Path(__file__).parent
    if digest(base / 'manifest.json') != args.manifest_sha256:
        raise RuntimeError('External frozen manifest pin mismatch')
    manifest = json.loads((base / 'manifest.json').read_text(encoding='utf-8'))
    before = {}
    for row in manifest['files']:
        before[row['file']] = digest(base / row['file'])
        if before[row['file']] != row['sha256']:
            raise RuntimeError('Frozen source pin mismatch')
    if digest(args.node) != args.node_sha256 or digest(args.pwsh) != args.pwsh_sha256:
        raise RuntimeError('Explicit runtime digest mismatch')
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    sandbox = output / 'sandbox'
    sandbox.mkdir()
    for part in ('temp', 'appdata', 'localappdata', 'profile'):
        (sandbox / part).mkdir()
    environment = {'SystemRoot': os.environ['SystemRoot'], 'WINDIR': os.environ['SystemRoot'],
                   'TEMP': str(sandbox / 'temp'), 'TMP': str(sandbox / 'temp'),
                   'APPDATA': str(sandbox / 'appdata'), 'LOCALAPPDATA': str(sandbox / 'localappdata'),
                   'USERPROFILE': str(sandbox / 'profile'), 'HOME': str(sandbox / 'profile'),
                   'POWERSHELL_TELEMETRY_OPTOUT': '1',
                   'PSModuleAnalysisCachePath': str(sandbox / 'module-analysis-cache')}
    spec = importlib.util.spec_from_file_location('root_owned_prehost_inert', base / 'prehost_native_inert.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    foreign = output / 'foreign-identical-pwsh.exe'
    shutil.copyfile(args.pwsh, foreign)
    if digest(foreign) != args.pwsh_sha256:
        raise RuntimeError('Foreign copy bytes differ')
    rows = []
    payload = b'\x00\r\n' + 'owned fd3 é ☃ 😀'.encode('utf-8')
    cases = [
        ('node-suspended-cancel', 'node-inert', args.node, args.node_sha256, args.node, False, False),
        ('pwsh-foreign-identical-refusal', 'powershell-inert', args.pwsh, args.pwsh_sha256, str(foreign), False, True),
        ('node-fd3-raw-roundtrip', 'node-inert', args.node, args.node_sha256, args.node, True, False),
        ('pwsh-fd3-raw-roundtrip', 'powershell-inert', args.pwsh, args.pwsh_sha256, args.pwsh, True, False),
    ]
    for name, role, approved, image_sha, actual, transport, refusal in cases:
        directory = output / name
        directory.mkdir()
        script = base / ('node_fd3_inert.cjs' if role == 'node-inert' else 'ps_fd3_inert.ps1')
        row = {'name': name, 'passed': False, 'qualified': False}
        rows.append(row)
        case = module.OwnedInertCase(str(directory), approved, image_sha, actual,
                                     image_sha, str(script), digest(script), role, environment)
        primary = None
        try:
            try:
                case.start(resume=transport)
                print(json.dumps({'case': name, 'owned_pid': case.facts['pid'],
                                  'state': case.state}), flush=True)
            except RuntimeError:
                if not refusal or case.facts.get('image_status_hex') != 'c0000001':
                    raise
            else:
                if refusal:
                    raise AssertionError('Foreign identical image was admitted')
            if transport:
                case.exchange(payload)
        except BaseException as error:
            primary = error
            row['primary_type'] = type(error).__name__
        finally:
            try:
                row['custody'] = case.retire(cancel=not transport or primary is not None)
            except BaseException as cleanup:
                row['cleanup_type'] = type(cleanup).__name__
                row['custody'] = case.custody()
                with (output / (name + '.json')).open('x', encoding='utf-8', newline='\n') as stream:
                    json.dump(row, stream, indent=2); stream.write('\n')
                raise RuntimeError('Inert cleanup debt; stop receiving') from cleanup
        if primary is not None:
            with (output / (name + '.json')).open('x', encoding='utf-8', newline='\n') as stream:
                json.dump(row, stream, indent=2); stream.write('\n')
            raise RuntimeError('Inert case refused; no retry') from primary
        try:
            custody = row['custody']
            if any(custody.get(field) is not True for field in ('terminal', 'job_zero', 'closed')):
                raise AssertionError('Physical retirement is not complete')
            if transport:
                if (custody.get('natural_success') is not True or custody.get('resumed') is not True or
                    any(custody.get(field) is not False for field in
                        ('timeout', 'deadline_exceeded', 'cancel_requested', 'io_ambiguous', 'retirement_ambiguous')) or
                    type(custody.get('forced_calls')) is not list or custody['forced_calls'] != [] or
                    type(custody.get('io_cancel_calls')) is not int or custody['io_cancel_calls'] != 0):
                    raise AssertionError('Inert transport did not retire naturally')
                if row['custody'].get('exit_code') != 0:
                    raise AssertionError('Inert child natural exit was not zero')
                if (directory / 'stdout.bin').read_bytes() != 'INERT_FD3_COMPLETE é ☃\n'.encode('utf-8'):
                    raise AssertionError('Actual stdout bytes differ')
                if (directory / 'stderr.bin').read_bytes() != 'INERT_FD3_STDERR α\n'.encode('utf-8'):
                    raise AssertionError('Actual stderr bytes differ')
            elif custody.get('cancel_requested') is not True or custody.get('natural_success') is not False:
                raise AssertionError('Expected cancelled or refused control custody differs')
        except BaseException as error:
            row['verification_error_type'] = type(error).__name__
            with (output / (name + '.json')).open('x', encoding='utf-8', newline='\n') as stream:
                json.dump(row, stream, indent=2); stream.write('\n')
            raise
        row['passed'] = True
        with (output / (name + '.json')).open('x', encoding='utf-8', newline='\n') as stream:
            json.dump(row, stream, indent=2); stream.write('\n')
        print(json.dumps({'case': name, 'passed': True, 'pid': case.facts['pid'],
                          'closed': case.facts['closed']}), flush=True)
    after = {name: digest(base / name) for name in before}
    if before != after:
        raise RuntimeError('Frozen source changed')
    receipt = {'state': 'INERT_SEAM_RECEIVED_NOT_PROVIDER_ENROLLMENT', 'qualified': False,
               'source_before': before, 'source_after': after, 'controls': rows,
               'provider_qualified': False, 'native23_qualified': False,
               'limit': 'Four real inert cases only; provisioning/descendant/budget/close-error/complete original23 remain separate.'}
    with (output / 'receipt.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(receipt, stream, indent=2); stream.write('\n')


if __name__ == '__main__':
    main()
