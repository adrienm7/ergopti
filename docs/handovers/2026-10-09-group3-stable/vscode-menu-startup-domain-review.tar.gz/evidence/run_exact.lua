local root = assert(arg[1]) .. "/static/ergopti_plus/"
package.path = root .. "macos/?.lua;" .. root .. "macos/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local helpers = require("tests.helpers")
helpers.reset_results()
local mode = arg[3]
if mode ~= "genuine" then
 local original = helpers.read_driver_source
 helpers.read_driver_source = function(symbol)
  local source = assert(original(symbol))
  local before, after
  if mode == "wrong-domain" then
   before = 'error("menu.start did not commit")'
   after = 'error("unrelated startup refusal")'
  elseif mode == "returned-value" then
   before = 'Boot.stage("File watchers armed")'
   after = 'local stage = Boot.stage; Boot.stage = function(name) stage(name); return "unexpected-domain" end; return Boot.stage("File watchers armed")'
  else error("unknown mutation") end
  local start = assert(source:find(before,1,true))
  assert(not source:find(before,start + #before,true), "mutation preimage must be unique")
  return source:sub(1,start-1) .. after .. source:sub(start + #before)
 end
end
assert(loadfile(assert(arg[2])))()
local result = helpers.get_results()
print("STARTUP_DOMAIN " .. result.passed .. "/" .. result.failed)
if result.failed > 0 then os.exit(1) end
