
## Urgent stop and unresolved keymap qualification

The maintainer requested immediate termination before container deletion. Only
three completed corrections are included. The corrected batch did not receive
a new full shared test run or native Windows CI dispatch. CI is **not green**.
The original run completed with failure at the last observation on 28 October
2026 at 23:18:40 Paris. Its three failed unit groups are core,
hotstrings-shortcuts and keymap; aggregate verdict failures follow from them.
The UI group passed. No corrected-head CI run was started after the stop.

[Keymap job 123111092632](https://github.com/adrienm7/ergopti/actions/runs/40771445154/job/123111092632)
reported 1,386 passes and 21 failures. No fourth production correction is
claimed. Read the two archived `STOP_HANDOVER.md` notes before resuming:

- Nine custody failures compare busy activity at a raw temporary path with a
  download owner's authoritative canonical `Owner.Path`. Source review
  establishes this coordinate mismatch. The shared `FileReadActivityKey` is
  deliberately lexical and publishes before native I/O; do not add a dual-alias
  shim or filesystem resolution to it. Actual short-path causal execution was
  not completed.
- Two late-completion fakes write new bytes after `Abort()` has acknowledged
  quiescence. That violates the real transport's acknowledgement contract.
  Model queued readiness after acknowledgement without another write. Preserve
  an independent foreign-file replacement control; never restore blind deletion
  to make these cases pass.
- Teardown drops queued polls and callback bookkeeping before the live successor
  owner retires. Leaked global read activity can explain the later eight
  configuration-scope refusals, but the native cascade remains unproved.
- A separate raw/canonical path mismatch in configuration bundle selection is
  also an unproved alternative. The peer did not finish inspecting downstream
  borrowed-owner selection. Do not label all eight failures as cascades.

One unqualified test draft is saved with its exact bytes, index/worktree
patches, base SHA and branch in
`post-validation-evidence/evidence/windows-final-registry-path-proof/`.
There are no untracked draft files or production changes. Its native job was
never submitted. The peer performed source review only. Preserve these limits.

## Resume from a fresh checkout

Clone `github.com/adrienm7/ergopti`, fetch `fix/windows`, and create a local branch
from its remote tip. Read `AGENTS.md`, the routed Windows memory, and the driver,
ship-fix, verify-change, false-green-tests and commit-and-push skills. Use Node
22.22.2 as pinned, run `npm ci`, then `npx husky install`; never bypass hooks.

Verify the original and supplemental archive checksums. The supplemental bundle
contains the completed original source branches; its prerequisite is the pushed
`3b33225970415794481337525e4cc23cb15f2922` baseline. The registry draft branch
also starts at that baseline, already reachable from the delivery history.
Recreate a separate worktree at that exact base, apply the archived binary
working-tree/index patches as appropriate, and compare every restored file with
`STOP-manifest.json`. The draft is research material, not a ready fix.

Use real Windows, the pinned AutoHotkey 2.0.26 and native Windows PowerShell 5.1
for authoritative qualification. Linux PowerShell 7 host checks and AutoHotkey
under Wine supply narrower logic evidence; Wine's empty PowerShell executable
is not qualification. Retain all genuine failures.

First run the eight configuration-scope cases alone in a fresh process. Then
run the two late-completion cases followed by those eight in another process,
recording owner counts before and after cleanup. Separately prove genuine
short-name/long-name file equivalence using Win32 APIs and compare raw paths,
`Owner.Path`, lexical keys and native file identities. Repair faithful fixture
completion and exact-owner teardown before assigning a production cause. Then
run the complete keymap cohort and the normal full Windows lane.

Keep hotstring engines, tap-hold thresholds, gesture behavior, recommended
settings, model-browser work, workflows and protected CI tooling outside this
follow-up. Preserve current dev behavior during a normal merge; never rebase or
force-push this delivery. Push only `fix/windows`, never `dev` or `main`, and do
not open a pull request. Existing audit TODOs still apply.

Concrete checkout commands, after installing the pinned Node and Git:

```sh
git clone --branch fix/windows https://github.com/adrienm7/ergopti.git ergopti
cd ergopti
node --version
npm ci
npx husky install
cd docs/audits/windows-2026-10-28
sha256sum -c ARTIFACT_SHA256SUMS
sha256sum -c POST_VALIDATION_SHA256SUMS
tar -xzf post-validation-evidence.tar.gz
git bundle verify post-validation-evidence/post-validation-owned.bundle
cd ../../..
git worktree add ../ergopti-registry-resume -b windows/registry-resume 3b33225970415794481337525e4cc23cb15f2922
git -C ../ergopti-registry-resume apply --check ../ergopti/docs/audits/windows-2026-10-28/post-validation-evidence/evidence/windows-final-registry-path-proof/STOP-working-tree.patch
git -C ../ergopti-registry-resume apply ../ergopti/docs/audits/windows-2026-10-28/post-validation-evidence/evidence/windows-final-registry-path-proof/STOP-working-tree.patch
```

`node --version` must print `v22.22.2` before installing dependencies. The draft
index patch is empty and there are no untracked files. Its restored custody
fixture must have SHA256
`4007e997168c7d8e0324f23b2ed79571da03d80616550957ccf2bb06ee3f7387`.
Do not treat applying that test draft as a qualified correction.
