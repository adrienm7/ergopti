#!/usr/bin/env python3
"""Read archived native evidence; console extraction is diagnostic, never qualification."""
import argparse, hashlib, json, re
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--raw-log',type=Path)
p.add_argument('--manifest',type=Path)
p.add_argument('--annotations',type=Path)
a=p.parse_args()
output={'qualification':False,'reason':'Diagnostics only. Canonical TAP plus exact tested source and complete original validator receipt are required.','inputs':[]}
def read(path):
 data=path.read_bytes();output['inputs'].append({'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 return data.decode('utf-8-sig')
if a.raw_log:
 raw=read(a.raw_log);lines=[re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s+','',line) for line in raw.splitlines()]
 running={}; results={}; durations={}; duplicates=[]; plans=[]; footers=[]; phases=[];watchdogs=[]
 for line in lines:
  m=re.fullmatch(r'1\.\.(\d+)',line)
  if m: plans.append(int(m[1]))
  m=re.fullmatch(r'RUNNING (\d+)/(\d+) - (.+)',line)
  if m:
   key=int(m[1]);running.setdefault(key,[]).append({'total':int(m[2]),'name':m[3]})
  m=re.fullmatch(r'(ok|not ok) (\d+) - (.+)',line)
  if m:
   key=int(m[2]);results.setdefault(key,[]).append({'status':m[1],'detail':m[3]})
  m=re.fullmatch(r'# duration_ms (\d+) (\d+(?:\.\d+)?)',line)
  if m: durations.setdefault(int(m[1]),[]).append(float(m[2]))
  if re.fullmatch(r'# \d+ passed, \d+ failed\.',line):footers.append(line)
  if line.startswith('# group1-capacity-native-phase:') or line.startswith('# group1-registry-native-phase:'): phases.append(line)
  if '[WATCHDOG]' in line:watchdogs.append(line)
 for kind,group in [('running',running),('result',results),('duration',durations)]:
  duplicates.extend({'kind':kind,'index':i,'occurrences':len(xs),'conflicting':any(x!=xs[0] for x in xs[1:])} for i,xs in group.items() if len(xs)>1)
 output['consoleDiagnostics']={'plans':plans,'footers':footers,'uniqueStartedOrdinals':len(running),'uniqueTerminalOrdinals':len(results),'duplicates':duplicates,'observedPhases':phases,'watchdogs':watchdogs,'failedResults':[{'index':i,**x} for i,xs in sorted(results.items()) for x in xs if x['status']=='not ok'],'note':'No deduplicated console transcript is offered as an execution manifest.'}
if a.manifest:
 v=json.loads(read(a.manifest));executed=v.get('executed',[])
 output['archivedManifestClaims']={k:v.get(k) for k in ['complete','planned','executed_count','timed_count','passed','failed']}
 output['archivedManifestClaims']['unexecuted']=v.get('planned',0)-v.get('executed_count',0)
 output['archivedManifestClaims']['errorCount']=len(v.get('errors',[]))
 output['archivedManifestClaims']['observedSelectedSubjects']=[x for x in executed if any(t in x.get('name','') for t in ['configuration snapshot: actual full save','configuration snapshot: removed caps','real full-save publication','hotstrings-capacity:','genuine acquired-read timer custody','scope-obsolete-source','script-control submenu:','personal-file-controls:','hotstring-extension-scope: pack-owned staged cohort'])]
if a.annotations:
 value=json.loads(read(a.annotations));items=value if isinstance(value,list) else value.get('annotations',[])
 output['annotations']=[{k:x.get(k) for k in ['title','message','path','start_line','end_line','annotation_level']} for x in items]
 output['annotationsNativeCompleteness']='UNOBSERVED: annotation lists cannot establish full native execution, duration, footer, successful subjects or artifact source identity.'
print(json.dumps(output,indent=2,ensure_ascii=False))
