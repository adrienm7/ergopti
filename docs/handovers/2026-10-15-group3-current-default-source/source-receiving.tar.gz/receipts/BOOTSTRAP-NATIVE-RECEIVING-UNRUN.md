# PRIVATE — exact default-profile bootstrap initializer receiving

This receives Root's proposed two-file correction, not the historical 70d correction or the later SDK159/176 packet. Source custody only: no Swift compiler, native command, test subject, generator or workflow was executed. No canonical path changed. Keep private until the owner's correction/review is published and the final receiving source is admitted.

## Exact subject and conservation

Root manifest SHA256 `747c062137545175d1e8db6d15d3b70e60fc94cc402663fa690c332ab9a04acc`, basis `eb6cd9db17c9ebbe4dfdbba1d05141e394d777eb`:

- `Sources/ErgoptiPlus/OwnedRuntimeBootstrapStageOwner.swift`: 9292-byte `ef7c2908ff59baedf85d85f29f356745d1f17ae5c3b58393c6ace9329ddd9f7c` → 11411-byte `220262e07957c348210789a59ff9ce9083890ac76ed72d959a28b9152b2f814c`.
- `Tests/ErgoptiPlusTests/OwnedRuntimeLifecycleInitializerCustodyTests.swift`: 1585-byte `9f8f5c37b3ba1e88b5eb10c1709359bc115f4329b3a231362e02b57f534c716b` → 2408-byte `e363c3ccb82d3777d6c0f37c7fe3810dbe0942f9fb5340f418901a4c3f6356fd`.

Both relative paths use `static/ergopti_plus/macos/launcher/`. Exact ordered literal Root edits, including its subsequent close-status observation refinement, reconstruct both declared postimage hashes. The three existing XCTest method bodies remain byte-exact. This checks transport/conservation, not semantic or native success. Root's independent peer44 is separately reported, not rerun or replaced here.

The default source membership remains **127** leaves. The existing `Package.swift` 34861f7e… automatically includes this already-existing test file, enables `ERGOPTI_GUARDIAN_TEST_SUPPORT` on C/executable/test targets for DEBUG, and adds no installed-SDK flag. No new Swift/C/header member, Package change or 32-source SDK extension is needed to compile this regression. Default compiler closure still includes Package/lock/two external project headers (131 inputs); both qualification policies and both operational workflow bodies remain additional explicit custody. Release compilation alone cannot execute the DEBUG test seam.

## Smallest existing receiving path

The actual full `swift test` command in Root's existing macOS Build role already discovers this test file. No test registration or new role is required for full-suite enrollment. However, earlier PAC/HTTP failures can prevent reaching it, and an overall XCTest zero without an exact case receipt must not be counted as four-case receiving.

For independent finite receiving before those blocked cohorts, Root can add one focused command to its existing native Unit role after native prerequisites and before the unrelated HTTP/number-row actors. Use the same published checkout, default Package and runner architecture; do not change any existing command, assertion, timeout or required role. Preserve the full original stage graph. This proposal is not permission to run a stopped role or bypass its number-row composition admission.

The transparent native command, **NOT EXECUTED HERE**, is:

```bash
swift test --package-path static/ergopti_plus/macos/launcher \
  --scratch-path "$RUNNER_TEMP/bootstrap-initializer-current-default" \
  --filter '(^|[.])OwnedRuntimeLifecycleInitializerCustodyTests([/.]|$)'
```

Use the established `set +e`, pipe-to-tee, immediate `PIPESTATUS` capture, then `set -e` pattern. Require both Swift and capture exit statuses 0; retain the complete transcript and before/after source receipts with source SHA, run ID, attempt, architecture, actual `swift --version`/SDK, DEBUG/default flags and fixed membership. Run on the required arm64 and amd64 lanes when Root releases the gate. Set no qualification profile, SDK define, custom source list, skip, consent or trust exception. Do not use `--skip-build` for a changed source epoch.

Exact independently declared inventory, each started/terminal-passed once with zero skip/duplicate/extra/incomplete case:

1. `testEarlyRefusalDoesNotInvokeInitializedSelfRetirement`
2. `testLateRefusalRetiresInitializedSelfWithoutDuplicateCloseDebt`
3. `testLateRefusalReleasesActualNamespaceBeforeSuccessor`
4. `testBootstrapStageLateRefusalRetiresInitializedSelfWithoutDuplicateCloseDebt`

Require the class, bundle and Selected-tests root successful summaries, each exactly four tests/zero failures, and strict complete serial framing. The existing `swift_xctest_evidence.cjs.evaluate` is the **All-tests** collector and does not alone accept or prove a Selected-tests four-case cohort. Root's existing exact native-daemon-log receiver demonstrates a closed Selected→All root adaptation PLUS independently fixed cases/framing; any additive bootstrap receiver must preserve that distinction and have its own original/missing/duplicate/skip/truncation/exit/capture/source-mismatch negative controls. Do not merely grep `Executed 4` or repurpose a seven-/fourteen-case approval. This packet deliberately supplies no opaque generator or unreviewed replacement collector. Root owns the final finite receiver/registration and its source pins.

## Causal native withdrawal, separate from passing cohort

The private withdrawal image restores ONLY the exact original `var complete`/failure defer and terminal `complete = true` in Root's candidate, keeping its actual close-status observation and all four assertions. Source SHA256 `19ba02eea7393cc74a8ca88f5d32261b406ee6a5864c0ef25a910ac93c2971da`. Reversing just that delta restores candidate220262… byte-for-byte; source-conservation.json records this check.

On a separately owned disposable source projection, run only the new fourth method using this withdrawn image. Required causal failure is the original late initialized-self cleanup reaching real deinit with an already-closed parent: actual Darwin.close -1/EBADF differs from the preserved `[status:0,error:0]` assertion. Compilation error, launch error, unavailable test seam, absent case, timeout, arbitrary assertion failure or cleanup debt is NOT the expected causal refusal. Never overwrite the canonical candidate under an active gate. Rebuild the withdrawn source in its own scratch path; never reuse the candidate executable. Restore candidate bytes and receive the four-case cohort again in a fresh correctly bound build epoch. These are pending native experiments, not three claimed successes or authority to dispatch them now.

## Composition and remaining authority

This regression does not qualify the whole installed runtime, protected publication/retirement, native14 OwnedProgram cohort, number-row12/TIS7, PAC14/independent HTTP clients, archive/Brew/Shortcuts, packaging or installation. Their original assertions, budgets and failures remain mandatory. Full default number-row admission still requires the exact final published supplier, the reviewed current-input ledger and four-controller successor; the old70d-hardcoded135 and workflow self-binding problem are not solved by this two-file fix. The private supplemental34 scope matrix remains private and historical, with its actual old-bootstrap HOLD; do not silently rewrite that evidence to approved current bytes.

Needed from Root before actual receiving: published full40 source successor containing these reviewed pairs; actual final Mac workflow/depth0 tuple; finite receiver/operational enrollment review; and the current default composition's separate independent admission. No physical-device request, future SDK159 packet, trust-policy alteration or replay of unchanged HTTP/WPAD is required by this handoff.
