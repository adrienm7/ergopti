"""Reproduce inherited native Compose prefix shadowing using original conversion."""

import hashlib
import json
from pathlib import Path
import sys

from shared_probe import NativeCompose, require

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "static/ergopti/linux/xkb_generation"))
import keylayout_to_xkb as converter  # noqa: E402

registry = root / "static/layouts/registry"
entry = next(
    x
    for x in json.loads((registry / "index.json").read_text())["layouts"]
    if x["id"] == "bepo"
)
source = (registry / entry["file"]).read_text()
layout = converter.parse_keylayout(source)
keycodes = converter.load_keycodes(
    root / "static/ergopti_plus/_shared/modules/layouts/mac_keycodes.json", "iso"
)
converted = converter.convert_layout(
    layout, keycodes, "bepo", "Dead-key audit", converter.XkbHints.from_entry(entry)
)
require(layout.actions["cedille"].whens["monnaie"] == ("₢", None), "source expectation")
require(
    '<dead_currency> <dead_cedilla>\t: "₢"' in converted.compose_text,
    "written rule must exist",
)
require(converted.conflicts == [], "converter reports no conflicts")

compose = NativeCompose()
observations = []
pair = ["dead_currency", "dead_cedilla"]
try:
    variants = [
        ("generated_with_locale", converted.compose_text),
        (
            "generated_without_locale_include",
            converted.compose_text.replace('include "%L"\n', "", 1),
        ),
        ("minimal_explicit_rule", '<dead_currency> <dead_cedilla> : "₢"\n'),
        (
            "locale_plus_explicit_rule",
            'include "%L"\n<dead_currency> <dead_cedilla> : "₢"\n',
        ),
        (
            "generated_private_trigger_control",
            converted.compose_text.replace("<dead_currency>", "<U100100>"),
        ),
    ]
    for name, text in variants:
        table, state = compose.load(text)
        try:
            prefix = (
                ["U100100", "dead_cedilla"]
                if name.endswith("trigger_control")
                else pair
            )
            observations.append(
                {
                    "name": name,
                    "table_sha256": hashlib.sha256(text.encode()).hexdigest(),
                    "sequence": prefix,
                    "pair": compose.replay(state, prefix),
                    "with_following_c": compose.replay(state, prefix + ["c"]),
                    "ordinary_currency_c": compose.replay(state, [prefix[0], "c"])
                    if name.startswith("generated_")
                    else None,
                }
            )
        finally:
            compose.close_table(table, state)
finally:
    compose.close()

by_name = {x["name"]: x for x in observations}
for name in ["generated_with_locale", "locale_plus_explicit_rule"]:
    require(
        by_name[name]["pair"][-1]["status"] == 1, name + " wrongly remains composing"
    )
    require(
        by_name[name]["with_following_c"][-1].get("output") == "₵",
        name + " inherited longer sequence",
    )
for name in [
    "generated_without_locale_include",
    "minimal_explicit_rule",
    "generated_private_trigger_control",
]:
    require(by_name[name]["pair"][-1].get("output") == "₢", name + " direct positive")
require(
    by_name["generated_with_locale"]["ordinary_currency_c"][-1].get("output")
    == layout.actions["c"].whens["monnaie"][0],
    "ordinary rule positive",
)

locale = Path("/usr/share/X11/locale/en_US.UTF-8/Compose")
locale_lines = [
    line
    for line in locale.read_text().splitlines()
    if line.startswith("<dead_currency> <dead_cedilla>")
]
require(
    len(locale_lines) == 2 and all("₵" in line for line in locale_lines),
    "system reference longer prefixes",
)
mapped = [
    line.split()[-1]
    for line in Path("/proc/self/maps").read_text().splitlines()
    if "libxkbcommon.so" in line and "/" in line
]
elf = Path(mapped[0]).resolve()
require(elf.read_bytes()[:4] == b"\x7fELF", "genuine native shared object")
result = {
    "audited_sha": "f2c3ea43542c985fb20e5f0887976f1c02525341",
    "source_output": "₢",
    "written_rule_present": True,
    "reported_conflicts": 0,
    "observations": observations,
    "native_dependency": {
        "path": str(elf),
        "sha256": hashlib.sha256(elf.read_bytes()).hexdigest(),
    },
    "system_locale_reference": {
        "path": str(locale),
        "sha256": hashlib.sha256(locale.read_bytes()).hexdigest(),
        "matching_lines": locale_lines,
    },
    "qualification": "Genuine libxkbcommon Compose protocol over original Python-converted shipped Bépo input and explicitly labelled generated-data controls. Actual shared Lua converters produce byte-identical files. No hardware, application, native macOS or AHK execution; the locale include is not a fake parser. The private-trigger control is not a production fix.",
}
Path(sys.argv[2]).write_text(json.dumps(result, ensure_ascii=False, indent="\t") + "\n")
print(
    "PREFIX_CONTROLS=5; inherited pair remains composing, following c produces ₵; "
    "without include/minimal/private trigger produce source ₢"
)
