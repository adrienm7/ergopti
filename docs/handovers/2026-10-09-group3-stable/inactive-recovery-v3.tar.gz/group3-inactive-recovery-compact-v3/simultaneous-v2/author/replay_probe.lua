local root=assert(arg[1])
local v1=assert(arg[2])
local subject=assert(arg[3])
package.path=root.."/static/ergopti_plus/linux/?.lua;"..root.."/static/ergopti_plus/linux/?/init.lua;"..root.."/static/ergopti_plus/_shared/lua/?.lua;"..root.."/static/ergopti_plus/_shared/lua/?/init.lua;"..package.path
arg={v1.."/candidate",subject.."/candidate"}
dofile(assert(arg[4] or "reconciled-reader-cleanup-probe.lua"))
