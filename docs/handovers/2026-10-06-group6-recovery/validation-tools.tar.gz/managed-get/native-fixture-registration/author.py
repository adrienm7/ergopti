from pathlib import Path
import hashlib,json,difflib,ast
R=Path(__file__).parent
Q=Path('/workspace/scratch/group6-linux-network/current-owner-get-output-qualification')
H='static/ergopti_plus/linux/tests/hardware/'
def sha(b):return hashlib.sha256(b).hexdigest()
def emit(name,b):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
p=Q/'native30/controls/native_public_http_controls.py.source';original=p.read_bytes();s=original.decode()
changes=[
 ('receipt["dependency_commit"] != "54493dc2a586181b94969db9bcfa9c0b12cb653a" or receipt["phase"] != "original"','receipt["dependency_commit"] != EXPECTED_DEPENDENCY_COMMIT or receipt["phase"] != EXPECTED_DEPENDENCY_PHASE'),
 ('    inventory = json.loads((Path(__file__).resolve().parent.parent / "DEPENDENCY-FILES.json").read_text())', '''    inventory_bytes = DEPENDENCY_INVENTORY.read_bytes()
    if hashlib.sha256(inventory_bytes).hexdigest() != EXPECTED_INVENTORY_SHA256:
        raise RuntimeError("Exact dependency inventory source freeze changed")
    inventory = json.loads(inventory_bytes)'''),
 ('    shutil.copytree(immutable, base, symlinks=False)', '''    shutil.copytree(immutable, base, symlinks=False)
    copied_actual = {path.relative_to(base).as_posix() for path in base.rglob("*")
                     if path.is_file() or path.is_symlink()}
    if copied_actual != declared:
        raise RuntimeError("Copied dependency inventory changed")
    for entry in inventory["entries"]:
        copied = base / (REPOSITORY / entry["path"]).relative_to(immutable)
        if entry["kind"] == "symlink":
            raise RuntimeError("Normal native snapshot does not admit dependency symlinks")
        if copied.is_symlink() or not copied.is_file() or hashlib.sha256(copied.read_bytes()).hexdigest() != entry["sha256"]:
            raise RuntimeError("Copied dependency bytes changed")'''),
 (' != "91bf6bbfcd8d4ffe479dd553e5df281246de0f98cf7c133e341988b0478c7f83"',' != EXPECTED_NATIVE_SHA256'),
 ('    EXPECTED_MANIFEST = "66a93763a4addaa3390c14853d0c380c82748febb1bf7e1857a2ba08a484407a"', '''    EXPECTED_MANIFEST = args.expected_manifest
    EXPECTED_INVENTORY_SHA256 = args.expected_inventory_sha256
    EXPECTED_DEPENDENCY_COMMIT = args.expected_dependency_commit
    EXPECTED_DEPENDENCY_PHASE = args.expected_dependency_phase
    EXPECTED_NATIVE_SHA256 = args.expected_native_sha256
    DEPENDENCY_INVENTORY = args.dependency_inventory.resolve(strict=True)'''),
 ('    CONTROL, REPOSITORY = args.control.resolve(), args.repository.resolve()', '''    CONTROL, REPOSITORY = args.control.resolve(strict=True), args.repository.resolve(strict=True)
    admitted_control = REPOSITORY / "static/ergopti_plus/linux/tests/hardware/run_managed_http_native.lua"
    if CONTROL != admitted_control or admitted_control.is_symlink() or not admitted_control.is_file():
        parser.error("The native Lua control must belong to the admitted source snapshot")'''),
 ('    args, remaining = parser.parse_known_args()', '''    parser.add_argument("--expected-manifest", required=True)
    parser.add_argument("--expected-inventory-sha256", required=True)
    parser.add_argument("--expected-native-sha256", required=True)
    parser.add_argument("--expected-dependency-commit", required=True)
    parser.add_argument("--expected-dependency-phase", choices=("original", "working-tree-snapshot"), required=True)
    parser.add_argument("--dependency-inventory", type=Path, required=True)
    args, remaining = parser.parse_known_args()
    for value in (args.expected_manifest, args.expected_native_sha256, args.expected_inventory_sha256):
        if re.fullmatch(r"[0-9a-f]{64}", value) is None:
            parser.error("An exact SHA256 source admission is required")
    if re.fullmatch(r"[0-9a-f]{40}", args.expected_dependency_commit) is None:
        parser.error("An exact Git source dependency commit is required")
    if not args.error_module.is_dir():
        parser.error("GIO_EXTRA_MODULES requires the compiled module DIRECTORY")
    module = args.error_module / "libergopti-native-error.so"
    if module.is_symlink() or not module.is_file():
        parser.error("The actual GIO error module is missing")''')]
for a,b in changes:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b,1)
s=s.replace('"""Prove staged production HTTP routing through actual GIO, curl and sockets."""','''# tests/hardware/run_managed_http_native.py
"""Prove source-admitted public HTTP routing with owned native fixtures."""''',1)
new=s.encode();name=H+'run_managed_http_native.py';emit('preimages/'+name,original);emit('candidate/'+name,new)
# Admission changes cannot modify any class/test method, guardian or cleanup helper.
def tests(body):
 t=ast.parse(body);return {n.name:ast.get_source_segment(body,n) for c in t.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
assert tests(s)==tests(original.decode());assert len(tests(s))==30
for src,target in [('native_public_http.lua.source','run_managed_http_native.lua'),('native_gio_error.c.source','managed_http_gio_error.c')]:
 b=(Q/'native30/controls'/src).read_bytes();emit('preimages/'+H+target,b)
 # Original native fixture and guardian retained in full, including existing banner.
 prefix = (('--- tests/hardware/' + target + '\n') if target.endswith('.lua') else ('/* tests/hardware/' + target + ' */\n')).encode()
 emit('candidate/'+H+target,prefix+b)
b=(Q/'controls/native_http_output_target.lua').read_bytes()
name=H+'run_http_output_target_native.lua';emit('preimages/'+name,b)
header=b'''--- tests/hardware/run_http_output_target_native.lua
--- ==============================================================================
--- MODULE: Native Retained HTTP Output Receipts
--- DESCRIPTION:
--- Checks actual loopback curl, anonymous parent output and physical retirement.
--- This native profile requires Linux LuaJIT/FFI and does not qualify proxy policy.
--- ==============================================================================

'''
emit('candidate/'+name,header+b)
# Source-only standalone bootstrap: direct core fixture uses no repository fallback.
bootstrap=b'''--- tests/hardware/run_http_output_target_native_entry.lua
--- ==============================================================================
--- MODULE: Native Retained Output Fixture Bootstrap
--- DESCRIPTION:
--- Resolves only the supplied source-admitted driver and executes its native fixture.
--- ==============================================================================

local driver = assert(arg[1], "Exact native driver root is required")
package.path = driver .. "/?.lua;" .. driver .. "/?/init.lua;"
    .. driver .. "/../_shared/lua/?.lua;" .. driver .. "/../_shared/lua/?/init.lua;" .. package.path
local compat = require("compat.utf8")
if compat.install then compat.install() end
dofile(driver .. "/tests/hardware/run_http_output_target_native.lua")
'''
emit('candidate/'+H+'run_http_output_target_native_entry.lua',bootstrap)
patch=[]
for path in sorted((R/'candidate').rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(R/'candidate').as_posix()
 patch.extend(difflib.unified_diff([],path.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+rel))
emit('native-fixtures.patch',''.join(patch).encode())
emit('PRESERVATION.json',(json.dumps({'source':str(Q),'native30_methods':{k:sha(v.encode()) for k,v in tests(s).items()},'native30_method_count':30,'python_admission_only_changes':len(changes),'native_lua_full_copy_after_path_prefix':True,'c_full_copy_after_path_prefix':True,'output18_original_full_tail':sha(b),'output18_expected':18,'normal_gate_execution':'UNEXECUTED'},indent=2)+'\n').encode())
