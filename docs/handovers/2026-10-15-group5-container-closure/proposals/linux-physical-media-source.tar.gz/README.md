# Linux original-source media metrics proposal

This inert handoff contains the exact four Reader/Hook suppliers and four consumer/daemon/test sources. Source attachments use `.source`; original receipts use `.json.receipt` to retain their bytes. Nothing here is applied or automatically loaded.

The original pre-remap source callback accounts numeric physical positions separately from five semantic media IDs. Consumed native input remains countable; remapper fanout and delayed synthetic output never gain physical heatmap authority. Existing logical character/WPM callbacks remain separate. Actual script pause must be observed as literal false; true/unknown/missing/throwing pause cancels holds and grants no metrics. Negative-only original down/up bookkeeping preserves exclusion across resume. Media FIFO drains only after the original writer's literal true ACK.

[MANIFEST.json](MANIFEST.json) maps eight target paths, original shared dependencies and every lossless attachment. [Combined source patch](patches/combined8.patch.gz) is deterministic gzip (`mtime=0`); strict Git forward/reverse was verified against just the exact seven existing preimages plus one absence. Check preimages before considering adoption.

Source reviews: [supplier four](reviews/supplier4.json.receipt), [supplier cut custody](reviews/supplier4-cuts.json.receipt), and [consumer pause successor](reviews/consumer4-pause-CLEAR.json.receipt). [Original consumer pause HOLD](reviews/consumer4-original-HOLD.json.receipt) remains historical. G3 owns the canonical Reader/Hook paths; Root/G3 coordination is still required for adoption.

Portable receiving counts are separate: Reader69 +Hook23 =92 per Lua5.4/LuaJIT; the existing consumer module has original23 +new9 =32 per runtime. Both cohorts pass, but this handoff does not manufacture a combined-gate result. Consumer eight omission controls fail at assertions and exact restoration returns32/0. Before the pause correction, the two new cases fail at real assertions (7PASS2FAIL); corrected source has9/0. All original test assertions remain.

The tests use original Hook/Reader algorithms with controlled transport/grab/classification and real owned `/dev/null`/`/dev/zero` fstat, plus actual SQLite CLI. [Actual FIFO receipt](receipts/native-fifo/ACTUAL.json.receipt) separately proves decoded native FFI transport and kernel ENOTTY refusal, with no capture capability. Real evdev/uinput, physical input/grab/compositor behavior remains UNRUN. No numeric ABI, readiness, installation, personal profile, permission or lease-recovery grant is made.
