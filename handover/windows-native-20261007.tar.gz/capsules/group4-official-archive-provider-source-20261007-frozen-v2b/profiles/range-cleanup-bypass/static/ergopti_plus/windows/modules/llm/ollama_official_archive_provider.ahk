﻿; modules/llm/ollama_official_archive_provider.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Owned Official Ollama Archive Provider
; DESCRIPTION:
; Resolves each official HTTPS redirect through the existing system proxy and
; curl owners after native intake acquisition. The same intake seals the final
; file and canonical reader verifies it; a network receipt never prepares data.
; ==============================================================================

/** Only the canonical repository URL and official release-object hosts are valid. */
OllamaArchiveOfficialUrl(Url, Asset) {
	if !(Url is String) || !(Asset is Map) || !_HTTP_CurlScalarIsSafe(Url)
			|| InStr(Url, "#") || !RegExMatch(Url, "\Ahttps://([^/]+)/([^\s]+)\z", &parts)
		return false
	local host := parts[1]
	if host == "github.com"
		return Url == Asset.Get("url", "")
	return host == "release-assets.githubusercontent.com" || host == "objects.githubusercontent.com"
}

/** The probe observes one ZIP byte; full archive bytes belong only to intake. */
OllamaArchiveProbeComplete(Request, Asset) {
	if !(Request is CurlAsyncRequest) || !Request.Completed || Request.Aborted
			|| !(Request.Status is Integer) || Request.Status != 206 || IsObject(Request.Handle)
			|| !(Asset is Map) || !(Asset.Get("bytes", 0) is Integer)
			|| !(Request.ResponseText == "P")
		return false
	return Request.GetResponseHeader("content-range") == "bytes 0-0/" . Asset["bytes"]
}

class OllamaOfficialArchiveProvider {
	__New(Intake, Options, Current, OnPrepared) {
		if !(Intake is OllamaArchiveIntake) || !(Options is Map)
				|| !(Options.Get("poll_ms", 0) is Integer) || Options["poll_ms"] <= 0
				|| !HasMethod(Current, "Call") || !HasMethod(OnPrepared, "Call") || Intake.HasOwner()
			throw TypeError("Official acquisition requires exclusive actual intake and explicit current ownership.")
		this.Intake := Intake
		this.Options := Options.Clone()
		this.CurrentFn := Current
		this.IntakeCurrentFn := Intake.CurrentFn
		this.Intake.CurrentFn := ObjBindMethod(this, "_IntakeCurrent")
		this.PreparedFn := OnPrepared
		this.Intake.PreparedFn := ObjBindMethod(this, "_Prepared")
		this.Record := 0
		this.Generation := 0
		this.Timer := ObjBindMethod(this, "Poll")
		this.TimerOwned := false
		this.FirstError := ""
	}

	Start(Prepare, Target, Asset, Deadline) {
		if !(Prepare is Map) || !(Target is Map) || !(Asset is Map) || !(Deadline is Integer)
			throw TypeError("Archive acquisition requires captured catalogue, target, asset and original deadline.")
		local canonical := OllamaReleaseWindowsAsset(Prepare.Get("AssetId", ""))
		for name in ["asset_id", "version", "filename", "sha256", "bytes", "url"]
			if Type(Asset.Get(name, 0)) != Type(canonical[name]) || !(Asset[name] == canonical[name])
				throw ValueError("Archive acquisition cannot enlarge or replace the canonical per-file record.")
		if this.Intake.Options["archive_bytes"] != canonical["bytes"]
			throw ValueError("Intake and provider require the same canonical archive ceiling.")
		local previous := Critical("On")
		try {
			if this.Record is Map || this.Intake.HasOwner()
				return false
			if this.Generation == 0x7fffffffffffffff
				throw Error("Archive provider generation identities are exhausted.")
			local record := Map("generation", ++this.Generation, "request", Prepare.Clone(), "target", Target.Clone(),
				"asset", canonical, "deadline", Deadline, "cancelled", false, "busy", false, "building", true,
				"phase", "acquiring", "intake_record", 0, "url", canonical["url"], "seen", Map(), "url_bytes", 0,
				"proxy", 0, "proxy_pending", false, "proxy_tasks", [], "proxy_runs", [], "requests", [], "probe", 0,
				"download", 0, "download_url", "",
				"prepared", false, "delivered", false)
			this.Record := record
			this.FirstError := ""
		} finally Critical(previous)
		local accepted := false, admitted := false
		try {
			if !this._Current(record)
				return false
			accepted := this.Intake.Start(record["request"], record["target"], Deadline) == true
			record["intake_record"] := this.Intake.Record
			if !accepted || !this._Current(record)
				return false
			record["phase"] := "namespace"
			admitted := true
			return true
		} catch Any as Err {
			this._Fault(record, "archive_acquisition_refused")
			return false
		} finally {
			record["building"] := false
			if !admitted
				this._Fault(record, "archive_acquisition_refused")
			this._Schedule()
		}
	}

	_Owns(Record) {
		return this.Record is Map && this.Record == Record && this.Generation == Record["generation"]
	}
	_Current(Record) {
		local current := this.CurrentFn.Call(Record["request"].Clone(), Record["target"].Clone())
		return current is Integer && current == true && this._Owns(Record) && !Record["cancelled"]
			&& !A_IsSuspended && A_TickCount < Record["deadline"]
			&& (!(Record["intake_record"] is Map) || Record["prepared"]
				|| this.Intake.Record == Record["intake_record"] && !Record["intake_record"]["cancelled"])
	}
	_IntakeCurrent(Prepare, Target) {
		local record := this.Record
		if !(record is Map) || !this._SourceMatches(record, Prepare, Target)
			return false
		local inherited := this.IntakeCurrentFn.Call(Prepare.Clone(), Target.Clone())
		return inherited is Integer && inherited == true && this._Current(record)
			&& this._SourceMatches(record, Prepare, Target)
			&& (!IsObject(record["download"]) || this._RequestMatches(record["download"], record["download_url"], false))
	}
	_SourceMatches(Record, Prepare, Target) {
		for name in ["ManagedRoot", "CataloguePath", "CatalogueSha256", "AssetId", "TicketId", "MaxExpandedBytes", "MaxEntries"]
			if Type(Prepare.Get(name, 0)) != Type(Record["request"].Get(name, 0))
					|| !(Prepare.Get(name, 0) == Record["request"].Get(name, 0))
				return false
		for name in ["models_dir", "origin", "port"]
			if Type(Target.Get(name, 0)) != Type(Record["target"].Get(name, 0))
					|| !(Target.Get(name, 0) == Record["target"].Get(name, 0))
				return false
		return true
	}
	_RequestMatches(Request, Url, RangeProbe) {
		return Request is CurlAsyncRequest && Request.Method == "GET" && Request.Url == Url
			&& (!RangeProbe || Request.Headers.Get("Range", "") == "bytes=0-0")
	}
	_Fault(Record, Reason) {
		; The same strong record retains resources even if its admission
		; generation has been invalidated. A successor's record is never changed.
		if !(this.Record is Map) || this.Record != Record
			return false
		if this.FirstError == ""
			this.FirstError := Reason
		Record["cancelled"] := true
		Record["phase"] := "retiring"
		return false
	}

	_Resolve(Record, Url) {
		global HTTP_CURL_MAX_HEADER_BYTES
		if !this._Current(Record) || !OllamaArchiveOfficialUrl(Url, Record["asset"])
				|| Record["seen"].Has(Url)
			throw ValueError("Official archive redirect is foreign, repeated or stale.")
		local bytes := StrPut(Url, "UTF-8") - 1
		if bytes > HTTP_CURL_MAX_HEADER_BYTES - Record["url_bytes"]
			throw ValueError("Official archive URL receipts exceed the existing metadata ceiling.")
		Record["seen"][Url] := true
		Record["url_bytes"] += bytes
		Record["url"] := Url
		Record["proxy"] := 0
		Record["proxy_pending"] := true
		Record["phase"] := "proxy"
		try {
			if !SystemProxy_ResolveCurlAsync(Url, ObjBindMethod(this, "_ProxyResolved", Record, Url),
					0, ObjBindMethod(this, "_SpawnProxy", Record), EnvGet, ObjBindMethod(this, "_ProxyOwner", Record))
				throw Error("The official destination's actual system proxy could not be resolved.")
		} catch Any as Err {
			Record["proxy_pending"] := false
			throw Err
		}
	}
	_ProxyOwner(Record, Owner) {
		; The real resolver publishes its owner before effects, including queued
		; resolutions. Borrowing a shared run never grants permission to stop it.
		Record["proxy_runs"].Push(Owner)
	}
	_SpawnProxy(Record, Executable, Arguments, Done) {
		if !this._Current(Record)
			throw Error("Archive proxy construction belongs to a stale source.")
		local row := Map("task", 0, "probe", 0, "delivery", 0, "done", false, "stop_attempted", false)
		Record["proxy_tasks"].Push(row)
		row["task"] := ShellRunner_StageTreeOwned(Executable, Arguments,
			ObjBindMethod(this, "_ProxyTaskDone", row, Done), 65536, true, true)
		row["probe"] := _SR_IntakeCaptureQuiescence(row["task"])
		row["delivery"] := _SR_IntakeCaptureSourceDelivery(row["task"])
		return row["task"]
	}
	_ProxyTaskDone(Row, Done, ExitCode, Stdout, Stderr) {
		Row["done"] := true
		Done.Call(ExitCode, Stdout, Stderr)
	}
	_ProxyResolved(Record, Url, Selection) {
		Record["proxy_pending"] := false
		if !this._Current(Record) || !(Record["url"] == Url)
			return this._Fault(Record, "archive_proxy_source_changed")
		if !(Selection is Map) || !(Selection.Get("ok", 0) is Integer) || Selection["ok"] != true
				|| !(Selection.Get("inherit", "") is Integer) || !(Selection.Get("proxy", 0) is String)
				|| (Selection["inherit"] != false && Selection["inherit"] != true)
			return this._Fault(Record, "archive_proxy_refused")
		Record["proxy"] := Selection.Clone()
	}

	_NewRequest(Record, RangeProbe) {
		if !this._Current(Record) || !OllamaArchiveOfficialUrl(Record["url"], Record["asset"])
				|| !(Record["proxy"] is Map)
			throw Error("Archive request lost its destination or proxy admission.")
		local request := CurlAsyncRequest()
		Record["requests"].Push(request)
		request.Open("GET", Record["url"])
		if !Record["proxy"]["inherit"]
			request.SetProxy(Record["proxy"]["proxy"])
		local remaining := Record["deadline"] - A_TickCount
		if remaining <= 0 || !this._Current(Record)
			throw Error("Archive request outlived the original bootstrap deadline.")
		request.ConnectTimeoutMs := Min(request.ConnectTimeoutMs, remaining)
		request.TotalTimeoutMs := remaining
		if RangeProbe {
			request.SetRequestHeader("Range", "bytes=0-0")
			request.DispatchPort := Map("before_launch", ObjBindMethod(this, "_BeforeProbe", Record),
				"spawn", ObjBindMethod(this, "_SpawnProbe", Record))
		}
		return request
	}
	_BeforeProbe(Record, Request) {
		if !this._Current(Record) || !this._RequestMatches(Request, Record["url"], true)
			Request.Abort()
	}
	_SpawnProbe(Record, Executable, Arguments, Done, UnusedBefore, UnusedAfter, CaptureBytes) {
		if !this._Current(Record) || !this._RequestMatches(Record["probe"], Record["url"], true)
			throw Error("Archive metadata construction belongs to a stale source.")
		local row := Map("task", 0, "probe", 0, "delivery", 0, "done", false, "stop_attempted", false)
		Record["proxy_tasks"].Push(row)
		row["task"] := ShellRunner_StageTreeOwned(Executable, Arguments,
			ObjBindMethod(this, "_ProxyTaskDone", row, Done), CaptureBytes, true, true)
		row["probe"] := _SR_IntakeCaptureQuiescence(row["task"])
		row["delivery"] := _SR_IntakeCaptureSourceDelivery(row["task"])
		return row["task"]
	}
	_MetadataRetired(Record) {
		for row in Record["proxy_tasks"] {
			if IsObject(row["task"]) && (!HasMethod(row["probe"], "Call") || !row["probe"].Call())
				return false
			if IsObject(row["task"]) && !row["done"] && (!HasMethod(row["delivery"], "Call") || row["delivery"].Call())
				return false
		}
		for owner in Record["proxy_runs"]
			if !owner.Done || owner.Capture is Map
				return false
		return true
	}
	_ProbeSettled(Request) {
		if !Request.Completed
			return false
		if Request.CleanupPending
			Request._Cleanup()
		return Request.Completed && !IsObject(Request.Handle) && !Request.CleanupPending
	}
	_AdmitProbe(Record) {
		local request := Record["probe"]
		if !(request is CurlAsyncRequest) || !this._ProbeSettled(request) || !this._MetadataRetired(Record)
			return false
		if !this._Current(Record) || request.Aborted || !(request.Status is Integer)
			throw Error("Archive metadata is failed, stale or has an invalid HTTP status.")
		if request.Status == 301 || request.Status == 302 || request.Status == 303
				|| request.Status == 307 || request.Status == 308 {
			local location := request.GetResponseHeader("location")
			this._Resolve(Record, location)
			return false
		}
		if !OllamaArchiveProbeComplete(request, Record["asset"]) || !this._Current(Record)
			throw Error("The official archive's exact byte receipt is incomplete or foreign.")
		local download := this._NewRequest(Record, false)
		Record["download_url"] := Record["url"]
		Record["download"] := download
		if !this._Current(Record) || !this.Intake.BeginDownload(download)
			throw Error("The original intake did not admit the final official archive request.")
		Record["phase"] := "download"
		return true
	}

	_Prepared(Ticket) {
		local record := this.Record
		local issued := IsObject(Ticket) ? this.Intake.Files.IntakeTickets.Get(ObjPtr(Ticket), 0) : 0
		if !(record is Map) || !(Ticket is OllamaIntakePreparedTicket) || Ticket.Row["owner"] != this.Intake
				|| Ticket.Files != this.Intake.Files || !(issued is Map) || issued.Get("ticket", 0) != Ticket
				|| issued.Get("row", 0) != Ticket.Row || record["delivered"]
			throw ValueError("Prepared archive handoff is foreign, duplicate or stale.")
		record["prepared"] := true
		if !this._Current(record)
			throw ValueError("Prepared archive handoff outlived its captured source.")
		record["delivered"] := true
		try this.PreparedFn.Call(Ticket)
		catch Any as Err {
			this._Fault(record, "archive_prepared_delivery_refused")
			throw Err
		}
		record["phase"] := "complete"
		this._Schedule()
	}
	Poll() {
		local record := this.Record
		if !(record is Map) || record["building"] || record["busy"]
			return
		record["busy"] := true
		try {
			if !record["cancelled"] && !this._Current(record)
				this._Fault(record, "archive_source_or_deadline_changed")
			if record["cancelled"]
				this._Retire(record)
			else if record["phase"] == "namespace" {
				if this.Intake.Record != record["intake_record"] || this.Intake.Record["cancelled"]
					throw Error("Archive intake acquisition lost its original source.")
				if this.Intake.Record["phase"] == "namespace-ready"
					this._Resolve(record, record["url"])
			} else if record["phase"] == "proxy" && record["proxy"] is Map && this._MetadataRetired(record) {
				record["probe"] := this._NewRequest(record, true)
				record["phase"] := "probing"
				if !record["probe"].Send()
					throw Error("The official metadata request refused dispatch.")
			} else if record["phase"] == "probing"
				this._AdmitProbe(record)
			else if record["phase"] == "download" && !this.Intake.HasOwner() && !record["prepared"]
				throw Error("Intake retired without an issued prepared archive.")
			else if record["phase"] == "complete" && this._NoWorkOwned(record)
				this._Release(record)
		} catch Any as Err {
			this._Fault(record, "archive_observation_refused")
		} finally {
			record["busy"] := false
			this._Schedule()
		}
	}
	_Retire(Record) {
		this.Intake.Stop()
		for request in Record["requests"] {
			if !request.Completed
				request.Abort()
			if request.CleanupPending
				request._Cleanup()
		}
		for row in Record["proxy_tasks"] {
			if !IsObject(row["task"]) || (HasMethod(row["probe"], "Call") && row["probe"].Call())
				continue
			if !row["stop_attempted"] {
				row["stop_attempted"] := true
				row["task"].requestTerminate()
			}
		}
		if this._NoWorkOwned(Record)
			return this._Release(Record)
		return false
	}
	_NoWorkOwned(Record) {
		if this.Intake.HasOwner() || Record["proxy_pending"] || !this._MetadataRetired(Record)
			return false
		for request in Record["requests"]
			if !request.Completed || IsObject(request.Handle) || request.CleanupPending
				return false
		return true
	}
	_Release(Record) {
		SetTimer(this.Timer, 0)
		if !this._Owns(Record) || !this._NoWorkOwned(Record)
			return false
		this.TimerOwned := false
		this.Record := 0
		return true
	}
	_Schedule() {
		if !(this.Record is Map)
			return
		this.TimerOwned := true
		try SetTimer(this.Timer, -this.Options["poll_ms"])
		catch Any as Err {
			this._Fault(this.Record, "archive_timer_refused")
			this.Intake.Stop()
		}
	}
	Stop() {
		if this.Record is Map {
			this._Fault(this.Record, "archive_lifecycle_revoked")
			this.Poll()
		}
		return !this.HasOwner()
	}
	HasOwner() {
		return this.Record is Map || this.TimerOwned || this.Intake.HasOwner()
	}
}
