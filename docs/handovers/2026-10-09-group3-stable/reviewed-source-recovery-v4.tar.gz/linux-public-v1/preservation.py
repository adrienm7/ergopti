from pathlib import Path
import re,hashlib,json
b=Path(__file__).parent
pattern=re.compile(r'--\[(=*)\[.*?\]\1\]|--[^\n]*|\[(=*)\[.*?\]\2\]|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\b[A-Za-z_][A-Za-z_0-9]*\b',re.S)
def bodies(s):
 result=[]
 for m in re.finditer(r'helpers\.it\s*\(',s):
  tokens=list(pattern.finditer(s,m.end()));first=next((i for i,t in enumerate(tokens) if t.group()=='function'),None)
  if first is None:raise ValueError('missing test callback')
  start=tokens[first].start();stack=[]
  for token in tokens[first:]:
   v=token.group()
   if v in ['function','if','repeat']:stack.append(v)
   elif v in ['for','while']:stack.append('await_do')
   elif v=='do':
    if stack and stack[-1]=='await_do':stack[-1]='do'
    else:stack.append('do')
   elif v in ['end','until']:
    assert stack,(m.start(),token.start())
    stack.pop()
    if not stack: result.append(s[start:token.end()]);break
 return result
result=[]
for p in sorted((b/'preimages').rglob('*.lua')):
 rel=str(p.relative_to(b/'preimages'));q=b/'candidate'/rel
 if '/tests/' not in rel:continue
 old,new=p.read_text(),q.read_text();a=bodies(old);z=bodies(new);position=0
 for body in a:
  found=next((i for i in range(position,len(z)) if z[i]==body),None)
  assert found is not None,('test callback changed',rel,body[:130]);position=found+1
 oldassert=[line for line in old.splitlines() if 'helpers.assert_' in line];pos=0
 for line in oldassert:pos=new.index(line,pos)+len(line)
 result.append({'path':rel,'old_callbacks':len(a),'new_callbacks':len(z),'all_old_callback_bodies_byte_exact':True,'old_assert_lines':len(oldassert),'all_old_assert_lines_byte_exact_ordered':True,'whole_old_prefix':q.read_bytes().startswith(p.read_bytes()),'old_callback_sha256':[hashlib.sha256(x.encode()).hexdigest() for x in a]})
(b/'preservation.json').write_text(json.dumps(result,indent=2)+'\n');print([(x['path'].split('/')[-1],x['old_callbacks'],x['new_callbacks']) for x in result])
