local root = "/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path = root .. "lua/?.lua;" .. package.path
local Json = require("json")
local Policy = require("control.driver_control")
local f=assert(io.open(root.."modules/control/driver_control.json","rb"));local raw=assert(f:read("*a"));assert(f:close());local spec=Policy.validate(Json.decode(raw))
local cases={
 {"integer", [["schema":1]], true},
 {"decimal", [["schema":1.0]], true},
 {"exponent", [["schema":1e0]], true},
 {"escaped key", [["sc\u0068ema":1]], true},
 {"boolean", [["schema":true]], false},
 {"numeric string", [["schema":"1"]], false},
 {"last boolean", [["schema":1,"schema":true]], false},
 {"last numeric string", [["schema":1,"schema":"1"]], false},
 {"last decimal", [["schema":true,"sc\u0068ema":1.0]], true},
}
local passed,failed=0,0
for _,phase in ipairs({"completion","resolution"}) do
 for _,row in ipairs(cases) do
  local text="{"..row[2]..',"request_id":"result-kind","state":"requested","driver_pid":100,"successor_pid":200}'
  local decoded=Json.decode(text);assert(decoded.request_id=="result-kind" and decoded.successor_pid==200)
  local result,kind
  if phase=="completion" then result=Policy.completion(spec,text,200,Json.decode)
  else kind,result=Policy.resolve(spec,text,200,1700000000,Json.decode) end
  local expected='{"schema":1,"request_id":"result-kind","state":"completed","driver_pid":200,"successor_pid":200}\n'
  local ok = (row[3] and result==expected and (phase=="completion" or kind=="completed")) or (not row[3] and result==nil and kind==nil)
  print((ok and "PASS " or "FAIL ")..phase.." "..row[1])
  if ok then passed=passed+1 else failed=failed+1 end
 end
end
print(passed.." passed, "..failed.." failed");os.exit(failed==0 and 0 or 1)
