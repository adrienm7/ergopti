export PATH="/workspace/.ergopti-cloud/runtime/node-v22.22.2-linux-x64/bin:/workspace/.ergopti-cloud/python/bin:/workspace/.ergopti-cloud/bin:$PATH"
export npm_config_cache=/workspace/.ergopti-cloud/npm-cache
export UV_CACHE_DIR=/workspace/.ergopti-cloud/uv-cache
export XDG_DATA_HOME=/workspace/.ergopti-cloud/share
export XDG_CONFIG_HOME=/workspace/.ergopti-cloud/config
export XDG_CACHE_HOME=/workspace/.ergopti-cloud/cache
export TMPDIR=/var/tmp/ergopti-cloud-validation
export PYTHONDONTWRITEBYTECODE=1
