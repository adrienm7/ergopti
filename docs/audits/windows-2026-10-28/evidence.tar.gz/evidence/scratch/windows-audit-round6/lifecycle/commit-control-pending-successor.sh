#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import json
w=Path('/workspace/scratch/windows-audit-round6/verification-worker')
r=json.loads((w/'receipts/381-lifecycle-pending-successor-green62-exit.json').read_text());assert r['exit_code']==0,r
s=(w/'receipts/381-lifecycle-pending-successor-green62.log').read_text(errors='replace');assert '# 62 passed, 0 failed.' in s
r=json.loads((w/'receipts/382-lifecycle-pending-successor-lua-parity-exit.json').read_text());assert r['exit_code']==1,r
s=(w/'receipts/382-lifecycle-pending-successor-lua-parity.log').read_text();assert '2 passed, 2 failed' in s
CHECK
node tools/test/verify-change.cjs --plan
npm run test:ahk-encoding
npm run test:ahk-loop-capture
node tools/test/find-false-greens.cjs
npm run lint:conventions:strict
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
for p,h in json.loads((out/'control-pending-successor-candidate-hashes.json').read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
CHECK
git add -- static/ergopti_plus/windows/infra/driver_control.ahk static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk
git commit -F /workspace/scratch/windows-audit-round6/lifecycle/control-pending-successor-commit-message.txt
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
for p,h in json.loads((out/'control-pending-successor-candidate-hashes.json').read_text()).items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
print(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
CHECK
