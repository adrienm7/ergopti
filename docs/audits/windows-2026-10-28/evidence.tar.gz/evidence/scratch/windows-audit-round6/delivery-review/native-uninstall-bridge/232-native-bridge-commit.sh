set -euo pipefail
cd /workspace/ergopti-windows-r7-installer
pwd
if test -n "$(git diff --cached --name-only)"; then
    printf '%s\n' 'Refusing to mix an existing index with the native bridge' >&2
    exit 1
fi
git diff --check
git add -- static/ergopti_plus/windows/tests/unit/infra/lifecycle/test_uninstall.ahk
git commit -F /workspace/scratch/windows-audit-round6/delivery-review/native-uninstall-bridge/commit-message.txt
git log -1 --format=fuller
git status --short
