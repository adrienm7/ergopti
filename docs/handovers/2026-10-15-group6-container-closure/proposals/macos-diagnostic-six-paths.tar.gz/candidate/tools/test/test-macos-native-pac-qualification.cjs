// tools/test/test-macos-native-pac-qualification.cjs
'use strict';

/** Read direct test members of one top-level XCTest class, never its neighbors.
 * This finite source reader is not a Swift compiler or runtime admission.
 * Unknown literal/signature forms refuse instead of producing a partial oracle.
 */
function swiftClassTestMethods(source, suite) {
	if (typeof source !== 'string' || typeof suite !== 'string' || !/^[A-Za-z_]\w*$/.test(suite))
		throw new TypeError('Invalid Swift class source selector.');
	const refused = () => {
		throw new Error('Unsupported or incomplete Swift class source.');
	};
	function comment(at) {
		if (source.startsWith('//', at)) {
			const end = source.indexOf('\n', at + 2);
			return end < 0 ? source.length : end;
		}
		if (!source.startsWith('/*', at)) return null;
		let depth = 1;
		at += 2;
		while (at < source.length) {
			if (source.startsWith('/*', at)) {
				depth++;
				at += 2;
			} else if (source.startsWith('*/', at)) {
				depth--;
				at += 2;
				if (!depth) return at;
			} else at++;
		}
		return refused();
	}
	function quoted(at) {
		const start = at;
		while (source[at] === '#') at++;
		if (source[at] !== '"') return null;
		const hashes = source.slice(start, at);
		const quote = source.startsWith('"""', at) ? '"""' : '"';
		const close = quote + hashes;
		const escape = '\\' + hashes;
		at += quote.length;
		while (at < source.length) {
			if (source.startsWith(close, at)) return at + close.length;
			if (source.startsWith(escape, at)) {
				at += escape.length;
				if (source[at] === '(') at = interpolation(at + 1);
				else {
					if (at >= source.length) return refused();
					at++;
				}
			} else at++;
		}
		return refused();
	}
	function interpolation(at) {
		let depth = 1;
		while (at < source.length) {
			const end = comment(at) ?? quoted(at);
			if (end !== null) {
				at = end;
				continue;
			}
			if (source[at] === '(') depth++;
			if (source[at] === ')' && --depth === 0) return at + 1;
			at++;
		}
		return refused();
	}
	let masked = '';
	for (let at = 0; at < source.length; ) {
		const end = comment(at) ?? quoted(at);
		if (end !== null) {
			masked += source.slice(at, end).replace(/[^\r\n]/g, ' ');
			at = end;
		} else {
			// The current source cohort uses only numeric unquoted division.
			// Unsupported regex/escaped-identifier forms cannot forge a member.
			if (
				source[at] === '`' ||
				(source[at] === '/' &&
					(!/^\/\s*[0-9]/.test(source.slice(at)) || !/[A-Za-z0-9_)\]]$/.test(masked.trimEnd())))
			)
				return refused();
			masked += source[at++];
		}
	}
	const tokens = masked.match(/[A-Za-z_]\w*|[^\s]/g) ?? [];
	let depth = 0;
	let owners = 0;
	let active = false;
	const methods = [];
	for (let index = 0; index < tokens.length; index++) {
		const token = tokens[index];
		if (depth === 0 && token === 'extension' && tokens[index + 1] === suite) return refused();
		if (depth === 0 && token === 'class' && tokens[index + 1] === suite) {
			if (
				tokens[index + 2] !== ':' ||
				tokens[index + 3] !== 'XCTestCase' ||
				tokens[index + 4] !== '{'
			)
				return refused();
			owners++;
			active = true;
		}
		if (active && depth === 1 && token === 'func' && /^test\w+$/.test(tokens[index + 1] ?? '')) {
			if (tokens[index + 2] !== '(' || tokens[index + 3] !== ')') return refused();
			methods.push(tokens[index + 1]);
		}
		if (token === '{') depth++;
		if (token === '}') {
			if (active && depth === 1) active = false;
			if (--depth < 0) return refused();
		}
	}
	if (
		depth !== 0 ||
		owners !== 1 ||
		methods.length === 0 ||
		new Set(methods).size !== methods.length
	)
		return refused();
	return methods;
}

/** Independent literal source controls; no Swift or native code is executed. */
function swiftClassSourceControls() {
	const assert = require('node:assert/strict');
	const owner = 'final class Owned: XCTestCase { func testOriginal() throws { let value = 1 } }';
	const neighbor = 'final class Neighbor: XCTestCase { func testOther() {} }';
	let passed = 0;
	const accepts = [
		['literal-owner', owner],
		['neighbors-before-and-after', neighbor + owner + neighbor],
		[
			'comments-with-decoys',
			'// class Owned: XCTestCase { func testFake() {} }\n' +
				'/* outer /* nested } */ class Owned: XCTestCase { func testFake() {} } */\n' +
				owner
		],
		[
			'quoted-braces',
			'final class Owned: XCTestCase { func testOriginal() { let v = "} { func testFake()" } }'
		],
		[
			'raw-multiline-decoys',
			String.raw`let fake = ##"""
final class Owned: XCTestCase { func testFake() {} }
"""##
` + owner
		],
		[
			'nested-interpolation-quotes',
			String.raw`final class Owned: XCTestCase {
func testOriginal() { let v = "value \(call("}", { () -> String in return "{" }))" }
}`
		],
		[
			'nested-type-excluded',
			'final class Owned: XCTestCase { class Nested { func testOther() {} } func testOriginal() {} }'
		],
		[
			'current-numeric-division',
			'final class Owned: XCTestCase { func testOriginal() { let v = (42 - 2) / 10 } }'
		]
	];
	for (const [label, source] of accepts) {
		assert.deepEqual(swiftClassTestMethods(source, 'Owned'), ['testOriginal'], label);
		passed++;
	}
	const refuses = [
		['absent-class', neighbor],
		['duplicate-class', owner + owner],
		['not-XCTest', 'class Owned: NSObject { func testOriginal() {} }'],
		['empty-class', 'final class Owned: XCTestCase {}'],
		[
			'duplicate-member',
			'final class Owned: XCTestCase { func testOriginal() {} func testOriginal() {} }'
		],
		['parameterized-test', 'final class Owned: XCTestCase { func testOriginal(value: Int) {} }'],
		['unclosed-class', 'final class Owned: XCTestCase { func testOriginal() {}'],
		['unclosed-comment', owner + '/*'],
		['unclosed-string', owner + 'let value = "'],
		['unclosed-interpolation', owner + String.raw`let value = "broken \(call(`],
		['extension-ownership', owner + 'extension Owned { func testOther() {} }'],
		['escaped-identifier', 'class Owned: XCTestCase { func `testOriginal`() {} }'],
		['unsupported-regex', 'let value = /123 { func testFake() }/10\n' + owner],
		['unmatched-brace', owner + '}']
	];
	for (const [label, source] of refuses) {
		assert.throws(() => swiftClassTestMethods(source, 'Owned'), undefined, label);
		passed++;
	}
	for (const suite of ['', 'Owned|Neighbor']) {
		assert.throws(() => swiftClassTestMethods(owner, suite));
		passed++;
	}
	assert.equal(passed, 24);
	console.log('PASS: class-scoped Swift source controls=24; Swift/native execution UNRUN.');
	return passed;
}

/** Constructed transcript and actual CLI controls; native Darwin remains unexecuted. */
module.exports = function run({ workflow, admitNativePacSelector, PAC_FILTER, PAC_STEP_GUARD }) {
	swiftClassSourceControls();
	const assert = require('node:assert/strict');
	const fs = require('node:fs');
	const os = require('node:os');
	const path = require('node:path');
	const { spawnSync } = require('node:child_process');
	const reader = require('../diagnostics/managed_http_pac_xctest_evidence.cjs');
	const full = require('../diagnostics/swift_xctest_evidence.cjs');
	const repository = path.resolve(__dirname, '../..');
	const classes = ['ManagedHTTPWorkerTests', 'ManagedHTTPWireTests', 'ManagedHTTPWPADWireTests'];
	const counts = [12, 1, 1];
	let passed = 0;
	const stageSource = require('./fixtures/macos-stage-source.cjs');
	const check = (label, action) => {
		action();
		passed++;
	};
	// The source definitions are the independent method oracle; the
	// newly authored reader's method table never generates its expected receipts.
	const definitions = classes.map((suite, index) => {
		const file = path.join(
			repository,
			'static',
			'ergopti_plus',
			'macos',
			'launcher',
			'Tests',
			'ErgoptiPlusTests',
			suite + '.swift'
		);
		const methods = swiftClassTestMethods(fs.readFileSync(file, 'utf8'), suite);
		assert.equal(methods.length, counts[index]);
		return { suite, methods };
	});
	const summary = (count) =>
		` Executed ${count} tests, with 0 failures (0 unexpected) in 1.0 seconds`;
	const lines = [
		"Test Suite 'Selected tests' started at 2026-10-09 00:00:00.",
		"Test Suite 'ErgoptiPlusPackageTests.xctest' started at 2026-10-09 00:00:00."
	];
	for (const { suite, methods } of definitions) {
		lines.push(`Test Suite '${suite}' started at 2026-10-09 00:00:00.`);
		for (const method of methods) {
			lines.push(`Test Case '-[ErgoptiPlusTests.${suite} ${method}]' started.`);
			if (method === 'testActualCFNetworkHTTPPACArgumentShapeObservation')
				lines.push('PAC_ARGUMENT_SHAPE purpose=http type=http port=20000');
			if (method === 'testActualCFNetworkHTTPSPACArgumentShapeObservation')
				lines.push('PAC_ARGUMENT_SHAPE purpose=https type=https port=20000');
			lines.push(`Test Case '-[ErgoptiPlusTests.${suite} ${method}]' passed (0.001 seconds).`);
		}
		lines.push(`Test Suite '${suite}' passed at 2026-10-09 00:00:01.`, summary(methods.length));
	}
	lines.push(
		"Test Suite 'ErgoptiPlusPackageTests.xctest' passed at 2026-10-09 00:00:01.",
		summary(14),
		"Test Suite 'Selected tests' passed at 2026-10-09 00:00:01.",
		summary(14)
	);
	const valid = lines.join('\n') + '\n';
	check('exact-original-twelve-and-two-observations', () =>
		assert.equal(reader.evaluate(valid, 0, 0).complete, true)
	);
	check('PTY-normalization', () =>
		assert.equal(
			reader.evaluate('\x1b[32m' + valid.replaceAll('\n', '\r\n') + '\x1b[0m', 0, 0).complete,
			true
		)
	);
	check('full-reader-refuses-selected', () =>
		assert.notEqual(full.evaluate(valid, 0, 0).exit_status, 0)
	);
	check('literal-full-url-control', () =>
		assert.ok(
			definitions[0].methods.includes('testActualCFNetworkPACReceivesDistinctHTTPSPathsAndQueries')
		)
	);
	const observations = [
		'testActualCFNetworkHTTPPACArgumentShapeObservation',
		'testActualCFNetworkHTTPSPACArgumentShapeObservation'
	];
	check('two-explicit-observations-preserve-original-twelve', () => {
		assert.equal(
			definitions[0].methods.filter((method) => !observations.includes(method)).length,
			10
		);
		for (const method of observations)
			assert.equal(definitions[0].methods.filter((actual) => actual === method).length, 1);
	});
	let originalOnly = valid;
	for (const method of observations) {
		const name = `-[ErgoptiPlusTests.ManagedHTTPWorkerTests ${method}]`;
		const purpose =
			method === 'testActualCFNetworkHTTPPACArgumentShapeObservation' ? 'http' : 'https';
		const observationPair = `Test Case '${name}' started.\nPAC_ARGUMENT_SHAPE purpose=${purpose} type=${purpose} port=20000\nTest Case '${name}' passed (0.001 seconds).\n`;
		assert.ok(valid.includes(observationPair));
		check('missing-observation-' + method, () =>
			assert.equal(reader.evaluate(valid.replace(observationPair, ''), 0, 0).complete, false)
		);
		check('failed-observation-' + method, () =>
			assert.equal(
				reader.evaluate(
					valid.replace(`Test Case '${name}' passed`, `Test Case '${name}' failed`),
					0,
					0
				).complete,
				false
			)
		);
		check('skipped-observation-' + method, () =>
			assert.equal(
				reader.evaluate(
					valid.replace(`Test Case '${name}' passed`, `Test Case '${name}' skipped`),
					0,
					0
				).complete,
				false
			)
		);
		originalOnly = originalOnly.replace(observationPair, '');
	}
	originalOnly = originalOnly
		.replace(summary(12), summary(10))
		.replaceAll(summary(14), summary(12));
	check('original-twelve-alone-cannot-qualify-fourteen', () => {
		const verdict = reader.evaluate(originalOnly, 0, 0);
		assert.equal(verdict.complete, false);
		assert.equal(verdict.observed, 12);
		assert.equal(verdict.expected, 14);
	});
	const httpReceipt = 'PAC_ARGUMENT_SHAPE purpose=http type=http port=20000\n';
	const httpsReceipt = 'PAC_ARGUMENT_SHAPE purpose=https type=https port=20000\n';
	check('fixed-receipt-ports', () =>
		assert.deepEqual(reader.evaluate(valid, 0, 0).argument_observations, {
			http: 20000,
			https: 20000
		})
	);
	check('other-closed-shape-does-not-waive-original-tests', () =>
		assert.equal(reader.evaluate(valid.replaceAll('port=20000', 'port=20075'), 0, 0).complete, true)
	);
	check('buffered-receipts-do-not-invent-delivery-order', () =>
		assert.equal(
			reader.evaluate(
				valid.replace(httpReceipt, '').replace(httpsReceipt, '') + httpsReceipt + httpReceipt,
				0,
				0
			).complete,
			true
		)
	);
	for (const [label, bad] of [
		['missing-http-receipt', valid.replace(httpReceipt, '')],
		['missing-https-receipt', valid.replace(httpsReceipt, '')],
		['duplicate-receipt', valid + httpReceipt],
		['foreign-purpose', valid.replace('purpose=http ', 'purpose=ftp ')],
		['unused-codebook-slot', valid.replace('port=20000', 'port=20009')],
		[
			'trailing-receipt-data',
			valid.replace(
				'purpose=http type=http port=20000',
				'purpose=http type=http port=20000 extra=unadmitted'
			)
		],
		[
			'raw-value-receipt',
			valid.replace(
				'purpose=http type=http port=20000',
				'purpose=http type=http port=http://same.example/a'
			)
		]
	])
		check(label, () => assert.equal(reader.evaluate(bad, 0, 0).complete, false));
	for (const method of [
		'testActualCFNetworkPACReceivesDistinctHTTPSPathsAndQueries',
		'testActualCFNetworkPACPreservesHTTPPathAndOrderedNativeChoices'
	])
		check('original-full-url-failure-remains-failure-' + method, () =>
			assert.equal(
				reader.evaluate(
					valid.replace(
						`Test Case '-[ErgoptiPlusTests.ManagedHTTPWorkerTests ${method}]' passed`,
						`Test Case '-[ErgoptiPlusTests.ManagedHTTPWorkerTests ${method}]' failed`
					),
					0,
					0
				).complete,
				false
			)
		);
	const narrative = valid.replace(httpReceipt, '').replace(httpsReceipt, '');
	const narrativeLines = narrative.trimEnd().split('\n');
	const summaryPositions = narrativeLines.flatMap((line, index) =>
		/^\s*Executed /.test(line) ? [index] : []
	);
	assert.equal(summaryPositions.length, 5);
	for (const position of summaryPositions) {
		const placed = [...narrativeLines];
		placed.splice(position, 0, httpReceipt.trimEnd(), httpsReceipt.trimEnd());
		check('observations-before-summary-' + position, () =>
			assert.equal(reader.evaluate(placed.join('\n') + '\n', 0, 0).complete, true)
		);
	}
	for (const [label, placed] of [
		['before-root', httpReceipt + httpsReceipt + narrative],
		['after-root', narrative + httpReceipt + httpsReceipt],
		[
			'between-cases',
			narrative.replace(
				'passed (0.001 seconds).\n',
				'passed (0.001 seconds).\n' + httpReceipt + httpsReceipt
			)
		]
	])
		check('observations-' + label, () =>
			assert.equal(reader.evaluate(placed, 0, 0).complete, true)
		);
	check('foreign-prefix-observation-refused', () =>
		assert.equal(reader.evaluate(valid + 'FOREIGN ' + httpReceipt, 0, 0).complete, false)
	);
	check('fixed-public-proxy-types', () =>
		assert.deepEqual(reader.evaluate(valid, 0, 0).argument_proxy_types, {
			http: 'http',
			https: 'https'
		})
	);
	for (const [label, typed] of [
		[
			'http-purpose-https-tunnel',
			valid.replace('purpose=http type=http', 'purpose=http type=https')
		],
		[
			'https-purpose-http-proxy',
			valid.replace('purpose=https type=https', 'purpose=https type=http')
		]
	])
		check(label, () => assert.equal(reader.evaluate(typed, 0, 0).complete, true));
	for (const [label, typed] of [
		['socks-type', valid.replace('type=http', 'type=socks')],
		['unknown-type', valid.replace('type=http', 'type=auto')],
		['missing-type', valid.replace('type=http ', '')],
		['noncanonical-type', valid.replace('type=http', 'type=HTTP')],
		['duplicate-type-field', valid.replace('type=http', 'type=http type=https')]
	])
		check(label, () => assert.equal(reader.evaluate(typed, 0, 0).complete, false));
	const first = `-[ErgoptiPlusTests.${definitions[0].suite} ${definitions[0].methods[0]}]`;
	const second = `-[ErgoptiPlusTests.${definitions[0].suite} ${definitions[0].methods[1]}]`;
	const pair = `Test Case '${first}' started.\nTest Case '${first}' passed (0.001 seconds).\n`;
	for (const [label, bad] of [
		['partial', valid.slice(0, valid.lastIndexOf("Test Suite 'Selected tests' passed"))],
		['missing', valid.replace(pair, '')],
		[
			'foreign-same-count',
			valid.replaceAll(first, '-[ErgoptiPlusTests.ManagedHTTPWorkerTests testForeign]')
		],
		[
			'duplicate-start',
			valid.replace(
				`Test Case '${first}' started.`,
				`Test Case '${first}' started.\nTest Case '${first}' started.`
			)
		],
		[
			'overlapping-start',
			valid
				.replace(
					`Test Case '${first}' started.`,
					`Test Case '${first}' started.\nTest Case '${second}' started.`
				)
				.replace(
					`Test Case '${second}' started.\nTest Case '${second}' passed`,
					`Test Case '${second}' passed`
				)
		],
		['failed', valid.replace(`Test Case '${first}' passed`, `Test Case '${first}' failed`)],
		['skipped', valid.replace(`Test Case '${first}' passed`, `Test Case '${first}' skipped`)],
		['wrong-class-count', valid.replace(summary(12), summary(11))],
		['wrong-bundle-count', valid.replace(summary(14), summary(13))],
		['wrong-root-count', valid.slice(0, valid.lastIndexOf(summary(14))) + summary(13) + '\n'],
		['wrong-root', valid.replaceAll("'Selected tests'", "'All tests'")],
		['duplicate-root', valid + valid],
		['extra-summary', valid + summary(14) + '\n'],
		['noncanonical-count', valid.replace('Executed 12 tests', 'Executed 012 tests')],
		['foreign-bundle', valid.replaceAll('ErgoptiPlusPackageTests.xctest', 'Foreign.xctest')],
		[
			'wrong-suite',
			valid.replace(
				"Test Suite 'ManagedHTTPWireTests' passed",
				"Test Suite 'ManagedHTTPWireTests' failed"
			)
		],
		['malformed-terminal', valid.replace('passed (0.001 seconds).', 'passed (private).')],
		['compile-error', 'error: compilation failed\n' + valid],
		[
			'summary-skip',
			valid.replace(
				summary(12),
				' Executed 12 tests, with 1 test skipped and 0 failures (0 unexpected) in 1.0 seconds'
			)
		],
		['before-root', pair + valid.replace(pair, '')],
		['after-root', valid.replace(pair, '') + pair]
	])
		check(label, () => assert.equal(reader.evaluate(bad, 0, 0).complete, false));
	check('swift-status-preserved', () => {
		const r = reader.evaluate(valid, 73, 0);
		assert.equal(r.complete, false);
		assert.equal(r.exit_status, 73);
	});
	check('tee-status-preserved', () => {
		const r = reader.evaluate(valid, 0, 9);
		assert.equal(r.complete, false);
		assert.equal(r.exit_status, 9);
	});
	check('status-lexical', () => assert.throws(() => reader.evaluate(valid, '00', 0)));
	check('status-range', () => assert.throws(() => reader.evaluate(valid, 256, 0)));
	check('exact-selector-admitted', () => assert.ok(admitNativePacSelector(workflow)));
	for (const [label, token, replacement] of [
		['wrong-filter', PAC_FILTER, "--filter 'ManagedHTTPWorkerTests'"],
		['foreign-job', '  e2e-hs:\n', '  unrelated-native:\n'],
		[
			'foreign-step',
			'      - name: Qualify actual native PAC and WPAD XCTest controls\n',
			'      - name: Foreign controls\n'
		],
		['implicit-success-gate', PAC_STEP_GUARD, PAC_STEP_GUARD.replace(/        if: [^\n]+\n/, '')],
		[
			'forgiven-step',
			'      - name: Qualify actual native PAC and WPAD XCTest controls\n',
			'      - name: Qualify actual native PAC and WPAD XCTest controls\n        continue-on-error: true\n'
		],
		['lost-swift-status', '"${pac_statuses[0]}"', '"0"'],
		['lost-tee-status', '"${pac_statuses[1]}"', '"0"'],
		['not-actual-owner', 'pac_statuses=("${PIPESTATUS[@]}")', 'pac_statuses=(0 0)'],
		['wrong-reader', 'managed_http_pac_xctest_evidence.cjs', 'swift_xctest_evidence.cjs'],
		[
			'changed-deadline',
			'native-pac-verdict.json" ${pac_evidence_args[@]+"${pac_evidence_args[@]}"}\n        timeout-minutes: 10',
			'native-pac-verdict.json" ${pac_evidence_args[@]+"${pac_evidence_args[@]}"}\n        timeout-minutes: 20'
		]
	])
		check(label, () => {
			assert.ok(workflow.includes(token));
			assert.equal(admitNativePacSelector(workflow.replace(token, replacement)), null);
		});
	const nativeStep = workflow.match(
		/^      - name: Qualify actual native PAC and WPAD XCTest controls\n[\s\S]*?(?=^      - )/m
	)[0];
	check('before-sdk-refused', () => {
		const changed = workflow
			.replace(nativeStep, '')
			.replace(
				'      - name: Qualify actual SDK accepted-owner and deadline XCTest controls\n',
				nativeStep +
					'      - name: Qualify actual SDK accepted-owner and deadline XCTest controls\n'
			);
		assert.equal(admitNativePacSelector(changed), null);
	});
	check('duplicate-selector-refused', () =>
		assert.equal(admitNativePacSelector(workflow + nativeStep), null)
	);
	const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'ergopti-native-pac-reader-'));
	try {
		const transcript = path.join(temporary, 'transcript.log'),
			verdict = path.join(temporary, 'verdict.json');
		const script = path.resolve(__dirname, '../diagnostics/managed_http_pac_xctest_evidence.cjs');
		fs.writeFileSync(transcript, valid);
		for (const [label, swift, tee, expected] of [
			['CLI-success', '0', '0', 0],
			['CLI-swift', '73', '0', 73],
			['CLI-capture', '0', '9', 9]
		])
			check(label, () => {
				const actual = spawnSync(process.execPath, [script, transcript, swift, tee, verdict], {
					encoding: 'utf8'
				});
				assert.equal(actual.status, expected);
				const result = JSON.parse(fs.readFileSync(verdict, 'utf8'));
				assert.equal(result.exit_status, expected);
				assert.equal(result.complete, expected === 0);
				assert.deepEqual(Object.keys(result), [
					'schema',
					'cohort',
					'expected',
					'argument_observations',
					'argument_proxy_types',
					'observed',
					'complete',
					'swift_status',
					'capture_status',
					'errors',
					'exit_status'
				]);
			});
	} finally {
		fs.rmSync(temporary, { recursive: true, force: true });
	}
	stableV101PacCollectorControls(repository);
	assert.equal(passed, 82);
	console.log(
		'PASS: native PAC/WPAD selected-cohort portable controls=82; actual Darwin/native14 execution UNRUN.'
	);
};
module.exports.swiftClassTestMethods = swiftClassTestMethods;
module.exports.swiftClassSourceControls = swiftClassSourceControls;
// The standalone CLI executes its exported owner with the shared exact selector.
if (require.main === module)
	module.exports(require('./test-macos-dev-qualification-deferral.cjs').pacContext());

/** Independently discovered Worker12 remains mandatory under the exact v1.0.1 scope. */
function stableV101PacCollectorControls(repository) {
	const assert = require('node:assert/strict');
	const fs = require('node:fs');
	const path = require('node:path');
	const reader = require('../diagnostics/managed_http_pac_xctest_evidence.cjs');
	const full = require('../diagnostics/swift_xctest_evidence.cjs');
	const q = require('../ci/dev-release-qualification.cjs');
	const now = new Date('2026-10-10T20:00:00Z');
	const sha = '0123456789abcdef0123456789abcdef01234567';
	const env = {
		GITHUB_ACTIONS: 'true',
		GITHUB_REPOSITORY: 'adrienm7/ergopti',
		GITHUB_EVENT_NAME: 'push',
		GITHUB_REF: 'refs/heads/main',
		GITHUB_SHA: sha,
		ERGOPTI_DEV_RELEASE_RELEASE: 'true',
		ERGOPTI_DEV_RELEASE_PRERELEASE: 'false',
		ERGOPTI_DEV_RELEASE_CHANNEL: 'main',
		ERGOPTI_DEV_RELEASE_TAG: 'v1.0.1',
		ERGOPTI_DEV_RELEASE_VERSION: '1.0.1'
	};
	const profile = q.authorizeQualificationProfile(
		q.STABLE_V101_PROFILE_ID,
		q.environmentContext(env),
		now
	);
	const receipt = q.qualificationReceipt(profile, 'macos-native-pac', { source_sha: sha });
	const admission = full.pacQualification(receipt, env, now);
	const suites = ['ManagedHTTPWorkerTests', 'ManagedHTTPWireTests', 'ManagedHTTPWPADWireTests'];
	const definitions = {};
	for (const suite of suites) {
		const source = fs.readFileSync(
			path.join(
				repository,
				'static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests',
				suite + '.swift'
			),
			'utf8'
		);
		definitions[suite] = swiftClassTestMethods(source, suite);
	}
	assert.equal(definitions.ManagedHTTPWorkerTests.length, 12);
	function transcript(groups) {
		const lines = [
			"Test Suite 'Selected tests' started at 2026-10-10 20:00:00.",
			"Test Suite 'ErgoptiPlusPackageTests.xctest' started at 2026-10-10 20:00:00."
		];
		let count = 0;
		for (const [suite, methods] of Object.entries(groups)) {
			lines.push(`Test Suite '${suite}' started at 2026-10-10 20:00:00.`);
			for (const method of methods) {
				const name = `-[ErgoptiPlusTests.${suite} ${method}]`;
				lines.push(`Test Case '${name}' started.`);
				if (method === 'testActualCFNetworkHTTPPACArgumentShapeObservation')
					lines.push('PAC_ARGUMENT_SHAPE purpose=http type=http port=20000');
				if (method === 'testActualCFNetworkHTTPSPACArgumentShapeObservation')
					lines.push('PAC_ARGUMENT_SHAPE purpose=https type=https port=20000');
				lines.push(`Test Case '${name}' passed (0.001 seconds).`);
				count++;
			}
			lines.push(
				`Test Suite '${suite}' passed at 2026-10-10 20:00:01.`,
				`Executed ${methods.length} tests, with 0 failures (0 unexpected) in 1 seconds`
			);
		}
		for (const root of ['ErgoptiPlusPackageTests.xctest', 'Selected tests'])
			lines.push(
				`Test Suite '${root}' passed at 2026-10-10 20:00:01.`,
				`Executed ${count} tests, with 0 failures (0 unexpected) in 1 seconds`
			);
		return lines.join('\n');
	}
	const workers = { ManagedHTTPWorkerTests: definitions.ManagedHTTPWorkerTests };
	const valid = transcript(workers);
	const result = reader.evaluate(valid, 0, 0, admission);
	assert.equal(result.complete, true);
	assert.equal(result.expected, 12);
	assert.equal(result.observed, 12);
	assert.equal(result.qualification.qualified, false);
	assert.equal(result.qualification.source_sha, sha);
	assert.deepEqual(result.qualification.classes, []);
	assert.equal(reader.evaluate(valid, 0, 0).complete, false, 'default still requires all14');
	assert.equal(reader.evaluate(transcript(definitions), 0, 0).complete, true);
	assert.equal(reader.evaluate(transcript(definitions), 0, 0, admission).complete, false);
	for (const method of definitions.ManagedHTTPWorkerTests) {
		const missing = {
			ManagedHTTPWorkerTests: definitions.ManagedHTTPWorkerTests.filter((name) => name !== method)
		};
		assert.equal(reader.evaluate(transcript(missing), 0, 0, admission).complete, false);
		assert.equal(
			reader.evaluate(valid.replace(`${method}]' passed`, `${method}]' failed`), 0, 0, admission)
				.complete,
			false
		);
		assert.equal(
			reader.evaluate(valid.replace(`${method}]' passed`, `${method}]' skipped`), 0, 0, admission)
				.complete,
			false
		);
	}
	for (const suite of ['ManagedHTTPWireTests', 'ManagedHTTPWPADWireTests'])
		assert.equal(
			reader.evaluate(transcript({ ...workers, [suite]: definitions[suite] }), 0, 0, admission)
				.complete,
			false
		);
	assert.equal(
		reader.evaluate(
			valid.replace('purpose=https type=https port=20000', 'purpose=https type=https port=99999'),
			0,
			0,
			admission
		).complete,
		false
	);
	assert.equal(
		reader.evaluate(valid.replace('Selected tests', 'All tests'), 0, 0, admission).complete,
		false
	);
	assert.equal(reader.evaluate(valid, 73, 0, admission).exit_status, 73);
	assert.equal(reader.evaluate(valid, 0, 9, admission).exit_status, 9);
	assert.throws(() => reader.evaluate(valid, 0, 0, { mode: 'deferred' }));
	assert.throws(() => full.pacQualification(receipt, env, new Date(profile.expires_at)));
	console.log(
		'[OK] v1.0.1 PAC receiving requires every Worker12 method and both exact argument observations.'
	);
}
