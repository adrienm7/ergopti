const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
process.env.TZ='Europe/Paris';
const f=require('./typing-page-probe-fixture.cjs').loadMetricsTypingPage('windows');
const html=fs.readFileSync('/workspace/ergopti-windows-r6-ui-metrics/static/ergopti_plus/_shared/ui/metrics_typing/index.html','utf8');
for(const m of html.matchAll(/<([a-z]+)\b([^>]*\bid="([^"]+)"[^>]*)>/gi)){
 if(m[1]==='canvas')continue;
 const node=f.context.document.createElement(m[1]);
 node.value=m[2].match(/\bvalue="([^"]*)"/)?.[1]||'';
 const classes=new Set((m[2].match(/\bclass="([^"]*)"/)?.[1]||'').split(/\s+/));
 node.classList={contains:x=>classes.has(x),add:x=>classes.add(x),remove:x=>classes.delete(x),toggle:x=>classes.has(x)?classes.delete(x):classes.add(x)};
 f.elements.set(m[3],node);
}
const NativeDate=Date,fixedNow=Date.parse('2026-10-26T12:00:00Z');
f.context.Date=class ClockPort extends NativeDate{constructor(...args){super(...(args.length?args:[fixedNow]));}static now(){return fixedNow;}};
const manifest=Object.fromEntries(['2026-10-24','2026-10-25','2026-10-26'].map(date=>[date,{Editor:{chars:10,time:10000,wpm_chars:10}}]));
try{f.messageListeners.filter(x=>x.name==='message').at(-1).callback({data:{type:'prefetch',blob:{metrics_manifest:manifest,_prefetch_data:{historical:{},today:{}},app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}}}});}catch(e){console.log('PORTFAIL',e.stack);process.exitCode=2;}
console.log(JSON.stringify({streak:f.elements.get('records_streak')?.innerHTML,diagnostics:f.diagnostics}));
assert.equal(f.elements.get('records_streak').innerHTML,'3 jours');
