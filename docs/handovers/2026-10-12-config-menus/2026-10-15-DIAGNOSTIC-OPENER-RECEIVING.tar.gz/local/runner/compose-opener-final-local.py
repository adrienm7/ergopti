import datetime
import hashlib
import json
from pathlib import Path

OUT = Path('/workspace/.ergopti-cloud')
read = lambda n: json.loads((OUT / n).read_text())
js = read('opener-selected-js-status.json')
native = read('opener-selected-native-status.json')
recheck = read('opener-linux-recheck-status.json')
pair = read('opener-paired-gates-status.json')
assert pair['state'] == 'FAILED'
assert js['status'] == 'PASSED' and native['status'] == 'FAILED' and recheck['status'] == 'PASSED'
assert js['inputs_unchanged'] and native['inputs_unchanged'] and recheck['inputs_unchanged']
assert js['before'] == js['after'] == native['before'] == native['after']
assert all(recheck['before'][key] == value for key, value in native['before'].items())
assert recheck['before'] == recheck['after']
assert [(c['gate'], c['exit_code']) for c in native['commands'] if c['exit_code']] == [('linux', 1)]
assert [c['gate'] for c in js['commands']] == ['format', 'js']
assert [c['gate'] for c in native['commands']] == ['hs', 'hs-e2e', 'linux', 'linux-e2e', 'linux-managed-http-native']
assert [c['gate'] for c in recheck['commands']] == ['original-native-sibling-fixture', 'linux']
assert all(c['exit_code'] == 0 for c in js['commands'] + recheck['commands'])
for label, record in [('js', js), ('native', native), ('recheck', recheck)]:
    name = 'opener-linux-recheck.log' if label == 'recheck' else 'opener-selected-' + label + '.log'
    assert hashlib.sha256((OUT / name).read_bytes()).hexdigest() == record['log_sha256']
selected = {c['gate']: {'exit_code': c['exit_code'], 'seconds': c['seconds'], 'receipt': 'opener-selected-js-status.json' if c['gate'] in ['format', 'js'] else 'opener-selected-native-status.json'} for c in js['commands'] + native['commands']}
initial_linux = selected['linux']
selected['linux'] = {'exit_code': recheck['commands'][1]['exit_code'], 'seconds': recheck['commands'][1]['seconds'], 'receipt': 'opener-linux-recheck-status.json'}
assert len(selected) == 7 and all(c['exit_code'] == 0 for c in selected.values())
record = {'status': 'PASSED', 'received_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': js['before']['head'], 'source_tree': js['before']['index_tree'], 'inputs_unchanged': True, 'selected_gates': selected, 'original_paired_attempt': 'FAILED, retained unchanged', 'original_linux': initial_linux, 'initial_linux_counts': {'passed': 13848, 'failed': 1, 'modules': 521}, 'original_failure': 'First native FIFO digest timed out with100ms budget; underlying cause UNKNOWN. Printed112.03ms includes writer join and is not timer fire time.', 'unchanged_focus_replay': {'passed': 9, 'failed': 0, 'receipt': 'opener-linux-recheck-status.json'}, 'source_or_assertion_changes': False, 'nonreproduced_initial_timeout_causally_resolved': False, 'receiving_rule': 'Six original successful selected gates retained; only the failed Linux suite received again in full on identical source. Initial failure and focused replay remain distinct evidence, not a historical-debt or environment waiver.'}
(OUT / 'opener-local-final-receiving.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
