# Native macOS tooltip pixel preparation

This scratch candidate is **unexecuted**. It neither qualifies macOS on Linux nor
completes TODO 88. Parent owns source adoption, test scheduling and CI integration.
No production source, existing diagnostic helper or workflow has been edited.

Use an actual logged-in macOS GUI machine or macOS hosted runner, the repository
selected signed Hammerspoon 1.1.1 application, Python 3.9+ and Pillow 11.3.0.
The existing native diagnostic workflows acquire this exact release with
`https://github.com/Hammerspoon/hammerspoon/releases/download/1.1.1/Hammerspoon-1.1.1.zip`
and verify its signature. Provisioning must retain the official HTTPS archive's
hash and signature/signer evidence establishing the selected official publisher.
The supervisor checks signature integrity; it does not establish the official
publisher or retain signer output itself. This probe checks the app's selected version, strict signature,
copied executable hash and actual native process version. It never grants TCC and
does not call persistent Ergopti configuration storage APIs. The copied signed
application keeps its original CFBundleID: Cocoa/Hammerspoon startup defaults
remain in their existing domain and are not privately namespaced by this probe.
WindowServer and actual fonts/canvas are prerequisites;
absence is a refusal, not a skip counted as a pass.

```
python3 -m venv /tmp/ergopti-tooltip-observer
/tmp/ergopti-tooltip-observer/bin/pip install Pillow==11.3.0
/tmp/ergopti-tooltip-observer/bin/python run.py \
  --repo /path/to/ergopti \
  --app /path/to/Hammerspoon.app \
  --output /path/to/new-tooltip-evidence
```

Production Mac/shared sources are copied without modification into an invocation
owned snapshot; acquisition and final hashes must match the original tree. The
actual `assemble_blocks` formatter is recovered from `Tooltip.show_predictions`
using Lua's debug upvalue API, with its source path asserted. This deliberately
avoids arming the keyboard interaction watchers. It then calls the actual
`Renderer.render`, `canvas:isShowing`, `imageFromCanvas` and `Renderer.hide`.
Logging, locale and unrelated input-tag configuration storage are isolated. The
real SyntheticInput module reserves a persistent Quartz tag block at require-time;
this probe supplies a strict in-memory storage port allowing only that exact key
and requires its one read/write receipt. Other configuration access refuses.
Actual styling, font
selection, shared line policy, constants, placement and canvas APIs are used.

The fixture has three identical typed/corrected/continuation rows and exercises
each selected row at indentation 0, +2, -1 and -3. Twelve native PNG exports are
retained without any subsequent writing, scaling, cropping or recolouring. An
independent observer reads native attributed-text byte ranges and saved pixels:
typed text is gray, selected corrections green, selected continuations orange,
and unselected corrections/continuations bold gray. Its literal prefix/color
expectations are independently authored rather than generated from production
policy or the unchanged shared corpus. It compares real font-metric advances to
raster row starts and checks actual heavier bold ink. Fractional geometry and
native antialiasing are tolerated narrowly; inability to identify three rows is
a failing observation. Native PNG export uses the documented `saveToFile` default
point-sized representation, with no post-export image editing.

The supervisor reuses the unchanged metrics diagnostic's libproc exact executable
owner and bounded cleanup. Each invocation owns a unique copied app path and its
new result directory. Only exact copied executable processes may be signalled;
the launching `open -W` child is separately reaped. Lua stops its retained timers,
hides/deletes its owned canvas and publishes a cleanup receipt before the parent
terminates the copied application. Timeout/failure retains all preparation and
evidence for diagnosis and makes the supervisor fail. No existing Hammerspoon
instance is killed. Scratch is retained and can be removed after reviewing the
confirmed exact-owner cleanup receipt.

Evidence includes `sources.json`, native `result.json`, untouched `paint-*.png`,
pixel/attribute checks and executable cleanup in `supervisor.json`, and launch
logs. The declared scope is production formatting/rendering, native showing and
hide, font roles, raster colours/bold and indentation. Keyboard watcher lifecycle,
physical input, complete application startup and installed-package behavior are
explicitly unmeasured. This preparation needs independent review and an actual
Mac execution slot before adoption or any pass claim.
