from pathlib import Path
import json,re,hashlib,datetime,subprocess,os,stat
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-merge11-final-hs');R=Path('/workspace/ergopti-macos-field-admission')
GO=json.loads((O/'go.json').read_text());HEAD=GO['commit'];TREE=GO['tree'];assert GO['source_phase']=='committed_source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
d=json.loads((O/'receipt.json').read_text());exit_receipt=json.loads((O/'tool-exit.json').read_text())
assert d['state']=='ALL_GATES_ACTUAL0' and exit_receipt['actual_child_wait_exit']==0
assert d['head']==HEAD and d['tree']==TREE
assert git('rev-parse','HEAD').decode().strip()==HEAD and git('write-tree').decode().strip()==TREE
assert not git('status','--porcelain')
expected=['node-preflight','lua54-preflight','luajit-native-preflight','sqlite-preflight','pwsh-preflight','git-preflight','hs-groups-inventory','hs-integration','hs-meta','hs-core','hs-modules','hs-menu_llm','hs-menu_input','hs-ui','hs-other','hs-e2e']
assert [g['name']for g in d['gates']]==expected
staged=git('ls-files','--stage','-z');digest=hashlib.sha256(staged).hexdigest();physical_count=0
for entry in staged.split(b'\0'):
 if not entry:continue
 meta,path=entry.split(b'\t',1);mode,oid,stage=meta.split();p=R/os.fsdecode(path);st=p.lstat();data=os.fsencode(os.readlink(p))if stat.S_ISLNK(st.st_mode)else p.read_bytes();observed=b'120000'if stat.S_ISLNK(st.st_mode)else b'100755'if st.st_mode&0o111 else b'100644'
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()==oid and observed==mode and stage==b'0',os.fsdecode(path)
 physical_count+=1
initial=d['physical_initial'];final=d['physical_final'];assert initial==dict(final,label='initial')
assert initial['stage_digest']==digest
allmods=[];declared=[];groups=[];newcases=[];canon=(O/'hs-groups-inventory.log').read_text().splitlines();assert canon==['integration','meta','core','modules','menu_llm','menu_input','ui','other']
for g in d['gates']:
 assert g['actual_exit']==0,g['name'];p=Path(g['log']);assert sha(p)==g['sha256'];s=p.read_text(errors='strict');name=g['name']
 for k in ['source_before','source_after']:
  v=g[k];assert v['tree']==TREE and v['stage_digest']==digest and not v['mismatches'] and not v['unstaged'] and not v['untracked']
 if name.startswith('hs-')and name not in ('hs-groups-inventory','hs-e2e'):
  h=re.search(r'Module group "([^"]+)": (\d+) of (\d+) module\(s\)',s);assert h and h[1]==name[3:]
  loaded=re.findall(r'^>>> Loading ([^\r\n]+)',s,re.M);assert int(h[2])==len(loaded);declared.append(int(h[3]));allmods.extend(loaded)
  summary=re.search(r'OVERALL RESULTS:\s*Total modules:\s*(\d+)\s*Passed tests:\s*(\d+)\s*Failed tests:\s*(\d+)',s);assert summary and int(summary[1])==len(loaded) and int(summary[3])==0
  rows=[json.loads(line[len('# lua_timing '):])for line in s.splitlines()if line.startswith('# lua_timing ')]
  cases=[x for x in rows if x['kind']=='case'];assert all(x['status']=='pass'for x in cases) and len(cases)==int(summary[2])
  mods=[x for x in rows if x['kind']=='module'];assert all(x['status']=='pass'for x in mods)and len(mods)==len(loaded)
  for x in cases:
   if x['module'] in ['tests.unit.infra.field_run.test_field_run','tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_deferred_errors']or 'text_carrier_avoids_held_key'in x['module']:newcases.append(x)
  groups.append({'name':name,'modules':len(loaded),'passed':int(summary[2]),'failed':0})
assert len(declared)==8 and len(set(declared))==1 and len(allmods)==len(set(allmods))==declared[0]
assert sum(x['passed']for x in groups)>25000
assert sum(x['module']=='tests.unit.infra.field_run.test_field_run'for x in newcases)==34
assert sum(x['module']=='tests.unit.ui.menu.keyboard_layout.test_menu_keyboard_layout_deferred_errors'for x in newcases)==2
assert sum('text_carrier_avoids_held_key'in x['module']for x in newcases)==3
s=(O/'hs-e2e.log').read_text();m=re.search(r'^# pass (\d+) / (\d+)$',s,re.M);assert m and int(m[1])==int(m[2])==185
skip=re.search(r'^# skip (\d+) driver-specific vector\(s\) or host-specific scenario\(s\)$',s,re.M);assert skip and int(skip[1])==1
obs=json.loads((O/'residual-observer.json').read_text());assert obs['qualified']and not obs['live_refs']and not obs['unreadable_live_same_uid']
q={'qualified_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_phase':'committed_source','source_commit':HEAD,'source_tree':TREE,'actual_child_wait_exit':exit_receipt['actual_child_wait_exit'],'selected_gates_all_actual0':True,'gate_count':len(d['gates']),'full_mac_unit_tests':{'groups':groups,'passed':sum(x['passed']for x in groups),'failed':0,'modules':len(allmods),'unique_modules':len(set(allmods))},'canonical_partition_complete':True,'regression_execution_cases':newcases,'e2e':{'pass':185,'total':185,'preexisting_driver_or_host_specific_na':1,'scenario_bodies_not_modified_by_this_validator':True},'physical_index_invariance':{'files':physical_count,'stage_digest':digest,'all_before_after_matches':True},'residual_observer':obs,'receipt_sha256':sha(O/'receipt.json'),'tool_exit_sha256':sha(O/'tool-exit.json'),'upstream_owner_provenance':{'dev_commit':GO['dev_commit'],'root_owned_candidate_f699_integrated':False,'source':'Canonical KeyEventHealth.now_ms and Unicode carrier remain exactly incoming dev. Private candidate three additional tests are not delivered.'},'scope':'Linux-host Lua54/Hammerspoon modeled native ports, actual LuaJIT/luv/lfs/SQLite helpers. No Darwin/AppKit/Carbon/physical keyboard qualification inferred.'}
(O/'modules.json').write_text(json.dumps(allmods,indent=2)+'\n');(O/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in ['regression_execution_cases','residual_observer','full_mac_unit_tests']},indent=2));print(json.dumps(q['full_mac_unit_tests'],indent=2))
