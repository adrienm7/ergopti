from pathlib import Path
import subprocess,json,datetime,os
s=Path('/workspace/scratch/oct28-final34-common')
t=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).isoformat()
with(s/'producer.log').open('wb')as f:
 p=subprocess.Popen(['python3',str(s/'run.py')],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 (s/'producer.json').write_text(json.dumps({'wrapper_pid':os.getpid(),'producer_pid':p.pid,'started_paris':t(),'source_commit':'80e8092f2051ad4927dcc880f9585a0e69f6613a'})+'\n')
 rc=p.wait()
(s/'tool-exit.json').write_text(json.dumps({'wrapper_pid':os.getpid(),'producer_pid':p.pid,'actual_child_wait_exit':rc,'finished_paris':t(),'scope':'Actual subprocess wait status recorded by detached owned wrapper; no tool-session exit inferred.'},indent=2)+'\n')
raise SystemExit(rc)
