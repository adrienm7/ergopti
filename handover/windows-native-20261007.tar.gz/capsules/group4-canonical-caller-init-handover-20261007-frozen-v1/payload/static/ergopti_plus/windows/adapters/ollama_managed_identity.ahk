﻿; adapters/ollama_managed_identity.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Managed Ollama Request Identity
; DESCRIPTION:
; Allocates an OS GUID as an intent ticket, never a process or file capability.
; ==============================================================================

OllamaManagedNewTicketId() {
	local value := Buffer(16, 0)
	if DllCall("ole32\CoCreateGuid", "Ptr", value, "Int") != 0
		throw Error("The managed request identity could not be allocated.")
	local ticket := ""
	loop value.Size
		ticket .= Format("{:02x}", NumGet(value, A_Index - 1, "UChar"))
	return ticket
}
