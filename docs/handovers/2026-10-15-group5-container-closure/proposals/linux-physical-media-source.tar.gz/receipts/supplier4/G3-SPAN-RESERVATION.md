Group 5 follow-up to #issuecomment-6197855627: Root authorizes PRIVATE copied
Linux producer implementation now. Canonical `adapters/keyboard_hook.lua` and
`adapters/evdev_reader.lua` remain G3-owned and untouched until the owner checkpoint.
Please flag active overlapping supplier work. No branch/gate or runner changes.

Proposed exact supplier regions:

- Reader `build_ffi_backend`/original-native-port snapshot + existing `open`
  descriptor state and `event_view`: bind the original C `luv.fs_fstat` on the
  already-open descriptor, retain positive exact `st_rdev <= 2^53-1` as canonical
  decimal `device`, reject absent/unsafe values. No second reader/open/grab;
  custom backends cannot mint media/native authority. Preserve all original
  capabilities, read_epoch, provider/codec/source-owner/close-debt guards.
- Hook `_dispatch_post_remap` physical callback: append only the fifth argument
  `_event_receipts[ev]` when the original genuine/current event is admitted.
  Existing `(code, key_name, char, value)` stay exact. Add weak private receipt
  records and `physical_event_view(capability)` / `physical_source_current(capability)`
  bound to the actual Hook session, physical source classification, original
  Reader/source owner+observer and no SYN loss/reconciliation. No caller-positive
  Boolean, detached row, remapped output or synthetic event grants rights.

Group 5 consumer/keylogger/daemon private joins reuse the shared five-key media
policy and current privacy/hold epoch. Admission occurs before the next native
read; capture app/privacy then. Pause/private/auth changes cancel the entire hold.
No media alias enters numeric keyboard geometry/WPM; old keyboard/volume behavior
is retained. Failed SQL retains the exact pending media queue.

Authentic ABI evidence: upstream luv commit
7233e6dea92498a244feb51b790c1ba51e8abbff/src/fs.c forwards uv_stat_t.st_rdev via
lua_pushinteger and invokes uv_fs_fstat with the existing descriptor; synchronous
requests are cleaned before return. Actual installed C binding observes distinct
/dev/null and /dev/zero rdev and returns EBADF after acknowledged same-fd close.
That proves only the descriptor API. This container has no /dev/input/event0 or
/dev/uinput: no physical evdev/grab/compositor/hardware proof is claimed.
