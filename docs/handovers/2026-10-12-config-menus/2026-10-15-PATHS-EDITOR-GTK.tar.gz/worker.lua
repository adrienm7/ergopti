-- Private native receiving scenario. Production modules and file authorities
-- remain intact; this is an X11/WebKit UI subject, not an installed daemon.
local mode, target, receipt_path = assert(arg[1]), assert(arg[2]), assert(arg[3])
local report = { mode = mode, status = "running", assertions = {}, cleanup = {},
	limitations = { "no physical input", "no native Browse picker", "no daemon restart" } }
local Json = require("json")
local Manager, Gtk, GLib

local function check(value, name)
	report.assertions[#report.assertions + 1] = { name = name, passed = value == true }
	print((value == true and "PASS " or "FAIL ") .. name)
	assert(value == true, name)
end

local function read(path)
	local file, detail, errno = io.open(path, "rb")
	if not file then return nil, detail, errno end
	local read_ok, bytes, read_error = pcall(file.read, file, "*a")
	local close_ok, closed, close_error = pcall(file.close, file)
	if not close_ok or closed ~= true then
		report.cleanup.stream_errors = report.cleanup.stream_errors or {}
		report.cleanup.stream_errors[#report.cleanup.stream_errors + 1] = tostring(close_ok and close_error or closed)
	end
	-- The original read failure remains primary even if its held stream also
	-- refuses close. A successful read needs the actual close acknowledgement.
	if not read_ok then error(bytes, 0) end
	if type(bytes) ~= "string" then error(tostring(read_error or "native file read failed"), 0) end
	if not close_ok or closed ~= true then error(tostring(close_ok and close_error or closed), 0) end
	return bytes
end

local function pump()
	-- Bound each dispatch batch; a recurring source must not monopolize the probe.
	for _ = 1, 100 do
		if not Gtk.events_pending() then break end
		Gtk.main_iteration_do(false)
	end
	GLib.usleep(20000)
end

local function wait(predicate, seconds)
	local deadline = GLib.get_monotonic_time() + (seconds or 15) * 1000000
	repeat
		pump()
		if predicate() then return true end
	until GLib.get_monotonic_time() >= deadline
	return false
end

local function evaluate(source)
	local view = assert(Manager.webview_for("paths_editor"), "actual paths_editor WebView missing")
	local done, answer, failure = false, nil, nil
	view:run_javascript(source, nil, function(_, result)
		local called, value = pcall(function()
			return view:run_javascript_finish(result):get_js_value():to_string()
		end)
		if called then answer = value else failure = tostring(value) end
		done = true
	end, nil)
	assert(wait(function() return done end, 10), "actual WebKit evaluation deadline")
	assert(not failure, failure)
	return answer
end


local passed, failure = xpcall(function()
 local lgi = require("lgi")
 Gtk, GLib = lgi.require("Gtk", "3.0"), lgi.GLib
 lgi.require("WebKit2", "4.1")
 local Paths = require("infra.config_paths")
 local I18n = require("infra.i18n")
 I18n.init()
 local stage = assert(arg[4])
 local defaultConfig = assert(os.getenv("XDG_CONFIG_HOME")) .. "/ergopti"
 local defaultLogs = assert(os.getenv("XDG_STATE_HOME")) .. "/ergopti_plus/logs"
 local customConfig, customLogs = target .. "/custom-B", target .. "/logs-B/ergopti_plus"
 local typedConfig, typedLogs = target .. "/typed folder D", target .. "/typed logs D/ergopti_plus"
 local expectedConfig, expectedLogs = customConfig, customLogs
 if mode == "type-config" then expectedConfig = typedConfig
 elseif mode == "type-logs" then expectedLogs = typedLogs
 elseif mode == "clear-config" then expectedConfig = defaultConfig
 elseif mode == "clear-logs" then expectedLogs = defaultLogs
 elseif mode == "reset" then expectedConfig, expectedLogs = defaultConfig, defaultLogs end
 Manager = require("ui.webview_manager")
 Manager.set_daemon_state({})
 if stage == "receive" then
  check(Paths.set_config_dir(customConfig) == true, "genuine bootstrap setup custom configuration B")
  check(Paths.set_logs_dir(customLogs) == true, "genuine bootstrap setup custom logs B")
 end
 check(Manager.show("paths_editor") == true, "genuine Manager shows paths editor")
 check(wait(function() return evaluate("String(typeof _data==='object' && _data!==null && document.getElementById('input-config-dir').value!=='')") == "true" end), "native HostBridge initializes real page")
 local function value(name) return evaluate("String(document.getElementById('input-" .. name .. "-dir').value)") end
 if stage == "reopen" then
  check(Paths.get_config_dir() == expectedConfig, "new process resolves expected saved configuration")
  check(Paths.get_logs_dir() == expectedLogs, "new process resolves expected saved logs")
  check(value("config") == expectedConfig, "new document displays saved configuration")
  check(value("logs") == expectedLogs, "new document displays saved logs")
  evaluate("document.getElementById('btn-cancel').click();'clicked'")
  check(wait(function() return not Manager.is_visible("paths_editor") end), "real Cancel retires reopened document")
  return
 end
 check(value("config") == customConfig and value("logs") == customLogs, "initial fields display genuine B bootstrap")
 local expectedFieldConfig, expectedFieldLogs = expectedConfig, expectedLogs
 if mode == "clear-config" then expectedFieldConfig = "" end
 if mode == "clear-logs" then expectedFieldLogs = "" end
 if mode == "reset" then evaluate("document.getElementById('btn-reset').click();'reset'")
 elseif mode ~= "untouched" then
  local field = mode:find("config",1,true) and "config" or "logs"
  local raw = field == "config" and expectedFieldConfig or expectedFieldLogs
  evaluate("var n=document.getElementById('input-" .. field .. "-dir');n.value=" .. assert(Json.encode(raw)) .. ";n.dispatchEvent(new Event('input',{bubbles:true}));'entered'")
 end
 check(value("config") == expectedFieldConfig and value("logs") == expectedFieldLogs, "literal edit or reset reaches native document")
 for _,locale in ipairs({"fr", "en"}) do
  check(I18n.set_locale(locale) == true, "production locale switches before duplicate ready " .. locale)
  local expectedCaption = I18n.get("paths_editor.heading")
  evaluate("_post({action:'ready'});'production-ready-posted'")
  check(wait(function() return evaluate("String(_strings['paths_editor.heading'])") == expectedCaption end), "real duplicate ready response received " .. locale)
  check(value("config") == expectedFieldConfig, "duplicate ready preserves configuration intent " .. locale)
  check(value("logs") == expectedFieldLogs, "duplicate ready preserves logs intent " .. locale)
  check(evaluate("String(document.getElementById('default-config-dir').textContent)") == defaultConfig, "real default configuration caption refreshed " .. locale)
  check(evaluate("String(document.getElementById('default-logs-dir').textContent)") == defaultLogs, "real default logs caption refreshed " .. locale)
 end
 check(Paths.get_config_dir() == customConfig and Paths.get_logs_dir() == customLogs, "ready responses do not publish edited paths")
 evaluate("document.getElementById('btn-save').click();'clicked'")
 check(wait(function() return not Manager.is_visible("paths_editor") end), "real Save writer persists and retires page")
 check(Paths.get_config_dir() == expectedConfig, "real Save publishes independent expected configuration")
 check(Paths.get_logs_dir() == expectedLogs, "real Save publishes independent expected logs")
 report.expected_config, report.expected_logs = expectedConfig, expectedLogs
end, debug.traceback)
local environment_ok = true
-- Attempt independent cleanup even after any assertion or native callback failure.
if Manager then
	local called, retired = pcall(Manager.shutdown)
	report.cleanup.manager_called, report.cleanup.manager_retired = called, called and retired == true
	if not called or retired ~= true then
		passed = false
		report.cleanup.error = tostring(retired)
		if failure == nil then failure = "actual manager cleanup refused: " .. tostring(retired) end
	end
end
report.status = environment_ok and (passed and "PASS" or "FAIL") or "ENVIRONMENT_UNRUN"
report.failure = not passed and tostring(failure) or nil
if not passed then io.stderr:write(tostring(failure), "\n") end
local receipt, open_error = io.open(receipt_path, "wb")
local receipt_ok = false
if receipt then
	local write_ok, written, write_error = pcall(function()
		return receipt:write(assert(Json.encode(report)), "\n")
	end)
	local close_ok, closed, close_error = pcall(receipt.close, receipt)
	receipt_ok = write_ok and written ~= nil and close_ok and closed == true
	if not receipt_ok then
		io.stderr:write("Native receipt write/close refused: ", tostring(write_ok and write_error or written),
			" / ", tostring(close_ok and close_error or closed), "\n")
	end
else io.stderr:write("Native receipt open refused: ", tostring(open_error), "\n") end
if not receipt_ok then os.exit(1) end
os.exit(environment_ok and (passed and 0 or 1) or 2)
