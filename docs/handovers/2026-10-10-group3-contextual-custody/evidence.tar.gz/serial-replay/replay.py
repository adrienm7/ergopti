"""Frozen component replay plan. Runtime requires explicit parent release."""

from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('/workspace/ergopti')
HERE = Path(__file__).resolve().parent
PROPOSAL = HERE.parent / 'contextual-shortcut-recovery-assessment'
CHECKED = HERE.parent / 'contextual-shortcut-recovery-checked-runner'
SOURCE = 'static/ergopti_plus/linux/modules/shortcuts/keyboard_shortcuts.lua'
TEST = 'static/ergopti_plus/linux/tests/unit/modules/shortcuts/test_keyboard_shortcuts.lua'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_bytes())

def verify_members(folder, entries):
    for relative, expected in entries.items():
        body = (folder / relative).read_bytes()
        assert sha(body) == expected['sha256'] and len(body) == expected['bytes'], relative

def inspect_dependencies():
    manifest = read_json(PROPOSAL / 'dependency-manifest.json')
    observed = []
    for expected in manifest['files']:
        body = (ROOT / expected['path']).read_bytes()
        actual = {'path': expected['path'], 'bytes': len(body), 'sha256': sha(body)}
        assert actual == expected, 'Changed preparation dependency: ' + expected['path']
        observed.append(actual)
    return {'files': observed, 'tree_copy_created': False}

def planned_runs():
    enrollment = read_json(CHECKED / 'enrollment-receipt.json')
    contextual = enrollment['independent_expected_census']['contextual-late-custody']['unique_names']
    assert len(contextual) == 20 and len(set(contextual)) == 20
    # Required failing identities are frozen from source causal boundaries,
    # before any replay, not inferred from a candidate or mutant output.
    negative_names = contextual[1:]
    required_failures = {
        'late-guard-removed': negative_names,
        'stale-admission-after-source': contextual[7:10],
        'post-admission-owner-fence-removed': [contextual[14], contextual[17]],
        'post-decision-owner-fence-removed': [contextual[18]],
        'terminal-owner-fence-removed': [contextual[19]],
        'issuer-pins-removed': [contextual[15], contextual[16], contextual[17], contextual[19]],
        'source-error-escape': [contextual[13]],
    }
    runs = []
    for control in enrollment['future_negative_controls']:
        runs.append({'name': 'enrollment-' + control['name'], 'kind': 'enrollment-negative',
            'source': str(PROPOSAL / 'candidate' / SOURCE),
            'test': control.get('test', str(PROPOSAL / 'candidate' / TEST)),
            'cohort': control['cohort'], 'filter': control.get('filter'),
            'expected': 'nonzero exit; enrollment refusal or unknown-cohort error'})
    for image in ['original', 'candidate']:
        runs.append({'name': image + '-contextual', 'kind': 'component',
            'source': str(PROPOSAL / image / SOURCE), 'test': str(PROPOSAL / 'candidate' / TEST),
            'cohort': 'contextual-late-custody', 'filter': None,
            'expected_failed_names': negative_names if image == 'original' else []})
    for mutant, failed in required_failures.items():
        runs.append({'name': mutant, 'kind': 'component',
            'source': str(PROPOSAL / 'mutants' / (mutant + '.lua')),
            'test': str(PROPOSAL / 'candidate' / TEST), 'cohort': 'contextual-late-custody',
            'filter': None, 'expected_failed_names': failed})
    for image in ['original', 'candidate']:
        for cohort in ['magic-editor-broker', 'configuration-owner']:
            runs.append({'name': image + '-' + cohort, 'kind': 'component',
                'source': str(PROPOSAL / image / SOURCE), 'test': str(PROPOSAL / 'original' / TEST),
                'cohort': cohort, 'filter': None, 'expected_failed_names': []})
    assert len(runs) == 18
    for run in runs:
        run['source_sha256'] = sha(Path(run['source']).read_bytes())
        run['test_sha256'] = sha(Path(run['test']).read_bytes())
    return runs

def component_observations(run, stdout, exit_code):
    expected = read_json(CHECKED / 'enrollment-receipt.json')['independent_expected_census'][run['cohort']]
    text = stdout.decode('utf-8', errors='replace')
    selected = re.findall(r'^SELECTED (.+)$', text, re.M)
    passed = re.findall(r'^  ok   (.+)$', text, re.M)
    failed = re.findall(r'^  FAIL (.+?) — ', text, re.M)
    results = re.findall(r'^RESULT (\d+) passed, (\d+) failed; selected=(\d+) intended=(\d+) completed=(\d+) enrollment_errors=(\d+) cohort=(\S+) filter=(.+)$', text, re.M)
    assert len(results) == 1, 'Missing or repeated exact completion receipt'
    totals = results[0]
    assert sorted(selected) == sorted(expected['unique_names']) and len(set(selected)) == expected['count'], 'Selected case census differs'
    assert sorted(passed + failed) == sorted(expected['unique_names']), 'Completed case identity census differs'
    assert len(passed) + len(failed) == expected['count'], 'Completed case total differs'
    assert [int(value) for value in totals[:6]] == [len(passed), len(failed), expected['count'], expected['count'], expected['count'], 0]
    assert sorted(failed) == sorted(run['expected_failed_names']), 'Independent causal failure set differs'
    assert exit_code == (1 if failed else 0), 'Native process exit differs from test result'
    return {'selected_names': selected, 'passed_names': passed, 'failed_names': failed,
            'passed': len(passed), 'failed': len(failed), 'intended': expected['count'],
            'enrollment_errors': 0, 'independent_expected_failed_names': run['expected_failed_names']}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', action='store_true')
    parser.add_argument('--execute-after-parent-release', action='store_true')
    args = parser.parse_args()
    # Preserve both previously reviewed packets before doing anything else.
    original = read_json(PROPOSAL / 'final-source-seal.json')
    checked = read_json(CHECKED / 'enrollment-receipt.json')
    verify_members(PROPOSAL, original['files'])
    verify_members(CHECKED, checked['files'])
    assert len(original['files']) == 24
    runs = planned_runs()
    if args.plan:
        print(json.dumps({'runtime': 'UNRUN', 'abis': ['luajit', 'lua5.4'], 'serial': True, 'runs': runs}, indent=2))
        return 0
    if not args.execute_after_parent_release:
        raise SystemExit('Runtime HOLD: use --execute-after-parent-release only after explicit parent release')
    # A new result namespace prevents overwriting any previous execution evidence.
    results_dir = HERE / 'execution'
    assert not results_dir.exists(), 'Refusing to overwrite previous replay evidence'
    results_dir.mkdir()
    dependencies_before = inspect_dependencies()
    (results_dir / 'dependencies-before.json').write_text(json.dumps(dependencies_before, indent=2) + '\n')
    receipt = {'runtime': 'RUNNING', 'serial': True, 'runs': [], 'errors': [],
        'proposal_seal_sha256': sha((PROPOSAL / 'final-source-seal.json').read_bytes()),
        'checked_receipt_sha256': sha((CHECKED / 'enrollment-receipt.json').read_bytes()),
        'runner_sha256': sha((CHECKED / 'run-checked.lua').read_bytes()),
        'pre_canonical_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()}
    try:
        for abi in ['luajit', 'lua5.4']:
            executable = shutil.which(abi)
            assert executable, 'Required activated Lua ABI unavailable: ' + abi
            abi_dir = results_dir / abi
            abi_dir.mkdir()
            version = subprocess.run([executable, '-v'], cwd=ROOT, capture_output=True, timeout=15)
            (abi_dir / 'version.stdout').write_bytes(version.stdout)
            (abi_dir / 'version.stderr').write_bytes(version.stderr)
            assert version.returncode == 0, 'Required Lua ABI did not start: ' + abi
            for run in runs:
                assert sha(Path(run['source']).read_bytes()) == run['source_sha256']
                assert sha(Path(run['test']).read_bytes()) == run['test_sha256']
                scratch = abi_dir / (run['name'] + '-tmp')
                scratch.mkdir()
                environment = os.environ.copy()
                environment['TMPDIR'] = str(scratch)
                command = [executable, str(CHECKED / 'run-checked.lua'), str(ROOT), run['source'], run['test'], run['cohort']]
                if run['filter'] is not None:
                    command.append(run['filter'])
                outcome = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, timeout=90)
                out_path, err_path = abi_dir / (run['name'] + '.stdout'), abi_dir / (run['name'] + '.stderr')
                out_path.write_bytes(outcome.stdout)
                err_path.write_bytes(outcome.stderr)
                actual = {'abi': abi, 'plan': run, 'command': command, 'cwd': str(ROOT),
                    'exit': outcome.returncode, 'stdout': {'path': str(out_path), 'bytes': len(outcome.stdout), 'sha256': sha(outcome.stdout)},
                    'stderr': {'path': str(err_path), 'bytes': len(outcome.stderr), 'sha256': sha(outcome.stderr)}}
                try:
                    if run['kind'] == 'enrollment-negative':
                        assert outcome.returncode != 0, 'Mis-selection control returned false green'
                        output = (outcome.stdout + outcome.stderr).decode('utf-8', errors='replace')
                        assert 'ENROLLMENT_REFUSED' in output or 'Unknown independent cohort:' in output, 'Negative failed without its enrollment refusal'
                        actual['status'] = 'EXPECTED_ENROLLMENT_REFUSAL'
                    else:
                        actual['observations'] = component_observations(run, outcome.stdout, outcome.returncode)
                        actual['status'] = 'EXPECTED_CAUSAL_FAILURE' if run['expected_failed_names'] else 'PASS'
                except AssertionError as error:
                    actual['status'] = 'UNEXPECTED_RESULT'
                    actual['error'] = str(error)
                    receipt['errors'].append({'abi': abi, 'name': run['name'], 'error': str(error)})
                receipt['runs'].append(actual)
                print(json.dumps({'abi': abi, 'name': run['name'], 'status': actual['status'], 'exit': outcome.returncode}), flush=True)
        dependencies_after = inspect_dependencies()
        (results_dir / 'dependencies-after.json').write_text(json.dumps(dependencies_after, indent=2) + '\n')
        assert dependencies_after == dependencies_before
        verify_members(PROPOSAL, original['files'])
        verify_members(CHECKED, checked['files'])
        receipt['post_canonical_head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
        receipt['pre_post_dependency_pins_equal'] = True
        receipt['prior_packets_immutable'] = True
        receipt['runtime'] = 'COMPLETE' if not receipt['errors'] else 'COMPLETE_WITH_UNEXPECTED_RESULTS'
    except Exception as error:
        receipt['runtime'] = 'INCOMPLETE'
        receipt['errors'].append({'orchestrator': type(error).__name__, 'error': str(error)})
        raise
    finally:
        (results_dir / 'replay-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return 0 if not receipt['errors'] else 1

if __name__ == '__main__':
    sys.exit(main())
