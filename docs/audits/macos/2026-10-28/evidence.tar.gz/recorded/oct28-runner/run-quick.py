from pathlib import Path
import os,subprocess,json,concurrent.futures,time
w=Path('/workspace/ergopti-macos-native-validation');d=Path('/workspace/scratch/oct28-runner');e=dict(os.environ);e.update(USER='agent',LOGNAME='agent');e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu'
for key in ['TMPDIR','XDG_RUNTIME_DIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_STATE_HOME']:
 p=d/key.lower();p.mkdir(mode=0o700,exist_ok=True);e[key]=str(p)
def run(spec):
 name,cmd,cwd=spec;start=time.monotonic()
 with (d/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=cwd,env=e,stdout=f,stderr=subprocess.STDOUT)
 x={'name':name,'command':cmd,'cwd':str(cwd),'actual_exit':r.returncode,'seconds':time.monotonic()-start};print(json.dumps(x),flush=True);return x
specs=[('matrix',['node','tools/test/test-bash-resolution.cjs'],w),('discovery5',['lua','tests/run.lua','--only=tests.unit.harness.test_runner_discovery_failure'],w/'static/ergopti_plus/macos'),('hotpath8',['lua','tests/run.lua','--only=tests.unit.infra.logger.test_hotpath_segments_declared'],w/'static/ergopti_plus/macos')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:r=list(pool.map(run,specs))
(d/'quick-receipt.json').write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(any(x['actual_exit'] for x in r))
