# Serial qualification proposal

SOURCE ONLY. Root39531 owns the local slot. Nothing in this follow-up has been imported or executed.

1. Transparent original309b body14 diagnostic on original309b core to collect fixed dispatch/callback/fence/retained booleans; expected original7/7 is retained separately. Original marker output and assertions are unchanged.
2. Eleven native descriptor controls plus three coordinator cause controls on both actual Lua ABIs, before/after producer source separately. Preserve generic construction seven and all original raw-owner/auth/forwarding assertions. Stop at a candidate failure. Previous failed source/captures are never replaced.
3. After source-qualified core, genuine preflight25 and corrected body14 on an admitted fresh ordinary stage under exact f864 launch/entry and unchanged sole guardian, recording actual PIDbirth/close receipts. Stop at the first candidate failure. Both new captures must prove pending0/rescue0 and full physical owner reap.
4. Only after successful candidates, original body14 fixture on the SAME corrected producer isolates the six post-retirement ownership assumptions; corrected body14 on original309b producer isolates the descriptor cancel receipt correction. Expected-before failures remain causal, never credited as passes. Original preflight24 remains a separate honest contract migration receipt.

Output-hop composition receives only identical private native/parent cause handling and needs its own later qualification; neither its sink nor its writer ownership changes here. No actual18/30 proof, GUI/native packaging/installation or enterprise-network credit is inherited.
