# Managed Windows models directory source

One shared Windows leaf policy emits one AHK getter through the existing three-output owner. The directory is a separate mutable-data child of the explicitly owned managed runtime; no logs root is reused. Every old managed-root refusal body remains intact. The new independent models corpus rejects malformed/reserved components and a collision with the immutable versions subtree. Valid Unicode and non-device names are generated from the declaration; no fallback getter is introduced.

Only the actual generator ran through a closed in-memory filesystem for source generation. No test, driver, native directory operation, parser or GUI was executed. All macOS/Linux outputs were checked byte-exact. Native acquisition/provenance, real directory creation and canonical caller/listener work remain pending. Root must run registered controls and native receiving before adoption.
