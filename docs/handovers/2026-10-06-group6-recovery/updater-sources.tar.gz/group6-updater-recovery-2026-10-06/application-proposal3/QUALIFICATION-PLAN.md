<!-- group6-linux-native-updater-application-proposal3/QUALIFICATION-PLAN.md -->

# Bounded source qualification plan

This proposal is source only. No parser, module import, test, native operation,
generator, Git operation or CI run was executed while preparing it. A later
exclusive slot from the root owner is required. Source hashes are in
`APPLICATION-SOURCE-ONLY.json`; independently reviewed production and installer
bindings are in `group6-owned-install-source-review-revision5/REVIEW.json`.

1. Copy the current root Linux/shared source into an immutable, private
   qualification layout, preserving real source-relative paths and known test
   prerequisites. Record every input hash before overlaying the exact candidate
   files. Do not borrow the historical qualified native core: its output-hop and
   prepared-header composition still needs its own reviewed final pins.
2. In fresh processes, run the fixed candidate arrays sequentially: production
   manager18, actual archive transfer4, known pre-reader installer refusal8,
   unchanged shared async15, local install budget10, update caller4, genuine
   controlled Versions handshake8. Keep every exception and per-array floor.
   Stop on an unexpected candidate failure; distinguish harness debt from a
   receiving-boundary regression without claiming either from an absent API.
3. Replay the same new controls against the exact immutable reviewed
   predecessors. Preserve actual causal failures separately from old producers
   that lack the newly introduced contract. Original manager8 and installer
   synchronous34 cases remain required; no assertion, label or oracle changes.
4. After registry source review, execute its original23 and install-admission6
   arrays against the composed root491/private-registry/qualified08f69 source.
   These controlled native ports are not C, pipe or installer qualification.
   Existing standalone FD125 and actual12 controls remain mandatory and intact.
5. Register every qualified array through the normal Linux framework using the
   nine proposed modules and additive checked manifest rows. Verify actual
   discovery and exactly96 cases; do not reset statistics or treat an
   unregistered file as evidence.
6. Run a distinct genuine native composite: installed ABI/clock admission,
   checksum GET, streaming archive with a nonempty intermediate redirect body,
   per-URL system route, strong preceding curl/read/write settlement, same-FD
   digest and publication, all three private tar modes and namespace disposal.
   Include cancellation, expired original phase budget, late writer failure,
   source withdrawal, no-replace collision and rollback. Use the existing
   subreaper guardian and capture each exact producer identity before action.
   No logical cancellation, loop inactivity or displayed path stands for a
   physical ACK. Kernel5.15/6.8 and installed-package coverage remain separate.
7. Root owns build-helper activation in source/package pipelines and mandatory
   native CI. Generated `.so` files come from the canonical C/header helper,
   never hand-edited artifacts or copied qualification binaries. Root also owns
   canonical shared defaults, test catalogue and the selected `verify-change`
   gates, sequential JS/native execution and affected sibling drivers.

The known-refusal installer path returns an authentic cleanup operation only
because the fixed producer observed refusal before its first reader. Unknown
constructor exceptions or nil returns retain debt. The original accepted native
Versions transaction continues after later pause or page retirement; stale
presentation callbacks and successor-script restarts remain refused. A failed
synchronous channel choice never commits automatically after delayed cleanup;
another explicit choice is required after the exact ACK.

Original local filesystem commands remain synchronous. The new install budget
checks admission and checkpoints; it does not establish a physical timeout for
every shell command. No completed TODO, pipeline success, installed capability,
Windows runtime validation or native device qualification is claimed here.
