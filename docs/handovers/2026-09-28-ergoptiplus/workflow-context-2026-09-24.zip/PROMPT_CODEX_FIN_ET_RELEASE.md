# Mission : terminer la refonte ErgoptiPlus, l'intégrer à `dev`, pousser et boucler jusqu'à la release

Tu travailles dans le dépôt `D:/Documents/GitHub/ergopti` (machine Windows 11 ; Git Bash et
PowerShell disponibles ; `gh` authentifié sur `adrienm7/ergopti`). Tu reprends un chantier
commencé par des agents Claude dont le quota est épuisé. Ce fichier est autonome : il remplace
`PROMPT_REPRISE_1_RELEASE.md` et `PROMPT_REPRISE_2_SUITE.md`, qui restent seulement comme
historique.

Le but final :
1. terminer toutes les tâches de la refonte ;
2. intégrer le tout par-dessus le `dev` à jour, avec mes derniers commits amont ;
3. pousser `dev` ;
4. suivre la CI jusqu'à ce qu'elle soit verte ET que la release soit créée. Si c'est KO, tu
   corriges, tu pousses et tu recommences.

## 0. Autorisations et règles impératives

- **Autorisation explicite de pousser `dev`.** Je t'autorise à pousser `dev`, et seulement
  `dev`, à l'étape 7, puis à y pousser les correctifs nécessaires tant que la CI n'est pas
  verte et que la release n'existe pas. Cette autorisation remplace, pour cette mission, la
  règle « ne jamais pousser `dev` sans accord » d'`AGENTS.md`. Elle ne couvre JAMAIS `main`.
- **Pas de réécriture de `dev`.** Pas de `--force`, pas de `--force-with-lease`, pas de
  réécriture de `origin/dev`. `dev` avance uniquement en fast-forward (`git merge --ff-only`).
- **Historique linéaire.** Pas de commit de merge, pas de squash, pas de trailer
  `Co-Authored-By`, ni aucun crédit d'outil.
- **Commits.** Commits atomiques, au format Conventional Commits en anglais : sujet de 72
  caractères au plus, corps qui explique le pourquoi.
- **Staging.** Ajoute les chemins un par un : jamais `git add -A`, `git add .`, `git add -u`,
  `stash`, `reset --hard` ni `clean` sur un worktree actif.
- **Contrat du dépôt.** Lis `AGENTS.md`, puis `docs/memory/README.md` et les sujets qu'il
  désigne. Les procédures sont dans `.agents/skills/<nom>/SKILL.md` : lis ces fichiers
  directement. Au minimum : `commit-and-push`, `verify-change`, `ship-fix`,
  `cross-driver-parity`, `i18n`, `logger`, `ahk-driver`, `hammerspoon-driver`,
  `linux-driver`, `meta-test`, `false-green-tests`, `windows-toolchain`, `bulk-edit`,
  `workflow-change-control`.
- **Qualité.**
  - TDD : écris le test, vois-le échouer, puis implémente.
  - Parité complète entre macOS (Hammerspoon), Windows (AutoHotkey v2) et Linux (LuaJIT).
  - Chaque texte visible par l'utilisateur existe dans les 21 locales, avec de vraies
    traductions (`en.json` fait référence ; voir le skill `i18n`).
  - Les fichiers générés passent toujours par leur générateur.
  - AutoHotkey : UTF-8 avec BOM et LF. Tout le reste : LF.
  - Fail fast, pas de fallback silencieux.
- **Écriture des fichiers.** Les heredocs de Git Bash abîment les antislashs, et Python en mode
  texte force le CRLF. Écris les fichiers avec ton outil d'édition, ou en binaire.
- **Disque.** D: est presque plein (quelques Go libres). Crée tout nouveau worktree sous
  `C:/ewtb/`.
- **Jonctions.** Chaque worktree a des jonctions `node_modules` et `.venv` vers le checkout
  principal. Avant de supprimer un worktree, retire-les avec `cmd /c rmdir <chemin>`, sinon le
  contenu partagé est effacé.
- **Tests.** Ne jamais affaiblir, sauter ni supprimer un test pour faire passer la CI.

## 1. Où tout se trouve

Dossier de contexte : `D:/ewt/_context/`.

- **À faire d'abord :** `node D:/ewt/_context/tools/build_context.cjs`. Cela régénère :
  - `TASK_STATUS.md` : état de chaque tâche (implémentation, relecture), avec ses commits,
    `not_done`, risques et questions ;
  - `TASK_SPECS.md` : mes décisions produit validées (DECISIONS, puis EXTRA_COMMON qui
    l'emporte) et la spec complète de chacune des 35 tâches, par lane.

  Ces deux fichiers sont ta source de vérité fonctionnelle. Le script relit le journal du
  workflow Claude, ou sa copie `journal.jsonl` si l'original a disparu.
- **Mes demandes d'origine, R1 à R35 :** `feature_map_script_with_R1-R35.js`. R36 (les 3
  touches personnalisables) correspond à la tâche D6.
- **Rapports d'analyse initiaux :** `map/*.txt` et `map/critique.md`. Leurs numéros de ligne
  datent de la base : ce sont des hypothèses, revérifie-les.
- **Worktrees de travail :** `D:/ewt/<lane>` sur les branches `feat/ovh-<lane>`, pour les
  lanes state, menu, logging, updater, actions, diag, navlayer et layouts. Toutes partent de la
  base `f4d0bfd633ab7af50044199917e1e3db4241d8be`. Il y a environ 200 commits au total.
- **Branche d'intégration :** `feat/overhaul`, encore au commit de base.
- **`dev` local :** `origin/dev` plus mon commit non poussé `f5eabcfe6` (skill
  `workflow-change-control`, règle dans `AGENTS.md`, mémoire). Il doit partir avec la release.
  Vérifie avec `git log origin/dev..dev`.
- **Amont :** j'ai poussé beaucoup de correctifs Linux sur `dev` (dernière release
  `v0.0.0-dev.135` au moment de l'écriture). **Kanata est RETIRÉ sous Linux.** Le démon exécute
  lui-même les tap-holds et la couche de navigation :
  - `static/ergopti_plus/linux/platform/remap/tap_hold_engine.lua`, `tap_hold_loader.lua`,
    `tap_hold_manager.lua` ;
  - commits `a5616e7fa`, `6eec7b633`, `339f7c65c`, et `2b7b9269f` pour le menu Tap-Holds du
    tray Linux.

  La décision « Tap-Holds (Linux : son sous-menu kanata) » de DECISIONS est donc périmée : sous
  Linux, pars du menu tray et du moteur du démon amont.

## 2. Nettoyage de départ

1. **Vérifie que plus aucun agent Claude n'écrit dans `D:/ewt/*`.** `git status` doit rester
   stable sur une minute. Sinon, arrête-toi et demande-moi.
2. **Supprime les notes non suivies.** Il s'agit des fichiers `_PAUSED_READ_FIRST.txt` et
   `_UPSTREAM_NOTE.txt` à la racine des worktrees.
3. **Si `D:/ewt/integ` existe**, c'est un début d'intégration sur l'ancienne base, à ignorer.
   Retire ses jonctions, puis `git worktree remove --force D:/ewt/integ` et
   `git worktree prune`.
4. **Trie le travail non commité de chaque worktree** (`git -C D:/ewt/<lane> status`). Des
   agents ont pu être interrompus en cours de tâche, notamment D4, E3, N3 et la relecture
   de L3.
   - Ce qui est complet, cohérent et vert : commite-le atomiquement dans sa lane.
   - Le reste : restaure ces fichiers exacts et note-les comme non faits.

## 3. Intégrer l'existant sur le `dev` à jour

1. `git -C D:/Documents/GitHub/ergopti fetch origin`.
2. Vérifie que `feat/overhaul` ne contient rien au-delà de la base. Ensuite :
   `git branch -f feat/overhaul dev`, où `dev` = `origin/dev` + `f5eabcfe6`. Si `dev` local
   est en retard sur `origin/dev`, rebase d'abord `f5eabcfe6` dessus.
3. Crée un worktree `C:/ewtb/integ` sur `feat/overhaul`, avec ses jonctions
   (`cmd /c mklink /J`).
4. **Cherry-picke chaque lane dans cet ordre :** state, logging, menu, actions, updater, diag,
   navlayer, layouts. Utilise `git cherry-pick f4d0bfd633ab..feat/ovh-<lane>` pour garder les
   commits atomiques. Environ 60 fichiers se recouvrent entre lanes et avec l'amont. Règles de
   résolution :
   - **Locales JSON et `manifest.toml` :** union des clés et des lignes, chacune à sa
     position.
   - **Fichiers générés** (`menu_manifest.json`, manifests de features, `_generated/*`,
     templates de config, `docs/architecture.md`) : régénère-les avec leurs générateurs,
     jamais à la main.
   - **Code Linux : l'amont fait foi.** Retire tout ce que les lanes ont ajouté pour kanata.
     La couche de nav générée pour Linux (N2) doit alimenter le moteur du démon ; sinon,
     retire proprement la partie Linux de N2 et note-le.
   - **Menus Linux :** pars du menu tray amont. Les lignes Restaurer et Tout effacer utilisent
     `common.restore_recommended` et `common.clear_to_system`.
   - **Compteurs de ratchets** (par exemple le total de `tools/test/test-linux-feature-parity.cjs`) :
     recalcule-les, ne prends la valeur d'aucun des deux côtés.
   - **Le commit `64c6f319d` de layouts** casse seul le ratchet driver-tree-parity, que le
     commit suivant répare. Laisse-le ainsi, ou réordonne si c'est trivial.
5. **Après chaque lane :** régénère, puis `node tools/test/verify-change.cjs`. Corrige la
   casse entre lanes par des commits `fix(...)` dédiés, avec un test de régression.

## 4. Relire ce qui n'a jamais été relu

**Tâches concernées.** Dans `TASK_STATUS.md`, prends toutes les tâches dont l'implémentation
est `done` ou `partial` mais dont la relecture est absente, `blocked` ou `interrupted`. Au
moment de l'écriture : A3, C3, D6, E3, L3, et N3 / D4 si elles ont produit des commits.
Prends aussi les restes des relectures `partial` (A1, C2, D2).

**Méthode.** Pour chacune, fais une relecture adversariale contre sa spec dans
`TASK_SPECS.md` : parité sur les 3 OS, 21 locales, tests capables d'échouer, fail fast.
Corrige chaque défaut avec un test qui échoue avant le correctif.

## 5. Implémenter ce qui reste

Tu travailles par-dessus `feat/overhaul`, qui contient déjà l'amont. Ne construis jamais de
nouveau travail sur l'ancienne base.

**Parallélisme.** Si tu peux lancer plusieurs sessions ou sous-agents, par exemple un
`codex exec` par worktree, fais tourner au plus 3 tâches indépendantes en parallèle :
- chacune dans son worktree `C:/ewtb/<tâche>`, sur une branche `feat/ovh2-<tâche>` créée
  depuis `feat/overhaul` ;
- chaque session commence par `git log` et `git status` et reprend l'existant ;
- n'arrête jamais une session en cours pour lui ajouter une exigence : fais une tâche de
  suivi.

Sinon, enchaîne les tâches une par une directement dans `C:/ewtb/integ`.

Chaque tâche est suivie d'une auto-relecture adversariale, puis rapatriée sur `feat/overhaul`
par cherry-pick. La spec complète de chaque tâche est dans `TASK_SPECS.md`.

**Ordre conseillé :**

1. **W1 : défauts neutres.**
   - Une config vide donne le comportement de l'OS.
   - Toute fonctionnalité qui modifie la saisie est désactivée par défaut.
   - Les valeurs « conseillées » sont séparées dans le manifest.
   - La persistance est clairsemée.
   - « Restaurer les valeurs conseillées » et « Tout effacer (comportement du système) »
     existent par périmètre.
   - Aucune migration : il n'y a pas encore d'utilisateurs.
2. **W2 : assistant de premier lancement.**
   - Une page par sous-menu, avec « Activer » à Non par défaut et une liste dépliable des
     réglages conseillés à importer.
   - Il se lance automatiquement sur les 3 OS quand `config.toml` est absent, et reste
     relançable depuis Configuration.
   - Il dépend de W1.
3. **Trou A1.**
   - Les lignes sous une catégorie désactivée doivent rester actives et modifiables.
   - Sous Windows, change d'abord le modèle d'état (`ApplyMasterGatesToFeatures`).
4. **A4 : sous-menus Tap-Hold et Combinaisons de touches.**
   - Sous-menu Tap-Hold avec « Main gauche — Tap / Hold » et « Main droite — Tap / Hold ».
   - Sous-menu « Combinaisons de touches » sous Raccourcis, avec sa propre case à cocher.
   - Catalogue de touches partagé.
   - Sous Linux, pars du menu Tap-Holds amont et du moteur du démon.
5. **A5 : conflits avec les gestes système.** Avertissements, ligne de statut ✓/⚠ et
   « Réglages des gestes du système… ».
6. **B4 :** la console de débogage s'ouvre grande et centrée.
7. **C4 : fenêtre de résultat du contrôle de mise à jour manuel.**
   - Fenêtre centrée, sur 2 lignes, avec Fermer / Mettre à jour.
   - Elle indique le canal vérifié et ajoute une ligne par autre canal plus récent.
   - Sparkle est localisé.
   - Aujourd'hui, Windows installe directement et Linux ne fait que logguer : c'est à
     remplacer par cette fenêtre.
8. **D3 : Spaces / bureaux.** 4 actions (précédent / suivant, normal et circulaire) ; retrait
   de `space_wrap` et du réglage « Navigation circulaire ».
9. **D4 : prédiction IA** (reprends le travail existant de la lane actions s'il a été
   commité).
   - Action « générer une prédiction IA » sur les 3 OS, avec un retour visible à chaque
     refus.
   - Raccourcis conseillés Ctrl+Espace (macOS), Win+Espace (Windows) et Super+Espace (Linux),
     touches avalées.
   - Retrait des anciens réglages de raccourci déclencheur.
   - Libellé « Modèle sélectionné » et pluriel corrigé.
   - « Nombre de suggestions » déplacé dans les paramètres de génération.
10. **D5 : actions inspirées de Shortcutie.**
    - SANS « fermer toutes les apps ».
    - La suppression de la quarantaine et le vidage de la corbeille demandent confirmation.
11. **Trou D2 :** `copy_selected_path` sous Linux.
12. **F2 :**
    - interrupteur Karabiner respecté ;
    - « Retirer Ergopti de Karabiner » ;
    - sauvegarde et restauration du registre du pavé tactile Windows ;
    - état du guardian de remap dans le diagnostic.

    F1 est abandonnée, car kanata est retiré.
13. **N3 : éditeur web de la couche de navigation** (reprends le travail existant de la lane
    navlayer s'il a été commité).
    - Clavier visuel, pavé numérique, clics et molette.
    - Il écrit `layers.toml` et alimente le moteur de chaque driver. Sous Linux, c'est le
      moteur du démon.
    - Entrée de menu « Éditer la couche de navigation… ».
    - Implémentée dans la lane navlayer (5 commits, `48239f347` à `547e56e14`) mais jamais
      relue : relis-la à l'étape 4.
    - Sous Linux, `linux/ui/layer_editor/bridge.lua` applique encore la couche via
      `platform/remap/manager.restart()`, le chemin kanata. À l'intégration, fais pointer cet
      `apply()` sur le moteur de tap-holds du démon.
    - Restes connus :
      - pas de capture d'un raccourci en l'appuyant ;
      - pas de construction de séquences multi-accords ;
      - seule la couche `nav` est éditable.
14. **Trou L3, décision du mainteneur (2026-09-26).** AUCUNE coupure automatique des
    hotstrings propres à Ergopti (`sfbs_reduction`, `rolls`) selon la disposition détectée,
    sur aucun OS. Ces groupes sont désactivés par défaut, et l'utilisateur choisit de les
    activer ou non, quelle que soit sa disposition (par exemple un fork d'Ergopti).
    - Retire la coupure automatique Windows (`ff00d5139`) et ne l'ajoute pas sous macOS ni
      Linux.
    - Vérifie que les deux groupes sont bien désactivés dans les valeurs par défaut
      partagées, et que le menu laisse les activer sous n'importe quelle disposition.
16. **Nouvelle tâche L4 (demande du mainteneur, 2026-09-26) : chaque disposition est une
    extension.** On sait déjà émuler ou installer les dispositions du registre (Ergo-L…) et
    ajouter des extensions de hotstrings et de raccourcis. Chaque `.keylayout` du registre
    devient une extension qui peut embarquer ses propres hotstrings et raccourcis.
    - Une entrée du registre = le `.keylayout` + des hotstrings et des raccourcis
      optionnels, au même format que les extensions existantes (réutilise leur format, leur
      chargement et leur menu, ne crée pas un second système).
    - Les groupes propres à Ergopti (`sfbs_reduction`, `rolls` et tout autre groupe qui
      n'a de sens que sur Ergopti) deviennent le contenu de l'extension Ergopti.
    - Installer ou activer une disposition rend ses hotstrings et raccourcis disponibles,
      sans les activer : ils restent désactivés par défaut et l'utilisateur les active,
      quelle que soit la disposition active (point 14).
    - Le gestionnaire de dispositions (L3) montre ce que chaque disposition embarque.
    - **Touche magique ★ (conseil retenu, sauf contre-ordre du mainteneur) :** elle reste
      une fonction générale, pas une partie de l'extension Ergopti.
      - Restent généraux : le déclencheur ★, la répétition de la lettre précédente, les
        abréviations par langue (`c★` = c'est, emojis, symboles, Typst). Ils ne dépendent
        que d'avoir une touche qui produit ★.
      - Chaque extension de disposition déclare quelle touche physique est sa touche ★
        (Ergopti déclare la sienne). Sans déclaration, l'utilisateur choisit la touche,
        comme aujourd'hui avec « Transformer une touche en touche ★ ».
      - Passent dans l'extension de la disposition : les règles qui dépendent de la
        géométrie d'Ergopti, comme les corrections de faux positifs de la répétition
        (`repeat_corrections`, ê→u).
      - Les valeurs par défaut actuelles de la partie générale ne changent pas.
      - Le mainteneur a validé ce découpage le 2026-09-26.
    - **Touche ★ configurable (demande du mainteneur, 2026-09-26), sur les 3 OS :**
      - Choisir l'emplacement physique qui produit la touche magique : n'importe quelle
        touche ou position du clavier, en l'appuyant ou dans une liste. Pars des champs
        existants `magic_key_source_scan` et `magic_key_source_char` et de la section
        « Transformer une touche en touche ★ » ; complète ce qui manque sur chaque driver.
      - Choisir le caractère déclencheur : ★ par défaut, ou `;` ou tout autre symbole.
        Les hotstrings écrits avec ★ dans les TOML se déclenchent alors avec ce caractère,
        et tous les libellés de l'interface affichent le caractère choisi.
      - La disposition active peut proposer sa touche ★ par défaut ; le choix de
        l'utilisateur l'emporte toujours.
      - Corrige au passage le bug connu de Linux, où la touche magique vaut `\` au lieu
        de ★ et où les libellés affichent un antislash (`docs/ERGOPTI_PLUS.md` §6.2).
      - Tests par driver (déclenchement avec un autre caractère, changement d'emplacement,
        libellés), 21 locales, et une valeur invalide refusée avec un message clair.
    - Sur les 3 OS, avec les tests par driver et les 21 locales. Si un autre choix de
      conception reste ambigu, pose la question au mainteneur.
15. **Autres restes des `not_done`** dans `TASK_STATUS.md`. Par exemple : le libellé de la
    ligne de l'éditeur de chemins, les titres des fenêtres GTK Linux en anglais en dur, et
    R17 sous Linux (`menu.updates.open_releases`, que l'updater retire).

**Questions produit : réponses par défaut, à appliquer sauf si je t'ai dit autre chose.**
- **A3, gestes conseillés macOS (décision du mainteneur, 2026-09-26) :** garde les valeurs
  par défaut qu'il a choisies dans le manifest pour le glissement à 2 doigts vers la gauche
  et les glissements horizontaux à 3, 4 et 5 doigts (flèche haut, mots, Spaces, fenêtres) :
  elles sont mûrement réfléchies. N'aligne pas le manifest sur le runtime ; c'est le runtime
  qui doit appliquer ces valeurs. Les gestes sont désactivés par défaut.
- **L3 :** pas de coupure automatique selon la disposition, voir le point 14.
- Pour toute autre question produit ouverte, choisis l'option la plus conservatrice et
  cohérente avec DECISIONS, puis liste-la dans le rapport final.

Optimot n'est PAS à faire : j'attends l'accord de son auteur.

## 6. Vérifications avant le push

1. `git fetch origin`. Si `origin/dev` a bougé, rebase `feat/overhaul` dessus. Vérifie ensuite
   que `git merge-base --is-ancestor origin/dev feat/overhaul` réussit.
2. Dans `C:/ewtb/integ` :
   - `node tools/test/verify-change.cjs --range=origin/dev..HEAD` ;
   - puis `node tools/test/verify-change.cjs --all --diagnose`.

   Corrige toute régression candidate. Rouges connus, propres à cette machine, à classer
   avec preuve en les reproduisant sur `origin/dev` :
   - Node local 22.16 alors que le dépôt épingle 22.22.2 ;
   - le générateur `codegen-unicode-case-linux.cjs` exige Unicode 17 ;
   - le test RTK ne trouve pas `dirname` ;
   - l'étape `build:linux` dépasse 60 s sous Windows : vérifie-la avec
     `npm run build:linux` lancé directement ;
   - 7 tests Linux de `test_file_watchers.lua` échouent sous Windows.

   La suite AHK tourne ici : lis le plus récent `%TEMP%/ergopti_test_results_*.txt`. Le Swift
   du launcher macOS ne compile pas ici, seule la CI macOS le valide.
3. **CI sur la branche avant `dev`.** La CI ne se déclenche pas sur un simple push de branche
   de fonctionnalité. Pousse `feat/overhaul` (autorisé), puis
   `gh workflow run ci.yml --ref feat/overhaul`. Suis ce run comme à l'étape 8 et corrige
   jusqu'au vert, jobs macOS, Windows et Linux compris. Les jobs de release ne tournent que
   sur `dev` et `main`.

## 7. Pousser `dev`

1. `git fetch origin`, puis refais la vérification d'ancêtre de l'étape 6.
2. Dans le checkout principal `D:/Documents/GitHub/ergopti`, qui est sur `dev` et doit être
   propre (sinon arrête-toi et demande-moi) : `git merge --ff-only feat/overhaul`.
3. `git push origin dev`, sans aucune option de force. Si le push est refusé parce que `dev`
   a bougé : fetch, rebase `feat/overhaul` sur `origin/dev`, relance l'étape 6.2, puis
   réessaie.

## 8. Boucle CI → release

Le workflow `.github/workflows/ci.yml` tourne à chaque push sur `dev`. La release est créée
ainsi :
- `resolve-release-meta` calcule le tag suivant `v0.0.0-dev.<N>`. Ce job exige que
  `macos-ok`, `windows-ok` et `linux-ok` aient réussi.
- `build-macos`, `build-windows`, `build-linux` et `release-gate-macos` s'exécutent ensuite.
- `finalize-release` fait le `gh release create`, en prerelease, avec comme cible le SHA
  poussé.

Pour chaque SHA poussé :

```bash
SHA=$(git -C D:/Documents/GitHub/ergopti rev-parse origin/dev)
gh run list --workflow ci.yml --branch dev --commit "$SHA" --json databaseId,status,conclusion
gh run watch <id> --exit-status > C:/ewtb/ci-<id>.log 2>&1   # jamais dans un pipe tail/head
gh run view <id> --json conclusion,jobs --jq '.conclusion, (.jobs[] | select(.conclusion!="success" and .conclusion!="skipped") | .name + " " + .conclusion)'
gh release list --limit 5 --json tagName,isPrerelease,createdAt
gh api repos/adrienm7/ergopti/releases/tags/<tag> --jq .target_commitish   # doit valoir $SHA
```

**Condition de fin :** le run du SHA est en `success` ET une release `v0.0.0-dev.<N>` existe,
dont la cible est ce SHA et qui porte ses assets.

**Si la CI est KO :**
1. `gh run view <id> --log-failed > C:/ewtb/ci-<id>-failed.log`.
2. Trouve la cause racine et reproduis-la localement quand c'est possible.
3. Corrige avec un test de régression, dans un commit atomique.
4. Lance `verify-change`, puis pousse sur `dev` (autorisé).
5. Recommence la boucle.

**Cas particuliers :**
- **Échec d'infrastructure** (runner, réseau, timeout de téléchargement) : relance une fois
  avec `gh run rerun <id> --failed`.
- **Blocage extérieur au dépôt** (panne GitHub, secret manquant, quota de minutes) : arrête et
  explique.
- **Pas de progrès :** si le même job échoue trois fois de suite pour la même cause malgré
  tes correctifs, arrête et écris le rapport au lieu de boucler.
- **`skip=true`** (le tag existe déjà) : pousse un commit utile de plus ou demande-moi, ne
  touche jamais aux tags à la main.

## 9. Rapport final

Écris `D:/ewt/_context/RAPPORT_FINAL.md` avec :
- les tâches livrées et leurs commits ;
- ce qui a été exclu ou reste à faire, et pourquoi ;
- les réponses par défaut appliquées aux questions produit ;
- les résultats des vérifications locales ;
- l'URL du run CI vert et le tag de la release.

Ajoute une **liste précise de tests manuels** par OS :
- **Windows :** émulation Ergopti lue depuis le `.keylayout`, couche de nav générée, les 3
  touches personnalisables et leurs libellés, fenêtre d'erreur, logs dans
  `%LOCALAPPDATA%\ergopti_plus\logs`, mises à jour.
- **macOS :** tous les menus cliquables (c'était le bug bloquant), cases à cocher en premier
  item des sous-menus, gestes, logs dans `~/Library/Logs/ergopti_plus`, cadence de mise à
  jour, assistant de premier lancement.
- **Linux :** tap-holds du démon, menus du tray, gestionnaire de dispositions, prédiction IA.

Ne supprime pas les worktrees `D:/ewt/*` : liste-les dans le rapport.
