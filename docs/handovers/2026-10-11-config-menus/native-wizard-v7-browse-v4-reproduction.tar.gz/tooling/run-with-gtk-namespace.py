#!/usr/bin/env python3
"""Select the actual generated GTK overlay launcher from its stable manifest."""
import json
import os
from pathlib import Path
import sys

if len(sys.argv) < 2:
    raise SystemExit('usage: run-with-gtk-namespace.py executable [arguments...]')
selection = json.loads(Path('/workspace/tooling/gtk-overlay-current.json').read_text())
launcher = Path(selection['launcher'])
manifest = Path(selection['manifest'])
if launcher.name != 'launch.sh' or launcher.parent.parent != Path('/workspace/tooling') \
        or not launcher.parent.name.startswith('gtk-overlay-'):
    raise SystemExit('The GTK launcher does not belong to the prepared workspace view.')
record = json.loads(manifest.read_text())
if manifest.parent != launcher.parent or record['views'] != str(launcher.parent) \
        or record['prefix'] != '/workspace/tooling/gtk' \
        or record['host_mutations'] is not False \
        or record['browser_sandbox_disabled'] is not False:
    raise SystemExit('The GTK view manifest does not acknowledge its prepared ownership.')
os.execv(str(launcher), [str(launcher), *sys.argv[1:]])
