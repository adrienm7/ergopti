#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ergopti-windows-r6-lifecycle
python3 - <<'CHECK'
from pathlib import Path
import json,re,subprocess,hashlib
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle');w=out.parent/'verification-worker'
r=json.loads((w/'receipts/463-lifecycle-menu-population-admission-commit-exit.json').read_text());assert r['exit_code']==0,r
assert not subprocess.check_output(['git','status','--porcelain'])
text=(w/'458-lifecycle-request-key-domain-green153.tap').read_text(encoding='utf-8-sig');assert '# 153 passed, 0 failed.' in text
pairs=re.findall(r'^ok (\d+) - (.+)$',text,re.M);assert len(pairs)==153 and {int(x[0]) for x in pairs}==set(range(1,154))
actual=[x[1].rstrip('\r') for x in pairs]
read=lambda p:[s for s in p.read_text().splitlines() if s.strip() and not s.startswith('#')]
base=read(out/'native-controls-all.txt');warm=read(out/'warmup-close-all.txt');assert len(base)==46 and len(warm)==15
assert len(set(base)&set(actual))==19 and not set(warm)&set(actual)
menu_text=(w/'462-lifecycle-menu-population-green-all.tap').read_text(encoding='utf-8-sig');assert '# 18 passed, 0 failed.' in menu_text
menu_pairs=re.findall(r'^ok (\d+) - (.+)$',menu_text,re.M);assert len(menu_pairs)==18 and {int(x[0]) for x in menu_pairs}==set(range(1,19))
menu_names=[x[1].rstrip('\r') for x in menu_pairs];assert not set(menu_names)&set([*base,*warm,*actual])
names=list(dict.fromkeys([*base,*warm,*actual,*menu_names]));assert len(names)==213
(out/'final-native213-list.txt').write_text('\n'.join(names)+'\n')
paths=['static/ergopti_plus/windows/infra/driver_control.ahk','static/ergopti_plus/windows/infra/webview_browser_warmup.ahk','static/ergopti_plus/windows/ui/healthcheck/core.ahk','static/ergopti_plus/windows/infra/json.ahk','static/ergopti_plus/windows/tests/unit/infra/control/test_driver_control.ahk','static/ergopti_plus/windows/tests/meta/ui/webview/test_webview_shared_env_reentrancy_guard.ahk','static/ergopti_plus/windows/tests/unit/ui/healthcheck/test_diagnostics_window_control.ahk','static/ergopti_plus/windows/infra/menu_population.ahk','static/ergopti_plus/windows/tests/unit/ui/menu/test_menu_population.ahk']
(out/'final-native213-source-hashes.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'expected_names':names},indent=2)+'\n')
print('FINAL_NATIVE_COHORT_EXPECTED213')
CHECK
status=0
env WINEPREFIX=/workspace/toolchain/wine-r3-metrics-owned WINEPATH='Z:\workspace\toolchain\node-v22.22.2-win-x64' timeout --kill-after=5s 300s xvfb-run -a bash tools/test/run-ahk-under-wine.sh --ahk /workspace/toolchain/ahk/AutoHotkey64.exe --runner run_all.ahk --results /workspace/scratch/windows-audit-round6/verification-worker/464-lifecycle-final-native213.tap -- '--list=Z:\workspace\scratch\windows-audit-round6\lifecycle\final-native213-list.txt' || status=$?
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=Path('/workspace/scratch/windows-audit-round6/lifecycle')
p=json.loads((out/'final-native213-source-hashes.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==p['commit']
assert not subprocess.check_output(['git','status','--porcelain'])
for name,digest in p['sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('FINAL_NATIVE_SOURCES_UNCHANGED')
CHECK
exit "$status"
