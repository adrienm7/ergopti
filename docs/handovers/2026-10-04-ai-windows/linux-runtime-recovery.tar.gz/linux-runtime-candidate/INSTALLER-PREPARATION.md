<!-- linux-runtime-candidate/INSTALLER-PREPARATION.md -->

# User-local archive installer preparation

The user selected installation without administrator privileges. These two files
are outside the checkout and unregistered. Focused scratch qualification passed;
see `INSTALLER-QUALIFICATION.md` for the exact sources, counts and failures.
They do not complete TODO48. The tiny fixture reuses the scratch subreaper after
adding an optional `hasattr(failure, "add_note")` guard for Python3.10; its actual
timeout/failed-leader teardown regressions were rerun successfully.

`modules/llm/ollama_install_files.lua` owns only native file receipts. It creates
private sibling staging, reserves an exact archive inode, requires pinned size
and the complete GNU NUL-delimited SHA receipt, admits the verified runtime tree,
and observes an exact inode/device transfer after no-clobber publication. A
successful `mv -n` that skipped a raced foreign target is refused. Cancellation
after an actual transfer retains the verified installation. Cleanup never follows
symlinks and refuses replaced captured staging identities. The caller must first
settle every external native operation.

`modules/llm/ollama_archive_installer.lua` coordinates these file receipts with
injected process and existing owned HTTP ports. It reserves before calling the
injected authorizer, requires explicit binary-download consent and current source,
preflights the required GNU/zstd semantics, and waits for physical settlement
before advancing each step or removing files. Signal acceptance is never a
settlement receipt. Unknown dispatch acquisition or malformed operation ports
retain explicit cleanup debt; they cannot silently release a successor. A result
callback is suppressed after source invalidation/cancellation, while exact
settlement listeners remain available to the enable actor.

No process state machine is imported by this preparation. Group3's unpublished
`_shared/lua/native_worker_owner.lua` is the intended policy owner. Its eventual
adapter must supply:

- `start(program, argv, { owner, authorized, timeout_ms, max_output_bytes }, done)`;
- retained `started`, `cancel`, `is_settled`, `on_settled` receipts;
- exact actual exit, descendant group absence and every allocated close ACK;
- `{ ok, exit_code, stdout }` after successful helper retirement;
- source checks before dispatch/output/completion, with immediate cancellation
  suppression and independent settlement delivery.

This port is an explicit candidate contract, not evidence that the announced
Group3 API already implements it. A thin Linux native adapter should map the
common policy's published API; do not add a duplicate process state machine.

## Current container prerequisites

Read-only binary and help receipts found `/usr/bin/zstd` and `unzstd` 1.5.7,
GNU `sha256sum` and `mv` (coreutils9.7), GNU `tar`1.35, `curl` and `uname`.
Help includes SHA `--zero`, tar `--zstd`, `--no-same-owner` and
`--no-same-permissions`, and mv `--no-clobber`/`--no-target-directory`.
No setup package installation is needed for these tools in this container.
The production transaction checks these prerequisites through owned foreground
operations and refuses unavailable semantics. It never runs sudo or an official
system-wide install shell script. Driver package prerequisite changes must be
coordinated with their owner; none are proposed or applied here.

## Still required before adoption

- Read-only independent review of the native file and transaction sources.
- Resolver/canonical path ownership must reject symlinked existing ancestors;
  the file candidate currently checks the final managed parent and bin/lib tree.
- Document the private same-UID ownership boundary honestly. Path-based lstat
  guards reject observed replacements but do not provide fd-relative atomic
  protection against a hostile concurrent process running as the same UID.
- Canonical shared release catalogue ownership, resolver ownership and published
  Group3 process API adaptation.
- Real official verified archive installation and daemon/version/model validation
  after download scope and test timing are coordinated. No archive has been
  downloaded by this preparation.
- Actual model installation, truthful consent/UI integration, daemon ownership,
  final hosted packaging/install and original TODO16/38 requirements.
