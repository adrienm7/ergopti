local packet=assert(arg[1])
local root=packet..'/candidate/static/ergopti_plus'
package.path=root..'/linux/?.lua;'..root..'/linux/?/init.lua;'
 ..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
if arg[3] then
 local directory=arg[3];local searchers=package.searchers or package.loaders
 local prior=searchers[2]
 searchers[2]=function(name)
  local relative=name:gsub('%.','/')..'.lua'
  local file=io.open(directory..'/'..relative,'rb')
  if file then
   local bytes=assert(file:read('*a'));assert(file:close())
   local label='@'..root..'/linux/'..relative
   return assert((loadstring or load)(bytes,label)),label:sub(2)
  end
  return prior(name)
 end
end
require('compat.utf8').install()
local native_loop=require('luv')
if arg[2]=='original-shared-copy' then
 require('test.key_combination_chords_contract').register(require('tests.helpers'))
else require(assert(arg[2])) end
local results=require('tests.helpers').get_results()
assert(require('luv')==native_loop)
print('INDEPENDENT_PUBLIC93 '..results.passed..'/'..results.failed)
os.exit(results.failed>0 and 1 or 0)
