local packet=assert(arg[1])
local root='/workspace/ergopti/static/ergopti_plus'
package.path=packet..'/candidate/static/ergopti_plus/linux/?.lua;'..packet..'/candidate/static/ergopti_plus/linux/?/init.lua;'
 ..packet..'/generator-context/static/ergopti_plus/linux/?.lua;'
 ..root..'/linux/?.lua;'..root..'/linux/?/init.lua;'
 ..packet..'/candidate/static/ergopti_plus/_shared/lua/?.lua;'..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
if arg[3] then package.path=arg[3]..'/?.lua;'..arg[3]..'/?/init.lua;'..package.path end
require('compat.utf8').install()
local native_loop=require('luv')
local paths=require('infra.paths');local shared=paths.shared
paths.shared=function(relative)
 if relative=='modules/menu/menu_manifest.json' then return packet..'/generator-context/static/ergopti_plus/_shared/'..relative end
 return shared(relative)
end
local modules={arg[2] or 'tests.unit.modules.test_key_combinations'}
for _,name in ipairs(modules) do require(name) end
local results=require('tests.helpers').get_results()
assert(require('luv')==native_loop)
print('PUBLIC_JOIN_CONTROLLED '..results.passed..'/'..results.failed)
os.exit(results.failed>0 and 1 or 0)
