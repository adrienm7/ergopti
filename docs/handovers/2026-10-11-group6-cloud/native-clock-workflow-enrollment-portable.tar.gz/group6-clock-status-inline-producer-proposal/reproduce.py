"""Reproduce only finite portable clock guards; never canonical refs or native qualification."""
from pathlib import Path
import argparse,subprocess,tarfile,tempfile,shutil,os
parser=argparse.ArgumentParser();parser.add_argument('--repository',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
base=Path(__file__).resolve().parent;meta=base.parent/'group6-clock-workflow-owning-enrollment-proposal'
args.output.mkdir(parents=True,exist_ok=True);work=Path(tempfile.mkdtemp(prefix='portable-clock-replay-',dir=args.output));root=work/'source';root.mkdir();archive=work/'published4260.tar'
with archive.open('wb') as output:subprocess.run(['git','archive','4260b745ee01b3b733c3c3faa9285d497b0f5a0f'],cwd=args.repository,stdout=output,check=True)
with tarfile.open(archive) as t:
 for member in t.getmembers():
  assert not member.name.startswith('/') and '..' not in Path(member.name).parts
  target=root/member.name
  if member.isdir():target.mkdir(parents=True,exist_ok=True)
  elif member.isfile():target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(member).read());os.chmod(target,member.mode)
  else:raise RuntimeError('Nonregular published source input')
changed=subprocess.check_output(['git','diff','--name-only','8d6e3a1198a16645e41b7d4bf0f56a013be6072a','e91afe50c6b4acc216ccde709434b2df94c7dfc6','--','static/ergopti_plus','tools'],cwd=args.repository).decode().splitlines()
for relative in changed:
 target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(subprocess.check_output(['git','show','e91afe50c6b4acc216ccde709434b2df94c7dfc6:'+relative],cwd=args.repository))
for owner in [meta,base]:
 for source in (owner/'candidate').rglob('*'):
  if source.is_file():target=root/source.relative_to(owner/'candidate');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
(root/'.github/workflows/ci-macos.yml').write_bytes((base/'4260b74-workflow-own.candidate.yml').read_bytes())
for command in [['init','-q'],['config','user.name','Portable clock reproduction'],['config','user.email','portable@example.invalid'],['add','--all'],['commit','-qm','Isolated clock reproduction sources']]:subprocess.run(['git','-c','core.hooksPath=/dev/null',*command],cwd=root,check=True)
private=work/'private-tmp';private.mkdir(mode=0o700);env=os.environ.copy();env.update({'TMPDIR':str(private),'PYTHONDONTWRITEBYTECODE':'1','NODE_PATH':str(args.repository/'node_modules')})
for name in ['test-native-http-clock-evidence.cjs','test-ci-full-default.cjs','test-ci-pipeline-wiring.cjs']:
 with (work/(name+'.stdout')).open('wb') as out,(work/(name+'.stderr')).open('wb') as err:subprocess.run(['node',str(root/'tools/test'/name)],cwd=root,env=env,stdout=out,stderr=err,timeout=240,check=True)
print('Portable-only receiving logs: '+str(work))
