from pathlib import Path
import subprocess,os,json,hashlib,shlex,sys,ctypes,time,signal
from types import SimpleNamespace
from datetime import datetime
from zoneinfo import ZoneInfo
root=Path('/workspace/scratch/oct28-cloner/eacces-replay-r2');root.mkdir(mode=0o700)
old_resources=Path('/workspace/scratch/oct28-cloner/00-base/resources')
new_resources=Path('/workspace/scratch/oct28-cloner/01-second/resources')
old=(old_resources/'clone_app.sh').read_text();source=(new_resources/'clone_app.sh').read_text()
port=Path('/workspace/ergopti-macos-picker-observer/tools/test/lib/app-cloner-native-stat-port.cjs')
if sys.platform=='linux':
 if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'Private subreaper admission failed')
def retire_group(gid):
 deadline=time.monotonic()+5
 while time.monotonic()<deadline:
  if sys.platform=='linux':
   while True:
    try: child,_=os.waitpid(-gid,os.WNOHANG)
    except ChildProcessError:break
    if not child:break
  try:os.killpg(gid,0)
  except ProcessLookupError:return
  time.sleep(.01)
 raise RuntimeError('Owned exact process group remains; retain fixture')
def run_owned(argv,env):
 child=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 try:output,errors=child.communicate(timeout=15)
 except subprocess.TimeoutExpired:
  if child.returncode is None:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
  child.communicate(timeout=5);retire_group(child.pid);raise
 retire_group(child.pid)
 return SimpleNamespace(returncode=child.returncode,stdout=output,stderr=errors)
rows=[]
for version,resources in [('old',old_resources),('new',new_resources)]:
 text=(resources/'clone_app.sh').read_text()
 for mode in ['healthy','failure','foreign','refusal']:
  for shell in ['/usr/bin/zsh','/usr/bin/bash']:
   case=root/(version+'-'+Path(shell).name+'-'+mode);case.mkdir(mode=0o700);home=case/'home';home.mkdir(mode=0o700);binary=case/'bin';binary.mkdir(mode=0o700);diag=case/'owned.log';diag.write_bytes(b'');app=case/'Source.app';(app/'Contents/MacOS').mkdir(parents=True);(app/'Contents/MacOS/Source').write_bytes(b'inert');dest=home/'Applications/Log audit.app';workspace_receipt=case/'workspace-created';tee_receipt=case/'tee-retired'
   subprocess.run(['/workspace/toolchain/node-v22.22.2-linux-x64/bin/node','-e','require(process.argv[1]).createNativeStatResources({resources:process.argv[2],fixtureRoot:process.argv[3],toBashPath:x=>x})',str(port),str(resources),str(case)],check=True,capture_output=True)
   buddy=binary/'PlistBuddy';buddy.write_text('''#!/bin/sh
[ "$#" = 3 ] && [ "$1" = -c ] && [ "$2" = 'Print :CFBundleExecutable' ] && [ "$3" = "$OWNED_SOURCE/Contents/Info.plist" ] || exit 91
case "$MODE" in
foreign) mv "$OWNED_DEST" "$OWNED_DEST.held"; mkdir "$OWNED_DEST"; printf foreign > "$OWNED_DEST/marker" ;;
refusal) chmod 500 "$HOME/Applications" ;;
esac
if [ "$MODE" != healthy ]; then chmod 400 "$OWNED_LOG"; fi
printf '%s\\n' Source
''');buddy.chmod(0o700)
   (binary/'mktemp').write_text('''#!/bin/sh
[ "$#" = 2 ] && [ "$1" = -d ] && [ "$2" = /tmp/appcloner.XXXXXX ] || exit 92
created=$(/usr/bin/mktemp -d "$OWNED_TMP_TEMPLATE") || exit $?
printf '%s\\n' "$created" > "$OWNED_WORKSPACE_RECEIPT" || exit $?
printf '%s\\n' "$created"
''');(binary/'mktemp').chmod(0o700)
   (binary/'tee').write_text('''#!/bin/sh
[ "$#" = 2 ] && [ "$1" = -a ] && [ "$2" = "$OWNED_LOG" ] || exit 93
/usr/bin/tee "$@"
tee_status=$?
printf '%s' "$tee_status" > "$OWNED_TEE_RECEIPT.tmp" || exit 94
/bin/mv -- "$OWNED_TEE_RECEIPT.tmp" "$OWNED_TEE_RECEIPT" || exit 95
exit "$tee_status"
''');(binary/'tee').chmod(0o700)
   actual=text
   if mode=='healthy':
    boundary='log "SRC_EXE=$SRC_EXE"';assert actual.count(boundary)==1;actual=actual[:actual.index(boundary)+len(boundary)]+'\necho healthy-tee-marker\nexit 0\n'
   assert actual.count('/usr/libexec/PlistBuddy')>=1;actual=actual.replace('/usr/libexec/PlistBuddy',shlex.quote(str(buddy)),1);script=case/'native-stat-port-resources/clone_app.sh';script.write_text(actual)
   env=dict(os.environ,PATH=str(binary)+':'+os.environ['PATH'],HOME=str(home),MODE=mode,OWNED_SOURCE=str(app),OWNED_DEST=str(dest),OWNED_LOG=str(diag),OWNED_TEE_RECEIPT=str(tee_receipt),OWNED_WORKSPACE_RECEIPT=str(workspace_receipt),OWNED_TMP_TEMPLATE=str(case/'workspace.XXXXXX'),OWNED_STAT_QUERY=str(case/'native-stat-query.py'),OWNED_STAT_FAULT='',REAL_PYTHON=sys.executable,LC_ALL='C')
   p=run_owned([shell,str(script),str(app),'Log audit','','','tint','','0',str(diag)],env)
   assert workspace_receipt.is_file(),'The actual workspace must have been created before the fault';workspace=Path(workspace_receipt.read_text().strip());assert workspace.parent==case and workspace.name.startswith('workspace.')
   assert tee_receipt.read_text() in (['0'] if mode=='healthy' else ['0','1']),'The actual tee must have returned and closed its captured pipes'
   marker=(dest/'marker').read_text() if (dest/'marker').is_file() else None
   if mode=='healthy':assert p.returncode==0 and not dest.exists() and not workspace.exists() and p.stdout=='healthy-tee-marker\n'
   elif version=='new' or shell.endswith('bash'):
    assert p.returncode==1 and not workspace.exists()
    if mode=='failure':assert not dest.exists()
    if mode=='foreign':assert marker=='foreign'
    if mode=='refusal':assert dest.exists()
   else:assert p.returncode==1 and workspace.exists()
   log=diag.read_text();assert ('permission denied' in (p.stdout+p.stderr).lower())==(mode!='healthy');assert ('SRC_EXE='+str(app/'Contents/MacOS/Source') in log)==(mode=='healthy')
   rows.append({'version':version,'mode':mode,'shell':shell,'exit':p.returncode,'created_workspace':str(workspace),'workspace_exists_after':workspace.exists(),'destination_exists_after':dest.exists(),'foreign_marker':marker,'tee_retired':tee_receipt.read_text(),'whole_source':mode!='healthy','stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'fixture_retained':str(case)})
   # Restore only the exact permission controls created by this observer; no deletion.
   (home/'Applications').chmod(0o700);diag.chmod(0o600)
receipt={'time_paris':datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'cases':rows,'case_count':len(rows),'all_oracles_passed':True,'real_execution':'Linux actual zsh/bash plus whole production source, except healthy prefix exit before icon/native desktop work. Only BSD stat argv, metadata fixture and owned mktemp location are controlled; tee is actual and retired.','ownership':'No global temporary-folder search or deletion; each workspace is admitted by a private exact creation receipt. All fixture evidence retained.','native_darwin':'Not executed'};(root/'independent-matrix.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'cases':len(rows),'all_oracles_passed':True,'old_new_source_hashes':[hashlib.sha256(old.encode()).hexdigest(),hashlib.sha256(source.encode()).hexdigest()]}))
