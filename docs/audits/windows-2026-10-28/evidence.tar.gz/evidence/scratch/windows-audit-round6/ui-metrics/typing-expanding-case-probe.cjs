'use strict';
const assert=require('node:assert/strict');
const vm=require('node:vm');
const {loadMetricsTypingPage}=require('/workspace/ergopti-windows-r6-ui-metrics/tools/test/support/metrics-apps-page.cjs');
for(const sensitive of [true,false]) {
 const page=loadMetricsTypingPage('windows');
 const blob={metrics_manifest:{'2026-10-26':{'Editor.exe':{chars:2,time:200}}},_prefetch_data:{historical:{c:{'İ':{c:1,t:100,e:0},a:{c:1,t:100,e:0}},bg:{'İa':{c:1,t:100,e:0}}},today:{}},app_icons:{},keycode_layout:{},driver_meta:{os:'windows',heatmap_id:'sc'}};
 page.messageListeners.filter(e=>e.name==='message').at(-1).callback({data:{type:'prefetch',blob}});
 if(sensitive)page.elements.get('btn_case_sensitive').classList.add('active');else page.elements.get('btn_case_sensitive').classList.remove('active');
 page.context.apply_local_filters();
 vm.runInContext("app_state.current_tab='c'",page.context);page.context.render_current_tab();page.timers.at(-1)();
 const chars=JSON.parse(vm.runInContext('JSON.stringify(app_state.rendered_list.map(r=>({key:r.key,count:r.count})))',page.context));
 vm.runInContext("app_state.current_tab='bg'",page.context);page.context.render_current_tab();page.timers.at(-1)();
 const bigrams=JSON.parse(vm.runInContext('JSON.stringify(app_state.rendered_list.map(r=>({key:r.key,count:r.count})))',page.context));
 console.log(JSON.stringify({sensitive,chars,bigrams}));
 assert.equal(chars.reduce((total,r)=>total+r.count,0),2,'case mode preserves two native character occurrences');
 assert.equal(bigrams.length,1,'case mode preserves the native bigram');
}
