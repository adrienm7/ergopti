# `_shared/` — cross-driver shared tree

Everything here is consumed by **more than one** driver (`windows/` AHK,
`macos/` Hammerspoon/Lua, `linux/` LuaJIT). The single most common point of
confusion is the difference between `lua/` and `modules/` — they look like they
overlap (both have `llm/`, `logger/`) but they are **different kinds of thing**.
This file is the invariant.

## Folder boundary (the rule)

| Folder               | Contains                                                                                                                                                                     | Consumed by                                                                                                                        | Example                                                                                                                                                           |
| -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **`lua/`**           | **Runtime Lua code** — modules `require`d at runtime by the Lua drivers.                                                                                                     | macOS + Linux Lua drivers, via `require("…")`.                                                                                     | `hotstrings/engine/matcher/`, `core/logger/engine/init.lua`, `core/text/engine/toml_codec/`, `layouts/engine/layers/terminators_catalogue.lua`                    |
| **`modules/<sub>/`** | **Data + specs + scripts** — JSON/TOML data, JS `*.spec.js`, `SPEC.md`, install/validation scripts (`.ps1`/`.sh`/`.py`). **No runtime `.lua`.**                              | Every driver (parsed as data), plus the JS test/codegen tooling.                                                                   | `settings/data/features/manifest.toml`, `menu/data/menu_manifest.json`, `ai/data/*.json` + `install/*.{ps1,sh}`, `core/logger/data/SPEC.md` + `test_vectors.json` |
| **`core/`**          | **JS contracts** — the hexagonal port/domain specs (`ports/*.spec.js`, `domain/*.spec.js`), `contracts.json`, and `config_schema/`. The contract _is_ the cross-driver test. | JS test suite (`test:port-compliance`, `test:config-schema`, …).                                                                   | `core/ports/contracts.json`, `settings/data/config_schema/config.schema.json`                                                                                     |
| **`data/`**          | **Pure data** — no code.                                                                                                                                                     | All drivers + the website.                                                                                                         | `core/i18n/data/locales/*.json`, `layouts/data/keycodes/azerty.json`, `metrics/data/db/schema.sql`                                                                |
| **`ui/`**            | **Shared webview frontends** — host-agnostic `index.html`/`script.js`/`style.css` rendered by WebView2 (Windows) and WKWebView (macOS).                                      | Windows + macOS UI hosts.                                                                                                          | `ui/model_browser/`, `ui/onboarding/`, `ui/metrics_typing/`                                                                                                       |
| **`tap_hold/`**      | Shared tap-hold defaults TOML (FEAT A single source).                                                                                                                        | AHK boot loader + macOS Karabiner generator.                                                                                       | `tap_hold/data/defaults.toml`                                                                                                                                     |
| **`tests/`**         | Cross-driver shared **corpora & fixtures** — run identically by every driver's suite to certify parity.                                                                      | AHK + Lua test suites.                                                                                                             | `tests/corpus/toml/fuzz_corpus.json`, `tests/corpus/llm/`                                                                                                         |
| **`_generated/`**    | **Generated data written once for every driver** — never edited by hand; `npm run build:manifest` rewrites it.                                                               | Build tooling: each driver's `_generated/config_template.toml` is a projection of it (`tools/lib/config-template-projection.cjs`). | `_generated/config_template.toml`                                                                                                                                 |

## Why two homes for `llm/` and `logger/`

There is **no overlap**, only a naming coincidence:

- `_shared/ai/engine/` and `_shared/core/logger/engine/` hold the **runtime Lua** (`parser.lua`,
  `prompt_builder.lua`, `core/logger/engine/init.lua`) that the Lua drivers `require`.
- `_shared/ai/data/` and `_shared/core/logger/data/` hold **data + specs +
  scripts** (`defaults.json`, model install scripts, `SPEC.md`, `test_vectors.json`)
  — zero `.lua` files.

## How the AHK driver gets shared logic — no transpilation exists

**Nothing in this repository is transpiled.** Every generator under `tools/codegen/`
and `tools/build/` emits **data** in the target language; none translates Lua to AHK.
Two of them additionally carry hand-written AHK inside a JS template string, which
is what creates the illusion of transpilation — and one of those never even opens
the Lua file it names as its source.

The prior claim that "AHK cannot read the shared data" is also false:
`windows/lib/json.ahk` and `windows/lib/toml/` exist, and the AHK driver already
reads `menu_manifest.json`, `priority.json`, the 21 locale JSONs, every hotstrings
TOML and `profiles.json` **at runtime**. Codegen here is therefore never about
capability — only about boot cost and pre-resolution.

So a behaviour shared with the AHK driver reaches it in exactly one of two ways:

1. **Generated data** — the shared source is collapsed into a pre-resolved literal
   (`_generated/features_manifest.ahk`, `_generated/terminators.ahk`).
2. **A hand-written twin pinned by a shared vector corpus** — `_shared/tests/corpus/`
   is then the contract, and a divergence fails CI on both drivers.

A third hand-maintained copy with no corpus between it and its twin is not allowed.

## Invariants

> 1. No runtime `.lua` belongs under `modules/`; no data-only catalogue belongs under
>    `lua/` (the `.lua` files in `lua/` are all executable modules, e.g. `core/text/engine/json.lua`).
> 2. **Generate only** when the driver cannot read the source, or when reading it at
>    boot would cost measurable milliseconds. Otherwise read the data at runtime — and
>    when you do generate, generate _data_, never _logic_.
> 3. No node under `_shared/` may be named after a platform. Two current violations
>    (`lua/linux/`, `lua/llm/linux_bridge.lua`) are still there.
> 4. `_shared/` is **not** automatically shared: measured, only 37.7 % of its
>    8 473 lines are required in production by both Lua drivers. Check the real
>    consumers before assuming an edit reaches macOS _and_ Linux.
>
> Keep new files on the correct side of these lines.
