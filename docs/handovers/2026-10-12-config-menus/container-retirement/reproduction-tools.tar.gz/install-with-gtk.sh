#!/bin/bash
set -euo pipefail

cd /workspace/ergopti
setup_root=/workspace/.ergopti-cloud
mkdir -p "$setup_root"/{runtime,bin,share,config,cache,tmp,apt/debs,apt/lists/partial,apt/cache/archives/partial}
export UV_CACHE_DIR="$setup_root/uv-cache"
export XDG_DATA_HOME="$setup_root/share"
export XDG_CONFIG_HOME="$setup_root/config"
export XDG_CACHE_HOME="$setup_root/cache"
export npm_config_cache="$setup_root/npm-cache"
export PYTHONDONTWRITEBYTECODE=1

node_version=$(cat .node-version)
test "$(uname -s)" = Linux
test "$(uname -m)" = x86_64
node_root="$setup_root/runtime/node-v${node_version}-linux-x64"
if [ ! -x "$node_root/bin/node" ] || [ "$("$node_root/bin/node" --version)" != "v$node_version" ]; then
    node_asset="node-v${node_version}-linux-x64.tar.xz"
    curl -fL --proto '=https' --tlsv1.2 "https://nodejs.org/dist/v${node_version}/SHASUMS256.txt" -o "$setup_root/runtime/node-SHASUMS256.txt"
    curl -fL --proto '=https' --tlsv1.2 "https://nodejs.org/dist/v${node_version}/${node_asset}" -o "$setup_root/runtime/$node_asset"
    python3 - "$setup_root/runtime" "$node_asset" <<'PY'
import hashlib
import sys
import tarfile
from pathlib import Path
root, asset = Path(sys.argv[1]), sys.argv[2]
expected = [line.split()[0] for line in (root / 'node-SHASUMS256.txt').read_text().splitlines() if line.split()[-1] == asset]
assert len(expected) == 1
assert hashlib.sha256((root / asset).read_bytes()).hexdigest() == expected[0]
with tarfile.open(root / asset) as archive:
    archive.extractall(root, filter='data')
PY
fi
export PATH="$node_root/bin:$PATH"

python3 - "$setup_root" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
(root / 'apt/sources.list').write_text('deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main\n')
(root / 'apt/apt.conf').write_text(f'''Dir::Etc::sourcelist "{root}/apt/sources.list";
Dir::Etc::sourceparts "-";
Dir::Etc::parts "-";
Dir::State::lists "{root}/apt/lists";
Dir::Cache::archives "{root}/apt/cache/archives";
Dir::Cache::pkgcache "{root}/apt/pkgcache.bin";
Dir::Cache::srcpkgcache "{root}/apt/srcpkgcache.bin";
Debug::NoLocking "true";
APT::Get::List-Cleanup "false";
''')
PY
/usr/bin/apt-get -c "$setup_root/apt/apt.conf" update
package_refresh=$(mktemp -d "$setup_root/apt/debs/refresh.XXXXXXXX")
(
    cd "$package_refresh"
    /usr/bin/apt-get -c "$setup_root/apt/apt.conf" download lua5.4 liblua5.4-0 luajit libluajit-5.1-2 libluajit-5.1-common lua-luv lua-filesystem lua-posix libedit2 libxml2-utils libuv1t64 libxml2 liblua5.1-0
)
for package in "$package_refresh"/*.deb; do
    dpkg-deb -x "$package" "$setup_root/sysroot"
done
python3 - "$setup_root" "$node_root" <<'PY'
import sys
from pathlib import Path
root, node_root = Path(sys.argv[1]), Path(sys.argv[2])
for name, version, binary in [('lua', '5.4', 'lua5.4'), ('lua5.4', '5.4', 'lua5.4'), ('luajit', '5.1', 'luajit')]:
    wrapper = f'''#!/bin/sh
set -eu
export LD_LIBRARY_PATH="{root}/sysroot/usr/lib/x86_64-linux-gnu${{LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}}"
export LUA_CPATH='{root}/sysroot/usr/lib/x86_64-linux-gnu/lua/{version}/?.so;'"${{LUA_CPATH:-;}}"
export LUA_PATH='{root}/sysroot/usr/share/lua/{version}/?.lua;{root}/sysroot/usr/share/lua/{version}/?/init.lua;'"${{LUA_PATH:-;}}"
exec {root}/sysroot/usr/bin/{binary} "$@"
'''
    target = root / 'bin' / name
    if target.exists():
        assert not target.is_symlink() and target.read_text() == wrapper, f'Preserve unexpected file: {target}'
    target.write_text(wrapper)
    target.chmod(0o755)
xmllint = root / 'bin/xmllint'
if not xmllint.exists():
    xmllint.symlink_to(root / 'sysroot/usr/bin/xmllint')
(root / 'activate.sh').write_text(f'''export PATH="{node_root}/bin:{root}/python/bin:{root}/bin:$PATH"
export npm_config_cache={root}/npm-cache
export UV_CACHE_DIR={root}/uv-cache
export XDG_DATA_HOME={root}/share
export XDG_CONFIG_HOME={root}/config
export XDG_CACHE_HOME={root}/cache
export TMPDIR=/var/tmp/ergopti-cloud-validation
export PYTHONDONTWRITEBYTECODE=1
''')
PY
if [ ! -x "$setup_root/python/bin/python" ]; then
    python3 -m venv "$setup_root/python"
fi
uv pip install --python "$setup_root/python/bin/python" "ruff==$(node tools/lint/format.cjs --ruff-version)"
mkdir -p /var/tmp/ergopti-cloud-validation
mkdir -p "$HOME/.config/ergopti_plus/hammerspoon"
. "$setup_root/activate.sh"
./tools/rtk/bootstrap.sh ensure
npm ci --no-audit --no-fund
node --version
ruff --version
lua -e 'assert(require("luv").version()); assert(require("lfs").attributes(".")); print(_VERSION)'
luajit -e 'assert(require("luv").version()); assert(require("lfs").attributes(".")); assert(require("posix")); print(jit.version)'

# Tested native GTK source-receiving runtime; keep host packages unchanged.
cat > "$setup_root/install-gtk.sh" <<'ERGOPTI_GTK_INSTALL_GTK_SH'
#!/usr/bin/env bash
set -euo pipefail
cloud_gtk_base=/workspace/.ergopti-cloud
export APT_CONFIG="$cloud_gtk_base/apt/apt.conf"
mkdir -p "$cloud_gtk_base/gtk-root" "$cloud_gtk_base/gtk-downloads"
apt-get update > "$cloud_gtk_base/gtk-apt-update.log" 2>&1
/usr/bin/python3 - <<'PY'
import hashlib,json,pathlib,subprocess,urllib.request,datetime
base=pathlib.Path('/workspace/.ergopti-cloud')
manifest=json.loads((base/'gtk-dependency-feasibility.json').read_text())
rows=[]
for p in manifest['selected']:
    fields={}
    record=subprocess.check_output(['apt-cache','show',p['name']+'='+p['version']],text=True).split('\n\n')[0]
    for line in record.splitlines():
        if ': ' in line and not line.startswith(' '):
            key,value=line.split(': ',1);fields[key]=value
    assert fields['SHA256']==p['sha256'],p['name']
    assert fields['Filename']==p['filename'],p['name']
    assert int(fields['Size'])==p['archive_bytes'],p['name']
    archive=base/'gtk-downloads'/pathlib.Path(p['filename']).name
    if not archive.exists():
        with urllib.request.urlopen('https://deb.debian.org/debian/'+p['filename'],timeout=60) as response:
            archive.write_bytes(response.read())
    data=archive.read_bytes()
    assert len(data)==p['archive_bytes'] and hashlib.sha256(data).hexdigest()==p['sha256'],p['name']
    control=subprocess.check_output(['dpkg-deb','--field',str(archive),'Package','Version'],text=True)
    assert 'Package: '+p['name'] in control and 'Version: '+p['version'] in control,control
    subprocess.run(['dpkg-deb','--extract',str(archive),str(base/'gtk-root')],check=True)
    rows.append({**p,'archive':str(archive),'verified_against_refreshed_signed_index':True,'extracted':True})
    print(p['name'],p['version'],'verified/extracted',flush=True)
receipt={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXTRACTED_NOT_YET_RUNTIME_QUALIFIED','prefix':str(base/'gtk-root'),'system_packages_changed':False,'signature_policy':'APT signed-by Debian archive keyring; no insecure flags','package_count':len(rows),'packages':rows,'apt_update_log_sha256':hashlib.sha256((base/'gtk-apt-update.log').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((base/'gtk-dependency-feasibility.json').read_bytes()).hexdigest()}
(base/'gtk-install-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
PY
if [ -d "$cloud_gtk_base/gtk-root/usr/share/glib-2.0/schemas" ]; then
    glib-compile-schemas "$cloud_gtk_base/gtk-root/usr/share/glib-2.0/schemas"
fi
ERGOPTI_GTK_INSTALL_GTK_SH
cat > "$setup_root/activate-gtk.sh" <<'ERGOPTI_GTK_ACTIVATE_GTK_SH'
# Dedicated, extracted Debian GTK runtime; source after the normal activation.
export PATH="/workspace/.ergopti-cloud/gtk-root/usr/bin:/workspace/.ergopti-cloud/bin:$PATH"
export LD_LIBRARY_PATH="/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu:/workspace/.ergopti-cloud/sysroot/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LUA_PATH="/workspace/.ergopti-cloud/gtk-root/usr/share/lua/5.1/?.lua;/workspace/.ergopti-cloud/gtk-root/usr/share/lua/5.1/?/init.lua;${LUA_PATH:-;}"
export LUA_CPATH="/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/lua/5.1/?.so;${LUA_CPATH:-;}"
export GI_TYPELIB_PATH="/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/girepository-1.0${GI_TYPELIB_PATH:+:$GI_TYPELIB_PATH}"
export WEBKIT_EXEC_PATH=/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1
export WEBKIT_INJECTED_BUNDLE_PATH=/workspace/.ergopti-cloud/gtk-root/usr/lib/x86_64-linux-gnu/webkit2gtk-4.1/injected-bundle
export GSETTINGS_SCHEMA_DIR=/workspace/.ergopti-cloud/gtk-root/usr/share/glib-2.0/schemas
export XDG_DATA_DIRS="/workspace/.ergopti-cloud/gtk-root/usr/share:${XDG_DATA_DIRS:-/usr/local/share:/usr/share}"
export GDK_BACKEND=x11
ERGOPTI_GTK_ACTIVATE_GTK_SH
cat > "$setup_root/build-gtk-overlay.py" <<'ERGOPTI_GTK_BUILD_GTK_OVERLAY_PY'
import pathlib,os,json
base=pathlib.Path('/workspace/.ergopti-cloud');out=base/'gtk-overlay';out.mkdir(exist_ok=True)
rows=[]
def merge(host,prefix,dest,mapped):
 dest.mkdir(exist_ok=True)
 for name in sorted(set(os.listdir(host) if host.is_dir() else [])|set(os.listdir(prefix) if prefix.is_dir() else [])):
  h,p=host/name,prefix/name;d=dest/name
  if h.is_dir() and not h.is_symlink() and p.is_dir() and not p.is_symlink():
   merge(h,p,d,mapped/name);continue
  target=p if p.exists() or p.is_symlink() else mapped/name
  if d.is_symlink(): assert os.readlink(d)==str(target)
  else: d.symlink_to(target)
  rows.append({'view':str(d),'target':str(target)})
merge(pathlib.Path('/usr/lib/x86_64-linux-gnu'),base/'gtk-root/usr/lib/x86_64-linux-gnu',out/'libs',pathlib.Path('/run/gtk-system-libs'))
merge(pathlib.Path('/usr/bin'),base/'gtk-root/usr/bin',out/'bin',pathlib.Path('/run/gtk-system-bin'))
(out/'manifest.json').write_text(json.dumps({'entries':rows,'count':len(rows),'system_files_modified':False},indent=2)+'\n')
print(len(rows))
ERGOPTI_GTK_BUILD_GTK_OVERLAY_PY
cat > "$setup_root/run-with-gtk.sh" <<'ERGOPTI_GTK_RUN_WITH_GTK_SH'
#!/usr/bin/env bash
set -euo pipefail
source /workspace/.ergopti-cloud/activate.sh
source /workspace/.ergopti-cloud/activate-gtk.sh
exec /usr/bin/bwrap --unshare-user --unshare-pid --die-with-parent --new-session \
 --ro-bind / / --tmpfs /run \
 --ro-bind /usr/lib/x86_64-linux-gnu /run/gtk-system-libs \
 --ro-bind /usr/bin /run/gtk-system-bin \
 --ro-bind /workspace/.ergopti-cloud/gtk-overlay/libs /usr/lib/x86_64-linux-gnu \
 --ro-bind /workspace/.ergopti-cloud/gtk-overlay/bin /usr/bin \
 --bind /workspace /workspace --bind /tmp /tmp --proc /proc --dev /dev --tmpfs /dev/shm -- "$@"
ERGOPTI_GTK_RUN_WITH_GTK_SH
cat > "$setup_root/gtk-dependency-feasibility.json" <<'ERGOPTI_GTK_GTK_DEPENDENCY_FEASIBILITY_JSON'
{
  "selected": [
    {
      "name": "libjavascriptcoregtk-4.1-0",
      "version": "2.52.6-1~deb13u1",
      "archive_bytes": 7511632,
      "installed_kib": 31958,
      "sha256": "3383ebb3e13f31225c65f41112420be58493a3de112b5993cf5c417cfedc47c8",
      "filename": "pool/main/w/webkit2gtk/libjavascriptcoregtk-4.1-0_2.52.6-1~deb13u1_amd64.deb"
    },
    {
      "name": "gir1.2-javascriptcoregtk-4.1",
      "version": "2.52.6-1~deb13u1",
      "archive_bytes": 53444,
      "installed_kib": 316,
      "sha256": "9e57221197602f7e1adebb55dbf01ddcd56d71479faab3392fda5836d4294c03",
      "filename": "pool/main/w/webkit2gtk/gir1.2-javascriptcoregtk-4.1_2.52.6-1~deb13u1_amd64.deb"
    },
    {
      "name": "gir1.2-soup-3.0",
      "version": "3.6.5-3",
      "archive_bytes": 29684,
      "installed_kib": 93,
      "sha256": "d52c5be8f54c526178a18b28611d2c64ddefbc930d0eaa99b19ec2a7b2326f07",
      "filename": "pool/main/libs/libsoup3/gir1.2-soup-3.0_3.6.5-3_amd64.deb"
    },
    {
      "name": "libgles2",
      "version": "1.7.0-1+b2",
      "archive_bytes": 17256,
      "installed_kib": 106,
      "sha256": "e12c18aa77939d122ee1dea520ba0440b97dc19200b7396e03dff03a3ece74c1",
      "filename": "pool/main/libg/libglvnd/libgles2_1.7.0-1+b2_amd64.deb"
    },
    {
      "name": "xdg-dbus-proxy",
      "version": "0.1.6-1+deb13u2",
      "archive_bytes": 25640,
      "installed_kib": 72,
      "sha256": "ab3d712fc62e7ac401aef2d08242721544917f8161859d8e650fef8e147a7001",
      "filename": "pool/main/x/xdg-dbus-proxy/xdg-dbus-proxy_0.1.6-1+deb13u2_amd64.deb"
    },
    {
      "name": "libharfbuzz-icu0",
      "version": "10.2.0-1+deb13u1",
      "archive_bytes": 15452,
      "installed_kib": 61,
      "sha256": "0b45d951629e98673c0da73b2bcd0886a467d833bb3b7499892a168f247165d2",
      "filename": "pool/main/h/harfbuzz/libharfbuzz-icu0_10.2.0-1+deb13u1_amd64.deb"
    },
    {
      "name": "libhyphen0",
      "version": "2.8.8-7+b2",
      "archive_bytes": 30664,
      "installed_kib": 81,
      "sha256": "fa9dca7b8cf1381fd52800c44a385c5725a78a88bd705f7c39b1046a5293435e",
      "filename": "pool/main/h/hyphen/libhyphen0_2.8.8-7+b2_amd64.deb"
    },
    {
      "name": "libhidapi-hidraw0",
      "version": "0.14.0-1+b2",
      "archive_bytes": 12664,
      "installed_kib": 49,
      "sha256": "89c546cb55be403ce63fe668baff2515979100a30fa07e2b97de186b9c07f01e",
      "filename": "pool/main/h/hidapi/libhidapi-hidraw0_0.14.0-1+b2_amd64.deb"
    },
    {
      "name": "libmanette-0.2-0",
      "version": "0.2.12-1",
      "archive_bytes": 43752,
      "installed_kib": 325,
      "sha256": "98841a467692c46fd1870275113235691ebbfe71a3524f6b2a0fa7e9c33c6e56",
      "filename": "pool/main/libm/libmanette/libmanette-0.2-0_0.2.12-1_amd64.deb"
    },
    {
      "name": "libwebkit2gtk-4.1-0",
      "version": "2.52.6-1~deb13u1",
      "archive_bytes": 24163372,
      "installed_kib": 96656,
      "sha256": "6471d989a61a56a7801e88e420789aa6b0eaba630a9787365bba8b9576b7ba1c",
      "filename": "pool/main/w/webkit2gtk/libwebkit2gtk-4.1-0_2.52.6-1~deb13u1_amd64.deb"
    },
    {
      "name": "gir1.2-webkit2-4.1",
      "version": "2.52.6-1~deb13u1",
      "archive_bytes": 109960,
      "installed_kib": 614,
      "sha256": "79ada9d709a892ffc1279384830dc061671f36003332cedbad8ab27dae831c4e",
      "filename": "pool/main/w/webkit2gtk/gir1.2-webkit2-4.1_2.52.6-1~deb13u1_amd64.deb"
    },
    {
      "name": "libstemmer0d",
      "version": "2.2.0-4+b2",
      "archive_bytes": 118780,
      "installed_kib": 819,
      "sha256": "ee9510a4f48b6efad845cad80b8773d72219291d325e4e3c3d07b3930a7bf2ee",
      "filename": "pool/main/s/snowball/libstemmer0d_2.2.0-4+b2_amd64.deb"
    },
    {
      "name": "libxmlb2",
      "version": "0.3.22-1",
      "archive_bytes": 63096,
      "installed_kib": 191,
      "sha256": "21288db65dd4b5b4e7f054674d383a5af328663d0cd81e6871e8bcde221b2f0e",
      "filename": "pool/main/libx/libxmlb/libxmlb2_0.3.22-1_amd64.deb"
    },
    {
      "name": "libappstream5",
      "version": "1.0.5-1",
      "archive_bytes": 225908,
      "installed_kib": 785,
      "sha256": "532cdb01d8b8bc522719bba46fa61d16f91a3efbad32394466b97d4a69340a7d",
      "filename": "pool/main/a/appstream/libappstream5_1.0.5-1_amd64.deb"
    },
    {
      "name": "libgraphene-1.0-0",
      "version": "1.10.8-5",
      "archive_bytes": 42352,
      "installed_kib": 147,
      "sha256": "ddcf98f17f6c0a7c76974d7238be1468e59c186034c1b806638d32d9f446ea6e",
      "filename": "pool/main/g/graphene/libgraphene-1.0-0_1.10.8-5_amd64.deb"
    },
    {
      "name": "liblzo2-2",
      "version": "2.10-3+b1",
      "archive_bytes": 55100,
      "installed_kib": 173,
      "sha256": "f3032201fe2928a87e13f05ce256ff3ac2a7860c7e594dc51ae6d7348a4466ce",
      "filename": "pool/main/l/lzo2/liblzo2-2_2.10-3+b1_amd64.deb"
    },
    {
      "name": "libcairo-script-interpreter2",
      "version": "1.18.4-1+b1",
      "archive_bytes": 59256,
      "installed_kib": 201,
      "sha256": "52b45eb6e49c53c0a35ef45555a9457b094482eafef27d27cd777b916a2f06de",
      "filename": "pool/main/c/cairo/libcairo-script-interpreter2_1.18.4-1+b1_amd64.deb"
    },
    {
      "name": "libgtk-4-common",
      "version": "4.18.6+ds-2",
      "archive_bytes": 2797392,
      "installed_kib": 15787,
      "sha256": "32f0ad042f983b1d53cd2c260d4042eda9041b6debb71beb91937196b1ff3f6b",
      "filename": "pool/main/g/gtk4/libgtk-4-common_4.18.6+ds-2_all.deb"
    },
    {
      "name": "libgtk-4-1",
      "version": "4.18.6+ds-2",
      "archive_bytes": 3166640,
      "installed_kib": 11261,
      "sha256": "51ab1114a57702e703cce745c24caf5bd31ec1d2a900c72fd15fe47c6c030e68",
      "filename": "pool/main/g/gtk4/libgtk-4-1_4.18.6+ds-2_amd64.deb"
    },
    {
      "name": "libadwaita-1-0",
      "version": "1.7.6-1~deb13u1",
      "archive_bytes": 528344,
      "installed_kib": 2827,
      "sha256": "b3ff133512acc2d303892eba6eeac29506efd579e418fdbce6af6dcb50b3de4c",
      "filename": "pool/main/liba/libadwaita-1/libadwaita-1-0_1.7.6-1~deb13u1_amd64.deb"
    },
    {
      "name": "libxdo3",
      "version": "1:3.20160805.1-5.1",
      "archive_bytes": 30996,
      "installed_kib": 78,
      "sha256": "d634e25d2b50af140ee9f44bab507fcfb665f3556fd483faefdb56e85598cc12",
      "filename": "pool/main/x/xdotool/libxdo3_3.20160805.1-5.1_amd64.deb"
    },
    {
      "name": "lua-lgi",
      "version": "0.9.2-4",
      "archive_bytes": 108076,
      "installed_kib": 642,
      "sha256": "c3153108be65eaebd661b342bcc2e69d6f364ea84106e041653c91576ffb6b49",
      "filename": "pool/main/l/lua-lgi/lua-lgi_0.9.2-4_amd64.deb"
    },
    {
      "name": "xdotool",
      "version": "1:3.20160805.1-5.1",
      "archive_bytes": 51488,
      "installed_kib": 122,
      "sha256": "98ac8681533b01020c7288fb2e9de403d586747dab48cfd58e04cb00d0c44fb1",
      "filename": "pool/main/x/xdotool/xdotool_3.20160805.1-5.1_amd64.deb"
    },
    {
      "name": "xvfb",
      "version": "2:21.1.16-1.3+deb13u3",
      "archive_bytes": 3198040,
      "installed_kib": 4525,
      "sha256": "365da2b6c93339f34337c434a9489bb6411a240fa47b9f49693d3091745f28c2",
      "filename": "pool/main/x/xorg-server/xvfb_21.1.16-1.3+deb13u3_amd64.deb"
    },
    {
      "name": "zenity-common",
      "version": "4.1.90-1",
      "archive_bytes": 2493456,
      "installed_kib": 9329,
      "sha256": "f058842a23605662eb92efc602aee198906db888ed61301e5b8f061e042f91d0",
      "filename": "pool/main/z/zenity/zenity-common_4.1.90-1_all.deb"
    },
    {
      "name": "zenity",
      "version": "4.1.90-1",
      "archive_bytes": 73892,
      "installed_kib": 190,
      "sha256": "ac56ebaf225e62c8413101d7ddc255eff459b683c8c6a0801da978cfa473bbbd",
      "filename": "pool/main/z/zenity/zenity_4.1.90-1_amd64.deb"
    }
  ]
}
ERGOPTI_GTK_GTK_DEPENDENCY_FEASIBILITY_JSON
chmod +x "$setup_root/run-with-gtk.sh"
bash "$setup_root/install-gtk.sh"
/usr/bin/python3 "$setup_root/build-gtk-overlay.py"

