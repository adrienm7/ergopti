﻿#Requires AutoHotkey v2.0
#SingleInstance Off
#NoTrayIcon
FileAppend(A_Temp, A_Args[1], "UTF-8")
ExitApp(0)
