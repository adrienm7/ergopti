'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const vm = require('node:vm');
const root = process.env.ERGOPTI_PROPOSAL_SOURCE_ROOT || '/workspace/ergopti';
const base = __dirname;
const { parse } = require(root + '/node_modules/smol-toml');
const bindings = require(root + '/tools/lib/menu-hotstring-language-binding.cjs');
const availability = require(root + '/tools/lib/menu-row-availability.cjs');
const { selectGates } = require(root + '/tools/test/verify-change.cjs');
const { scriptTokens } = require(root + '/tools/lib/script-source.cjs');
const paths = [
 'static/ergopti_plus/windows/ui/menu/menu_hotstrings.ahk',
 'static/ergopti_plus/windows/infra/manifest_menu.ahk',
 'static/ergopti_plus/_shared/modules/features/manifest.toml'
];
const read = (role, name) => fs.readFileSync(path.join(base, role, name), 'utf8');
const before = paths.map(p => read('before',p)), candidate = paths.map(p => read('candidate',p));
const results = [];
function check(name, fn) { fn(); results.push({name, status:'PASS'}); }
for (const [i,p] of paths.entries()) {
 check('preserved LF: '+p, () => assert(!candidate[i].includes('\r')));
 if (p.endsWith('.ahk')) {
  check('preserved UTF-8 BOM: '+p, () => assert(fs.readFileSync(path.join(base,'candidate',p)).subarray(0,3).equals(Buffer.from([239,187,191]))));
  check('tokenizer balanced braces (not native parsing): '+p, () => {
   let depth=0;
   for(const token of scriptTokens(candidate[i],'.ahk')) {
    if(token.kind==='symbol'&&token.value==='{') depth++;
    if(token.kind==='symbol'&&token.value==='}') depth--;
    assert(depth>=0);
   }
   assert.equal(depth,0);
  });
 }
}
const oldManifest=parse(before[2]), nextManifest=parse(candidate[2]);
const newKeys=['hotstring_personal_default_construction_ahk','hotstring_personal_file_construction_ahk','hotstring_personal_folder_construction_ahk','hotstring_personal_tree_construction_ahk'];
check('all existing manifest values unchanged', () => {
 const restored=parse(candidate[2]);
 for(const key of newKeys) { assert(!Object.hasOwn(oldManifest.menu,key)); delete restored.menu[key]; }
 assert.deepStrictEqual(restored,oldManifest);
});
check('existing shared renderer bytes are exact prefix', () => assert(candidate[1].startsWith(before[1])));
check('exactly four recipes declared', () => assert.deepStrictEqual(Object.keys(nextManifest.menu).filter(k=>!Object.hasOwn(oldManifest.menu,k)),newKeys));
for(const [key,frame,count,target] of [
 [newKeys[1],'hotstring_personal_file_frame','post_append_controls_plus_sections_plus_open','native_menu'],
 [newKeys[2],'hotstring_personal_directory_frame','post_append_subfolders_plus_files','native_menu'],
 [newKeys[3],'hotstring_personal_directory_frame','post_append_folders','rows_or_native_menu']
]) check('independent literal placement policy: '+key, () => assert.deepStrictEqual({...nextManifest.menu[key]},{kind:'personal_frame_placement',platform:'ahk',program:['preflight_frame','place_frame'],frame,count_policy:count,target_policy:target}));
check('four original direct native frame sites present before',()=>assert.equal((before[0].match(/MenuRenderer_AppendTemplate\(/g)||[]).length,4));
check('four native frame sites delegated in candidate (no census assertion)',()=>assert.equal((candidate[0].match(/MenuRenderer_AppendTemplate\(/g)||[]).length,0));
for(const count of ['(*) => 1 + ControlRows.Length + SectionRows.Length','(*) => SubfolderRows.Length + FileRows.Length','(*) => FolderRows.Length, Rows']) check('literal original late native count binding: '+count,()=>assert(candidate[0].includes(count)));
for(const statement of [
 'TFMenu := Menu(), HandedOff := false',
 'FolderMenu := Menu()\n\t\tOwnedMenus.Push(FolderMenu)',
 'if Node["subfolders"].Count > 0 && _HS_RenderTree(Node["subfolders"], "", SubfolderRows, OwnedMenus) != true',
 'OwnedMenus.Push(FileRow["submenu"])',
 'Result := (FileStem := TF.stem . "",\n\t\tFileCount := FmtCount(Owner is PersonalFileAdoptedOwner ? Owner.ActiveCount() : TF.count) . "",',
 'FolderRow := (FolderPositive := FolderTotal > 0,\n\t\t\tFolderCount := FolderPositive ? FmtCount(FolderTotal) . "" : "",\n\t\t\tFolderNameReceipt := FolderName . "",'
]) check('original allocation/traversal/coercion source retained: '+statement.split('\n')[0],()=>{assert(before[0].includes(statement));assert(candidate[0].includes(statement));});
check('all four original primary/cleanup finally blocks unchanged',()=>{
 const blocks=s=>s.match(/\} catch as ErrorInfo \{\n\t\tPrimaryFailure := ErrorInfo[\s\S]*?\n\t\}\n\}/g);
 assert.equal(blocks(before[0]).length,4);assert.deepStrictEqual(blocks(candidate[0]),blocks(before[0]));
});
const helper=candidate[1].slice(candidate[1].indexOf('MenuRenderer_ConstructPersonalFrame(RecipeKey,'));
check('preflight precedes data/native placement',()=>assert(helper.indexOf('Rendered := TemplateOwner.Call(')<helper.indexOf('case "place_frame":')));
check('data handoff returns before native append or count read',()=>{const start=helper.indexOf('if DataHandoff {');const append=helper.indexOf('Added := AppendOwner.Call(');assert(start<append);assert(helper.slice(start,append).includes('RowSink.Push(Row)\n\t\t\t\treturn true'));assert(!helper.slice(start,append).includes('ReadCount.Call'));});
check('directory second read owns a new empty command map',()=>assert(helper.includes('AppendCommands := Recipe["frame"] == "hotstring_personal_directory_frame" ? Map() : Commands')));
check('native count read occurs after append and retains whole admission',()=>assert(helper.indexOf('Added := AppendOwner.Call(')<helper.indexOf('return Added == ReadCount.Call() && WholeTreeAdmitted')));
const actualManifest=JSON.parse(fs.readFileSync(root+'/static/ergopti_plus/_shared/modules/menu/menu_manifest.json','utf8'));
const rejection=[];
for(const [name,fn] of [
 ['default',s=>bindings.personalDefaultChoicePublication(s,'ahk',actualManifest)],
 ['file',bindings.personalFileCaptionPublication],
 ['folder including parent',bindings.personalFolderCaptionPublication]
]) {
 const observed={name,baseline:fn(before[0]),candidate:fn(candidate[0])};
 check('current Root proof rejects unjoined new grammar: '+name,()=>{assert.equal(observed.baseline,true);assert.equal(observed.candidate,false);});rejection.push(observed);
}
const english=JSON.parse(fs.readFileSync(root+'/static/ergopti_plus/_shared/data/locales/en.json','utf8'));
const unvalidated=[];
for(const key of newKeys) {
 const malformed=structuredClone(nextManifest.menu);malformed[key]={kind:'INVALID_UNREVIEWED_CONSTRUCTION'};
 let accepts=true;try { availability.validateChildTemplates(malformed,k=>english[k]); } catch { accepts=false; }
 unvalidated.push({key,malformed_recipe_accepted_by_current_validator:accepts});
 check('current schema lacks new recipe validation: '+key,()=>assert.equal(accepts,true));
}
// Use the actual owning linter functions against just the three external files.
// This bounded function receiving does not run or stand in for the complete gate.
let linter=fs.readFileSync(root+'/tools/lint/lint-conventions.js','utf8');
linter=linter.slice(0,linter.indexOf("console.log('lint-conventions: scanning…');"));
linter=linter.replace(/^import .*;\n/gm,'');
linter=linter.replace(/const REPO_ROOT = new URL\('[\s\S]*?\.replace\(\/\^\\\/\(\[A-Z\]:\)\/[^;]*;/,'const REPO_ROOT = suppliedRoot;');
const sandbox={readFileSync:fs.readFileSync,writeFileSync:fs.writeFileSync,readdirSync:fs.readdirSync,statSync:fs.statSync,join:path.join,relative:path.relative,extname:path.extname,sharedPaths:require(root+'/tools/lib/paths.cjs'),suppliedRoot:root,process:{argv:[]},console};
vm.createContext(sandbox);
vm.runInContext(linter,sandbox,{filename:'actual-owning-convention-functions.js'});
for(const p of paths) {
 sandbox.proposalPath=path.join(base,'candidate',p);
 check('owning convention functions bounded: '+p,()=>vm.runInContext(p.endsWith('.ahk')?'checkFileHeader(proposalPath); checkAhkAntiPatterns(proposalPath); checkAhkStringEscaping(proposalPath); checkSectionSpacing(proposalPath); checkBannerAlignment(proposalPath);':'checkTomlKeys(proposalPath);',sandbox));
}
check('bounded owning convention functions report zero violations',()=>assert.equal(vm.runInContext('totalViolations',sandbox),0));
const report={status:'INACTIVE; no feature/native qualification',checks:results.length,passed:results.length,failed:0,source_sha:JSON.parse(fs.readFileSync(path.join(base,'HANDWRITTEN-FOUR-SITE-CONTRACT.json'))).source_sha,paths,results,current_root_proof:rejection,current_schema:unvalidated,verify_change_selected_gates:[...selectGates(paths)],not_executed:['Complete verify-change gates','Native AHK parse, unit and E2E receiving','Existing 31 prepared native cases and 12 source-witness controls','Native callback lifetime, refusal cleanup, packaging, installed startup or physical acceptance','Owning menu generator after explicit Root schema/proof join'],pins:Object.fromEntries(paths.map(p=>[p,{before:crypto.createHash('sha256').update(fs.readFileSync(path.join(base,'before',p))).digest('hex'),candidate:crypto.createHash('sha256').update(fs.readFileSync(path.join(base,'candidate',p))).digest('hex')}]))};
fs.writeFileSync(path.join(base,'BOUNDED-CHECKS.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({checks:report.checks,passed:report.passed,current_root_proof:rejection,current_schema:unvalidated,selected:[...selectGates(paths).keys()]},null,2));
