// static/ergopti_plus/windows/native/key_combination_owner/pair_arbitration_test.c
/** @file pair_arbitration_test.c
 * @brief Handwritten pure C expectations; no Windows or physical input proof.
 */

#include "pair_arbitration.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks;

#define CHECK(condition) do { \
	++checks; \
	if (!(condition)) { \
		fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #condition); \
		exit(1); \
	} \
} while (0)

/* Literal miniature policy supplied by the test, not a production catalogue:
 * A then B -> action 71; B then A -> action 72; A then C -> none. */
static const ErgoptiPair_Row rows[] = {
	{11, 22, 101, 71, 0},
	{22, 11, 102, 72, 0},
	{11, 33, 103, 0, 2}
};

static ErgoptiPair_Context context(void) {
	ErgoptiPair_Context result = {8, 9, 10, true, true, false, true};
	return result;
}

static ErgoptiPair_Policy policy(bool symmetric, double threshold) {
	ErgoptiPair_Policy result = {rows, 3, threshold, symmetric, 9};
	return result;
}

static ErgoptiPair_State initialized(bool symmetric, double threshold) {
	ErgoptiPair_State result = ERGOPTI_PAIR_STATE_INIT;
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_Policy supplied = policy(symmetric, threshold);
	CHECK(ErgoptiPair_Initialize(&result, &supplied, &ctx) == ERGOPTI_PAIR_OK);
	return result;
}

static ErgoptiPair_Input edge(enum ErgoptiPair_InputKind kind, uint32_t key,
	uint64_t press, uint64_t at) {
	ErgoptiPair_Input result = {kind, ERGOPTI_PAIR_ORIGIN_PHYSICAL, key, 41, 51, press, at};
	return result;
}

static ErgoptiPair_Input clock_at(uint64_t at) {
	ErgoptiPair_Input result = {ERGOPTI_PAIR_CLOCK, ERGOPTI_PAIR_ORIGIN_UNKNOWN, 0, 0, 0, 0, at};
	return result;
}

static ErgoptiPair_Plan step(ErgoptiPair_State *state, ErgoptiPair_Context ctx,
	ErgoptiPair_Input input) {
	ErgoptiPair_Plan result;
	CHECK(ErgoptiPair_Reduce(state, &ctx, &input, state, &result) == ERGOPTI_PAIR_OK);
	CHECK(result.retirement_count <= 2);
	return result;
}

static void no_selection(const ErgoptiPair_Plan *plan) {
	CHECK(!plan->selected);
	CHECK(plan->pair_id == 0);
	CHECK(plan->action_id == 0);
}

static void check_original(const ErgoptiPair_Input *input, uint32_t key,
	uint64_t press, uint64_t at) {
	CHECK(input->kind == ERGOPTI_PAIR_DOWN);
	CHECK(input->origin == ERGOPTI_PAIR_ORIGIN_PHYSICAL);
	CHECK(input->key == key);
	CHECK(input->press == press);
	CHECK(input->at_ms == at);
	CHECK(input->source == 41);
	CHECK(input->generation == 51);
}

static void test_policy_and_initialization(void) {
	ErgoptiPair_State state = ERGOPTI_PAIR_STATE_INIT;
	ErgoptiPair_State before;
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_Policy supplied = policy(false, 100);
	ErgoptiPair_Row invalid[3];
	ErgoptiPair_Input input = clock_at(0);
	ErgoptiPair_Plan plan, old_plan;
	memset(&plan, 0x5a, sizeof(plan));
	old_plan = plan;
	before = state;
	CHECK(ErgoptiPair_Reduce(&state, &ctx, &input, &state, &plan) == ERGOPTI_PAIR_NOT_INITIALIZED);
	CHECK(memcmp(&before, &state, sizeof(state)) == 0);
	CHECK(memcmp(&old_plan, &plan, sizeof(plan)) == 0);
	CHECK(ErgoptiPair_Initialize(NULL, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_ARGUMENT);
	supplied.simultaneous_threshold_ms = 0;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	supplied.simultaneous_threshold_ms = -1;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	supplied.simultaneous_threshold_ms = NAN;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	supplied.simultaneous_threshold_ms = INFINITY;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	supplied = policy(false, 100);
	supplied.revision = 99;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	supplied = policy(false, 100);
	memcpy(invalid, rows, sizeof(rows));
	supplied.rows = invalid;
	invalid[1].canonical_index = 1;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	memcpy(invalid, rows, sizeof(rows));
	invalid[2].pair_id = 101;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	memcpy(invalid, rows, sizeof(rows));
	invalid[2].first_key = 11;
	invalid[2].second_key = 22;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_INVALID_POLICY);
	supplied = policy(false, 100);
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_OK);
	before = state;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_ALREADY_INITIALIZED);
	CHECK(memcmp(&before, &state, sizeof(state)) == 0);
	input.kind = (enum ErgoptiPair_InputKind)99;
	CHECK(ErgoptiPair_Reduce(&state, &ctx, &input, &state, &plan) == ERGOPTI_PAIR_INVALID_ARGUMENT);
	CHECK(memcmp(&before, &state, sizeof(state)) == 0);
	CHECK(memcmp(&old_plan, &plan, sizeof(plan)) == 0);
}

static void test_inclusive_deadline(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State state = initialized(false, 100);
	ErgoptiPair_Plan plan = step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	CHECK(state.mode == ERGOPTI_PAIR_WAITING);
	CHECK(plan.current_route == ERGOPTI_PAIR_BUFFER_PROPOSAL);
	CHECK(!plan.flush_first);
	plan = step(&state, ctx, clock_at(1100));
	CHECK(state.mode == ERGOPTI_PAIR_WAITING);
	CHECK(!plan.flush_first);
	CHECK(plan.current_route == ERGOPTI_PAIR_NO_EVENT);
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1100));
	CHECK(state.mode == ERGOPTI_PAIR_CHORD);
	CHECK(plan.selected);
	CHECK(plan.pair_id == 101);
	CHECK(plan.action_id == 71);
	CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
	CHECK(!plan.flush_first);
	check_original(&plan.actual_first, 11, 61, 1000);
	check_original(&plan.actual_second, 22, 62, 1100);
}

static void test_deadline_expiry_and_held_alone(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State state = initialized(false, 100);
	ErgoptiPair_Plan plan;
	step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&state, ctx, clock_at(1101));
	CHECK(state.mode == ERGOPTI_PAIR_HELD_ALONE);
	CHECK(plan.flush_first);
	check_original(&plan.original_first, 11, 61, 1000);
	no_selection(&plan);
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1101));
	CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
	CHECK(!plan.flush_first);
	no_selection(&plan);
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_REPEAT, 11, 61, 1110));
	CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_UP, 11, 61, 1120));
	CHECK(state.mode == ERGOPTI_PAIR_IDLE);
	CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
	ctx.first_available = false;
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 63, 1130));
	CHECK(state.mode == ERGOPTI_PAIR_IDLE);
	CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
}

static void test_late_second_without_clock(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State state = initialized(false, 100);
	ErgoptiPair_Plan plan;
	step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1101));
	CHECK(plan.flush_first);
	CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
	check_original(&plan.original_first, 11, 61, 1000);
	no_selection(&plan);
}

static void test_symmetric_and_ordered_selection(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State ordered = initialized(false, 100);
	ErgoptiPair_State symmetric = initialized(true, 100);
	ErgoptiPair_Plan plan;
	step(&ordered, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1000));
	plan = step(&ordered, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1001));
	CHECK(plan.selected && plan.pair_id == 102 && plan.action_id == 72);
	step(&symmetric, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1000));
	plan = step(&symmetric, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1001));
	CHECK(plan.selected && plan.pair_id == 101 && plan.action_id == 71);
	check_original(&plan.actual_first, 22, 62, 1000);
	check_original(&plan.actual_second, 11, 61, 1001);
	{
		ErgoptiPair_State none = ERGOPTI_PAIR_STATE_INIT;
		ErgoptiPair_Row supplied_rows[3];
		ErgoptiPair_Policy supplied = policy(true, 100);
		memcpy(supplied_rows, rows, sizeof(rows));
		supplied_rows[0].action_id = 0;
		supplied.rows = supplied_rows;
		CHECK(ErgoptiPair_Initialize(&none, &supplied, &ctx) == ERGOPTI_PAIR_OK);
		plan = step(&none, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1000));
		CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
		CHECK(none.mode == ERGOPTI_PAIR_IDLE);
		no_selection(&plan);
	}
}

static void test_none_and_original_order(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State state = initialized(false, 100);
	ErgoptiPair_Plan plan;
	step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 33, 63, 1001));
	CHECK(plan.flush_first);
	check_original(&plan.original_first, 11, 61, 1000);
	CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
	CHECK(state.mode == ERGOPTI_PAIR_HELD_ALONE);
	no_selection(&plan);
}

static void test_release_and_repeat_before_join(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State released = initialized(false, 100);
	ErgoptiPair_State repeated = initialized(false, 100);
	ErgoptiPair_Plan plan;
	step(&released, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&released, ctx, edge(ERGOPTI_PAIR_UP, 11, 61, 1001));
	CHECK(plan.flush_first && plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
	check_original(&plan.original_first, 11, 61, 1000);
	CHECK(released.mode == ERGOPTI_PAIR_IDLE);
	step(&repeated, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&repeated, ctx, edge(ERGOPTI_PAIR_REPEAT, 11, 61, 1001));
	CHECK(plan.flush_first && plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
	CHECK(repeated.mode == ERGOPTI_PAIR_HELD_ALONE);
	plan = step(&repeated, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1002));
	CHECK(!plan.flush_first);
	no_selection(&plan);
}

static void test_joined_repeats_and_both_release_orders(void) {
	unsigned reverse;
	ErgoptiPair_Context ctx = context();
	for (reverse = 0; reverse < 2; ++reverse) {
		ErgoptiPair_State state = initialized(false, 100);
		ErgoptiPair_Plan plan;
		step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
		step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001));
		plan = step(&state, ctx, edge(ERGOPTI_PAIR_REPEAT, 11, 61, 1002));
		CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
		no_selection(&plan);
		plan = step(&state, ctx, edge(ERGOPTI_PAIR_REPEAT, 22, 62, 1003));
		CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
		no_selection(&plan);
		plan = step(&state, ctx, edge(ERGOPTI_PAIR_UP, reverse ? 22 : 11, reverse ? 62 : 61, 1004));
		CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
		CHECK(state.mode == ERGOPTI_PAIR_CHORD);
		plan = step(&state, ctx, edge(ERGOPTI_PAIR_UP, reverse ? 11 : 22, reverse ? 61 : 62, 1005));
		CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
		CHECK(state.mode == ERGOPTI_PAIR_IDLE);
		CHECK(!state.first_down && !state.second_down);
		no_selection(&plan);
	}
}

static void test_unproven_origin_never_supplies_pair(void) {
	unsigned origin;
	ErgoptiPair_Context ctx = context();
	for (origin = ERGOPTI_PAIR_ORIGIN_UNKNOWN; origin <= ERGOPTI_PAIR_ORIGIN_INJECTED; ++origin) {
		ErgoptiPair_State first = initialized(false, 100);
		ErgoptiPair_State second = initialized(false, 100);
		ErgoptiPair_Input input = edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000);
		ErgoptiPair_Plan plan;
		if (origin == ERGOPTI_PAIR_ORIGIN_PHYSICAL) continue;
		input.origin = (enum ErgoptiPair_Origin)origin;
		plan = step(&first, ctx, input);
		CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
		CHECK(first.mode == ERGOPTI_PAIR_IDLE);
		no_selection(&plan);
		step(&second, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
		input = edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001);
		input.origin = (enum ErgoptiPair_Origin)origin;
		plan = step(&second, ctx, input);
		CHECK(plan.flush_first);
		CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
		no_selection(&plan);
	}
}

static void test_exact_source_generation_and_press(void) {
	unsigned changed;
	ErgoptiPair_Context ctx = context();
	for (changed = 0; changed < 3; ++changed) {
		ErgoptiPair_State state = initialized(false, 100);
		ErgoptiPair_Input input = edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001);
		ErgoptiPair_Plan plan;
		step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
		if (changed == 0) input.source = 42;
		if (changed == 1) input.generation = 52;
		if (changed == 2) input.press = 0;
		plan = step(&state, ctx, input);
		CHECK(plan.current_route == ERGOPTI_PAIR_PASS_ORIGINAL);
		if (changed == 1) {
			CHECK(!plan.flush_first);
			CHECK(plan.requires_native_retirement && plan.retirement_count == 1);
			CHECK(plan.withdrawal == ERGOPTI_PAIR_WITHDRAW_SOURCE_GENERATION);
			CHECK(state.mode == ERGOPTI_PAIR_RETIRING);
		} else {
			CHECK(plan.flush_first);
		}
		no_selection(&plan);
	}
	{
		ErgoptiPair_State state = initialized(false, 100);
		ErgoptiPair_Plan plan;
		step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
		step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001));
		plan = step(&state, ctx, edge(ERGOPTI_PAIR_UP, 11, 999, 1002));
		CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
		CHECK(plan.requires_native_retirement && plan.retirement_count == 2);
		CHECK(plan.withdrawal == ERGOPTI_PAIR_WITHDRAW_PRESS_IDENTITY);
		CHECK(state.mode == ERGOPTI_PAIR_RETIRING);
		CHECK(state.first_down && state.second_down);
		no_selection(&plan);
	}
}

static void test_context_pause_and_cancel_retirement(void) {
	unsigned changed;
	for (changed = 0; changed < 7; ++changed) {
		ErgoptiPair_Context ctx = context();
		ErgoptiPair_State state = initialized(false, 100);
		ErgoptiPair_Input input = clock_at(1002);
		ErgoptiPair_Plan plan;
		step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
		if (changed == 0) ++ctx.owner_epoch;
		if (changed == 1) ++ctx.policy_revision;
		if (changed == 2) ++ctx.route_epoch;
		if (changed == 3) ctx.current = false;
		if (changed == 4) ctx.enabled = false;
		if (changed == 5) ctx.paused = true;
		if (changed == 6) input.kind = ERGOPTI_PAIR_CANCEL;
		plan = step(&state, ctx, input);
		CHECK(state.mode == ERGOPTI_PAIR_RETIRING);
		CHECK(plan.requires_native_retirement);
		CHECK(plan.retirement_count == 1);
		check_original(&plan.retirement_inputs[0], 11, 61, 1000);
		CHECK(!plan.flush_first);
		no_selection(&plan);
		CHECK(plan.withdrawal == (changed == 6 ? ERGOPTI_PAIR_WITHDRAW_CANCEL : ERGOPTI_PAIR_WITHDRAW_CONTEXT));
		ctx = context();
		plan = step(&state, ctx, edge(ERGOPTI_PAIR_UP, 11, 61, 1010));
		CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
		CHECK(plan.requires_native_retirement && plan.retirement_count == 1);
		CHECK(state.mode == ERGOPTI_PAIR_RETIRING);
		CHECK(state.first_down);
		no_selection(&plan);
	}
}

static void test_chord_retirement_retains_only_live_inputs(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State state = initialized(false, 100);
	ErgoptiPair_Plan plan;
	step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001));
	ctx.paused = true;
	plan = step(&state, ctx, edge(ERGOPTI_PAIR_REPEAT, 22, 62, 1002));
	CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
	CHECK(plan.requires_native_retirement && plan.retirement_count == 2);
	check_original(&plan.retirement_inputs[0], 11, 61, 1000);
	check_original(&plan.retirement_inputs[1], 22, 62, 1001);
	CHECK(!plan.flush_first);
	no_selection(&plan);
	{
		ErgoptiPair_State partial = initialized(false, 100);
		ctx = context();
		step(&partial, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
		step(&partial, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001));
		step(&partial, ctx, edge(ERGOPTI_PAIR_UP, 11, 61, 1002));
		ctx.paused = true;
		plan = step(&partial, ctx, clock_at(1003));
		CHECK(plan.requires_native_retirement && plan.retirement_count == 1);
		check_original(&plan.retirement_inputs[0], 22, 62, 1001);
	}
}

static void test_origin_withdrawal_and_backward_clock(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State state = initialized(false, 100);
	ErgoptiPair_Input input;
	ErgoptiPair_Plan plan;
	step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	input = edge(ERGOPTI_PAIR_UP, 11, 61, 1001);
	input.origin = ERGOPTI_PAIR_ORIGIN_UNKNOWN;
	plan = step(&state, ctx, input);
	CHECK(plan.requires_native_retirement && plan.retirement_count == 1);
	CHECK(plan.current_route == ERGOPTI_PAIR_RETAIN_PROPOSAL);
	CHECK(plan.withdrawal == ERGOPTI_PAIR_WITHDRAW_ORIGIN);
	CHECK(!plan.flush_first);
	state = initialized(false, 100);
	step(&state, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&state, ctx, clock_at(999));
	CHECK(plan.requires_native_retirement && plan.retirement_count == 1);
	CHECK(plan.withdrawal == ERGOPTI_PAIR_WITHDRAW_CLOCK);
	CHECK(!plan.flush_first);
	no_selection(&plan);
}

static void test_integer_fractional_and_overflow_boundaries(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State fraction = initialized(false, 0.5);
	ErgoptiPair_State late = initialized(false, 0.5);
	ErgoptiPair_State overflow = initialized(false, 100);
	ErgoptiPair_Plan plan;
	step(&fraction, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&fraction, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1000));
	CHECK(plan.selected && plan.pair_id == 101);
	step(&late, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000));
	plan = step(&late, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001));
	CHECK(plan.flush_first);
	no_selection(&plan);
	step(&overflow, ctx, edge(ERGOPTI_PAIR_DOWN, 11, 61, UINT64_MAX - 100));
	plan = step(&overflow, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, UINT64_MAX));
	CHECK(plan.selected && plan.pair_id == 101);
}

static void test_policy_copy_and_detached_proposal(void) {
	ErgoptiPair_Context ctx = context();
	ErgoptiPair_State state = ERGOPTI_PAIR_STATE_INIT;
	ErgoptiPair_State next, before;
	ErgoptiPair_Row mutable_rows[3];
	ErgoptiPair_Policy supplied = policy(false, 100);
	ErgoptiPair_Input input = edge(ERGOPTI_PAIR_DOWN, 11, 61, 1000);
	ErgoptiPair_Plan plan;
	memcpy(mutable_rows, rows, sizeof(rows));
	supplied.rows = mutable_rows;
	CHECK(ErgoptiPair_Initialize(&state, &supplied, &ctx) == ERGOPTI_PAIR_OK);
	mutable_rows[0].action_id = 999;
	before = state;
	CHECK(ErgoptiPair_Reduce(&state, &ctx, &input, &next, &plan) == ERGOPTI_PAIR_OK);
	CHECK(memcmp(&before, &state, sizeof(state)) == 0);
	CHECK(state.mode == ERGOPTI_PAIR_IDLE);
	CHECK(next.mode == ERGOPTI_PAIR_WAITING);
	plan = step(&next, ctx, edge(ERGOPTI_PAIR_DOWN, 22, 62, 1001));
	CHECK(plan.selected && plan.action_id == 71);
}

int main(void) {
	test_policy_and_initialization();
	test_inclusive_deadline();
	test_deadline_expiry_and_held_alone();
	test_late_second_without_clock();
	test_symmetric_and_ordered_selection();
	test_none_and_original_order();
	test_release_and_repeat_before_join();
	test_joined_repeats_and_both_release_orders();
	test_unproven_origin_never_supplies_pair();
	test_exact_source_generation_and_press();
	test_context_pause_and_cancel_retirement();
	test_chord_retirement_retains_only_live_inputs();
	test_origin_withdrawal_and_backward_clock();
	test_integer_fractional_and_overflow_boundaries();
	test_policy_copy_and_detached_proposal();
	printf("PASS %u handwritten pure C checks; Windows/native delivery NOT_RUN\n", checks);
	return 0;
}
