# Backup allocation race — UNRUN

ConfigBackup_Create obtains an absent identity from the actual NextId allocator,
then calls FSEnsureDirectoryStrict, which adopts a directory another producer has
created in between. The proposal transparently observes the real allocator's
return, creates a genuine foreign directory/sentinel, then lets the unchanged
public Create continue. It never replaces an ownership decision or copy result.

The positive case uses the genuine path without interception. The race requires
the observer to have completed normally before checking refusal, foreign bytes,
and absence of this transaction's payload/manifest. No production edits or actual
execution yet. This is separate from prohibited updater PublishCopy integrity
work. The production backup owner is in the frozen21 cohort.
