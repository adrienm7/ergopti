"""Independent closed source replay of the frozen public93 V1+V2 proposals."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

repo = Path('/workspace/ergopti')
v1 = Path('/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v1/freeze')
v2 = Path('/workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v2/freeze')
review = Path('/workspace/.ergopti-cloud/reviews/group3-linux93-public-join-v2-independent')
review.mkdir(exist_ok=False)
projection = review / 'projection'
candidate = projection / 'candidate'
source = candidate / 'static/ergopti_plus'
git_source = 'cbb0efd431752da5ec8ccf38029463a76bb4ee55'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipts = []
for packet, wanted in [(v1, '3da5ab41a31cf1176a39552c51fe5fe21a8738a6bfe1b5ff36eddbe858cb684d'),
                       (v2, 'b641ef20792023aafc2c5ece36e1043a90a134b935a5b1a0a3c4592a063ff5d0')]:
    assert sha(packet / 'receipt.json') == wanted
    receipt = json.loads((packet / 'receipt.json').read_text())
    for name, expected in receipt['artifacts'].items():
        assert sha(packet / name) == expected, name
    receipts.append(receipt)
shutil.copytree(v1 / 'dependencies/current-source', candidate)
shutil.copytree(v1 / 'guard-dependencies', candidate, dirs_exist_ok=True)
shutil.copytree(v1 / 'candidate', candidate, dirs_exist_ok=True)
shutil.copytree(v1 / 'generator-context', candidate, dirs_exist_ok=True)
shutil.copytree(v2 / 'candidate', candidate, dirs_exist_ok=True)
shutil.copyfile(v1 / 'dependencies/hook-sibling/caps_word.lua', source / 'linux/adapters/caps_word.lua')
shutil.copytree(v1 / 'generator-context', projection / 'generator-context')

# Close only static Lua imports of the focused subjects, using immutable Git
# objects. Existing pinned bytes always win; native Lua libraries are external.
names = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', git_source,
                                'static/ergopti_plus/linux', 'static/ergopti_plus/_shared/lua'], cwd=repo).decode().splitlines()
names = set(names)
supplements = []
todo = list(source.rglob('*.lua'))
seen = set()
pattern = re.compile(r'\brequire\s*\(?\s*["\']([^"\']+)["\']')
while todo:
    path = todo.pop()
    if path in seen:
        continue
    seen.add(path)
    for module in pattern.findall(path.read_text()):
        relative = module.replace('.', '/')
        locations = [f'static/ergopti_plus/{prefix}/{relative}{tail}'
                     for prefix in ['linux', '_shared/lua'] for tail in ['.lua', '/init.lua']]
        if any((candidate / name).exists() for name in locations):
            continue
        name = next((item for item in locations if item in names), None)
        if name is None:
            continue
        image = subprocess.check_output(['git', 'show', git_source + ':' + name], cwd=repo)
        target = candidate / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(image)
        supplements.append({'path': name, 'sha256': sha(target), 'source': git_source})
        todo.append(target)

shared_contract = 'static/ergopti_plus/_shared/lua/test/key_combination_chords_contract.lua'
target = candidate / shared_contract
target.parent.mkdir(parents=True, exist_ok=True)
if not target.exists():
    target.write_bytes(subprocess.check_output(['git', 'show', git_source + ':' + shared_contract], cwd=repo))
    supplements.append({'path': shared_contract, 'sha256': sha(target), 'source': git_source})
pins = {str(path.relative_to(projection)): sha(path) for path in projection.rglob('*') if path.is_file()}
(review / 'source-pins.json').write_text(json.dumps({'git_source': git_source, 'supplements': supplements, 'projection': pins}, indent=2) + '\n')

runner = '''local packet=assert(arg[1])
local root=packet..'/candidate/static/ergopti_plus'
package.path=root..'/linux/?.lua;'..root..'/linux/?/init.lua;'
 ..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
if arg[3] then
 local directory=arg[3];local searchers=package.searchers or package.loaders
 local prior=searchers[2]
 searchers[2]=function(name)
  local relative=name:gsub('%.','/')..'.lua'
  local file=io.open(directory..'/'..relative,'rb')
  if file then
   local bytes=assert(file:read('*a'));assert(file:close())
   local label='@'..root..'/linux/'..relative
   return assert((loadstring or load)(bytes,label)),label:sub(2)
  end
  return prior(name)
 end
end
require('compat.utf8').install()
local native_loop=require('luv')
if arg[2]=='original-shared-copy' then
 require('test.key_combination_chords_contract').register(require('tests.helpers'))
else require(assert(arg[2])) end
local results=require('tests.helpers').get_results()
assert(require('luv')==native_loop)
print('INDEPENDENT_PUBLIC93 '..results.passed..'/'..results.failed)
os.exit(results.failed>0 and 1 or 0)
'''
(review / 'run.lua').write_text(runner)
shutil.copytree(v2 / 'variants', review / 'variants')
for name in ['old_local_scope', 'old_global_scope', 'copy_wrong_namespace', 'native_receiver_filter_omitted', 'future_pair_filter_omitted']:
    shutil.copytree(v1 / 'variants' / name, review / 'variants' / name)
results = []
environment = dict(os.environ, TMPDIR='/tmp', PYTHONDONTWRITEBYTECODE='1')
def run(abi, case, module, variant=None):
    command = ['/workspace/.ergopti-cloud/bin/' + abi, str(review / 'run.lua'), str(projection), module]
    if variant is not None:
        command.append(str(review / 'variants' / variant))
    process = subprocess.run(command, cwd=source / 'linux', env=environment, capture_output=True, timeout=60)
    log = review / (abi + '-' + case + '.log')
    log.write_bytes(process.stdout + process.stderr)
    summaries = [line for line in process.stdout.decode(errors='replace').splitlines() if line.startswith('INDEPENDENT_PUBLIC93 ')]
    result = {'abi': abi, 'case': case, 'exit': process.returncode, 'summary': summaries[-1:], 'command': command, 'log_sha256': sha(log)}
    results.append(result)
    (review / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(result['abi'], result['case'], result['exit'], result['summary'], flush=True)
    return result
for abi in ['luajit', 'lua5.4']:
    for case, module in [('candidate', 'tests.unit.modules.test_key_combinations'),
                         ('scope', 'tests.unit.infra.test_key_combinations_scope'),
                         ('menu', 'tests.unit.ui.test_key_combinations_menu'),
                         ('global', 'tests.unit.infra.test_global_shortcuts_pair_scope'),
                         ('shared-copy', 'original-shared-copy')]:
        row = run(abi, case, module)
        if row['exit'] != 0 or not row['summary']:
            raise RuntimeError(('candidate or harness failure', row))
    for variant in sorted(path.name for path in (v2 / 'variants').iterdir() if path.is_dir()):
        row = run(abi, variant, 'tests.unit.modules.test_key_combinations', variant)
        assert row['exit'] == 1 and row['summary'], row
    for case, module in [('old_local_scope','tests.unit.infra.test_key_combinations_scope'),
                         ('old_global_scope','tests.unit.infra.test_global_shortcuts_pair_scope'),
                         ('copy_wrong_namespace','tests.unit.infra.test_key_combinations_scope'),
                         ('native_receiver_filter_omitted','tests.unit.infra.test_key_combinations_scope'),
                         ('future_pair_filter_omitted','tests.unit.infra.test_global_shortcuts_pair_scope')]:
        row = run(abi, case, module, case)
        assert row['exit'] == 1 and row['summary'], row
for relative, expected in pins.items():
    assert sha(projection / relative) == expected, relative
for packet, receipt in zip([v1, v2], receipts):
    for relative, expected in receipt['artifacts'].items():
        assert sha(packet / relative) == expected, relative
print('FROZEN_PACKETS_AND_PRIVATE_SOURCE_UNCHANGED', flush=True)
