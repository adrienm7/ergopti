<!-- group3-linux93-public-join-v1/README.md -->

# Inactive Linux simultaneous-pair public join

This private nineteen-path source proposal joins the separately reviewed v1 runtime and v2 cleanup repair to Linux declarations, typed persistence, lazy third-slot menus, copy and both scoped/global clear/restore. It is not canonical adoption, native qualification, or completion of TODO93. The collector changed no canonical source, index, ref, workflow or public availability.

The preimages are exact `cbb0efd431752da5ec8ccf38029463a76bb4ee55` Git objects. The manifest and menu builder were cleanly composed with incoming G1 Source44; the other old preimages match. Issue86 coordination: 6078926846, 6079074544, 6079308484; G1 no-overlap acknowledgement 6079363253. Parent must reconcile current G5/G6 source ownership and current preimages before any adoption.

Linux alone declares 100ms and false once through Features. Every third slot defaults/recommends None. Save/copy preserve switches, unknown records and personal data. Global recommended retains its existing category-preset behavior; the distinct `mod_combos.enabled=false` remains unchanged. Copy reads fresh canonical Linux tap leaves through an explicit shared-policy section and exact parameter/source/delivery leases. No Save marker, caller boolean or declaration alone can issue native input ownership. Unavailable predecessor fixtures explicitly lack the new declaration; the positive cohorts use the real privately generated Features owner.

Third-slot OneShotShift, CapsWord, run_program and alt_tab_monitor are not offered by the actual picker/slot validator. Ordered slots and existing Manager program/window denials remain unchanged. The last two actions require a software binding-domain join: Manager still reads ordered `key_combination_taps` for their original source/start receipts. No receiving fallback or generic execution authority was added.

Controlled results on each Lua ABI: runtime 199/0, local scope/actual menu 81/0, existing locale/menu 8/0, global scope 27/0, original shared/Mac copy contract 13/0. The old source owner/local/global scope produce 194/5, 64/17, 25/2. Wrong copy namespace, omitted native receiving filter and omitted future-pair filter produce 79/2, 78/3, 25/2. The source guard is old RED/new PASS; all fourteen added source-boundary counterfactuals are RED. Existing assertions/callback bodies and v2 prefix are preserved; these are software/controlled-port observations, not physical input or GUI credit.

Required canonical regeneration by the parent after source reconciliation:

```sh
npm run build:manifest
npm run build:menu
npm run gen:diagram
```

The first two original generators were executed only in the tiny private generator context. Their seven generated outputs are reference/dependency data, excluded from the nineteen-path patch. `generation.json` pins inputs and lists exact output paths/preimages. No action catalogue, layout or schema generator is required: the scoped JSON schema is authoritative handwritten source; features/templates/menu/architecture remain generator-owned. Parent must retain incoming cbb/G6 outputs and regenerate, never copy these snapshots.

Verify the frozen files and source patch:

```sh
cd /workspace/.ergopti-cloud/preparations/group3-linux93-public-join-v1/freeze
sha256sum -c files.sha256
python verify_packet.py
```

`verify_packet.py` checks byte pins, safe archive members, Git-object preimages and patch roundtrip in its own temporary tree. It does not apply anything to canonical. The registered existing Linux modules are listed in `registration.json`; no new test-manifest edit is needed for the support helper.

Still required: independent source review, full registered suites, style/schema/generated parity, native same-device Reader→Hook→output receiving proof and genuine pause/reload/hotplug/retirement qualification. Cross-device chords and native state third-slot actions remain separate software joins. Public simultaneous enablement, native kernel tests and UI/Save/device qualification are UNRUN. Windows/macOS behavior is not expanded by this proposal.
