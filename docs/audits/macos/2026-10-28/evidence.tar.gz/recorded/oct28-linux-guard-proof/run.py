from pathlib import Path
import os,subprocess,json
s=Path('/workspace/scratch/oct28-linux-guard-proof');rows=[];env=os.environ.copy();env['LUA_CPATH']='/workspace/toolchain/luajit-native/install/lib/lua/5.1/?.so;;';env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib'
for mode in ['clean','stale']:
 for version in ['before','after']:
  p=subprocess.run(['/workspace/toolchain/luajit-native/install/bin/luajit',str(s/'probe.lua'),mode,version],cwd=s/'drivers/linux',env=env,capture_output=True,text=True)
  (s/(mode+'-'+version+'.log')).write_text(p.stdout+p.stderr);rows.append(dict(mode=mode,version=version,status=p.returncode,output=p.stdout,stderr=p.stderr));print(mode,version,p.returncode,(p.stdout+p.stderr)[-500:])
(s/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
