"""Future serial physical156 receiver; never a native Darwin clock claim."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

BASE=Path(__file__).resolve().parent
facts=json.loads((BASE/'runtime-source-inventory.json').read_text())['files']
for rel,pin in facts.items():
    source=BASE/'runtime-source'/rel
    assert source.stat().st_size==pin['bytes']
    assert hashlib.sha256(source.read_bytes()).hexdigest()==pin['sha256']
subprocess.run([sys.executable,'-I','-B',str(BASE/'verify_inverse.py')],check=True)
work=Path(tempfile.mkdtemp(prefix='future-clock156-',dir=BASE))
root=work/'source'
shutil.copytree(BASE/'runtime-source',root)
private=work/'private-tmp';private.mkdir(mode=0o700)
environment=os.environ.copy();environment['TMPDIR']=str(private)
script=root/'tools/test/macos_native_http_receiving_facts_test.py'
with (work/'physical156.stdout').open('wb') as out,(work/'physical156.stderr').open('wb') as err:
    result=subprocess.run([sys.executable,'-I','-B',str(script)],cwd=root,env=environment,stdout=out,stderr=err)
raw=(work/'physical156.stderr').read_text()
received={'qualification':'PORTABLE_SOFTWARE_ONLY_NATIVE_MODELED_NO_DARWIN_CREDIT','entrypoint':'physical original unittest.main alphabetical discovery','exit':result.returncode,'raw_stdout_sha256':hashlib.sha256((work/'physical156.stdout').read_bytes()).hexdigest(),'raw_stderr_sha256':hashlib.sha256((work/'physical156.stderr').read_bytes()).hexdigest()}
(work/'receipt.json').write_text(json.dumps(received,indent=2)+'\n')
assert result.returncode==0,(result.returncode,str(work))
assert 'Ran 156 tests' in raw and '\nOK\n' in raw,str(work)
print(json.dumps({'logs':str(work),'tests':156,'failures':0,'errors':0,'skips':0,'qualification':received['qualification']},sort_keys=True))
