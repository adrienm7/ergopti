"""Independent real idle-loop retirement boundary; no compiler/native models."""
from pathlib import Path
import importlib.util,json,sys,time,threading,unittest
from unittest import mock
source=Path(sys.argv[1]);receipt=Path(sys.argv[2]);sys.argv=[sys.argv[0],'-v']
spec=importlib.util.spec_from_file_location('idle_poll_real_wire',source/'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py');wire=importlib.util.module_from_spec(spec);spec.loader.exec_module(wire)
FACT={}
class IdleRetirementControl(unittest.TestCase):
 def test_idle_six_real_serving_loops_close_within_short_original_ownership_window(self):
  selected=[];entered=threading.Event();lock=threading.Lock();selector=wire.socketserver._ServerSelector;original=selector.select
  def observed(instance,timeout=None):
   with lock:
    selected.append(timeout)
    if len(selected)>=6:entered.set()
   return original(instance,timeout)
  fixture=None
  try:
   with mock.patch.object(selector,'select',observed):
    fixture=wire.WireFixture(native=False)
    self.assertTrue(entered.wait(3),'all six actual serving selectors must enter')
    start=time.monotonic();fixture.close();elapsed=time.monotonic()-start
   FACT.update(close_seconds=elapsed,first_six_actual_selector_timeouts=selected[:6],serving_workers=len(fixture.server_threads),shutdown_workers=len(fixture.server_shutdowns),fixture_closed=fixture.closed,root_exists=fixture.root.exists(),all_serving_workers_closed=all(not t.is_alive() for _,t in fixture.server_threads),all_shutdown_workers_closed=all(not s['worker'].is_alive() for s in fixture.server_shutdowns),all_server_sockets_closed=all(s.socket.fileno()==-1 for s in fixture.servers),command_file_debt=len(fixture.command_file_debt),command_group_debt=len(fixture.command_group_debt),qualification='actual portable POSIX/TLS/selectors/public shutdown; not Darwin/native')
   self.assertEqual(FACT['serving_workers'],6);self.assertEqual(FACT['shutdown_workers'],6)
   self.assertTrue(FACT['fixture_closed']);self.assertFalse(FACT['root_exists']);self.assertTrue(FACT['all_serving_workers_closed']);self.assertTrue(FACT['all_shutdown_workers_closed']);self.assertTrue(FACT['all_server_sockets_closed']);self.assertEqual(FACT['command_file_debt'],0);self.assertEqual(FACT['command_group_debt'],0)
   # An independently authored receiving deadline detects idle poll delay. This
   # is only the outside diagnostic control, not a new production/CI deadline.
   self.assertLess(elapsed,0.30,'idle serving-loop polling consumes the retirement window')
  finally:
   if fixture is not None and not fixture.closed:fixture.close()
   receipt.write_text(json.dumps(FACT,indent=2)+'\n')
unittest.main()
