from pathlib import Path
import hashlib,json,tarfile
B=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-current-g1-union-independent');P=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-g1-published-union/freeze');h=lambda b:hashlib.sha256(b).hexdigest()
text='''# Independent review of the current G1 / Linux93 source union

Verdict: **SOURCE_CLEAR_PRIVATE_CURRENT_G1_SOURCE_UNION**. The23-path source patch is applicable only to the exact published `1028f6bd3eeb08a1aa50f96d1ad9738d2826d7bb` preimages (22 existing files, one new fixture). No canonical adoption, native enablement, full current-union suite or physical qualification is claimed here.

## Source preservation

All406 author seals,45 safe regular archive members and23 actual Git preimages verify independently. The actual G1 feature is `cbe96086b90ec8085895a505c0ee5a7975089dc3`; `96297a0d6b605a67eac2b48023f825b1e1572a0d` contains the already merged Root handover above that feature;1028 integrates it. These frames are distinguished explicitly.

The two overlaps are limited to six contextual blocks in manifest.toml and one prompt_delay block in Linux menu_builder.lua. Peeling those seven blocks reconstructs both complete original G1 images byte-exact against cbe/962/1028. Every other21 source postimage is byte-exact to the qualified V3 tree `f5ca71ad756a945cf4781222c1ccf636339d2aeb`. No old test bodies, source admission fences, master-state policies, typed defaults or third-slot refusals are changed by this union.

Of the31 paths in the G1 feature,27 other runtime/source images are exact to cbe, one current TODO image is exact to its legitimately merged962/1028 bytes, two source overlaps are recovered by the exact peel, and one generated shared menu is assessed through the original generator. The patch does not touch documentation. The TODO was already different from cbe before this union; it is not falsely described as byte-exact to the earlier feature commit.

The original owner commands `npm run build:manifest` and `npm run build:menu` were independently run in both private complete generator contexts. All14 generated outputs reproduce their frozen hashes. The generated G1 baseline menu equals the committed1028 bytes, while the composed menu structurally changes only `key_combinations_group`. Every other menu group and original G1 generator implementation stays exact. Generated snapshots remain private references; parent/owners must regenerate on their final sources. Four private forward/inverse patch checks and applications preserve all23 source pairs exactly.

## Independent bounded executions

Both actual LuaJIT and Lua5.4 execute the genuine original G1 AI-parent22/0, original hotstring language-frame5/0, and original Group3 menu/21-locales8/0 cohorts. The real composed builder calls the original pair provider and supplies its actual delay callback; a controlled text-prompt port observes current150, declared100 and unchanged cancellation=nil. This is a functional assertion probe, not an empty0/0 unit-suite success. The exact peeled G1 builder fails that same probe on the missing callback on both ABIs.

Seven complete unchanged G1/G3 Node guards pass: category submenu order, unavailable menu rows, menu category coverage, original catalogue/source owner, first menu group, restrictions explanation, and Linux software parity. The entirely peeled manifest is legitimately GREEN for the conditional catalogue guard: removing the Linux declaration removes its guarded simultaneous branch. That inverse is explicitly noncausal, not a supposed RED proof. The original current candidate guard is re-executed to preserve separate input pins from that conditional observation.

One initial reviewer sparse-graph run lacked the genuine original `tests.support.llm_preferences_fixture` and exited during imports before executing product cases. Its raw log/result are retained. Pinning all required original G1 dependency bytes from actual Git1028 produced the terminal passes above, with no stub substitution or assertion changes. Author history also retains its initial locale-context7/1, repaired by completing the original graph, and its initial incorrect expected RED for the conditional whole-manifest peel. No source image was changed to obtain those contextual corrections.

Author-only observations retained separately: the unchanged complete G3 targeted cohorts37/216/81/27/8 each pass on both ABIs; the genuine regenerated original-G1-defaults counterfactual is199/17 on each ABI. Those executions were not duplicated as new scenarios by this reviewer. The21 source postimages are already exact to the earlier qualified V3 tree.

## Authority and remaining qualification

Custody is the narrow released G1 source scope recorded at6082330742; no ownership of new shared regions, workflows or generators is inferred. The406 author seals and89 prior independent V3 seals remain exact after replay. All writes were private; canonical/index/refs/CI and Root's shared projection were untouched by this reviewer.

The previous Root terminal receipt202773/f5ca records404 JS,17783 HS,12567 Linux and189 Linux E2E successes, virtual E2E101 passed/1 skipped, with AHK native skipped on Linux and kernel/physical unrun. That receipt qualifies the previous V3 sources only. Root must run the current combined source qualification after adoption/regeneration and any native CI required for the final changes. These controlled Lua/UI-port/Node observations do not prove actual uinput, Xorg/Wayland, GUI, packaging or installation behavior. All13 Group3 TODOs remain partial;16/38 stay;22 remains withdrawn.
'''
(B/'REPORT.md').write_text(text)
v={'verdict':'SOURCE_CLEAR_PRIVATE_CURRENT_G1_SOURCE_UNION','preimage':'1028f6bd3eeb08a1aa50f96d1ad9738d2826d7bb','author_receipt_sha256':h((P/'receipt.json').read_bytes()),'author_patch_sha256':h((P/'candidate.patch').read_bytes()),'author_seal_sha256':h((P/'files.sha256').read_bytes()),'independent_controls_both_abis':{'G1_AI':'22/0','G1_hotstrings':'5/0','G3_menu21locales':'8/0','actual_builder_callback':'PASS functional assertion probe','G1_builder_peeled':'RED expected'},'original_Node_guards':'7 PASS +1 final candidate pin replay PASS','whole_manifest_peel':'GREEN explicitly noncausal conditional guard','generation':'four original npm commands PASS;14 exact output hashes; committed G1 menu exact; only key_combinations_group changes','source':'23 actual Git1028 preimages,21 previous V3 images unchanged, complete2 G1 images peeled exact,27 other G1 sources exact, merged current TODO untouched','canonical_adoption':False,'full_current_union_gate':'UNRUN reviewer; Root next','native':'UNRUN','physical':'UNRUN','reviewer_harness_failure':'initial missing genuine G1 fixture import, retained; recovered with pinned original graph','author_and_prior_seals_unchanged':[406,89],'report_sha256':h((B/'REPORT.md').read_bytes())}
(B/'verdict.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['candidate.patch','source-pair.tar','composition.json','custody.json']:(B/name).write_bytes((P/name).read_bytes())
(B/'prior-v3-terminal-summary.json').write_bytes(Path('/workspace/.ergopti-cloud/continuation-2026-10-09/linux93-v3-terminal-summary.json').read_bytes())
R=B/'review-scripts'
for name in ['review-linux93-current-g1-union.py','continue-linux93-current-g1-union.py','freeze-linux93-current-g1-union.py']:(R/name).write_bytes((B.parent/name).read_bytes())
files=[]
for p in B.rglob('*'):
 if not p.is_file() or p.is_symlink() or p.name in ['MANIFEST.json','SHA256SUMS','source-review-capsule.tar.gz','capsule-receipt.json']:continue
 rel=p.relative_to(B)
 if rel.parts[0] in ['projection','owner-generation','roundtrip']:continue
 files.append(p)
files.sort(key=lambda p:str(p.relative_to(B)))
manifest={'kind':'PRIVATE_INACTIVE_CURRENT_G1_SOURCE_UNION_REVIEW','files':[{'path':str(p.relative_to(B)),'sha256':h(p.read_bytes()),'bytes':p.stat().st_size} for p in files]};(B/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(B/'MANIFEST.json')
(B/'SHA256SUMS').write_text(''.join(h(p.read_bytes())+'  '+str(p.relative_to(B))+'\n' for p in files));files.append(B/'SHA256SUMS')
archive=B/'source-review-capsule.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(B)),recursive=False)
with tarfile.open(archive) as t:
 ms=t.getmembers();assert len(ms)==len(files) and len({m.name for m in ms})==len(files)
 for m in ms:assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts and t.extractfile(m).read()==(B/m.name).read_bytes()
receipt={'report_sha256':h((B/'REPORT.md').read_bytes()),'verdict_sha256':h((B/'verdict.json').read_bytes()),'seal_sha256':h((B/'SHA256SUMS').read_bytes()),'sealed_files':len(files)-1,'manifest_sha256':h((B/'MANIFEST.json').read_bytes()),'archive_sha256':h(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'safe_members':len(files)};(B/'capsule-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
