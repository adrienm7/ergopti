# Fresh official native network receiving

Manual38129586139 tests exact5f7a8467c9696b26a75de104f6329b39c181b8cb
on codex/ci-validation. Both native jobs are terminal failure. This assessment
downloads official read-only API receipts and runs no suite or native target.

ARM artifact11698906648 and Intel artifact11698753162 match the API's SHA256
and byte count. ZIP CRC, unique relative members, no traversal or symlinks and
bounded extracted size are verified. Both SourcePAC10 cohorts actually pass;
all402 recorded input digests match the exact tested Git tree. Those source
receipts name their narrower source-PAC scope. They do not create a separate
before/after PAC14 source receipt; official artifact/job SHA provenance and the
same tested checkout establish the retained PAC14 context.

Both PAC14 cohorts execute12 passing methods and two failed methods, without
skips. Their original verdict retains14 failures including two unexpected
failures, Swift exit1 and capture exit0. Both fail the same two methods:

- WPAD: its own add command completes with status0. Both positive requests reach
  system trust and retain URL/CFNetwork-1202, stream SSL domain3/code-9813.
  No response headers/body or origin success follows. Its original trust-removal
  command reaches its deadline and restoration remains refused. The exact owned
  CA's admin visibility is unobserved in this fixture.
- Wire: its certificate diagnostic precedes trust-add and belongs to the
  deliberately untrusted negative request. It proves no positive-request
  certificate defect. Its subsequent original add command reaches its deadline;
  restoration remove exits1. The positive routes are unreached.

The two independent HTTP methods reach their original add-command deadline.
Their separate fixture's later exact-CA lookup reports owned_status-25300 and
owned_present0, with one admin entry. Noninteractive admin authorization reports
status0. Removal exits1 and its fixture reports trust_unsettled1. These facts
cannot establish WPAD's different owned CA visibility, the native timeout's
OS/permission cause, or successful restoration. Model setup separately reaches
trust-add deadline; successful model stages remain unestablished by this log.

The existing reviewed post-install proposal alone observes none of those
currently failed positive outcomes: HTTP/Wire do not receive add success, and
WPAD has no admitted query callee. Receive the original timed add child's already
owned settled output and fixed process milestones next, under exact custody and
privacy/closure controls. Root5580 contains a distinct source-only candidate for
those observations. Separately enroll a genuinely source-bound same-WPAD-fixture
query callee before using the post-install proposal to diagnose its anchor
visibility; no available sibling HTTP binary can be assumed at that earlier
XCTest stage. Do not infer a fix through keychain replacement, extra anchors,
trustd restart, TLS bypass, removal waiver or longer deadlines.

`group6-network-fresh-receipt.json` binds jobs, API archives, logs, exact source
digests and method-scoped closed facts. `group6-network-fresh-receipt.py` replays
that read-only assessment. Existing original assertions, restoration debt,
TODO36/62 and transversal16/38 remain open. No patch is adopted and no release,
model, packaging/install, enterprise device or whole-CI qualification is claimed.
