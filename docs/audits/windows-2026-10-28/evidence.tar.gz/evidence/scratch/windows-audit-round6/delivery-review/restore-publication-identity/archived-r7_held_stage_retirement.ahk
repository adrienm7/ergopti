; Actual protected-close refusal retains the exact owned stage until native ACK.
_R7HR_NativeRetirement() {
	Root := A_Temp . "\ergopti_r7_stage_retire_" . PLC_CurrentProcessId() . "_" . A_TickCount
	Stage := Root . "\owned.tmp", Handle := -1, Retry := -1
	try {
		DirCreate(Root)
		Handle := DllCall("kernel32\CreateFileW", "Str", Stage, "UInt", 0xC0010000,
			"UInt", 0, "Ptr", 0, "UInt", 1, "UInt", 0x80, "Ptr", 0, "Ptr")
		AssertTrue(Handle != -1)
		Before := FSHandleSnapshot(Handle)
		AssertTrue(Before["ok"])
		AssertTrue(DllCall("kernel32\SetHandleInformation", "Ptr", Handle, "UInt", 2, "UInt", 2, "Int"),
			"the fixture must protect only its exact owned native handle")
		Disposition := Buffer(1, 1)
		AssertTrue(DllCall("kernel32\SetFileInformationByHandle", "Ptr", Handle, "Int", 4,
			"Ptr", Disposition, "UInt", 1, "Int"), "DELETE access must retire the exact unpublished object without pathname cleanup")
		Closed := DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int")
		CloseError := A_LastError
		if Closed {
			Handle := -1
			throw Error("the protected native close must really refuse")
		}
		AssertTrue(CloseError != 0)
		Flags := 0
		AssertTrue(DllCall("kernel32\GetHandleInformation", "Ptr", Handle, "UInt*", &Flags, "Int"))
		AssertTrue((Flags & 2) != 0, "the exact refused capability must remain protected and live")
		After := FSHandleSnapshot(Handle)
		AssertTrue(After["ok"])
		for Key in ["volume", "index_high", "index_low"]
			AssertEqual(Before[Key], After[Key], "refusal must retain exact native " . Key)
		Retry := DllCall("kernel32\CreateFileW", "Str", Stage, "UInt", 0xC0010000,
			"UInt", 0, "Ptr", 0, "UInt", 1, "UInt", 0x80, "Ptr", 0, "Ptr")
		RetryError := A_LastError
		if Retry != -1 {
			DllCall("kernel32\CloseHandle", "Ptr", Retry, "Int")
			Retry := -1
			throw Error("a delete-pending stage cannot be reacquired before physical close")
		}
		AssertTrue(RetryError != 0)
		_TestPrint("# held-stage-retirement close_error=" . CloseError . " flags=" . Flags . " pending_create_error=" . RetryError
			. " volume=" . After["volume"] . " id_high=" . After["index_high"] . " id_low=" . After["index_low"])
		AssertTrue(DllCall("kernel32\SetHandleInformation", "Ptr", Handle, "UInt", 2, "UInt", 0, "Int"))
		AssertTrue(DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int"))
		Handle := -1
		AssertFalse(FileExist(Stage), "the acknowledged exact close must complete the owned disposition")
		Retry := DllCall("kernel32\CreateFileW", "Str", Stage, "UInt", 0xC0010000,
			"UInt", 0, "Ptr", 0, "UInt", 1, "UInt", 0x80, "Ptr", 0, "Ptr")
		AssertTrue(Retry != -1, "the same real CREATE_NEW must succeed after exact retirement ACK")
	} finally {
		if Handle != -1 {
			DllCall("kernel32\SetHandleInformation", "Ptr", Handle, "UInt", 2, "UInt", 0, "Int")
			DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int")
		}
		if Retry != -1
			DllCall("kernel32\CloseHandle", "Ptr", Retry, "Int")
		if DirExist(Root)
			DirDelete(Root, true)
	}
}
Test("Config restore design: exact owned disposition survives real protected close refusal then retry (held-stage-retirement-native)", _R7HR_NativeRetirement)
