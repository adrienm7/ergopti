from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess,time
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-merge11-final-linux');R=Path('/workspace/ergopti-macos-release-linux')
def at():return datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()
GO=json.loads((O/'go.json').read_text());assert GO['authorized_by_parent'] is True
MAN=json.loads(Path('/workspace/scratch/oct28-bsd-writer-assembly/manifest-go.json').read_text())
ENV=os.environ.copy();ENV['PATH']=MAN['toolchain']['path_prefix']+':'+ENV.get('PATH','');ENV['LD_LIBRARY_PATH']=MAN['toolchain']['ld_library_path']+':'+ENV.get('LD_LIBRARY_PATH','');ENV['USER']=ENV['LOGNAME']='agent'
for key,name in [('TMPDIR','tmpdir'),('XDG_CACHE_HOME','xdg_cache_home'),('XDG_CONFIG_HOME','xdg_config_home'),('XDG_DATA_HOME','xdg_data_home'),('XDG_STATE_HOME','xdg_state_home'),('XDG_RUNTIME_DIR','xdg_runtime_dir')]:
 p=O/name;p.mkdir(exist_ok=True,mode=0o700);ENV[key]=str(p)
assert os.getuid()!=0
ROWS=[];snapshots=[]
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def physical(label):
 entries=git('ls-files','--stage','-z');digest=hashlib.sha256(entries).hexdigest();bad=[];count=total=0
 for row in entries.split(b'\0'):
  if not row:continue
  meta,rel=row.split(b'\t',1);mode,oid,stage=meta.split();assert stage==b'0';p=R/os.fsdecode(rel);st=p.lstat();data=os.fsencode(os.readlink(p)) if stat.S_ISLNK(st.st_mode) else p.read_bytes()
  observed=b'120000' if stat.S_ISLNK(st.st_mode) else b'100755' if st.st_mode&0o111 else b'100644';actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()
  if observed!=mode or actual!=oid:bad.append(os.fsdecode(rel))
  count+=1;total+=len(data)
 obj={'at_paris':at(),'label':label,'commit':git('rev-parse','HEAD').decode().strip(),'index_tree':git('write-tree').decode().strip(),'stage_digest':digest,'entries':count,'bytes':total,'mismatches':bad,'unstaged':git('diff','--name-only').decode(),'untracked':git('ls-files','--others','--exclude-standard').decode()}
 (O/('physical-'+label+'.json')).write_text(json.dumps(obj,indent=2)+'\n');snapshots.append(obj)
 assert obj['commit']==GO['commit'] and obj['index_tree']==GO['tree'] and not bad and not obj['unstaged'] and not obj['untracked'],obj
 if len(snapshots)>1:assert obj['stage_digest']==snapshots[0]['stage_digest']
 return obj
initial=physical('initial')
def publish(state):
 (O/'receipt.json').write_text(json.dumps({'state':state,'source':GO,'producer_pid':os.getpid(),'started_paris':START,'gates':ROWS,'physical_initial':initial,'physical_latest':snapshots[-1],'snapshots':snapshots,'native_darwin_executed':False},indent=2)+'\n')
def run(name,command,cwd=R):
 physical(name+'-before');start=time.monotonic();started=at()
 with(O/(name+'.log')).open('wb') as out:
  p=subprocess.Popen(command,cwd=cwd,env=ENV,stdout=out,stderr=subprocess.STDOUT);(O/'active.json').write_text(json.dumps({'name':name,'pid':p.pid,'command':command,'started_paris':started})+'\n');code=p.wait()
 row={'name':name,'command':command,'cwd':str(cwd),'actual_exit':code,'seconds':round(time.monotonic()-start,3),'started_paris':started,'finished_paris':at(),'log':str(O/(name+'.log'))};ROWS.append(row);physical(name+'-after');publish('RUNNING');print(name,code,flush=True);return code
START=at();publish('RUNNING')
for gate in MAN['toolchain']['preflight']:assert run(gate['name'],gate['command'])==0
code="package.path='./?.lua;./?/init.lua;../_shared/lua/?.lua;../_shared/lua/?/init.lua;'..package.path;local g=require('tests.support.module_groups');local m=require('tests.test_manifest');local j=require('json');local out={modules=m,groups={}};for _,x in ipairs(g.GROUPS) do out.groups[#out.groups+1]={name=x.name,modules=g.select(m,x.name)} end;print(j.encode(out))"
assert run('linux-groups-inventory',['luajit','-e',code],R/'static/ergopti_plus/linux')==0
inventory=json.loads((O/'linux-groups-inventory.log').read_text());names=[g['name'] for g in inventory['groups']];assert names==['integration','meta','core','infra','input','modules','ui'];assert len(inventory['modules'])>0
seen=[]
for group in inventory['groups']:assert group['modules'];seen+=group['modules']
assert len(seen)==len(set(seen)) and set(seen)==set(inventory['modules'])
for name in names:run('linux-'+name,['npm','run','-s','test:linux','--','--module='+name])
run('linux-e2e',['npm','run','-s','test:linux:e2e'])
physical('final');publish('COMPLETE');(O/'active.json').unlink();raise SystemExit(0 if all(x['actual_exit']==0 for x in ROWS)else 1)
