-- UNEXECUTED actual installed luv/native helper clock-domain qualification.
-- Explicit artifact path is a test input, not production loader fallback.
local ffi, uv = require("ffi"), require("luv")
assert(ffi.os == "Linux" and type(uv.hrtime) == "function")
local library_path = assert(arg[1], "actual generated native helper required")
assert(library_path:sub(1, 1) == "/" and not library_path:find("\0", 1, true))
ffi.cdef([[unsigned int ergopti_archive_publication_abi_version(void);
double ergopti_archive_publication_clock_ms(void);]])
local native = ffi.load(library_path)
assert(native.ergopti_archive_publication_abi_version() == 1)
local clock = native.ergopti_archive_publication_clock_ms
for _ = 1, 256 do
	local before = uv.hrtime() / 1e6
	local actual = clock()
	local after = uv.hrtime() / 1e6
	assert(actual >= before and actual <= after,
		"actual Linux precise clocks must share the original monotonic domain")
end
print("256 actual native clock brackets completed; no calibration or deadline restart")
