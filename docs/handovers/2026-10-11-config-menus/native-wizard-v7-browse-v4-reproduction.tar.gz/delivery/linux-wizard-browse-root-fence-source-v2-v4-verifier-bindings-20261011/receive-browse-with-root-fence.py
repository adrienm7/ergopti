"""Root-only fixed genuine Browse receiving with the reviewed full Source fence."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/ergopti')
DELIVERY = Path('/workspace/ergopti-delivery/group1-complete-resume-20261007')
PACKET = DELIVERY / 'linux-wizard-genuine-browse-adapter-source-v4-sqv-verifier-20261011'
V7 = DELIVERY / 'linux-wizard-real-webkit-private-harness-source-only-v7-metadata-20261011'
PROPOSAL_SHA = '3eaa2eac6a79a648b76e2f9b01d94b617bf923341323e351b1856fb41a77f598'
FREEZE_SHA = '25fd99051b4363dd95e214cbfe6ac8f799e29b6318f3a24bf2b121b765206e80'
V7_PROPOSAL_SHA = '36aa743baa913455d34f83c5de712aa18eaec0c76e025ff1510c4189c8d501f2'
REVIEW = DELIVERY / 'linux-wizard-genuine-browse-v4-verifier-independent-source-review-20261011/INDEPENDENT-SOURCE-REVIEW.json'
REVIEW_SHA = '0c243cef7a8b57bd66be4b120c24151f80761d2cecfc93c1de26edaf06cd1f5d'
HELPERS = {
    '/workspace/tooling/run-with-reaper.py': '3106bf9b753d7663e2dafcee2eec1421ed5a62a10e06b48e146c76ba41ee088d',
    '/workspace/tooling/run-with-gtk-namespace.py': '3f61f31c24810daf8a5036d3ab9af405691d1bb9e5a5f1511ac15b098b966ece',
    '/workspace/tooling/gtk-overlay-current.json': '5031605b50c8931505eec596c2e9f135b8f5d2e57d8facd052fd6386cd94c2d1',
    '/workspace/tooling/gtk-overlay-58omgo_e/launch.sh': '9d978cef88233d4be68cb30e19247e7857eb4d03db4882ea837537fbebe79396',
    '/workspace/tooling/gtk-overlay-58omgo_e/manifest.json': 'c91c65935b1410515f26909d05a1be32d0aa67104c5001b1cb4193f407419d01',
}
if sys.flags.optimize:
    raise RuntimeError('Optimized Python cannot enforce custody guards')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--qualification', type=Path, required=True)
parser.add_argument('--qualification-sha', required=True)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--v7-root-receipt', type=Path, required=True)
parser.add_argument('--v7-root-receipt-sha', required=True)
parser.add_argument('--receipt', type=Path, required=True)
parser.add_argument('--execute', action='store_true')
args = parser.parse_args()
if not args.execute:
    print('SOURCE ONLY: no native process, namespace, Source/index/ref mutation or installation.')
    raise SystemExit(0)
env = os.environ.copy()
env.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*parts):
    return subprocess.check_output(['git', *parts], cwd=ROOT, env=env)

def read_json(path):
    return json.loads(path.read_text())

assert re.fullmatch('[0-9a-f]{40}', args.expected_head)
for value in (args.qualification_sha, args.v7_root_receipt_sha):
    assert re.fullmatch('[0-9a-f]{64}', value)
qualification = args.qualification.resolve(strict=True)
assert qualification.is_relative_to(DELIVERY) and sha(qualification) == args.qualification_sha
q = read_json(qualification)
assert q['exit_code'] == 0
assert all(q[key] is True for key in ('inputs_unchanged', 'index_unchanged', 'head_unchanged'))
assert sha(qualification.with_suffix('.log')) == q['log_sha256']
head = git('rev-parse', 'HEAD').decode().strip()
assert head == args.expected_head
assert re.fullmatch('[0-9a-f]{40}', q['head'])
assert git('show', '-s', '--format=%P', head).decode().split() == [q['head']]
assert isinstance(q['source_pins'], dict) and q['source_pins']
for name, expected in q['source_pins'].items():
    path = ROOT / name
    assert not Path(name).is_absolute() and path.resolve().is_relative_to(ROOT)
    assert path.is_file() and sha(path) == expected, name
diff = git('diff-tree', '--no-commit-id', '--name-status', '-r', '-z', '--no-renames', q['head'], head, '--')
assert diff, 'A genuine ordinary title commit is required'
assert diff.endswith(b'\0')
fields = diff[:-1].split(b'\0')
assert len(fields) % 2 == 0
for index in range(0, len(fields), 2):
    assert fields[index] in (b'A', b'M')
    assert fields[index + 1].decode() in q['source_pins']
assert not git('status', '--porcelain')
assert git('branch', '--show-current').decode().strip() == 'feat/config-menus'
assert git('rev-parse', 'refs/remotes/origin/feat/config-menus').decode().strip() == head
assert git('ls-remote', '--exit-code', '--heads', 'origin', 'refs/heads/feat/config-menus').decode().splitlines() == [head + '\trefs/heads/feat/config-menus']

assert sha(PACKET / 'SOURCE-PROPOSAL.json') == PROPOSAL_SHA
assert sha(PACKET / 'FREEZE.json') == FREEZE_SHA and sha(REVIEW) == REVIEW_SHA
review = read_json(REVIEW)
assert review['status'] == 'PASS_FINITE_VERIFIER_SOURCE_ONLY_RUNTIME_UNRUN'
assert review['freeze_sha256'] == FREEZE_SHA and review['proposal_sha256'] == PROPOSAL_SHA
proposal = read_json(PACKET / 'SOURCE-PROPOSAL.json')
inputs = {str(PACKET / name): value['sha256'] for name, value in proposal['files'].items()}
inputs.update(HELPERS)
inputs.update({str(PACKET / 'SOURCE-PROPOSAL.json'): PROPOSAL_SHA,
               str(PACKET / 'FREEZE.json'): FREEZE_SHA, str(REVIEW): REVIEW_SHA,
               str(qualification): args.qualification_sha, str(qualification.with_suffix('.log')): q['log_sha256']})
assert sha(V7 / 'SOURCE-PROPOSAL.json') == V7_PROPOSAL_SHA
v7_proposal = read_json(V7 / 'SOURCE-PROPOSAL.json')
inputs.update({str(V7 / name): value['sha256'] for name, value in v7_proposal['files'].items()})
inputs[str(V7 / 'SOURCE-PROPOSAL.json')] = V7_PROPOSAL_SHA
for name, expected in read_json(PACKET / 'V7-UNCHANGED-PINS.json').items():
    inputs[str(V7 / name)] = expected
dependencies = read_json(PACKET / 'DEPENDENCIES.json')
inputs.update(dependencies['unmodified_environment_pins'])
prefix = Path(dependencies['new_owned_prefix'])
installation = prefix / 'INSTALL-RECEIPT.json'
installed = read_json(installation)
assert installed['status'] == 'DEPENDENCIES_EXTRACTED; native chooser and Browse remain UNRUN'
assert installed['prefix'] == str(prefix) and installed['source_manifest_sha256'] == sha(PACKET / 'DEPENDENCIES.json')
assert installed['old_environment_pins_unchanged'] is True
assert installed['packages'] == [{'name': p['name'], 'version': p['version'], 'sha256': p['sha256']} for p in dependencies['packages']]
inputs[str(installation)] = sha(installation)
inputs[str(prefix / 'usr/bin/zenity')] = installed['binary_sha256']
inputs[str(prefix / 'bin/zenity')] = installed['wrapper_sha256']
assert installed['wrapper_sha256'] == sha(PACKET / 'zenity-owned-wrapper.sh')
inputs[str(prefix / 'state/schemas/gschemas.compiled')] = installed['schemas_sha256']
# Metadata-only V4 binding: actual successful sqv/default-policy proof and
# authenticated output are retained inputs; no signature execution occurs here.
verifier_source = read_json(PACKET / 'VERIFIER-PROVENANCE.json')
verifier = installed['verifier']
assert verifier['binary'] == verifier_source['binary'] == '/usr/bin/sqv'
assert verifier['binary_sha256'] == verifier_source['binary_sha256']
assert verifier['installed_package_version'] == verifier_source['installed_package_version']
assert verifier['provenance_source_sha256'] == sha(PACKET / 'VERIFIER-PROVENANCE.json')
assert verifier['exit_code'] == 0
trust = dependencies['trust']
verify_command = verifier['command']
assert len(verify_command) == 7
original_authenticated = Path(verify_command[5])
assert original_authenticated.name == 'Release.authenticated' and original_authenticated.parent.parent.resolve() == PACKET.resolve()
assert original_authenticated.parent.name.startswith('actual-signed-release-')
assert verify_command == [verifier_source['binary'], '--keyring', trust['keyring_path'],
                          '--cleartext', '--output', str(original_authenticated), trust['InRelease_path']]
assert verifier['original_packages_entry'] == [trust['Packages_sha256'], str(trust['Packages_bytes']), 'main/binary-amd64/Packages']
inputs[verifier_source['binary']] = verifier_source['binary_sha256']
inputs[str(original_authenticated)] = verifier['authenticated_release_sha256']
inputs[str(prefix / 'provenance/Release.authenticated')] = verifier['authenticated_release_sha256']
for name in ('Packages', 'InRelease', 'keyring'):
    inputs[trust[name + '_path']] = trust[name + '_sha256']
for item in dependencies['packages']:
    payload = prefix / 'packages' / Path(item['filename']).name
    assert payload.stat().st_size == item['bytes']
    inputs[str(payload)] = item['sha256']
closure = read_json(PACKET / 'SOURCE-CLOSURE.json')
assert len(closure['production_sources']) == 654
for name, expected in closure['production_sources'].items():
    assert name in q['source_pins'] and q['source_pins'][name] == expected, name
    assert sha(ROOT / name) == expected, name

# Admit the original actual Root five-mode outcome, not an invented PASS file.
v7_outer_path = args.v7_root_receipt.resolve(strict=True)
assert v7_outer_path.is_relative_to(DELIVERY) and sha(v7_outer_path) == args.v7_root_receipt_sha
v7_outer = read_json(v7_outer_path)
assert v7_outer['runtime_status'] == 'PASS' and v7_outer['child_exit'] == 0
assert v7_outer['primary_failure'] is None and v7_outer['reconciliation_errors'] == []
for key in ('head_unchanged', 'raw_index_unchanged', 'tracked_membership_unchanged', 'tracked_source_unchanged', 'inputs_unchanged'):
    assert v7_outer[key] is True
assert v7_outer['head'] == head and v7_outer['qualification_sha256'] == args.qualification_sha
assert sha(v7_outer_path.with_suffix('.log')) == v7_outer['log_sha256']
v7_receipt = Path(v7_outer['native_receipt'])
assert v7_receipt.name == 'ACTUAL-RESULTS.json' and v7_receipt.parent.parent.resolve() == V7.resolve()
assert v7_receipt.parent.name.startswith('actual-wizard-') and sha(v7_receipt) == v7_outer['native_receipt_sha256']
previous = read_json(v7_receipt)
modes = ['cancel', 'finish', 'reopen', 'locales', 'recommended']
for key in ('planned_processes', 'attempted_processes', 'launched_processes', 'completed_processes', 'passed_processes'):
    assert previous[key] == modes
assert previous['status'] == 'PASS' and previous['primary_error'] is None
assert previous['cleanup_errors'] == [] and previous['qualification_errors'] == []
assert previous['unexecuted_processes'] == [] and previous['uncompleted_processes'] == []
assert previous['xvfb_session_disposed'] is True
assert previous['final_source_reconciliation'] == {'status': 'MATCH', 'changed': []}
assert previous['source_closure_sha256'] == sha(PACKET / 'SOURCE-CLOSURE.json')
assert previous['worker_sha256'] == sha(V7 / 'wizard-native-worker.lua') and previous['controller_sha256'] == sha(V7 / 'run-private-wizard.py')
assert [entry['mode'] for entry in previous['processes']] == modes
for entry in previous['processes']:
    assert entry['status'] == 'PASS' and entry['exit'] == 0
    assert entry['launched'] is True and entry['completed'] is True and entry['timed_out'] is False
    assert entry['native_session_disposed'] is True
    assert entry['native_receipt']['assertions'] and all(a['passed'] is True for a in entry['native_receipt']['assertions'])
    assert entry['native_receipt']['cleanup']['manager_retired'] is True
assert previous['independent_file_assertions'] and all(a['passed'] is True for a in previous['independent_file_assertions'])
profile = Path(previous['profile'])
assert profile == v7_receipt.parent and profile.resolve() == profile and not profile.is_symlink()
profile_members = {str(path.relative_to(profile)) for path in profile.rglob('*')
                   if path.is_file() or path.is_symlink()}
assert profile_members == set(previous['final_profile_files']) | {'ACTUAL-RESULTS.json'}
for name, item in previous['final_profile_files'].items():
    path = profile / name
    assert not Path(name).is_absolute() and path.resolve().is_relative_to(profile)
    if item['kind'] == 'file':
        assert path.is_file() and not path.is_symlink() and path.stat().st_size == item['bytes']
        assert sha(path) == item['sha256']
    elif item['kind'] == 'symlink':
        assert path.is_symlink() and os.readlink(path) == item['target']
    else:
        raise RuntimeError('Unknown genuine V7 profile file kind')
# Retain the genuine original logs/receipts as raw inputs. Ordinary native caches
# can evolve during a new GUI session; V3 separately enforces original actual
# config/bootstrap/metrics bytes and new-target emptiness throughout receiving.
for name in ['xvfb.log', 'xvfb-command-status.json', *[mode + suffix for mode in modes
             for suffix in ('-native.log', '-native.json', '-command-status.json')]]:
    item = previous['final_profile_files'][name]
    assert item['kind'] == 'file'
    inputs[str(profile / name)] = item['sha256']
inputs.update({str(v7_outer_path): args.v7_root_receipt_sha,
               str(v7_outer_path.with_suffix('.log')): v7_outer['log_sha256'],
               str(v7_receipt): v7_outer['native_receipt_sha256']})
for name, expected in inputs.items():
    assert sha(Path(name)) == expected, name

receipt = args.receipt
assert receipt.is_absolute() and receipt.parent.resolve(strict=True).is_relative_to(DELIVERY)
assert not receipt.exists() and not receipt.is_symlink()
log = receipt.with_suffix('.log')
assert receipt != log and not log.exists() and not log.is_symlink()
index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
if not index_path.is_absolute():
    index_path = ROOT / index_path
index_bytes = index_path.read_bytes()
assert hashlib.sha256(index_bytes).hexdigest() == v7_outer['raw_index_sha256']

def snapshot():
    names = sorted(set(git('ls-files', '-z').decode().split('\0')) - {''})
    result = {}
    for name in sorted(set(names) | set(q['source_pins'])):
        path = ROOT / name
        if path.is_symlink():
            result[name] = {'kind': 'symlink', 'target': os.readlink(path), 'sha256': sha(path) if path.is_file() else None}
        elif path.is_file():
            result[name] = {'kind': 'file', 'sha256': sha(path)}
        else:
            result[name] = {'kind': 'missing_or_other'}
    return names, result

before_tracked, before = snapshot()
for name, expected in q['source_pins'].items():
    assert before[name]['sha256'] == expected, name
assert before_tracked == v7_outer['tracked_paths'] and before == v7_outer['source_pins']
assert git('rev-parse', 'HEAD').decode().strip() == head
assert index_path.read_bytes() == index_bytes
command = ['python3', '/workspace/tooling/run-with-reaper.py', 'python3',
           '/workspace/tooling/run-with-gtk-namespace.py', 'python3',
           str(PACKET / 'run-browse.py'), '--checkout', str(ROOT), '--v7-receipt', str(v7_receipt), '--execute']
record = {'scope': 'genuine Browse four phases, raw Source/index/HEAD outer fence',
          'qualification': str(qualification), 'qualification_sha256': args.qualification_sha,
          'head': head, 'source_pins': before, 'tracked_paths': before_tracked,
          'explicit_selected_untracked_paths': sorted(set(q['source_pins']) - set(before_tracked)),
          'raw_index_sha256': hashlib.sha256(index_bytes).hexdigest(),
          'input_pins': inputs, 'command': command, 'runtime_status': 'UNRUN',
          'limitations': ['physical input UNRUN', 'Wayland UNRUN', 'live engine reload UNRUN', 'installed restart UNRUN',
                         'direct production stdout/exit capture UNRUN', 'standalone chooser stdout/exit UNRUN']}
primary = None
child_exit = None
reconciliation_errors = []
output_pins = {}
try:
    with log.open('xb') as output:
        child_exit = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT).returncode
    assert child_exit == 0, 'actual Browse controller refused; raw log preserved'
    summary = json.loads(log.read_bytes().splitlines()[-1])
    assert summary['status'] == 'PASS' and summary['primary_error'] is None
    assert summary['cleanup_errors'] == [] and summary['qualification_errors'] == []
    actual_path = Path(summary['receipt'])
    assert actual_path.name == 'ACTUAL-RESULTS.json' and actual_path.parent.parent.resolve() == PACKET.resolve()
    assert actual_path.parent.name.startswith('actual-browse-') and sha(actual_path) == summary['sha256']
    actual = read_json(actual_path)
    assert actual['status'] == 'PASS' and actual.get('primary_error') is None
    assert actual['cleanup_errors'] == [] and actual['qualification_errors'] == []
    assert actual['owned_sessions_disposed'] is True
    assert actual['final_source_reconciliation'] == {'status': 'MATCH', 'changed': []}
    phases = ['cancel', 'accept', 'cancel', 'retry']
    assert actual['planned_phases'] == phases and actual['completed_phases'] == phases
    assert actual['source_closure_sha256'] == sha(PACKET / 'SOURCE-CLOSURE.json')
    assert actual['original_oracle_sha256'] == sha(PACKET / 'ORIGINAL-BROWSE-EXPECTATIONS.json')
    assert actual['v7_receipt_sha256'] == sha(v7_receipt) and actual['profile'] == str(profile)
    assert actual['run_dir'] == str(actual_path.parent)
    assert actual['native_command_status']['exit_code'] == 0
    native_path = actual_path.parent / 'native.json'
    assert sha(native_path) == actual['native_receipt_sha256']
    native = read_json(native_path)
    assert native == actual['native_receipt'] and native['status'] == 'PASS' and native.get('failure') is None
    assert native['cleanup']['manager_called'] is True and native['cleanup']['manager_retired'] is True
    assert not native['cleanup'].get('manager_error') and not native['cleanup'].get('stream_errors')
    oracle = read_json(PACKET / 'ORIGINAL-BROWSE-EXPECTATIONS.json')
    original_dir = str(profile / 'recommended-config')
    folders = [original_dir, str(profile / oracle['accepted_directory_relative']),
               str(profile / oracle['accepted_directory_relative']), str(profile / oracle['second_retry_directory_relative'])]
    assert native['phases'] == [{'id': str(index), 'mode': mode, 'expected_folder': folders[index - 1], 'status': 'PASS'}
                                for index, mode in enumerate(phases, 1)]
    names = [a['name'] for a in native['assertions']]
    expected_names = ['actual V7 published folder is retained', 'actual published English locale is retained',
                      'genuine configured startup remains hidden', 'actual wizard opens with host data',
                      'actual English preview arrives', 'real navigation enters config page']
    phase_names = ['held DOM folder before Browse ', 'external owned actor starts before Browse ',
                   'actor start acknowledgement matches ', 'real Browse click completes ',
                   'real picker normalized folder/cancel reaches DOM ', 'actor and independent file checks finish ',
                   'actual actor/file acknowledgement matches ', 'real Next remains enabled ',
                   'real chosen-folder read is acknowledged after Next ', 'real Back allows next Browse ',
                   'Browse does not publish resolver before Finish ']
    for index in range(1, 5):
        expected_names.extend(name + str(index) for name in phase_names)
    expected_names.extend(['native close retires wizard', 'closing after Browse preserves published resolver',
                           'genuine reopen remains available after Browse', 'genuine reopen restores original published folder',
                           'native close retires wizard'])
    assert names == expected_names and all(a['passed'] is True for a in native['assertions'])
    file_names = [a['name'] for a in actual['file_assertions']]
    assert file_names and all(a['passed'] is True for a in actual['file_assertions'])
    required_files = []
    for label in ['before native receiving', *['after real chooser ' + str(i) for i in range(1, 5)],
                  'after chosen-folder reads and reopen', 'after all owned native cleanup']:
        required_files.append(label + ' exact original config/bootstrap/metrics bytes unchanged')
        for relative in (oracle['accepted_directory_relative'], oracle['second_retry_directory_relative']):
            required_files.append(label + ' new target remains empty: ' + relative)
    positions = [file_names.index(name) for name in required_files]
    assert positions == sorted(positions) and len(set(positions)) == len(required_files)
    for index in range(1, 5):
        for prefix in ('real owned chooser input completed ', 'actual actor session retired '):
            assert file_names.count(prefix + str(index)) == 1
    assert [a['id'] for a in actual['actors']] == ['1', '2', '3', '4']
    actor_raw = {}
    for index, entry in enumerate(actual['actors'], 1):
        actor_path = actual_path.parent / ('actor-' + str(index) + '.json')
        assert sha(actor_path) == entry['receipt_sha256']
        actor = read_json(actor_path)
        assert actor == entry['receipt'] and entry['command_status']['exit_code'] == 0
        assert actor['status'] == 'INPUT_SEQUENCE_COMPLETED; receiving UNQUALIFIED' and actor['mode'] == phases[index - 1]
        assert not actor.get('primary_error') and not actor.get('receipt_write_error') and not actor.get('secondary_log_error')
        assert actor['owned_window']['title'] == oracle['original_locale_titles']['en']['original_native_title']
        assert actor['commands'] and all(c['exit'] in (0, 1) for c in actor['commands'])
        actor_raw[str(actor_path)] = sha(actor_path)
    for path in actual_path.parent.rglob('*'):
        if path.is_symlink():
            raise RuntimeError('Unexpected symlink in owned Browse raw outputs')
        if path.is_file():
            output_pins[str(path)] = sha(path)
    record.update(actual_browse_receipt=str(actual_path), actual_browse_receipt_sha256=sha(actual_path),
                  actual_native_receipt=str(native_path), actual_native_receipt_sha256=sha(native_path),
                  raw_actor_receipts=actor_raw, actual_native_assertions=len(native['assertions']),
                  actual_file_assertions=len(actual['file_assertions']))
except BaseException as error:
    primary = {'type': type(error).__name__, 'error': str(error)}
finally:
    def observe(name, action):
        try:
            record[name] = action()
        except BaseException as error:
            record[name] = None
            reconciliation_errors.append({'stage': name, 'type': type(error).__name__, 'error': str(error)})
    observe('head_unchanged', lambda: git('rev-parse', 'HEAD').decode().strip() == head)
    observe('raw_index_unchanged', lambda: index_path.read_bytes() == index_bytes)
    def reconcile_sources():
        after_tracked, after = snapshot()
        record['tracked_membership_unchanged'] = before_tracked == after_tracked
        record['tracked_paths_after'] = after_tracked
        record['changed_paths'] = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
        return before_tracked == after_tracked and before == after
    observe('tracked_source_unchanged', reconcile_sources)
    observe('inputs_unchanged', lambda: all(sha(Path(name)) == expected for name, expected in inputs.items()))
    record['raw_browse_output_pins'] = output_pins
    observe('raw_browse_outputs_unchanged', lambda: all(sha(Path(name)) == expected for name, expected in output_pins.items()))
    observe('log_sha256', lambda: sha(log))
    record.update(child_exit=child_exit, primary_failure=primary, reconciliation_errors=reconciliation_errors)
    record['runtime_status'] = 'PASS' if child_exit == 0 and primary is None and not reconciliation_errors and all(
        record.get(key) is True for key in ('head_unchanged', 'raw_index_unchanged', 'tracked_membership_unchanged', 'tracked_source_unchanged', 'inputs_unchanged', 'raw_browse_outputs_unchanged')) else 'FAIL'
    try:
        with receipt.open('x') as output:
            json.dump(record, output, indent=2)
            output.write('\n')
    except BaseException as error:
        raise RuntimeError('Outer receipt write failed: ' + str(error) + '; preserved primary: ' + repr(primary) + '; reconciliation: ' + repr(reconciliation_errors)) from error
if record['runtime_status'] != 'PASS':
    raise SystemExit(1)
