# group3-linux93-public-join-v2/qualify.py
from pathlib import Path
import subprocess, json, hashlib
b=Path(__file__).parent
old=b.parent/'group3-linux93-public-join-v1/freeze'
source='static/ergopti_plus/linux/modules/shortcuts/key_combinations.lua'
manager='static/ergopti_plus/linux/platform/remap/tap_hold_manager.lua'
def emit(name, images):
 d=b/'variants'/name
 for path,content in images.items():
  p=d/path.removeprefix('static/ergopti_plus/linux/');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
 return d
s=(b/'candidate'/source).read_text();m=(b/'candidate'/manager).read_text()
variants={
 'original_module_identity_omitted':emit('original_module_identity_omitted',{manager:m.replace('getmetatable(M)==nil and rawequal(package.loaded["platform.remap.tap_hold_manager"],M)','true').encode()}),
 'old_v1':emit('old_v1',{p:(old/'candidate'/p).read_bytes() for p in [source,manager]}),
 'old_source':emit('old_source',{source:(old/'candidate'/source).read_bytes()}),
 'observer_identity_omitted':emit('observer_identity_omitted',{source:s.replace('or rawget(manager,"managed_pair_options_current")~=observe','').encode()}),
 'catalogue_currency_omitted':emit('catalogue_currency_omitted',{manager:m.replace('and fields_equal(rawget(NativeCatalogue,"actions"),catalogue_snapshot)','').encode()}),
 'constructor_currency_omitted':emit('constructor_currency_omitted',{manager:m.replace('and rawget(Combinations,"new")==original_combination_constructor','').replace('and rawget(Engine,"new")==original_engine_constructor','').replace('and rawget(PairModule,"new")==original_pair_constructor','').encode()}),
 'config_currency_omitted':emit('config_currency_omitted',{manager:m.replace('and rawget(Config,"load")==original_config_load and rawget(Config,"load_document")==original_config_document','').encode()}),
 'loaded_catalogue_currency_omitted':emit('loaded_catalogue_currency_omitted',{manager:m.replace('and fields_equal(_loaded.catalog,record.catalogue) and fields_equal(_loaded.keys,record.keys)','').encode()}),
 'issued_getter_currency_omitted':emit('issued_getter_currency_omitted',{manager:m.replace('and rawget(owner,"engine_options")==record.options_getter','').encode()}),
 'reissue_snapshot_currency_omitted':emit('reissue_snapshot_currency_omitted',{manager:m.replace('if _combinations and not managed_owner_current(_loaded,_combinations) then return false end','').replace('and fields_equal(loaded.catalog,issuer.catalogue) and fields_equal(loaded.keys,issuer.keys)','').encode()}),
}
results=[]
for abi in ['luajit','lua5.4']:
 binary='/workspace/.ergopti-cloud/bin/'+abi
 for label,extra in [('candidate',None),*variants.items()]:
  args=[binary,str(b/'run.lua'),str(b),'tests.unit.modules.test_key_combinations']
  if extra:args.append(str(extra))
  r=subprocess.run(args,cwd='/workspace/ergopti/static/ergopti_plus/linux',capture_output=True)
  output=r.stdout+r.stderr
  log=b/'evidence'/f'{abi}-{label}.log';log.write_bytes(output)
  summaries=[x for x in output.decode(errors='replace').splitlines() if x.startswith('PUBLIC_JOIN_CONTROLLED')]
  row={'abi':abi,'case':label,'exit':r.returncode,'summary':summaries[-1:]}
  results.append(row);print(row,flush=True)
  assert r.returncode==(0 if label=='candidate' else 1),row
 for label,module in [('scope','tests.unit.infra.test_key_combinations_scope'),('global','tests.unit.infra.test_global_shortcuts_pair_scope')]:
  r=subprocess.run([binary,str(b/'run.lua'),str(b),module],cwd='/workspace/ergopti/static/ergopti_plus/linux',capture_output=True)
  output=r.stdout+r.stderr;(b/'evidence'/f'{abi}-{label}.log').write_bytes(output)
  summaries=[x for x in output.decode(errors='replace').splitlines() if x.startswith('PUBLIC_JOIN_CONTROLLED')]
  row={'abi':abi,'case':label,'exit':r.returncode,'summary':summaries[-1:]};results.append(row);print(row,flush=True)
  assert r.returncode==0,row
(b/'results.json').write_text(json.dumps(results,indent=2)+'\n')
