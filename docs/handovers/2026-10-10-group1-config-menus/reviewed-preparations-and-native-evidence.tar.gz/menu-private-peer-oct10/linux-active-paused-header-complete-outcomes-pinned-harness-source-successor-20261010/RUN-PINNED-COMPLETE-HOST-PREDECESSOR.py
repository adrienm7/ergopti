from pathlib import Path
import hashlib,json,subprocess,re,os,sys
R=Path('/workspace/ergopti');Q=Path(__file__).resolve().parent
P=Path("/workspace/ergopti-delivery/group1-complete-resume-20261007/menu-private-peer-oct10/linux-active-paused-header-existing-template-source-only-20261010")
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(sys.argv)==2, 'Supply a fresh receipt directory outside canonical Root'
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
assert R not in out.parents, 'No canonical Root writes'
assert sha((Q/'RUN-COMPLETE-REGISTERED-HEADER-HOST.lua').read_bytes())=="f623312edad4b2b0485ad924b790717ef6d5372564018f75a323a767b3a434f2"
assert sha((P/'source-only.patch').read_bytes())=="5ead6c219fa440ecb60adbce18312ce0d8b42cb6bc04bd4f48c20b14114a7fce"
assert sha((P/'SOURCE-PROPOSAL.json').read_bytes())=='d30031c20bc1c72fddec2fd57924a17886fb89a5a62dfc9162981c541c856927'
assert sha((Q/'EXPECTED-ACTUAL-SUBJECT-NAMES.json').read_bytes())=='7cf9c45503a102caafcfb72f48f991a873e8c609bdc6a9113d58cddb6faf3f63'
assert sha((Q/'PREPARATION-DEPENDENCY-PINS.json').read_bytes())=='87f05dabd670f9fd06fc7baf5c3578f98ff19784ac7f771c447e609a699a0961'
proposal=json.loads((P/'SOURCE-PROPOSAL.json').read_text())
original_file=P/'preimages/static/ergopti_plus/linux/ui/menu/menu_builder.lua'
original_pin=next(row['pre_sha256'] for row in proposal['paths'] if row['path']=='static/ergopti_plus/linux/ui/menu/menu_builder.lua')
assert sha(original_file.read_bytes())==original_pin, 'Original provider does not match immutable source preimage'
expected_subjects=62
subject_inventory={'original_baseline':6,'original_paused_captions':21,'original_active_versions':6,'current_canonical_caption_consumption':1,'missing_resume_context':1,'canonical_refusals':14,'captured_owner_withdrawals':2,'during_publication_withdrawals':6,'foreign_projection_fields':5}
assert sum(subject_inventory.values())==expected_subjects
subject_names=json.loads((Q/'EXPECTED-ACTUAL-SUBJECT-NAMES.json').read_text())
assert len(subject_names['ordered'])==expected_subjects and len(set(subject_names['ordered']))==expected_subjects

# Requires actual Root receiving plus genuine owning generation; no copied old projection.
for item in proposal['paths']:
 assert sha((R/item['path']).read_bytes())==item['post_sha256'], 'Actual receiving source drift: '+item['path']
j=json.loads((R/'static/ergopti_plus/_shared/modules/menu/menu_manifest.json').read_text())
assert j['linux_tray_active_header']==[{'type':'label','id':'linux_tray_active_header','i18n':'menu.builder.active_brand','caption_getter':'linux_tray_version','caption_layout':'prefix','caption_joiner':' — ','platforms':['linux'],'unavailable':'hide'}], 'Owning active header missing'
assert j['linux_tray_paused_header']==[{'type':'command','id':'linux_tray_resume','i18n':'menu.builder.title_paused','caption_getter':'linux_tray_version','caption_layout':'prefix','caption_joiner':' — ','platforms':['linux'],'unavailable':'hide'}], 'Owning paused header missing'
expected=json.loads((Q/'PREPARATION-DEPENDENCY-PINS.json').read_text())
for path,pin in expected.items():assert sha((R/path).read_bytes())==pin, 'Actual unchanged runner/dependency drift: '+path
paths=set(subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard','--','static/ergopti_plus','tools'],cwd=R).decode().split('\0'));paths.discard('')
for path in (R/'static/ergopti_plus').rglob('*'):
 if path.is_file() and not path.is_symlink() and ('_generated' in path.parts or path.suffix in {'.lua','.json','.toml','.ahk'}):paths.add(path.relative_to(R).as_posix())
snapshot=lambda:{path:sha((R/path).read_bytes()) for path in sorted(paths) if (R/path).is_file()}
before=snapshot();(out/'ROOT-PINS-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
results=[]
interrupted=None
for exe,mode in [('lua5.4','candidate'),('lua5.4','original'),('luajit','candidate'),('luajit','original')]:
 assert snapshot()==before
 assert sha(original_file.read_bytes())==original_pin
 command=[exe,str(Q/'RUN-COMPLETE-REGISTERED-HEADER-HOST.lua'),mode]
 log=out/(exe+'-'+mode+'-RAW.log')
 with log.open('wb') as stream:proc=subprocess.run(command,cwd=R/'static/ergopti_plus/linux',stdout=stream,stderr=subprocess.STDOUT,env=os.environ.copy())
 plain=re.sub(r'\x1b\[[0-9;]*m','',log.read_bytes().decode(errors='replace'))
 def count(label):
  values=re.findall(label+r':\s*(\d+)',plain);return int(values[-1]) if values else None
 result={'command':command,'mode':mode,'exit_code':proc.returncode,'passed':count('Passed tests'),'failed':count('Failed tests'),'modules':count('Total modules'),'log_sha256':sha(log.read_bytes()),'root_inputs_unchanged':snapshot()==before}
 result['failure_subjects']=re.findall(r'^\s+- (.+?) : ',plain,re.MULTILINE)
 result['executed_subject_names']=re.findall(r'^  (?:ok   |FAIL )(.+?)(?: — .*)?$',plain,re.MULTILINE)
 result['subject_inventory_exact']=result['executed_subject_names']==subject_names['ordered']
 result['failure_subject_family']={name:('original_baseline' if name in subject_names['baseline'] else 'new_shared_header' if name in subject_names['new'] else 'unknown') for name in result['failure_subjects']}
 result.update({'load_errors':re.findall(r'! load error in ([^\n]+)',plain),
  'expected_subjects':expected_subjects,'observed_subjects':(result['passed']+result['failed']) if result['passed'] is not None and result['failed'] is not None else None,
  'original_preimage_before_after_exact':sha(original_file.read_bytes())==original_pin,
  'ignored':0 if result['passed'] is not None and result['failed'] is not None and result['passed']+result['failed']==expected_subjects and '! load error in ' not in plain else None,
  'whole_host_complete':result['modules']==1 and result['passed'] is not None and result['failed'] is not None and result['passed']+result['failed']==expected_subjects and '! load error in ' not in plain and result['subject_inventory_exact']})
 results.append(result)
 (out/(exe+'-'+mode+'-ATTEMPT-RECEIPT.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 # Persist raw attempt/counters before admission; incomplete attempt cannot qualify.
 if not result['root_inputs_unchanged'] or not result['original_preimage_before_after_exact'] or not result['whole_host_complete']:
  interrupted={'reason':'Actual source drift/load error/incomplete target execution','failed_attempt':len(results)-1}
  break
(out/'ROOT-PINS-AFTER.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'TERMINAL-RECEIPT.json').write_text(json.dumps({'results':results,'candidate_all_pass':len([r for r in results if r['mode']=='candidate'])==2 and all(r['whole_host_complete'] and r['exit_code']==0 and r['failed']==0 for r in results if r['mode']=='candidate'),'original_counterfactual_red':len([r for r in results if r['mode']=='original'])==2 and all(r['whole_host_complete'] and r['exit_code']!=0 and r['failed']>0 and len(r['failure_subjects'])==r['failed'] and all(name in subject_names['new'] for name in r['failure_subjects']) for r in results if r['mode']=='original'),'interrupted':interrupted,'not_executed':4-len(results),'subject_inventory':subject_inventory,'original_expected_sha256':original_pin,'root_inputs':len(before),'root_inputs_unchanged':snapshot()==before,'source_packet_sha256':"5ead6c219fa440ecb60adbce18312ce0d8b42cb6bc04bd4f48c20b14114a7fce",'scope':'Complete existing registered Linux header/pause host on both ABIs; original predecessor changes only actual provider source via process loader; all other modules NOT EXECUTED. No filters/assertions changed, no Root writes/gens.','original_source':str(P/'preimages/static/ergopti_plus/linux/ui/menu/menu_builder.lua'),'original_sha256':sha((P/'preimages/static/ergopti_plus/linux/ui/menu/menu_builder.lua').read_bytes()),'ignored_status':'Zero only when exact62 active source registrations execute completely; otherwise unknown, attempt unqualified','original_positive_new_failure_separation':'Original six-case names must have no failures; genuine predecessor must fail at least one new name; exact62 actually printed source-derived names required in original registration order','slot':'All requested commands terminal; release immediately'},indent=2)+'\n')

if interrupted:raise SystemExit(1)
