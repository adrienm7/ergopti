from pathlib import Path
import json,subprocess,shutil,hashlib
B=Path('/workspace/.ergopti-cloud/reviews/windows-native-desktop-source-v2-independent');A=Path('/workspace/.ergopti-cloud/preparations/windows-native-desktop-source-prototype-v2');D=B/'independent-roundtrip';D.mkdir();pairs=json.loads((A/'source-pairs.json').read_text())['changed_paths']
for row in pairs:
 if not row['new']:
  p=D/row['file'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((A/'preimage'/row['file']).read_bytes())
results=[]
for name,patch in [('forward',A/'forward.patch'),('inverse',A/'inverse.patch')]:
 for mode in ['check','apply']:
  cmd=['git','apply','--whitespace=error'];
  if mode=='check':cmd+=['--check']
  cp=subprocess.run(cmd+[str(patch)],cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);results.append({'direction':name,'mode':mode,'exit':cp.returncode,'stdout':cp.stdout.decode(),'stderr':cp.stderr.decode()});assert cp.returncode==0
 if name=='forward':
  for row in pairs:assert (D/row['file']).read_bytes()==(A/'projection'/row['file']).read_bytes()
 else:
  for row in pairs:
   if row['new']:assert not (D/row['file']).exists()
   else:assert (D/row['file']).read_bytes()==(A/'preimage'/row['file']).read_bytes()
(B/'independent-roundtrip.json').write_text(json.dumps({'operations':results,'all16postimages_exact':True,'all11preimages_restored':True,'five_new_paths_removed_by_inverse':True,'canonical_mutations':False},indent=2)+'\n')
print('Independent patch roundtrip: 4 operations PASS,16 postimages exact,11 original preimages restored')
