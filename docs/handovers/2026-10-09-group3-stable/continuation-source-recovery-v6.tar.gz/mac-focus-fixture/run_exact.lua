local projection, target = assert(arg[1]), assert(arg[2])
package.path = projection .. "/static/ergopti_plus/_shared/lua/?.lua;" .. package.path
if jit then require("compat.utf8").install() end
arg = { "--only", target }
dofile(projection .. "/static/ergopti_plus/macos/tests/run.lua")
