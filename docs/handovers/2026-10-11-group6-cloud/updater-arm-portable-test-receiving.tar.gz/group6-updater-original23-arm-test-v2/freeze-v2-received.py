from pathlib import Path
import ast, hashlib, json, tarfile
root=Path(__file__).resolve().parent
assert ast.parse((root/'reproduce.py').read_text())
relative='physical-source/tools/test/test-windows-updater-original-source.cjs'
selected=[relative,'preimage.cjs','test-only.patch','test-only.inverse.patch','REVIEW.md','author-test.py','reproduce.py','preserve-assertions.cjs','assertion-preservation.json','freeze-v2-received.py','format.first-plugin-resolution.stderr','source-five-hash-fence.json','immutable-inputs37.inventory.json','model-arm-test.cjs','model-arm-test.first-cross-realm.cjs','model-arm-predecessor.cjs','receive-arm-omission.cjs','receive-counterfactuals.cjs','runtime.json','format.stdout','format.stderr','format-check.stdout','format-check.stderr','syntax.stdout','syntax.stderr','unformatted-first22.receipt.json','final22.receipt.json','modeled-arm22.receipt.json']
for prefix in ['candidate22','final22','modeled-arm22','modeled-arm22.first-cross-realm','counter-scope','counter-proxy','counter-local-argc','counter-import','counter-arm-predecessor','counter-arm-omission']:
 for suffix in ['stdout','stderr']:
  selected.append(prefix+'.'+suffix)
 for suffix in ['exit']:
  path=root/(prefix+'.'+suffix)
  if path.exists():selected.append(prefix+'.'+suffix)
if (root/'independent-review.json').exists():selected.append('independent-review.json')
entries=[]
for name in selected:
 p=root/name
 assert p.is_file() and not p.is_symlink(),name
 data=p.read_bytes()
 entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':1,'scope':'test-only-arm-portability-source-software','native':False,'official':False,'baseline_capsule_sha256':'d9c942180724ee74c3544e96035af81728e5e96536b1d13111bf68da96b5e98f','entries':entries}
(root/'safe-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
selected.append('safe-manifest.json')
archive=root.parent/'group6-updater-original23-arm-test-v2-received.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in selected:
  tar.add(root/name,arcname=root.name+'/'+name,recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members)
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'members':len(selected),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((root/'safe-manifest.json').read_bytes()).hexdigest()}))
