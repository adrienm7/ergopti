local root, source = assert(arg[1]), assert(arg[2])
package.path = root .. '/static/ergopti_plus/linux/?.lua;' .. root .. '/static/ergopti_plus/linux/?/init.lua;' .. root .. '/static/ergopti_plus/_shared/lua/?.lua;' .. root .. '/static/ergopti_plus/_shared/lua/?/init.lua;' .. package.path
require('compat.utf8').install()
local helpers = require('tests.helpers'); helpers.reset_results()
local file=assert(io.open(source,'rb')); local text=assert(file:read('*a')); assert(file:close())
local chunk=assert((loadstring or load)(text,'@' .. source)); chunk()
local result=helpers.get_results(); print('Fixture focused:',result.passed,'passed;',result.failed,'failed')
os.exit(result.failed>0 and 1 or 0)
