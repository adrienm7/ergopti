# Duplicate model rows: bounded Windows renderer preparation

This preparation is outside the checkout. All Windows tests are **not executed**.
No production source, existing assertion, shared manifest, locale, schema,
generator, TODO, workflow, or test runner was changed.

## Ownership reservation

Do not adopt until the parent has resolved the ownership reservation in issue 86,
comment 5984512809, with groups 1, 2, 7 and the Windows agent. The actual shared
policy already preserves model IDs and duplicate rows. This change concerns the
Windows native materialization of those rows; it adds no private model policy.

| Proposed owner coordination | Exact source hunk |
| --- | --- |
| Group 1 renderer owner | `infra/manifest_menu.ahk`, `_MR_RenderRows` only: append distinct submenu/leaf rows with Insert, apply icon/check/disable using native position, reject unexpected row-count drift |
| Groups 2/7 and Windows dispatcher owner | `infra/menu_dispatcher.ahk`, `RegisterMenuItemInsert` only: recognize blank append, compare native counts, resolve last native ID, refuse ambiguity/count/ID errors without a label fallback |
| Group 4 test harness owner, subject to Windows test coordination | `tests/run_llm_model_menu_disabled.ahk`, one additional isolated Insert stub using actual `Menu.Insert` |
| Group 1/Windows test owner | Additional cases in `native_cases.ahk`, intended for inclusion in the existing native menu test owner, preserving all current tests/assertions |

`MenuPopulation.Fill/Complete` need no modification. They already append one seed
then batches and retain command IDs. A uniqueness scan limited to one input batch
would miss collisions with the seed and earlier batches. The renderer therefore
reads the actual current native count for every row, separators included.

Direct `RegisterMenuItem` remains byte-for-byte unchanged and retains its public
Add/update semantics. The renderer uses it for the guaranteed-empty first native
row, where label collision is impossible, preserving the real registration path
required by the immutable `test_keyboard_shortcut_groups_register_dispatch`
assertion. Later rows use tracked Insert. This avoids a duplicate-name scan or
batch-local uniqueness rule. Numbered Insert and named Insert retain their existing
position and uniqueness-checked lookup paths. Blank Insert must never use a label
fallback, even on a failed native ID lookup. A refused registration returns zero;
the existing `RequireTracking` population paths reject it rather than publishing
a falsely complete leaf. If insertion succeeded before count/ID discovery failed,
the native row can remain in the candidate menu, untracked. Transactional staging
must reject that candidate; this preparation does not introduce rollback policy.

The renderer still escapes ampersands exactly once, at the existing source line.
Its existing optional-icon error handling is retained. It now throws on native
count drift before applying positional state, to avoid changing another row.

## Native API basis

`upstream-script_menu.cpp` is an unmodified official AutoHotkey source reference
pinned to `c426c967033603ed4748144eae91ce2cd3769934`; `upstream-receipt.json` records
its URL and SHA-256. It is source evidence, not a Windows runtime result.

- Lines 57–74: blank `Insert` appends using an insertion pointer. The explicit
  position immediately after the last item is also permitted.
- Lines 89–95: `Add` searches for an existing label; Insert skips that lookup.
- Lines 469–489: `N&` selects a one-based position; native text matching uses
  case-insensitive `lstrcmpi`. Labels differing only by case therefore also need
  distinct Insert rows.
- Lines 190–195: `SetIcon` resolves the supplied item through that selector.
- Lines 1374–1381: icon state is written as `MIIM_BITMAP` / `hbmpItem`.

The tests read actual `GetMenuItemCount`, `GetMenuItemID`, `GetMenuStringW`,
`GetMenuState` with `MF_BYPOSITION`, `GetSubMenu`, and `GetMenuItemInfoW` with
`MIIM_BITMAP`. Text assertions deliberately use AHK case-sensitive `==` rather
than an ordinary case-insensitive comparison. The icon test first requires a
successful native positional control with the executing AHK binary's real icon;
it then verifies that only the intended duplicate row has a bitmap.

## Prepared tests: 11 registrations, none executed

Successful cases use genuine AHK `Menu` objects and native HMENU receipts:

1. Blank Insert creates separate exact duplicate and case-variant labels.
2. Blank dispatcher registration yields distinct IDs, tokens and callbacks,
   retaining the first token.
3. Production row rendering preserves exact text/callback order and independent
   checked/disabled state in both first/second orderings.
4. The real icon belongs only to the second equal-label row, after a separator.
5. Action, inert label, nested data submenu and existing native submenu retain
   separate rows and state.
6. A lazy seed followed by two sixteen-row batches and final completion retains
   all 34 duplicate IDs/callbacks, first token and later checked/disabled state.
7. Direct `RegisterMenuItem` still updates the existing same-label callback,
   retaining its ID and the unrelated tail's token.

Four adverse-admission cases explicitly use object ports backed by real native
menus, not substitutes for successful GTK/AHK rendering:

8. Missing initial handle/count refuses before insertion.
9. Missing post-insertion handle/count refuses tracking.
10. Actual insertion of two rows refuses unexpected growth.
11. Actual popup submenu `GetMenuItemID == 0xFFFFFFFF` refuses leaf registration,
    even with an earlier same-label leaf that a unique-leaf-name fallback would
    otherwise bind incorrectly.

Failure cases assert no callback/token registration, token-counter increment or
callback invocation. Successful callback assertions invoke the dispatcher's
registered callbacks by actual native ID; they prove callback ownership, not a
physical mouse click or Windows message delivery. Existing dispatcher lifecycle,
retry, startup, pruning and population tests must also stay green.

## Reproduction and source receipts

`prepare.py` created three full candidate files and three reviewable patches from
immutable BOM/LF preimages. `source-receipts.json` records exact preimage/candidate
hashes and observed checkout HEAD. The preimages are more precise than HEAD if
another owner had authorized uncommitted work. Do not rerun the script over this
directory after production sources change: it refuses preimage drift and never
rewrites existing preimages. Rebuilding a revised candidate from unchanged
preimages is permitted; receipts describe the final prepared candidate.

Before adoption, compare each production file to its recorded preimage, resolve
ownership, review the patches, and adapt only the agreed hunks. Include these new
cases in the existing test owner without removing or changing its assertions.
Check UTF-8 BOM and LF after any integration. No expectations were regenerated
from the changed implementation.

Required qualification remains actual Windows AHK v2 native execution, the
isolated model-menu harness, and the applicable full menu/dispatcher/startup/
population regressions. Packaging and physical E2E requirements stay separate.
Linux has generated these preparations but executed no Windows/native cases.
