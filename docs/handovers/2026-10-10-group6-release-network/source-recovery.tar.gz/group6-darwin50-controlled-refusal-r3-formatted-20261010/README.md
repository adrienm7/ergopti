# Formatted Darwin receiver controls and Linux enrollment proposal

This immutable private R3 preserves R2's complete AST, 2,894-token sequence and
comments after repository-pinned Prettier 3.6.2 with `/workspace/ergopti/.prettierrc`.
The original R3 native wrapper, guardian, independent literal corpus, adapter,
Python resolver and copied contexts remain byte-exact. No production policy,
clock, assertion or native publication rule changes.

Root actually executed the immutable R2: 25 portable contracts PASS, exit0,
recorded by the linked ACTUAL-RECEIVING.json. R3 was formatted and statically
parsed for preservation; its target runtime has NOT been reexecuted. The source
receiving command parses bytes with Acorn only and never imports target code.
This transfers exact semantics, not a fresh executed-suite claim.

## Enrollment proposal and custody

The only shared proposals are package.json (one new direct npm alias) and
tools/test/run-js-suite.cjs (one conditional spread). The entry is selected ONLY
when `process.platform === 'linux'`. Existing 407 CHECKS remain in exact order and
whole-byte reconstruction; Linux gets 408, Windows and Darwin remain at407.
Windows is never sent through process.getuid/POSIX permission, symlink or physical
FD-reuse controls. The direct alias is intended for this Linux collector; it does
not claim portability to Windows. All481 prior package scripts and metadata are
unchanged and the added alias brings482. The existing gate-script reachability
scanner sees the direct filename normally; no orphan allowance, scanner change,
extra workflow or CI caller change is proposed.

Parent `/root` is the proposed serial enrollment executor. It must establish
current package/registry custody and recheck the declared preimages before
adoption; this packet makes no external-owner grant inference. The separate
workflow+two-CI-guard request6095992820 remains HOLD. No proposed shared file is
applied, staged or committed. The original full Darwin50 workflow enrollment is
not implied by normal portable controls.

The coherent proposal consists of four paths: the original diagnostic wrapper
(new and still absent canonically), the formatted harness, package alias and
Linux-only collector entry. It deliberately excludes the original workflow and
two CI guards. The parent can review this separately once current ownership is
resolved. Generated artifacts are absent.

## Limits

Synthetic packet/corpus envelopes and guardian EventEmitter PIDs are controlled
choreography only; no Python/guardian, Darwin ABI, WNOWAIT, libproc, native kill,
physical process-group retirement, literal50 corpus, routing, package, release or
installation receiving is proved. Actual Darwin negatives and50+TERM+INT remain
UNEXECUTED. The existing original wrapper120s and original guardian settlement
budgets are unchanged. R2's25 green controls cannot remove TODO62 or substitute
for native qualification.

Future qualification after shared approval: exact private formatted harness
focused replay, canonical JS source/format gates after serialized adoption, and
actual original Darwin receiving on both ABI lanes. Do not run a full shared
suite concurrently with another gate or change a running workflow.
