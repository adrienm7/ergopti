# Snapshot16 warning source checkpoint

Received source: 60adb7e83d504b04ca807bfda8657254cccae306.
Actual run: 38246997305 attempt2. The one child is dry, exit0; native16 was not launched.
TAP445B versus stdout1,253,792B. The first mismatch is offset0 (# versus D).
The retained stdout tail contains LocalSameAsGlobal warnings in old functions;
Worker is only the partial first tail line, not an invented complete warning header.

The eight observed names have32 bare registration binding sites across15 fixtures.
Every complete recorded registration block is exact in Main63cf and Dev9ad.
The new Snapshot owner and test create none of those eight generic globals and
contain no Worker/Callback/Command identifiers. This does not prove an exhaustive
census of all compiler warnings in the unavailable stdout prefix. Main's isolated
native runner has only console/key-combination unit includes; no whole ordinary
Main warning-free/native16 qualification was received or borrowed.

Top-level for bindings produce globals, while same-named ordinary function locals
are the LocalSameAsGlobal warning mechanism. Test framework stdout/TAP mirroring
cannot absorb interpreter warnings that bypass its _TestPrint/_LogBootProgress paths.
The strict receiver correctly refused the mismatched closed captures. There is no
source evidence of a transport corruption or Snapshot-created Worker global.

## Original registration locations

Paths are relative to static/ergopti_plus/windows/tests/. These are original start
lines; the separate minimal proposal manifest gives exact closed start/end spans.

- meta/test_secure_field_stale_verdict_fails_closed.ahk: 354 Owner, 485 Owner.
- unit/test_config_full_save_generation.ahk: 1468 Name, 1611 Name.
- unit/test_config_migrate.ahk: 915 Index, 922 Index, 1337 Name, 1340 Name.
- unit/test_config_transition_runtime.ahk: 480 Name, 483 Name, 486 Name.
- unit/test_config_transition_windows_port.ahk: 505 Name, 685 Callback, 798 Callback.
- unit/test_config_write_terminal_barrier.ahk: 240 Name, 246 Name, 276 Name, 506 Name, 512 Name, 707 Name.
- unit/test_json_object_key_nul.ahk: 14 Source.
- unit/test_klr_cache_encryption.ahk: 250 Worker.
- unit/test_language_deferred_declared_parent.ahk: 230 Owner, 236 Owner, 264 Name, 268 Owner.
- unit/test_llm_api_remote.ahk: 1660 Index.
- unit/test_llm_menu_transactions_20260813.ahk: 3088 Command.
- unit/test_logger_native_write.ahk: 177 Count.
- unit/test_managed_remote_transport.ahk: 2492 Index.
- unit/test_metrics_range_date_types.ahk: 45 Index.
- unit/test_walker_json_flush_merge.ahk: 221 Source.

## Prepared next step

The separate private15-path/32-binding alpha proposal is at
/workspace/.ergopti-cloud/continuation-2026-10-12/snapshot16-registration-global-alpha-private-v1.
It changes only registration variable identifiers, preserving original string/data/
callback/order and exact outside bytes. Explicit peer custody and independent review
are pending. It does not change runner/framework/CHECKS/#Warn, normalize stdout,
remove or relax assertions, increase capture/deadline budgets or run Windows locally.
A finite official Windows receiving plan can compare the same original dry receive,
then restore the sole Worker registration binding as a causal warning counterfactual;
full candidate receiving must still pass whole-runner dry before the exact native16.
Other generic globals and unreceived warning classes remain outside the proposal.

No validation suite, module import, compiler, native process, canonical/index/ref
mutation or network operation was performed for this checkpoint. One initial metadata
parser attempt expected the truncated Worker line to have a full header and refused;
its raw/script are preserved. The final parser separately records that partial line.
