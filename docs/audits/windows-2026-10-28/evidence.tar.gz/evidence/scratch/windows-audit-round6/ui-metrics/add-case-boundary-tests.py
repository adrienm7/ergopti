from pathlib import Path
import json
b=Path('/workspace/ergopti-windows-r6-ui-metrics');r=Path('/workspace/scratch/windows-audit-round6/ui-metrics');w=b/'static/ergopti_plus/windows/tests'
ids=['capital-i-dot','separate-combining-dot','corrected-i-dot','greek-word-context','dotless-i']
folds={
'capital-i-dot':{'c':{'a':'a','İ':'İ'},'bg':{'İa':'İa'}},
'separate-combining-dot':{'c':{'a':'a','i':'i','̇':'̇'},'bg':{'i̇':'i̇','̇a':'̇a'},'tg':{'i̇a':'i̇a'}},
'corrected-i-dot':{'c':{'[BS]':'[BS]','İ':'İ'},'bg':{'İ[BS]':'İ[bs]'}},
'greek-word-context':{'c':{' ':' ','İ':'İ','Ο':'ο','Σ':'σ'},'bg':{'İΟ':'İο','ΟΣ':'ος','Σ ':'σ '},'tg':{'İΟΣ':'İος','ΟΣ ':'ος '},'qg':{'İΟΣ ':'İος '},'w':{'İΟΣ':'i̇ος'}},
'dotless-i':{'c':{'I':'i','İ':'İ','ı':'ı'},'bg':{'Iİ':'iİ','ıI':'ıi'},'tg':{'ıIİ':'ıiİ'}}}
cases=[]
for id in ids:
 d=r/('expanding-case-native-producer'if id in ids[:2]else'case-context-native-producer');x=json.loads((d/(id+'.json')).read_text());x['id']=id
 if id=='capital-i-dot':x['events']=['İ','a']
 elif id=='separate-combining-dot':x['events']=['i','̇','a']
 x['expected_rows']={mode:{}for mode in ['case_sensitive','case_folded']}
 for tab in ['c','bg','tg','qg','pg','hx','hp','w']:
  for mode in x['expected_rows']:
   x['expected_rows'][mode][tab]=[{'key':key if mode=='case_sensitive'else folds[id][tab][key],'count':item['c']+item['e']if tab=='w'else item['c'],'accuracy':0 if id=='corrected-i-dot'and tab=='c'and key=='İ'else 100}for key,item in x['range']['historical'][tab].items()]
 cases.append(x)
fixture={'description':'Native scalar histories and SQLite snapshots. Fixed character-token casing preserves event arity; word keys retain full-text lowercase.','app':'expanding-case.exe','timestamp':'2026-10-26 12:00:00.000','delay_ms':100,'cases':cases}
(w/'fixtures/metrics_case_projection.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
p=b/'tools/test/test-metrics-filter-cache.cjs';s=p.read_text();a='console.log(`${passed} passed, 0 failed.`);';assert s.count(a)==1
s=s.replace(a,'''const nativeCaseProjection = JSON.parse(fs.readFileSync(path.resolve(root, '../../windows/tests/fixtures/metrics_case_projection.json'),'utf8'));
assert.deepEqual(nativeCaseProjection.cases.map(vector=>vector.id),['capital-i-dot','separate-combining-dot','corrected-i-dot','greek-word-context','dotless-i']);
for (const host of ['windows','macos','linux']) {
	for (const source of ['historical','today']) {
		for (const sensitive of [true,false]) {
			for (const vector of nativeCaseProjection.cases) {
				test(`${host} ${source} keeps native case boundaries ${vector.id}, case-sensitive ${sensitive}`, () => {
					const page=loadMetricsTypingPage(host);
					freezePageClock(page,source==='historical'?'2026-10-27T12:00:00':'2026-10-26T12:00:00');
					publishTypingPage(page,host,vector.manifest);
					if(sensitive) page.elements.get('btn_case_sensitive').classList.add('active');else page.elements.get('btn_case_sensitive').classList.remove('active');
					deliverTypingManifest(page,host,vector.manifest,{range:source==='historical'?vector.range:{historical:{},today:{[nativeCaseProjection.app]:vector.range.historical}}});
					for(const tab of ['c','bg','tg','qg','pg','hx','hp','w']) {
						vm.runInContext(`app_state.current_tab=${JSON.stringify(tab)}`,page.context);
						page.context.render_current_tab();page.timers.at(-1)();
						const rows=JSON.parse(vm.runInContext('JSON.stringify(app_state.rendered_list.map(row=>({key:row.key,count:row.count,accuracy:row.acc})))',page.context));
						const expected=structuredClone(vector.expected_rows[sensitive?'case_sensitive':'case_folded'][tab]);
						const sort=items=>items.sort((a,b)=>a.key.localeCompare(b.key));
						assert.deepEqual(sort(rows),sort(expected),'case mode preserves native scalar counts, errors and n-gram boundaries');
					}
					assert.equal(page.diagnostics.some(entry=>entry.level==='error'),false);
				});
			}
		}
	}
}
assert.equal(passed,1223,'all native case-boundary and unchanged word-fold histories must execute');

test('fixed-token lowercase preserves every Unicode scalar arity',()=>{
	const fixture=typingFixture();
	assert.equal(typeof fixture.context.lowercase_metric_key,'function');
	const maxCodepoint=0x10ffff,surrogateStart=0xd800,surrogateEnd=0xdfff;
	let checked=0;
	for(let codepoint=0;codepoint<=maxCodepoint;codepoint++) {
		if(codepoint>=surrogateStart&&codepoint<=surrogateEnd)continue;
		const scalar=String.fromCodePoint(codepoint);
		assert.equal(Array.from(fixture.context.lowercase_metric_key(scalar,'c')).length,1,`U+${codepoint.toString(16)} retains one native scalar`);
		checked++;
	}
	assert.equal(checked,maxCodepoint+1-(surrogateEnd-surrogateStart+1));
});
test('metric-key case policy preserves Greek context, dotless I and full-text word keys',()=>{
	const fixture=typingFixture(),lower=fixture.context.lowercase_metric_key;
	assert.equal(typeof lower,'function');
	for(const tab of ['c','bg','tg','qg','pg','hx','hp']) {
		assert.equal(lower('İΟΣ',tab),'İος');
		assert.equal(lower('ΟΣİ',tab),'οσİ');
		assert.equal(lower('AİΣ',tab),'aİς');
		assert.equal(lower('ıIİ',tab),'ıiİ');
		assert.equal(lower('𐐀',tab),'𐐨');
	}
	for(const tab of ['w','w_bg','w_tg','w_qg','w_pg']) {
		assert.equal(lower('İΟΣ',tab),'i̇ος');
		assert.equal(lower('ΟΣİ',tab),'οσi̇');
	}
	assert.equal(lower('Ctrl+S','sc'),'ctrl+s');
});
assert.equal(passed,1225,'native case-boundary regressions and Unicode scalar policy controls must execute');

'''+a);p.write_text(s)
