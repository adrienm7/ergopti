# modules/llm/ollama_download_archive.ps1
# Finite native HTTPS archive acquisition; never executes downloaded payloads.
[CmdletBinding()]
param(
	[Parameter(Mandatory = $true)][string]$TaskManagedRoot,
	[Parameter(Mandatory = $true)][string]$ReleaseSourcePath,
	[Parameter(Mandatory = $true)][string]$ReleaseSourceSha256,
	[Parameter(Mandatory = $true)][string]$TaskAsset,
	[Parameter(Mandatory = $true)][string]$RequestTicket,
	[Parameter(Mandatory = $true)][string]$ManagedHelperPath,
	[Parameter(Mandatory = $true)][string]$ManagedHelperSha256,
	[Parameter(Mandatory = $true)][ValidateRange(1, 2147483647)][int]$TimeoutMs,
	[Parameter(Mandatory = $true)][ValidateRange(0, 2147483647)][int]$MaxRedirects
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. ([IO.Path]::Combine($PSScriptRoot, 'ollama_native_source.ps1'))
$nativeSource = Read-OllamaNativeCode $ManagedHelperPath $ManagedHelperSha256
try { . $nativeSource.block } finally { $nativeSource.stream.Dispose() }
Initialize-OllamaManagedNative
Add-Type -AssemblyName System.Net.Http | Out-Null

function Invoke-OllamaPinnedDownload($Root, $Source, [string]$Ticket, [int]$Deadline, [int]$RedirectLimit) {
	if ($Ticket -notmatch '^[0-9a-f]{32}\z') { throw 'Archive acquisition requires its originating private ticket.' }
	$stagePath = [IO.Path]::Combine($Root.path, '.stage-' + $Ticket)
	$drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($stagePath))
	if ($drive.AvailableFreeSpace -lt $Source.pin.bytes) { throw 'The complete pinned archive will not fit on the private target volume.' }
	$wal = Begin-OllamaCreationWal $Root $Source $Ticket
	$stageHandle = [IntPtr]::Zero
	$client = $null; $handler = $null; $response = $null
	$cancellation = $null; $request = $null; $body = $null; $output = $null
	try {
		$construction = Get-OllamaCreationReceipt $wal
		$construction.phase = 'creation-owned'
		[Console]::Out.WriteLine(($construction | ConvertTo-Json -Compress))
		Add-OllamaCreationRecord $wal 'stage-intent' '' ''
		[Ergopti.Ollama.ManagedNative]::CreateProtectedDirectory($stagePath, (New-OllamaPrivateSecurity).GetSecurityDescriptorBinaryForm())
		$stageHandle = [Ergopti.Ollama.ManagedNative]::OpenDirectory($stagePath, $true)
		$stageIdentity = [Ergopti.Ollama.ManagedNative]::Identity($stageHandle)
		Add-OllamaCreationRecord $wal 'stage-owned' '' $stageIdentity
		$handler = [Net.Http.HttpClientHandler]::new()
		$handler.AllowAutoRedirect = $false
		$handler.UseDefaultCredentials = $false
		$handler.UseProxy = $true
		# Reuse the current user's native system proxy, with integrated proxy
		# credentials only. No origin credentials or TLS verification overrides.
		$proxy = [Net.WebRequest]::GetSystemWebProxy()
		$proxy.Credentials = [Net.CredentialCache]::DefaultCredentials
		$handler.Proxy = $proxy
		$client = [Net.Http.HttpClient]::new($handler, $false)
		$client.Timeout = [TimeSpan]::FromMilliseconds($Deadline)
		$cancellation = [Threading.CancellationTokenSource]::new()
		$cancellation.CancelAfter($Deadline)
		$uri = [Uri]::new($Source.url)
		$redirects = 0
		while ($true) {
			if (-not $uri.IsAbsoluteUri -or $uri.Scheme -ne 'https' -or $uri.UserInfo -ne '' -or $uri.Fragment -ne '') {
				throw 'Archive redirects must remain absolute HTTPS without embedded credentials or fragments.'
			}
			$request = [Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::Get, $uri)
			$response = $client.SendAsync($request, [Net.Http.HttpCompletionOption]::ResponseHeadersRead, $cancellation.Token).GetAwaiter().GetResult()
			$status = [int]$response.StatusCode
			if ($status -in @(301, 302, 303, 307, 308)) {
				if ($redirects -ge $RedirectLimit -or $null -eq $response.Headers.Location) { throw 'Archive redirect policy refused.' }
				$uri = [Uri]::new($uri, $response.Headers.Location)
				$redirects++
				$response.Dispose(); $response = $null
				$request.Dispose(); $request = $null
				continue
			}
			if ($status -ne 200) { throw ('Archive response status refused: ' + $status) }
			break
		}
		$length = $response.Content.Headers.ContentLength
		if ($null -ne $length -and $length -ne $Source.pin.bytes) { throw 'The archive Content-Length disagrees with the captured pin.' }
		$owned = New-OllamaExtractedFile $wal $stagePath $Source.pin.filename
		$output = $owned.stream
		$body = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
		$buffer = New-Object byte[] 65536
		[long]$written = 0
		while (($count = $body.ReadAsync($buffer, 0, $buffer.Length, $cancellation.Token).GetAwaiter().GetResult()) -gt 0) {
			if ($count -gt ($Source.pin.bytes - $written)) { throw 'The streamed archive exceeds its exact pinned byte count.' }
			$output.Write($buffer, 0, $count); $written += $count
		}
		if ($written -ne $Source.pin.bytes) { throw 'The archive stream ended before its exact pinned byte count.' }
		$output.Flush($true)
		if ((Get-OllamaStreamHash $output) -ne $Source.pin.sha256) { throw 'The complete streamed archive SHA-256 disagrees with the captured pin.' }
		$receipt = Get-OllamaCreationReceipt $wal
		return [ordered]@{ ok = $true; phase = 'downloaded'; ticket = $Ticket; root_identity = $Root.identity;
			stage_identity = $stageIdentity; archive_identity = $owned.identity;
			archive = [IO.Path]::Combine($stagePath, $Source.pin.filename); bytes = $written; sha256 = $Source.pin.sha256;
			creation_wal_identity = $receipt.creation_wal_identity; creation_wal_sha256 = $receipt.creation_wal_sha256 }
	} catch {
		$failure = $_
		try { $failure.Exception.Data['ollama_creation_receipt'] = Get-OllamaCreationReceipt $wal }
		catch { [Console]::Error.WriteLine('Download refusal cannot prove its final creation journal image.') }
		throw $failure.Exception
	} finally {
		if ($null -ne $output) { $output.Dispose() }
		if ($null -ne $body) { $body.Dispose() }
		if ($null -ne $response) { $response.Dispose() }
		if ($null -ne $request) { $request.Dispose() }
		if ($null -ne $client) { $client.Dispose() }
		if ($null -ne $handler) { $handler.Dispose() }
		if ($null -ne $cancellation) { $cancellation.Dispose() }
		$wal.stream.Dispose()
		if ($stageHandle -ne [IntPtr]::Zero -and -not [Ergopti.Ollama.ManagedNative]::CloseHandle($stageHandle)) { throw 'The exact download stage retains native close debt.' }
	}
}

$downloadRoot = $null; $releaseSource = $null
try {
	$downloadRoot = Open-OllamaManagedRoot $TaskManagedRoot
	$releaseSource = Open-OllamaReleaseSource $ReleaseSourcePath $ReleaseSourceSha256 $TaskAsset
	$result = Invoke-OllamaPinnedDownload $downloadRoot $releaseSource $RequestTicket $TimeoutMs $MaxRedirects
	$releaseSource.stream.Dispose(); $releaseSource = $null
	Close-OllamaManagedRoot $downloadRoot; $downloadRoot = $null
	$result | ConvertTo-Json -Depth 12 -Compress
} catch {
	# Private transport URLs and certificate/proxy exception text stay private.
	# The physical owner receives a fixed failure, type and retained file proof.
	$failure = [ordered]@{ ok = $false; phase = 'refused'; error = 'native_archive_download_refused';
		cleanup_pending = $true; ticket = $RequestTicket; exception_type = $_.Exception.GetType().FullName }
	if ($_.Exception.Data.Contains('ollama_creation_receipt')) { $failure.creation_receipt = $_.Exception.Data['ollama_creation_receipt'] }
	$failure | ConvertTo-Json -Depth 12 -Compress
	exit 1
} finally {
	if ($null -ne $releaseSource) { $releaseSource.stream.Dispose() }
	if ($null -ne $downloadRoot) { Close-OllamaManagedRoot $downloadRoot }
}
