#!/usr/bin/env python3
"""Send genuine XTest input to one retained owned zenity process/window."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

PACKET = Path(__file__).resolve().parent
XDO = "/workspace/tooling/window-switch-native/usr/bin/xdotool"
ZENITY = "/workspace/tooling/wizard-browse-zenity-v1/usr/bin/zenity"


def process_identity(pid):
    raw = (Path("/proc") / str(pid) / "stat").read_text()
    tail = raw.rsplit(")", 1)[1].split()
    return int(tail[2]), tail[19]  # pgrp and starttime; same retained PID namespace.


def run_owned_input(args, receipt):
    oracle = json.loads((PACKET / "ORIGINAL-BROWSE-EXPECTATIONS.json").read_text())
    if args.anchor_pgid <= 1 or args.profile.is_symlink() or not args.profile.is_dir():
        raise RuntimeError("Caller-owned native session/profile is unavailable")
    expected_anchor = (args.anchor_pgid, args.anchor_starttime)
    environment = os.environ.copy()
    environment["LD_LIBRARY_PATH"] = (
        "/workspace/tooling/window-switch-native/usr/lib/x86_64-linux-gnu:"
        + environment.get("LD_LIBRARY_PATH", "")
    )
    title = oracle["original_locale_titles"][oracle["configured_profile_required_locale"]]["original_native_title"]

    def anchor_current():
        if process_identity(args.anchor_pgid) != expected_anchor:
            raise RuntimeError("Retained unreaped owner anchor changed")

    def xdo(*arguments, missing_ok=False):
        anchor_current()
        result = subprocess.run([XDO, *arguments], env=environment,
                                capture_output=True, text=True, timeout=5)
        receipt["commands"].append({"arguments": list(arguments), "exit": result.returncode,
                                    "stdout": result.stdout, "stderr": result.stderr})
        if result.returncode == 1 and missing_ok and not result.stderr and not result.stdout:
            return ""
        if result.returncode != 0:
            raise RuntimeError("Actual X11 input/observation command refused")
        return result.stdout.strip()

    def candidates():
        found = []
        anchor_current()
        for proc in Path("/proc").iterdir():
            if not proc.name.isdecimal():
                continue
            try:
                pid = int(proc.name)
                identity = process_identity(pid)
                command = (proc / "cmdline").read_bytes().split(b"\0")
            except (FileNotFoundError, ProcessLookupError):
                continue
            if identity[0] != args.anchor_pgid or command[0] != os.fsencode(ZENITY):
                continue
            windows = xdo("search", "--onlyvisible", "--pid", str(pid), "--name",
                          "^" + re.escape(title) + "$", missing_ok=True).splitlines()
            for window in windows:
                if xdo("getwindowname", window) != title or xdo("getwindowpid", window) != str(pid):
                    raise RuntimeError("Actual chooser window/PID/title changed")
                found.append((pid, identity, window))
        if len(found) > 1:
            raise RuntimeError("Native chooser ownership is ambiguous")
        return found

    deadline = time.monotonic() + 30
    selected = []
    while not selected and time.monotonic() < deadline:
        selected = candidates()
        if not selected:
            time.sleep(0.05)
    if not selected:
        raise RuntimeError("Genuine owned chooser did not become visible")
    pid, identity, window = selected[0]
    receipt["owned_window"] = {"pid": pid, "starttime": identity[1], "id": window, "title": title}

    def current():
        if process_identity(pid) != identity or candidates() != selected:
            raise RuntimeError("Retained chooser authority changed before native input")

    def key(*arguments):
        current()
        xdo("windowfocus", "--sync", window)
        if xdo("getwindowfocus") != window:
            raise RuntimeError("Owned chooser does not hold native X11 focus")
        # No --window SendEvent shortcut: xdotool's real XTest route sends
        # the keys to the genuinely focused native chooser.
        xdo(*arguments)

    if args.mode == "cancel":
        key("key", "--clearmodifiers", "Escape")
    else:
        relative = oracle["second_retry_directory_relative"] if args.mode == "retry" else oracle["accepted_directory_relative"]
        target = args.profile / relative
        if target.is_symlink() or not target.is_dir():
            raise RuntimeError("Independently predetermined owned target is absent")
        key("key", "--clearmodifiers", "ctrl+l")
        key("type", "--clearmodifiers", "--delay", "1", "--", str(target))
        key("key", "--clearmodifiers", "Return")
        # Some native folder modes first navigate, then accept. Only send
        # the second Return if the exact original chooser remains visible.
        time.sleep(0.4)
        if candidates() == selected:
            key("key", "--clearmodifiers", "Return")
    deadline = time.monotonic() + 10
    while candidates() and time.monotonic() < deadline:
        time.sleep(0.05)
    if candidates():
        raise RuntimeError("Owned chooser did not retire after genuine input")
    receipt["status"] = "INPUT_SEQUENCE_COMPLETED; receiving UNQUALIFIED"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--anchor-pgid", type=int, required=True)
    parser.add_argument("--anchor-starttime", required=True)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--mode", choices=("cancel", "accept", "retry"), required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if not args.execute:
        print("SOURCE ONLY: no native input or chooser process executed.")
        return
    receipt = {"status": "running", "mode": args.mode, "commands": [],
               "claim_limit": "input only; Root worker/file oracles must qualify receiving"}
    primary = write_failure = None
    try:
        run_owned_input(args, receipt)
    except BaseException as error:
        primary = error
        receipt.update(status="FAIL", primary_error=str(error), primary_type=type(error).__name__)
    finally:
        # Every post-argument setup/native failure reaches an independent receipt
        # attempt. A secondary write error cannot replace the raw primary.
        try:
            with args.receipt.open("x") as output:
                json.dump(receipt, output, indent=2)
                output.write("\n")
        except BaseException as error:
            write_failure = error
            receipt.update(status="FAIL", receipt_write_error=str(error))
            try:
                print(json.dumps(receipt), file=sys.stderr)
            except BaseException as log_error:
                receipt["secondary_log_error"] = str(log_error)
    if primary is not None:
        raise primary
    if write_failure is not None:
        raise write_failure


if __name__ == "__main__":
    main()
