'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const packet='/workspace/.ergopti-cloud/preparations/windows-native-desktop-source-prototype-v3';
const {sharedRunnerSource}=require(packet+'/projection/tools/lib/ahk-runner-source.cjs');
const {scriptTokens}=require(packet+'/projection/tools/lib/script-source.cjs');
const read=file=>fs.readFileSync(path.join(packet,'projection',file),'utf8');
const runner='static/ergopti_plus/windows/tests/run_all.ahk';
const tokens=s=>scriptTokens(s,'.ahk').map(t=>[t.kind,t.value]);
const original=tokens(fs.readFileSync(path.join(__dirname,'original-e896-run_all.ahk'),'utf8'));
assert.deepEqual(tokens(sharedRunnerSource(read,'run_all.ahk')),original);
const anchor='#Include unit/test_curl_proxy_auth_integration.ahk\n',incoming='#Include unit/test_curl_proxy_discovery.ahk\n';
for(const [name,modified] of [['omitted',read(runner).replace(incoming,'')],['moved',read(runner).replace(anchor+incoming,incoming+anchor)]]){
 assert.throws(()=>assert.deepEqual(tokens(sharedRunnerSource(file=>file===runner?modified:read(file),'run_all.ahk')),original),{name:'AssertionError'});
}
console.log('PASS: complete e896 runner token/order identity; omission and name-preserving reorder CAUSAL RED; no native execution.');
