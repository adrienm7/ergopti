# Canonical Windows route source investigation

This is a SOURCE-ONLY diagnostic proposal, not a production repair or qualification.
No tests, native calls, suites, Git mutations or main-checkout edits were run.

## Established source facts

- `Resolve-ErgoptiNativeNetworkRoutes` has four successful paths: loopback,
  environment, static configuration, and native automatic routes. A successful
  one-route receipt alone does not distinguish them.
- The canonical function passes the original `DestinationUrl` string to
  `ErgoptiNativeProxyEx.Resolve`. Its C# entry passes that same `url` to
  `WinHttpGetProxyForUrlEx`. Neither source truncates path, query, scheme or port.
- The C# receiver loops over every `nativeResult.Count` and copies every entry;
  the PowerShell receiver loops over every returned entry. No truncation to one
  was found in these sources.
- Fixture vector 1 requires three routes. Its PAC matches a single exact full
  HTTPS URL and otherwise returns DIRECT. A one-entry native DIRECT could mean
  the exact PAC condition did not match, but current evidence does not establish
  that the receipt came from the native branch.
- Microsoft pinned sdk-api `c12073e417d5780fe796278ada21b90cef1b0568`
  `nf-winhttp-winhttpgetproxyforurlex.md` explicitly documents the full PAC list,
  including DIRECT, and per-URL invocation. Pinned SDK flags identify existing
  0x00080000/0x00100000 as NO_CACHE_CLIENT/NO_CACHE_SVC. Neither is result sorting.
  No documented path-stripping remedy was found. Do not change API flags or
  loosen full-URL expectations on speculation.

## Minimal evidence needed

The proposal projects only closed first-route Source and Kind when the actual
returned receipt is a hashtable with exactly one hashtable route. Every projected
source comes from the production source vocabulary. Endpoint/URL/PAC/exception
text is never emitted. The AHK parser validates the same closed vocabulary and
rejects a single-route projection attached to any other route count.

- `native_direct` + `direct` establishes that the one route came from the actual
  native list, not a local/static/environment bypass. It still does not establish
  why the PAC expression matched or failed: preserve the original full-URL
  assertions and diagnose actual native PAC input next.
- `system_direct` or `system_config_absent_direct` establishes the configuration
  path was static; inspect the injected reader's actual primitive shape and PAC
  presence under the same owned fixture.
- `loopback` or `environment*` identifies earlier admission paths.
- `unknown` retains uncertainty instead of assigning a cause.

The proposal changes only the existing optional diagnostic helper, failure frame,
and existing AHK failure-frame receiver. Actual native providers, original
acceptance body, PAC bytes, ABI guards, assertions, captures, clocks and retirement
are unchanged.

## Required receiving validation (UNRUN)

1. Check packet preimages, whole-file inverse, LF and the preserved AHK BOM.
2. Extract `Set-ManagedRoutesDiagnosticResult` via the genuine PowerShell parser
   from the frozen proposed fixture (do not execute the native fixture on Linux).
   Call that actual helper with independent hashtable/array/primitive controls:
   every production source; native/direct versus system/direct; mixed-case and
   arbitrary sources/kinds; malformed route entries; count zero/two; reset after
   valid result. Assert closed values and no private source/endpoint reflection.
3. Exercise the actual AHK regex and structural guards through the existing
   independent Node model; native and static valid frames; source/kind casing,
   delimiters, duplicate frames, out-of-range counts and non-single projections.
   Model success is not AutoHotkey or WinHTTP qualification.
4. Run verify-change, encoding checks and targeted Windows workflow_dispatch.
   Observe unchanged original assertions and physical fixture/tree retirement.

No genuine Windows producer or new production behavior is credited by this packet.
