from pathlib import Path
import subprocess,os,json,time,hashlib,datetime,stat
r=Path('/workspace/ergopti-macos-layout-owner-oracle');s=Path('/workspace/scratch/oct28-final34-common');env=dict(os.environ)
env['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/sqlite-native-audit3/usr/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:/workspace/toolchain/powershell:'+env['PATH']
env['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu'
env['USER']=env['LOGNAME']='agent'
for key,name in [('TMPDIR','tmpdir'),('XDG_RUNTIME_DIR','xdg_runtime_dir'),('XDG_CACHE_HOME','xdg_cache_home'),('XDG_CONFIG_HOME','xdg_config_home'),('XDG_DATA_HOME','xdg_data_home'),('XDG_STATE_HOME','xdg_state_home')]:
 p=s/name;p.mkdir(exist_ok=True,mode=0o700);env[key]=str(p)
manifest=json.loads(Path('/workspace/scratch/oct28-bsd-writer-assembly/manifest-go.json').read_text());rows=[]
expected='22d4937c6b77a68ed1c3ac6af74418063dc31b4c'
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
def physical(label):
 count=total=0;dg=hashlib.sha256();bad=[]
 for entry in git('ls-files','--stage','-z').split(b'\0'):
  if not entry:continue
  inf,path=entry.split(b'\t',1);mode,oid,stage=inf.split();p=r/os.fsdecode(path);st=p.lstat();data=os.fsencode(os.readlink(p))if stat.S_ISLNK(st.st_mode)else p.read_bytes()
  actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode();observed=b'120000'if stat.S_ISLNK(st.st_mode)else(b'100755'if st.st_mode&0o111 else b'100644')
  if actual!=oid or mode!=observed:bad.append(os.fsdecode(path))
  dg.update(mode+b' '+oid+b'\t'+path+b'\0');count+=1;total+=len(data)
 result={'label':label,'index_tree':git('write-tree').strip().decode(),'entries':count,'bytes':total,'digest':dg.hexdigest(),'mismatches':bad,'unstaged':git('diff','--name-only').decode(),'untracked':git('ls-files','--others','--exclude-standard').decode()};(s/('physical-'+label+'.json')).write_text(json.dumps(result,indent=2)+'\n');assert result['index_tree']==expected and not bad and not result['unstaged'] and not result['untracked'],result
 return result
initial=physical('initial')
def run(name,command):
 assert git('write-tree').strip().decode()==expected
 start=time.monotonic();t=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).isoformat()
 with(s/(name+'.log')).open('wb')as f:
  p=subprocess.Popen(command,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);(s/'active.json').write_text(json.dumps({'pid':p.pid,'name':name,'command':command,'started_paris':t})+'\n');rc=p.wait()
 row={'name':name,'command':command,'actual_exit':rc,'seconds':round(time.monotonic()-start,3),'started_paris':t,'finished_paris':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).isoformat(),'log':str(s/(name+'.log'))};rows.append(row);(s/'gates.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,rc,flush=True);assert git('write-tree').strip().decode()==expected
 return rc
assert os.getuid()!=0
for gate in manifest['toolchain']['preflight']:assert run(gate['name'],gate['command'])==0
assert run('inventory',['node','tools/test/run-js-suite.cjs','--list-features'])==0
inv=json.loads((s/'inventory.log').read_text());assert inv['planned_count']==529,inv
previous_inv=json.loads(Path('/workspace/scratch/oct28-final32-common/inventory.log').read_text());assert inv==previous_inv,(inv,previous_inv)
for gate in manifest['producers']['common']['gates']:run(gate['name'],gate['command'])
run('false-green',['node','tools/test/find-false-greens.cjs'])
final=physical('final');receipt={'source':json.loads((s/'source.json').read_text()),'gates':rows,'inventory':inv,'physical_initial':initial,'physical_final':final,'all_actual_exit_zero':all(x['actual_exit']==0 for x in rows),'native_darwin_executed':False,'scope':'One canonical full JS run plus explicit common gates. Failures are retained without retries, baseline changes or skipped tests.'};(s/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(s/'active.json').unlink();raise SystemExit(0 if receipt['all_actual_exit_zero']else 1)
