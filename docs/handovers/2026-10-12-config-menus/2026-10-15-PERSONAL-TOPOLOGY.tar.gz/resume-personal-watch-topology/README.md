# Linux Personal watcher topology receiving packet

This packet contains the reviewed, externally tested proposal for exactly two paths:

- `static/ergopti_plus/linux/infra/file_watchers.lua`
- `static/ergopti_plus/linux/tests/unit/meta/test_file_watchers.lua`

The baseline is published commit `b666a22f72cf3b27e55bef08720f7064348d1d40`. The final producer is `candidate3-prepared.lua` (SHA256 `ce210bf735981a45015458d49bf09422f588b8f8707edb0bf663a9240683f768`). The final complete independent test image is `tests-83.lua` (SHA256 `d14677ca2fd8f79acdb973e4ea4d7f76b4a896e08890bf91b833bbf9d2a73f6c`). `preimages.json` records both literal and proposed hashes; `proposal.patch` applies to the two literal preimages. An external `git apply --check` succeeds. No canonical checkout was modified by this packet builder.

The entire original 38,693-byte, 49-subject test module is an identical prefix. The final body adds 34 hand-authored subjects; it was not generated from the implementation. SHA256SUMS covers every other archive member. The archive deliberately omits the duplicate dependency capture and package caches.

## Production defect and bounded change

The original native Personal directory watcher filters directory names out as non-TOML. Pump mode can observe the original parent-directory mtime change but neither backend extends its initial recursive coverage. A moved-in populated tree or a directory created after startup therefore lacks later descendant observation. The daemon's actual reload callback reloads Hotstrings configuration without rearming these handles.

The proposal reconciles only Personal coverage at the existing settled deadline. Native directory-topology receipts and pump directory-mtime changes request a classified census; ordinary in-place file edits and idle pumps do not recursively enumerate. New directory bindings are active before their contents are listed. Changes during staged admission rearm debounce. Lexical Linux path keys remain case-sensitive and preserve literal backslashes; binding device/inode/kind detects replacements. Depth16 and existing symlink backend policies remain bounded as before.

A failed census or binding activation retains healthy prior coverage and retires only staged entries. An accepted real burst still calls the existing reload consumer, including independent main/base events. Coverage-only retries have their own bounded deadline and do not repeatedly reload during refusal. A successful retry that adds or rebinds previously unobserved coverage schedules one fresh settled read, deduplicated with any pending real burst, so bytes changed during the refusal are consumed. A healthy no-delta retry adds no notification.

Personal coverage has its own exact-entry/session admission guards and retirement ledger. Close request success does not imply async close acknowledgment; failed stop/close remains owned for repair. Initial construction, ordinary deadline reconciliation and retry paths fence successor generations before further scheduling or root continuation. Main Hotstrings/base roles remain distinct even if their path overlaps Personal.

New filesystem shell operations use unchanged `adapters.shell_runner.exec_checked` and its sole `quote` function. Native no-POSIX metadata uses existing luv.fs_stat rather than spawning a shell for every unknown event. Actual native refusal is not reclassified as absent capability. The listing fallback uses GNU `ls --zero` and validates NUL framing, invalid members and duplicates. Legal LF basenames therefore do not poison the complete census.

`M.stop()` now returns the state of the Personal retirement ledger only. Its boolean does not acknowledge generic-root shutdown; those historical paths and their current callers remain unchanged. This is not a global owner lifecycle rewrite. Root disappearance still delivers its already accepted burst; creating a new parent anchor to observe root recreation is excluded. Explicit empty-Personal start shapes retain historical narrow behavior.

## Final identical-corpus results

All final phases use the exact same frozen 83-subject file. The runtimes are Lua5.4.7 and LuaJIT2.1.1737090214. Both backends operate on independently seeded real temporary files; `native` uses actual luv/inotify, and `pump` explicitly disables the module's luv backend while the fixture uses luv only for its real filesystem, clock wait and owned cleanup.

| Phase | Lua5.4 | LuaJIT | Exit |
| --- | --- | --- | --- |
| Literal unchanged producer, final83 corpus | 55 passed / 28 failed | 55 passed / 28 failed | 1 each |
| Full proposed producer, final83 corpus | 83 passed / 0 failed | 83 passed / 0 failed | 0 each |
| 11 focused protection withdrawals | All expected named failures | All expected named failures | 1 each child |
| Full restored producer, final83 corpus | 83 passed / 0 failed | 83 passed / 0 failed | 0 each |

No final subject was skipped. Original49 names and their passing prefix match in the literal, candidate and restored logs. `final-matrix.json` has all26 naturally terminal child results, their commands, exact source/corpus/log hashes and named failures. `receiving-receipt.json` independently rechecks those artifacts. The literal final83 receipts are `literal83-lua54-status.json` and `literal83-luajit-status.json`.

The 22 narrow negative children select subjects from the same complete final83 file; no new smaller assertion corpus was generated. Their exact named failures are recorded in `receiving-receipt.json`. Each row below ran on both engines, with zero passing selected subjects:

| Source protection withdrawn | Expected failed subjects per engine |
| --- | ---: |
| Distinguish refused directory listing from empty data | 2 |
| Refuse duplicate listing entries | 1 |
| Preserve accepted callbacks during Personal refusal | 1 |
| Notify consumer after repaired unobserved coverage | 1 |
| Keep retirement ownership until actual ACK | 1 |
| Retry retained stop/close ownership | 2 |
| Reject obsolete callback admission | 1 |
| Fence runtime reconciliation generation | 1 |
| Fence initial construction generation | 1 |
| Rearm debounce for staged directory activity | 1 |
| Preserve LF names with exact NUL census | 2 |

These intentional source mutants are external images, never published implementation. The complete candidate is restored before both final83 restored passes; no per-withdrawal full-suite repetition was needed.

## Preserved earlier cohorts, rejected premises and fixture mistakes

All earlier source images, independent corpus revisions, stdout/stderr and status files are retained, including failures and noncausal evidence. They do not replace the final same-corpus results.

1. The initial66 cohort is `candidate1-tests.lua` = `literal-tests.lua` + `added-tests-v1.lua`. Literal Lua5.4/JIT both51/15; candidate1 Lua5.4 was66/0. `candidate1-preservation.json` pins the sealed first images and initial receipts. Some old-producer safeguard tests failed before reaching their injected refusal; those results establish the broader topology defect, not each individual protection.
2. The72 cohort (`added-tests-v2.lua`, full reconstructed `tests-72-rejected-reentry.lua`) initially used a new module instance in its generation helper. `candidate1-generation-lua54` was1/0 but is NONCAUSAL: the old owner was never pumped again. The corrected same-module helper (`added-tests-v3.lua`, `tests-72-same-owner.lua`) gives candidate1 zero passes/one failure in `candidate1-same-owner-generation-lua54`.
3. Two newly added refusal cases initially expected `settle(0)` to suppress an already accepted normal callback. Source review with the parent established this would change existing admission policy and block unrelated roots. Only these new mistaken premises were corrected to preserve the accepted callback, retain prior file coverage and require a repaired-coverage notification. The original49 never changed. Earlier72 literal both51/21 and later77 literal both52/25 receipts remain as historical cohorts. `revise-tests-v4.py` records the independent expectation correction; `tests-77.lua` preserves the resulting intermediate corpus.
4. The80-case draft (`added-tests-v5.lua`, `tests-80-fixture-typo.lua`) called nonexistent `helpers.assert_false` in its new ACK case. `candidate2-v5-lua54` is79/1 from that fixture typo. It was corrected to `assert_eq(result, false)`, preserving the predicate. That older ACK failure is not causal. The corrected80 image is `tests-80.lua`; literal both53/27, candidate2 Lua5.4 80/0. There is no claimed candidate2 JIT80 result.
5. Independent review found initial constructor reentry could let the obsolete stack arm its old base root. The added81 constructor case gives candidate2 zero passes/one failure (`candidate2-initial-generation-lua54`). Final code adds the immediate epoch abort before retry/base mutation.
6. Independent review also found legal LF basenames made the new authoritative line-based census refuse ALL Personal coverage, unlike the old partial scan. Two real no-POSIX LF-sibling controls give candidate2 zero passes/two failures (`candidate2-lf-lua54`). Final code changes only the checked command to NUL output and parser; the new fault selector matches the unchanged stable command prefix so both producer versions are received. No assertions were weakened. These controls plus the constructor case make the final83 corpus.

Historical assembly/delta scripts are included for audit. They are not application artifact generators and may rely on their recorded prior images; authoritative frozen source/corpus bytes and receipts take precedence. `personal-implementation.lua` is the initial fragment only, not an accepted final producer.

## Reproduction and dependency provenance

`source-manifest.json` identifies all2,361 tracked files captured from baseline commit b666a22. At packaging time every dependency byte remains identical, with no extra or missing files; only the two owned files carry their declared final images. Rebuild the external dependency tree with `git archive b666a22f72cf3b27e55bef08720f7064348d1d40 static/ergopti_plus/linux static/ergopti_plus/_shared`, validate the manifest, then overlay the chosen producer and frozen test image. No duplicate full source tree is in the archive.

The recorded runner is `/workspace/.ergopti-cloud/resume-personal-watch-topology/runner.lua`; it prepends only the external Linux/shared modules, installs the existing UTF8 compatibility adapter, optionally applies a subject filter, prints Helpers JSON and returns failure status. Relocating the packet requires updating that external source-root location. `run-final-matrix.py` records the exact final mutation/runner commands and enforces frozen corpus/source hashes around every naturally terminating child. It restores the full producer in `finally`.

The environment used `. /workspace/.ergopti-cloud/activate.sh` and `TMPDIR=/var/tmp/ergopti-cloud-validation`; the private temporary directory execution required the environment's standard sandbox escalation. Version commands are in `receiving-receipt.json`. No topology fixture directories remain at the packet checkpoint. Every native test handle belongs to that private session and is explicitly retired; no broad process termination or unrelated filesystem cleanup was used.

## Evidence limits and independent review

Real directory creation, moves, deletion, in-place edits, atomic replacement, native events, per-file bindings and actual close completion are exercised. Fault ports intentionally simulate listing/activation/stop/close/capture refusals while retaining real resources. Same-module reentry, stale/nil callback replay and withheld ACK delivery are explicitly controlled source-boundary models. They do not claim the kernel naturally produced that failure or reentrant schedule. Artificial debounce-clock advancement is not wall-clock timer qualification.

This owning-module packet does not qualify the whole daemon, actual Hotstrings engine, installed application, packaging, input device or an installed OS. Callback byte-consumer checks prove observation freshness, not keyboard expansion acceptance. GNU coreutils9.7 supports the tested NUL command; other installed target distributions/versions remain unqualified. Root disappearance/recreation anchor coverage remains a separate lot. No claim of Group1 completion or TODO closure is made.

The parent and `resume_menus` independently approved the frozen final producer/test source within this scope. Their source review is separate from executed results. The parent will append canonical full-gate/CI/publication results separately; none are fabricated in this packet.
