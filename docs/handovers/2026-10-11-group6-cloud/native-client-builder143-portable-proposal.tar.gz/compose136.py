import ast,hashlib,json
from pathlib import Path
BASE=Path(__file__).resolve().parent
FROZEN=BASE.parent/'group6-native-http-builder136-enrollment-proposal'
REPAIR=BASE.parent/'group6-r2-canonical-order-repair/candidate'
INDEPENDENT=BASE.parent/'group6-native-http-callee103-independent-proposal/candidate'
DEST=BASE/'canonical136'
TEST='tools/test/macos_native_http_receiving_facts_test.py'
REG='tools/test/test-managed-ollama-protocol.cjs'
HELPER='tools/test/macos_native_http_fixture_builder_controls.py'
original=(REPAIR/TEST).read_text()
assert hashlib.sha256(original.encode()).hexdigest()=='3f9d04684b5e3c72f362bdc2aabf59ef10475d2402482ab1bde72121316addc1'
frozen=(FROZEN/'candidate'/TEST).read_text(); prior=(FROZEN/'preimage'/TEST).read_text()
# Recover only the exact old additive module-level enrollment.
start=frozen.index('# Fixed-path independent-builder portable enrollment.')
end=frozen.index('if __name__ == "__main__":',start)
entry=frozen[start:end]
assert frozen.replace(entry,'',1)==prior
composed=original.replace('if __name__ == "__main__":',entry+'if __name__ == "__main__":',1)
def bodies(s):
 lines=s.splitlines(True)
 return {(n.lineno,n.name):''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.FunctionDef)}
assert list(bodies(original).values())==list(bodies(composed).values())
for rel, content in [(TEST,composed.encode()),(REG,(FROZEN/'candidate'/REG).read_bytes()),(HELPER,(FROZEN/'candidate'/HELPER).read_bytes())]:
 p=DEST/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
# Exact declared builder graph and native caller subjects, copied outside checkout.
builder_source=(INDEPENDENT/'static/ergopti_plus/macos/tests/support/native_http_fixture_builder.py').read_text()
# Finite constant graph parsed without importing the test/helper or native subjects.
mac='static/ergopti_plus/macos/'
paths=[mac+'launcher/Sources/ErgoptiPlus/'+s for s in ['ManagedHTTPWorker.swift','ManagedPACSource.swift','ManagedCertificateAuthorities.swift','ManagedBootstrapPolicy.generated.swift']]
paths+=[mac+'tests/support/native_http_fixture_main.swift']
paths+=[mac+'launcher/Sources/CPOSIXCompatibility/include/'+s for s in ['CPOSIXCompatibility.h','OwnedProgramCompatibility.h','LoopbackListenerCompatibility.h','OwnedImageAliasCompatibility.h','OwnedSuspendedImageCompatibility.h','OwnedListenerEventCompatibility.h']]
paths+=[mac+'platform/network/native_http.py',mac+'platform/network/managed_http.py','static/ergopti_plus/_shared/python/network_proxy_policy.py','static/ergopti_plus/_shared/modules/network/proxy_policy.json',mac+'tests/support/native_http_fixture_builder.py',mac+'tests/support/native_http_wire_fixture.py','tools/diagnostics/macos_owned_process.py',mac+'tests/support/native_http_wire_client_receiving.py']
for rel in paths:
 src=BASE/'prospective-candidate'/rel
 if not src.is_file():src=INDEPENDENT/rel
 if not src.is_file():src=Path('/workspace/ergopti')/rel
 p=DEST/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(src.read_bytes())
(BASE/'canonical136-source-review.json').write_text(json.dumps({'repaired103_preimage_sha256':hashlib.sha256(original.encode()).hexdigest(),'owning136_postimage_sha256':hashlib.sha256(composed.encode()).hexdigest(),'all103_function_spans_exact':True,'helper33_source_exact':True,'fixed_enrollment_span_sha256':hashlib.sha256(entry.encode()).hexdigest(),'native_credit':False},indent=2)+'\n')
