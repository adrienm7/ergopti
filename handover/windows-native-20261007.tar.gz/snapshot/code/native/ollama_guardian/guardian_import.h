#ifndef ERGOPTI_GROUP4_GUARDIAN_IMPORT_H
#define ERGOPTI_GROUP4_GUARDIAN_IMPORT_H
#include <stdint.h>
#include <stddef.h>

typedef enum {
    GI_EMPTY = 0, GI_ACQUIRING = 1, GI_PREPARED = 2,
    GI_EXPORTED = 3, GI_ABORTED = 4, GI_RESOURCE_DEBT = 5
} GI_Phase;

typedef struct {
    uintptr_t source_handle;
    uint32_t kind;
    uint64_t volume;
    uint64_t index;
    const uint16_t *native_path;
    size_t path_units;
    uint8_t sha256[32];
} GI_Expected;

typedef struct {
    uintptr_t handle;
    uint32_t attempted;
    uint32_t uncertain;
} GI_Imported;

typedef struct {
    void *context;
    void *(*allocate)(void *, size_t);
    void (*release)(void *, void *);
    int (*duplicate_source)(void *, uintptr_t, uintptr_t *);
    int (*duplicate_content)(void *, uintptr_t, const GI_Expected *, uintptr_t *);
    int (*validate_content)(void *, uintptr_t, const GI_Expected *);
    int (*close)(void *, uintptr_t);
} GI_Port;

typedef struct {
    uint64_t id;
    GI_Phase phase;
    uint32_t initialized;
    uint32_t first_error;
    uintptr_t source;
    uint32_t source_close_attempted;
    uint32_t source_close_uncertain;
    GI_Imported *contents;
    size_t count;
    size_t acquired;
    GI_Port port;
} GI_Row;

/* Called only on a server-allocated zero row, before native acquisition. Paths
   and expected inventory remain borrowed through this synchronous constructor.
   The native port must validate process/full creation, type, identity, complete
   path and file digest; this core does not authenticate supplied inventory. */
int GI_Begin(GI_Row *, uint64_t, uintptr_t, const GI_Expected *, size_t, GI_Port);

/* Export is irreversible. A row that donated capabilities to a guardian must
   not use Abort to close them; the actual guardian owns terminal retirement. */
int GI_MarkExported(GI_Row *);

/* Before Export only: resources have never been exposed to a runtime consumer.
   Each native close is attempted once. Any refusal retains the resource row. */
int GI_Abort(GI_Row *);
#endif
