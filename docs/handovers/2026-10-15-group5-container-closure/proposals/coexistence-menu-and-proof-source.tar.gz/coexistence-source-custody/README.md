# Inert coexistence source custody handover

This is source and review preservation, not a product patch adoption or native qualification. Read LIMITS.json first. INDEX.json maps each original private reference to its included exact body in BLOBS/. Absolute references in preserved original receipts are historical locators, not required dependencies outside this archive. Full source PRE/POSTs, patches, frozen corpora, review bodies and controlled receiving receipts are included once by SHA256.

Reviewed coexistence composition has 37 distinct paths. The two Root Layout proof files and one guardian file are separate proposals. Proof2 natural parity failed after the original Layout assertion passed; historical matrix join remains incomplete despite its separate finite independent source review. Root owns any adoption. Proof2 finite source review1d5ed09e and actual terminal failure6523b5ac are both included. No active stock mutator is supplied. All native behavior remains UNRUN.

Use `python3 verify.py` after extracting. `python3 body.py ORIGINAL_REFERENCE` emits that exact retained source/receipt body without importing application code.
