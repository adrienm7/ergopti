﻿; _generated/ollama_release.ahk
; AUTO-GENERATED from _shared/modules/llm/ollama_release.json.
; DO NOT EDIT BY HAND — run `node tools/codegen/codegen-ollama-release.cjs`.
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Pinned Ollama Windows Release
; DESCRIPTION:
; Returns a fresh closed asset record from the canonical cross-driver release.
; No mutable global initializer, download, installation or process is acquired.
; ==============================================================================

/** Returns the pinned official archive for one exact Windows asset identity. */
OllamaReleaseWindowsAsset(AssetId) {
	if !(AssetId is String) || !(AssetId == "windows-amd64" || AssetId == "windows-arm64")
		throw ValueError("Pinned Windows Ollama asset identity is unavailable.")
	switch AssetId {
		case "windows-amd64":
			return Map("asset_id", "windows-amd64", "version", "0.24.0",
				"filename", "ollama-windows-amd64.zip", "sha256", "40c523d3eeba6f4647c5ca58fe47f15b8dee79f7675ebf573458890064f424c7",
				"bytes", 2069313829, "url", "https://github.com/ollama/ollama/releases/download/v0.24.0/ollama-windows-amd64.zip")
		case "windows-arm64":
			return Map("asset_id", "windows-arm64", "version", "0.24.0",
				"filename", "ollama-windows-arm64.zip", "sha256", "f248475a81a7dcd841a32e1f6c06c83310c893c49c4bdf7da8c10f3eef27231a",
				"bytes", 24673830, "url", "https://github.com/ollama/ollama/releases/download/v0.24.0/ollama-windows-arm64.zip")
	}
}

/** Returns inclusive extraction limits from the canonical Windows policy. */
OllamaWindowsArchivePolicy() {
	return Map("MaxExpandedBytes", 17179869184, "MaxEntries", 65535)
}
