# Current dev macOS fixture qualification repair

Exact base: a550193ebc31aa819c369f701a61ebed72d86216. Three-path preparation only; no root changes or refs.

All eleven CI fixture failure names reproduce on current source. Actual focused errors identify leaked `compat.utf8`, which shared `text_utils/init.lua` now requires unconditionally at line 12. The new dependency was introduced in commit `1d34df085` to preserve strict UTF-8 provider error boundaries. Neither `number_policy` nor `error_description` is involved in this causal trace.

Before correction: gesture scope 2 passed/9 failed; tooltip renderer scope 1 passed/1 failed; typing scenario scope 1 passed/1 failed. Each failed on an unchanged exact module-cache restoration assertion reporting compat.utf8.

Restoring only the exact shared text utility preimage from `1d34df085^` makes the same three unchanged modules pass 11/0, 2/0, 2/0. Reinstating current production bytes and adding compat.utf8 to each existing fixture owner list also yields 11/0, 2/0, 2/0. This retains all production UTF-8 fixes and every original fixture assertion and scenario-count floor. Each fixture differs by exactly one owner-list line; removing that line recovers every original fixture byte.

The focused runner performs the same optional lfs discovery preload as macOS tests/run.lua:111 before scenario snapshots. Without that actual-runner setup, a cold isolated metrics replay also reports lfs loaded by the repository native stub; that is a harness setup difference and was not hidden by weakening assertions or adding unrelated fixture ownership. Original cold baseline, explicit discovery runner and exact-source inverse logs are retained.

Qualification: focused Mac unit modules under Lua 5.4 with repository native stubs only. No full suite, native macOS device, Windows/Linux suites, packaging/install or CI was run by this reviewer. The separate parse_notes_control_escapes failure remains outside this three-fixture correction. Parent owns root application, review and integrated CI.
