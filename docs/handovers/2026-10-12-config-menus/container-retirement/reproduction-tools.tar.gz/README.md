# Preserved cloud reproduction tools

This capsule contains exactly three historical source scripts plus this README
and SHA256SUMS. It contains no SDK, binary, downloaded package, key material,
credential, personal configuration or actual user log. All entries are regular
source files stored with mode 0644; invoke shell and Python scripts explicitly.
Verify `sha256sum -c SHA256SUMS` after extraction into a new owned directory.
Do not extract directly over an existing project or setup prefix.

## Fixed paths and relocation

The tested layout is `/workspace/ergopti` for the repository and
`/workspace/.ergopti-cloud` for the isolated setup, package and runtime prefixes.
`install-with-gtk.sh` explicitly changes to that repository. `activate.sh`
selects Node v22.22.2 and the original extracted Lua/Python tools there.
The native HTTP replay's BASE, APT paths and expected APT configuration/source
hashes also bind that exact layout. Retain these original files unchanged for
provenance. They are not generic installers for arbitrary mount paths.

For another layout, first prepare a separately reviewed source adaptation and
new authenticated receipts. Do not substitute paths inside this capsule and
continue claiming its hashes or historical qualification. In a fresh matching
layout, compare existing targets before placing these three sources in the
setup root; preserve any pre-existing different file or active prefix.

## Received installer execution

The exact `install-with-gtk.sh` with SHA-256
`d0001f511181bf5c7c527fb5dd9ca2e2aede5c6209d8d6ecc60a6c3a3a7bd68c`
was actually executed in the original Debian trixie amd64 cloud container and
exited 0 on 2026-10-15 at 01:26:03 UTC. The subsequent tool check passed with
Node v22.22.2, Ruff 0.15.8, Lua 5.4 and LuaJIT 2.1.1737090214. Its native GTK
smoke also exited 0 with the WebKit sandbox enabled. The closed execution log
hash is `eeeaa815f57ada865c4a365bfa31741ed608a961d82510190f943ba58fc68858`;
the smoke log hash is
`c8dc095a3f583e2091273c59da1ae8698dc9549b3f2d3fef3661b371d3bbb6cf`.

The installer embeds the exact GTK install script, activation, overlay builder,
wrapper and signed-index package metadata. It builds isolated extracted
prefixes and invokes the repository's canonical tooling. It relies on the
original host's base Python/uv/curl/APT/dpkg, Debian public archive keyring and
GTK/GI/DBus/bwrap facilities. Its 26 GTK packages were an additive closure for
that inspected host, not a complete distribution-independent OS bootstrap.
Historical execution in that retained container is not a successful fresh
restoration test after container deletion. Network/package availability and the
current source owners must be re-admitted; do not bypass signature or pin checks.

## Native HTTP replay boundary

The exact `native-http-replay-20261015.py` with SHA-256
`1b9e36ce3cbda426ee064b813fc17e4a9e85441a70869a37abad4209ab7a270a`
embeds the 18 authenticated SDK package identities and six canonical source/pin
hashes. The existing-prefix `readmit` mode was actually verified: exit 0 in
1.144878252 seconds, 776 effective SDK payloads and all 7,185 retained entries
unchanged. Both curl versions and the original legacy signature were received.
The retained trusted tool-admission digest was
`3dfe9522e30cfb64a7419b6a0a3acb67e5cd8fc125c59e514e49f958c773d224`.
That digest identifies the original existing prefix; it is not authority for a
newly reconstructed prefix and cannot replace missing native material.

The `create` mode is REVIEWED AND UNEXECUTED. It documents reconstruction into
a NEW owned prefix using signed APT and unchanged canonical preparation owners;
it refuses an existing destination. It requires a real OpenSSL development SDK
under `/usr`, standard host build tools and the signed APT layout described
above. Exact package rotation, changed pins or missing prerequisites cause
refusal. It must receive its own actual setup, admission, native gate and
installation results. Neither `create` nor a fresh restoration is qualified by
the historical `readmit` result. No private validation keys are preserved here;
use the canonical preparation owners to obtain fresh owned validation material.

## Existing public evidence and metadata

All paths below are relative to
`docs/handovers/2026-10-12-config-menus/` in the repository:

- `2026-10-15-receiving.tar.gz`, SHA-256
  `4e386dc676f1af80b4704d6d516d10e7a824a192b325fd6cd24e907464c34afb`,
  already retains exact `local/activate-gtk.sh`, `local/run-with-gtk.sh` and
  `local/build-gtk-overlay.py` sources.
- `2026-10-15-DIAGNOSTIC-OPENER-RECEIVING.tar.gz`, SHA-256
  `f16054c9e655e030dc9da99f14e05381d67dbaea1afcb8e8acead01bc19d22a6`,
  retains `environment/native-http-replay-20261015-README.md`, the actual
  replay receipt, both native HTTP activation scripts, `sdk-packages.json`
  and `FINAL-PREREQUISITES.json`. Consult those dated commands and boundaries.
- `2026-10-15-RELOAD-AND-DIAGNOSTICS-RECEIVING.tar.gz`, SHA-256
  `26e326a2701ef257b2639a4ab091e91ec537d255027dc10415321a91586c05ae`,
  retains later source-bound local/hosted results and `receipts/resume18-sdk-readmission.json`.
  Passed and failed runs remain separate; none qualifies a future environment.

The six canonical preparation/reader sources are already tracked in the
repository: `tools/test/fixtures/validation-curl/prepare_validation_keyring.py`,
`setup_validation_curl.py`, `PINS.json`, `tools/test/linux-managed-http-evidence.cjs`,
`tools/build/stage-linux-network-runtime.py` and
`tools/test/run-linux-managed-http-native.cjs`. Keep their actual source pins;
this capsule does not replace or modify those owners.
