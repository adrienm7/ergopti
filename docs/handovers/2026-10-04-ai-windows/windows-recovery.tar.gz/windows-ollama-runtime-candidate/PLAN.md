# Windows user-local Ollama runtime candidate

This is a scratch preparation, not an integrated or qualified feature. Nothing
here starts Ollama, downloads a release, installs software, edits the driver, or
changes its menus or configuration. The AHK owner and PowerShell launcher have
not been parsed or executed on Windows.

## Existing owners and the narrow native boundary

`windows/adapters/shell_runner.ahk` already provides
`ShellRunner_SpawnTreeOwned`: the executable starts suspended, joins its exact
kill-on-close Job Object before it resumes, inherits only explicitly listed
stream handles, and retains native/capture cleanup debt. Its public task handle
has `start`, `terminate`, `requestTerminate` and `detach`. `terminate() == true`
means zero job descendants were confirmed; false is retained debt, including
cancellation while native construction is still in progress. Do not reopen a
PID, kill by executable name, detach a daemon, or add another process stack.

The accompanying `ollama_runtime_owner.ahk` candidate owns only that exact
long-lived task. It accepts an explicit consent ticket and a captured executable,
models directory and canonical configured loopback port. It does not enable AI,
install a model, claim HTTP readiness, or acquire any private request file. Its
trusted `ollama-runtime-launch.ps1` sets the host/models environment in the
child, then invokes `ollama serve` in the foreground. That avoids changing the
driver's environment, which other native launches inherit, and keeps the server
and its model-runner descendants in the existing job. Output goes to NUL instead
of accumulating an unbounded ShellRunner capture. The final component should
use the existing central logger and a separately bounded diagnostic surface.

`windows/ui/menu/menu_llm/enable_admission.ahk` already captures backend, model,
origin, auxiliary generation, exact config bytes/path, disabled state, pause and
cleanup barriers. `LLM_OllamaIsRunning_Async(..., Structured=true)` and the shared
`LLM_EnableReceipt` verify a complete `/api/version` response. Fresh admission
must remain the only enabled-state writer after successful explicit repair.
The process owner deliberately reports launch acceptance separately from server
readiness. A source/backend/port/pause transition cancels its exact task through
the existing lifecycle dispatcher; it must never kill an external server.

## Required orchestration and API gaps

1. Root owns one shared pinned release catalogue, consumed by all drivers. Its
   Windows entries must name the official versioned portable archive, CPU
   architecture, exact published SHA-256 and byte size, complete runtime layout,
   bounded network retry policy and download timeout. The existing macOS pin is
   0.24.0; this proposal does not guess Windows digests or bytes. Resolve official
   small release metadata first, without downloading the large archive. Reject
   absent architecture assets explicitly. The current old shared installer PS1
   is unpinned, default-port-bound and detached; do not execute or revive it.
2. Acquire a current-user managed root under LOCALAPPDATA, without administrator
   rights, PATH/registry/startup changes or an application/service installer.
   FileSystem already provides exclusive directory creation,
   `FSWriteCreateDurable`, `FSAtomicMoveCreate`, `FSAtomicMoveReplace` and reparse
   detection, but does not create/verify a protected current-user DACL. A narrow
   native Windows acquisition port must create a fresh directory with its DACL
   at creation, verify existing ancestry/owner/ACL, reject reparse points and
   untrusted writable roots, and return an exact owned lease. Do not call a
   directory private merely because its name includes a PID or UUID.
3. A shared installer policy captures one private ticket with explicit consent,
   current source identity, endpoint, backend/model and policy generation. Its
   native Windows transaction owns one exclusive stage on the same volume as
   the managed versions directory. Download the exact catalogued archive using
   system curl in a ShellRunner job with system-proxy/trust policy, pinned live
   byte ceiling, bounded stall/total time and retries. `CurlAsyncRequest` has an
   8 MiB normal response cap, so silently relaxing or reusing it for a multi-GB
   archive is unsuitable. Keep normal HTTP limits intact.
4. Verify exact byte count and SHA-256 before extraction. Open the ZIP as a data
   archive, reject rooted/traversing/alternate-stream/reparse entries, enforce
   independent file-count and expanded-byte bounds, and extract the whole
   executable/library layout into the owned stage. Check the expected CLI and
   every required library. Publish a new immutable version directory with a
   no-replace same-volume rename, then a durable atomic current-version receipt.
   Refused pointer publication preserves the predecessor and exact stage debt;
   never overwrite an in-use binary/library set. A held binary-version lease
   prevents deletion while a daemon still owns that version.
5. The shared orchestration first checks the configured loopback origin using an
   exact, retained native version-request owner. An already reachable external
   server needs no local task. A failed request is not start/install consent.
   Explicit Start uses an existing verified CLI; explicit Install captures
   separate installation consent and only then may publish its CLI and start
   it. An external listener that races launch is never killed. A fresh version
   receipt proves endpoint availability, not that our child owns that listener.
6. The orchestration separately owns its deadline and retry/poll timers, probe
   request handles/private files, download/extraction job, staging lease,
   publication receipt and active runtime-version lease. Publish each owner
   before calling a yielding constructor/start port. After every native return
   check the exact ticket again. On pause, source drift, backend/port change,
   cancel, timeout or shutdown, suppress callbacks first, retire only exact
   resources and keep any refused cleanup owners until acknowledged. Cleanup
   refusal blocks successors and successful shutdown; it is not permission to
   reuse a ticket. Cleanup may run under pause; visible/new work may not.
7. After repair readiness, return the explicit native result to the existing
   source-fenced enable owner and request a new version receipt. Do not turn on
   the master setting from installer/process completion. Runtime installation
   does not install a model. If model installation is offered, require distinct
   accurate consent and verify the exact selected tag via the existing strict
   model listing/pull owners. Refuse a stale model continuation.

## Native acceptance before adoption

Register the eventual AHK unit include explicitly, prove valid/invalid parser
controls with Ahk2Exe/parse-only harness, retain UTF-8 BOM + LF, and run the
selected JS/encoding/convention gates. Portable source checks are not execution.

On a Windows non-release workflow, run the actual AHK owner with the production
ShellRunner, production timer boundaries and private fixture paths. A fixture
CLI records its actual child-only OLLAMA_HOST/OLLAMA_MODELS, starts a real grandchild
and remains alive. Assert launch uses the configured nondefault port, original
driver environment is byte-identical, child/grandchild handles become signaled
after cancellation, unrelated external process/listener survives, and timer,
job/process/thread/capture counts return to their exact predecessor. Capture
actual native refusal paths at suspended construction, resume, cancellation,
handle close, timer cancellation and private-file sharing denial; refuse a
successor until exact settlement, and retain the predecessor Critical state.

Use actual loopback listeners for strict version readiness, including malformed,
truncated, non-200 and redirect cases. Change source bytes or port while requests
are held, including same-byte preference revisions, and assert no readiness or
enable callback escapes. A launch receipt alone must fail these tests. Exercise
pause/backend transfer and OnExit through the real lifecycle owners.

For installation tests, use independent tiny ZIP fixtures and hard-coded hashes
for CLI plus required libraries; include wrong digest/size, missing libraries,
zip traversal/ADS, oversized extraction, locked predecessor, failed rename,
failed receipt write, concurrent acquisition and cancellation during each
phase. Execute the real native publisher. Assert no Program Files, machine PATH,
registry, service or external process mutation. Then one Windows native test
must download the pinned official archive, install as a standard user, launch
the genuine server, obtain a fresh version and exact model-inventory receipt,
cancel every owned descendant and retire every private staging resource.

Finally qualify source startup, compiled packaging/installation, graphical
consent/refusal, typing during download, physical pause/resume and selected model
acceptance. Passing synthetic fixtures does not remove TODO48 or the transverse
validation items.

## Integration ownership

Only scratch preparation is authorized to this subagent. Root must coordinate
shared catalogue/policy/menu/locales and existing Windows workstation ownership,
then announce production paths before adoption. The minimal eventual native
paths are a Windows Ollama resolver/publisher, this lifecycle owner and launcher,
their registered native tests, and existing lifecycle/enable adapters. Shared
consent/policy/data should be implemented by their coordinated shared owner.
