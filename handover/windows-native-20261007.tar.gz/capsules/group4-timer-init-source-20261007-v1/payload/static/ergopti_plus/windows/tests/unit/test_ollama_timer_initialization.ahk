﻿; tests/unit/test_ollama_timer_initialization.ahk
#Requires AutoHotkey v2.0

; ==============================================================================
; MODULE: Managed Windows Timer And Initialization Controls
; DESCRIPTION:
; Exercises the real timer methods and exclusive lifecycle API with recording
; owners. No native process, directory, DLL or callback timer is acquired.
; ==============================================================================

Test("ollama-managed-timer-exact-identity", _OMTI_TimerIdentity)
Test("ollama-managed-timer-refused-cancel", _OMTI_TimerRefusal)
Test("ollama-managed-timer-thrown-cancel", (*) => _OMTI_TimerRefusal(true))
Test("ollama-managed-lifecycle-cold-refusal", _OMTI_Cold)
Test("ollama-managed-lifecycle-exclusive-owner", _OMTI_Lifecycle)

class _OMTI_Intake extends OllamaArchiveIntake {
	__New(Mode := "accepted") {
		this.Options := Map("poll_ms", 37)
		this.Record := Map("cancelled", false)
		this.Timer := (*) => 0
		this.TimerOwned := false
		this.TimerFn := ObjBindMethod(this, "Set")
		this.Mode := Mode
		this.Calls := []
		this.FirstError := ""
		this.Stops := 0
	}
	Set(Callback, Period) {
		this.Calls.Push(Map("callback", Callback, "period", Period))
		if this.Mode == "throw"
			throw Error("controlled timer refusal")
		return this.Mode == "accepted"
	}
	_Fault(Record, Reason) {
		this.FirstError := Reason
		Record["cancelled"] := true
		return false
	}
	_RequestRetirement(Record) {
		this.Stops += 1
	}
}

_OMTI_TimerIdentity() {
	local owner := _OMTI_Intake(), callback := owner.Timer
	owner._Schedule()
	AssertTrue(owner.TimerOwned)
	AssertEqual(-37, owner.Calls[1]["period"])
	AssertTrue(owner.Calls[1]["callback"] == callback)
	AssertTrue(owner._StopTimer())
	AssertEqual(0, owner.Calls[2]["period"])
	AssertTrue(owner.Calls[2]["callback"] == callback)
	AssertFalse(owner.TimerOwned)
}

_OMTI_TimerRefusal(Throws := false) {
	local owner := _OMTI_Intake(Throws ? "throw" : "refused")
	owner._Schedule()
	AssertTrue(owner.TimerOwned, "A refused admission retains exact callback debt.")
	AssertEqual("intake_timer_refused", owner.FirstError)
	AssertEqual(1, owner.Stops)
	AssertFalse(owner._StopTimer())
	AssertTrue(owner.TimerOwned, "Cancellation needs a true acknowledgement.")
	owner.Mode := "accepted"
	AssertTrue(owner._StopTimer())
	AssertFalse(owner.TimerOwned)
}

class _OMTI_Files {
	HasFileDebt() => true
}

class _OMTI_Coordinator extends OllamaManagedCoordinator {
	__New() {
		this.Files := _OMTI_Files()
		this.Stops := 0
	}
	Stop() {
		this.Stops += 1
		return false
	}
	HasNativeOwner() => true
}

_OMTI_Cold() {
	global _LLM_ManagedWindowsCoordinator
	local saved := _LLM_ManagedWindowsCoordinator
	try {
		_LLM_ManagedWindowsCoordinator := 0
		for callable in [LLM_ManagedWindows_PrepareShutdown, LLM_ManagedWindows_HasNativeOwner, LLM_ManagedWindows_DataDebt] {
			local refused := false
			try callable.Call()
			catch as Err {
				refused := Err.Message == "Managed Windows lifecycle has not been initialized."
			}
			AssertTrue(refused, "Every public observer requires canonical initialization.")
		}
	} finally _LLM_ManagedWindowsCoordinator := saved
}

_OMTI_Lifecycle() {
	global _LLM_ManagedWindowsCoordinator
	local saved := _LLM_ManagedWindowsCoordinator, owner := _OMTI_Coordinator()
	try {
		_LLM_ManagedWindowsCoordinator := 0
		AssertTrue(LLM_ManagedWindows_Init(owner))
		local refused := false
		try LLM_ManagedWindows_Init(_OMTI_Coordinator())
		catch as Err {
			refused := Err.Message == "Managed Windows coordination initialization is exclusive."
		}
		AssertTrue(refused)
		AssertTrue(_LLM_ManagedWindowsCoordinator == owner)
		AssertTrue(LLM_ManagedWindows_HasNativeOwner())
		AssertTrue(LLM_ManagedWindows_DataDebt())
		AssertFalse(LLM_ManagedWindows_PrepareShutdown())
		AssertEqual(1, owner.Stops)
		AssertTrue(_LLM_ManagedWindowsCoordinator == owner)
	} finally _LLM_ManagedWindowsCoordinator := saved
}
