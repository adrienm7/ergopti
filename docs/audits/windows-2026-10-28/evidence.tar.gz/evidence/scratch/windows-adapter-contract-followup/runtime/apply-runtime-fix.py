from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/unit/modules/llm/servers/test_ollama_runtime_ready_cancellation.ahk')
s=p.read_text(encoding='utf-8-sig');name='_ORRC_RetiredBootstrapCallback';start=s.index(name+'() {');end=s.index('\n}\n',start)+2;body=s[start:end]
assert body.count('Failure := ""')==1;body=body.replace('Failure := ""','Failure := "", ContractThrew := false')
old='catch as Err\n\t\t\tFailure := Err.Message';assert body.count(old)==1;body=body.replace(old,'catch as Err {\n\t\t\tContractThrew := true\n\t\t\tFailure := Err.Message\n\t\t}')
old='AssertEqual("", Failure, "a retained real bootstrap callback cannot dereference a retired runtime record")';assert body.count(old)==1;body=body.replace(old,'AssertFalse(ContractThrew, "a retained real bootstrap callback cannot dereference a retired runtime record: " . Failure)')
s=s[:start]+body+s[end:];p.write_text(s,encoding='utf-8-sig',newline='\n')
