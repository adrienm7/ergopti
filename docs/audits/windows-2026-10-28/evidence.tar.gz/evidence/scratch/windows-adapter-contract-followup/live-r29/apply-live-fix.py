from pathlib import Path
p=Path('/workspace/ergopti-windows-r6-tests/static/ergopti_plus/windows/tests/live/live_harness.ahk')
s=p.read_text(encoding='utf-8-sig')
s=s.replace("@returns {Object} State whose Done and Error members the caller waits on.","@returns {Object} State with terminal Done, independent Failed and Error diagnosis.")
old='State := {Done: false, Error: "", Hwnd: 0, Started: A_TickCount, Optional: Optional,'
assert s.count(old)==1
s=s.replace(old,'State := {Done: false, Failed: false, Error: "", Hwnd: 0, Started: A_TickCount, Optional: Optional,')
start=s.index('_LiveDriveTick(State, Match, Action, *) {');end=s.index('\n}\n',start)+2
body=s[start:end]
old='\t\tif !State.Optional\n\t\t\tState.Error := "no window matched \'" . (HasMethod(Match, "Call") ? "the watched window" : Match)\n\t\t\t\t. "\' within " . State.Limit . " ms"\n'
new='\t\tif !State.Optional {\n\t\t\tState.Failed := true\n\t\t\tState.Error := "no window matched \'" . (HasMethod(Match, "Call") ? "the watched window" : Match)\n\t\t\t\t. "\' within " . State.Limit . " ms"\n\t\t}\n'
assert body.count(old)==1;body=body.replace(old,new)
old='\tHwnd := HasMethod(Match, "Call") ? Match.Call() : WinExist(Match)\n\tif !Hwnd\n\t\treturn\n\tSetTimer(State.Tick, 0)\n\tState.Hwnd := Hwnd\n\ttry Action.Call(Hwnd)\n\tcatch as Err\n\t\tState.Error := Err.Message\n'
new='\ttry {\n\t\tHwnd := HasMethod(Match, "Call") ? Match.Call() : WinExist(Match)\n\t\tif !Hwnd\n\t\t\treturn\n\t\tSetTimer(State.Tick, 0)\n\t\tState.Hwnd := Hwnd\n\t\tAction.Call(Hwnd)\n\t} catch as Err {\n\t\tSetTimer(State.Tick, 0)\n\t\tState.Failed := true\n\t\tState.Error := Err.Message\n\t}\n'
assert body.count(old)==1;body=body.replace(old,new)
s=s[:start]+body+s[end:]
old='if State.Error != ""\n\t\tthrow Error(What . ": " . State.Error)';assert s.count(old)==1
s=s.replace(old,'if State.Failed\n\t\tthrow Error(What . ": " . State.Error)')
p.write_text(s,encoding='utf-8-sig',newline='\n')
