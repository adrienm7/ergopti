/* Actual registry implementation, with source/factory/kernel ports recorded.
   No source publication, kernel job, guardian or daemon is executed here. */
#include "guardian_service.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct GSC_Owner { GSC_Phase phase; DWORD error; GI_Expected member; uint16_t path[32]; uint64_t token;uint32_t active; };
struct GF_Owner { GF_Phase phase; DWORD error; };
static uint32_t creates,binds,begins,stops,partial,wrong_digest,release_requests;
static GF_Owner *last_factory;
static const uint8_t digest[32]={1u};

GSC_Owner *GSC_Create(uint64_t id,uint32_t count,uint32_t paths,const uint8_t hash[32]) {
    GSC_Owner *row=calloc(1u,sizeof(*row));(void)id;(void)count;(void)paths;(void)hash;creates++;
    if(row==NULL)return NULL;
    row->phase=partial?GSC_RETAINED_DEBT:GSC_UNBOUND;row->error=partial?ERROR_ACCESS_DENIED:0u;
    row->member.kind=0u;row->member.native_path=row->path;row->member.path_units=1u;
    row->path[0]='G';memcpy(row->member.sha256,digest,32u);
    if(wrong_digest)row->member.sha256[0]=2u;
    return row;
}
int GSC_Inherited(GSC_Owner *row,HANDLE *a,HANDLE *b,HANDLE *c,HANDLE *d) {
    if(row==NULL)return 0;*a=(HANDLE)1;*b=(HANDLE)2;*c=(HANDLE)3;*d=(HANDLE)4;return 1;
}
int GSC_InheritanceUsed(const GSC_Owner *row) { return row->token!=0u; }
int GSC_AcquireInheritance(GSC_Owner *row,uint64_t token) { row->token=token;row->active=1u;return 1; }
int GSC_ReleaseInheritance(GSC_Owner *row,uint64_t token) { if(row->token!=token)return 0;row->active=0u;return 1; }
uint64_t GSC_InheritanceToken(const GSC_Owner *row) { return row->token; }
int GSC_Bind(GSC_Owner *row,HANDLE process) { (void)process;if(!row->token||row->active)return 0;binds++;row->phase=GSC_BOUND;return 1; }
int GSC_Poll(GSC_Owner *row) { row->phase=GSC_DATA_READY;return 1; }
const GI_Expected *GSC_Records(const GSC_Owner *row,size_t *count) { *count=1u;return &row->member; }
GSC_Phase GSC_State(const GSC_Owner *row) { return row!=NULL?row->phase:GSC_RETAINED_DEBT; }
HANDLE GSC_Source(const GSC_Owner *row) { (void)row;return (HANDLE)10; }
DWORD GSC_FirstError(const GSC_Owner *row) { return row!=NULL?row->error:ERROR_INVALID_PARAMETER; }
int GSC_RequestSourceRelease(GSC_Owner *row) { (void)row;++release_requests;return 1; }
int GSC_BindTransferred(GSC_Owner *row,HANDLE process) {
    (void)process;if(row->token!=0u || row->active)return 0;binds++;row->phase=GSC_BOUND;return 1;
}
int GSC_TryRetire(GSC_Owner *row) { row->phase=GSC_RETIRED;return 1; }
GF_Owner *GF_Begin(uint64_t id,GSC_Owner *source,HANDLE job,HANDLE daemon,DWORD pid,const FILETIME *time,const wchar_t *image) {
    (void)id;(void)source;(void)job;(void)daemon;(void)pid;(void)time;(void)image;
    begins++;last_factory=calloc(1u,sizeof(*last_factory));if(last_factory!=NULL)last_factory->phase=GF_HOST_STARTING;return last_factory;
}
GF_Owner *GF_BeginIntake(uint64_t id,GSC_Owner *source,HANDLE job,HANDLE daemon,DWORD pid,const FILETIME *time,const wchar_t *image) {
    return GF_Begin(id,source,job,daemon,pid,time,image);
}
int GF_HasIntakeContainment(const GF_Owner *row) { return row!=NULL; }
int GF_ReleaseIntakeSource(GF_Owner *row) { return row!=NULL && row->phase==GF_READY; }
int GF_ConfirmIntakeDirectory(GF_Owner *row,const GI_Expected *root,const GI_Expected *intake) {
    return row!=NULL && root!=NULL && intake!=NULL && row->phase==GF_READY;
}
GF_Phase GF_Poll(GF_Owner *row) { return row->phase; }
DWORD GF_FirstError(const GF_Owner *row) { return row->error; }
int GF_RequestStop(GF_Owner *row) { stops++;row->phase=GF_STOPPING;return 1; }
static DWORD TestPid(HANDLE handle) { return (DWORD)(uintptr_t)handle; }
static BOOL TestTimes(HANDLE handle,FILETIME *a,FILETIME *b,FILETIME *c,FILETIME *d) {
    (void)handle;memset(a,0,sizeof(*a));memset(b,0,sizeof(*b));memset(c,0,sizeof(*c));memset(d,0,sizeof(*d));return TRUE;
}
#define GetProcessId TestPid
#define GetProcessTimes TestTimes
#include "guardian_service.c"
#undef GetProcessId
#undef GetProcessTimes

#define CHECK(value) do {if(!(value)){fprintf(stderr,"FAIL %s:%d: %s\n",name,__LINE__,#value);return 0;}} while(0)
static int New(uint64_t *id) { uint64_t token;return GB_Create(2u,64u,digest,digest,id)&&GB_AcquireInheritance(*id,&token)&&GB_ReleaseInheritance(*id,token); }
static int Offered(uint64_t *id) { GB_Status status;return New(id)&&GB_Bind(*id,(HANDLE)10)&&GB_Poll(*id,&status)&&status.phase==GB_OFFERED; }
static int Unknown(void) {
    const char *name="unknown registry ID has no acquisition or activation";GB_Status status;uint32_t old=begins;
    CHECK(!GB_Poll(0u,&status)&&!GB_Bind(UINT64_MAX,(HANDLE)10)&&!GB_ClaimActivation(UINT64_MAX)&&!GB_BeginGuardian(UINT64_MAX,(HANDLE)11,(HANDLE)12,(HANDLE)10));
    CHECK(begins==old);return 1;
}
static int BeforeReady(void) {
    const char *name="copied offer cannot authorize daemon activation";uint64_t id;uint32_t old=begins;
    CHECK(Offered(&id));CHECK(!GB_ClaimActivation(id)&&begins==old);return 1;
}
static int BindOnce(void) {
    const char *name="exact source binding is once only";uint64_t id;uint32_t old=binds;
    CHECK(New(&id));CHECK(GB_Bind(id,(HANDLE)10)&&!GB_Bind(id,(HANDLE)20)&&binds==old+1u);return 1;
}
static int NativeReady(void) {
    const char *name="only native guardian READY grants one activation";uint64_t id;
    CHECK(Offered(&id)&&GB_BeginGuardian(id,(HANDLE)11,(HANDLE)12,(HANDLE)10));CHECK(!GB_ClaimActivation(id));
    last_factory->phase=GF_READY;CHECK(GB_ClaimActivation(id)&&!GB_ClaimActivation(id));return 1;
}
static int BeginOnce(void) {
    const char *name="guardian constructor cannot duplicate its effects";uint64_t id;uint32_t old=begins;
    CHECK(Offered(&id)&&GB_BeginGuardian(id,(HANDLE)11,(HANDLE)12,(HANDLE)10));
    CHECK(!GB_BeginGuardian(id,(HANDLE)11,(HANDLE)12,(HANDLE)10)&&begins==old+1u);return 1;
}
static int WrongImage(void) {
    const char *name="substituted guardian digest refuses before process creation";uint64_t id;GB_Status status;uint32_t old=begins;
    wrong_digest=1u;CHECK(Offered(&id));wrong_digest=0u;
    CHECK(!GB_BeginGuardian(id,(HANDLE)11,(HANDLE)12,(HANDLE)10)&&begins==old);
    CHECK(GB_Poll(id,&status)&&status.phase==GB_DEBT&&status.first_error==ERROR_INVALID_DATA);return 1;
}
static int Stop(void) {
    const char *name="stop burns activation without copied retirement";uint64_t id;GB_Status status;uint32_t old=stops;
    CHECK(Offered(&id)&&GB_BeginGuardian(id,(HANDLE)11,(HANDLE)12,(HANDLE)10));last_factory->phase=GF_READY;
    CHECK(GB_Stop(id)&&stops==old+1u&&!GB_ClaimActivation(id));
    CHECK(GB_Poll(id,&status)&&status.phase==GB_STOPPING);
    last_factory->phase=GF_RETIRED;CHECK(GB_Poll(id,&status)&&status.phase==GB_RETIRED);return 1;
}
static int Overflow(void) {
    const char *name="signed wire identity never wraps or acquires";uint64_t previous=GB_last_id,id=9u;uint32_t old=creates;
    GB_last_id=(uint64_t)INT64_MAX;
    CHECK(!New(&id)&&id==0u&&creates==old);GB_last_id=previous;return 1;
}
static int Partial(void) {
    const char *name="partial constructor retains its ID and first error";uint64_t id;GB_Status status;
    partial=1u;CHECK(GB_Create(2u,64u,digest,digest,&id));partial=0u;
    CHECK(id!=0u&&GB_Poll(id,&status)&&status.phase==GB_DEBT&&status.first_error==ERROR_ACCESS_DENIED);
    CHECK(GB_Stop(id)&&GB_Poll(id,&status)&&status.phase==GB_RETIRED&&status.first_error==ERROR_ACCESS_DENIED);return 1;
}
static int ForeignSource(void) {
    const char *name="foreign real source capability refuses before guardian creation";
    uint64_t id;uint32_t old=begins;GB_Status status;
    CHECK(Offered(&id));
    CHECK(!GB_BeginGuardian(id,(HANDLE)11,(HANDLE)12,(HANDLE)20)&&begins==old);
    CHECK(GB_Poll(id,&status)&&status.phase==GB_DEBT&&status.first_error==ERROR_INVALID_DATA);
    return 1;
}
static int LeaseIdentity(void) {
    const char *name="registry correlates channel and native lease token";uint64_t a,b,ta,tb;GB_Row *row;
    CHECK(GB_Create(2u,64u,digest,digest,&a)&&GB_Create(2u,64u,digest,digest,&b));
    CHECK(GB_AcquireInheritance(a,&ta)&&GB_AcquireInheritance(b,&tb)&&ta!=tb);
    row=GB_Find(a);CHECK(row!=NULL&&row->source->active);
    CHECK(!GB_ReleaseInheritance(a,tb)&&row->source->active&&row->first_error==0u);
    CHECK(GB_ReleaseInheritance(a,ta)&&!row->source->active);
    CHECK(GB_ReleaseInheritance(b,tb));return 1;
}
static int LeaseOverflow(void) {
    const char *name="inheritance token overflow refuses before flag acquisition";uint64_t id,token=9u,old=GB_last_inheritance;GB_Row *row;
    CHECK(GB_Create(2u,64u,digest,digest,&id));row=GB_Find(id);
    GB_last_inheritance=(uint64_t)INT64_MAX;
    CHECK(!GB_AcquireInheritance(id,&token)&&token==0u&&!row->source->active&&!row->source->token);
    GB_last_inheritance=old;return 1;
}
static int IntakeStopCannotAuthorizePreparation(void) {
    const char *name="intake cancellation never signals archive preparation";uint64_t id;uint32_t before=release_requests;
    CHECK(GB_CreateIntake(2u,64u,digest,digest,&id));
    CHECK(GB_Stop(id) && release_requests==before);return 1;
}
static int IntakeTransferredSourceDoesNotRequireInheritance(void) {
    const char *name="late source binding uses exact non-inherited channel";uint64_t id;GB_Row *row;GB_Status status;HANDLE a,b,c,d;
    CHECK(GB_CreateIntake(2u,64u,digest,digest,&id));row=GB_Find(id);
    CHECK(GB_Inherited(id,&a,&b,&c,&d) && row->source->token==0u && !row->source->active);
    CHECK(GB_IntakeBindTransferredSource(id,(HANDLE)10));
    CHECK(!GB_IntakeBindTransferredSource(id,(HANDLE)10) && !GB_Inherited(id,&a,&b,&c,&d));
    CHECK(GB_Poll(id,&status) && status.phase==GB_OFFERED && row->source->token==0u);return 1;
}
int main(void) {
    int (*tests[])(void)={Unknown,BeforeReady,BindOnce,NativeReady,BeginOnce,WrongImage,Stop,Overflow,Partial,ForeignSource,LeaseIdentity,LeaseOverflow,IntakeStopCannotAuthorizePreparation,IntakeTransferredSourceDoesNotRequireInheritance};
    const char *names[]={"unknown registry ID has no acquisition or activation","copied offer cannot authorize daemon activation",
        "exact source binding is once only","only native guardian READY grants one activation","guardian constructor cannot duplicate its effects",
        "substituted guardian digest refuses before process creation","stop burns activation without copied retirement",
        "signed wire identity never wraps or acquires","partial constructor retains its ID and first error",
        "foreign real source capability refuses before guardian creation",
        "registry correlates channel and native lease token","inheritance token overflow refuses before flag acquisition",
        "intake cancellation never signals archive preparation","late source binding uses exact non-inherited channel"};
    size_t i;puts("1..14");for(i=0u;i<14u;++i){int ok=tests[i]();printf("%s %zu - %s\n",ok?"ok":"not ok",i+1u,names[i]);if(!ok)return 1;}return 0;
}
