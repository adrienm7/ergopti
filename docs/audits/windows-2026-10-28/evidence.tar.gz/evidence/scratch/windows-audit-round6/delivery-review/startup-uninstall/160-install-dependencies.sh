set -euo pipefail
cd /workspace/ergopti-windows-r7-installer
pwd
node --version
npm ci --no-audit --no-fund
npx husky install
node tools/test/verify-change.cjs --plan
