const assert=require('node:assert/strict');
const {scriptTokens}=require('./original-script-source.cjs');
const before='#Include menu_population.ahk if !_MR_FrameNativeConstructorCurrent(Menu) throw Error(';
const after='#Include menu_population.ahk\nif !_MR_FrameNativeConstructorCurrent(Menu) throw Error(';
const shape=source=>scriptTokens(source,'.ahk').map(({kind,value})=>({kind,value}));
assert.deepEqual(shape(before),shape(after),'the original constructor policy/oracle operands remain identical');
console.log('Original bootstrap token policy identical; only the native directive line boundary is restored.');
