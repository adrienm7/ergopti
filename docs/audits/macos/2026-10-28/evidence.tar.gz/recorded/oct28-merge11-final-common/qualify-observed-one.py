from pathlib import Path
import datetime,hashlib,json,re,subprocess
from zoneinfo import ZoneInfo
s=Path('/workspace/scratch/oct28-merge11-final-common');r=Path('/workspace/ergopti-macos-final-common')
def load(name):return json.loads((s/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
receipt=load('receipt.json');go=load('go.json');exit_record=load('tool-exit.json');observer=load('residual-observer.json')
assert go['source_state']=='committed' and go['go_from_parent'] is True
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==go['commit']
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=r,text=True).strip()==go['tree']
assert receipt['physical_initial']['index_tree']==receipt['physical_final']['index_tree']==go['tree']
for state in [receipt['physical_initial'],receipt['physical_final']]:
 assert not state['mismatches'] and not state['unstaged'] and not state['untracked']
assert receipt['physical_initial']['digest']==receipt['physical_final']['digest']
raw=(s/'js.log').read_bytes();text=raw.decode(errors='replace');rows=re.findall(r'^  (PASS|FAIL) (\d+)/(\d+) — (.*)$',text,re.M)
count=go['expected_js_features'];assert count==529
assert load('inventory.log')==load('prelaunch-inventory.json')
assert len(rows)==count and {int(x[1])for x in rows}==set(range(1,count+1)) and all(int(x[2])==count for x in rows)
failed=[x for x in rows if x[0]=='FAIL'];assert {int(x[1])for x in failed}=={487},failed
assert all(x[0]=='PASS' for x in rows if x[1] in ['250','474','483'])
assert 'windows/ui/menu/menu_gestures.ahk registers the Infos command' in text
gates=receipt['gates'];assert len(gates)==19 and len({x['name']for x in gates})==19
assert [x['actual_exit']for x in gates if x['name']=='js']==[1]
assert all(x['actual_exit']==0 for x in gates if x['name']!='js') and receipt['all_actual_exit_zero'] is False
assert exit_record['actual_child_wait_exit']==1
assert observer['qualified'] and not observer['live_refs'] and not observer['unreadable_live_same_uid']
not_run=re.search(r'(\d+) case\(s\) in (\d+) check\(s\) were NOT EXECUTED on this host:',text);assert not_run and not_run.groups()==('1','1')
pins=[]
for path in ['static/ergopti_plus/windows/ui/menu/menu_gestures.ahk','tools/test/test-recommended-defaults-rule.cjs']:
 item={'path':path,'refs':{}}
 for ref in [go['commit'],go['base_dev']]:
  data=subprocess.check_output(['git','show',ref+':'+path],cwd=r);item['refs'][ref]={'sha256':hashlib.sha256(data).hexdigest(),'git_blob':subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=r,text=True).strip()}
 assert len({x['sha256']for x in item['refs'].values()})==1
 pins.append(item)
(s/'upstream-oracle-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
qualification={'state':'COMPLETE_WITH_ONE_UPSTREAM_ORACLE_FAILURE','overall_green':False,'qualified_at_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat(),'source_state':'COMMITTED','source_commit':go['commit'],'source_tree':go['tree'],'canonical_js_checks':{'planned':count,'completed':count,'unique_indices_complete':True,'passed_checks':count-1,'failed_checks':1,'failed_check_details':failed,'actual_js_exit':1,'host_specific_cases_not_executed':{'count':1,'checks':1,'description':'Pre-existing AHK host-specific cases remain explicitly not executed, never passed.'}},'actual_child_wait_exit':1,'all_other_gates_actual_zero':True,'gates':[{'name':x['name'],'actual_exit':x['actual_exit'],'command':x['command']}for x in gates],'source_physical_invariant':receipt['physical_final'],'residual_observer':observer,'native_darwin_executed':False,'receipt_sha256':sha(s/'receipt.json'),'tool_exit_sha256':sha(s/'tool-exit.json'),'js_log_sha256':hashlib.sha256(raw).hexdigest(),'upstream_oracle_source_pins':str(s/'upstream-oracle-source-pins.json'),'original_all_pass_qualifier':{'path':str(s/'qualify.py'),'sha256':sha(s/'qualify.py'),'executed':False,'reason':'The complete actual run has a new failing assertion487. Preserve the original all-pass qualifier and record the observed failure; never reinterpret it as success.'},'scope':'One complete canonical Common run on exact committed merge11 source. The new actual failure487 is retained: its Windows command source and raw-spelling oracle are both byte-identical to dev42ac. Former failures250/474/483 all execute PASS. No tests disabled, retried or weakened; this proves execution completeness and provenance, never an overall passing Common suite.'}
(s/'qualification-observed-one.json').write_text(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'state':qualification['state'],'source':go['commit'],'tree':go['tree'],'counts':[count-1,1],'other_gates':18,'source_invariant':True,'observer_qualified':True,'qualification_sha256':sha(s/'qualification-observed-one.json')}))
