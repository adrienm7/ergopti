-- Private real Browse receiving subject; all production authorities stay intact.
local profile, run_dir, receipt_path, oracle_path = assert(arg[1]), assert(arg[2]), assert(arg[3]), assert(arg[4])
local Json = require("json")
local Manager, Gtk, GLib
local report = { status = "running", assertions = {}, phases = {}, cleanup = {},
	limitations = { "X11 virtual display only", "no physical input", "no Wayland", "no daemon restart" } }

local function check(value, name)
	report.assertions[#report.assertions + 1] = { name = name, passed = value == true }
	print((value == true and "PASS " or "FAIL ") .. name)
	assert(value == true, name)
end

local function read(path)
	local file = assert(io.open(path, "rb"))
	local ok, bytes, detail = pcall(file.read, file, "*a")
	local closed_ok, closed, close_error = pcall(file.close, file)
	if not closed_ok or closed ~= true then
		report.cleanup.stream_errors = report.cleanup.stream_errors or {}
		report.cleanup.stream_errors[#report.cleanup.stream_errors + 1] = tostring(closed_ok and close_error or closed)
	end
	if not ok then error(bytes, 0) end
	assert(type(bytes) == "string", detail)
	assert(closed_ok and closed == true, tostring(closed_ok and close_error or closed))
	return bytes
end

local function write_json(path, value)
	local encoded = assert(Json.encode(value))
	local file = assert(io.open(path .. ".pending", "wb"))
	local ok, written, detail = pcall(file.write, file, encoded, "\n")
	local closed_ok, closed, close_error = pcall(file.close, file)
	if not closed_ok or closed ~= true then
		report.cleanup.stream_errors = report.cleanup.stream_errors or {}
		report.cleanup.stream_errors[#report.cleanup.stream_errors + 1] = tostring(closed_ok and close_error or closed)
	end
	if not ok then error(written, 0) end
	assert(written ~= nil, detail)
	assert(closed_ok and closed == true, tostring(closed_ok and close_error or closed))
	assert(os.rename(path .. ".pending", path))
end

local function pump()
	for _ = 1, 100 do
		if not Gtk.events_pending() then break end
		Gtk.main_iteration_do(false)
	end
	GLib.usleep(20000)
end

local function wait(predicate, seconds)
	local deadline = GLib.get_monotonic_time() + (seconds or 15) * 1000000
	repeat
		pump()
		if predicate() then return true end
	until GLib.get_monotonic_time() >= deadline
	return false
end

local function exists(path)
	return GLib.file_test(path, GLib.FileTest.IS_REGULAR)
end

local function evaluate(source)
	local view = assert(Manager.webview_for("onboarding"), "actual onboarding WebView missing")
	local done, answer, failure = false, nil, nil
	view:run_javascript(source, nil, function(_, result)
		local called, value = pcall(function()
			return view:run_javascript_finish(result):get_js_value():to_string()
		end)
		if called then answer = value else failure = value end
		done = true
	end, nil)
	assert(wait(function() return done end, 15), "actual WebKit evaluation deadline")
	if failure ~= nil then error(failure, 0) end
	return answer
end

local function page_ready()
	return wait(function()
		return evaluate("String(typeof _platform==='string' && _platform==='linux' && document.querySelectorAll('#lang-list .lang-item').length===21)") == "true"
	end)
end

local function close_native()
	assert(Manager.webview_for("onboarding")):get_toplevel():close()
	check(wait(function() return not Manager.is_visible("onboarding") end), "native close retires wizard")
end

local environment_ok, environment_error = pcall(function()
	assert(os.getenv("DISPLAY"), "no genuine X11 display")
	local lgi = require("lgi")
	Gtk, GLib = lgi.require("Gtk", "3.0"), lgi.GLib
	lgi.require("WebKit2", "4.1")
end)

local passed, failure = false, environment_error
if environment_ok then
	passed, failure = xpcall(function()
		local oracle = assert(Json.decode(read(oracle_path)))
		local Paths, I18n = require("infra.config_paths"), require("infra.i18n")
		I18n.init()
		local original_dir = profile .. "/recommended-config"
		check(Paths.get_config_dir() == original_dir, "actual V7 published folder is retained")
		check(I18n.get_locale() == oracle.configured_profile_required_locale, "actual published English locale is retained")
		Manager = require("ui.webview_manager")
		Manager.set_daemon_state({})
		local startup_error
		local shown = require("ui.onboarding.startup").run({ graphical = true, path = Paths.config("config.toml"),
			show = function(app) return Manager.show(app) == true end,
			fail = function(detail) startup_error = detail end })
		check(shown == true and startup_error == nil and not Manager.is_visible("onboarding"), "genuine configured startup remains hidden")
		check(Manager.show("onboarding") == true and page_ready(), "actual wizard opens with host data")
		evaluate("document.querySelector('#lang-list .lang-item[data-code=\"en\"]').click(); 'clicked'")
		check(wait(function() return evaluate("String(_selectedLocale==='en')") == "true" end), "actual English preview arrives")
		evaluate("document.getElementById('btn-next').click(); 'clicked'")
		check(wait(function() return evaluate("String(_steps[_stepIndex])") == "config" end), "real navigation enters config page")
		local held = original_dir
		for index, mode in ipairs({ "cancel", "accept", "cancel", "retry" }) do
			local id = tostring(index)
			local expected = held
			if mode ~= "cancel" then
				local relative = mode == "retry" and oracle.second_retry_directory_relative or oracle.accepted_directory_relative
				expected = profile .. "/" .. relative
			end
			local quoted = assert(Json.encode(held))
			check(evaluate("String(_configDir===" .. quoted .. " && document.getElementById('config-input').value===" .. quoted .. ")") == "true", "held DOM folder before Browse " .. id)
			write_json(run_dir .. "/request-" .. id .. ".json", { id = id, mode = mode })
			check(wait(function() return exists(run_dir .. "/started-" .. id .. ".json") end, 10), "external owned actor starts before Browse " .. id)
			local started = assert(Json.decode(read(run_dir .. "/started-" .. id .. ".json")))
			check(started.id == id and started.mode == mode and started.status == "OWNED_ACTOR_STARTED", "actor start acknowledgement matches " .. id)
			-- The real host callback blocks in ui.modal.run/shell.exec_line. Only
			-- the independent external XTest actor can operate its native chooser.
			local clicked = false
			local view = assert(Manager.webview_for("onboarding"))
			view:run_javascript("document.getElementById('config-browse').click(); 'clicked'", nil, function(_, result)
				local ok, value = pcall(function() return view:run_javascript_finish(result):get_js_value():to_string() end)
				if ok and value == "clicked" then clicked = true else failure = value end
			end, nil)
			check(wait(function() return clicked or failure ~= nil end, 45) and clicked, "real Browse click completes " .. id)
			if failure ~= nil then error(failure, 0) end
			quoted = assert(Json.encode(expected))
			check(wait(function()
				return evaluate("String(_configDir===" .. quoted .. " && document.getElementById('config-input').value===" .. quoted .. ")") == "true"
			end), "real picker normalized folder/cancel reaches DOM " .. id)
			check(wait(function() return exists(run_dir .. "/completed-" .. id .. ".json") end, 10), "actor and independent file checks finish " .. id)
			local completed = assert(Json.decode(read(run_dir .. "/completed-" .. id .. ".json")))
			check(completed.id == id and completed.mode == mode and completed.status == "INPUT_AND_FILES_ACKNOWLEDGED", "actual actor/file acknowledgement matches " .. id)
			check(evaluate("String(!document.getElementById('btn-next').disabled)") == "true", "real Next remains enabled " .. id)
			evaluate("document.getElementById('btn-next').click(); 'clicked'")
			check(wait(function()
				return evaluate("String(_steps[_stepIndex]==='tap_holds' && !_configPending && _loadedDir===" .. quoted .. ")") == "true"
			end), "real chosen-folder read is acknowledged after Next " .. id)
			evaluate("document.getElementById('btn-back').click(); 'clicked'")
			check(wait(function() return evaluate("String(_steps[_stepIndex])") == "config" end), "real Back allows next Browse " .. id)
			check(Paths.get_config_dir() == original_dir, "Browse does not publish resolver before Finish " .. id)
			report.phases[#report.phases + 1] = { id = id, mode = mode, expected_folder = expected, status = "PASS" }
			held = expected
		end
		close_native()
		check(Paths.get_config_dir() == original_dir, "closing after Browse preserves published resolver")
		check(Manager.show("onboarding") == true and page_ready(), "genuine reopen remains available after Browse")
		check(evaluate("String(_configDir)") == original_dir, "genuine reopen restores original published folder")
		close_native()
	end, debug.traceback)
end

if Manager then
	local called, retired = pcall(Manager.shutdown)
	report.cleanup.manager_called, report.cleanup.manager_retired = called, called and retired == true
	if not called or retired ~= true then
		passed = false
		report.cleanup.manager_error = tostring(retired)
		if failure == nil then failure = retired end
	end
end
if report.cleanup.stream_errors then passed = false end
report.status = not environment_ok and "ENVIRONMENT_UNRUN" or passed and "PASS" or "FAIL"
report.failure = not passed and tostring(failure) or nil
local receipt_ok, receipt_error = pcall(write_json, receipt_path, report)
if not receipt_ok then
	io.stderr:write("Native receipt refused: ", tostring(receipt_error), "\n")
end
if not passed then io.stderr:write(tostring(failure), "\n") end
os.exit(not receipt_ok and 1 or not environment_ok and 2 or passed and 0 or 1)
