"""Replay unchanged receiving counterexample plus narrow caller-data refusals."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

r=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-public-join-v2-independent')
v1=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-public-join-v1-independent/receiving-projection')
v2=r/'projection'
original=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-public-constructor-probe/probe.lua').read_text()
needle="local root='/workspace/ergopti/static/ergopti_plus'"
assert original.count(needle)==1
environment=dict(os.environ,TMPDIR='/tmp',PYTHONDONTWRITEBYTECODE='1')
results=[]
for name,projection,source in [('original-HOLD',v1,v1/'dependencies/static/ergopti_plus'),
                               ('repaired',v2,v2/'candidate/static/ergopti_plus')]:
    adapted=original.replace(needle,'local root='+repr(str(source)))
    assert adapted.replace('local root='+repr(str(source)),needle)==original
    probe=r/(name+'-receiving-probe.lua');probe.write_text(adapted)
    for abi in ['luajit','lua5.4']:
        command=['/workspace/.ergopti-cloud/bin/'+abi,str(probe),str(projection)]
        proc=subprocess.run(command,cwd=source/'linux',env=environment,capture_output=True,timeout=20)
        log=r/(abi+'-'+name+'-receiving.log');log.write_bytes(proc.stdout+proc.stderr)
        expected=b'CALLER_CONSTRUCTOR registered=true pending=true invoked=true cleaned=true' if name=='original-HOLD' else b'CALLER_CONSTRUCTOR registered=false pending=false invoked=false cleaned=true'
        assert expected in proc.stdout,(proc.stdout,proc.stderr)
        assert proc.returncode==(1 if name=='original-HOLD' else 0)
        row={'case':name,'abi':abi,'exit':proc.returncode,'observation':expected.decode(),'command':command,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
        results.append(row);print(row['abi'],row['case'],row['observation'],flush=True)

extra='''local packet=assert(arg[1])
local root=packet..'/candidate/static/ergopti_plus'
package.path=root..'/linux/?.lua;'..root..'/linux/?/init.lua;'..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
require('compat.utf8').install();local Loop=require('luv')
local count=0
require('tests.support.input_owner_fixture').with_manager_session({public_chords=true,before_manager=function(s)
 s.bytes='[mod_combos.config.tab_then_caps_lock]\\ncombo="copy"\\n'
end},function(s)
 local Source=require('modules.shortcuts.key_combinations')
 for _,value in ipairs({true,{},setmetatable({chords={tab_then_caps_lock='copy'}},{__index=function()return true end})}) do
  assert(Source.buffered_settings_current(value)==false,'unissued caller bool/table/meta has no input registry authority');count=count+1
 end
 local caller=Source.new(setmetatable({keys={{id='tab',key='tab'},{id='caps_lock',key='caps_lock'}},
  hold_picker={modifiers={'ctrl'},layers={}},is_paused=function()return false end,
  changed=function()return true end,actions={is_assignable=function()return true end}}, {__index=function()return true end}))
 assert(caller.get_chord('tab_then_caps_lock')=='copy')
 local options=caller.engine_options({tab=300,caps_lock=300})
 assert(Source.buffered_settings_current(options)==false,'detached meta constructor cannot become Manager issuance');count=count+1
 assert(s.hook.set_remapper(nil));assert(s.broker.output_current());assert(next(s.broker.view().owners)==nil)
end)
assert(require('luv')==Loop);print('INDEPENDENT_CALLER_DATA_REFUSALS '..count..'/0 CLEANUP=true')
'''
(r/'caller-data-probe.lua').write_text(extra)
for abi in ['luajit','lua5.4']:
    command=['/workspace/.ergopti-cloud/bin/'+abi,str(r/'caller-data-probe.lua'),str(v2)]
    proc=subprocess.run(command,cwd=v2/'candidate/static/ergopti_plus/linux',env=environment,capture_output=True,timeout=20)
    log=r/(abi+'-caller-data.log');log.write_bytes(proc.stdout+proc.stderr)
    assert proc.returncode==0 and b'INDEPENDENT_CALLER_DATA_REFUSALS 4/0 CLEANUP=true' in proc.stdout,(proc.stdout,proc.stderr)
    results.append({'case':'caller-data','abi':abi,'exit':0,'observation':proc.stdout.decode().strip(),'command':command,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    print(abi,proc.stdout.decode().strip(),flush=True)
(r/'independent-probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
