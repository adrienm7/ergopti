#!/bin/bash
# Reuse the isolated parser in a child invocation; no shared activation edit.
set -euo pipefail
/workspace/ergopti-cloud/group6-ruby/bin/ruby --version
# For a future controlled test command only, expose the wrapper in that child's
# environment. Never inject this into a running gate:
# env PATH="/workspace/ergopti-cloud/group6-ruby/bin:$PATH" node tools/test/test-homebrew-cask.cjs
