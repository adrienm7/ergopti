"""Freeze only observed final bytes; safe deterministic regular-member capsule."""
from pathlib import Path, PurePosixPath
import difflib
import gzip
import hashlib
import io
import json
import shutil
import tarfile

P = Path(__file__).resolve().parent
CONCERN = Path('/workspace/ergopti-cloud/group6-native-command-closure-concern')
REL = 'static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py'
old = json.loads((P / 'manifest.json').read_text())
if 'paths' not in old:
    before, after = [(P / role / REL).read_text() for role in ('preimage', 'candidate')]
    for name, a, b in [('proposal', before, after), ('inverse', after, before)]:
        text = ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile='a/' + REL, tofile='b/' + REL))
        key = name + '.patch'; renamed = name + '-standalone18.patch'
        assert hashlib.sha256(text.encode()).hexdigest() == old['files'][key]
        (P / renamed).write_text(text)
        old['files'][renamed] = old['files'].pop(key)
    (P / 'standalone18-manifest.json').write_text(json.dumps(old, indent=2) + '\n')
(P / 'manifest.json').write_bytes((P / 'manifest90.json').read_bytes())
evidence = P / 'earlier-canonical72-counterexamples'; evidence.mkdir(exist_ok=True)
for file in CONCERN.iterdir():
    if file.is_file() and file.name != 'prepare_guard.py':
        shutil.copyfile(file, evidence / file.name)
files = []
for file in sorted(P.rglob('*')):
    if file.name in ('proposal.tar.gz', 'capsule.json'):
        continue
    assert not file.is_symlink()
    if not file.is_file():
        continue
    rel = file.relative_to(P).as_posix()
    assert not PurePosixPath(rel).is_absolute() and '..' not in PurePosixPath(rel).parts
    assert '__pycache__' not in rel and not rel.endswith('.pyc')
    data = file.read_bytes()
    files.append((rel, data))
assert len({rel for rel, data in files}) == len(files)
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for rel, data in files:
        info = tarfile.TarInfo(rel); info.size = len(data); info.mode = 0o600
        info.uid = info.gid = 0; info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
compressed = gzip.compress(raw.getvalue(), mtime=0)
(P / 'proposal.tar.gz').write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:gz') as archive:
    received = archive.getmembers()
    assert len(received) == len(files)
    for member, (rel, data) in zip(received, files):
        assert member.isfile() and member.name == rel
        assert archive.extractfile(member).read() == data
inventory = [{'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for rel, data in files]
fact = {'qualification': 'SAFE_REGULAR_MEMBER_SOURCE_AND_PORTABLE_RECEIVING_CAPSULE_NO_NATIVE_CREDIT',
        'capsule': 'proposal.tar.gz', 'bytes': len(compressed),
        'sha256': hashlib.sha256(compressed).hexdigest(), 'regular_members': len(files),
        'apply_scope': list(json.loads((P / 'manifest90.json').read_text())['paths']),
        'members': inventory}
(P / 'capsule.json').write_text(json.dumps(fact, indent=2) + '\n')
print(json.dumps({key: value for key, value in fact.items() if key != 'members'}, sort_keys=True))
print(json.dumps({name: hashlib.sha256((P / name).read_bytes()).hexdigest() for name in ['proposal.patch', 'inverse.patch', 'manifest90.json', 'capsule.json', 'REVIEW.md', 'owning90-receiving.json']}, sort_keys=True))
