-- Explicit semantic models of private diagnostic delegates, not native proof.
local source = assert(arg[1])
local passed = 0
local function fixture(defer_initialize)
	local model = { next_fd = 100, files = {}, written = {}, closes = {}, requests = {}, callbacks = {} }
	local function stat(pid, parent)
		local fields = { "S", tostring(parent), tostring(pid) }
		for i = 4, 19 do fields[i] = "0" end
		fields[20] = tostring(pid + 500)
		return tostring(pid) .. " (modeled native) " .. table.concat(fields, " ") .. "\n"
	end
	local native = {}
	function native.fs_open(path, flags)
		model.next_fd = model.next_fd + 1
		local fd = model.next_fd; model.files[fd] = { path = path, flags = flags }
		return fd
	end
	function native.fs_read(fd, capacity, offset, callback)
		if callback then
			model.callbacks.read = callback
			if model.refuse_read then return nil, "ORIGINAL-ERROR", "ORIGINAL-CODE" end
			return "ORIGINAL-READ-REQUEST", "ORIGINAL-ERROR", "ORIGINAL-CODE"
		end
		local pid = tonumber(model.files[fd].path:match("/proc/(%d+)/stat$")); assert(pid)
		return stat(pid, pid == 10 and 9 or 10)
	end
	function native.fs_write(fd, bytes, offset)
		assert(offset == 0); model.written[model.files[fd].path] = bytes; return #bytes
	end
	function native.fs_close(fd, callback)
		model.closes[fd] = (model.closes[fd] or 0) + 1
		if callback then model.callbacks.reader_close = callback; return "ORIGINAL-CLOSE-REQUEST" end
		if model.refuse_close then return nil end
		return true
	end
	function native.fs_fstat() error("unexpected metadata probe") end
	function native.fs_fsync() return true end
	function native.spawn(executable, options, callback)
		model.spawn_args, model.spawn_callback = { executable, options }, callback
		return "ORIGINAL-PROCESS", 11, "ORIGINAL-SPAWN-ERROR"
	end
	function native.write(handle, bytes, callback)
		model.write_args, model.callbacks.write = { handle, bytes }, callback
		return "ORIGINAL-WRITE-REQUEST"
	end
	function native.shutdown(handle, callback) model.callbacks.shutdown = callback; return "ORIGINAL-SHUTDOWN-REQUEST" end
	function native.close(handle, callback) model.callbacks.handle_close = callback; return nil end
	function native.new_timer() return "ORIGINAL-TIMER" end
	function native.timer_start(handle, delay, repeating, callback)
		model.callbacks.timer = callback; return 0
	end
	function native.hrtime() return 123000000 end
	local ffi = { C = { getpid = function() return 10 end, getppid = function() return 9 end } }
	local constructor = assert(loadfile(source))()
	local diagnostic = constructor(native, ffi, "/MODELED-PRIVATE-EVIDENCE", 9)
	local case
	if not defer_initialize then assert(diagnostic:initialize()); case = diagnostic:begin("names") end
	return model, native, diagnostic, case
end
local function test(name, callback)
	local model, native, diagnostic, case = fixture()
	callback(model, native, diagnostic, case); passed = passed + 1; print("MODEL PASS " .. name)
end

test("actual delegate identity and callback tuple are forwarded unchanged", function(model, native, diagnostic, case)
	local received
	local options = { stdio = { "STDIN", "STDOUT", "STDERR" } }
	local process, pid, err = native.spawn("tar", options, function(...) received = { ... } end)
	assert(process == "ORIGINAL-PROCESS" and pid == 11 and err == "ORIGINAL-SPAWN-ERROR")
	assert(model.spawn_args[1] == "tar" and model.spawn_args[2] == options and diagnostic:available())
	model.spawn_callback(7, 0)
	assert(received[1] == 7 and received[2] == 0 and case.child_exit_ack)
	assert(model.written["/MODELED-PRIVATE-EVIDENCE/spawn-002.json"] ==
		'{"schema":1,"role":"names","pid":11,"parent_pid":10,"group_id":11,"birth_ticks":511}\n')
end)

test("pending read distinguishes accepted request from observed callback", function(model, native, diagnostic, case)
	local called = 0
	local request, err, code = native.fs_read(123, 36, 0, function(first, second)
		assert(first == nil and second == "MODELED-PAYLOAD"); called = called + 1
	end)
	assert(request == "ORIGINAL-READ-REQUEST" and err == "ORIGINAL-ERROR" and code == "ORIGINAL-CODE")
	assert(case.read_submission == "accepted" and case.read_pending and called == 0)
	assert(diagnostic:checkpoint("await-deadline"))
	model.callbacks.read(nil, "MODELED-PAYLOAD")
	assert(case.read_submission == "callback" and not case.read_pending and called == 1)
end)

test("explicit refused native request cannot claim pending admission", function(model, native, diagnostic, case)
	model.refuse_read = true
	assert(native.fs_read(123, 1, 0, function() error("refused callback not delivered") end) == nil)
	assert(case.read_submission == "refused" and not case.read_pending)
end)

test("reader and pipe closes record only existing exact callbacks", function(model, native, diagnostic, case)
	native.spawn("tar", { stdio = { "STDIN", "STDOUT", "STDERR" } }, function() end)
	local closed = false
	assert(native.fs_close(123, function(err) assert(err == nil); closed = true end) == "ORIGINAL-CLOSE-REQUEST")
	assert(case.reader_close_pending and not case.reader_closed and not closed)
	model.callbacks.reader_close(nil, true)
	assert(not case.reader_close_pending and case.reader_closed and closed)
	native.close("STDIN", function() closed = "PIPE-ACK" end)
	assert(not case.stdin_closed)
	model.callbacks.handle_close()
	assert(case.stdin_closed and closed == "PIPE-ACK")
end)

test("private capture close refusal remains debt without duplicate close", function(model, native, diagnostic, case)
	model.refuse_close = true
	assert(not diagnostic:checkpoint("cleanup") and not diagnostic:available())
	local debt = diagnostic.files[#diagnostic.files]
	assert(debt.state == "uncertain-close" and model.closes[debt.fd] == 1)
	assert(not diagnostic:available() and model.closes[debt.fd] == 1)
end)

test("timer checkpoint precedes original expiry callback without new waits", function(model, native, diagnostic, case)
	local original_calls = 0
	local timer = native.new_timer()
	assert(timer == "ORIGINAL-TIMER")
	assert(native.timer_start(timer, 5000, 0, function(value)
		assert(value == "ORIGINAL-CALLBACK-ARG")
		assert(model.written["/MODELED-PRIVATE-EVIDENCE/checkpoint-001.json"]:find('"reason":"timer-fired"', 1, true))
		original_calls = original_calls + 1
	end) == 0)
	model.callbacks.timer("ORIGINAL-CALLBACK-ARG")
	assert(original_calls == 1 and diagnostic:available())
end)

do
	local model, native, diagnostic = fixture(true)
	assert(not diagnostic:available() and #diagnostic.files == 0)
	model.refuse_close = true
	assert(not pcall(diagnostic.initialize, diagnostic))
	local debt = diagnostic.files[1]
	assert(debt and debt.state == "uncertain-close" and model.closes[debt.fd] == 1)
	local acquired = model.next_fd
	assert(not pcall(diagnostic.initialize, diagnostic) and model.next_fd == acquired)
	assert(not diagnostic:available() and model.closes[debt.fd] == 1)
	passed = passed + 1
	print("MODEL PASS initialization failure retains exact acquired descriptor without reacquisition")
end

print(string.format("private tar diagnostics semantic models: %d completed,0 skipped; no native proof", passed))
