﻿; Shared unit/native desktop admission and initial receipt owners.
#Requires Autohotkey v2.0+
#SingleInstance Force
SetWorkingDir(A_ScriptDir)
#Warn All, StdOut
#Warn VarUnset, Off
; Parse runner flags:
;   --dry-run        parse/load gate only — register every test, skip execution.
;   --interactive    explicitly allow tests that activate windows or inject keys.
;   --only <substr>  run only tests whose name contains <substr> (case-insensitive),
;                    e.g. AutoHotkey64.exe run_all.ahk --only "(my-slug)" to replay
;                    a single failing test without the whole suite.
; Reject malformed options before includes can initialize tests or input hooks.
_RejectRunnerArguments(Message) {
	FileAppend("Invalid test runner arguments: " . Message . "`n", "**")
	ExitApp(2)
}

global _AHK_DRY_RUN := false
global _AHK_ONLY_FILTER := ""
global _AHK_INTERACTIVE := false
global _AHK_QUALIFICATION_PROFILE := ""
_riArgIndex := 1
while (_riArgIndex <= A_Args.Length) {
	_riArg := A_Args[_riArgIndex]
	if (_riArg == "--dry-run")
		_AHK_DRY_RUN := true
	else if (_riArg == "--interactive")
		_AHK_INTERACTIVE := true
	else if (SubStr(_riArg, 1, 24) == "--qualification-profile=") {
		if _AHK_QUALIFICATION_PROFILE != ""
			_RejectRunnerArguments("--qualification-profile may be supplied only once")
		_AHK_QUALIFICATION_PROFILE := SubStr(_riArg, 25)
		if _AHK_QUALIFICATION_PROFILE == ""
			_RejectRunnerArguments("--qualification-profile requires a non-empty id")
	}
	else if (_riArg == "--only" || SubStr(_riArg, 1, 7) == "--only=") {
		if StrLen(_AHK_ONLY_FILTER) > 0
			_RejectRunnerArguments("--only may be supplied only once")
		if (_riArg == "--only") {
			if (_riArgIndex >= A_Args.Length)
				_RejectRunnerArguments("--only requires a non-empty filter")
			_riArgIndex += 1
			_AHK_ONLY_FILTER := A_Args[_riArgIndex]
			if (SubStr(_AHK_ONLY_FILTER, 1, 2) == "--")
				_RejectRunnerArguments("a filter starting with -- requires the --only= form")
		} else
			_AHK_ONLY_FILTER := SubStr(_riArg, 8)
		if (Trim(_AHK_ONLY_FILTER, " `t`r`n") == "")
			_RejectRunnerArguments("--only requires a non-empty filter")
	} else
		_RejectRunnerArguments("unknown option or unexpected positional argument")
	_riArgIndex += 1
}

; Test framework first — Assert / Test / RunTests must exist before any
; subsequent file registers its cases or invokes assertions inside lambdas.
#Include test_framework.ahk
; Acquire the selected receipt before any bootstrap observation or test include.
_TestResultsBeginRun()

; AppState — must come before test_stubs.ahk because the stubs reference
; AppState fields directly, and before any infra/ file that reads AppState.
#Include ../infra/app_state.ahk

; Stubs second — they define ScriptInformation, Features, SendNewResult,
; WrapTextIfSelected, DeadKey, ToggleCapsLock, etc., which infra/ files
; reference at definition (Bind) time or at call time during tests.
#Include test_stubs.ahk
#Include ../modules/keylogger/keylogger_health.ahk

; Install a very early error handler for top-level / #Include phase errors.
; When a newly added production module (LLM, gestures, keylogger, prompt builder,
; menu_llm persist, etc.) or test_*.ahk has a top-level statement that throws
; (unset global, t() before i18n is ready, missing stub for a static initializer,
; bad include order, etc.) the default AHK behaviour is to show a modal error
; MsgBox. In the headless CI runner that dialog is never dismissed → the exe
; never exits → the step times out even if the previous green run was ~10 s.
; This handler writes a clear "not ok 0" line to the exact file the CI tailer
; watches and forces a clean ExitApp so the failure is visible and fast.
_FatalErrorHandler(e, mode) {
    msg := "not ok 0 - FATAL STARTUP ERROR: " . e.Message
    try 	msg .= "`r`nSTACK TRACE:`r`n" . e.Stack
	msg .= "`r`nLikely cause: top-level code or missing stub in a newly added module."
	global TEST_RESULTS_FILE
	try _TestResultsWrite(TEST_RESULTS_FILE, msg . "`r`n")
	try FileAppend(msg . "`r`n", "**")
	try FileAppend(msg . "`r`n", "*")
    ExitApp(1)
    return 1
}
OnError(_FatalErrorHandler)
