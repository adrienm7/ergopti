<!-- README.md -->

# Prepared headers and safe owned replacement proposal

This is a SOURCE-ONLY Linux TODO62 packet. No model, driver, native, compiler or
CI command has executed against these bytes. Main checkout, index and refs are
untouched. The immutable815/91bf GET/output packet and reviewed a336 output-hop
packet remain unchanged. Root owns application and final registration.

## Two explicit compositions

`candidate/` uses the integrated91bf/ee82/ae1f source contracts.
`output-hop-composition/candidate/` applies the SAME bounded preparation and
reservation changes to reviewed a336/d39/c35 output-hop sources. It does not
enable archive routing, replace its lease or change private output completion
ownership. Neither composition inherits qualification from its input packet.

`author.py` and `author_fixture_ports.py` are inert source-authoring helpers.
Their output must be byte-admitted through this packet inventory, not executed
against mutable main sources as a hidden preparation step.

## Header contract

A new shared pure `network.http_headers` converts sorted caller names/values
once with the existing canonical HeaderPolicy. Native preflight retains ordered
string rows behind an opaque lexical capability, and returns a detached plain
string view. Actual native composition consumes genuine capabilities only.
Raw caller values, public injection and a mutated view cannot replace retained
bytes. Legacy native callers without the capability retain their original
sorted conversion and empty-semicolon behavior.

Every managed dispatch gets a capability; every followed hop rebinds only an
unchanged subset after the existing shared sensitive-header transition law.
Duplicate normalized wire fields and their original order remain in private
rows. URL, proxy choice, output, metrics and deadline are not cached in tokens.
A token's weak registry lifetime follows its actual request/queued owner.

## Public admission and temporal meaning

A BOOLEAN incumbent permits exactly one owned tentative successor reservation.
Preparation happens while the incumbent remains its exact physical owner.
Invalid metadata leaves the valid incumbent running. Owned incumbents and an
existing successor refuse before caller metadata/source evaluation. Accepted
replacement owns its original absolute timer during the wait; cancellation,
clock/source reentry or expiry cannot acquire a child. Only predecessor native
and deadline close ACKs allow adoption/dispatch. Failed successor timer arming
retains its exact timer debt without cancelling a valid predecessor.

A native constructor terminal emitted synchronously is held until the returned
child's started receipt is known. Started children retain early logical failure.
A returned pre-start failure remains a terminal failure, retires the original
coordinator deadline timer and publishes only after actual physical child/timer
retirement. Delayed deadline callbacks cannot replace that known construction
failure. No native ownership function or exact process-group oracle is changed.

## Original native preflight cases168/180/196

The once-conversion regular→owned replacement168 stays on the ACTUAL PUBLIC
adapter, with its complete assertions unchanged. Owned→owned refusal196 also
stays public, preserves conversion==0 and never probes the incumbent source.
Only the historical late-allocation constructor180 scopes its get_owned port
to the ACTUAL single native Curl engine. All other ports in that exact scenario
still refer to the public adapter; its original assertion body is unchanged.
An additive public initial malformed-header scenario proves the stronger
managed preflight contract: one conversion, zero native handles/FDs/requests,
one settled refusal. This is an explicit contract distinction, not a wholesale
fixture retarget or weaker expectation.

## Bodycleanup14 observations

The source proposal delegates actual Curl.dispatch_owned unchanged and retains
its genuine token for observation. A monitor is excluded only while the fixture
intentionally withholds cleanup and only if that exact captured request owner,
operation, timer handle, open handle receipt and cleanup_monitor all match.
All other handles, including closing handles, remain debt. The exclusion ends
before recovery, which requires all native handles/FDs and the timer ACK.
The original14 case count, literal resource expectations and sentinel/reuse
assertions are unchanged. Protected fixture restoration does not claim cleanup
success if its observation fails. Actual native qualification is UNEXECUTED.

## Independent controls and required replay

Four new model modules contain32 explicitly authored controls:11 pure header,
9 actual public wrapper/real-core native-port,7 native capability and5 logical/
physical construction controls. The new prepared_native_ports helper retains
the historical meta4df factory prefix and adds protected loader restoration;
no original assertion bodies are relocated. The existing authorization27
fixture gets only an explicit new preflight receipt/rebind port; its original
metadata callbacks and complete assertion tail remain unchanged.

Before any application, request bounded peer source review of both composition
and fixture scopes. Then request an exclusive serialized slot to stage exact
current root dependencies and exercise both runtimes sequentially. Replay the
UNCHANGED input producer with new literal controls as causal evidence separately
from candidate outcomes. Retain original137/FD88 and owner suites. Native
preflight25/bodycleanup14 plus original335 cohort require genuine curl/luv/
physical receipts and ordinary UID; failure stops qualification. No test outcome
is claimed here. Native body-pipe1ms timeout contract disposition remains a
separate outstanding prerequisite; do not infer this packet resolves it.
