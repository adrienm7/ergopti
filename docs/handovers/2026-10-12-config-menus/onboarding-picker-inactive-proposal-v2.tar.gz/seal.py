from pathlib import Path
import json,hashlib,tarfile,gzip,io
p=Path(__file__).parent
v1=p.parent/'resume-onboarding-picker-inactive-proposal.tar.gz'
assert hashlib.sha256(v1.read_bytes()).hexdigest()=='cd2e9dcef92973d08b018ae7390cf6f862b52cf539416a59a54e0e4f2d403b22'
files={str(f.relative_to(p)):f.read_bytes() for f in p.rglob('*') if f.is_file() and f.name!='SEALED-RECEIPT.json'}
files['SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\n' for n,b in sorted(files.items())).encode()
out=p.parent/'resume-onboarding-picker-inactive-proposal-v2.tar.gz';assert not out.exists()
with out.open('xb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for n,b in sorted(files.items()):
    m=tarfile.TarInfo(n);m.mode=0o644;m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
receipt={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(files),'bytes':out.stat().st_size,'native_execution':'UNRUN','inactive':True,'original_tests_preserved':True,'added_tests':4,'subjects':7,'prior_seal_preserved':True,'no_canonical_edits':True}
(p/'SEALED-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
