from pathlib import Path
import subprocess,os,json,datetime
from zoneinfo import ZoneInfo
O=Path('/workspace/scratch/oct28-field-admission')
with(O/'quick-producer.log').open('wb')as out:
 p=subprocess.Popen(['python3',str(O/'quick-followup.py')],stdout=out,stderr=subprocess.STDOUT)
 (O/'quick-producer.json').write_text(json.dumps({'wrapper_pid':os.getpid(),'producer_pid':p.pid})+'\n')
 rc=p.wait()
(O/'quick-tool-exit.json').write_text(json.dumps({'actual_child_wait_exit':rc,'finished_paris':datetime.datetime.now(ZoneInfo('Europe/Paris')).isoformat()})+'\n')
