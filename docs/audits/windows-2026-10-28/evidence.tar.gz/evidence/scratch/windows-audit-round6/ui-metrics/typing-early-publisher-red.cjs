const assert=require('node:assert/strict'),fs=require('node:fs');
const html=fs.readFileSync('/workspace/ergopti-windows-r6-ui-metrics/static/ergopti_plus/_shared/ui/metrics_typing/index.html','utf8');
const {loadMetricsTypingPage}=require('./typing-page-probe-fixture.cjs');
const payload={manifest:{'2026-01-01':{Editor:{chars:30,time:60000}}},app_icons:{},kc_layout:{}};
let initialized=false,receipt;
process.env.TZ='UTC';
const page=loadMetricsTypingPage('macos',(name,context)=>{
 if(!initialized){
  initialized=true;const nodes=new Map();const original=context.document.getElementById;
  for(const match of html.matchAll(/<([a-z][a-z0-9]*)\b([^>]*\bid="([^"]+)"[^>]*)>/gi)){
   if(match[1]==='canvas')continue;const node=context.document.createElement(match[1]);node.value=match[2].match(/\bvalue="([^"]*)"/)?.[1]||'';
   const classes=new Set((match[2].match(/\bclass="([^"]*)"/)?.[1]||'').split(/\s+/));node.classList={contains:x=>classes.has(x),add:x=>classes.add(x),remove:x=>classes.delete(x),toggle:x=>classes.has(x)?classes.delete(x):classes.add(x)};nodes.set(match[3],node);
  }
  context.document.getElementById=id=>nodes.get(id)||original(id);
  const fixed=Date.parse('2026-01-01T12:00:00Z');context.Date=class ClockPort extends Date{constructor(...args){super(...(args.length?args:[fixed]));}static now(){return fixed;}};
 }
 if(name==='data.js'){
  receipt={phase:name,publisher:typeof context.publishTypingMetricsData,charts:typeof context.render_charts};
  try{context.publishTypingMetricsData(payload,{manifest_revision:1,assets_revision:1});}catch(error){receipt.error=error.message;}
 }
});
receipt.afterAllScripts={charts:typeof page.context.render_charts,retryAccepted:page.context.publishTypingMetricsData(payload,{manifest_revision:1,assets_revision:1})};
console.log(JSON.stringify(receipt));assert.equal(receipt.publisher,'undefined','native readiness must stay closed until all rendering dependencies exist');
