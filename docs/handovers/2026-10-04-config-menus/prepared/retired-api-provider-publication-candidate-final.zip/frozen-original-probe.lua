local root = assert(arg[1])
package.path = root .. '/static/ergopti_plus/linux/?.lua;' .. root .. '/static/ergopti_plus/linux/?/init.lua;'
    .. root .. '/static/ergopti_plus/_shared/lua/?.lua;' .. root .. '/static/ergopti_plus/_shared/lua/?/init.lua;' .. package.path
require('compat.utf8').install()
local helpers = require('tests.helpers')
local Json = require('json')
local Logger = require('logger.shim')
local warnings, errors = {}, {}
local real_warn, real_error = Logger.warn, Logger.error
Logger.warn = function(_, fmt, ...) warnings[#warnings + 1] = string.format(fmt, ...) end
Logger.error = function(_, fmt, ...) errors[#errors + 1] = string.format(fmt, ...) end
require('config_outdated').reset_for_tests()
local path = os.tmpname()
local source = [[{"version":1,"active_id":"retired-1","entries":[{"id":"retired-1","provider":"removed_vendor_for_probe","label":"Old provider","token":"not-a-real-credential","future":{"empty":[],"nothing":null}},{"id":"usable-1","provider":"cerebras","label":"Usable provider","token":"not-a-real-credential"}],"future_root":{"flag":false}}]]
local file = assert(io.open(path, 'wb')); assert(file:write(source)); assert(file:close())
local Entries = helpers.load_module('modules.llm.api_entries'); Entries._set_path_for_test(path)
local Remote = helpers.load_module('modules.llm.api_remote')
assert(Remote.provider('removed_vendor_for_probe') == nil, 'real published provider owner proves this identity retired')
assert(Remote.provider('cerebras') ~= nil, 'real published provider control must be usable')
local initial = Entries.list()
local initial_active = Entries.active()
local observed = {}
for _, entry in ipairs(initial) do observed[#observed + 1] = entry.id end
local accepted = Entries.set_active('usable-1')
file = assert(io.open(path, 'rb')); local published = assert(file:read('*a')); assert(file:close())
local actual = assert(Json.decode_lossless(published))
local expected = assert(Json.decode_lossless([[{"version":1,"active_id":"usable-1","entries":[{"id":"retired-1","provider":"removed_vendor_for_probe","label":"Old provider","token":"not-a-real-credential","future":{"empty":[],"nothing":null}},{"id":"usable-1","provider":"cerebras","label":"Usable provider","token":"not-a-real-credential","model":"","base_url":""}],"future_root":{"flag":false}}]]))
local function equal(a,b)
    if type(a)~=type(b) or Json.is_array(a)~=Json.is_array(b) or Json.is_null(a)~=Json.is_null(b) then return false end
    if Json.is_null(a) then return true end
    if type(a)~='table' then return a==b end
    for key,value in pairs(a) do if not equal(value,b[key]) then return false end end
    for key in pairs(b) do if a[key]==nil then return false end end
    return true
end
local preserved = equal(actual, expected)
print('published provider absent=true; usable neighbor present=true')
print('runtime ids=' .. table.concat(observed, ','))
print('initial active=' .. tostring(initial_active and initial_active.id))
print('ordinary selection acknowledged=' .. tostring(accepted))
print('independent full published model retained=' .. tostring(preserved))
print('warnings=' .. #warnings .. '; errors=' .. #errors)
assert(os.remove(path)); os.remove(path .. '.tmp')
Logger.warn, Logger.error = real_warn, real_error
assert(accepted == true, 'usable neighbor selection must publish through the real owner')
if arg[2] == 'preservation' then
    assert(preserved, 'ordinary selection must retain the complete ignored retired-row source model')
end
assert(#initial == 1 and initial[1].id == 'usable-1', 'retired provider entry must be ignored while usable neighbor survives')
assert(initial_active == nil, 'retired provider must not become runtime active')
assert(#warnings == 2 and #errors == 0, 'retired row and dangling selection require warning-once, never ERROR')
