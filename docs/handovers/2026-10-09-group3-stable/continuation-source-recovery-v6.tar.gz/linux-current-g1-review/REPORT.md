# Independent review of the current G1 / Linux93 source union

Verdict: **SOURCE_CLEAR_PRIVATE_CURRENT_G1_SOURCE_UNION**. The23-path source patch is applicable only to the exact published `1028f6bd3eeb08a1aa50f96d1ad9738d2826d7bb` preimages (22 existing files, one new fixture). No canonical adoption, native enablement, full current-union suite or physical qualification is claimed here.

## Source preservation

All406 author seals,45 safe regular archive members and23 actual Git preimages verify independently. The actual G1 feature is `cbe96086b90ec8085895a505c0ee5a7975089dc3`; `96297a0d6b605a67eac2b48023f825b1e1572a0d` contains the already merged Root handover above that feature;1028 integrates it. These frames are distinguished explicitly.

The two overlaps are limited to six contextual blocks in manifest.toml and one prompt_delay block in Linux menu_builder.lua. Peeling those seven blocks reconstructs both complete original G1 images byte-exact against cbe/962/1028. Every other21 source postimage is byte-exact to the qualified V3 tree `f5ca71ad756a945cf4781222c1ccf636339d2aeb`. No old test bodies, source admission fences, master-state policies, typed defaults or third-slot refusals are changed by this union.

Of the31 paths in the G1 feature,27 other runtime/source images are exact to cbe, one current TODO image is exact to its legitimately merged962/1028 bytes, two source overlaps are recovered by the exact peel, and one generated shared menu is assessed through the original generator. The patch does not touch documentation. The TODO was already different from cbe before this union; it is not falsely described as byte-exact to the earlier feature commit.

The original owner commands `npm run build:manifest` and `npm run build:menu` were independently run in both private complete generator contexts. All14 generated outputs reproduce their frozen hashes. The generated G1 baseline menu equals the committed1028 bytes, while the composed menu structurally changes only `key_combinations_group`. Every other menu group and original G1 generator implementation stays exact. Generated snapshots remain private references; parent/owners must regenerate on their final sources. Four private forward/inverse patch checks and applications preserve all23 source pairs exactly.

## Independent bounded executions

Both actual LuaJIT and Lua5.4 execute the genuine original G1 AI-parent22/0, original hotstring language-frame5/0, and original Group3 menu/21-locales8/0 cohorts. The real composed builder calls the original pair provider and supplies its actual delay callback; a controlled text-prompt port observes current150, declared100 and unchanged cancellation=nil. This is a functional assertion probe, not an empty0/0 unit-suite success. The exact peeled G1 builder fails that same probe on the missing callback on both ABIs.

Seven complete unchanged G1/G3 Node guards pass: category submenu order, unavailable menu rows, menu category coverage, original catalogue/source owner, first menu group, restrictions explanation, and Linux software parity. The entirely peeled manifest is legitimately GREEN for the conditional catalogue guard: removing the Linux declaration removes its guarded simultaneous branch. That inverse is explicitly noncausal, not a supposed RED proof. The original current candidate guard is re-executed to preserve separate input pins from that conditional observation.

One initial reviewer sparse-graph run lacked the genuine original `tests.support.llm_preferences_fixture` and exited during imports before executing product cases. Its raw log/result are retained. Pinning all required original G1 dependency bytes from actual Git1028 produced the terminal passes above, with no stub substitution or assertion changes. Author history also retains its initial locale-context7/1, repaired by completing the original graph, and its initial incorrect expected RED for the conditional whole-manifest peel. No source image was changed to obtain those contextual corrections.

Author-only observations retained separately: the unchanged complete G3 targeted cohorts37/216/81/27/8 each pass on both ABIs; the genuine regenerated original-G1-defaults counterfactual is199/17 on each ABI. Those executions were not duplicated as new scenarios by this reviewer. The21 source postimages are already exact to the earlier qualified V3 tree.

## Authority and remaining qualification

Custody is the narrow released G1 source scope recorded at6082330742; no ownership of new shared regions, workflows or generators is inferred. The406 author seals and89 prior independent V3 seals remain exact after replay. All writes were private; canonical/index/refs/CI and Root's shared projection were untouched by this reviewer.

The previous Root terminal receipt202773/f5ca records404 JS,17783 HS,12567 Linux and189 Linux E2E successes, virtual E2E101 passed/1 skipped, with AHK native skipped on Linux and kernel/physical unrun. That receipt qualifies the previous V3 sources only. Root must run the current combined source qualification after adoption/regeneration and any native CI required for the final changes. These controlled Lua/UI-port/Node observations do not prove actual uinput, Xorg/Wayland, GUI, packaging or installation behavior. All13 Group3 TODOs remain partial;16/38 stay;22 remains withdrawn.
