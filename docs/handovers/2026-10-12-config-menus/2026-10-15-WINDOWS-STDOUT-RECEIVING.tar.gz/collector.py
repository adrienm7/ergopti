#!/usr/bin/env python3
"""Seal terminal bounded Windows follow-up evidence without executing or publishing."""
from pathlib import Path
import json,subprocess,hashlib,io,gzip,tarfile,re,os
b=Path('/workspace/.ergopti-cloud');repo=Path('/workspace/ergopti')
sha='ae6245f0a158290c600a3589d0e32db2273c971f';old='840004ea43505538ff00c48ca10f64dca3c1b0b5'
out=b/'2026-10-15-WINDOWS-STDOUT-RECEIVING.tar.gz'
assert not out.exists()
def h(data):return hashlib.sha256(data).hexdigest()
def stable(p):
 with p.open('rb') as f:
  before=os.fstat(f.fileno());data=f.read();after=os.fstat(f.fileno())
 assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
 return data
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
status=json.loads((b/'folder-intent-windows-followup-38663542439-status.json').read_text())
assert status['status']=='completed' and status['head_sha']==sha
assert status['tree']==git('rev-parse',sha+'^{tree}').decode().strip()
files={}
for p in sorted(b.glob('folder-intent-windows-followup-*')):
 if p.is_file() and p.suffix in {'.json','.md','.py','.log'}:
  data=stable(p)
  assert not re.search(rb'https?://[^\s\"]*[?&](?:sig|signature|token|x-amz-signature)=',data,re.I)
  files['receipts/'+p.name]=data
assert any(name.endswith('terminal-receipt.json') for name in files),'Missing independent terminal receipt'
paths=['tools/test/test-ahk-suite-manifest.cjs','static/ergopti_plus/_shared/ahk/tap_hold/buffered_data_snapshot_owner.ahk','static/ergopti_plus/windows/tests/unit/test_buffered_data_snapshot_owner.ahk','static/ergopti_plus/windows/tests/run_all.ahk','static/ergopti_plus/windows/tests/test_framework.ahk']
for source in (old,sha):
 for name in paths:files['sources/'+source+'/'+name]=git('show',source+':'+name)
files['collector.py']=stable(Path(__file__))
files['README.md']=('''# Refreshed Windows native stdout refusal

This packet receives manual run 38663542439 on exact CI ae6245f0a158290c600a3589d0e32db2273c971f, copied append-only from Dev d60ad231ae41c7391c1012c5feb9fc5723bbcca4. It includes the published seventeen-case receiver correction. The independent terminal receipt records complete paginated API jobs/annotations, source/tree joins, terminal counts and Release outcome.

Windows units fail `snapshot16 complete stdout differs`, comparing full native stdout with disk TAP minus BOM. This is distinct from the preceding source-pin refusal. Exact native output bytes and failing phase were not received; no warning cause is inferred. General Windows units and the two new wizard initializer cases remain UNRUN/unqualified. Preserve #Warn, original callbacks and all full-output/source/exit assertions. Native stderr, selection and TAP assertions after the refused comparison are unqualified.

All-OS run 38658948881, local portable suites, genuine GTK source sessions and Chromium are separate evidence in the sibling 2026-10-15 receiving packet. This follow-up does not establish installed wizard, physical-device or whole-group acceptance. Every Group 1 item remains partial. No production/test/workflow source is modified by this documentary packet.

Read receipts/folder-intent-windows-followup-root-handoff.md for the precise Root-owned receiving action. Historical active observations remain historical; the completed terminal receipt and status are authoritative. API metadata is not complete native logs or a native SDK fingerprint. Source files here are literal immutable Git bytes, never replacement expectations.
''').encode()
manifest={'run_id':38663542439,'source_commit':sha,'source_tree':status['tree'],'dev_source':'d60ad231ae41c7391c1012c5feb9fc5723bbcca4','scope':'PAGINATED_API_AND_LITERAL_SOURCES; NO_COMPLETE_NATIVE_STDOUT_OR_SDK_RECEIVING','terminal_status':status,'members':{n:{'bytes':len(v),'sha256':h(v)} for n,v in sorted(files.items())}}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
files['SHA256SUMS']=''.join(h(v)+'  '+n+'\n' for n,v in sorted(files.items())).encode()
with out.open('xb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tf:
 for n,v in sorted(files.items()):
  t=tarfile.TarInfo(n);t.size=len(v);t.mode=0o644;t.mtime=0;t.uid=t.gid=0;tf.addfile(t,io.BytesIO(v))
with tarfile.open(out,'r:gz') as tf:
 assert tf.getnames()==sorted(files)
 for n,v in files.items():assert tf.extractfile(n).read()==v
 for line in tf.extractfile('SHA256SUMS').read().decode().splitlines():
  digest,n=line.split('  ',1);assert h(tf.extractfile(n).read())==digest
print(json.dumps({'archive':str(out),'sha256':h(out.read_bytes()),'members':len(files),'member_hashes_verified':True}))
