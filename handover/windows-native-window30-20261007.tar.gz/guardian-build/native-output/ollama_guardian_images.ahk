﻿; _generated/ollama_guardian_images.ahk
#Requires AutoHotkey v2.0

/** Returns fresh code pins generated from the qualified guardian build. */
OllamaGuardianCodePins() {
	global _VendorDir
	return Map(
		"NativeModule", Map("path", _VendorDir . "\ollama\ergopti_guardian_bridge.dll", "bytes", 165888, "sha256", "669605b0a42109766165f65edd9f02398e98f6169ed9a3b2ef47748e7e1a9bdb"),
		"Guardian", Map("path", _VendorDir . "\ollama\guardian_host.exe", "bytes", 100864, "sha256", "04cda8742d9b944738d0db1672476cd8eb2dfeb60effcdfea0813d995c495098"),
		"ManagedBridge", Map("path", _VendorDir . "\ollama\SourceProducerNative.dll", "bytes", 6656, "sha256", "0a9825679516f0f4f264ee6a402ac148d037f33c8ff3745f2135c210d023697e"),
		"FilesHelper", Map("path", _VendorDir . "\ollama\ollama_managed_files.ps1", "bytes", 60297, "sha256", "71683265c0e44b33a7890bd8a206151e26516bc95432c5b70251960863579117"),
		"PublicationHelper", Map("path", _VendorDir . "\ollama\ollama_publication_owner.ps1", "bytes", 25556, "sha256", "f3f1b0bd32818b7f40309f8e092ff19425512f5c7d5c7158ab0a81b814d70272"),
		"ProducerHelper", Map("path", _VendorDir . "\ollama\ollama_source_producer.ps1", "bytes", 20601, "sha256", "39a8025762b16eade2c395582584d34b5a4a5e0061ba31689f36d7bd37034f42"),
		"SourceWorker", Map("path", _VendorDir . "\ollama\ollama_source_worker.ps1", "bytes", 10583, "sha256", "476cadbe54deced1553de1c8927ac4571c0c44648abd41514ed6fcd4e6b3153f"),
		"Launcher", Map("path", _VendorDir . "\ollama\ollama-runtime-launch.ps1", "bytes", 1737, "sha256", "66b671b4e40fc32ede4995270c584f65de3ae82da6a865d28be93fd660fa84db"),
		"InstallWorker", Map("path", _VendorDir . "\ollama\ollama_install_worker.ps1", "bytes", 6127, "sha256", "6f490b9f4cc340c18c128e6d89a1dbd98f988d52f93ba961625d19cb4332d3ef")
	)
}
