# Private Snapshot16 registration binding proposal

Status: SOURCE PROPOSAL; independent review, owner custody and runtime receiving pending.
Source commit: `60adb7e83d504b04ca807bfda8657254cccae306`.
Nothing in the canonical checkout, index, refs, warning policy, runner, framework or CHECKS was changed.

The actual hosted run 38246997305 attempt 2 launched one dry child, which exited 0.
Its TAP contains only the boot/plan/filter/dry-skip transcript (445 bytes); stdout contains
1,253,792 bytes. Strict receiving failed at byte 0: expected `#`, observed `D`.
The retained tail contains genuine LocalSameAsGlobal warnings in existing functions.
No Snapshot16 native execution was launched. There is no claim of sixteen passed cases.

Thirty-two bare registration bindings for the eight observed symbol names occur in
fifteen existing fixtures. All thirty-two original registration blocks are exact in
Main63cf and Dev9ad. Neither new Snapshot owner nor its unit fixture creates one of
these eight global names. Main's isolated native-desktop runner does not include
these fifteen fixtures; its success does not qualify the ordinary whole runner.

## Proposed source scope

The patch alpha-renames only the observed registration binding and its code references
inside each original loop to a fixture-specific `...Registration...` identifier.
The scope is still top-level, and loop/data/callback behavior and registration ordering
are retained. It does not move declarations, wrap callbacks, introduce helpers or
change function-local variables. Function/property member names such as `.Name` are
unchanged. String literals and comments remain exact, including labels, callback
name arrays and independent expected values. Bind targets/argument ordering are
unchanged except for the corresponding variable-name substitution.

Every proposed identifier was absent (case-insensitive Git search) from the committed
ErgoptiPlus and tools sources. This is collision avoidance against the received source,
not protection from arbitrary future code. All bytes outside the closed spans are
unchanged. The exact alpha inverse restores every complete original image. All fifteen
files retain BOM and LF. Git, working-file and index preimages matched at receiving.
No functions or assertion bodies were modified. No suite/compiler/runtime was executed.

Paths below are relative to `static/ergopti_plus/windows/tests/`; lines refer to the
unchanged original and candidate line numbering.

| Fixture | Closed registration spans |
| --- | --- |
| meta/test_secure_field_stale_verdict_fails_closed.ahk | 354–359 Owner, 485–487 Owner |
| unit/test_config_full_save_generation.ahk | 1468–1470 Name, 1611–1613 Name |
| unit/test_config_migrate.ahk | 915–920 Index, 922–934 Index, 1337–1339 Name, 1340–1342 Name |
| unit/test_config_transition_runtime.ahk | 480–482 Name, 483–485 Name, 486–488 Name |
| unit/test_config_transition_windows_port.ahk | 505–507 Name, 685–688 Callback, 798–801 Callback |
| unit/test_config_write_terminal_barrier.ahk | 240–245 Name, 246–248 Name, 276–278 Name, 506–511 Name, 512–514 Name, 707–709 Name |
| unit/test_json_object_key_nul.ahk | 14–19 Source |
| unit/test_klr_cache_encryption.ahk | 250–252 Worker |
| unit/test_language_deferred_declared_parent.ahk | 230–233 Owner, 236–238 Owner, 264–265 Name, 268–269 Owner |
| unit/test_llm_api_remote.ahk | 1660–1662 Index |
| unit/test_llm_menu_transactions_20260813.ahk | 3088–3089 Command |
| unit/test_logger_native_write.ahk | 177–178 Count |
| unit/test_managed_remote_transport.ahk | 2492–2494 Index |
| unit/test_metrics_range_date_types.ahk | 45–50 Index |
| unit/test_walker_json_flush_merge.ahk | 221–223 Source |

## Bounds and causal receiving plan

These are the eight names observed in the closed tail, not an exhaustive warning census
of the unavailable complete stdout. Other top-level bindings (e.g. Metadata, Subject,
Spec, Value or Budget), builtin-name collisions and other warning kinds remain outside
this proposal. Eliminating these thirty-two sites is not yet evidence of a warning-free
whole runner or a qualified Snapshot16 implementation.

After owner grants and the active gate ends, use official Windows CI only:

1. Receive the same original whole-runner dry transcript with strict stdout/TAP equality
   and unchanged native/deadline/census/source checks. The current actual dry failure is
   retained as the original observation; do not reinterpret it as assertion failures.
2. A finite causal counterfactual may restore just the uniquely original `Worker` loop
   after the candidate and require the original LocalSameAsGlobal Worker warnings to
   reappear in unchanged original functions. There is exactly one Worker-producing
   site in this received fixture census. Keep #Warn enabled and preserve full evidence.
   If another source of Worker exists in the composed include graph, record that premise
   rather than credit the single-site omission as independently causal.
3. The final candidate must preserve the exact whole original enrollment and labels,
   then pass dry receiving before running the same original sixteen native cases.
   If another warning remains, retain its actual source and fail; do not normalize,
   truncate or remove the strict receiver assertion. Do not borrow isolated runner or
   release-branch results as qualification of this composition.

A temporary diagnostic comparison without the two Snapshot includes could establish
which old function warnings predate that inclusion, but it would be a separate
nonqualifying observation: it cannot enroll or qualify the sixteen cases and is not
needed to adopt this source proposal. No such runtime was executed here.

## Ownership and follow-up

Parent must obtain explicit narrow fixture spans from the actual owners: configuration/
language and transition fixtures, LLM/managed transport, logger/KLR/security, and the
remaining JSON/walker/metrics fixtures. This packet grants no custody and changes no
shared runner/framework/workflow/inventory or source-pin declarations. Any subsequent
committed-source inventory must authenticate the actual final composition without
regenerating expected labels, weakening assertions or borrowing native coverage.
