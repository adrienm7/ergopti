from pathlib import Path
import subprocess,json,hashlib,shutil,sys,os
p=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g3-number-row-current135-private-prototype-v1');cases=p/'source-control-runs';cases.mkdir(exist_ok=True);rows=json.loads((cases/'results-in-progress.json').read_text());fixtures=json.loads((p/'sparse-fixtures.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest();node='/workspace/.ergopti-cloud/node-v22.22.2-linux-x64/bin/node';assert Path(node).is_file()
recipe='tools/diagnostics/fixtures/number-row-native-causal/projection-manifest.original-c15.json.raw';receiver='tools/diagnostics/number_row_native_causal.py';receiver_sha=h((p/'postimages'/receiver).read_bytes());basis=Path('/workspace/.ergopti-cloud/continuation-2026-10-14/g5-number-row-source-basis-received-v1/members/source-review-basis')
def run(name,argv,cwd,expected=0):
 dest=cases/name;assert not dest.exists();dest.mkdir();(dest/'argv.json').write_text(json.dumps({'argv':argv,'cwd':str(cwd),'expected_exit':expected,'role':'source/controlled receiving only, no native execution'},indent=2)+'\n')
 proc=subprocess.run(argv,cwd=cwd,capture_output=True,timeout=120);(dest/'stdout.raw').write_bytes(proc.stdout);(dest/'stderr.raw').write_bytes(proc.stderr);(dest/'exit.raw').write_text(str(proc.returncode)+'\n');row={'name':name,'exit':proc.returncode,'stdout_sha256':h(proc.stdout),'stderr_sha256':h(proc.stderr),'role':'source-only or controlled portable receiving, no native/GHA authority'};rows.append(row);(cases/'results-in-progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,proc.returncode,flush=True)
 if proc.returncode!=expected: print(proc.stderr.decode(errors='replace')[-4500:],flush=True);raise RuntimeError(name+' failed; original raw outputs retained')
 return proc
for fixture in fixtures:
 name=fixture['fixture'];root=Path(fixture['root']);head=fixture['actual_private_controller_commit'];outside=cases/(name+'-inputs');
 if name=='current135':outside.mkdir()
 projection=outside/'projection';evidence=outside/'evidence';historical=outside/'historical-controls';receiving=outside/'receiving'
 for x in [projection,evidence,historical,receiving]:
  if name=='current135':x.mkdir()
 approval=(root/'tools/diagnostics/fixtures/number-row-native-causal/g5-source-approvals.json.raw') if name=='legacy69' else p/'provisional-current135-envelope.json';approval_sha=h(approval.read_bytes());composition=outside/'composition.json'
 if name=='current135':
  run(name+'-generator',[sys.executable,'-B','tools/diagnostics/generate_number_row_source_composition.py','--head',head,'--recipe',recipe,'--approval',str(approval),'--approval-sha256',approval_sha,'--receiver',receiver,'--output',str(composition)],root)
  composition_sha=h(composition.read_bytes())
  run(name+'-preparer',[sys.executable,'-B','tools/diagnostics/prepare_number_row_native_causal.py','--composition-controls',head,recipe,str(projection),str(evidence),receiver,receiver_sha,str(composition),composition_sha,str(approval),approval_sha,str(historical)],root)
  argv=[sys.executable,'-B','tools/diagnostics/test_number_row_source_composition.py','--repo',str(root),'--head',head,'--recipe',str(root/recipe),'--approval',str(approval),'--approval-sha256',approval_sha,'--composition',str(composition),'--composition-sha256',composition_sha,'--projection',str(projection),'--original-producer',str(evidence/'NumberRowSourceProbe.original.swift'),'--receiver',str(root/receiver),'--positive-receiver',str(root/'tools/diagnostics/keyboard_geometry_xctest_receipt.py'),'--receiving',str(receiving),'--controls-projection',str(historical)]
  if name=='current135':argv += ['--current-build','--source-basis',str(basis),'--canonical-repo','/workspace/ergopti']
  run(name+'-composition-controls',argv,root)
 portable=outside/'portable-receiving-node22';portable.mkdir()
 run(name+'-original53-node22',[sys.executable,'-B','tools/diagnostics/test_number_row_native_causal.py','--fixture-manifest',str(root/'tools/diagnostics/fixtures/number-row-native-causal/fixture-manifest.json.raw'),'--projection',str(historical),'--receiving',str(portable),'--receiver',str(root/receiver),'--positive-receiver',str(root/'tools/diagnostics/keyboard_geometry_xctest_receipt.py'),'--transport',str(root/'tools/diagnostics/tis_evidence_transport.cjs'),'--node',node,'-v'],root)
(cases/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2),flush=True)
