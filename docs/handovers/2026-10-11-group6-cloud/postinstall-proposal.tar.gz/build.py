from pathlib import Path
import argparse
import hashlib
import json
import difflib

parser = argparse.ArgumentParser()
parser.add_argument('--repository', default='/workspace/ergopti')
ROOT = Path(parser.parse_args().repository).resolve()
OUT = Path(__file__).resolve().parent
WIRE = Path('static/ergopti_plus/macos/tests/support/native_http_wire_fixture.py')
TEST = Path('tools/test/macos_native_http_receiving_facts_test.py')
source = (ROOT / WIRE).read_text()
spans = [
    ('            self.trust_attempted = True\n            self._command(\n',
     '            self.trust_attempted = True\n            # A diagnostic query shares the original installation budget; it\n            # cannot start a fresh clock after the native add command settles.\n            deadline = time.monotonic() + 15 if self.trust_query_executable is not None else None\n            self._command(\n'),
    ('                trust_operation="add",\n            )\n        elif self.trust_attempted:\n',
     '                trust_operation="add",\n                deadline=deadline,\n            )\n            if deadline is not None:\n                original_fact = self.command_fact\n                try:\n                    self._observe_admin_trust(deadline, after_install=True)\n                finally:\n                    # A settled optional refusal cannot overwrite the original\n                    # add outcome. Unsettled query authority remains blocking.\n                    if self.command_fact is None or self.command_fact["phase"] != "settle":\n                        self.command_fact = original_fact\n        elif self.trust_attempted:\n'),
    ('    def _observe_admin_trust(self, deadline, *, after=False):\n',
     '    def _observe_admin_trust(self, deadline, *, after=False, after_install=False):\n'),
    ('            prefix = "# native_http_admin_trust_after " if after else "# native_http_admin_trust "\n            print(prefix + json.dumps(fact, sort_keys=True), flush=True)\n',
     '            prefix = (\n                "# native_http_admin_trust_installed "\n                if after_install\n                else "# native_http_admin_trust_after "\n                if after\n                else "# native_http_admin_trust "\n            )\n            if after_install:\n                # PAC owns stdout exclusively for its original JSON replies.\n                print(prefix + json.dumps(fact, sort_keys=True), file=sys.stderr, flush=True)\n            else:\n                print(prefix + json.dumps(fact, sort_keys=True), flush=True)\n'),
]
candidate = source
for old, new in spans:
    assert candidate.count(old) == 1
    candidate = candidate.replace(old, new, 1)
inverse = candidate
for old, new in reversed(spans):
    assert inverse.count(new) == 1
    inverse = inverse.replace(new, old, 1)
assert inverse == source
extra = (OUT / 'additional_tests.py').read_text()
original_tests = (ROOT / TEST).read_text()
anchor = '\n\nif __name__ == "__main__":\n    unittest.main()\n'
assert original_tests.count(anchor) == 1
candidate_tests = original_tests.replace(anchor, '\n\n' + extra + anchor, 1)
assert candidate_tests.replace('\n\n' + extra + anchor, anchor, 1) == original_tests
for relative, before, after in [(WIRE, source, candidate), (TEST, original_tests, candidate_tests)]:
    for directory, body in [('preimage', before), ('candidate', after)]:
        target = OUT / directory / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(body)
    patch = ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile='a/' + str(relative), tofile='b/' + str(relative)))
    with (OUT / 'proposal.patch').open('a' if relative == TEST else 'w') as output:
        output.write(patch)
manifest = {'schema': 1, 'base': '5f7a8467c9', 'scope': 'source-only unadopted proposal; no native credit', 'files': {}}
for relative in (WIRE, TEST):
    manifest['files'][str(relative)] = {directory: hashlib.sha256((OUT / directory / relative).read_bytes()).hexdigest() for directory in ('preimage', 'candidate')}
manifest['original_test_bytes_preserved_by_exact_additive_inverse'] = True
manifest['fixture_exact_inverse_span_count'] = len(spans)
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
