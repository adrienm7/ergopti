local packet=assert(arg[1])
local root=packet..'/candidate/static/ergopti_plus'
package.path=root..'/linux/?.lua;'..root..'/linux/?/init.lua;'..root..'/_shared/lua/?.lua;'..root..'/_shared/lua/?/init.lua;'..package.path
require('compat.utf8').install();local Loop=require('luv')
local count=0
require('tests.support.input_owner_fixture').with_manager_session({public_chords=true,before_manager=function(s)
 s.bytes='[mod_combos.config.tab_then_caps_lock]\ncombo="copy"\n'
end},function(s)
 local Source=require('modules.shortcuts.key_combinations')
 for _,value in ipairs({true,{},setmetatable({chords={tab_then_caps_lock='copy'}},{__index=function()return true end})}) do
  assert(Source.buffered_settings_current(value)==false,'unissued caller bool/table/meta has no input registry authority');count=count+1
 end
 local caller=Source.new(setmetatable({keys={{id='tab',key='tab'},{id='caps_lock',key='caps_lock'}},
  hold_picker={modifiers={'ctrl'},layers={}},is_paused=function()return false end,
  changed=function()return true end,actions={is_assignable=function()return true end}}, {__index=function()return true end}))
 assert(caller.get_chord('tab_then_caps_lock')=='copy')
 local options=caller.engine_options({tab=300,caps_lock=300})
 assert(Source.buffered_settings_current(options)==false,'detached meta constructor cannot become Manager issuance');count=count+1
 assert(s.hook.set_remapper(nil));assert(s.broker.output_current());assert(next(s.broker.view().owners)==nil)
end)
assert(require('luv')==Loop);print('INDEPENDENT_CALLER_DATA_REFUSALS '..count..'/0 CLEANUP=true')
