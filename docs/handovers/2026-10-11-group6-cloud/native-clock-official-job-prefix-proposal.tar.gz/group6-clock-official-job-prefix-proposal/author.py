from pathlib import Path
import difflib
P=Path(__file__).resolve().parent
p='tools/ci/native_http_clock_evidence.cjs';s=(P/'preimages'/p).read_text();needle='job.name === `Managed Ollama native · ${epoch.architecture}`'
replacement='''((epoch.architecture === 'arm64' && job.name === 'macOS / Managed Ollama native · arm64') ||
				(epoch.architecture === 'amd64' && job.name === 'macOS / Managed Ollama native · amd64'))'''
assert s.count(needle)==1;(P/'candidate'/p).write_text(s.replace(needle,replacement,1))
p='tools/test/test-native-http-clock-evidence.cjs';s=(P/'preimages'/p).read_text();needle="name: 'Managed Ollama native · arm64'";assert s.count(needle)==1;s=s.replace(needle,"name: 'macOS / Managed Ollama native · arm64'",1)
marker="\t});\n\tcontrol('actual fresh Git HEAD clean closure receives fixed nineteen inputs'"
assert s.count(marker)==1
add='''
		// Literal parent-prefixed names come from actual ci.yml/API receiving,
		// independent of the comparison implementation. Caller JSON stays modeled.
		const amdVerdict = { ...verdict, source: { ...verdict.source, architecture: 'amd64' } };
		const amdArtifact = { ...artifact, name: 'native-http-clock-amd64-123-2' };
		const amdJob = { ...job, name: 'macOS / Managed Ollama native · amd64' };
		const amdResult = evidence.officialConsistency(amdVerdict, run, amdArtifact, amdJob, archive, receiving);
		assert.equal(amdResult.authentication, 'NOT_ESTABLISHED_BY_CALLER_SUPPLIED_JSON');
		assert.equal(amdResult.swift_factory_activation, 'HELD');
		for (const name of [
			'Managed Ollama native · arm64',
			'Managed Ollama native · amd64',
			'Windows / Managed Ollama native · arm64',
			'macOS / macOS / Managed Ollama native · arm64',
			'macOS/Managed Ollama native · arm64',
			'macOS / Managed Ollama native · amd64',
			'macOS / Managed Ollama native · arm64 extra',
			null,
			true,
			123,
			['macOS / Managed Ollama native · arm64'],
			{ name: 'macOS / Managed Ollama native · arm64' }
		]) assert.throws(() => evidence.officialConsistency(verdict, run, artifact, { ...job, name }, archive, receiving), /Official job consistency refused/);
		assert.throws(() => evidence.officialConsistency(amdVerdict, run, amdArtifact, job, archive, receiving), /Official job consistency refused/);
		assert.throws(() => evidence.officialConsistency(verdict, run, artifact, [job, job], archive, receiving), /Official job consistency refused/);
		assert.throws(() => evidence.officialConsistency(verdict, run, artifact, {}, archive, receiving), /Official job consistency refused/);
		assert.throws(() => evidence.officialConsistency(verdict, run, artifact, job, archive, {}), /Attempt-scoped job receiving path refused/);
		assert.throws(() => evidence.officialConsistency(verdict, run, artifact, job, archive, { job_api_path: '/repos/adrienm7/ergopti/actions/runs/123/jobs' }), /Attempt-scoped job receiving path refused/);
'''
s=s.replace(marker,add+marker,1);(P/'candidate'/p).write_text(s)
for p in ['tools/ci/native_http_clock_evidence.cjs','tools/test/test-native-http-clock-evidence.cjs']:
 a=(P/'preimages'/p).read_text();b=(P/'candidate'/p).read_text()
 for suffix,x,y in [('patch',a,b),('inverse.patch',b,a)]:
  with (P/('candidate.'+suffix)).open('a') as stream:stream.write(''.join(difflib.unified_diff(x.splitlines(True),y.splitlines(True),fromfile='a/'+p,tofile='b/'+p)))
