﻿; Native mechanism prototype only, not a production regression qualification.
_R7PI_HandlePublicationCapability() {
 Root := A_Temp . "\ergopti_r7_handle_publication_" . PLC_CurrentProcessId() . "_" . A_TickCount
 Stage := Root . "\owned.tmp", Destination := Root . "\config.toml", Other := Root . "\foreign-move.tmp"
 Handle := -1
 try {
  _RIT_WriteFile(Destination, "old configuration`n")
  Handle := DllCall("kernel32\CreateFileW", "Str", Stage, "UInt", 0xC0010000, "UInt", 0,
   "Ptr", 0, "UInt", 1, "UInt", 0x80, "Ptr", 0, "Ptr")
  AssertTrue(Handle != -1, "actual CREATE_NEW must acquire an exclusive READ/WRITE/DELETE stage")
  Bytes := Buffer(StrPut("owned configuration`n", "UTF-8"))
  StrPut("owned configuration`n", Bytes, "UTF-8")
  Written := 0
  AssertTrue(DllCall("kernel32\WriteFile", "Ptr", Handle, "Ptr", Bytes, "UInt", Bytes.Size - 1, "UInt*", &Written, "Ptr", 0, "Int"))
  AssertEqual(Bytes.Size - 1, Written)
  AssertTrue(DllCall("kernel32\FlushFileBuffers", "Ptr", Handle, "Int"))
  Moved := false
  try FileMove(Stage, Other, false)
  catch
   Moved := true
  AssertTrue(Moved, "a real competing pathname move must be denied by native sharing")
  AssertFalse(DllCall("kernel32\DeleteFileW", "Str", Stage, "Int"), "a real competing pathname delete must be denied")
  NameBytes := StrLen(Destination) * 2
  NameOffset := A_PtrSize == 8 ? 20 : 12
  Rename := Buffer(NameOffset + NameBytes + 2, 0)
  NumPut("UInt", 1, Rename, 0)
  NumPut("UInt", NameBytes, Rename, A_PtrSize == 8 ? 16 : 8)
  StrPut(Destination, Rename.Ptr + NameOffset, StrLen(Destination) + 1, "UTF-16")
  Published := DllCall("kernel32\SetFileInformationByHandle", "Ptr", Handle, "Int", 3,
   "Ptr", Rename, "UInt", Rename.Size, "Int")
  NativeError := A_LastError
  AssertTrue(Published, "actual same-handle FileRenameInfo must publish the owned object; error=" . NativeError)
  AssertFalse(FileExist(Stage), "successful handle rename must retire only its old name")
  AssertTrue(DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int"))
  Handle := -1
  AssertEqual("owned configuration`n", FSReadUtf8Exact(Destination))
 } finally {
  if Handle != -1
   DllCall("kernel32\CloseHandle", "Ptr", Handle, "Int")
  if DirExist(Root)
   DirDelete(Root, true)
 }
}
Test("Config restore design: actual exclusive handle prevents replacement and publishes itself (restore-handle-capability)", _R7PI_HandlePublicationCapability)
