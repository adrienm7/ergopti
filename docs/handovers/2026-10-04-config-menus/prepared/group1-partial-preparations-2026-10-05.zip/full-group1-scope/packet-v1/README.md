# Retained synchronous scope cohort

Frozen parent: `88909124461a3dbdfe5b745453fe50333eb64adc`. Patch SHA256: `148132f9761a6710b2cf8e16ee06830f5cb54f953d1581ee18c030b08493d29d`.

The synchronous participant previously resolved the provider's latest owner for every inverse, retry and release. A separately admitted scope could replace that owner between global categories. Global rollback then restored the successor and left its own committed source/runtime unchanged, or reported restoration while the actual failed request still retained debt.

The participant now captures and retains the exact owner observed at its synchronous apply terminal. Inverse, release and compensation address that cohort. Pre-apply admission still checks the latest provider for unsettled debt; reentrant requests and replacement of a committed inverse are refused. A failed/raising apply captures its compensation owner. A reported success with a missing, malformed or raising owner lookup refuses and retains an explicit unresolved ownership state rather than guessing a successor. An ordinary refusal without mutation or an owner remains retryable.

The shared continuation/owner interfaces and void release contract remain unchanged. This correction does not make a final composition release transactional or prevent a provider from replacing its owner internally before the synchronous apply returns. Owners still must expose their actual terminal journal. Missing ownership has no guessed recovery capability; it remains pending for lifecycle diagnosis. Composition exception/release handling, native fence release journals and other scope publication debt remain separate work.

## Evidence

All eleven preexisting contract cases/assertions are byte-exact in their original ordered prefix; additions precede only the original final module closing line. No corpus or generated file changed. Handwritten complete source models include unknown neighbors. Four real-file actual transaction cases verify distinct-source rollback, same-path external successor preservation and exact-source retry, exact inverse release and failed runtime compensation. Remaining controls cover reentrant actual application, a throwing terminal retaining native compensation, missing/malformed/raising owner lookup, provider admission and harmless ownerless refusal. Temporary files/backups are tracked and cleaned at their exact owned paths. Fixture conditional IO proves observed source fencing, not an atomic kernel CAS or advisory lease contract.

| Focused registered selection | Exact predecessor with final tests | Candidate |
| --- | --- | --- |
| Linux shared composition, LuaJIT | 12 passed / 10 failed | 22 passed / 0 failed |
| Linux shared composition, Lua5.4 | 12 passed / 10 failed | 22 passed / 0 failed |
| macOS shared composition, portable Lua5.4 | not repeated | 22 passed / 0 failed |
| Existing Linux global scope, LuaJIT | unchanged | 11 passed / 0 failed |
| Existing Linux real-file TapHold scope, LuaJIT | unchanged | 48 passed / 0 failed |
| Existing macOS global scope, portable Lua5.4 | unchanged | 4 passed / 0 failed |

The predecessor replay preloads only its exact original participant source; candidate tests, transaction owner, physical file IO and all other dependencies remain identical. All new failure cases use preexisting participant/transaction APIs. Lua5.4 parse and LF pass; a sparse application reconstructs both exact postimages. `patch-manifest.json` binds all source identities. `verify-change-plan.json` exports selected gates without running them. One initial parse attempt lacked activated luac; the final activated syntax check passed. Intermediate diagnostic logs are retained separately from final results.

Focused replay from `candidate/static/ergopti_plus/linux`:

    luajit <packet>/focused.lua tests.unit.infra.test_config_scope_composition
    lua5.4 <packet>/focused.lua tests.unit.infra.test_config_scope_composition
    luajit <packet>/old-owner.lua <packet>

The exact old-source command intentionally exits1. From the corresponding macOS directory, the same module/runner works under Lua5.4.

Independent source review is pending. Full selected JS/native suites, hosted Windows/macOS/Linux execution, packaging, installation, actual GUI/runtime and physical keyboard acceptance have not been executed for this patch. TODO5 and transverse16/38 remain partial. No root checkout/index/refs/CI or TODO was modified. Root owns final preimage composition, relevant TODO note, gates and integration.
