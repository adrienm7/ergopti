// Independent scoped lease XCTest evidence; never full-package qualification.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { cleanTranscript } = require('./swift_xctest_evidence.cjs');
// Independently frozen c80 identities, including the 17 retained filesystem cases.
const METHODS = Object.freeze([
	'testGuardianRefusesActivationBeforeArmed',
	'testGuardianProcessRemainsAliveAfterStartup',
	'testGuardianDrainsReplacedRecordsDirectoryBeforeRestart',
	'testGuardianPresenceProbesDoNotImpersonateGuardian',
	'testGuardianStartupWaitsOutSharedPresenceProbe',
	'testGuardianStartupRejectsExclusiveGuardianOwner',
	'testModernGuardianRegistrationNeverBypassesUserDenial',
	'testModernGuardianRegistrationRetriesNotFoundOnce',
	'testModernGuardianObservationNeverRegistersAndRequiresExactHealth',
	'testModernGuardianObservationRechecksAuthorizationAfterHealth',
	'testModernGuardianActivationAuthorizationFailsClosed',
	'testGuardianRegistrationRefusesUnapprovedActivationBeforePublication',
	'testGuardianRegistrationRefusesApprovalLostDuringArmHandshake',
	'testGuardianRegistrationRevokesAuthorizationFromLiveTransport',
	'testModernGuardianSettingsOpenOnlyForCurrentApprovalRequirement',
	'testGuardianStatusInvocationRequiresExactLauncherIdentity',
	'testGuardianSettingsInvocationRequiresExactLauncherIdentity',
	'testLegacyRegistrationPreservesAlreadyRunningGuardian',
	'testLegacyRegistrationReplacesStaleExecutablePathBeforeReady',
	'testGuardianRegistrationPublishesLockedDurableRecordBeforeArmed',
	'testGuardianRegistrationCollisionPreservesExistingRecordAndAcknowledgement',
	'testGuardianAcknowledgementRollsBackAfterPostRenameDirectorySyncFailure',
	'testRegistrationCannotArmFromPostRenameDirectorySyncFailure',
	'testGuardianAcknowledgementDurabilityLockIsTokenLocal',
	'testGuardianRestartRecoversStaleAcknowledgementTemporary',
	'testGuardianRestartPrioritizesAcknowledgedRecordsBeyondUnarmedCap',
	'testGuardianFencesAbandonedRecord',
	'testGuardianFencesLiveOwnerAfterSIGKILL',
	'testGuardianFencesExternallyUnlinkedLiveRecord',
	'testGuardianRestartFencesOrphanedAcknowledgementAfterRecordLoss',
	'testGuardianSkipsExplicitlyRetiredRecord',
	'testGuardianFencesRetirementFromDifferentRecordNonce',
	'testGuardianTerminationFencesLockedActiveRecordBeforeExit',
	'testGuardianPermanentDrainErrorFencesUntilExactGateCanBeTaken',
	'testRegistrationStillRecognizesHealthyGuardianAfterActivationCompletes',
	'testReplacementGuardianWaitsForPriorGenerationTransportGate',
	'testRetainedGuardianCallbackRefusesReplacementUntilActualOwnerRelease',
	'testGuardianTerminationCannotFenceBeforeArmedActivationCompletes',
	'testGuardianTerminationWaitsForPostReadyLiveTransportAcknowledgement',
	'testGuardianCannotPublishDrainingBetweenRevalidationAndLiveAcknowledgement',
	'testGuardianLeavesPersonalKarabinerProcesses',
	'testWorkerIdentityUsesOneModeAndOneTombstone',
	'testLauncherExecutableFileIdentityMatchesLstat',
	'testLeaseExecutableIdentityParsesCanonicalEnvironment',
	'testInnerSpawnerRevalidatesExecutableBeforeEverySpawn',
	'testInnerSpawnerKillsRacingReplacementBeforeUserSpaceExecution',
	'testInnerInvocationRejectsAReplacedLauncherVnode',
	'testIdentityRejectsMismatchedNamesAndUnboundedHeartbeat',
	'testIdentityRejectsEverySharedKarabinerProcessFamily',
	'testLivePayloadNeverMentionsRevokedAndFenceRepeatsIdentically',
	'testAllLeaseRolesAreHandledBeforeApplicationBootstrap',
	'testHeadlessDispatchAndHelperExportAreOrderedBeforeSideEffects',
	'testReservedSocketEndpointsStayAboveEveryFileActionTarget',
	'testReservedSocketsStayAboveFD3WhenLowDescriptorsAreClosed',
	'testPreparedInnerControlDescriptorClosesAcrossCLIExec',
	'testChildReapingPreparationRestoresWaitpidOwnership',
	'testCLIFileActionInitializationPreservesReturnedError',
	'testCLICloseActionFailureRefusesSpawn',
	'testCLIRequiresCompletelyEmptyDiagnosticsForSuccess',
	'testCLILargeDiagnosticOutputCannotDeadlockBeforeExit',
	'testCLIDiagnosticDrainBoundsEachTurnUnderContinuousOutput',
	'testInnerSpawnerCloseActionFailureRefusesEverySpawnPosition',
	'testInnerProcessGroupOwnershipCannotRaceOrOutliveReap',
	'testBoundedLineDecoderRejectsOversizeAndMalformedUTF8',
	'testBoundedLineDecoderRejectsLineFlood',
	'testBoundaryPollRetriesInterruptedCallsWithinFixedZeroDelayBudget',
	'testPrivateHeartbeatProtocolRequiresCanonicalSequence',
	'testInnerSilenceDeadlineDrainsBoundaryCommandBeforeFencing',
	'testInnerSilenceDeadlineAcceptsHealthyHeartbeatCycles',
	'testEOFBeforeActivationFencesWithoutReady',
	'testEOFDuringActivationFencesWithoutFalseReady',
	'testEOFAfterReadyFencesTheGeneration',
	'testStoppedOuterWithPendingHammerspoonEOFTriggersInnerSilenceFence',
	'testPrivatePeerClosureOutranksBufferedSet',
	'testPrivateBoundaryEINTRStillLetsClosureOutrankBufferedSet',
	'testPublicTerminalBatchNeverForwardsBufferedPause',
	'testInnerHUPOutranksBufferedReadyAcknowledgement',
	'testOuterIdempotentModeAckCannotOutrankSameBatchInnerHUP',
	'testInnerBoundaryEINTRPreservesSingleBufferedFailureDiagnostic',
	'testParentEOFAfterPublicPingOutranksItsLatePong',
	'testPublicStopAfterPingOutranksItsLatePong',
	'testGuardianLossDoesNotOutrankStopSameParentBatch',
	'testPendingInnerAcknowledgementOutranksCommandDeadline',
	'testEOFDuringPauseFencesWithoutFalsePausedAck',
	'testEOFDuringHeartbeatFencesWithoutHeartbeatAck',
	'testEOFDuringFenceRetriesUntilTwoConsecutiveFinalWrites',
	'testStopDuringActivationPreemptsBeforeFence',
	'testRapidPauseResumeNeverOverlapsCLIChildren',
	'testChildTimeoutFencesAndNeverPublishesReady',
	'testFenceTransportBoundsPermanentSpawnFailuresAndReportsFirstFailureOnce',
	'testDetachedWorkerStopsAfterBoundedDirectFenceSpawnFailures',
	'testPrivateCommandDeadlinesExpireBeforePublicReadyBudget',
	'testInnerLossRequiresReplacementFenceBeforeFinish',
	'testOuterRevalidatesGuardianAfterLiveTransportBeforePublishingReady',
	'testOuterRetiresLiveWriterBeforeReleasingGuardianDrainGate',
	'testAuthenticatedOuterFencesDirectlyWhenReplacementSpawnerStaysUnavailable',
	'testInnerLossDuringStopJoinsReplacementFenceBeforeStoppedAck',
	'testOuterCoalescesRapidPauseResumeBehindOneInFlightWrite',
	'testOuterSerializesPublicPingAndQueuedModeByExactSequence',
	'testOuterPublishesSequencedPingFailureWithoutInventingAcknowledgement',
	'testOuterRejectsEveryNonExactPingSequence',
	'testLateOrphanModeWriteIsAbsorbedByMonotoneTombstone',
	'testOwnedGroupConfinementPreventsLateOrphanAfterCoreReset',
	'testSiblingProgressWitnessRejectsStoppedExistingProcess',
	'testCLIChildResetsInheritedHUPToDefault',
	'testKilledInnerGroupReapsOrphanAndPreservesSharedProcessSiblings',
	'testFencedThenStoppedInnerIsKilledAndReapedWithinBound',
	'testFencedThenExitedInnerRetiresDescendantsBeforeReap',
	'testOuterRuntimeDeadlineKillsStoppedInnerGroupBeforeReplacementFence',
	'testOuterNeverManufacturesHeartbeatDuringContinuouslyReadableParentInput',
	'testUnrelatedSiblingSurvivesEveryDirectChildPreemption',
	'testUnrelatedSiblingSurvivesInnerLossReplacementFence',
	'testTerminalDiagnosticOuterSilenceFollowsBothOriginalFenceTransports',
	'testTerminalDiagnosticPeerClosureRemainsDistinctAndFollowsFence',
	'testTerminalDiagnosticTypedCLIFailurePreservesActivationResultAfterFence',
	'testTerminalDiagnosticExhaustedFenceDoesNotClaimRecovery',
	'testTerminalDiagnosticAcceptedStopRemainsQuiet',
	'testTerminalDiagnosticOuterFormattingOmitsHeartbeatSequenceAndRawFailure',
	'testTerminalDiagnosticInnerFormattingMatchesIndependentFrozenGrammar',
	'testTerminalDiagnosticNativeDeadlineRetainsFirstSnapshotAfterGuardianRetirement',
	'testTerminalDiagnosticNativePrivateEOFWaitsForBothFencesAndRetirement',
	'testTerminalDiagnosticNativeGuardianLossIsDistinctBeforeBothFences',
	'testTerminalDiagnosticNativeAcceptedStopOrEOFRemainsQuiet',
	'testTerminalDiagnosticNativeDeadlineWaitsForBothFencesAndRetirement',
	'testTerminalDiagnosticNativeUnexpectedAckSnapshotsBeforeStateMutation',
	'testTerminalDiagnosticNativeFailed73SnapshotsBeforeTerminalMutation',
	'testTerminalExportPositiveIndependentLiteralAndTypedSnapshotRoundTrip',
	'testTerminalExportRejectsIndependentPIIUnknownTypeMissingAndSizeVectors',
	'testTerminalExportRejectsIndependentEncodingEmptyAndSuffixVectors',
	'testRetainedDiagnosticMissingDirectoryDoesNotCreate',
	'testRetainedDiagnosticPrivateRecordsAndAtomicReplacement',
	'testRetainedDiagnosticUnknownPIIFieldsNeverExport',
	'testRetainedDiagnosticWrongRoleFilenameRefused',
	'testRetainedDiagnosticPublicRecordRefusedWithoutChmod',
	'testRetainedDiagnosticSymlinkRecordRefusedWithoutTargetMutation',
	'testRetainedDiagnosticHardlinkRecordRefusedWithoutMutation',
	'testRetainedDiagnosticFIFORefusedBeforeContentRead',
	'testRetainedDiagnosticOversizeRefusedBeforeContentRead',
	'testRetainedDiagnosticFileReplacementAfterCapturedReadRefused',
	'testRetainedDiagnosticDirectoryReplacementAfterCapturedReadRefused',
	'testRetainedDiagnosticLateAncestorAliasRefused',
	'testRetainedDiagnosticInitialDirectoryAliasRefused',
	'testRetainedDiagnosticWriterRefusesUnownedShapeWithoutMutation',
	'testRetainedDiagnosticDispatcherRejectsPathOverrideBeforeBootstrap',
	'testRetainedDiagnosticEnvelopeClosedMetadataAndBound',
	'testRetainedDiagnosticTrueParentAliasPreservingLeafInodesRefused'
]);
const NAMES = Object.freeze(
	METHODS.map((method) => `-[ErgoptiPlusTests.KarabinerLeaseWorkerTests ${method}]`)
);
function status(value) {
	if (!/^(?:0|[1-9][0-9]{0,2})$/.test(String(value)) || Number(value) > 255)
		throw new Error('pipeline');
	return Number(value);
}
function evaluate(text, swiftStatus, teeStatus) {
	const errors = [];
	const reject = (label) => {
		if (!errors.includes(label)) errors.push(label);
	};
	let swift = null,
		tee = null;
	try {
		swift = status(swiftStatus);
		tee = status(teeStatus);
	} catch {
		reject('pipeline');
	}
	let root = 'before',
		suite = 'before',
		active = null,
		summary = null;
	const starts = new Set(),
		terminals = new Set();
	for (const line of cleanTranscript(text).split('\n')) {
		if (!line.trim()) continue;
		if (summary !== null) {
			const count =
				/^\s*Executed (0|[1-9][0-9]*) tests?, with (\d+) failures? \((\d+) unexpected\) in /.exec(
					line
				);
			if (!count || count[1] !== '146' || count[2] !== '0' || count[3] !== '0') reject('summary');
			if (summary === 'root') root = 'after';
			else suite = 'after';
			summary = null;
			continue;
		}
		const opening = /^Test Suite '([^']+)' started at /.exec(line);
		const closing = /^Test Suite '([^']+)' (passed|failed) at /.exec(line);
		const starting = /^Test Case '([^']+)' started\.$/.exec(line);
		const terminal =
			/^Test Case '([^']+)' (passed|failed|skipped) \(\d+(?:\.\d+)? seconds?\)\.$/.exec(line);
		if (opening) {
			if (opening[1] === 'Selected tests') {
				if (root !== 'before' || suite !== 'before' || active !== null) reject('root');
				root = 'running';
			} else if (opening[1] === 'KarabinerLeaseWorkerTests') {
				if (root !== 'running' || suite !== 'before' || active !== null) reject('suite');
				suite = 'running';
			} else reject('foreign-suite');
		} else if (closing) {
			if (closing[2] !== 'passed') reject('failed-suite');
			if (closing[1] === 'Selected tests') {
				if (root !== 'running' || suite !== 'after' || active !== null) reject('root');
				root = 'summary';
				summary = 'root';
			} else if (closing[1] === 'KarabinerLeaseWorkerTests') {
				if (root !== 'running' || suite !== 'running' || active !== null) reject('suite');
				suite = 'summary';
				summary = 'suite';
			} else reject('foreign-suite');
		} else if (starting) {
			if (
				root !== 'running' ||
				suite !== 'running' ||
				active !== null ||
				!NAMES.includes(starting[1]) ||
				starts.has(starting[1])
			)
				reject('start');
			starts.add(starting[1]);
			active = starting[1];
		} else if (terminal) {
			if (
				root !== 'running' ||
				suite !== 'running' ||
				active !== terminal[1] ||
				terminals.has(terminal[1]) ||
				!NAMES.includes(terminal[1])
			)
				reject('terminal');
			if (terminal[2] !== 'passed') reject('failed-or-skipped-case');
			terminals.add(terminal[1]);
			active = null;
		} else if (/^\s*Test (Suite|Case) |^\s*Executed |(?:^|: )(?:fatal )?error: /.test(line))
			reject('unadmitted-test-frame');
	}
	if (
		root !== 'after' ||
		suite !== 'after' ||
		summary !== null ||
		active !== null ||
		starts.size !== 146 ||
		terminals.size !== 146 ||
		NAMES.some((name) => !starts.has(name) || !terminals.has(name))
	)
		reject('incomplete');
	if (swift !== 0 || tee !== 0) reject('pipeline');
	return {
		schema: 1,
		scope: 'lease-native-only',
		complete: errors.length === 0,
		full_package_qualified: false,
		completed: [...terminals].filter((name) => NAMES.includes(name)).length,
		swift_status: swift,
		capture_status: tee,
		errors
	};
}
function readBoundedRegular(file) {
	const descriptor = fs.openSync(
		file,
		fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK
	);
	try {
		const before = fs.fstatSync(descriptor),
			named = fs.lstatSync(file);
		if (
			!before.isFile() ||
			before.size > 16777216 ||
			before.dev !== named.dev ||
			before.ino !== named.ino
		)
			throw new Error('capture');
		const bytes = Buffer.alloc(before.size);
		let offset = 0;
		while (offset < bytes.length) {
			const count = fs.readSync(descriptor, bytes, offset, bytes.length - offset, null);
			if (count <= 0) throw new Error('capture');
			offset += count;
		}
		const after = fs.fstatSync(descriptor),
			finalName = fs.lstatSync(file);
		if (
			bytes.length !== before.size ||
			after.size !== before.size ||
			after.mtimeMs !== before.mtimeMs ||
			after.ctimeMs !== before.ctimeMs ||
			after.dev !== finalName.dev ||
			after.ino !== finalName.ino
		)
			throw new Error('capture');
		return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
	} finally {
		fs.closeSync(descriptor);
	}
}
function main(args, repository = path.resolve(__dirname, '../..')) {
	try {
		if (args.length !== 4) throw new Error('arguments');
		const source = fs.readFileSync(
			path.join(
				repository,
				'static/ergopti_plus/macos/launcher/Tests/ErgoptiPlusTests/RemapLeaseWorkerTests.swift'
			),
			'utf8'
		);
		const actual = [...source.matchAll(/\bfunc (test\w+)\(/g)].map((match) => match[1]);
		if (JSON.stringify([...actual].sort()) !== JSON.stringify([...METHODS].sort()))
			throw new Error('source');
		const receipt = evaluate(readBoundedRegular(args[0]), args[1], args[2]);
		fs.writeFileSync(args[3], JSON.stringify(receipt, null, '\t') + '\n', {
			flag: 'wx',
			mode: 0o600
		});
		console.log(
			`::notice title=Scoped native lease XCTest evidence::complete=${receipt.complete} completed=${receipt.completed} full_package_qualified=false`
		);
		return receipt.complete ? 0 : 1;
	} catch {
		console.error(
			'::error::Scoped native lease XCTest evidence refused; full package remains unqualified.'
		);
		return 1;
	}
}
module.exports = { METHODS, NAMES, evaluate, main };
if (require.main === module) process.exitCode = main(process.argv.slice(2));
