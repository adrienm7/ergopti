"""Build a finite source-only recovery archive from exact pinned allowlists."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import json
import stat
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(root, relative):
    rel = PurePosixPath(relative)
    if rel.is_absolute() or not rel.parts or any(x in ('', '.', '..') for x in rel.parts):
        raise ValueError('Relative source path refused')
    if not root.is_absolute() or not stat.S_ISDIR(root.lstat().st_mode):
        raise ValueError('Literal source root refused')
    current = root
    for index, part in enumerate(rel.parts):
        current = current / part
        actual = current.lstat()
        expected = stat.S_ISREG if index == len(rel.parts)-1 else stat.S_ISDIR
        if not expected(actual.st_mode):
            raise ValueError('Source component kind refused')
    return current.read_bytes()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--fixtures', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    owner = Path(__file__).absolute().parent
    inputs_raw = read_regular(owner, 'INPUTS.json')
    inputs = json.loads(inputs_raw)
    roots = {'prepared': args.prepared, 'fixtures': args.fixtures, 'review': args.review}
    files = {}

    def add(name, data):
        rel = PurePosixPath(name)
        if rel.is_absolute() or any(x in ('', '.', '..') for x in rel.parts):
            raise ValueError('Payload path refused')
        if '.private' in name or name.endswith(('.log', '.tar', '.gz')):
            raise ValueError('Capture or dependency archive inclusion refused')
        if name in files and files[name] != data:
            raise ValueError('Conflicting payload path refused')
        files[name] = data

    for group in inputs['groups']:
        root = roots[group['source']] / group['relative_root']
        raw = read_regular(root, 'SOURCE-INVENTORY.json')
        if digest(raw) != group['inventory_sha256']:
            raise ValueError('Original inventory binding refused')
        inventory = json.loads(raw)
        add('groups/' + group['name'] + '/SOURCE-INVENTORY.json', raw)
        records = inventory.get('artifacts', inventory.get('files'))
        if not isinstance(records, list):
            raise ValueError('Original inventory schema refused')
        for record in records:
            data = read_regular(root, record['path'])
            if digest(data) != record['sha256'] or ('bytes' in record and len(data) != record['bytes']):
                raise ValueError('Original source binding refused')
            add('groups/' + group['name'] + '/' + record['path'], data)
    for record in inputs['extra_files']:
        data = read_regular(roots[record['source']], record['path'])
        if digest(data) != record['sha256']:
            raise ValueError('Qualification/review binding refused')
        add(record['destination'], data)
    add('INPUTS.json', inputs_raw)
    for name in ('GENERATE.py', 'README.md', 'REVIEWS.json', 'COMMANDS.md'):
        add(name, read_regular(owner, name))

    if args.output.exists() or args.output.is_symlink():
        raise ValueError('Existing output refused')
    args.output.mkdir(mode=0o700)
    payload = args.output / 'payload'
    payload.mkdir(mode=0o700)
    for name, data in sorted(files.items()):
        target = payload / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    manifest = {'status': 'SOURCE_RECOVERY_NOT_FEATURE_INTEGRATION',
        'includes_private_logs': False, 'includes_stage_trees': False,
        'files': [{'path': name, 'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(files.items())]}
    manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
    (payload / 'PAYLOAD-MANIFEST.json').write_bytes(manifest_raw)
    files['PAYLOAD-MANIFEST.json'] = manifest_raw
    archive = args.output / 'group6-network-recovery-2026-10-06.tar.gz'
    with archive.open('xb') as native:
        with gzip.GzipFile(fileobj=native, filename='', mode='wb', mtime=0) as packed:
            with tarfile.open(fileobj=packed, mode='w', format=tarfile.PAX_FORMAT) as stream:
                import io
                for name, data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.uid = info.gid = 0
                    info.mtime = 0
                    stream.addfile(info, io.BytesIO(data))
    result = {'archive_sha256': digest(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
        'payload_manifest_sha256': digest(manifest_raw), 'payload_files': len(files),
        'payload_bytes': sum(len(x) for x in files.values()), 'source_only': True,
        'native_or_model_execution_by_generator': False}
    (args.output / 'ARCHIVE.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
