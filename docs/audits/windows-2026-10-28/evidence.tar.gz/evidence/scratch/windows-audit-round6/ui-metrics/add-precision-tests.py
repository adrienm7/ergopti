from pathlib import Path
import json
b=Path('/workspace/ergopti-windows-r6-ui-metrics');w=b/'static/ergopti_plus/windows/tests'
cases=[]
for i,(tab,table) in enumerate(zip(['bg','tg','qg','pg','hx','hp'],['bigrams','trigrams','quadgrams','pentagrams','hexagrams','heptagrams'])):
 prefix='abcde'[:i];last=chr(ord('a')+i)
 cases.append(dict(id='backspace-'+tab,tab=tab,table='ngram_'+table,token=prefix+'[BS]'+last,events=list(prefix)+['[BS]',last,'[BS]'],c=1,e=1,accuracy=100))
for id,tab,table,token,events in [('literal-bracket','pg','pentagrams','[bs]a',['[','b','s',']','a','[BS]']),('ordinary-bigram','bg','bigrams','ab',['a','b','[BS]']),('ordinary-char','c','chars','a',['a','[BS]'])]:
 cases.append(dict(id=id,tab=tab,table='ngram_'+table,token=token,events=events,c=1,e=1,accuracy=0))
(w/'fixtures/metrics_accuracy_projection.json').write_text(json.dumps({'app':'precision-probe.exe','timestamp':'2026-10-26 12:00:00.000','delay_ms':100,'cases':cases},indent=2)+'\n')
p=b/'tools/test/test-metrics-filter-cache.cjs';s=p.read_text();a='console.log(`${passed} passed, 0 failed.`);';assert s.count(a)==1
s=s.replace(a,'''const nativeAccuracyProjection = JSON.parse(
	fs.readFileSync(path.resolve(root, '../../windows/tests/fixtures/metrics_accuracy_projection.json'), 'utf8')
);
assert.equal(nativeAccuracyProjection.cases.length, 9);
for (const host of ['windows', 'macos', 'linux']) {
	for (const source of ['historical', 'today']) {
		for (const sensitive of [false, true]) {
			for (const vector of nativeAccuracyProjection.cases) {
				test(`${host} ${source} original token precision ${vector.id}, case-sensitive ${sensitive}`, () => {
					const page = loadMetricsTypingPage(host);
					freezePageClock(page, source === 'historical' ? '2026-10-27T12:00:00' : '2026-10-26T12:00:00');
					const app = nativeAccuracyProjection.app;
					const manifest = { '2026-10-26': { [app]: { chars: vector.events.length, time: 1000 } } };
					publishTypingPage(page, host, manifest);
					if (sensitive) page.elements.get('btn_case_sensitive').classList.add('active');
					else page.elements.get('btn_case_sensitive').classList.remove('active');
					const raw = { [vector.tab]: { [vector.token]: { c: vector.c, e: vector.e, t: 100 } } };
					deliverTypingManifest(page, host, manifest, { range: source === 'historical' ? {historical: raw, today: {}} : {historical: {}, today: {[app]: raw}} });
					vm.runInContext(`app_state.current_tab = ${JSON.stringify(vector.tab)}`, page.context);
					page.context.render_current_tab();
					page.timers.at(-1)();
					// Flat bracket strings have an independent, reported token-boundary ambiguity.
					// Pin their projection policy without claiming the current tokenizer can render them.
					if (vector.id !== 'literal-bracket') {
						const rows = vm.runInContext('app_state.rendered_list', page.context);
						assert.equal(rows.length, 1);
						assert.equal(rows[0].acc, vector.accuracy, 'case folding retains the original native correction policy');
						assert.equal(rows[0].count, vector.c);
					}
					const key = sensitive ? vector.token : vector.token.toLowerCase();
					const item = vm.runInContext(`app_state.data[${JSON.stringify(vector.tab)}][${JSON.stringify(key)}]`, page.context);
					assert.equal(item.errors, vector.e, 'raw error counters remain available to correction metrics');
					assert.equal(item.accuracy_errors, vector.accuracy === 100 ? 0 : vector.e, 'only the original native uppercase control marker receives the existing exemption');
					assert.equal(page.diagnostics.some(entry => entry.level === 'error'), false);
				});
			}
		}
	}
}
assert.equal(passed, 1022, 'all original-marker and ordinary-error precision controls must execute');

'''+a);p.write_text(s)
