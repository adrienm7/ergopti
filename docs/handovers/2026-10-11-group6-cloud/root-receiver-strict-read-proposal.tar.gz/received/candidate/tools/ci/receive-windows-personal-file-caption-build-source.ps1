# tools/ci/receive-windows-personal-file-caption-build-source.ps1
# Source commitment before the original native builder, then bounded receiving.
[CmdletBinding()]
param([Parameter(Mandatory = $true)][ValidateSet('prebuild', 'receive')][string]$Stage)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$InputPath = Join-Path $PSScriptRoot 'windows-personal-file-caption-cohort-inputs.json'
# Loader admission must be sealed into the owning input/producer source image.
$LoaderInputs = Get-Content -LiteralPath $InputPath -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable
$LibraryPath = Join-Path $PSScriptRoot 'lib/native-pac-build-source.psm1'
$LibraryItem = Get-Item -LiteralPath $LibraryPath
if ($LibraryItem.PSIsContainer -or ($LibraryItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
    (Get-FileHash -LiteralPath $LibraryPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $LoaderInputs.build_provenance.receiver_library_sha256) {
    throw 'Reviewed build receiver library changed.'
}
Import-Module $LibraryPath -Force -ErrorAction Stop
# Frozen Root census, not a count derived from the supplied object.
Invoke-NativePacBuildSourceReceipt -Stage $Stage -Root $Root -InputPath $InputPath -SourceCount 3262
