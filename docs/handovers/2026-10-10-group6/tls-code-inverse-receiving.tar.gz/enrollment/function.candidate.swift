func managedHTTPFailure(_ error: NSError) -> String {
	guard error.domain == NSURLErrorDomain else { return "unavailable" }
	let code = error.code
	switch code {
	case NSURLErrorTimedOut: return "deadline"
	case NSURLErrorCancelled: return "cancelled"
	case NSURLErrorNotConnectedToInternet, NSURLErrorNetworkConnectionLost: return "offline"
	case NSURLErrorCannotFindHost, NSURLErrorDNSLookupFailed: return "offline"
	case NSURLErrorServerCertificateUntrusted, NSURLErrorServerCertificateHasBadDate,
		NSURLErrorServerCertificateHasUnknownRoot, NSURLErrorServerCertificateNotYetValid,
		NSURLErrorSecureConnectionFailed, NSURLErrorClientCertificateRejected,
		NSURLErrorClientCertificateRequired:
		#if DEBUG
		_ = fputs("# native_http_certificate_code domain=NSURLErrorDomain code=\(code)\n", stderr)
		#endif
		return "certificate"
	case NSURLErrorUserAuthenticationRequired: return "unavailable"
	case NSURLErrorCannotConnectToHost: return "connect"
	default: return "unavailable"
	}
}
