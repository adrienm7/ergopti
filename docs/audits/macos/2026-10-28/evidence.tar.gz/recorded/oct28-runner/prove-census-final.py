from pathlib import Path
import os,subprocess,json
w=Path('/workspace/ergopti-macos-native-validation');d=Path('/workspace/scratch/oct28-runner/census-proof-final');d.mkdir()
e=dict(os.environ);e['PATH']='/workspace/toolchain/luajit-native/install/bin:/workspace/toolchain/node-v22.22.2-linux-x64/bin:/workspace/toolchain/bin:'+e['PATH'];e['LD_LIBRARY_PATH']='/workspace/toolchain/luajit-native/install/lib:/workspace/toolchain/sqlite-native-audit3/usr/lib/x86_64-linux-gnu'
facts=subprocess.check_output(['lua','-e','local n=require("luv");io.write(n.exepath(),string.char(0),n.fs_realpath(assert(package.searchpath("luv",package.cpath))),string.char(0),package.path)'],cwd=w,env=e).decode().split(chr(0));exe,library,lua_path=facts
native=d/'native';native.mkdir(exist_ok=True);link=native/'luv.so'
if not link.exists():link.symlink_to(library)
for key in ['LUA_CPATH','LUA_CPATH_5_4']:e[key]=str(native/'?.so')
for key in ['LUA_PATH','LUA_PATH_5_4']:e[key]=lua_path
subprocess.run([exe,'-e','assert(not pcall(require,"lfs"));assert(debug.getinfo(require("luv").fs_stat,"S").what=="C")'],env=e,check=True)
s=(w/'tools/test/test-bash-resolution.cjs').read_text();source=s.split('const censusSource = String.raw`',1)[1].split('`;',1)[0];(d/'actual-probe.lua').write_text(source)
old=d/'old-contract.lua';old.write_bytes(subprocess.check_output(['git','show','HEAD:static/ergopti_plus/_shared/lua/test/hotpath_segments_contract.lua'],cwd=w));results=[]
for name,contract in [('old',old),('fixed',w/'static/ergopti_plus/_shared/lua/test/hotpath_segments_contract.lua')]:
 root=d/(name+'-fixture');root.mkdir(exist_ok=True)
 r=subprocess.run([exe,'-',str(contract),str(root),str(w/'static/ergopti_plus/_shared/modules/timings/constants.toml'),str(w/'static/ergopti_plus/_shared/lua')],cwd=w,env=e,input=source,text=True,capture_output=True)
 (d/(name+'.stdout')).write_text(r.stdout);(d/(name+'.stderr')).write_text(r.stderr)
 actual_names=[p.name for p in root.iterdir()];assert any(chr(10) in n for n in actual_names)
 results.append({'name':name,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'real_newline_basenames':actual_names})
assert results[0]['exit']==0 and 'CENSUS_HIDDEN_ACCEPTED' in results[0]['stdout'];assert results[1]['exit']!=0 and 'source-census-newline-undeclared' in results[1]['stderr'];assert all('CENSUS_CONTROL_PASSED=8' in r['stdout'] for r in results)
(d/'receipt.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
