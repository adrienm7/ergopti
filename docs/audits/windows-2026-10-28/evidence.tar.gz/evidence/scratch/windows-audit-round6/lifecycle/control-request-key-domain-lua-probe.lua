local root="/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path=root.."lua/?.lua;"..package.path
local Json=require("json");local Policy=require("control.driver_control")
local function read(path) local f=assert(io.open(path,"rb"));local s=assert(f:read("*a"));assert(f:close());return s end
local spec=Policy.validate(Json.decode(read(root.."modules/control/driver_control.json")))
local corpus=Json.decode(read(root.."tests/corpus/control/driver_control.json"))
local rows={
 {"canonical","",true},
 {"canonical duplicate",[=["schema":1]=],true},
 {"escaped canonical duplicate",[=["sc\u0068ema":1]=],true},
 {"known unknown",[=["force":true]=],false},
 {"uppercase schema",[=["SCHEMA":99]=],false},
 {"mixed schema",[=["sChEmA":99]=],false},
 {"uppercase token",[=["TOKEN":"ignored"]=],false},
 {"mixed token",[=["ToKeN":"ignored"]=],false},
 {"uppercase request id",[=["REQUEST_ID":"ignored"]=],false},
 {"mixed request id",[=["Request_Id":"ignored"]=],false},
 {"escaped uppercase schema",[=["\u0053CHEMA":99]=],false},
 {"escaped uppercase token",[=["\u0054OKEN":"ignored"]=],false},
 {"escaped uppercase request id",[=["\u0052EQUEST_ID":"ignored"]=],false},
}
local passed,failed=0,0
for _,row in ipairs(rows) do
 local extra=row[2]=="" and "" or ","..row[2]
 local text='{"schema":1,"token":"'..corpus.token..'","request_id":"key-domain"'..extra..'}'
 local decoded=Json.decode(text);assert(decoded.schema==1 and decoded.token==corpus.token and decoded.request_id=="key-domain")
 local id,reason,echoed=Policy.parse_request(spec,text,corpus.token,Json.decode)
 local ok=(row[3] and id=="key-domain" and reason==nil and echoed==nil) or (not row[3] and id==nil and reason=="malformed" and echoed=="key-domain")
 print((ok and "PASS " or "FAIL ")..row[1]);if ok then passed=passed+1 else failed=failed+1 end
end
print(passed.." passed, "..failed.." failed");os.exit(failed==0 and 0 or 1)
