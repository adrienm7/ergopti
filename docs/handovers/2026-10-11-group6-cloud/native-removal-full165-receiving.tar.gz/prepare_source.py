from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=Path('/workspace/ergopti');OLD=Path('/workspace/ergopti-cloud/group6-native-removal-r2-controls-proposal');COMMIT='475b732253ef8ad425c8ef3b801976892b8438e3';TREE=P/'physical-source'
assert not TREE.exists(), 'Refusing existing source tree'
pins=json.loads((OLD/'runtime-source-inventory.json').read_text());files=list(pins)
MAC='static/ergopti_plus/macos/'
files += [MAC+'launcher/Sources/ErgoptiPlus/'+x for x in ('ManagedHTTPWorker.swift','ManagedPACSource.swift','ManagedCertificateAuthorities.swift','ManagedBootstrapPolicy.generated.swift')]
files += [MAC+'tests/support/native_http_fixture_main.swift',MAC+'launcher/Tests/ErgoptiPlusTests/ManagedHTTPWireTests.swift']
files += [MAC+'launcher/Sources/CPOSIXCompatibility/include/'+x for x in ('CPOSIXCompatibility.h','OwnedProgramCompatibility.h','LoopbackListenerCompatibility.h','OwnedImageAliasCompatibility.h','OwnedSuspendedImageCompatibility.h','OwnedListenerEventCompatibility.h')]
files += [MAC+'platform/network/native_http.py',MAC+'platform/network/managed_http.py','static/ergopti_plus/_shared/python/network_proxy_policy.py','static/ergopti_plus/_shared/modules/network/proxy_policy.json']
files=list(dict.fromkeys(files));own='tools/test/macos_native_http_receiving_facts_test.py';wire=MAC+'tests/support/native_http_wire_fixture.py';records=[]
for name in files:
 raw=subprocess.run(['git','show',COMMIT+':'+name],cwd=R,check=True,capture_output=True).stdout
 original=hashlib.sha256(raw).hexdigest()
 if name in pins:assert original==pins[name],name
 candidate=(OLD/'candidate'/name).read_bytes() if name in (own,wire) else raw
 path=TREE/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(candidate)
 live=(R/name).read_bytes();records.append({'path':name,'original_committed_source_sha256':original,'candidate_sha256':hashlib.sha256(candidate).hexdigest(),'candidate_bytes':len(candidate),'current_live_sha256':hashlib.sha256(live).hexdigest(),'live_equal_committed_base':live==raw,'candidate_override':name in (own,wire)})
base=(OLD/'preimages'/own).read_text();new=(TREE/own).read_text();marker='\nclass NativeTimedRemovalCaptureObservationTests(unittest.TestCase):';start=new.index(marker);end=new.index('\n\nif __name__ == "__main__":',start);assert new[:start]+new[end:]==base
new_body=new[start:end];methods=[line.strip().split('(',1)[0][4:] for line in new_body.splitlines() if line.startswith('    def test')];assert len(methods)==9
head=subprocess.run(['git','rev-parse','HEAD'],cwd=R,check=True,capture_output=True,text=True).stdout.strip()
(P/'source-inventory.json').write_text(json.dumps({'prepared_state':'FULL165_UNRUN','source_base_commit':COMMIT,'actual_live_head_observed':head,'finite_files':len(records),'physical_source':str(TREE),'original_whole_156_owning_file_restored_by_additive_class_inverse':True,'projected_old156_plus_new9':165,'new_test_identities':methods,'all_original_runtime13_pins_exact':True,'files':records},indent=2)+'\n')
(P/'private-tmp').mkdir(mode=0o700)
print(json.dumps({'prepared':str(TREE),'files':len(records),'live_equal_base':sum(x['live_equal_committed_base'] for x in records),'projected_census':165,'fullsuite_executed':False,'actual_head':head},indent=2))
