"""External proof only. No checkout, index, processes, tests or remote mutation."""
import argparse,datetime,hashlib,json,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/workspace/.ergopti-cloud'); OUT=ROOT/'diagnostic-opener-receiving'
TREE='5f3a0f0c5926593b8fe10802ca779d5e55222e51'; BASE='614970f3c2f8c2c1b6c27e27ff1c513dd6c933d7'
ARCHIVE=ROOT/'2026-10-15-DIAGNOSTIC-OPENER-RECEIVING.tar.gz'
def read(name):return json.loads((ROOT/name).read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def copy(name,relative):
 p=OUT/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
def emit(name,value):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def closed_gate(label):
 s=read('opener-selected-'+label+'-status.json')
 assert s['status'] in ['PASSED','FAILED'] and s['inputs_unchanged'] and s['before']==s['after']
 assert s['before']['index_tree']==TREE
 assert sha((ROOT/('opener-selected-'+label+'.log')).read_bytes())==s['log_sha256']
 return s

def prepare_closed():
 js=closed_gate('js');native=closed_gate('native');pair=read('opener-paired-gates-status.json')
 assert js['status']=='PASSED' and native['status']=='FAILED' and pair['state']=='FAILED'
 assert [(c['gate'],c['exit_code']) for c in native['commands'] if c['exit_code']]==[('linux',1)]
 for label in ['js','native']:
  for suffix in ['.log','-status.json','-controller.log']:
   name='opener-selected-'+label+suffix
   if (ROOT/name).exists():copy(name,'local/original/'+name)
 for name in ['opener-paired-gates-status.json','opener-paired-gates-controller.log','opener-native-clock-triage.json']:
  copy(name,'local/original/'+name)
 for name in ['config-opener-ci-terminal-receipt.json','config-opener-ci-terminal-run.json','config-opener-ci-terminal-jobs.json','config-opener-ci-terminal-artifacts.json']:
  copy(name,'ci/'+name)
 for p in ROOT.glob('config-opener-ci-failed-annotations-*.json'):copy(p.name,'ci/'+p.name)
 terminal=read('config-opener-ci-terminal-receipt.json')
 assert terminal['status']=='completed' and terminal['tree']==TREE and terminal['actual_sha']=='ff0fac6afe707cdb164f1cd37b7b856ed79a4384'
 assert terminal['outcomes']=={'success':30,'failure':5,'skipped':4} and terminal['total']==39
 assert len(terminal['linux_installed_scenarios'])==17 and all(s['conclusion']=='success' for s in terminal['linux_installed_scenarios'])
 emit('local/ORIGINAL-BOUNDARY.json',{'state':'FAILED','six_selected_gates_passed':True,'failed_gate':'linux','original_linux':{'passed':13848,'failed':1,'modules':521},'cause':'UNKNOWN','printed112ms':'Joint digest/writer completion, not timer-fire timestamp.','no_causal_fix_claim':True,'source_assertions_unchanged':True,'recheck':'PENDING; no active recheck log copied by prepare'})
 text='''# Diagnostic opener receiving\n\nDated source boundary:15October2026, published base614970f3c, exact candidate tree5f3a0f0c5926593b8fe10802ca779d5e55222e51. Final source SHA and unchanged Linux recheck remain pending until explicit parent seal authorization.\n\nThe original paired validation is FAILED and is preserved byte-for-byte. Six selected gates passed; Linux units reported13,848PASS/1FAIL across521modules. The failing original FIFO digest exceeded its100ms budget; cause UNKNOWN. Printed112.03ms joins digest and writer completion and is not a timer-fire timestamp. There is no causal fix or historical-debt/flakiness waiver. The original unchanged9-case fixture subsequently passed, and only Linux is rechecked in full; its active log is not copied here.\n\n|Selected gate|Original result|Source boundary|\n|---|---|---|\n|Format|PASS,430files|5f3a0f0c|\n|JS|426PASS,0FAIL|5f3a0f0c|\n|macOS Lua units with native ports stubbed|19,846PASS,0FAIL;1,604modules|5f3a0f0c|\n|macOS E2E stubbed|101PASS;1explicitSKIP|5f3a0f0c|\n|Linux Lua units|13,848PASS,1FAIL;521modules|5f3a0f0c;failure retained|\n|Linux E2E|193PASS,0FAIL|5f3a0f0c|\n|Linux managed HTTP native|18retained+30public actual controlsPASS,0SKIP|5f3a0f0c;authenticated SDK/tool admission|\n\nHosted manual CI38744427137 tested actual ff0fac6afe707cdb164f1cd37b7b856ed79a4384 with the exact same whole tree. It is FAILED:39jobs,30SUCCESS,5FAILURE,4SKIP. All17Linux installed scenarios succeeded. Failed jobs are both MacManagedOllama lanes, Macarchive qualification, Macverdict and selectedverdict. API job/step metadata was received; raw assertion logs/artifact contents were not received. No cause or acceptance is inferred from unavailable logs. Release is push-only guarded; this workflow_dispatch does not release.\n\nThe unchanged original diagnostics producer returned ok:true after its actual private xdg-open child exited23. The fix waits nonblockingly for child exit and both EOF receipts, then uses exact action/session/snapshot/revision/epoch ownership before acknowledgment or further side effects. Original-bug actual-child proof is distinct from newly discovered candidate cancellation reentry regressions. Final focused113/0 comprises77original+36additive subjects; native kernel save receiving is7/0. The earlier Mac UI9/0 used shared controller86bcb4 and does not qualify the final5cff controller; the fullcomposed Mac gate above receives the final image. Timeout/cancel/reentry controls through native ports remain distinct from actual child/kernel receipts. No desktop/browser rendering or installed Cocoa/WebKitGTK acceptance is claimed.\n\nSource/before and source/after retain17ownedpath pre/postimages, with the new document explicitly absent before. All original subjects/assertions are preserved apart from the declared obsolete background-shell-string expectation replaced by exact executable/argv completion semantics; the same ordered4effects, complete bytes and stable URL assertions remain. Review is independent source review, not execution. Required convention delta is exactly one LF blank line. Historical fixture, setup, temporary-directory and initial strict failures are retained with their boundaries; no failed verdict is rewritten.\n\nSafe environment summaries and activation sources preserve authenticated SDK/tool admission and replay limits; no private raw setup log, signed log URL, dependency binary, key, credential or duplicate earlier packet is included. Reconstructive replay was reviewed but not executed. This lot does not implement full daily-log collection or three-driver installed issue-form editability.\n'''
 (OUT/'README.md').write_text(text)
 shutil.copyfile(__file__,OUT/'seal-receiving.py')
 print(json.dumps({'state':'PREPARED_NOT_SEALED','static_members':sum(p.is_file() for p in OUT.rglob('*'))}))

def seal(source):
 assert re.fullmatch('[0-9a-f]{40}',source),'Explicit concrete full parent-provided source SHA required'
 assert not ARCHIVE.exists(),'Preserve existing sealed archive; do not overwrite'
 pub=read('opener-source-publication.json')
 assert pub['state']=='PUBLISHED' and pub['automatic_census_closed'] is True
 assert pub['source_commit']==source and pub['source_tree']==TREE
 recheck=read('opener-linux-recheck-status.json');final=read('opener-local-final-receiving.json')
 assert recheck['status']=='PASSED' and recheck['inputs_unchanged'] and recheck['before']==recheck['after']
 assert recheck['before']['index_tree']==TREE and recheck['source_or_assertion_changes'] is False
 assert [c['gate'] for c in recheck['commands']]==['original-native-sibling-fixture','linux']
 assert all(c['exit_code']==0 for c in recheck['commands'])
 assert final['status']=='PASSED' and final['source_tree']==TREE and final['inputs_unchanged']
 assert final['original_paired_attempt'].startswith('FAILED') and final['nonreproduced_initial_timeout_causally_resolved'] is False
 assert len(final['selected_gates'])==7 and all(c['exit_code']==0 for c in final['selected_gates'].values())
 assert subprocess.check_output(['git','rev-parse',source+'^{tree}'],cwd=ROOT/'config-healthcheck-opener-view',text=True).strip()==TREE
 prepare_closed()
 logfile=(ROOT/'opener-linux-recheck.log').read_bytes()
 assert sha(logfile)==recheck['log_sha256'],'Only closed exact log may be copied'
 counts={key:int(re.findall(pattern,logfile)[-1]) for key,pattern in {'passed':rb'Passed tests:\s*(\d+)','failed':rb'Failed tests:\s*(\d+)','modules':rb'Total modules:\s*(\d+)'}.items()}
 assert counts['passed']>0 and counts['failed']==0
 for name in ['opener-linux-recheck.log','opener-linux-recheck-status.json','opener-linux-recheck-controller.log','opener-linux-recheck-preflight-path-error.log','opener-local-final-receiving.json','opener-source-publication.json','opener-source-automatic.log']:
  copy(name,('publication/' if name.startswith('opener-source-') else 'local/recheck/')+name)
 for name in ['recheck-opener-linux.py','compose-opener-final-local.py']:copy(name,'local/runner/'+name)
 text=(OUT/'README.md').read_text().replace('Final source SHA and unchanged Linux recheck remain pending until explicit parent seal authorization.',f'Published source commit {source} has exactly this whole tree. Parent explicitly authorized final sealing after closed local recheck and publication automatic census.')
 text=text.replace('and only Linux is rechecked in full; its active log is not copied here.',f'and only Linux was then rechecked in full: {counts["passed"]}PASS/{counts["failed"]}FAIL across{counts["modules"]}modules, unchanged source/assertions. Both closed original and recheck logs are included. The recheck does not identify or causally repair the first timeout.')
 text+='\nFinal local composition:7selected gatesPASSED using6original successes and the fullunchanged Linux recheck; original pairFAILED remains authoritative for its own attempt. Hosted CI remainsFAILED as described above. A later archive-only feature publication may have a different tree solely because it adds this packet; that later commit is not the tested source commit.\n\nSHA256SUMS covers every regular member except itself; the outer sealed receipt supplies the archive hash.\n'
 (OUT/'README.md').write_text(text)
 emit('FINAL-RECEIVING.json',{'status':'SEALED','source_commit':source,'source_tree':TREE,'closed_local_status':'PASSED','original_pair_status':'FAILED','original_timeout_cause':'UNKNOWN','unchanged_linux_recheck':counts,'causal_fix_claimed':False,'manual_ci':'FAILED39jobs30success5failure4skip','manual_actual_sha':'ff0fac6afe707cdb164f1cd37b7b856ed79a4384','manual_tree':TREE,'installed_linux_scenarios_passed':17,'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 # Reject accidental private credential/signed redirect payloads without dumping contents.
 for p in OUT.rglob('*'):
  if p.is_file():
   assert not p.is_symlink() and '.private' not in p.name
   data=p.read_bytes()
   assert not re.search(rb'(?:X-Amz-Signature=[A-Fa-f0-9]{32}|[?&]sig=[A-Za-z0-9%/+]{24}|github_pat_[A-Za-z0-9_]{20}|gh[pousr]_[A-Za-z0-9]{20}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',data),str(p)
 members=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
 checks=''.join(sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix()+'\n' for p in members)
 (OUT/'SHA256SUMS').write_text(checks)
 with tarfile.open(ARCHIVE,'w:gz') as tar:
  for p in sorted(OUT.rglob('*')):
   if p.is_file():tar.add(p,arcname=p.relative_to(OUT).as_posix(),recursive=False)
 with tarfile.open(ARCHIVE,'r:gz') as tar:
  received=tar.getmembers();assert all(m.isfile() for m in received)
  assert len({m.name for m in received})==len(received)
  for line in tar.extractfile('SHA256SUMS').read().decode().splitlines():
   expected,path=line.split('  ',1);assert sha(tar.extractfile(path).read())==expected,path
  count=len(received)
 receipt={'status':'SEALED','source_commit':source,'source_tree':TREE,'archive_path':str(ARCHIVE),'archive_sha256':sha(ARCHIVE.read_bytes()),'regular_members':count,'sha256sums_checked_members':count-1}
 (ROOT/'diagnostic-opener-sealed.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prepare-closed',action='store_true');p.add_argument('--seal',action='store_true');p.add_argument('--source');a=p.parse_args()
 assert a.prepare_closed != a.seal,'Choose preparation or explicit parent-authorized seal'
 if a.seal:assert a.source;seal(a.source)
 else:prepare_closed()
