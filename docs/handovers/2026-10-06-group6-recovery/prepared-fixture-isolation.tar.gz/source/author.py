from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/ergopti');packet=Path('/workspace/scratch/group6-prepared-native-port-isolation')
f='static/ergopti_plus/linux/tests/support/prepared_native_ports.lua';old=(root/f).read_text()
start=old.index('--- Loads a fresh client against one fake libuv instance.')
end=old.index('\n\nreturn { fresh_client = fresh_client }',start)
new=old[:start]+'''--- Restores every backend captured while loading a fixture, including cold imports.
--- The entry objects retain nil, false and table values without truthiness coercion.
--- @param module_name string
--- @param fake table
--- @return table
local function load_against_fake(module_name, fake)
	local saved = {}
	for _, name in ipairs({ "luv", module_name, "adapters.shell_runner", "infra.monotonic" }) do
		saved[#saved + 1] = { name = name, value = package.loaded[name] }
	end
	package.loaded["luv"] = fake
	package.loaded[module_name] = nil
	local loaded, result = pcall(require, module_name)
	for _, entry in ipairs(saved) do package.loaded[entry.name] = entry.value end
	if not loaded then error(result, 0) end
	return result
end

--- Loads a fresh client against one fake libuv instance.
--- @param config table|nil
--- @return table client, table state
local function fresh_client(config)
	local fake, state = fake_luv(config)
	return load_against_fake("adapters.curl_http_client", fake), state
end

--- Loads a fresh file digest adapter against one fake libuv instance.
--- @param config table|nil
--- @return table digest, table state
local function fresh_digest(config)
	local fake, state = fake_luv(config)
	return load_against_fake("adapters.file_digest", fake), state
end
'''+old[end:]
(packet/'preimages'/f).write_bytes((root/f).read_bytes());(packet/'candidate'/f).write_text(new)
manifest='static/ergopti_plus/linux/tests/test_manifest.lua';mb=(root/manifest).read_bytes();(packet/'preimages'/manifest).write_bytes(mb)
mold=mb.decode();anchor='\t"tests.unit.meta.test_managed_http_fixture_import_isolation",';assert mold.count(anchor)==1
mnew=mold.replace(anchor,anchor+'\n\t"tests.unit.meta.test_prepared_native_port_import_isolation",');(packet/'candidate'/manifest).write_text(mnew)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+f,tofile='b/'+f))+''.join(difflib.unified_diff(mold.splitlines(True),mnew.splitlines(True),fromfile='a/'+manifest,tofile='b/'+manifest))
(packet/'isolation.patch').write_text(patch)
