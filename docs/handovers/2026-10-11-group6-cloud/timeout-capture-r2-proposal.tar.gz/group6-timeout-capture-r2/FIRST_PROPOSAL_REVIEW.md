# Settled timed-add capture: portable receiving proposal

This proposal adapts only the distinct existing-capture mechanism of retained
Root5580df8fbe to current Dev5f7a8467c9696b26a75de104f6329b39c181b8cb.
It is not adopted or independently accepted. Source custody remains pending.
Its initial source-only capsule and review remain preserved. Portable receiving
executes only after the parent reports its JS gate complete and explicitly
clears those controls; no native target executes in this preparation.

## Actual gap and narrow mechanism

Current `_command` already reports original phase/status, primary, closure
refusal, file debt and a fixed callee. Its callee read requires the normal wait
to return and produce a nonzero status. An actual timeout raises before that
read, then settles the child and closes the existing capture. Official current
receiving proves timed add refusals but lacks the completed child's capture
category and its post-settlement exit status. This proposal observes that exact
existing stderr before its original close, only when the original native owner
has an explicit reaped acknowledgment. It creates no file, process, clock,
wait, query, permission, retry or native acquisition.

The separate fixed stderr record preserves the existing trust-outcome record
unchanged. It contains bounded captured size, truncation, a closed callee and
literal category, original phase, exact post-settlement child exit status,
existing stream-close observation and file debt. Unknown/localized/truncated
content stays unknown. Literal interaction refusal does not prove a locked
keychain or a timeout cause. Missing or refused facts cannot admit trust or
erase cleanup debt. Induced child exit after settlement is cleanup evidence,
not the native command's primary result.

Optional capture and publication refusals are ignored without changing either
the original successful result or original failed exception. No private bytes,
hash of private bytes, PID, elapsed observation clock or exception attribute is
retained or exported. This deliberately declines those broader Root5580 fields
and its ability to fail a successful command on observer failure. No new private
exception custody or success-changing behavior is imported.

Native-group settlement is required to observe captures. The portable no-native
branch keeps its original output shape. An unreaped native owner receives only
unknown capture observations; no seek/read occurs while it owns the writable
file offset. File close uncertainty remains the original command's blocker.
No added observation grants closure, restoration or successor authority.

## Source preservation and unexecuted controls

The exact preimages and candidates cover only the fixture and its additive test
module. Four authored source spans and the final line-bound inverse reconstruct
the exact fixture preimage. All existing fixture function bodies except the
intentionally edited `_command` stay byte-exact. The complete original63-method
test file is recovered byte-exact by removing only the new class. Pinned
Ruff0.15.8 formatting and lint checks pass against those two isolated candidates.

Six proposed controls cover original timeout identity, existing capture closure,
the original wait/settle order, unknown/private/truncated output, unreaped-owner
read refusal, unchanged success and original outcome record, refused sink and
refused capture noninterference, and absence of private exception attributes.
Native process/settlement is a modeled port; capture files are actual private
files. No actual Darwin process, trust or permission result follows. After
parent clearance, serial original receiving executes six methods: one passes,
four fail by assertion and one errors on the absent new helper. Ten assertion
failure records include seven subtest failures in one method; they are not ten
failed methods. No method skips. The candidate executes all69 methods with69
passes, no failures/errors/skips, in23.987seconds. The complete original63 corpus
stays unchanged. Missing-helper errors retain their error classification and
are not called assertion failures. The existing timeout-primary, wait/settle
order and closure predicates execute before the missing diagnostic's assertion
in the first genuine predecessor counterexample.

The normal receiver and reproduction script reuse the existing checkout's
unchanged support graph rather than a duplicate repository. This isolated
receiving is separate from normal canonical JS registry enrollment, source
custody, independent review and native qualification.

Before adoption: independently review the conditional capture authority and
noninterference, recheck exact preimages and custody, run original-red/new cohort,
the full original-plus-added suite and selected gates, then qualify exact source
on both Darwin architectures. Fresh native cause evidence may then justify a
separate functional correction. Post-install exact-CA observation and same-WPAD
query-callee enrollment remain distinct proposals; this packet changes neither.
TODO36/62, transversal16/38, restoration, model, package/install and enterprise
device requirements remain open. No release or production guard changes.

## Missing canonical enrollment

The live owner at tools/test/test-managed-ollama-protocol.cjs:302 strictly
requires63 receiving-facts methods. This isolated two-path proposal adds six
methods and is incomplete for live adoption until a separately owned exact
registry change requires69. Preserve every original63 body and all status,
summary, no-skip and command-budget predicates. A combined independently reviewed
post-install plus timeout proposal would require its own exact composed source
and count; neither stand-alone count preparation qualifies that composition.
No count allowlist widening or weakened receiver is proposed. The canonical JS
gate on an adopted composition and native qualification remain outstanding.
