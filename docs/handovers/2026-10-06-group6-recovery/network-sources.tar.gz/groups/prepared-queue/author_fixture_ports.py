from pathlib import Path
import difflib
B=Path(__file__).parent
R=Path('/workspace/ergopti')
D='static/ergopti_plus/linux/tests/hardware/'
def save(path, text):
 p=B/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
def one(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
p=D+'run_http_preflight_receipts.lua';old=(R/p).read_text();save('fixture-preimages/'+p,old);s=old
s=one(s,'local HTTP = require("adapters.http_client")','local HTTP = require("adapters.http_client")\nlocal Curl = require("adapters.curl_http_client")')
s=one(s,'if not server_handles[handle] and not uv.is_closing(handle) then retained = true end','if not server_handles[handle] then retained = true end')
s=one(s,'check("first owned construction failure retains late native close acknowledgments", function()','''check("first owned construction failure retains late native close acknowledgments", function()
	-- This one historical scenario specifies native late-allocation construction
	-- debt. The stronger public no-allocation counterpart is exercised below.
	local HTTP = setmetatable({ get_owned = Curl.get_owned }, { __index = HTTP })''')
s=one(s,'\tHTTP.cancel(owner)\n\twait_for(native_clients_retired)','\tHTTP.cancel(owner)\n\tCurl.cancel("independent-owned-invalid")\n\twait_for(native_clients_retired)')
anchor='check("owned cleanup ownership rejects metadata without evaluating it", function()'
extra='''check("managed first malformed owned metadata refuses before all native allocation", function()
	local before_handles, before_requests, before_fds = {}, requests, {}
	uv.walk(function(handle) before_handles[handle] = true end)
	local scan = assert(uv.fs_scandir("/proc/self/fd"))
	while true do local name = uv.fs_scandir_next(scan); if not name then break end; before_fds[name] = true end
	local callbacks, result, conversions = 0, nil, 0
	local header = setmetatable({}, { __tostring = function()
		conversions = conversions + 1
		error("Synthetic fixed public metadata refusal")
	end })
	local operation = HTTP.get_owned(url .. "/direct", { ["X-Native"] = header },
		{ owner = "independent-public-invalid", timeout_ms = 1000 }, function(value) result, callbacks = value, callbacks + 1 end)
	assert(operation.started == false and operation:is_settled() and conversions == 1)
	assert(result and not result.ok and result.status == 0 and result.body == "" and callbacks == 1)
	assert(requests == before_requests)
	uv.walk(function(handle) assert(before_handles[handle], "preflight acquired a native handle") end)
	local after = assert(uv.fs_scandir("/proc/self/fd"))
	while true do local name = uv.fs_scandir_next(after); if not name then break end; assert(before_fds[name], "preflight acquired an FD") end
end)

'''
s=one(s,anchor,extra+anchor)
# The fixture's declared count is a real inventory guard; append exactly one.
# Existing final summary may derive checks, so require no hardcoded old count here.
save('fixture-candidate/'+p,s)
p=D+'run_http_body_cleanup_receipts.lua';old=(R/p).read_text();save('fixture-preimages/'+p,old);s=old
s=one(s,"local Http=require('adapters.http_client')", "local Http=require('adapters.http_client')\nlocal Curl=require('adapters.curl_http_client')")
anchor="local server_handles, sockets = {}, {}"
observation='''local native_operations = {}
local original_dispatch = Curl.dispatch_owned
-- Delegation records the genuine production token; no synthetic timer or
-- generic handle class can establish cleanup-monitor ownership.
Curl.dispatch_owned = function(...)
  local operation = original_dispatch(...)
  if type(operation)=='table' and type(operation._request)=='table' then
    native_operations[operation._request.owner]=operation
  end
  return operation
end
local observation_owner, monitor_observation = nil, false
local function exact_retained_monitor(handle)
  if not monitor_observation then return false end
  local operation=native_operations[observation_owner]
  local request=operation and operation._request
  local receipt=request and request.handles and request.handles[handle]
  return operation and not operation:is_settled() and request.owner==observation_owner
    and request.timer==handle and request.cleanup_monitor==true
    and receipt and receipt.state=='open'
end
'''
s=one(s,anchor,anchor+'\n'+observation)
s=one(s,"if not server_handles[h] and not uv.is_closing(h) then alive=true end", "if not server_handles[h] and not exact_retained_monitor(h) then alive=true end")
s=one(s,"local owner='native-body-close-debt-'..checks", "local owner='native-body-close-debt-'..checks\n  observation_owner,monitor_observation=owner,true")
s=one(s,"uv.walk(function(h) if not server_handles[h] and h~=retained_handle and not uv.is_closing(h) then alive=true end end)", "uv.walk(function(h) if not server_handles[h] and not exact_retained_monitor(h)\n      and not (not allow and h==retained_handle) then alive=true end end)")
s=one(s,"  allow=true\n  Http.cancel(owner)", "  allow=true\n  monitor_observation=false\n  Http.cancel(owner)")
# Ambiguous real-close return cases keep a genuine monitor until their exact
# already-closed descriptor observation is processed; there is no timer bypass
# when actual retirement was obtained.
s=one(s,"local owner='native-retired-body-fd-'..checks", "local owner='native-retired-body-fd-'..checks\n  observation_owner,monitor_observation=owner,false")
s=one(s,"uv.walk(function(h)if not server_handles[h] and h~=first and not uv.is_closing(h)then alive=true end end)", "uv.walk(function(h)if not server_handles[h] then alive=true end end)")
s=one(s,"  local callbacks=0\n  local dispatched=Http.post(origin,{},'{}',", "  local callbacks=0\n  observation_owner,monitor_observation='unknown-native-body',true\n  local dispatched=Http.post(origin,{},'{}',")
s=one(s,"  local recovered=Http.cancel('unknown-native-body') and count()==before", "  monitor_observation=false\n  local recovered=Http.cancel('unknown-native-body') and count()==before\n  wait_for(retired)")
s=one(s,"close(server);for _,s in ipairs(sockets)do close(s)end;uv.run()", "Curl.dispatch_owned=original_dispatch\nclose(server);for _,s in ipairs(sockets)do close(s)end;uv.run()")
# Preserve exact native port restoration on every ordinary or exceptional exit;
# a failing observation remains a failure, never an inferred physical ACK.
start=s.index('local origin=');body=s[start:]
body=body.replace("os.exit(failures==0 and 0 or 1)","return failures==0 and 0 or 1")
s=s[:start]+"local protected, outcome=xpcall(function()\n"+body+"\nend,debug.traceback)\npipe_backend[pipe_field],uv.pipe_open,uv.fs_close,uv.close=original_pipe,original_open,original_close,original_handle_close\nCurl.dispatch_owned=original_dispatch\nif not protected then error(outcome,0) end\nos.exit(outcome)\n"
save('fixture-candidate/'+p,s)
patch=[]
for p in sorted((B/'fixture-candidate').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(B/'fixture-candidate').as_posix();before=B/'fixture-preimages'/rel
 patch.extend(difflib.unified_diff(before.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
save('fixture-port.patch',''.join(patch))
