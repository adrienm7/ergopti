local root, os_name, module = arg[1], arg[2], arg[3]
local driver = root .. "/static/ergopti_plus/" .. os_name
local shared = root .. "/static/ergopti_plus/_shared/lua"
package.path = driver .. "/?.lua;" .. driver .. "/?/init.lua;" .. shared .. "/?.lua;" .. shared .. "/?/init.lua;" .. driver .. "/tests/?.lua;" .. driver .. "/tests/?/init.lua;" .. driver .. "/tests/stubs/?.lua;" .. package.path
if os_name == "macos" then _G.hs = require("tests.stubs.hs") end
local helpers = require("tests.helpers")
require(module)
local r = helpers.get_results()
print(string.format("RESULT %s: %d passed / %d failed", os_name, r.passed, r.failed))
for _, f in ipairs(r.failures) do print(f.name, f.err) end
assert(r.passed > 0 and r.failed == 0)
