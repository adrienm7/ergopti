// The native PAC producer retains existing raw files and its actual command observations.
const NATIVE_PAC_RAW_RETENTION_NAME = 'Retain native PAC raw source and command observations';
const NATIVE_PAC_RAW_RETENTION_BODY = "      - name: Retain native PAC raw source and command observations\n        if: ${{ always() && (steps.native-pac-build.outcome == 'success' || steps.native-pac-build.outcome == 'failure' || steps.native-pac-build.outcome == 'cancelled') }}\n        uses: actions/upload-artifact@v4\n        with:\n          name: windows-native-pac-raw-${{ github.sha }}-${{ github.run_id }}-${{ github.run_attempt }}\n          if-no-files-found: error\n          path: |\n            static/ergopti_plus/windows/build/native/network_pac/prepared/source_receipt.json\n            static/ergopti_plus/windows/build/native/network_pac/msvc_function.source.ps1\n            static/ergopti_plus/windows/build/native/network_pac/prepared/duktape.c\n            static/ergopti_plus/windows/build/native/network_pac/prepared/duktape.h\n            static/ergopti_plus/windows/build/native/network_pac/prepared/duk_config.h\n            static/ergopti_plus/windows/build/native/network_pac/prepared/LICENSE.txt\n            static/ergopti_plus/windows/build/native/network_pac/prepared/pac_generated.h\n            static/ergopti_plus/windows/build/native/network_pac/ergopti_network_pac.exe\n            static/ergopti_plus/windows/build/native/network_pac/artifact_receipt.json\n            static/ergopti_plus/windows/build/native/network_pac/identity-command.json\n            static/ergopti_plus/windows/build/native/network_pac/dependencies-command.json";
function nativePacRawRetentionProblems(files) {
	const owners = files.filter((entry) => entry.rel === WINDOWS_BOX);
	if (owners.length !== 1) return ['native PAC raw retention requires one Windows workflow'];
	const jobs = pipeline.jobsOfText(owners[0].text, WINDOWS_BOX).filter((job) => job.id === 'test-ahk');
	if (jobs.length !== 1) return ['native PAC raw retention requires one Windows unit owner'];
	const steps = pipeline.steps(jobs[0].body);
	const found = steps.filter((step) => step.name === NATIVE_PAC_RAW_RETENTION_NAME);
	if (found.length !== 1) return ['native PAC raw retention requires one retained producer step'];
	const problems = [];
	if (found[0].body.replace(/\n+$/, '') !== NATIVE_PAC_RAW_RETENTION_BODY)
		problems.push('native PAC raw retention condition/action/name/paths/fatal fields changed');
	const build = steps.findIndex((step) => step.name === 'Build and test native full-URL PAC evaluator');
	const artifact = steps.findIndex((step) => step.name === 'Retain native PAC artifact and source identity');
	const raw = steps.indexOf(found[0]);
	const runtime = steps.findIndex((step) => step.name === 'Read AutoHotkey runtime contract');
	if (!(build >= 0 && build < artifact && raw === artifact + 1 && raw < runtime))
		problems.push('native PAC raw retention follows original artifact before SDK admission');
	return problems;
}
errors.push(...nativePacRawRetentionProblems(pipeline.files()));
for (const [label, replacement] of [
	['deleted step', ''],
	['renamed step', NATIVE_PAC_RAW_RETENTION_BODY.replace(NATIVE_PAC_RAW_RETENTION_NAME, 'Unowned PAC raw evidence')],
	['duplicate step', NATIVE_PAC_RAW_RETENTION_BODY + '\n\n' + NATIVE_PAC_RAW_RETENTION_BODY],
	['skipped step', NATIVE_PAC_RAW_RETENTION_BODY.replace('        if: ', '        if: false # ')],
	['forgiven step', NATIVE_PAC_RAW_RETENTION_BODY.replace('        uses: ', '        continue-on-error: true\n        uses: ')],
	['wrong action', NATIVE_PAC_RAW_RETENTION_BODY.replace('actions/upload-artifact@v4', 'actions/upload-artifact@v3')],
	['missing files forgiven', NATIVE_PAC_RAW_RETENTION_BODY.replace('if-no-files-found: error', 'if-no-files-found: warn')],
	['foreign artifact namespace', NATIVE_PAC_RAW_RETENTION_BODY.replace('windows-native-pac-raw-', 'foreign-raw-')],
	...NATIVE_PAC_RAW_RETENTION_BODY.split('\n').filter((line) => line.startsWith('            ')).map((line) => [
		'missing retained source ' + line.trim(), NATIVE_PAC_RAW_RETENTION_BODY.replace(line + '\n', '').replace(line, '')
	])
]) {
	mustCatch('native PAC raw: ' + label, WINDOWS_BOX, NATIVE_PAC_RAW_RETENTION_BODY, replacement, nativePacRawRetentionProblems);
}
const nativePacRawMoved = pipeline.files().map((file) => file.rel === WINDOWS_BOX ? {
	...file,
	text: file.text.replace(NATIVE_PAC_RAW_RETENTION_BODY + '\n\n', '').replace(
		'      - name: Build and test native full-URL PAC evaluator\n',
		NATIVE_PAC_RAW_RETENTION_BODY + '\n\n      - name: Build and test native full-URL PAC evaluator\n'
	)
} : file);
assert.notDeepEqual(nativePacRawMoved, pipeline.files(), 'raw retention relocation changes actual source');
assert.ok(nativePacRawRetentionProblems(nativePacRawMoved).length > 0, 'raw retention cannot precede its producer');
console.log('PASS: native PAC raw retention source controls; native and producer execution UNRUN.');

