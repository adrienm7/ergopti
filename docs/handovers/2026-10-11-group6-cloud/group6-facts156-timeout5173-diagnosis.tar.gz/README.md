# Facts156 hosted timeout: bounded portable profile and prospective fixture improvement

Official CoreJS job114551226573 at5173d4fbb1565ea6252dbc74551e3260a818f3c5 ends411/412 with a genuine ETIMEDOUT from the unchanged60000ms Python spawn. The exact93132-byte original raw log is retained (SHA2561d4a80fb80aa05fea389c096118f21120308f8569e3c327f532f23d400fb923c). It names hosted Python3.12.15 and facts156. Child output is absent because the JS wrapper asserts before printing it. It does not report a bytecode error or the last executing case; the actual hosted timeout cause is unknown.

## Exact local original receiving

A finite25-path source closure was read from committed5173 Git objects, with exact blob/byte/SHA256 identities. Original source/case/helper/assertion bodies are unmodified. An outside-only TextTestResult start/stop recorder executes the original unittest.main alphabetical discovery through standard verbose output. It records every case duration, last started/stopped identity, available physical fixture/owned-model-child facts and terminal Python threads. It does not mock native child execution, process acquisition, clocks, keys, trust, HTTP or sockets.

| Actual cold source/context | Original cases | Failures/errors/skips | Terminal elapsed |
| --- | --- | --- | --- |
| Original, no PYTHONDONTWRITEBYTECODE |156|0/0/0|45.907s|
| Exact separate original closure, PYTHONDONTWRITEBYTECODE=1 |156|0/0/0|46.407s|
| Prospective one-hunk fixture, no bytecode variable |156|0/0/0|13.716s|

Every outer execution retains the unchanged60s boundary. Both original cold contexts pass and do not demonstrate a bytecode cause. The actual local interpreter is Python3.12.14, image SHA256fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7; local OpenSSL3.5.7/container differs from hosted Linux. Python3.12.15 and hosted image/runtime equivalence are not qualified here.

The original slow classes repeatedly construct real WireFixture instances, generate two RSA2048 keys/CA signatures and create six real servers. Guard18 takes11.235s, admin10 takes6.250s, wire8 takes5.087s, admission8 takes4.985s and server4 takes4.699s. The actual server loop inherits socketserver's500ms default select polling; original close must wait for each concurrent serving-loop shutdown to observe it.

## Concrete source-only performance proposal

`fixture-performance.patch` changes exactly the serving-worker acquisition expression to supply fixed poll_interval0.05. The original public serving/shutdown functions, six actual workers, start/retirement ownership, clocks, joins, captures, trust/restoration policy and every native15s command deadline remain unchanged. The original fixture preimage is SHA2569ce69d62fe7d1807b1df6aeedaab0ac6cb45b5fb5842330f9f0254f94033e289; final proposed postimage is c95cda5b0732cc54b86b34e1854fc193f0b487617d52a3784ddea8186e0e1672. Whole-file inverse is byte-exact; all24 other source paths and all four corpus files/346 prior helper/test function bodies remain exact. No testcase/count/corpus/assertion has been added, removed or reorganized.

An outside-only diagnostic observes the actual six OS selectors entering, then calls real fixture.close. It measures original idle close0.500953s versus prospective0.050368s. Both runs retain real six serving and shutdown workers, six closed sockets, root retirement and zero actual capture/command debt. No native SDK/Swift/Security/permission model is executed by this idle control. Its temporary0.30s assertion is only an independently imposed observation window, not an original contract or a new canonical cleanup requirement. Its original-red/potential-green logs are retained as private diagnostic measurements, not a regression claim. No literal50ms assertion is proposed for the canonical suite.

The full unchanged156 successor result demonstrates lower avoidable local serving-loop overhead with all original physical behavior/ownership assertions retained. This is a prospective resilience/performance improvement, not a reproduced historical hosted timeout or a workaround that raises the60s bound. Native Mac consumers and hosted3.12.15 behavior require owner-approved exact source qualification. Shared fixture G4/G5 custody remains ungranted in this packet; no live adoption is authorized by this local result alone.

## Closure and environment limits

All156 test start/stop pairs complete in each round; no last-started case remains open. Terminal active Python threads=1. Every recorded controlled model Popen child is physically reaped with stdin/stdout/stderr captures closed. Some source controls intentionally retain modeled native ACK debt records after exact outer test cleanup; those records are not Darwin process-closure acknowledgements. Passive /proc child enumeration is unavailable and yields null, so there is no claim of a complete global child census. Every original corpus cleanup assertion still executed. Before/after25-file hashes are exact for all three private source images, with exactly the one prospective fixture delta. Import-generated bytecode remains private and excluded from the source capsule, not mistaken for a source drift or error.

The first idle diagnostic shell presentation ended0 after displaying the intentional Python assertion-red; it did not capture that child exit numerically. It remains retained. The independent replay receives actual child exit1 with one assertion failure/zero errors and candidate exit0, with complete physical facts. No first receipt is rewritten as a successful test.

## Separate passive diagnostic preparation

`passive-diagnostics.patch` is a separate unadopted source-only proposal for test-managed-ollama-protocol.cjs, not part of the measured fixture candidate. It enables standard unittest verbose names only for facts156 and, on a failed child, prints bounded8192-character stdout/stderr tails plus script/status/signal/error_code BEFORE the unchanged original assertions. Optional diagnostic-sink errors cannot replace the original refusal. Original count156, all original assertions and timeout60000 remain exact under its whole-file inverse. It passes Node22 syntax only; its behavior/format/fullJS/native receiving are UNRUN. Future source owner approval and meaningful failure-output controls are still required before adoption.

Ruff format/check pass for the exact measured fixture successor. No full JS/native/CI/packaging/install suite was run in this packet. No canonical source/index/ref/lease/manual run/release was modified. The private portable test slot is explicitly released; parent owns any subsequent gate and official replay.
