local root = "/workspace/ergopti/static/ergopti_plus/macos"
local candidate = assert(arg[1])
package.path = table.concat({ candidate .. "/?.lua", candidate .. "/?/init.lua", root .. "/?.lua", root .. "/?/init.lua", root .. "/../_shared/lua/?.lua", root .. "/../_shared/lua/?/init.lua", package.path }, ";")
_G.hs = require("tests.stubs.hs")
local helpers = require("tests.helpers")
for index = 2, #arg do assert(loadfile(arg[index]))() end
local results = helpers.get_results()
print(string.format("CONTROL_TOTAL passed=%d failed=%d", results.passed, results.failed))
os.exit(results.failed > 0 and 1 or 0)
