# Independent focused lease receiving review

Verdict: CLEAR for the exact scoped source/model receiver in `/workspace/ergopti-group5-work/publications/lease-g6-focused-final-w2y63rs0`. This grants no native XCTest, complete package, installation or physical qualification. All146 genuine native methods remain UNEXECUTED here, including17 filesystem methods. Native Selected-tests wrapper compatibility remains unknown; the source safely refuses unsupported suite wrappers rather than treating filtered results as the full package.

## Independent frozen inputs

Corpus: `/workspace/ergopti-group5-work/lease-146-independent-FROZEN-qcj00j_k`. Genuine immutable c80 Swift source SHA256 ce28b9a330f8fe8f229d9acf28e3d04a848e1ead0be819b13ef8788661a29204 supplies exactly146 unique method identities, including17 retained diagnostic filesystem identities. Expected names and44 handwritten synthetic transcripts were frozen before the author's parser:2 complete positive schedules and42 negative schedules. Fixed synthetic timestamps and durations contain no user/private/native logs.

Driver: `/workspace/ergopti-group5-work/lease-146-independent-driver-FROZEN-25wniagn`. It independently requires the exact expected complete Boolean, closed scope lease-native-only, full_package_qualified=false, accepted completed146/errors[], and actual refusal errors for every negative. Missing symbols or imports receive no qualification credit.

Additional summary controls: `/workspace/ergopti-group5-work/lease-summary-independent-FROZEN-feelu_z5`. Before correction, both malformed duration and contradictory skipped suffix caused genuine assertions to fail against the unchanged original parser; exact receipts remain in `/workspace/ergopti-group5-work/lease-summary-before-EXECUTED-i4ee_x5a`. No original corpus or expected value changed.

## Source review

The final parser requires one Selected tests lifecycle, one exact KarabinerLeaseWorkerTests lifecycle, exactly146 distinct expected starts and matching passed terminals, matching146/zero-failure/zero-unexpected summaries, and both pipeline statuses0. Missing, duplicated, foreign, skipped, failed, partial or out-of-order frames cannot grant completion. The corrected summary grammar consumes the whole summary line; leading-space test frames are refused. Frozen expected names match the unchanged source identities.

Capture acquisition now allocates only the admitted regular-file size (at most16MiB), reads that fixed buffer, rejects early EOF, and preserves held-descriptor/path/size/mtime/ctime recuts and strict UTF-8 decoding. Actual private-file growth is rejected without a verdict. No raw transcript, path or exception becomes the closed verdict/console message. File acquisition failures and producer/pipeline failure preserve refusal; full_package_qualified stays false on every result.

The modeled transcript is evidence about admission behavior only. It cannot establish that Swift executed any method, that the two actual pipeline processes exited0, or that a runner emits this exact native wrapper. Those facts require the future genuine native CI run.

## Exact execution results

Five bounded final commands exit0, stderr empty; literal commands/cwd/owned TMPDIR/status/durations/hashes are in EXECUTION.json with individual raw stdout/stderr. Each timeout is30 seconds, with no retries or widened/native budgets.

- Independent frozen receiving44:44 PASS,2 accepted/42 refused,0 skips/errors.
- Independent frozen summary2:2 PASS after genuine original2 assertion failures.
- Registered receiver51:44 receiving +2 real POSIX capture/growth +3 leading-frame refusals +2 frozen malformed summaries, all PASS.
- Original G6 program:44 original controls and26 additional fixed-wrapper controls PASS.
- Static pipeline program:original52 deferral controls, item36=65, PAC/WPAD=82, priorfocused24=2 accepted/22 refused, one placement refusal, and registered51 PASS. These source/model controls are not native case counts. Repeated programs are not added together as unique coverage.

No full JS, compiler, Swift, native API, workflow, reference, index or canonical mutation executed. The source2 reviewer owns final shared CI/body inverses; the old raw source checks were executed proportionately before Root asked to avoid repeats. The separately retained original qualification `/workspace/ergopti-group5-work/lease-146-independent-executed-v1-yzaajrds` includes original44/52/24 preservation:44 exact prefix,52 ordered original bytes restored by additive inverse,24 whole literal. An overstrict independent52-prefix assertion initially failed; original52 is preserved by inverse, not a whole-prefix claim. No candidate assertion was altered for that correction.

## Causal sensitivity and restoration

All mutation hooks/files exist only in `/workspace/ergopti-group5-work/lease-146-independent-executed-final-naujoj7n/mutant-context`; the sealed author's overlay was never modified. Frozen mutation intentions/source hashes precede every command. No expected corpus was regenerated.

- Exact removal of the admitted-size reader bound causes the actual growing-file allocation assertion to fail. The final-source restore passes registered51.
- Exact removal of the final pipeline-status guard causes the independently frozen swift-pipeline-failure assertion to fail. Exact restore passes independent44.
- Exact removal of the full-line summary grammar causes both independently frozen summary assertions to fail. Exact restore passes both.

All3 mutant commands produce intended assertion failures, not missing files/imports/symbols; all3 restored commands exit0. Raw outputs and exact post/mutant hashes are retained in MUTANT-EXECUTION.json and FROZEN-MUTANT-INTENTION.json. All8 authored postimages and the copied independent44 fixture are unchanged after execution. The private helper is byte-exactly restored to the final postimage.

Existing producer complete-coverage HOLD and all previous immutable evidence remain untouched. Root retains authority over source adoption, coordination, commit/push and future CI.
