﻿; tests/unit/test_ollama_managed_windows_lifecycle.ahk

; ==============================================================================
; MODULE: Managed Windows Lifecycle Recording Controls
; DESCRIPTION:
; Exercises the real global-owner boundary with the explicit coordinator ports.
; Process/job and durable-file receipts remain independent native obligations.
; ==============================================================================

_OMW_UninitializedShutdownHasNoAuthority() {
	global _LLM_ManagedWindowsCoordinator
	local saved := _LLM_ManagedWindowsCoordinator
	try {
		_LLM_ManagedWindowsCoordinator := 0
		AssertTrue(LLM_ManagedWindows_PrepareShutdown())
		AssertFalse(LLM_ManagedWindows_HasNativeOwner())
		AssertFalse(LLM_ManagedWindows_DataDebt())
	} finally _LLM_ManagedWindowsCoordinator := saved
}

_OMW_InitializationIsExclusive() {
	global _LLM_ManagedWindowsCoordinator
	local saved := _LLM_ManagedWindowsCoordinator, world := _OMC_World()
	try {
		_LLM_ManagedWindowsCoordinator := 0
		AssertTrue(LLM_ManagedWindows_Init(world.Owner))
		AssertThrows(() => LLM_ManagedWindows_Init(world.Owner))
		AssertTrue(_LLM_ManagedWindowsCoordinator == world.Owner)
	} finally {
		try world.Drain()
		finally _LLM_ManagedWindowsCoordinator := saved
	}
}

_OMW_ShutdownRefusesUntilExactOwnerHandback() {
	global _LLM_ManagedWindowsCoordinator
	local saved := _LLM_ManagedWindowsCoordinator, world := _OMC_World()
	try {
		_LLM_ManagedWindowsCoordinator := 0
		LLM_ManagedWindows_Init(world.Owner)
		AssertTrue(world.Owner.Start(world.Plan))
		AssertFalse(LLM_ManagedWindows_PrepareShutdown())
		AssertTrue(LLM_ManagedWindows_HasNativeOwner())
		AssertEqual(world.Ready, 0)
		world.AllowStop := true
		AssertTrue(LLM_ManagedWindows_PrepareShutdown())
		AssertFalse(LLM_ManagedWindows_HasNativeOwner())
		AssertEqual(world.Failed, 1)
	} finally {
		try world.Drain()
		finally _LLM_ManagedWindowsCoordinator := saved
	}
}

_OMW_DurableFileDebtIsIndependentAndBlocksRestart() {
	global _LLM_ManagedWindowsCoordinator
	local saved := _LLM_ManagedWindowsCoordinator, world := _OMC_World()
	try {
		_LLM_ManagedWindowsCoordinator := 0
		LLM_ManagedWindows_Init(world.Owner)
		world.FileDebt := true
		AssertFalse(world.Owner.Start(world.Plan))
		AssertEqual(world.Starts, 0)
		AssertFalse(LLM_ManagedWindows_HasNativeOwner())
		AssertTrue(LLM_ManagedWindows_DataDebt())
	} finally {
		try world.Drain()
		finally _LLM_ManagedWindowsCoordinator := saved
	}
}

Test("ollama-managed-lifecycle-uninitialized", _OMW_UninitializedShutdownHasNoAuthority)
Test("ollama-managed-lifecycle-exclusive-init", _OMW_InitializationIsExclusive)
Test("ollama-managed-lifecycle-physical-handback", _OMW_ShutdownRefusesUntilExactOwnerHandback)
Test("ollama-managed-lifecycle-independent-file-debt", _OMW_DurableFileDebtIsIndependentAndBlocksRestart)
