from pathlib import Path
from collections import Counter
import json,hashlib,re
old=Path('/workspace/scratch/oct28-field-admission');new=Path('/workspace/scratch/oct28-combined34-hs');groups=['integration','meta','core','modules','menu_llm','menu_input','ui','other'];counters=[];normalized=[];pins=[]
for root in [old,new]:
 c=Counter();n=Counter()
 for group in groups:
  p=root/f'hs-{group}.log';raw=p.read_bytes();pins.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()})
  for line in raw.decode().splitlines():
   if line.startswith('# lua_timing '):
    x=json.loads(line[len('# lua_timing '):])
    if x['kind']=='case':
     assert x['status']=='pass';name=x['name'];c[x['module'],name]+=1
     if x['module']in['tests.unit.adapters.network.test_http_client_redirect_policy','tests.unit.ui.editors.test_keyboard_slot_declared_presentation']:name=re.sub(r'table: 0x[0-9a-fA-F]+','table: <runtime-address>',name)
     if x['module']=='tests.meta.boot.test_lua_sources_compile':name=re.sub(r'\(95[45] files scanned\)','(<source-census> files scanned)',name)
     n[x['module'],name]+=1
 counters.append(c);normalized.append(n)
def rows(c):return[{'module':m,'name':n,'count':count}for(m,n),count in c.items()]
a,b=counters;na,nb=normalized
D={'component_tree':'7c82d090801308bbfdcf40b1c754901b33a3ef70','combined_tree':'0bc786dfbffe727cf6fb549be0fe7cd7857ae066','component_passed':sum(a.values()),'combined_passed':sum(b.values()),'raw_added':rows(b-a),'raw_removed':rows(a-b),'normalized_added':rows(nb-na),'normalized_removed':rows(na-nb),'normalization_scope':'Only hex runtime table addresses in two named existing test modules and production Lua source census954→955 in existing compiler test; raw identities retained above. No assertion or test result normalized.','input_logs':pins,'initial_attribution_probe':'An initial strict raw case identity assertion failed because three existing case names include runtime addresses or source counts. No suite/source rerun or edit; exact raw difference is retained here.'}
assert D['component_passed']==25380 and D['combined_passed']==25385 and len(D['raw_added'])==8 and len(D['raw_removed'])==3 and len(D['normalized_added'])==5 and not D['normalized_removed']
p=new/'component-to-combined-case-delta.json';p.write_text(json.dumps(D,indent=2)+'\n');print(json.dumps(D['normalized_added'],indent=2));print('receipt_sha256',hashlib.sha256(p.read_bytes()).hexdigest())
