# Source-only route-origin receiving controls

These scripts are authored but **UNRUN**. No test, native call, suite, Git mutation,
main-checkout or product edit was performed by this child agent.

The subject packet is `/tmp/group6-windows-route-origin-diagnostic-r1`:

- PowerShell proposed fixture SHA-256:
  `fe52db99f7c822e3e8ba6107cbf85b6ab9c34819b7e3a4837c86509936d9a59b`.
- AutoHotkey proposed receiver SHA-256:
  `c88aaea21f2db7c16ec6cda0f06c64dd08005e735cc221a7bc30a02e82772173`.
- Its existing patch and preimages remain untouched.

`receiving.ps1` uses the genuine PowerShell parser to admit the whole fixture and
extract only its two unique passive functions. It never dot-sources the whole
fixture, compiles the native server, loads the production WinHTTP provider or
performs networking. Independently authored cases cover all 15 production source
values, the two closed kinds, mixed-case/private/nonscalar values, null/array/
primitive/custom-object results, zero/two/malformed routes, 4096/4097 count
admission, limits, case-insensitive hashtable keys, signed errno boundaries,
provenance/domain/status admission, and resets. The actual writer is captured in
memory; exact complete frames, no private metadata reflection and the original
one-attempt behavior are checked for every projection. It expects at least 70
controls (74 cases are authored), and checks the fixture hash before each call
and after completion. Failure output prints only a fixed authored case label.

`receiving.cjs` extends the previous independent Node receiver model. It extracts
the actual AHK regex from the frozen proposed carrier, admits each actual guard
exactly once, checks its BOM/LF and before/after hash, and executes 61 independently
specified cases. Controls include every source, valid native/static/unknown
frames, casing/delimiters/private suffixes, duplicates including CRLF, integer and
count boundaries, malformed/non-single projections, foreign-shape fields,
oversized capture and private surrounding lines. Accepted output is modeled as
only the closed regex groups. Node success is **not AutoHotkey, WinHTTP, PAC or
Windows qualification**. This is the same limited source-bound model technique
as the previously delivered route-shape receiver; its semantics are explicitly
fenced by the unchanged actual AHK guard text.

Root should check the source packet preimages against the actual checkout,
verify its whole-file inverse, preserve the AHK BOM and all original acceptance
assertions/providers/clocks/capture/retirement, then execute these controls through
its existing owned-command wrapper, sequentially with other local gates. Suggested
root-owned command shapes:

```text
pwsh -NoProfile -NonInteractive -File /tmp/group6-route-origin-receiving-r1/receiving.ps1
node /tmp/group6-route-origin-receiving-r1/receiving.cjs
```

Use the already-qualified PowerShell SDK and its private XDG cache/config/data
roots, telemetry opt-out and update-check settings. Each script defaults to the
frozen source packet; an alternate packet-root argument is accepted only if the
same expected subject hashes hold. Do not claim a passing control before root
records a terminal receipt. Then run normal verify-change, encoding/source gates
and targeted genuine Windows manual CI on the actual applied sources.

A single `native_direct` observation establishes origin only. It does not prove
why the full-URL PAC expression failed. This candidate remains diagnostic and
cannot be credited as a production routing fix or closure of TODO 62.
