local root="/workspace/ergopti-windows-r6-lifecycle/static/ergopti_plus/_shared/"
package.path=root.."lua/?.lua;"..package.path
local Json=require("json");local Policy=require("control.driver_control")
local f=assert(io.open(root.."modules/control/driver_control.json","rb"));local raw=assert(f:read("*a"));assert(f:close());local spec=Policy.validate(Json.decode(raw))
local rows={
 {"native", [[,"driver_pid":200]], true},
 {"decimal", [[,"driver_pid":200.0]], true},
 {"exponent", [[,"driver_pid":200e0]], true},
 {"string", [[,"driver_pid":"200"]], false},
 {"duplicate-string", [[,"driver_pid":200,"driver_pid":"200"]], false},
 {"escaped", [[,"driver_\u0070id":200]], true},
 {"boolean", [[,"driver_pid":true]], false},
 {"missing", "", false},
}
local passed,failed=0,0
for _,row in ipairs(rows) do
 local text='{"schema":1,"request_id":"claimed-kind","state":"claimed","successor_pid":200,"deadline":1700000120'..row[2]..'}'
 local decoded=Json.decode(text);assert(decoded.successor_pid==200 and decoded.deadline==1700000120)
 local kind,result=Policy.resolve(spec,text,200,1700000000,Json.decode)
 local expected='{"schema":1,"request_id":"claimed-kind","state":"completed","driver_pid":200,"successor_pid":200}\n'
 local ok=(row[3] and kind=="completed" and result==expected) or (not row[3] and kind==nil and result==nil)
 print((ok and "PASS " or "FAIL ")..row[1]);if ok then passed=passed+1 else failed=failed+1 end
end
print(passed.." passed, "..failed.." failed");os.exit(failed==0 and 0 or 1)
