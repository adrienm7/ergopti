#!/bin/sh
LD_LIBRARY_PATH="/workspace/tooling/wizard-browse-zenity-v1/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH
exec /workspace/tooling/wizard-browse-zenity-v1/usr/bin/zenity "$@"
