# Finite process bridge preparation and qualification

This unconnected preparation consumes actual Group3 shared worker commit
`1b3f5c183a71f7ca4fc40f60105acbe5f1b7a462`, copied read-only to
`/workspace/ergopti-validation/native_worker_owner-g3-1b3f5c.lua`, and the approved
scratch Linux physical process owner. Neither source was changed. No checkout
changes, official Ollama downloads or installation occurred.

## Source mapping

`shared/llm/finite_process_port.lua` exports `new(Worker, NativeProcess, native,
retry_ms)` and returns the existing installer-compatible `start(executable,
arguments, options, callback)` port. It reserves a nonempty string owner before
external source admission; snapshots argument/environment/options scalars; and
returns `started/result/cleanup_error/cancel/is_settled/on_settled`.

The published worker API owns admission, finite timeout/retry scheduling, stop,
and its exact native timer retirement. A deferred `runner.spawn` facade allocates
no native object. Only its `start` dispatches the actual physical process owner.
The native process receives no independent timeout; the common worker is the
finite deadline policy owner. Its cancel/settlement methods retain real process
exit, group absence and every owned stream/process/monitor close receipt. This
bridge neither calls kill directly nor manufactures process-group retirement.

`runner.spawn` maps the actual camelCase deferred methods
`start/isSettled/terminate/onSettled`; native callbacks retain the full bounded
result while the shared worker receives integer status. A valid physical refusal
capability remains an admitted deferred operation, although public `started` is
false. Cancellation before capability acquisition is recorded and applied when
that exact capability returns. Throwing/malformed acquisition retains unknown
debt and blocks exact-owner successors. Refused native settlement registration
can retire only when the shared worker independently polls literal true.

Callback/listener assertions are outside product-contained callbacks. Controlled
source expectations were frozen before execution. The facade adds no native
state machine: every retirement question delegates to the exact native owner
and the common worker timer, and its owner map only fences the installer port.

## Exact executions and blocking result

`results/initial-g3-1b3f5c/summary.json` records argument vectors, exit statuses,
raw stdout/stderr paths, transcript SHA-256 values and identical source hashes
before and after execution. Environment activation was
`source /workspace/ergopti-env.sh`; tools used authorized `require_escalated`
mode for configured native libraries and `/var/tmp` access.

| ABI/suite | Exit | Passed | Failed | Not executed |
| --- | --- | --- | --- | --- |
| LuaJIT controlled seams | 1 | 14 | 1 | 4 |
| Lua 5.4 controlled seams | 1 | 14 | 1 | 4 |
| LuaJIT actual native composition | 0 | 4 | 0 | 0 |
| Lua 5.4 actual native composition | 0 | 4 | 0 | 0 |

Controlled suites fail fast; their four following cases per ABI did not execute.
No harness skip occurred. Each native run used the existing physically owned
Python child-subreaper wrapper, reported zero adopted descendants, and required
an inactive real libuv loop after each case. Actual native cases cover ordinary
exit and exact output, a finite common deadline after an actual printed receipt
that a SIGTERM-ignore handler was installed, explicit cancel with an exact-owner
successor blocked until physical retirement, and real ENOENT. These eight native
passes do not override the two controlled retirement failures.

The failure is in the pinned shared worker's timer-close policy:

1. Native `close(timer, callback)` returns false; worker resets
   `timer_closing=false` and `timer_retired=false`.
2. The callback from that refused attempt arrives later and unconditionally sets
   `timer_retired=true`, despite no admitted close receipt.
3. On the next retry, `settled` sees that true flag, skips a fresh native close,
   and releases the exact owner.

The independent case requires a new admitted close and its own ACK before
retirement. It fails under both ABIs. Assertions were not removed, weakened or
changed. This blocks bridge adoption pending Group3's shared source repair.

## Proposed minimal common-owner correction

Bind each close attempt to a fresh identity token with separate `admitted` and
`callback_received` flags. Its callback may mark only that attempt's receipt,
and may mutate `entry.timer_retired` only after that exact attempt is admitted.
A rejected/throwing attempt invalidates its token; late callbacks from it must
never change the active entry's timer retirement flag. A successful synchronous
callback must be retained until the return receipt admits the same token.
Retry may create a fresh attempt; old callbacks must not borrow its admission.
Group3 owns this correction and its shared regression registration.

## Published daemon extension proposal

The current common worker mandates positive finite `timeout_ms`; passing nil
fails construction. A daemon must not use a giant artificial deadline or bypass
common policy with another owner. Add an explicit service lifetime mode under
Group3 ownership, e.g. `lifetime="service"` with `timeout_ms=nil`. Default mode
remains finite and requires a positive timeout. Service mode retains referenced
retry/admission/group/close monitoring and exact stop/pause semantics, and skips
only the elapsed-deadline comparison. Startup readiness retains its own finite
source/enable transaction budget. Publication must transfer from the originating
disabled enable ticket to stable application ownership atomically with the
preference-write receipt; it must not stop a published daemon because the
successful enable transition invalidated the disabled ticket.

This extension is not implemented here. Shared service source admission and
explicit reason receipts should be reviewed before actual daemon production
wiring. Archive installer, resolver, model/UI repair and package/install gates
remain separate unfinished scope.
