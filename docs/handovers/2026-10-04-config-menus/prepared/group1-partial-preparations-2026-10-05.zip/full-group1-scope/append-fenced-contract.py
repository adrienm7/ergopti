from pathlib import Path
p=Path('/workspace/ergopti-delivery/full-group1-scope/candidate/static/ergopti_plus/_shared/lua/test/config_scope_composition_contract.lua');old=p.read_text();assert old.endswith('end\n')
extra=r'''

	helpers.describe("fenced configuration transaction", function()
		local original = '[gestures]\nenabled = true\nswipe_3_down = "copy"\nfuture = 73\n[foreign]\nkeep = false\n'
		local expected = { gestures = { enabled = true, swipe_3_down = "copy", future = 73 }, foreign = { keep = false } }
		local Codec = require("toml_codec")
		local Fenced = require("config_scope_fenced_transaction")
		local function fixture(run)
			with_cohort_files(function(path, read, write, transaction)
				local file = path(); write(file, original)
				local primary, runtime, controls = transaction(file, "original-runtime")
				local token, claims, ports, trace = {}, {}, {}, {}
				local state = { available = true }
				for index = 1, 3 do
					ports[index] = {
						acquire = function(owner)
							trace[#trace + 1] = "acquire:" .. index
							if state.reacquire == index and state.released then return false end
							if state.refuse_acquire == index then return state.reply() end
							helpers.assert_eq(claims[index], nil)
							claims[index] = owner
							if state.reentrant then
								local callback = state.reentrant; state.reentrant = nil; callback()
							end
							return true
						end,
						release = function(owner)
							trace[#trace + 1] = "release:" .. index
							helpers.assert_eq(claims[index], owner, "release requires this exact live claim")
							if state.refuse_release == index then return state.reply() end
							claims[index], state.released = nil, true
							return true
						end,
					}
				end
				local owner = Fenced.new({ owner = token, transaction = primary, scope = "gestures", fences = ports,
					available = function() return state.available end })
				helpers.assert_eq(owner, token)
				run(owner, primary, runtime, controls, state, claims, trace, file, read, write)
			end)
		end

		for _, receipt in ipairs({
			{ name = "nil", reply = function() return nil end },
			{ name = "false", reply = function() return false end },
			{ name = "truthy", reply = function() return "true" end },
			{ name = "wrong type", reply = function() return {} end },
			{ name = "exception", reply = function() error("native claim refused") end },
		}) do
			for _, mode in ipairs({ "clear", "recommended" }) do
				helpers.it("owns " .. mode .. " compensation until a " .. receipt.name .. " release settles", function()
					fixture(function(owner, _, runtime, _, state, claims, _, file, read)
						state.refuse_release, state.reply = 2, receipt.reply
						helpers.assert_eq(owner.apply(mode), false)
						helpers.assert_eq(owner.pending(), true)
						helpers.assert_eq(owner.release(), false)
						helpers.assert_eq(owner.apply(mode), false)
						state.refuse_release = nil
						helpers.assert_eq(owner.retry_restore(), true)
						helpers.assert_eq(runtime.marker, "original-runtime")
						helpers.assert_eq(Codec.decode(read(file)), expected)
						helpers.assert_eq(owner.pending(), false)
						helpers.assert_eq(next(claims), nil)
					end)
				end)
			end

			helpers.it("retains no primary mutation when " .. receipt.name .. " acquisition refuses", function()
				fixture(function(owner, _, runtime, _, state, claims, _, file, read)
					state.refuse_acquire, state.reply = 2, receipt.reply
					helpers.assert_eq(owner.apply("clear"), false)
					helpers.assert_eq(owner.pending(), false)
					helpers.assert_eq(runtime.marker, "original-runtime")
					helpers.assert_eq(read(file), original)
					helpers.assert_eq(next(claims), nil)
				end)
			end)
		end

		helpers.it("retains an inverse until its released claim can be reacquired", function()
			fixture(function(owner, primary, runtime, _, state, claims, _, file, read)
				state.refuse_release, state.reply, state.reacquire = 2, function() return false end, 3
				helpers.assert_eq(owner.apply("clear"), false)
				local candidate = read(file)
				helpers.assert_eq(primary.committed(), true)
				helpers.assert_eq(runtime.marker, "neutral")
				state.refuse_release = nil
				helpers.assert_eq(owner.retry_restore(), false)
				helpers.assert_eq(read(file), candidate)
				state.reacquire = nil
				helpers.assert_eq(owner.retry_restore(), true)
				helpers.assert_eq(Codec.decode(read(file)), expected)
				helpers.assert_eq(next(claims), nil)
			end)
		end)

		helpers.it("keeps all claims while runtime compensation refuses", function()
			fixture(function(owner, _, runtime, controls, _, claims, _, file, read)
				controls.refuse_apply, controls.refuse_restore = true, true
				helpers.assert_eq(owner.apply("clear"), false)
				helpers.assert_eq(owner.pending(), true)
				for index = 1, 3 do helpers.assert_eq(claims[index], owner) end
				helpers.assert_eq(owner.retry_restore(), false)
				controls.refuse_restore = false
				helpers.assert_eq(owner.retry_restore(), true)
				helpers.assert_eq(runtime.marker, "original-runtime")
				helpers.assert_eq(Codec.decode(read(file)), expected)
				helpers.assert_eq(next(claims), nil)
			end)
		end)

		helpers.it("settles an acknowledged inverse release without repeating runtime restoration", function()
			fixture(function(owner, _, runtime, _, state, claims, _, file, read)
				helpers.assert_eq(owner.apply("recommended"), true)
				state.refuse_release, state.reply = 2, function() return false end
				helpers.assert_eq(owner.revert(), false)
				helpers.assert_eq(Codec.decode(read(file)), expected)
				local restored = runtime.restored
				state.refuse_release = nil
				helpers.assert_eq(owner.retry_restore(), true)
				helpers.assert_eq(runtime.restored, restored)
				helpers.assert_eq(next(claims), nil)
			end)
		end)

		helpers.it("refuses reentrant mutation while a native claim is being acquired", function()
			fixture(function(owner, _, _, _, state, _, _, file, read)
				state.reentrant = function()
					helpers.assert_eq(owner.pending(), true)
					helpers.assert_eq(owner.apply("recommended"), false)
					helpers.assert_eq(owner.retry_restore(), false)
				end
				helpers.assert_eq(owner.apply("clear"), true)
				helpers.assert_eq(owner.revert(), true)
				helpers.assert_eq(Codec.decode(read(file)), expected)
				state.available = false
				helpers.assert_eq(owner.apply("recommended"), false)
			end)
		end)
	end)
''';p.write_text(old[:-4]+extra+'end\n')
