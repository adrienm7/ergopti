// D:/ewt/_context/tools/build_context.cjs
//
// Builds the hand-off files for the ErgoptiPlus overhaul resume:
//   - journal.jsonl     copy of the paused workflow journal (source of task results)
//   - TASK_SPECS.md     product decisions, per-lane rules and every task spec
//   - TASK_STATUS.md    latest implement/review result of every task
//
// Usage: node D:/ewt/_context/tools/build_context.cjs
// Re-run it at any time; it only reads the workflow script and the journal.

'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const CTX = path.resolve(__dirname, '..');
const SCRIPT = path.join(CTX, 'overhaul_workflow_script.js');
const SRC_JOURNAL = 'C:/Users/admin/.claude/projects/D--Documents-GitHub-ergopti/7b42cfbe-60d7-41bb-87b3-b1a03baf7926/subagents/workflows/wf_97b8817b-99f/journal.jsonl';
const JOURNAL = path.join(CTX, 'journal.jsonl');

// ---- journal copy -------------------------------------------------------

if (fs.existsSync(SRC_JOURNAL)) fs.copyFileSync(SRC_JOURNAL, JOURNAL);
if (!fs.existsSync(JOURNAL)) throw new Error(`No journal at ${JOURNAL} or ${SRC_JOURNAL}`);

// ---- specs --------------------------------------------------------------

const lines = fs.readFileSync(SCRIPT, 'utf8').split('\n');
const endOfConstants = lines.findIndex((l) => l.startsWith('const extraNotes'));
if (endOfConstants < 0) throw new Error('end of the script constants not found');
const body = lines.slice(9, endOfConstants).join('\n')
  .replace(/const MAP = '[^']*'/, `const MAP = '${CTX.replace(/\\/g, '/')}/map'`);
const sandbox = {};
vm.runInNewContext(`${body}\nthis.out = { BASE, DECISIONS, COMMON, LANES, EXTRA_COMMON };`, sandbox);
const { BASE, DECISIONS, COMMON, LANES, EXTRA_COMMON } = sandbox.out;

const specs = [];
specs.push('# ErgoptiPlus overhaul: decisions and task specs', '');
specs.push(`Generated from \`overhaul_workflow_script.js\`. Base commit of every lane branch: \`${BASE}\`.`, '');
specs.push('## Approved product decisions (DECISIONS)', '', '```text', DECISIONS.trim(), '```', '');
specs.push('## Later notes that override the decisions above (EXTRA_COMMON)', '', '```text', EXTRA_COMMON.trim(), '```', '');
for (const lane of LANES) {
  specs.push(`## Lane \`${lane.key}\` (worktree ${lane.path}, branch ${lane.branch})`, '');
  specs.push(`Other lanes that touch nearby files: ${lane.others}`, '');
  specs.push('### Rules given to every agent of this lane (COMMON)', '', '```text', COMMON(lane).trim(), '```', '');
  for (const t of lane.tasks) {
    specs.push(`### ${t.id}: ${t.title}`, '', '```text', String(t.spec).trim(), '```', '');
  }
}
fs.writeFileSync(path.join(CTX, 'TASK_SPECS.md'), specs.join('\n'));

// ---- status -------------------------------------------------------------

const journal = fs.readFileSync(JOURNAL, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const labelOf = new Map(journal.filter((e) => e.type === 'started').map((e) => [e.agentId, e.label]));
const startedIds = new Set(labelOf.keys());
const finishedIds = new Set(journal.filter((e) => e.type === 'result' || e.type === 'failed').map((e) => e.agentId));

// Keep, per label, the last result that did real work (not blocked / failed).
const best = new Map();
for (const e of journal) {
  if (e.type !== 'result' || !e.result) continue;
  const label = labelOf.get(e.agentId);
  if (!label) continue;
  const prev = best.get(label);
  const real = e.result.status !== 'blocked';
  if (!prev || real || prev.result.status === 'blocked') best.set(label, { agentId: e.agentId, result: e.result });
}
const running = [...startedIds].filter((id) => !finishedIds.has(id)).map((id) => labelOf.get(id));

const out = [];
out.push('# ErgoptiPlus overhaul: task status', '');
out.push('Generated from the paused workflow journal. `impl` = implementation, `review` = adversarial review.');
out.push('A missing row means the step never produced a result. `blocked` means the agent stopped on the maintainer pause note without working.', '');
out.push('| Lane | Task | impl | review |', '|---|---|---|---|');
for (const lane of LANES) {
  for (const t of lane.tasks) {
    const s = (kind) => {
      const b = best.get(`${lane.key}:${t.id}:${kind}`);
      if (!b) return running.includes(`${lane.key}:${t.id}:${kind}`) ? 'interrupted' : '—';
      return `${b.result.status} (${(b.result.commits || []).length} commits)`;
    };
    out.push(`| ${lane.key} | ${t.id} | ${s('impl')} | ${s('review')} |`);
  }
}
out.push('');
for (const lane of LANES) {
  for (const t of lane.tasks) {
    for (const kind of ['impl', 'review']) {
      const b = best.get(`${lane.key}:${t.id}:${kind}`);
      if (!b || b.result.status === 'blocked') continue;
      const r = b.result;
      out.push(`## ${lane.key} ${t.id} ${kind}: ${r.status}`, '');
      out.push('Commits:', ...(r.commits || []).map((c) => `- \`${String(c.sha).slice(0, 9)}\` ${c.subject}`), '');
      for (const [name, list] of [['Not done', r.not_done], ['Risks', r.risks], ['Questions for the maintainer', r.user_questions], ['Gates', r.gates]]) {
        if (list && list.length) out.push(`${name}:`, ...list.map((x) => `- ${x}`), '');
      }
    }
  }
}
fs.writeFileSync(path.join(CTX, 'TASK_STATUS.md'), out.join('\n'));
console.log(`Wrote TASK_SPECS.md (${LANES.reduce((n, l) => n + l.tasks.length, 0)} tasks) and TASK_STATUS.md (${best.size} results).`);
