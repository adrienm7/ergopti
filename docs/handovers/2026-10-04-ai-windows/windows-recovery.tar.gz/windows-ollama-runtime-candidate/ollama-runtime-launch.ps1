# ollama-runtime-launch.ps1
# Runs the selected CLI in the foreground inside the caller's existing Job Object.
# This launcher creates no task, private staging file, model or global setting.

[CmdletBinding()]
param(
	[Parameter(Mandatory = $true)][string]$Executable,
	[Parameter(Mandatory = $true)][ValidateRange(1, 65535)][int]$Port,
	[Parameter(Mandatory = $true)][string]$ModelsDirectory
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Assert-LocalRegularPath([string]$Path, [bool]$Directory) {
	if ($Path -notmatch '^[A-Za-z]:\\' -or $Path.Contains("`r") -or $Path.Contains("`n")) {
		throw 'The runtime path must be an absolute local Windows path.'
	}
	$item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
	if ($item.PSProvider.Name -ne 'FileSystem' -or $item.PSIsContainer -ne $Directory) {
		throw 'The runtime path has the wrong native file shape.'
	}
	while ($null -ne $item) {
		if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
			throw 'Reparse points cannot authorize a managed runtime launch.'
		}
		$parent = if ($item.PSIsContainer) { $item.Parent } else { $item.Directory }
		$item = $parent
	}
}

try {
	Assert-LocalRegularPath $Executable $false
	Assert-LocalRegularPath $ModelsDirectory $true
	# Scope these values to this process and its descendants, never the driver.
	$env:OLLAMA_HOST = '127.0.0.1:' + $Port.ToString([Globalization.CultureInfo]::InvariantCulture)
	$env:OLLAMA_MODELS = $ModelsDirectory
	& $Executable serve
	if ($null -eq $LASTEXITCODE) {
		throw 'The foreground runtime returned no native exit status.'
	}
	exit $LASTEXITCODE
} catch {
	[Console]::Error.WriteLine('Owned Ollama launch failed: ' + $_.Exception.Message)
	exit 1
}
