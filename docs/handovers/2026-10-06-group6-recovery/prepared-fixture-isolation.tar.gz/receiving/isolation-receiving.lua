local root = "/workspace/ergopti/static/ergopti_plus/"
package.path = root .. "linux/?.lua;" .. root .. "linux/?/init.lua;" .. root .. "_shared/lua/?.lua;" .. root .. "_shared/lua/?/init.lua;" .. package.path
require("compat.utf8").install()
local helpers = require("tests.helpers")
dofile("/workspace/scratch/group6-prepared-native-port-isolation/candidate/static/ergopti_plus/linux/tests/unit/meta/test_prepared_native_port_import_isolation.lua")
local results = helpers.get_results()
print(string.format("RECEIVING: %d passed, %d failed", results.passed, results.failed))
assert(results.passed + results.failed == 7, "all seven receiving controls must execute")
os.exit(results.failed == 0 and 0 or 1)
