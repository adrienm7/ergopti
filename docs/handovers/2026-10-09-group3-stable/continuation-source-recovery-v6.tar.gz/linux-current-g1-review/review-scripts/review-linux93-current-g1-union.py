from pathlib import Path
import subprocess,json,hashlib,os,tarfile,shutil
B=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-current-g1-union-independent');B.mkdir(exist_ok=True)
P=Path('/workspace/.ergopti-cloud/preparations/group3-linux93-g1-published-union/freeze');V=Path('/workspace/.ergopti-cloud/reviews/group3-linux93-public-join-v3-independent');G='/workspace/ergopti';D='1028f6bd3eeb08a1aa50f96d1ad9738d2826d7bb';F='cbe96086b90ec8085895a505c0ee5a7975089dc3';OLD='f5ca71ad756a945cf4781222c1ccf636339d2aeb';PRIVATE='/workspace/.ergopti-cloud/continuation-2026-10-09/merged-devb06-validation';h=lambda b:hashlib.sha256(b).hexdigest()
def blob(n,rev=D,repo=G):return subprocess.check_output(['git','show',rev+':'+n],cwd=repo,stderr=subprocess.DEVNULL)
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def j(p,v):put(p,(json.dumps(v,indent=2)+'\n').encode())
r=json.loads((P/'receipt.json').read_text());c=json.loads((P/'composition.json').read_text());records=[]
for line in (P/'files.sha256').read_text().splitlines():
 sha,n=line.split('  ',1);assert not Path(n).is_absolute() and '..' not in Path(n).parts and h((P/n).read_bytes())==sha;records.append(n)
assert len(records)==406
for row in r['source_pairs']:
 try:a=blob(row['path'])
 except subprocess.CalledProcessError:a=None
 assert (h(a) if a else None)==row['pre_sha256'];assert h((P/'candidate'/row['path']).read_bytes())==row['post_sha256']
 if a:assert a==(P/'preimages'/row['path']).read_bytes()
 previous=blob(row['path'],OLD,PRIVATE);assert h(previous)==row['prior_qualified_post_sha256']
 if not row['overlap']:assert (P/'candidate'/row['path']).read_bytes()==previous
with tarfile.open(P/'source-pair.tar') as t:
 ms=t.getmembers();assert len(ms)==45 and len({m.name for m in ms})==45
 for m in ms:assert m.isfile() and '..' not in Path(m.name).parts and not m.name.startswith('/') and t.extractfile(m).read()==(P/m.name).read_bytes()
peels={}
for n in c['changed_overlaps']:
 s=(P/'candidate'/n).read_text()
 for row in c['exact_owned_hunks']:
  if row['path']==n:
   assert s.count(row['new_block'])==1 and h(row['new_block'].encode())==row['new_block_sha256']
   s=s.replace(row['new_block'],row['old_block'],1)
 assert s.encode()==blob(n)==blob(n,'96297a0d6b605a67eac2b48023f825b1e1572a0d')==blob(n,F)
 peels[n]={'whole_published_G1_image_exact':True,'sha256':h(s.encode())}
g1paths=subprocess.check_output(['git','show','--format=','--name-only',F],cwd=G,text=True).splitlines();assert len(g1paths)==31
other=[]
for n in g1paths:
 if n in c['changed_overlaps'] or n.endswith('/menu_manifest.json'):continue
 current=blob(n);original=blob(n,F);assert not (P/'candidate'/n).exists()
 assert current==original or n=='docs/ERGOPTIPLUS_TODO.md'
 other.append({'path':n,'published_current_sha256':h(current),'feature_sha256':h(original),'feature_bytes_equal':current==original,'changed_by_union':False})
assert len(other)==28 and sum(x['feature_bytes_equal'] for x in other)==27
Q=B/'projection';inputs=[]
for p in sorted((V/'projection').rglob('*')):
 if not p.is_file():continue
 n=str(p.relative_to(V/'projection'))
 try:b=blob(n)
 except subprocess.CalledProcessError:
  assert any(row['path']==n and row['pre_sha256'] is None for row in r['source_pairs']);continue
 put(Q/n,b);inputs.append({'path':n,'sha256':h(b),'source':D})
for n in g1paths:
 b=blob(n);put(Q/n,b);inputs.append({'path':n,'sha256':h(b),'source':D})
for row in r['source_pairs']:
 b=(P/'candidate'/row['path']).read_bytes();put(Q/row['path'],b);inputs.append({'path':row['path'],'sha256':h(b),'source':'frozen-current-G1-union'})
for p in (P/'generator-context').rglob('*'):
 if p.is_file():
  n=str(p.relative_to(P/'generator-context'));b=p.read_bytes();put(Q/n,b);inputs.append({'path':n,'sha256':h(b),'source':'frozen-private-generator-context'})
# Regenerate both exact owner contexts privately; no source expectation rewriting.
GEN=json.loads((P/'generation.json').read_text());genruns=[]
for context in ['generator-context','variants/manifest-g3-peeled-context']:
 out=B/'owner-generation'/context;out.mkdir(parents=True,exist_ok=True)
 for p in (P/context).rglob('*'):
  if p.is_file():put(out/p.relative_to(P/context),p.read_bytes())
 (out/'node_modules').symlink_to('/workspace/ergopti/node_modules',target_is_directory=True)
 for command in GEN['commands']:
  cp=subprocess.run(command.split(),cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
  name=context.replace('/','-')+'-'+command.split()[-1]+'.log';put(B/'logs'/name,cp.stdout);genruns.append({'context':context,'command':command,'exit':cp.returncode});assert cp.returncode==0
 for row in GEN['census']:
  if row['context']==context and row['generated']:
   b=(out/row['path']).read_bytes();assert h(b)==row['sha256']
base=B/'owner-generation/variants/manifest-g3-peeled-context/static/ergopti_plus/_shared/modules/menu/menu_manifest.json';union=B/'owner-generation/generator-context/static/ergopti_plus/_shared/modules/menu/menu_manifest.json'
assert base.read_bytes()==blob('static/ergopti_plus/_shared/modules/menu/menu_manifest.json')
a=json.loads(base.read_text());b=json.loads(union.read_text());changed=[k for k in set(a)|set(b) if a.get(k)!=b.get(k)];assert changed==['key_combinations_group']
# Exact standalone patch roundtrip on23 owned source images.
RT=B/'roundtrip';RT.mkdir(exist_ok=True);roundtrips=[]
for row in r['source_pairs']:
 if row['pre_sha256']:put(RT/row['path'],(P/'preimages'/row['path']).read_bytes())
for reverse in [False,True]:
 for check in [True,False]:
  args=['git','apply',*(['--reverse'] if reverse else []),*(['--check'] if check else []),str(P/'candidate.patch')];cp=subprocess.run(args,cwd=RT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert cp.returncode==0;roundtrips.append({'reverse':reverse,'check':check,'exit':cp.returncode})
 if not reverse:
  for row in r['source_pairs']:assert (RT/row['path']).read_bytes()==(P/'candidate'/row['path']).read_bytes()
for row in r['source_pairs']:
 if row['pre_sha256']:assert (RT/row['path']).read_bytes()==(P/'preimages'/row['path']).read_bytes()
 else:assert not (RT/row['path']).exists()
j(B/'preservation.json',{'author_seals':406,'actual_preimages_1028':23,'other21_prior_V3_postimages_exact':True,'complete_G1_peels':peels,'other28_G1_paths':other,'generated_owner_commands':genruns,'generated_output_hashes_all14_exact':True,'baseline_menu_equal_committed_1028':True,'only_changed_generated_group':changed,'source_patch_roundtrip_four':roundtrips})
j(B/'source-pins.json',{'inputs':inputs});put(B/'author-receipt.json',(P/'receipt.json').read_bytes());put(B/'author-results.json',(P/'results.json').read_bytes());put(B/'author-generation.json',(P/'generation.json').read_bytes())
# Our closed source runner cannot fall through to canonical sources.
R=B/'review-scripts';R.mkdir(exist_ok=True)
s=(V/'review-scripts/run.lua').read_text().replace("['platform.remap.tap_hold_manager']=true","['ui.menu.menu_builder']=true");put(R/'run.lua',s.encode())
probe=(P/'builder-delay-probe.lua').read_text();probe=probe[probe.index("local helpers=require('tests.helpers')"):];put(R/'builder-delay-probe.lua',probe.encode())
put(B/'variants/builder-g3-peeled/ui/menu/menu_builder.lua',blob('static/ergopti_plus/linux/ui/menu/menu_builder.lua'))
js=(P/'run_guard.cjs').read_text().replace("const tree='96297a0d6b605a67eac2b48023f825b1e1572a0d';const packet=__dirname;",f'const tree={json.dumps(D)};const packet={json.dumps(str(B))};').replace("path.join(packet,'candidate',rel)","path.join(packet,'projection',rel)").replace("path.join(packet,'generator-context',rel)","path.join(packet,'projection',rel)");put(R/'run_guard.cjs',js.encode())
results=[];env=os.environ.copy();env['TMPDIR']='/tmp';env['PATH']='/workspace/.ergopti-cloud/bin:'+env['PATH']
def run(case,args,expected):
 cp=subprocess.run(args,cwd=Q/'static/ergopti_plus/linux',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120);put(B/'logs'/(case+'.log'),cp.stdout);row={'case':case,'exit':cp.returncode,'expected_exit':expected,'summary':[s for s in cp.stdout.decode(errors='replace').splitlines() if 'INDEPENDENT_CONTROLLED' in s or 'ACTUAL_BUILDER_DELAY_CALLBACK' in s]};results.append(row);j(B/'results.json',results);print(row,flush=True);assert cp.returncode==expected
for abi in ['luajit','lua5.4']:
 for case,module in [('g1-ai','tests.unit.ui.test_ai_outer_parents'),('g1-hotstrings','tests.unit.ui.test_hotstrings_language_scope_frame'),('g3-menu','tests.unit.ui.test_key_combinations_menu')]:run(abi+'-'+case,[abi,str(R/'run.lua'),str(Q),module],0)
 for case,extra,expected in [('actual-builder',[],0),('builder-peeled',[str(B/'variants/builder-g3-peeled')],1)]:run(abi+'-'+case,[abi,str(R/'run.lua'),str(Q),str(R/'builder-delay-probe.lua'),*extra],expected)
for guard in ['test-hotstring-category-submenu-order.cjs','test-menu-unavailable-rows.cjs','test-menu-category-coverage.cjs','test-tap-hold-key-catalog-single-source.cjs','test-menu-first-group.cjs','test-platform-restrictions-explained.cjs','test-linux-feature-parity.cjs']:run('js-'+guard,['node',str(R/'run_guard.cjs'),'tools/test/'+guard],0)
# Whole declared-feature peel is correctly green; it is not a causal negative.
put(R/'peeled-manifest.json',json.dumps({'static/ergopti_plus/_shared/modules/features/manifest.toml':str(P/'preimages/static/ergopti_plus/_shared/modules/features/manifest.toml')}).encode())
run('js-conditional-whole-manifest-peeled',['node',str(R/'run_guard.cjs'),'tools/test/test-tap-hold-key-catalog-single-source.cjs',str(R/'peeled-manifest.json')],0)
print('SETTLED currentG1 bounded review controls; no full/native claim',flush=True)
