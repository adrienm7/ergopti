﻿; tests/unit/test_archive_intake_attachment.ahk

; ==============================================================================
; MODULE: Archive Intake Suspended-Construction Recording Controls
; DESCRIPTION:
; Exercises the actual attachment helpers with explicit no-kernel ports. These
; controls do not establish native job membership, handle identity or READY.
; ==============================================================================

_AIA_Attachment(Before, After) {
	return Map("before_job", Before, "after_job", After,
		"attach_attempted", false, "bind_attempted", false)
}

_AIA_ExactTupleOrder() {
	local calls := [], attachment := _AIA_Attachment(
		(Process) => (calls.Push("attach:" . Process), true),
		(Process, Job) => (calls.Push("bind:" . Process . ":" . Job), true))
	_SR_IntakeAttachBeforePrivateJob(attachment, 11)
	AssertEqual(calls.Length, 1)
	_SR_IntakeBindPrivateJob(attachment, 11, 22)
	AssertEqual(calls.Length, 2)
	AssertEqual(calls[1], "attach:11")
	AssertEqual(calls[2], "bind:11:22")
	AssertTrue(attachment["attach_attempted"])
	AssertTrue(attachment["bind_attempted"])
}

_AIA_RefusedAttachmentCannotRetry() {
	local calls := 0, attachment := _AIA_Attachment((*) => (++calls, false), (*) => true)
	AssertThrows(() => _SR_IntakeAttachBeforePrivateJob(attachment, 11))
	AssertTrue(attachment["attach_attempted"])
	AssertFalse(attachment["bind_attempted"])
	AssertThrows(() => _SR_IntakeAttachBeforePrivateJob(attachment, 11))
	AssertEqual(calls, 1)
}

_AIA_ThrowingBindRetainsAttempt() {
	local calls := 0, fail := (*) => (++calls, _AIA_Throw()),
		attachment := _AIA_Attachment((*) => true, fail)
	_SR_IntakeAttachBeforePrivateJob(attachment, 11)
	AssertThrows(() => _SR_IntakeBindPrivateJob(attachment, 11, 22))
	AssertTrue(attachment["bind_attempted"])
	AssertThrows(() => _SR_IntakeBindPrivateJob(attachment, 11, 22))
	AssertEqual(calls, 1)
}

_AIA_Throw() {
	throw Error("Controlled intake binding refusal.")
}

_AIA_ForgedTaskHasNoAttachment() {
	local calls := 0, port := (*) => (++calls, true)
	AssertThrows(() => _SR_IntakeConfigureTask({}, port, port))
	AssertEqual(calls, 0)
}

Test("archive-intake-exact-attachment-tuple", _AIA_ExactTupleOrder)
Test("archive-intake-attachment-refusal-once", _AIA_RefusedAttachmentCannotRetry)
Test("archive-intake-bind-throw-retained-once", _AIA_ThrowingBindRetainsAttempt)
Test("archive-intake-forged-task-no-effect", _AIA_ForgedTaskHasNoAttachment)
