#include "guardian_host.h"
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

static void GH_Debt(GH_Notice *notice,GG_Owner *owner,GG_Win32Context *context) {
    if(notice!=NULL){
        notice->first_error=owner!=NULL?owner->first_error:1u;
        notice->first_os_error=context!=NULL?context->first_os_error:GetLastError();
        InterlockedExchange(&notice->phase,GG_CLOSE_DEBT);
    }
    /* Module/process lifetime preserves all uncertain resources. No exception
       path publishes a success ACK or force-exits an unverified consumer. */
    for(;;)Sleep(1000u);
}

int GH_Run(HANDLE mapping) {
    GH_Config header;
    GH_Config *view;
    void *image;
    GH_Config *config;
    GH_Record *records;
    uint16_t *paths;
    GH_Notice *notice;
    GG_Content *contents;
    GG_Win32Context context={0};
    GG_Owner owner={0};
    size_t bytes,i,j;
    FILETIME exit_time,kernel,user;
    GG_Phase phase;
    view=MapViewOfFile(mapping,FILE_MAP_READ,0u,0u,sizeof(header));
    if(view==NULL)GH_Debt(NULL,NULL,NULL);
    memcpy(&header,view,sizeof(header));
    if(!UnmapViewOfFile(view))GH_Debt(NULL,NULL,NULL);
    bytes=sizeof(header);
    if(header.magic!=GH_CONFIG_MAGIC || header.id==0u || header.record_count==0u ||
        header.path_units==0u || (size_t)header.record_count>(SIZE_MAX-bytes)/sizeof(GH_Record))
        GH_Debt(NULL,NULL,NULL);
    bytes+=(size_t)header.record_count*sizeof(GH_Record);
    if((size_t)header.path_units>(SIZE_MAX-bytes)/sizeof(uint16_t))GH_Debt(NULL,NULL,NULL);
    bytes+=(size_t)header.path_units*sizeof(uint16_t);
    if(bytes!=header.bytes)GH_Debt(NULL,NULL,NULL);
    view=MapViewOfFile(mapping,FILE_MAP_READ,0u,0u,bytes);
    image=malloc(bytes);
    if(view==NULL || image==NULL)GH_Debt(NULL,NULL,NULL);
    memcpy(image,view,bytes);
    if(memcmp(image,&header,sizeof(header))!=0 || !UnmapViewOfFile(view))GH_Debt(NULL,NULL,NULL);
    if(!CloseHandle(mapping))GH_Debt(NULL,NULL,NULL);
    config=image;
    context.job=(HANDLE)(uintptr_t)config->job;context.parent=(HANDLE)(uintptr_t)config->parent;
    context.setup_process=(HANDLE)(uintptr_t)config->setup;context.stop=(HANDLE)(uintptr_t)config->stop;
    context.parent_pid=config->parent_pid;context.daemon_pid=config->daemon_pid;
    context.parent_creation=config->parent_creation;context.daemon_creation=config->daemon_creation;
    context.terminate_code=125u;
    notice=MapViewOfFile((HANDLE)(uintptr_t)config->notice,FILE_MAP_WRITE,0u,0u,sizeof(*notice));
    if(notice==NULL)GH_Debt(NULL,NULL,&context);
    memset(notice,0,sizeof(*notice));notice->magic=GH_CONFIG_MAGIC;notice->id=config->id;
    notice->pid=GetCurrentProcessId();
    if(!GetProcessTimes(GetCurrentProcess(),&notice->creation,&exit_time,&kernel,&user))GH_Debt(notice,NULL,&context);
    contents=calloc(config->record_count,sizeof(*contents));
    if(contents==NULL)GH_Debt(notice,NULL,&context);
    records=(GH_Record *)((uint8_t *)config+sizeof(*config));
    paths=(uint16_t *)((uint8_t *)records+(size_t)config->record_count*sizeof(*records));
    for(i=0u;i<config->record_count;++i){
        GH_Record *record=&records[i];
        if(record->handle==0u || record->handle==UINTPTR_MAX || record->kind>1u ||
            record->path_offset>=config->path_units || record->path_units==0u ||
            record->path_units>=config->path_units-record->path_offset ||
            paths[record->path_offset+record->path_units]!=0u)GH_Debt(notice,NULL,&context);
        for(j=0u;j<i;++j)if(records[j].handle==record->handle)GH_Debt(notice,NULL,&context);
        for(j=0u;j<record->path_units;++j)
            if(paths[record->path_offset+j]==0u)GH_Debt(notice,NULL,&context);
        contents[i].handle=(uintptr_t)record->handle;
    }
    if(!GG_Init(&owner,(uintptr_t)context.job,(uintptr_t)context.parent,
        (uintptr_t)context.stop,(uintptr_t)context.setup_process,contents,config->record_count,
        GG_Win32Port(&context))){
        if(!owner.job_bound)GH_Debt(notice,&owner,&context);
        if(!SetEvent(context.stop))GH_Debt(notice,&owner,&context);
    }
    for(i=0u;i<config->record_count;++i){
        GG_Win32Identity identity;
        identity.volume_serial=records[i].volume;identity.file_index_high=records[i].index_high;
        identity.file_index_low=records[i].index_low;identity.is_directory=records[i].kind;
        identity.native_path=(const wchar_t *)(paths+records[i].path_offset);
        if(!GG_Win32CheckContent(&context,(HANDLE)contents[i].handle,&identity)){
            /* The genuine job is already bound: even an admission refusal must
               observe parent death/stop without releasing content early. */
            if(!SetEvent(context.stop))GH_Debt(notice,&owner,&context);
            break;
        }
    }
    if(i==config->record_count && owner.first_error==0u){
        InterlockedExchange(&notice->ready,1);
        if(!SetEvent((HANDLE)(uintptr_t)config->ready))GH_Debt(notice,&owner,&context);
    }
    for(;;){
        phase=GG_Step(&owner);
        InterlockedExchange(&notice->phase,(LONG)phase);
        notice->first_error=owner.first_error;notice->first_os_error=context.first_os_error;
        if(phase==GG_RETIRED)break;
        if(phase==GG_CLOSE_DEBT || phase==GG_CONSTRUCTION_DEBT)GH_Debt(notice,&owner,&context);
        Sleep(10u);
    }
    if(!CloseHandle((HANDLE)(uintptr_t)config->ready))GH_Debt(notice,&owner,&context);
    InterlockedExchange(&notice->retired,1);
    if(!UnmapViewOfFile(notice))GH_Debt(notice,&owner,&context);
    notice=NULL;
    if(!CloseHandle((HANDLE)(uintptr_t)config->notice))GH_Debt(NULL,&owner,&context);
    free(contents);free(image);
    return context.first_os_error==ERROR_SUCCESS && owner.first_error==0u?0:1;
}

int wmain(int argc,wchar_t **argv) {
    wchar_t *end=NULL;
    unsigned long long handle;
    size_t i,units;
    if(argc!=3 || wcscmp(argv[1],L"--guardian-owned-config")!=0)return 2;
    units=wcslen(argv[2]);if(units==0u || units>sizeof(uintptr_t)*2u)return 2;
    for(i=0u;i<units;++i)if(!((argv[2][i]>=L'0'&&argv[2][i]<=L'9') ||
        (argv[2][i]>=L'a'&&argv[2][i]<=L'f')))return 2;
    handle=wcstoull(argv[2],&end,16);
    if(end==NULL || *end!=L'\0' || handle==0u || handle>=UINTPTR_MAX)return 2;
    return GH_Run((HANDLE)(uintptr_t)handle);
}
